package amgen.ri.rg.config;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;

/**
 * This implementation loads all context initialization parameters and provided
 * them as
 * configuration parameters.
 *
 * This is being transitioned away!!
 *
 * @version $Id: ContextConfigurationParameters.java,v 1.2 2011/10/26 04:13:07
 * cvs Exp $
 */
public class ContextConfigurationParameters extends AbstractConfigurationParameter implements ConfigurationParameterIF {
  public static ContextConfigurationParameters configurationParameters;
  private Map<ConfigurationParameterInstanceType, Map<String, String>> parameters;

  private ContextConfigurationParameters(ConfigurationParameterInstanceType rgVersion) {
    super(rgVersion);
    parameters = new HashMap<ConfigurationParameterInstanceType, Map<String, String>>();
    for (ConfigurationParameterInstanceType cpiType : ConfigurationParameterInstanceType.values()) {
      parameters.put(cpiType, new HashMap<String, String>());
    }
  }

  private ContextConfigurationParameters(ServletContext context) {
    super(context);

    parameters = new HashMap<ConfigurationParameterInstanceType, Map<String, String>>();
    for (ConfigurationParameterInstanceType cpiType : ConfigurationParameterInstanceType.values()) {
      parameters.put(cpiType, new HashMap<String, String>());
    }
    Enumeration paramNames = context.getInitParameterNames();
    while (paramNames.hasMoreElements()) {
      String paramName = paramNames.nextElement().toString();
      String paramValue = context.getInitParameter(paramName);
      boolean isInstanceType = false;
      for (ConfigurationParameterInstanceType cpiType : ConfigurationParameterInstanceType.values()) {
        if (paramName.endsWith("." + cpiType)) {
          isInstanceType = true;
          String name = paramName.substring(0, paramName.length() - cpiType.name().length() - 1);
          parameters.get(cpiType).put(name, paramValue);
        }
      }
      if (!isInstanceType) {
        parameters.get(ConfigurationParameterInstanceType.NONE).put(paramName, paramValue);
      }
    }
  }

  public static void init(ServletContext context) {
    System.err.println("Loading XMLConfigurationParameters...");
    configurationParameters = new ContextConfigurationParameters(context);
    System.err.println("Done.");
  }

  public static void init(ConfigurationParameterInstanceType rgVersion) {
    System.err.println("Loading XMLConfigurationParameters...");
    configurationParameters = new ContextConfigurationParameters(rgVersion);
    System.err.println("Done.");
  }

  public static ContextConfigurationParameters getInstance() {
    if (configurationParameters == null) {
      throw new IllegalArgumentException("ConfigurationParameters no intialized");
    }
    return configurationParameters;
  }

  @Override
  public String getConfigParameter(String parameterName) {
    String value = parameters.get(getRGVersion()).get(parameterName);
    if (value != null) {
      return value;
    }
    return parameters.get(ConfigurationParameterInstanceType.NONE).get(parameterName);
  }

  public String getConfigParameter(String parameterName, String rgVersion) {
    String value = parameters.get(ConfigurationParameterInstanceType.fromString(rgVersion)).get(parameterName);
    if (value != null) {
      return value;
    }
    return parameters.get(ConfigurationParameterInstanceType.NONE).get(parameterName);
  }
}
