package amgen.ri.rg.config;

import amgen.ri.util.ExtString;

/**
 *
 * @author jemcdowe
 */
public class ConfigurationParameterSource {

  public static String getConfigParameter(String parameterName) {
    String value = XMLConfigurationParameters.getInstance().getConfigParameter(parameterName);
    if (value != null) {
      return value;
    }
    return ContextConfigurationParameters.getInstance().getConfigParameter(parameterName);
  }

  public static String getConfigParameter(String parameterName, String rgVersion) {
    String value = XMLConfigurationParameters.getInstance().getConfigParameter(parameterName, rgVersion);
    if (value != null) {
      return value;
    }
    return ContextConfigurationParameters.getInstance().getConfigParameter(parameterName, rgVersion);
  }

  /**
   *
   * @return
   */
  public static ConfigurationParameterInstanceType getRGVersion() {
    ConfigurationParameterInstanceType value = XMLConfigurationParameters.getInstance().getRGVersion();
    if (value != null) {
      return value;
    }
    return ContextConfigurationParameters.getInstance().getRGVersion();
  }

  /**
   *
   * @param parameterName
   * @return
   */
  public static Double getConfigParameterNumber(String parameterName) {
    return ExtString.toDouble(getConfigParameter(parameterName));
  }
}
