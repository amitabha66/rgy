package amgen.ri.rg.config;

import amgen.ri.util.ExtString;
import javax.servlet.ServletContext;

/**
 * <p>@version $Id: AbstractConfigurationParameter.java,v 1.1 2013/07/09 18:32:09 jemcdowe Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public abstract class AbstractConfigurationParameter implements ConfigurationParameterIF {
  private ConfigurationParameterInstanceType rgVersion;

  public AbstractConfigurationParameter(ConfigurationParameterInstanceType rgVersion) {
    super();
    this.rgVersion = rgVersion;
    if (this.rgVersion == null || this.rgVersion.equals(ConfigurationParameterInstanceType.UNKNOWN)) {
      throw new IllegalArgumentException("Unknown RG version");
    }
  }

  public AbstractConfigurationParameter(ServletContext context) {
    super();
    String rgVersion = context.getInitParameter("AIG_VERSION");
    if (rgVersion == null) {
      rgVersion = context.getInitParameter("RG_VERSION");
    }
    this.rgVersion = ConfigurationParameterInstanceType.fromString(rgVersion);
    if (this.rgVersion == null || this.rgVersion.equals(ConfigurationParameterInstanceType.UNKNOWN)) {
      throw new IllegalArgumentException("Unknown RG version");
    }
  }

  public Double getConfigParameterNumber(String parameterName) {
    return ExtString.toDouble(getConfigParameter(parameterName));
  }

  public ConfigurationParameterInstanceType getRGVersion() {
    return rgVersion;
  }
}
