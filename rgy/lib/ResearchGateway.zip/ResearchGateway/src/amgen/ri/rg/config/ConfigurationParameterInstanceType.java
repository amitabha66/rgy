package amgen.ri.rg.config;


/**
 * <p>@version $Id: ConfigurationParameterInstanceType.java,v 1.1 2013/07/09 18:32:09 jemcdowe Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public enum ConfigurationParameterInstanceType {
    NONE, DEV, TEST, PROD, UNKNOWN;

    public static ConfigurationParameterInstanceType fromString(String s) {
        if (s == null) {
            return UNKNOWN;
        }
        try {
            return ConfigurationParameterInstanceType.valueOf(s.toUpperCase().replace(' ', '_'));
        } catch (Exception e) {
            return UNKNOWN;
        }
    }

}
