package amgen.ri.rg.resource;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.CacheManagerFactory;
import amgen.ri.aig.cache.CacheManagerIF;
import static amgen.ri.aig.cache.service.AbstractServiceCache.SERVICECONNECTION_TIMEOUTMILLIS;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.asf.sa.uddi.UDDIDetails;
import amgen.ri.asf.sa.uddi.UDDIQuery;
import amgen.ri.rg.config.ConfigurationParameterSource;
import java.io.*;
import java.net.MalformedURLException;
import java.sql.*;
import javax.naming.NoInitialContextException;
import javax.servlet.http.HttpSession;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.log4j.Logger;

/**
 *
 * @author jemcdowe
 */
public abstract class ResourceFactory implements Serializable {

  public static final int SERVICECONNECTION_TIMEOUTMILLIS = 1000;

  private EntityClassManager entityClassManager;
  private HttpSession session;
  private CacheManagerIF localCacheMgr;
  private CacheManagerIF globalCacheMgr;
  private UDDIQuery uddiQuery;

  private enum ConnectionPoolType {

    RG
  };

  protected ResourceFactory() {
  }

  protected ResourceFactory(HttpSession session) throws AIGException {
    this.session = session;
    localCacheMgr = CacheManagerFactory.getCacheManagerInstance(session);
    globalCacheMgr = CacheManagerFactory.getOracleCacheManagerInstance(AIGSessionLogin.getAIGSessionLogin(session).getUsername());
  }

  protected ResourceFactory(EntityClassManager entityClassManager) {
    if (entityClassManager != null) {
      this.entityClassManager = entityClassManager;
    }
  }

  /**
   * @return the entityClassManager
   */
  public EntityClassManager getEntityClassManager() {
    if (entityClassManager == null) {
      setEntityClassManager(new EntityClassManager());
    }
    return entityClassManager;
  }

  /**
   * @param entityClassManager the entityClassManager to set
   */
  public void setEntityClassManager(EntityClassManager entityClassManager) {
    this.entityClassManager = entityClassManager;
  }

  /**
   * @return the session
   */
  public HttpSession getSession() {
    return session;
  }

  /**
   * Returns the UDDI Query object
   *
   * @return the uddiQuery
   */
  protected UDDIQuery getUDDIQuery() {
    if (uddiQuery == null) {
      String uddiURL = ConfigurationParameterSource.getConfigParameter("UDDI_QUERY_URL");
      try {
        if (uddiURL == null) {
          uddiQuery = new UDDIQuery(null);
        } else {
          uddiQuery = new UDDIQuery(new UDDIDetails(uddiURL));
        }
        uddiQuery.setConnectionTimeoutMillis(SERVICECONNECTION_TIMEOUTMILLIS);
        uddiQuery.setMsgLogger(Logger.getLogger("rgservice"));
      } catch (MalformedURLException ex) {
        ex.printStackTrace();
      }
    }
    return uddiQuery;
  }

  /**
   * Function to create connection with database and to read the xml files used
   * for mapping.
   */
  public SqlSessionFactory getSqlSessionFactory(String factoryID) {
    SqlSessionFactory sqlSessionFactory = null;
    try {
      String resource = "rg.mybatis.config.xml";
      Reader reader = Resources.getResourceAsReader(resource);
      sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader, factoryID);
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
    return sqlSessionFactory;
  }

  /**
   * Returns a SqlSession for RG
   *
   * @return
   */
  public SqlSession getRGSqlSession() {
    try {
      return getSqlSession("rg");
    } catch (Exception e) {
      return getSqlSession("rg-direct");
    }
  }

  /**
   * Returns a SqlSession for RG
   *
   * @return
   */
  public SqlSession getSqlSession(String factoryID) {
    return getSqlSessionFactory(factoryID).openSession();
  }

  public void closeResources(Connection conn) {
    try {
      conn.close();
    } catch (Exception e) {
    }
  }

  public static void close(Statement stmt) {
    if (stmt != null) {
      try {
        stmt.close();
      } catch (Throwable t) {
      }
    }
  }

  public static void close(Connection conn) {
    if (conn != null) {
      try {
        conn.close();
      } catch (Throwable t) {
      }
    }
  }

  public static void close(ResultSet rset) {
    if (rset != null) {
      try {
        rset.close();
      } catch (Throwable t) {
      }
    }
  }

  public static void close(SqlSession sqlSession) {
    if (sqlSession != null) {
      try {
        sqlSession.close();
      } catch (Throwable t) {
      }
    }
  }

  public static void commitAndClose(SqlSession sqlSession) {
    if (sqlSession != null) {
      try {
        sqlSession.commit();
      } catch (Throwable t) {
      }
      close(sqlSession);
    }
  }

  /**
   * @return the localCacheMgr
   */
  public CacheManagerIF getLocalCacheMgr() {
    return localCacheMgr;
  }

  /**
   * @return the globalCacheMgr
   */
  public CacheManagerIF getGlobalCacheMgr() {
    return globalCacheMgr;
  }
}
