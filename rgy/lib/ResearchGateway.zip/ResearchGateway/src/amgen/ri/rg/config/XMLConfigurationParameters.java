package amgen.ri.rg.config;

import amgen.ri.xml.ExtXMLElement;
import java.io.IOException;
import java.util.List;
import org.apache.log4j.Logger;
import org.jdom.Document;
import org.jdom.Element;

/**
 * This implementation loads configuration parameters from an XML document.
 *
 * This is being transitioned in!!

 * <p>@version $Id: XMLConfigurationParameters.java,v 1.3 2015/05/28 17:24:17 jemcdowe Exp $</p>

 */
public class XMLConfigurationParameters extends AbstractConfigurationParameter implements ConfigurationParameterIF {
  public static String CONFIG_FILENAME = "/rg.config.xml";
  private static XMLConfigurationParameters instance;
  private Document configDoc;

  private XMLConfigurationParameters(ConfigurationParameterInstanceType rgVersion) throws IOException {
    super(rgVersion);
    loadXMLDocument();
  }

  public static void init() throws IOException {
    Document configDoc= getXMLDocument();
    System.err.println("Loading XMLConfigurationParameters...");
    ConfigurationParameterInstanceType rgVersion= ConfigurationParameterInstanceType.fromString(ExtXMLElement.getXPathValue(configDoc, "/RGConfiguration/Config[@name='RG_VERSION']/@value"));
    instance = new XMLConfigurationParameters(rgVersion);
    System.err.println("Done ["+instance.getRGVersion()+"]");
  }

  public static void init(Logger logger) throws IOException {
    Document configDoc= getXMLDocument();
    logger.info("Loading XMLConfigurationParameters...");
    ConfigurationParameterInstanceType rgVersion= ConfigurationParameterInstanceType.fromString(ExtXMLElement.getXPathValue(configDoc, "/RGConfiguration/Config[@name='RG_VERSION']/@value"));
    instance = new XMLConfigurationParameters(rgVersion);
    logger.info("Done ["+instance.getRGVersion()+"]");
  }

  public static void init(ConfigurationParameterInstanceType rgVersion) throws IOException {
    System.err.println("Loading XMLConfigurationParameters...");
    instance = new XMLConfigurationParameters(rgVersion);
    System.err.println("Done.");
  }

  public static void init(AbstractConfigurationParameter config) throws IOException {
    init(config.getRGVersion());
  }

  private void loadXMLDocument() throws IOException {
    configDoc = getXMLDocument();
    if (configDoc == null) {
      throw new IOException("Unable to load Research Gateway configuration file. " + CONFIG_FILENAME);
    }
  }

  private static Document getXMLDocument() throws IOException {
    return ExtXMLElement.toDocument(XMLConfigurationParameters.class, CONFIG_FILENAME);
  }

  public static XMLConfigurationParameters getInstance() {
    if (instance == null) {
      throw new IllegalArgumentException("No RGConfiguration instance. init() must be called prior to calling.");
    }
    return instance;
  }


  public String getConfigParameter(String name) {
    return getConfigParameter(name, this.getRGVersion().toString());
  }

  public String getConfigParameter(String name, String rgVersion) {
    try {
      loadXMLDocument();
    } catch (IOException ex) {
      ex.printStackTrace();
      return null;
    }
    String xpath = "/RGConfiguration/Config[upper-case(@name)='" + name.toUpperCase() + "'][upper-case(@version)='" + rgVersion.toUpperCase() + "' or count(@version)=0]";
    List<Element> configEls = ExtXMLElement.getXPathElements(configDoc, xpath);
    if (configEls.size() == 0) {
      return null;
    }
    Element versionedConfigEl = configEls.get(0);
    for (Element configEl : configEls) {
      String versionAttr = configEl.getAttributeValue("version");
      if (versionAttr != null) {
        versionedConfigEl = configEl;
      }
    }
    if (versionedConfigEl != null) {
      String value = versionedConfigEl.getChildText("Value");
      if (value == null) {
        value = versionedConfigEl.getAttributeValue("value");
      }
      return value;
    }
    return null;
  }
}
