package amgen.ri.rg.config;


/**
 * Implementations handle accessing configuration parameters.
 * @version $Id: ConfigurationParameterIF.java,v 1.1 2013/07/09 18:32:09 jemcdowe Exp $
 */
public interface ConfigurationParameterIF {
    /**
     * Returns a config parameter as a String. null if it does not exist.
     *
     * @param parameterName String
     * @return String
     */
    public String getConfigParameter(String parameterName);

    /**
     * Returns a config parameter as a Double. NaN if it does not exist.
     *
     * @param parameterName String
     * @return Double
     */
    public Double getConfigParameterNumber(String parameterName);

    public ConfigurationParameterInstanceType getRGVersion();
}
