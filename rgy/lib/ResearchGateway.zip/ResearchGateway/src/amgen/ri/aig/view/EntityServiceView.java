package amgen.ri.aig.view;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.asf.sa.uddi.ServiceDetails;


/**
 * An abstract class for viewer classes used for providing the view for the
 * Entity service content
 */
public abstract class EntityServiceView {
    private AIGServlet aigServlet;


    public EntityServiceView(AIGServlet aigServlet) {
        super();
        setAigServlet(aigServlet);
    }

    /**
     * Renders the result to either the response
     *
     * @param resultObj Object
     * @param parentResultItem Writer
     * @param response OutputStream
     * @throws IOException
     */
    public abstract void renderServiceResult(Object resultObj, ServiceResultCacheItem parentResultItem, ServiceDetails serviceDetails, HttpServletRequest request, HttpServletResponse response) throws
            IOException, AIGException;

    /**
     * Returns the mimetype for the view
     *
     * @return String
     */
    public abstract String getViewMimetype();

    public void setAigServlet(AIGServlet aigServlet) {
        this.aigServlet = aigServlet;
    }

    public AIGServlet getAigServlet() {
        return aigServlet;
    }
}
