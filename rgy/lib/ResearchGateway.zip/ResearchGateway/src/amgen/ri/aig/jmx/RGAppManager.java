package amgen.ri.aig.jmx;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.CacheManagerFactory;
import amgen.ri.aig.cache.CacheType;
import amgen.ri.util.Debug;
import javax.servlet.http.HttpSession;

/**
 * <p>@version $Id: RGAppManager.java,v 1.3 2014/07/08 15:51:49 jemcdowe Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class RGAppManager implements RGAppManagerMBean {

    public String getServiceCacheStats() {
        try {
            return CacheManagerFactory.getOracleCacheManagerInstance(null).getStats();
        } catch (Exception ex) {
            return "Unable to return statistics";
        }
    }

    /**
     * refreshServiceCache
     *
     * @todo Implement this amgen.ri.rg.jmx.RGAppManagerMBean method
     */
    public void refreshServiceCache() {
        try {
            CacheManagerFactory.getOracleCacheManagerInstance(null).clear();
            Debug.print("Global Service Cache: Cleared");
        } catch (Exception ex) {
        }
    }


    public void deleteCache(String cacheType) {
        try {
            CacheManagerFactory.getOracleCacheManagerInstance(null).clear(CacheType.fromString(cacheType));
            Debug.print("Global Service Cache: " + cacheType + " Cleared");
        } catch (Exception ex) {
        }
    }
}
