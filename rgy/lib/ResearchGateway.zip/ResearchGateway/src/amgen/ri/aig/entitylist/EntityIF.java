/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.entitylist;

import amgen.ri.aig.category.schema2.EntityListCategory;

/**
 *
 * @author jemcdowe
 */
public interface EntityIF {

  public String getDataValue();

  public String getDescription();

  public String getLabel();

  public EntityListCategory getEntityCategory();
  
}
