package amgen.ri.aig.sv;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jdom.Element;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.tree.EntityLineage;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.service.ServiceCacheResponse;
import amgen.ri.aig.cache.tree.TreeNodeCache;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.export.ExportUtils;
import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.aig.uddi.ServiceQuery;
import amgen.ri.asf.sa.uddi.ClassificationSchemeNames;
import amgen.ri.asf.sa.uddi.ClassificationSchemeQuery;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtFile;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EntityNodeDocumentRetrieval extends AIGServlet {

    private String documentID;
    private String documentName;
    private URL documentURL;
    private String mimetype;

    public EntityNodeDocumentRetrieval() {
        super();
    }

    public EntityNodeDocumentRetrieval(HttpServletRequest req, HttpServletResponse resp) {
        super(req, resp);
        try {
            if (doesParameterExist("resultKey", true)) {
                Element resultNode = TreeNodeCache.getTreeNodeCache(request).getTreeNode(getParameter("resultKey"));
                if (resultNode != null) {
                    mimetype = resultNode.getAttributeValue("MIMETYPE");
                }
                EntityLineage resultNodeEntityLineage = EntityLineage.getEntityLineageForTreeNode(resultNode);
                documentID = resultNodeEntityLineage.getDataValue();
                documentName = resultNode.getAttributeValue("TEXT");
            } else if (doesParameterExist("document_id", true)) {
                documentID = getParameter("document_id");
                documentName = getParameter("document_name");
                mimetype = getParameter("mimetype");
            } else {
                try {
                    documentURL = new URL(getParameter("document_url"));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (AIGException ex) {
        }
    }

    /**
     * Creates this AIG Servlet object
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return AIGServlet
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new EntityNodeDocumentRetrieval(req, resp);
    }

    /**
     * Handles the servlet request
     *
     * @throws ServletException
     * @throws IOException
     */
    public void performRequest() throws ServletException, IOException, AIGException {
        printRequest();
        if (documentID != null && documentName != null && mimetype != null) {
            ClassificationSchemeQuery classificationSchemeQuery = new ClassificationSchemeQuery();
            classificationSchemeQuery.addKeyValue(ClassificationSchemeNames.getName(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME), "Document");
            ServiceQuery serviceQuery= new ServiceQuery(classificationSchemeQuery, TModelCommonNameFactory.DOCUMENTRAWDATADEFINITION_tMODELNAME);
            
            ServiceCacheResponse documentRetrievalServices = ServiceCache.getServiceCache(request).getServices(serviceQuery);
            if (documentRetrievalServices.isEmpty()) {
                System.err.println("No document retrieval service found");
                return;
            }
            try {
                String extension = new ExportUtils().getExtension(mimetype);
                String docName = documentName
                        + (documentName.endsWith("." + extension) ? "" : "." + extension);
                response.addHeader("Content-disposition", "attachment; filename=" + docName.replaceAll("\\s+", "_"));

                ServiceDetails documentRetrievalService = documentRetrievalServices.get(0);
                documentRetrievalService.setParameterValue(ClassificationSchemeNames.getName(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME),
                        "Document", documentID);
                
                documentRetrievalService.setParameterValue(ClassificationSchemeNames.getName(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME), 
                        "Amgen Session Login", ((AIGSessionLogin) getSessionLogin()).getUsername());
                
                Object result = documentRetrievalService.executeService();
                if (result == null) {
                } else if (result instanceof byte[]) {
                    response.getOutputStream().write((byte[]) result);
                } else if (result instanceof String) {
                    response.getOutputStream().print((String) result);
                }
            } catch (Exception ex) {
                throw new AIGException(AIGException.Reason.UNABLE_TO_RUN_SERVICE, ex);
            }
        }

        if (documentURL != null) {
            String[] fields = documentURL.toString().split("\\.");
            String extension = fields[fields.length - 1];
            String mimetype = new ExportUtils().getMimetypeByExtension(extension);
            response.addHeader("Content-disposition", "attachment; filename=" + new File(documentURL.getFile()).getName());
            response.setContentType(mimetype);
            ExtFile.copy(documentURL.openStream(), response.getOutputStream());
            return;
        }

    }

    /**
     * Returns the mimetype of the servlet
     */
    protected String getServletMimeType() {
        return mimetype;
    }
}
