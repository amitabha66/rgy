package amgen.ri.aig.event;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.aig.AIGResponseMessage;
import amgen.ri.aig.AIGServlet;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.xml.ExtXMLElement;

/**
 * @version $Id: SessionPinger.java,v 1.3 2011/10/24 22:53:06 cvs Exp $
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class SessionPinger extends AIGServlet {
    /**
     * Default constructor
     */
    public SessionPinger() {
        super();
    }

    /**
     * Standard constructor which creates a new AIGServlet
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     */
    public SessionPinger(HttpServletRequest req, HttpServletResponse resp) {
        super(req, resp);
    }


    /**
     * Returns the getAIGServlet implementation class for the request
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return TBXServlet
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new SessionPinger(req, resp);
    }

    /**
     * Actual work entry stub
     * @throws ServletException
     * @throws IOException
     */
    protected void performRequest() throws Exception {
        AIGSessionLogin sessionLogin = null;
        try {
            if (request.getSession(false) != null) {
                sessionLogin = AIGSessionLogin.getAIGSessionLogin(request);
                if (sessionLogin != null) {
                    Double sessionIdleMinutes = ConfigurationParameterSource.getConfigParameterNumber("amgen.ri.aig.event.SessionPinger.SessionIdleMinutes");
                    if (!Double.isNaN(sessionIdleMinutes) && sessionLogin.hasBeenLongerThanMinutesSinceLastAccess(sessionIdleMinutes)) {
                        request.getSession(false).invalidate();
                        sessionLogin = null;
                    }
                }
            }
        } catch (Exception e) {}
        if (sessionLogin == null) {
            AIGResponseMessage.writeErrorElement("SessionPinger", "No Session Found", "No Session Found", response);
        } else {
            ExtXMLElement.write(sessionLogin.getSessionElement(), response.getWriter());
        }
    }

    /**
     * Returns the mimetype of the servlet
     */
    protected String getServletMimeType() {
        return "text/xml";
    }

}
