package amgen.ri.aig.entitylist;

import java.util.ArrayList;
import java.util.List;

import amgen.ri.aig.category.schema2.EntityListCategory;

/**
 * Concrete implementation of the EntityListIF which uses an ArrayList for the
 * members
 */
public class GenericEntityList extends AbstractEntityList {
    private List<EntityListMemberIF> members;
    private String listName;
    private String listDescription;
    private EntityListCategory category;
    private EntityListSourceServiceIF sourceService;


    public GenericEntityList(String listName, String listDescription, EntityListCategory category) {
        super();
        this.listName = listName;
        this.listDescription = listDescription;
        this.category = category;
        this.members = new ArrayList<EntityListMemberIF>();
    }

    public GenericEntityList(String listName, String listDescription, EntityListCategory category, int listMemberCount) {
        super(listMemberCount);
        this.listName = listName;
        this.listDescription = listDescription;
        this.category = category;
        this.members = new ArrayList<EntityListMemberIF>();
    }

    public GenericEntityList(String listName, String listDescription, EntityListCategory category, EntityListMemberIF member) {
        this(listName, listDescription, category);
        this.members.add(member);
    }

    public GenericEntityList(String listName, String listDescription, EntityListCategory category, List<EntityListMemberIF> members) {
        this(listName, listDescription, category);
        this.members.addAll(members);
    }

    /**
     *
     * @return EntityListCategory
     */
    public EntityListCategory getEntityCategory() {
        return category;
    }

    /**
     *
     * @return String
     */
    public String getListDescription() {
        return listDescription;
    }

    /**
     *
     * @return List
     */
    public List<EntityListMemberIF> getListMembers() {
        return members;
    }

    /**
     *
     * @return String
     */
    public String getListName() {
        return listName;
    }

    /**
     *
     * @return EntityListSourceServiceIF
     */
    public EntityListSourceServiceIF getSourceService() {
        return null;
    }

    public void setSourceService(EntityListSourceServiceIF sourceService) {
        this.sourceService = sourceService;
    }
}
