package amgen.ri.aig.cache.tree;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.servlet.SessionLogin;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtDate;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.util.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;

/**
 * Retrieves a TreeNode from the TreeNode cache with optional paging
 *
 * @version $id$
 */
@WebServlet(name = "TreeNodeCacheRetrieval", urlPatterns = {"/treenodecacheretrieval.go", "/treenodecacheretrieval"})
public class TreeNodeCacheRetrieval extends AIGServlet {
  private String nodePagingTextFormat = "%s [%d - %d of %d]";
  private String nodeCountTextFormat = "%s [%d]";
  private int pagesize = 25;

  enum TreeNodeCacheRetrievalRequest {
    ALLCHILDREN, ASLIST, UNKNOWN;

    public static TreeNodeCacheRetrievalRequest fromString(String s) {
      try {
        return TreeNodeCacheRetrievalRequest.valueOf(s.toUpperCase());
      } catch (Exception e) {
      }
      return UNKNOWN;
    }
  };

  /**
   * Default constructor
   */
  public TreeNodeCacheRetrieval() {
    super();
  }

  /**
   * Main constructor- used only by the getAIGServlet method
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   */
  private TreeNodeCacheRetrieval(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  /**
   * Creates this AIG Servlet object
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return AIGServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new TreeNodeCacheRetrieval(req, resp);
  }

  /**
   *
   * @return String
   */
  protected String getServletMimeType() {
    return "text/xml";
  }

  /**
   *
   * @throws Exception
   */
  protected void performRequest() throws Exception {
    final TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(request);
    SessionLogin sessionLogin = getSessionLogin();

    if (ExtString.equals(getParameter("uuid"), "ROOT")) {
      return;
    }

    switch (TreeNodeCacheRetrievalRequest.fromString(getParameter("op"))) {
      case ALLCHILDREN:
        response.setContentType("text/json");
        buildJSONObjectsFromCache(getParameter("uuid")).write(response.getWriter());
        break;
      case ASLIST:
        TreeNode parentTreeNode = tnCache.getTreeNodeObj(getParameter("uuid"));
        Document childTreeNodesDoc = buildTreeNodesFromCache(getParameter("uuid"), true);
        List<Element> childTreeNodesEls = ExtXMLElement.getXPathElements(childTreeNodesDoc, "//TREENODE[@NODE_TYPE='ENTITYNODE']");
        Element entityListEl = new Element("EntityList");
        entityListEl.setAttribute("name", parentTreeNode.getText());
        entityListEl.setAttribute("member_count", "" + childTreeNodesEls.size());
        entityListEl.setAttribute("description", (parentTreeNode.getDescription() == null ? "" : parentTreeNode.getDescription()));
        entityListEl.setAttribute("category", parentTreeNode.getEntityListCategory(getEntityClassManager()) + "");

        ExtXMLElement.addAttribute(entityListEl, "created_by", getSessionLogin().getUserPreferredDisplayName());
        entityListEl.setAttribute("created", ExtDate.getDateStringDate(AIGBase.DATE_FORMAT, new Date()));
        ExtXMLElement.addAttribute(entityListEl, "modified_by", sessionLogin.getUserPreferredDisplayName());
        entityListEl.setAttribute("modified", ExtDate.getDateStringDate(AIGBase.DATE_FORMAT, new Date()));
        entityListEl.setAttribute("list_id", parentTreeNode.getKey());
        for (Element childTreeNodeEl : childTreeNodesEls) {
          TreeNode childTreeNode = new TreeNode(childTreeNodeEl);
          Element entityListMemberEl = ExtXMLElement.addElement(entityListEl, "EntityListMember");
          entityListMemberEl.setAttribute("member", childTreeNode.getServiceData());
          entityListMemberEl.setAttribute("entity_id", childTreeNode.getServiceData());
          entityListMemberEl.setAttribute("label", childTreeNode.getText());
        }
        ExtXMLElement.write(entityListEl, response.getWriter(), usASCIIFormat);
        break;
      default:
        Document pageTreeNodes = buildTreeNodesFromCache(getParameter("uuid"), doesParameterExist("nopaging"));
        ExtXMLElement.write(pageTreeNodes, response.getWriter(), usASCIIFormat);
        break;
    }
  }

  public JSONObject buildJSONObjectsFromCache(String parentTreeNodeKey) throws AIGException, JSONException {
    final TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(request);
    JSONObject jChildNodesObj = new JSONObject();
    Element parentNode = tnCache.getTreeNode(parentTreeNodeKey);
    if (parentNode != null) {
      List<String> childUUIDs = tnCache.getChildTreeNodeKeys(parentTreeNodeKey);
      for (String childUUID : childUUIDs) {
        TreeNode treeNode = new TreeNode(tnCache.getTreeNode(childUUID));
        if (treeNode.getNodeType().equals(NodeType.ENTITYNODE)) {
          JSONObject jEntityNode = new JSONObject();
          jEntityNode.put("key", treeNode.getKey());
          jEntityNode.put("name", treeNode.getText());
          jEntityNode.put("description", treeNode.getDescription());
          jChildNodesObj.append("nodes", jEntityNode);
        }
      }
    }
    return jChildNodesObj;
  }

  public Document buildTreeNodesFromCache(String parentTreeNodeKey, boolean nopaging) throws AIGException {
    final TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(request);
    if (doesParameterEqual("request", "rename") && doesParameterExist("newname", true)) {
      tnCache.renameTreeNode(parentTreeNodeKey, getParameter("newname"));
    }

    Element parentNode = tnCache.getTreeNode(parentTreeNodeKey);
    Number page = getParameterNumber("page");
    String request = getParameter("request");
    String sort = getParameter("sort");
    String findValue = getParameter("find");
    boolean includeparent = doesParameterExist("includeparent"); //Generally only for debug use
    Element treeNodes = new Element("TREENODES");
    if (parentNode == null) {
      return new Document(treeNodes);
    }
    if (includeparent) {
      treeNodes.addContent((Element) parentNode.clone());
    }
    Element pageUpNode = null;
    Element pageDownNode = null;
    String updatedParentNodeText = null;
    List<String> childUUIDs = tnCache.getChildTreeNodeKeys(parentTreeNodeKey);

    TreeNodeFilter treeNodeFilter = tnCache.getTreeNodeFilter(parentTreeNodeKey);
    if (sort != null) {
      List<Element> childTreeNodesEl = tnCache.getTreeNodes(childUUIDs);
      int mod = 1;
      if (sort.startsWith("asc")) {
        mod = -1;
      }
      int[] sortIndx = ExtArray.quicksort(childTreeNodesEl, new TreeNodeComparator(sort));
      tnCache.setTreeNodeChildrenSortIndex(parentTreeNodeKey, sortIndx);
      page = 0;
    }
    int childNodeCount = childUUIDs.size();
    int[] sortIndexes = tnCache.getTreeNodeChildrenSortIndex(parentTreeNodeKey);
    if (sortIndexes != null && sortIndexes.length != childNodeCount) {
      sortIndexes = null;
    }
    int start = 0;
    int end = childNodeCount;
    if (childNodeCount > pagesize && !nopaging) {
      if (Double.isNaN(page.doubleValue())) {
        page = 0;
      }
      int pageCount = (int) ((double) childNodeCount / (double) pagesize) + (((double) childNodeCount % (double) pagesize) == 0 ? 0 : 1);
      if (doesParameterEqual("request", "first")) {
        page = 0;
      } else if (doesParameterEqual("request", "next")) {
        page = page.intValue() + 1;
      } else if (doesParameterEqual("request", "previous")) {
        page = page.intValue() - 1;
      } else if (doesParameterEqual("request", "last")) {
        page = pageCount - 1;
      } else if (doesParameterExist("find")) {
        page = findPageForValue(getParameter("find"), parentTreeNodeKey, pageCount, pagesize);
        ExtXMLElement.addAttribute(treeNodes, "select_by_text", getParameter("find"));
      }
      start = page.intValue() * pagesize;
      end = Math.min(childNodeCount, start + pagesize);
      if (start > 0) {
        pageUpNode = new Element("TREENODE");
        pageUpNode.setAttribute("TEXT", "Previous");
        pageUpNode.setAttribute("NODE_TYPE", NodeType.PAGEUPNODE + "");
        pageUpNode.setAttribute("NODE_COUNT", childNodeCount + "");
        pageUpNode.setAttribute("PAGESIZE", pagesize + "");
        pageUpNode.setAttribute("PAGECOUNT", pageCount + "");
        pageUpNode.setAttribute("UUID", UUID.randomUUID() + "");
      }
      if (end < childNodeCount) {
        pageDownNode = new Element("TREENODE");
        pageDownNode.setAttribute("TEXT", "Next");
        pageDownNode.setAttribute("NODE_TYPE", NodeType.PAGEDOWNNODE + "");
        pageDownNode.setAttribute("NODE_COUNT", childNodeCount + "");
        pageDownNode.setAttribute("PAGESIZE", pagesize + "");
        pageDownNode.setAttribute("PAGECOUNT", pageCount + "");
        pageDownNode.setAttribute("UUID", UUID.randomUUID() + "");
      }
      updatedParentNodeText = String.format(nodePagingTextFormat, new Object[]{
                parentNode.getAttributeValue("TEXT"), (start + 1), end, childNodeCount});
    } else {
      updatedParentNodeText = String.format(nodeCountTextFormat, new Object[]{parentNode.getAttributeValue("TEXT"), childNodeCount});
    }

    for (int i = start; i < end; i++) {
      int index = (sortIndexes == null ? i : sortIndexes[i]);
      String childUUID = childUUIDs.get(index);
      Element childNode = tnCache.getTreeNode(childUUID);
      if (childNode != null) {
        treeNodes.addContent((Element) childNode.clone());
      }
    }
    if (pageUpNode != null) {
      treeNodes.addContent(0, pageUpNode);
    }
    if (pageDownNode != null) {
      treeNodes.addContent(pageDownNode);
    }
    if (updatedParentNodeText != null) {
      Element updatedParentNode = (Element) parentNode.clone();
      updatedParentNode.setAttribute("TEXT", updatedParentNodeText);
      treeNodes.addContent(updatedParentNode);
    }
    ExtXMLElement.addAttribute(treeNodes, "page", page.intValue() + "");
    return new Document(treeNodes);
  }

  private int findPageForValue(String value, String parentUUID, int pageCount, int pageSize) throws AIGException {
    final TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(request);
    List<String> childUUIDs = tnCache.getChildTreeNodeKeys(parentUUID);
    int childNodeCount = childUUIDs.size();
    int[] sortIndexes = tnCache.getTreeNodeChildrenSortIndex(parentUUID);
    if (sortIndexes != null && sortIndexes.length != childNodeCount) {
      sortIndexes = null;
    }
    for (int page = 0; page < pageCount; page++) {
      int start = page * pageSize;
      int end = Math.min(childNodeCount, start + pageSize);
      for (int i = start; i < end; i++) {
        int index = (sortIndexes == null ? i : sortIndexes[i]);
        String childUUID = childUUIDs.get(index);
        Element childNode = tnCache.getTreeNode(childUUID);
        if (childNode != null) {
          String text = childNode.getAttributeValue("TEXT");
          if (text != null && text.equals(value)) {
            return page;
          }
        }
      }
    }
    return 0;
  }
}

class TreeNodeComparator implements Comparator {
  private int sortModifier = 1;

  TreeNodeComparator(String direction) {
    sortModifier = (direction.startsWith("asc") ? 1 : -1);
  }

  public int compare(Object obj1, Object obj2) {
    Element treeNodeEl1 = (Element) obj1;
    Element treeNodeEl2 = (Element) obj2;
    String text1 = treeNodeEl1.getAttributeValue("TEXT");
    String text2 = treeNodeEl2.getAttributeValue("TEXT");
    if (text1 == null || text2 == null) {
      return 0;
    }
    if (ExtString.isANumber(text1) && ExtString.isANumber(text2)) {
      return Double.compare(ExtString.toDouble(text1), ExtString.toDouble(text2));
    }
    return sortModifier * text1.compareTo(text2);
  }
}

class TreeNodeFilterHandler {
  public static List<String> filter(List<String> nodeUUIDs, TreeNodeFilter filter) {
    List<String> filteredList = new ArrayList<String>();
    for (String nodeUUID : nodeUUIDs) {
      if (filter.include(nodeUUID)) {
        filteredList.add(nodeUUID);
      }
    }
    return filteredList;
  }
}
