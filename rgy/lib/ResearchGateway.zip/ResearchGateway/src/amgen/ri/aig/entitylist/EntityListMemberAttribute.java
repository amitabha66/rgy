/*
 *   EntityListMemberAttribute
 *   RDBData wrapper class for EntityListMemberAttribute
 *   $Revision: 1.2 $
 *   Created: Jeffrey McDowell, 27 Aug 2008
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.entitylist;


import java.io.Serializable;
import java.lang.reflect.Field;

import org.jdom.Element;

import amgen.ri.rdb.OraSequenceField;
import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.Removeable;
import amgen.ri.rdb.SQLManagerIF;
import amgen.ri.rdb.Saveable;

/**
 *   RDBData wrapper class for EntityListMemberAttribute
 *   @version $Revision: 1.2 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class EntityListMemberAttribute extends RdbData implements Saveable, Removeable, Serializable {
    protected OraSequenceField attribute_id;
    protected int entity_list_member_id;
    protected String attribute_value;
    protected String attribute_type;

    /**
     * Default Constructor
     */
    public EntityListMemberAttribute() {
        super();
    }

    /**
     * RdbData Constructor
     */
    public EntityListMemberAttribute(String attribute_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.attribute_id = new OraSequenceField(attribute_id);
    }

    /**
     * Constructor which sets the class variables
     */
    public EntityListMemberAttribute(int entity_list_member_id, String attribute_value, String attribute_type, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.attribute_id = new OraSequenceField("attribute_id", this);
        this.entity_list_member_id = entity_list_member_id;
        this.attribute_value = attribute_value;
        this.attribute_type = attribute_type;
    }

    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return attribute_id + "";
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }

    /** This method returns the name of the table. */
    protected String getTableName() {
        return "ENTITY_LIST_MEMBER_ATTR";
    }

    /** Returns the SQL for INSERTing the object in the table */
    public String getInsertSQL() {
        return null;
    }

    /** Returns the SQL for UPDATing the object in the table */
    public String getUpdateSQL() {
        return null;
    }

    /** Returns the SQL for DELTEing the object/row in the table */
    public String getDeleteSQL() {
        return null;
    }

    /** Get value for entity_list_member_id */
    public int getEntity_list_member_id() {
        return getAsNumber("entity_list_member_id").intValue();
    }

    /** Set value for entity_list_member_id */
    public void setEntity_list_member_id(int entity_list_member_id) {
        set("entity_list_member_id", new Integer(entity_list_member_id));
    }

    /** Get value for attribute_value */
    public String getAttribute_value() {
        return (String) get("attribute_value");
    }

    /** Set value for attribute_value */
    public void setAttribute_value(String attribute_value) {
        set("attribute_value", attribute_value);
    }

    /** Get value for attribute_type */
    public String getAttribute_type() {
        return (String) get("attribute_type");
    }

    /** Set value for attribute_type */
    public void setAttribute_type(String attribute_type) {
        set("attribute_type", attribute_type);
    }

    /**
     * Returns the member attribute as an XML element as
     * <Attribute attribute_type='attribute_type' attribute_value='attribute_value'/>
     *
     * @return Element
     * @param includeMembers boolean
     */
    public Element getAsElement() {
        Element attrEl = new Element("Attribute");
        attrEl.setAttribute("attribute_type", getAttribute_type());
        attrEl.setAttribute("attribute_value", getAttribute_value());
        return attrEl;
    }

}
