package amgen.ri.aig.projectview.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jdom.Element;

import amgen.ri.util.ExtString;


/**
 * @version $Id: ProjectViewInVivoPK.java,v 1.2 2011/06/21 17:28:57 cvs Exp $
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class ProjectViewInVivoPK {
    private String id;
    private String assay;
    private String assayID;
    private Map<String, String> parameters;
    private Map<String, ProjectViewAssayResult> parameterResults;
    private Map<String, String> attributes;


    public ProjectViewInVivoPK(Element resultContentEl, Element assayEl) {
        this.attributes = new HashMap<String, String>();
        this.parameters = new HashMap<String, String>();
        this.parameterResults = new HashMap<String, ProjectViewAssayResult>();
        this.id = resultContentEl.getAttributeValue("result_context_key");
        this.assay = assayEl.getAttributeValue("display_name");
        this.assayID = assayEl.getAttributeValue("assay_id");

        List<Element> propertyEls = assayEl.getChildren("Property");
        for (Element propertyEl : propertyEls) {
            String name = propertyEl.getAttributeValue("type");
            String value = propertyEl.getAttributeValue("value");
            setParameterValue(name, value, propertyEl);
        }

        List<Element> resultContentValueEls = resultContentEl.getChildren("ResultContentValue");
        for (Element resultContentValueEl : resultContentValueEls) {
            String attributeName = resultContentValueEl.getAttributeValue("attribute_name");
            String attributeValue = resultContentValueEl.getAttributeValue("attribute_value_text");
            if (ExtString.hasLength(attributeName) && ExtString.hasLength(attributeValue)) {
                attributes.put(attributeName.toUpperCase(), attributeValue);
            }
        }
    }

    public String getId() {
        return id;
    }

    public String getAssay() {
        return assay;
    }

    private void setParameterValue(String parameterName, String parameterValue, Element propertyEl) {
        if (ExtString.hasLength(parameterName) && ExtString.hasLength(parameterValue)) {
            String key = createParameterKey(parameterName);
            parameters.put(key, parameterValue);
            parameterResults.put(key, new ProjectViewAssayResult(propertyEl));
        }
    }

    public String getParameterValue(String parameterName) {
        String key = createParameterKey(parameterName);
        return parameters.get(key);
    }

    public ProjectViewAssayResult getParameterResult(String parameterName) {
        String key = createParameterKey(parameterName);
        return parameterResults.get(key);
    }

    public Set<String> getParameterNames() {
        return parameters.keySet();
    }

    public Map<String, String> getAttributes() {
        return attributes;
    }

    public String getAssayID() {
        return assayID;
    }

    public String createParameterKey(String parameterName) {
        int parenthesesIndex= parameterName.indexOf('(');
        if (parenthesesIndex>0) {
            parameterName= parameterName.substring(0, parenthesesIndex);
        }
        parameterName= parameterName.toUpperCase().replaceAll("[^\\p{Alnum}]+", "");
        return parameterName;
    }
}
