/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.ora;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.AbstractCacheManager;
import amgen.ri.aig.cache.CacheManagerIF;
import amgen.ri.aig.cache.CacheType;
import amgen.ri.aig.cache.item.GlobalCacheItem;
import amgen.ri.aig.cache.offline.CacheBuilder;
import amgen.ri.aig.cache.offline.CacheBuilderTask;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.util.Utilities;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import com.google.common.util.concurrent.SimpleTimeLimiter;
import java.io.IOException;
import java.io.Reader;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpSession;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

/**
 *
 * @author jemcdowe
 */
public class OracleCacheManager extends AbstractCacheManager implements CacheManagerIF {

  private String requestUser;
  private String resource = "rg.mybatis.config.xml";
  private String factoryName = "rg";

  public OracleCacheManager(String requestUser) {
    super();
    this.requestUser = requestUser;
  }

  /**
   * Get the value of requestUser
   *
   * @return the value of requestUser
   */
  public String getRequestUser() {
    return requestUser;
  }

  /**
   * Set the value of requestUser
   *
   * @param requestUser new value of requestUser
   */
  public void setRequestUser(String requestUser) {
    this.requestUser = requestUser;
  }

  /**
   * Function to create connection with database and to read the xml files used for mapping.
   */
  protected SqlSessionFactory getSqlSessionFactory() {
    SqlSessionFactory sqlSessionFactory = null;
    try {
      Reader reader = Resources.getResourceAsReader(getResource());
      sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader, getFactoryName());
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
    return sqlSessionFactory;
  }

  public int clear() {
    try {
      new SimpleTimeLimiter().callWithTimeout(new CacheBuilderTask(null), CacheBuilder.TIMEOUT_MINS, TimeUnit.MINUTES, true);
      return 0;
    } catch (Exception ex) {
      Logger.getLogger(OracleCacheManager.class.getName()).log(Level.SEVERE, null, ex);
    }
    return 0;
  }

  public int clear(CacheType cacheType) {
    SqlSession sqlSession = null;
    try {
      sqlSession = getSqlSessionFactory().openSession();
      CacheMapper mapper = sqlSession.getMapper(CacheMapper.class);
      mapper.clearGlobalCache(cacheType.toString());
    } catch (Throwable t) {
      t.printStackTrace();
    } finally {
      close(sqlSession);
    }
    return 0;
  }

  /**
   * Returns whether the Cache containsInGlobal the given key in the group and hierarchy
   *
   * @param session HttpSession
   * @param cacheType CacheType
   * @param key String
   * @return boolean
   */
  public boolean contains(CacheType cacheType, String key) {
    SqlSession sqlSession = null;
    try {
      sqlSession = getSqlSessionFactory().openSession();
      CacheMapper mapper = sqlSession.getMapper(CacheMapper.class);

      CacheItemDAO item = new CacheItemDAO(cacheType, "GLOBAL", key);
      mapper.containsCacheItem(item);
      return item.contains();
    } catch (Throwable t) {
      t.printStackTrace();
    } finally {
      close(sqlSession);
    }
    return false;
  }

  /**
   * Returns a List of offline service keys
   */
  public List<String> getOfflineServiceKeys() {
    SqlSession sqlSession = null;
    try {
      sqlSession = getSqlSessionFactory().openSession();
      CacheMapper mapper = sqlSession.getMapper(CacheMapper.class);
      CacheItemDAO item = new CacheItemDAO("GLOBAL");
      mapper.getOfflineServiceKeys(item);
      return item.getKeys();
    } catch (Throwable t) {
      t.printStackTrace();
    } finally {
      sqlSession.close();
    }
    return new ArrayList<String>();
  }

  /**
   * Returns a List of offline service keys
   */
  public JSONObject getStatus() {
    SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
    DecimalFormat decimalFormat = new DecimalFormat("0.0");

    JSONObject jStatus = new JSONObject();
    SqlSession sqlSession = null;
    try {
      sqlSession = getSqlSessionFactory().openSession();
      CacheMapper mapper = sqlSession.getMapper(CacheMapper.class);
      List<CacheCountsDAO> cacheCounts = mapper.getCacheCounts();

      CacheStatus cacheStatus = mapper.getCacheStatus();
      appendNameValue(jStatus, "properties", "property", "Last Refresh Start", "value", dateFormat.format(cacheStatus.getCacheUpdateStart()));
      if (cacheStatus.getCacheUpdateEnd() != null) {
        appendNameValue(jStatus, "properties", "property", "Last Refresh End", "value", dateFormat.format(cacheStatus.getCacheUpdateEnd()));
        Map<String, Long> diff = Utilities.dateDifference(cacheStatus.getCacheUpdateStart(), cacheStatus.getCacheUpdateEnd());
        appendNameValue(jStatus, "properties", "property", "Duration (min)", "value", decimalFormat.format(new Double(diff.get("SECONDS")) / 60));
      } else {
        appendNameValue(jStatus, "properties", "property", "Status", "value", "Running");
      }
      appendNameValue(jStatus, "properties", "property", "Total Updates", "value", cacheStatus.getKeysUpdated());
      appendNameValue(jStatus, "properties", "property", "Total Services", "value", cacheStatus.getServicesUpdated());

      for (CacheCountsDAO cacheCount : cacheCounts) {
        appendNameValue(jStatus, "properties", "property", "Cache Type", "value", WordUtils.capitalize(cacheCount.getCacheType().toLowerCase()));
        appendNameValue(jStatus, "properties", "property", WordUtils.capitalize(cacheCount.getCacheType().toLowerCase()) + " Count", "value", cacheCount.getNumType());
      }
      if (cacheCounts.size() > 0) {
        appendNameValue(jStatus, "properties", "property", "Service(s) Offline", "value", cacheCounts.get(0).getOffLine());
      }

    } catch (Throwable t) {
      t.printStackTrace();
    } finally {
      sqlSession.close();
    }
    return jStatus;
  }

  void appendNameValue(JSONObject jParent, String appendKey, String nameKey, String nameVal, String objKey, Object objVal) throws JSONException {
    JSONObject jRecord = new JSONObject();
    jParent.append(appendKey, jRecord);
    jRecord.put(nameKey, nameVal);
    jRecord.putOpt(objKey, objVal);
  }

  public GlobalCacheItem get(CacheType cacheType, String key) {
    SqlSession sqlSession = null;
    try {
      sqlSession = getSqlSessionFactory().openSession();
      CacheMapper mapper = sqlSession.getMapper(CacheMapper.class);
      CacheItemDAO item = new CacheItemDAO(cacheType, "GLOBAL", key);
      mapper.getCacheItem(item);
      return (GlobalCacheItem) item.getCacheObj();
    } catch (Throwable t) {
      t.printStackTrace();
    } finally {
      close(sqlSession);
    }
    return null;
  }

  public List<GlobalCacheItem> getAll(CacheType cacheType, Collection<String> keys) {
    SqlSession sqlSession = null;
    try {
      sqlSession = getSqlSessionFactory().openSession();
      CacheMapper mapper = sqlSession.getMapper(CacheMapper.class);
      CacheItemDAO item = new CacheItemDAO(cacheType, "GLOBAL");
      item.setKeys(keys);
      mapper.getCacheItems(item);
      return item.getCacheItems();
    } catch (Throwable t) {
      t.printStackTrace();
    } finally {
      sqlSession.close();
    }
    return new ArrayList<GlobalCacheItem>();
  }

  @Override
  public List<ServiceDetails> getAllSortedServices(Collection<String> keys, ServiceNamingContext nameContext, boolean removeOfflineServices) {
    List<ServiceDetails> serviceDetails = new ArrayList<ServiceDetails>();
    SqlSession sqlSession = null;
    try {
      sqlSession = getSqlSessionFactory().openSession();
      CacheMapper mapper = sqlSession.getMapper(CacheMapper.class);
      CacheItemDAO item = new CacheItemDAO(CacheType.SERVICE, "GLOBAL");
      item.setKeys(keys);
      item.setRequestUser(getRequestUser());
      item.setNameContext(nameContext);
      mapper.getSortedServiceCacheItems(item);
      Set<String> offlineServiceKeys = new HashSet<String>();
      if (removeOfflineServices) {
        offlineServiceKeys.addAll(item.getOfflineKeys());
      }
      for (GlobalCacheItem globalCacheItem : item.getCacheItems()) {
        if (globalCacheItem.getCacheObject() instanceof ServiceDetails) {
          ServiceDetails service = (ServiceDetails) globalCacheItem.getCacheObject();
          if (!offlineServiceKeys.contains(service.getKey())) {
            serviceDetails.add(service);
          }
        }
      }
    } catch (Throwable t) {
      t.printStackTrace();
    } finally {
      sqlSession.close();
    }
    return serviceDetails;
  }

  public String getStats() {
    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  }

  public Object put(CacheType cacheType, String key, Object obj) throws AIGException {
    SqlSession sqlSession = null;
    try {
      sqlSession = getSqlSessionFactory().openSession();
      CacheMapper mapper = sqlSession.getMapper(CacheMapper.class);
      CacheItemDAO item = new CacheItemDAO(cacheType, "GLOBAL", key, obj);
      mapper.putCacheItem(item);
      sqlSession.commit();
      return obj;
    } catch (Throwable t) {
      t.printStackTrace();
    } finally {
      close(sqlSession);
    }
    return null;
  }

  public void removeSessionCache(HttpSession session) {
    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  }

  public void remove(CacheType cacheType, Collection<String> keys) {
    for (String key : keys) {
      remove(cacheType, key);
    }
  }

  public void remove(CacheType cacheType, String key) {
    SqlSession sqlSession = null;
    try {
      sqlSession = getSqlSessionFactory().openSession();
      CacheMapper mapper = sqlSession.getMapper(CacheMapper.class);
      CacheItemDAO item = new CacheItemDAO(cacheType, "GLOBAL", key);
      mapper.removeCacheItem(item);
      sqlSession.commit();
    } catch (Throwable t) {
      t.printStackTrace();
    } finally {
      close(sqlSession);
    }
  }

  private void close(SqlSession sqlSession) {
    try {
      sqlSession.close();
    } catch (Exception e) {
    }
  }

  /**
   * @return the resource
   */
  public String getResource() {
    return resource;
  }

  /**
   * @param resource the resource to set
   */
  public void setResource(String resource) {
    this.resource = resource;
  }

  /**
   * @return the factoryName
   */
  public String getFactoryName() {
    return factoryName;
  }

  /**
   * @param factoryName the factoryName to set
   */
  public void setFactoryName(String factoryName) {
    this.factoryName = factoryName;
  }

}
