package amgen.ri.aig.entitylist;

import amgen.ri.aig.category.schema2.EntityListCategory;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import amgen.ri.util.ExtString;

/**
 * @version $Id: GenericEntityListMember.java,v 1.1 2011/06/17 20:41:19 cvs Exp
 * $
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class GenericEntityListMember implements EntityListMemberIF {
  private String member;
  private String label;
  private String description;
  private EntityListCategory dataCategory;
  private String defaultResultViewServiceKey;
  private Map<String, Object> defaultResultViewParameters;

  public GenericEntityListMember(String label, String member, String description, EntityListCategory dataCategory) {
    if (!ExtString.hasTrimmedLength(member)) {
      throw new NullPointerException("Member can not be null or zero-length");
    }
    this.label = (ExtString.hasTrimmedLength(label) ? label : member);
    this.member = member;
    this.description = description;
    
    this.dataCategory = dataCategory;
  }

  public GenericEntityListMember(String member, EntityListCategory dataCategory) {
    this(member, member, null, dataCategory);
  }

  public GenericEntityListMember(EntityListMemberIF entityListMember) {
    this(entityListMember.getLabel(), entityListMember.getMember(), entityListMember.getDescription(), entityListMember.getEntityCategory());
  }

  /**
   *
   * @return String
   */
  public String getLabel() {
    return label;
  }

  /**
   * Returns the member of the EntityList- i.e.
   *
   * @return String
   */
  public String getMember() {
    return member;
  }

  /**
   * Returns the EntityListCategory of the member
   */
  @Override
  public EntityListCategory getEntityCategory() {
    return dataCategory;
  }

  /**
   * Returns whether this member has a default view when loaded into the entity
   * tree
   */
  public String getDefaultViewServiceKey() {
    return defaultResultViewServiceKey;
  }

  /**
   * Returns any parameters used to create a default result when loaded into the
   * entity tree
   *
   * @return Map
   */
  public Map<String, Object> getDefaultViewServiceParameters() {
    return defaultResultViewParameters;
  }

  /**
   * Sets a parameter used to create a default result when loaded into the
   * entity tree
   *
   */
  public void setDefaultResultViewParameters(String paramName, Object paramValue) {
    if (defaultResultViewParameters == null) {
      defaultResultViewParameters = new HashMap<String, Object>();
    }
    defaultResultViewParameters.put(paramName, paramValue);
  }

  /**
   * Sets whether this member has a default view when loaded into the entity
   * tree
   */
  public void setDefaultViewServiceKey(String defaultResultViewServiceKey) {
    this.defaultResultViewServiceKey = defaultResultViewServiceKey;
  }

  public String toString() {
    return member;
  }

  /**
   * Returns the members of the list members IDs as a delimited String
   *
   * @return String
   */
  public static String concatenateMemberIDs(List<EntityListMemberIF> members, String delimiter) {
    if (members == null) {
      return null;
    }
    return ExtString.join(getListMemberIds(members), delimiter);
  }

  /**
   * Returns the members of the list members IDs as a List
   *
   * @return List
   */
  public static List<String> getListMemberIds(List<EntityListMemberIF> members) {
    List<String> listMemberIds = new ArrayList<String>();
    if (members != null) {
      for (EntityListMemberIF member : members) {
        listMemberIds.add(member.getMember());
      }
    }
    return listMemberIds;
  }

  /**
   * Returns the members of the list members IDs as a List
   *
   * @return List
   */
  public static List<EntityListMemberIF> createEntityListMembers(Collection<String> members, EntityListCategory entityCategory) {
    List<EntityListMemberIF> listMembers = new ArrayList<EntityListMemberIF>();
    if (members != null) {
      for (String member : members) {
        listMembers.add(new GenericEntityListMember(member, entityCategory));
      }
    }
    return listMembers;
  }

  /**
   * Returns the members of the list members IDs as a List
   *
   * @return List
   */
  public static List<EntityListMemberIF> createEntityListMembers(String[] members, EntityListCategory entityCategory) {
    List<EntityListMemberIF> listMembers = new ArrayList<EntityListMemberIF>();
    if (members != null) {
      for (String member : members) {
        if (ExtString.hasTrimmedLength(member)) {
          listMembers.add(new GenericEntityListMember(member.trim(), entityCategory));
        }
      }
    }
    return listMembers;
  }

  @Override
  public String getDataValue() {
    return getMember();
  }

  @Override
  public String getDescription() {
    return description;
  }

}
