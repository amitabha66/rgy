package amgen.ri.aig.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import amgen.ri.aig.entitytable.ColumnFormat;

/**
 * Parses or creates an assay summary value of the format:
 *   <value> +/- <STD> (n=<n>, t=<t>)
 *    <value>= aggregated value
 *    STD= standard deviation
 *    n= number of observations used in the aggregation
 *    t= total observations
 *    e.g. 20.8 +/- 12.1 (n=2, t=2)
 *
 */
public class AssaySummaryFormat {
    public static final Pattern ASSAYSUMMARY_PATTERN = Pattern.compile(
            "\\s*([-+]?\\d*\\.?\\d*([Ee][-+]?\\d+){0,1})([\\s+\\+/\\-\\s+\\d*\\.\\d*]*([Ee][-+]?\\d+){0,1})([\\s+\\(n=(\\d+),\\s+t=(\\d+)\\)]*)"
            );
    public static final Pattern ASSAYSUMMARY_PATTERN2 = Pattern.compile(
            "\\s*(N/A)([\\s+\\+/\\-\\s+\\d*\\.\\d*]*([Ee][-+]?\\d+){0,1})([\\s+\\(n=(\\d+),\\s+t=(\\d+)\\)]*;\\s*.*)"
            );
    public static final Pattern ASSAYSUMMARYOBS_PATTERN = Pattern.compile(
            "\\(n=(\\d+),\\s+t=(\\d+)\\)"
            );
    public static final Pattern ASSAYSUMMARYOBS_PATTERN2 = Pattern.compile(
            "\\(n=(\\d+),\\s+t=(\\d+)\\);\\s*(.*)"
            );
    public static final Pattern ASSAYMODVALS_PATTERN = Pattern.compile(
            "(.*)(;(\\s*(.*)))+$"
            );


    private String assaySummary; //sumarized value
    private double value; //Aggregated Value
    private double stddev; //Standard Deviation of the Aggregated value
    private double aggregationCount; //Number of observations used in the aggregation
    private double observationCount; //Total number of available observations
    private String modifiedValues; //All appended modified values

    /**
     * Parses an assay summary String
     * e.g. 20.8 +/- 12.1 (n=2, t=2)
     * @param assaySummary String
     */
    public AssaySummaryFormat(String assaySummary) {
        this.assaySummary = assaySummary;
        Matcher assaySummaryMatcher = ASSAYSUMMARY_PATTERN.matcher(assaySummary);
        value = Double.NaN;
        stddev = Double.NaN;
        aggregationCount = Double.NaN;
        observationCount = Double.NaN;

        if (assaySummaryMatcher.find()) {
            try {
                value = Double.parseDouble(assaySummaryMatcher.group(1));
            } catch (Exception e) {}
            try {
                stddev = Double.parseDouble(assaySummaryMatcher.group(3).replace("+/-", ""));
            } catch (Exception e) {
            }
            Matcher assaySummaryObsMatcher = ASSAYSUMMARYOBS_PATTERN.matcher(assaySummaryMatcher.group(5));
            //Debug.print(assaySummaryMatcher.group(3));
            if (assaySummaryObsMatcher.find()) {
                try {
                    aggregationCount = Integer.parseInt(assaySummaryObsMatcher.group(1));
                } catch (Exception e) {}
                try {
                    observationCount = Integer.parseInt(assaySummaryObsMatcher.group(2));
                } catch (Exception e) {}
                try {
                    //Debug.print(assaySummaryObsMatcher.group(3));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        if (Double.isNaN(value)) {
            Matcher assaySummaryMatcher2 = ASSAYSUMMARY_PATTERN2.matcher(assaySummary);
            if (assaySummaryMatcher2.find()) {
                //Debug.print(assaySummaryMatcher2.group(2));
                Matcher assaySummaryObsMatcher = ASSAYSUMMARYOBS_PATTERN2.matcher(assaySummaryMatcher2.group(4));
                if (assaySummaryObsMatcher.find()) {
                    try {
                        //Debug.print(assaySummaryObsMatcher.group(1));
                        aggregationCount = Integer.parseInt(assaySummaryObsMatcher.group(1));
                    } catch (Exception e) {}
                    try {
                        //Debug.print(assaySummaryObsMatcher.group(2));
                        observationCount = Integer.parseInt(assaySummaryObsMatcher.group(2));
                    } catch (Exception e) {}
                    //Debug.print(assaySummaryObsMatcher.group(3));
                    modifiedValues = assaySummaryObsMatcher.group(3);
                }
            } else {
                modifiedValues = assaySummary;
            }
        }
        try {
            Matcher assaymodvalsMatcher = ASSAYMODVALS_PATTERN.matcher(assaySummary);
            if (assaymodvalsMatcher.find()) {
                modifiedValues = assaymodvalsMatcher.group(4);
            }
        } catch (Exception e) {
        }

    }

    /**
     * Creates an AssaySummaryFormat from individual fields
     *
     * @param value double
     * @param stddev double
     * @param aggregationCount int
     * @param observationCount int
     */
    public AssaySummaryFormat(double value, double stddev, int aggregationCount, int observationCount) {
        this.value = value;
        this.stddev = stddev;
        this.aggregationCount = aggregationCount;
        this.observationCount = observationCount;
    }

    /**
     * Returns an assay summary formatted String
     *
     * @return String
     */
    public String getAssaySummary() {
        if (assaySummary != null) {
            return assaySummary;
        }
        if (Double.isNaN(value)) {
            return "N/A";
        }
        assaySummary = getValue() + "";
        if (Double.isNaN(stddev)) {
            return assaySummary;
        }
        assaySummary += " +/- " + getStddev();
        if (getAggregationCount() <= 0 || getObservationCount() <= 0) {
            return assaySummary;
        }
        return (assaySummary = assaySummary + " (n=" + getAggregationCount() + ", t=" + getObservationCount() + ")");
    }
    /**
     * Returns an assay summary formatted String
     *
     * @return String
     */
    public String getAssaySummary(ColumnFormat columnFormat) {
        String assaySummary= "";
        if (Double.isNaN(value)) {
            assaySummary= "N/A";
        } else {
            assaySummary = getValue(columnFormat);
            if (!Double.isNaN(stddev)) {
            assaySummary += " +/- " + getStddev();
            }
        }
        if (getAggregationCount() >0 && getObservationCount() > 0) {
            assaySummary = assaySummary + " (n=" + getAggregationCount() + ", t=" + getObservationCount() + ")";
        }
        if (modifiedValues!= null) {
            assaySummary= assaySummary + ";" + modifiedValues;
        }
        return assaySummary;
    }

    /**
     * Gets aggregated value
     *
     * @return double
     */
    public double getValue() {
        return value;
    }
    /**
     * Gets aggregated value
     *
     * @return double
     */
    public String getValue(ColumnFormat columnFormat) {
        return (columnFormat== null ? value+"" : columnFormat.getFormatterValue(value));
    }

    /**
     * Gets aggregation count
     *
     * @return int
     */
    public int getAggregationCount() {
        return (Double.isNaN(aggregationCount) ? -1 : (int) aggregationCount);
    }

    /**
     * Gets observation count
     *
     * @return int
     */
    public int getObservationCount() {
        return (Double.isNaN(observationCount) ? -1 : (int) observationCount);
    }

    /**
     * Gets the Stddev
     *
     * @return double
     */
    public double getStddev() {
        return stddev;
    }

    public String getModifiedValues() {
        return modifiedValues;
    }

    public static double valueOf(String s) {
        AssaySummaryFormat assaySummaryFormat = new AssaySummaryFormat(s);
        return assaySummaryFormat.getValue();
    }

}
