package amgen.ri.aig.security;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.mail.SendMessage;
import amgen.ri.servlet.AbstractFilter;
import amgen.ri.servlet.SessionLogin;
import amgen.ri.util.ExtString;

/**
 * @version $Id: RGSecurityFilter.java,v 1.6 2015/03/24 21:14:27 jemcdowe Exp $
 */
public class RGSecurityFilter extends AbstractFilter {

  private List<String> excludedPaths;

  public RGSecurityFilter() {
    super();
    excludedPaths = new ArrayList<String>();
  }

  /**
   * Called by the web container to indicate to a filter that it is being placed
   * into service.
   *
   * @param filterConfig FilterConfig
   * @throws ServletException
   * @todo Implement this javax.servlet.Filter method
   */
  public void init(FilterConfig filterConfig) throws ServletException {
    super.init(filterConfig);
    String filterPathExclusions = filterConfig.getInitParameter("FILTER_EXCLUDEDPATHS");
    if (filterPathExclusions != null) {
      this.excludedPaths.clear();
      List<String> excludedPaths = Arrays.asList(filterPathExclusions.split("[,;:]+"));
      for (String excludedPath : excludedPaths) {
        String excludedPathTrimmed = excludedPath.trim();
        if (excludedPathTrimmed.length() > 0) {
          this.excludedPaths.add(excludedPathTrimmed);
        }
      }
    }
  }

  /**
   * The <code>doFilter</code> method of the Filter is called by the container
   * each time a request/response pair is passed through the chain due to a
   * client request for a resource at the end of the chain. Subclasses should
   * overwrite this method to do something.
   *
   * @param request ServletRequest
   * @param response ServletResponse
   * @param chain FilterChain
   * @throws IOException
   * @throws ServletException
   */
  @Override
  public void doCustomFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
    HttpServletRequest req = (HttpServletRequest) request;
    HttpServletResponse resp = (HttpServletResponse) response;
    SessionLogin sessionLogin = SessionLogin.getSessionLogin(req);
    if (sessionLogin == null) {
      resp.sendError(HttpServletResponse.SC_BAD_REQUEST);
      return;
    }

    RGAccessStatus accessStatus = (RGAccessStatus) req.getSession().getAttribute("RG_ACCESS_STATUS");
    if (accessStatus == null || accessStatus.equals(RGAccessStatus.UNKNOWN)) {
      accessStatus = new RGAccessController().processAccessStatus(sessionLogin);
      req.getSession().setAttribute("RG_ACCESS_STATUS", accessStatus);
    }

    switch (accessStatus) {
      case GRANTED:
        chain.doFilter(request, response);
        return;
      case DENIED:
        if (getFilterParameter("amgen.ri.aig.security.RGSecurityFilter.unauthorizedRedirectURL") != null) {
          resp.sendRedirect(getFilterParameter("amgen.ri.aig.security.RGSecurityFilter.unauthorizedRedirectURL"));
        } else {
          resp.sendError(HttpServletResponse.SC_UNAUTHORIZED,
                  "Insufficient privledges to access Research Gateway. If you need access to RG please contact the RG Global Support Team through Outlook or go to the RG MyTeams site at http://rg.amgen.com");
        }
        if (getFilterParameter("amgen.ri.aig.security.RGSecurityFilter.sendAccessAttemptEmail") != null) {
          String emailDomain = ConfigurationParameterSource.getConfigParameter("AMGEN_EMAIL_DOMAIN");
          if (emailDomain == null) {
            System.err.println("Warning: No email domain defined");
            return;
          }
          String subject = "Research Gateway Notification: Unauthorized Access Attempt ";
          String message = ExtString.applyTemplate(getFilterParameter("amgen.ri.aig.security.RGSecurityFilter.sendAccessAttemptEmailTemplate"),
                  new String[]{
                    sessionLogin.getUserPreferredDisplayName(),
                    ConfigurationParameterSource.getRGVersion().toString()
                  }
          );
          String[] addresses = new String[]{getFilterParameter("amgen.ri.aig.security.RGSecurityFilter.sendAccessAttemptEmail") + "@" + emailDomain};
          String from = sessionLogin.getRemoteUser() + "@" + emailDomain;
          SendMessage messenger = new SendMessage(req.getSession(true).getServletContext());
          try {

// **************************************************************
            //Change the to ACTUAL Send!!!!!!
            //Debug.print("Send Message to: "+ExtString.join(addresses, ','));
            //Debug.print("Subject: "+subject);
            //Debug.print("Message: "+message);
            messenger.sendHTMLMessage(addresses, null, null, from, subject, message);
// **************************************************************

          } catch (Exception e) {
            e.printStackTrace();
          }
        }
        return;
      default:
        break;
    }

  }

}
