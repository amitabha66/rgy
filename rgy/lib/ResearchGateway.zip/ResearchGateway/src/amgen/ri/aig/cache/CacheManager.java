package amgen.ri.aig.cache;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.item.GlobalCacheItem;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.servlet.http.HttpSession;
import org.apache.jcs.JCS;
import org.apache.jcs.access.exception.CacheException;

/**
 * Manages interactions with the AIG JCS cache
 *
 * @version $id$
 */
public class CacheManager extends AbstractCacheManager implements CacheManagerIF {
  private String sessionID;
  private JCS aigCache;

  /**
   * Creates a new, singleton CacheManager
   *
   * @throws AIGException
   */
  protected CacheManager(HttpSession session) throws AIGException {
    this(session.getId());
  }

  /**
   * Creates a new, singleton CacheManager
   *
   * @throws AIGException
   */
  protected CacheManager(String sessionID) throws AIGException {
    try {
      this.sessionID = sessionID;
      aigCache = JCS.getInstance("aigCache");
    } catch (CacheException ex1) {
      throw new AIGException(AIGException.Reason.CACHE_ERROR, ex1);
    }
  }

  /**
   * Returns the Cache object. Interaction with the cache directly is not
   * recommended and is only here for development purposes. 
   *
   * @return JCS
   */
  private JCS getCache() {
    return aigCache;
  }

  /**
   * Returns the statistics of the JCS
   *
   * @return JCS
   */
  public String getStats() {
    return getCache().getStats();
  }

  /**
   * Puts an object into the Cache in the proper group and hierarchy
   *
   * @param session HttpSession
   * @param cacheType CacheType
   * @param key String
   * @param obj Object
   * @return Object
   * @throws AIGException
   */
  public Object put(CacheType cacheType, String key, Object obj) throws AIGException {
    try {
      aigCache.putInGroup(cacheType + ":" + key, sessionID, obj);
    } catch (CacheException ex1) {
      throw new AIGException(AIGException.Reason.CACHE_ERROR, ex1);
    }
    return obj;
  }

  /**
   * Gets a cached object from the Cache or null if the key does not exist in
   * the group and hierarchy
   *
   * @param sessionID HttpSession
   * @param cacheType CacheType
   * @param key String
   * @return Object
   */
  public Object get(CacheType cacheType, String key) {
    return aigCache.getFromGroup(cacheType + ":" + key, sessionID);
  }

  /**
   * Removes an object from the Cache. Does nothing if the object does not exist
   * in the group and hierarchy
   *
   * @param session HttpSession
   * @param cacheType CacheType
   * @param key String
   */
  public void remove(CacheType cacheType, String key) {
    //Debug.print("Remove: "+cacheType + ":" + key+"  ("+containsInGlobal(session, cacheType, key)+")");
    aigCache.remove(cacheType + ":" + key, sessionID);
  }

  /**
   * Removes the session cache from the Cache removing all cached objects
   *
   * @param session HttpSession
   */
  public void removeSessionCache(HttpSession session) {
    aigCache.invalidateGroup(session.getId());
  }

  /**
   * Removes a set of keys from the cache
   *
   * @param session HttpSession
   * @param cacheType CacheType
   * @param strings String[]
   * @return int
   */
  public void remove(CacheType cacheType, Collection<String> keys) {
    for (String key : keys) {
      remove(cacheType, key);
    }
  }

  public List<GlobalCacheItem> getAll(String sessionID, CacheType cacheType, Collection<String> keys) {
    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  }

  public int clear() {
    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  }

  public int clear(CacheType cacheType) {
    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  }

}
