package amgen.ri.aig.export;

import java.util.HashMap;
import java.util.Map;

import amgen.ri.asf.sa.uddi.Categorization;

/**
 * @version $Id: ExportUtils.java,v 1.8 2012/09/14 23:05:20 cvs Exp $

 */
public class ExportUtils {
	
	public ExportUtils() {
	}

	public String getMimetype(Categorization docTypeCategorization) {
		if (docTypeCategorization != null && docTypeCategorization.getKeyValues().length > 0) {
			String keyValue = docTypeCategorization.getKeyValues()[0];
			if (keyValue.equals("MSExcel 2003")) {
				return "application/vnd.ms-excel";
			}
			if (keyValue.equals("MSExcel 2007")) {
				return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
			}
			if (keyValue.equals("MSExcel 97")) {
				return "application/vnd.ms-excel";
			}
			if (keyValue.equals("MSWord 2003")) {
				return "application/msword";
			}
			if (keyValue.equals("MSWord 2007")) {
				return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
			}
			if (keyValue.equals("MSWord 97")) {
				return "application/msword";
			}
			if (keyValue.equals("PowerPoint 2003")) {
				return "application/vnd.ms-powerpoint";
			}
			if (keyValue.equals("PowerPoint 97")) {
				return "application/vnd.ms-powerpoint";
			}
			if (keyValue.equals("PowerPoint 2007")) {
				return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
			}
			if (keyValue.equals("Adobe PDF")) {
				return "application/pdf";
			}
			if (keyValue.equals("RTF")) {
				return "application/rtf";
			}
			if (keyValue.equals("Bitmap Image")) {
				return "image/bmp";
			}
			if (keyValue.equals("GIF Image")) {
				return "image/gif";
			}
			if (keyValue.equals("TIFF Image")) {
				return "image/tiff";
			}
			if (keyValue.equals("PNG Image")) {
				return "image/png";
			}
			if (keyValue.equals("JPEG Image")) {
				return "image/jpeg";
			}
			if (keyValue.equals("Plain Text")) {
				return "text/plain";
			}
			if (keyValue.equals("XML Text")) {
				return "text/xml";
			}
			if (keyValue.equals("CSV Text")) {
				return "text/csv";
			}
			if (keyValue.equals("HTML Text")) {
				return "text/html";
			}
			if (keyValue.equals("FastaNA")) {
				return "text/plain";
				// return "chemical/seq-na-fasta";
			}
			if (keyValue.equals("FastaAA")) {
				return "text/plain";
				// return "chemical/seq-aa-fasta";
			}
			if (keyValue.equals("Genbank")) {
				return "chemical/seq-na-genbank";
			}
			if (keyValue.equals("Genpept")) {
				return "chemical/seq-aa-genbank";
			}
			if (keyValue.equals("SpotfireSTDF")) {
				return "application/vnd.spotfire.stdf";
			}
			if (keyValue.equals("MDL SDFile")) {
				return "chemical/x-mdl-sdfile";
			}      

		}
		return "text/plain";
	}

	public String getExtension(Categorization docTypeCategorization) {
		return getExtension(getMimetype(docTypeCategorization));
	}

	public String getExtension(String mimetype) {
		Map<String, String> extMap= getMimetype2ExtensionMap();
		if (extMap.containsKey(mimetype)) {
			return extMap.get(mimetype);
		}
		return "txt";
	}
  
  public String getMimetypeByExtension(String extension) {
    Map<String, String> mimetype2ExtensionMap= getMimetype2ExtensionMap();
    for(String mimetype :mimetype2ExtensionMap.keySet()) {
      if (mimetype2ExtensionMap.get(mimetype).equals(extension)) {
        return mimetype;
      }
    }
    return null;
  }
	

    private Map<String, String> getMimetype2ExtensionMap() {
    	Map<String, String> documentExtensions = new HashMap<String, String>();
        
        documentExtensions.put("application/vnd.ms-excel", "xls");
        documentExtensions.put("application/msexcel", "xla");        
        documentExtensions.put("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx");        

        documentExtensions.put("application/msword", "doc");
        documentExtensions.put("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "docx");        
        
        documentExtensions.put("application/vnd.ms-powerpoint", "ppt");
        documentExtensions.put("application/vnd.openxmlformats-officedocument.presentationml.presentation", "pptx");        

        documentExtensions.put("application/vnd.spotfire.stdf", "stdf");        
        documentExtensions.put("application/vnd.spotfire.dxp", "dxp");        
        
        documentExtensions.put("application/msaccess", "mdb");
        documentExtensions.put("application/msproject", "mpp");
        documentExtensions.put("application/mswrite", "wri");
        documentExtensions.put("application/rtf", "rtf");
        documentExtensions.put("application/msoutlook", "msg");
        documentExtensions.put("application/postscript", "ai");
        documentExtensions.put("application/postscript", "eps");
        documentExtensions.put("application/pdf", "pdf");
        documentExtensions.put("application/postscript", "ps");

        documentExtensions.put("image/bmp", "bmp");
        documentExtensions.put("image/gif", "gif");
        documentExtensions.put("image/png", "png");
        documentExtensions.put("image/tiff", "tiff");
        documentExtensions.put("image/tiff", "tif");
        documentExtensions.put("image/jpeg", "jpe");
        documentExtensions.put("image/jpeg", "jpeg");
        documentExtensions.put("image/jpeg", "jpg");

        documentExtensions.put("text/plain", "txt");
        documentExtensions.put("text/xml", "xml");
        documentExtensions.put("text/html", "htm");
        documentExtensions.put("text/html", "html");
        documentExtensions.put("text/csv", "csv");

        documentExtensions.put("chemical/x-pdb", "xyz");
        documentExtensions.put("chemical/x-pdb", "sdf");        

        documentExtensions.put("chemical/seq-na-fasta", "fna");
        documentExtensions.put("chemical/seq-aa-fasta", "faa");
        documentExtensions.put("chemical/seq-na-genbank", "gb");
        documentExtensions.put("chemical/seq-aa-genbank", "gp");
        
        documentExtensions.put("chemical/x-mdl-sdfile", "sdf");
        return documentExtensions;
    }	
}
