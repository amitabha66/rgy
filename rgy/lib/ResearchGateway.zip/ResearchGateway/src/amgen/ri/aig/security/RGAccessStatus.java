package amgen.ri.aig.security;

/**
 * <p>@version $Id: RGAccessStatus.java,v 1.1 2011/06/17 20:41:22 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public enum RGAccessStatus {
    GRANTED, DENIED, UNKNOWN;

    public static RGAccessStatus fromString(String s) {
        try {
            return RGAccessStatus.valueOf(s.toUpperCase());
        } catch (Exception e) {}
        return UNKNOWN;
    }
}
