package amgen.ri.aig.event;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.aig.AIGResponseMessage;
import amgen.ri.aig.AIGServlet;

/**
 * @version $Id: SessionRestart.java,v 1.2 2011/06/21 17:28:58 cvs Exp $
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class SessionRestart extends AIGServlet {
    /**
     * Default constructor
     */
    public SessionRestart() {
        super();
    }

    /**
     * Standard constructor which creates a new AIGServlet
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     */
    public SessionRestart(HttpServletRequest req, HttpServletResponse resp) {
        super(req, resp);
    }


    /**
     * Returns the getAIGServlet implementation class for the request
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return TBXServlet
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new SessionRestart(req, resp);
    }

    /**
     * Actual work entry stub
     * @throws ServletException
     * @throws IOException
     */
    protected void performRequest() throws Exception {
        if (request.getSession(false) != null) {
            request.getSession().invalidate();
        }
        AIGResponseMessage.writeErrorElement("SessionRestart", "Session Restarted", "Session Restarted", response);
    }

    /**
     * Returns the mimetype of the servlet
     */
    protected String getServletMimeType() {
        return "text/xml";
    }

}
