package amgen.ri.aig.uddi;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.tree.NodeType;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.service.ServiceCacheResponse;
import amgen.ri.aig.cache.tree.TreeNodeCache;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.asf.sa.uddi.CategoryKeyValue;
import amgen.ri.asf.sa.uddi.ClassificationSchemeQuery;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtArray;
import amgen.ri.xml.ExtXMLElement;
import java.io.IOException;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.rpc.ServiceException;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.output.XMLOutputter;

/**
 * Looks up services for a selected entity
 */
public class EntityResourcesLookup extends AbstractServiceLookup implements ServiceLookupIF {
  private List<String> nodeUUIDs;
  private EntityListCategory category;
  //If the resources are being looked up based on a Query service, this is its key
  // This can be used to lookup saved recent usages of the service like past reosurce selections
  private String queryServiceKey;

  /**
   * Default constructor
   */
  public EntityResourcesLookup() {
    super();
  }

  public EntityResourcesLookup(AIGServlet servlet) {
    super(servlet);
    if (doesParameterExist("uuid")) {
      setNodeUUIDs(getParameter("uuid").split(","));
    }
  }

  /**
   * Main constructor- used only by the getAIGServlet method
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   */
  public EntityResourcesLookup(HttpServletRequest request, HttpServletResponse response) {
    super(request, response);
    if (doesParameterExist("uuid")) {
      setNodeUUIDs(getParameter("uuid").split(","));
    }
  }

  /**
   * Get the value of nodeUUIDs
   *
   * @return the value of nodeUUIDs
   */
  public List<String> getNodeUUIDs() {
    return nodeUUIDs;
  }

  /**
   * Set the value of nodeUUIDs
   *
   * @param nodeUUIDs new value of nodeUUIDs
   */
  public void setNodeUUIDs(List<String> nodeUUIDs) {
    this.nodeUUIDs = nodeUUIDs;
  }

  /**
   * Set the value of nodeUUIDs
   *
   * @param nodeUUIDs new value of nodeUUIDs
   */
  public void setNodeUUIDs(String[] nodeUUIDs) {
    this.nodeUUIDs = Arrays.asList(nodeUUIDs);
  }

  /**
   * Set the value of nodeUUIDs
   *
   * @param nodeUUIDs new value of nodeUUIDs
   */
  public void setNodeUUIDs(String nodeUUIDs) {
    if (nodeUUIDs != null) {
      setNodeUUIDs(nodeUUIDs.split(","));
    }
  }

  /**
   * Creates this AIG Servlet object
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return AIGServlet
   */
  @Override
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new EntityResourcesLookup(req, resp);
  }

  @Override
  public Document getServicesDocument() throws JDOMException, AIGException {
    ServiceCacheResponse services = getServices();
    Document recentServicesDoc = getRecentServiceDocument(queryServiceKey);
    Set<String> resourceServiceKeySet = new HashSet<String>();
    if (recentServicesDoc != null) {
      resourceServiceKeySet.addAll(ExtXMLElement.getXPathValues(recentServicesDoc, "//ResourceServiceKeySet//Service/@serviceKey"));
    }
    Document servicesDocument = new Document(new Element("Services"));
    for (ServiceDetails service : services) {
      try {
        if (service.containsUserInAllowedUsers(getSessionLogin().getRemoteUser(), true)) {
          ServiceAttributes serviceAttributes = new ServiceAttributes(service, getEntityClassManager());
          Element searchServiceElement = getServiceElement(service);
          if (searchServiceElement != null) {
            servicesDocument.getRootElement().addContent(searchServiceElement);
            ExtXMLElement.addTextElement(searchServiceElement, "ID", UUID.randomUUID() + "");
            Element nameElement = searchServiceElement.getChild("Name");
            nameElement.setText(serviceAttributes.getName(ServiceNamingContext.RG_RESOURCE));
            Element descElement = searchServiceElement.getChild("Description");
            descElement.setText(serviceAttributes.getDescription(ServiceNamingContext.RG_RESOURCE));

            CategoryKeyValue orgCatValue = serviceAttributes.getOrganizationCategoryKeyValue();
            ExtXMLElement.addTextElement(searchServiceElement, "Category", (orgCatValue == null ? "Other" : orgCatValue.getKeyName()));
            if (resourceServiceKeySet.size() > 0) {
              ExtXMLElement.addElement(searchServiceElement, "IsDefaultView", resourceServiceKeySet.contains(service.getKey()) + "");
            } else {
              ExtXMLElement.addElement(searchServiceElement, "IsDefaultView", serviceAttributes.isEntityDefaultView() + "");
            }
          }
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return servicesDocument;
  }

  public JSONObject getServiceRecords() throws JDOMException, AIGException {
    return getServiceRecords(getServicesDocument());
  }

  protected void performRequest() throws ServletException, IOException, JDOMException, ServiceException, AIGException {
    ServiceCacheResponse services = getServices();
    try {
      Document resourceTreeNodesDocument = new Document(new Element("TREENODES"));
      Element recentServicesTreeNode = new Element("TREENODE");
      recentServicesTreeNode.setAttribute("IMAGE", "recentservices");
      recentServicesTreeNode.setAttribute("TEXT", "Recent");
      recentServicesTreeNode.setAttribute("EXPANDED", "true");
      recentServicesTreeNode.setAttribute("UUID", UUID.randomUUID() + "");
      if (services.size() > 0) {
        for (ServiceDetails service : services) {
          if (service.containsUserInAllowedUsers(getSessionLogin().getRemoteUser(), true) && isRecentService(service, RECENT_USAGE_DAYS_CUTOFF)) {
            ServiceAttributes serviceAttributes = new ServiceAttributes(service, getEntityClassManager());
            Element serviceNode = ExtXMLElement.addElement(recentServicesTreeNode, "TREENODE");
            ExtXMLElement.addAttribute(serviceNode, "IMAGE", "service");
            ExtXMLElement.addAttribute(serviceNode, "TEXT", serviceAttributes.getName(ServiceNamingContext.RG_RESOURCE));
            ExtXMLElement.addAttribute(serviceNode, "TITLE", serviceAttributes.getDescription(ServiceNamingContext.RG_RESOURCE));
            ExtXMLElement.addAttribute(serviceNode, "KEY", service.getKey());
            ExtXMLElement.addAttribute(serviceNode, "UUID", UUID.randomUUID() + "");
          }
        }
      }
      Map<String, Element> treeNodeMap = new HashMap<String, Element>();

      List<CategoryKeyValue> rankedCategoryKeyValues = getRankedCategoryKeyValues(services);
      for (CategoryKeyValue rankedCategoryKeyValue : rankedCategoryKeyValues) {
        Element servicesFolderTreeNode = new Element("TREENODE");
        resourceTreeNodesDocument.getRootElement().addContent(servicesFolderTreeNode);
        servicesFolderTreeNode.setAttribute("IMAGE", "servicescatfolder");
        servicesFolderTreeNode.setAttribute("TEXT", rankedCategoryKeyValue.getKeyName());
        servicesFolderTreeNode.setAttribute("EXPANDED", "true");
        servicesFolderTreeNode.setAttribute("UUID", UUID.randomUUID() + "");
        treeNodeMap.put(rankedCategoryKeyValue.getKeyValue(), servicesFolderTreeNode);
      }

      Element otherServicesEl = new Element("TREENODE");
      otherServicesEl.setAttribute("IMAGE", "servicesfolder");
      otherServicesEl.setAttribute("TEXT", "Other");
      otherServicesEl.setAttribute("EXPANDED", "true");
      otherServicesEl.setAttribute("UUID", UUID.randomUUID() + "");

      for (ServiceDetails service : services) {
        if (service.containsUserInAllowedUsers(getSessionLogin().getRemoteUser(), true)) {
          ServiceAttributes serviceAttributes = new ServiceAttributes(service, getEntityClassManager());
          boolean serviceAdded = false;
          CategoryKeyValue orgCatValue = serviceAttributes.getOrganizationCategoryKeyValue();
          if (orgCatValue != null) {
            if (!treeNodeMap.containsKey(orgCatValue.getKeyValue())) {
              Element servicesFolderTreeNode = new Element("TREENODE");
              resourceTreeNodesDocument.getRootElement().addContent(servicesFolderTreeNode);
              servicesFolderTreeNode.setAttribute("IMAGE", "servicescatfolder");
              servicesFolderTreeNode.setAttribute("TEXT", orgCatValue.getKeyName());
              servicesFolderTreeNode.setAttribute("EXPANDED", "true");
              servicesFolderTreeNode.setAttribute("UUID", UUID.randomUUID() + "");
              treeNodeMap.put(orgCatValue.getKeyValue(), servicesFolderTreeNode);
            }
            Element serviceNode = ExtXMLElement.addElement(treeNodeMap.get(orgCatValue.getKeyValue()), "TREENODE");
            ExtXMLElement.addAttribute(serviceNode, "IMAGE", "service");
            ExtXMLElement.addAttribute(serviceNode, "TEXT", serviceAttributes.getName(ServiceNamingContext.RG_RESOURCE));
            ExtXMLElement.addAttribute(serviceNode, "TITLE", serviceAttributes.getDescription(ServiceNamingContext.RG_RESOURCE));
            ExtXMLElement.addAttribute(serviceNode, "KEY", service.getKey());
            ExtXMLElement.addAttribute(serviceNode, "UUID", UUID.randomUUID() + "");
            serviceAdded = true;
          }

          if (!serviceAdded) {
            Element serviceNode = ExtXMLElement.addElement(otherServicesEl, "TREENODE");
            ExtXMLElement.addAttribute(serviceNode, "IMAGE", "service");
            ExtXMLElement.addAttribute(serviceNode, "TEXT", serviceAttributes.getName(ServiceNamingContext.RG_RESOURCE));
            ExtXMLElement.addAttribute(serviceNode, "TITLE", serviceAttributes.getDescription(ServiceNamingContext.RG_RESOURCE));
            ExtXMLElement.addAttribute(serviceNode, "KEY", service.getKey());
            ExtXMLElement.addAttribute(serviceNode, "UUID", UUID.randomUUID() + "");
          }
        }
      }
      if (recentServicesTreeNode.getChildren().size() > 0) {
        resourceTreeNodesDocument.getRootElement().addContent(0, recentServicesTreeNode);
      }
      if (otherServicesEl.getChildren().size() > 0) {
        resourceTreeNodesDocument.getRootElement().addContent(otherServicesEl);
      }
      new XMLOutputter().output(resourceTreeNodesDocument, response.getWriter());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private ServiceCacheResponse getServices() throws JDOMException, AIGException {
    ServiceCacheResponse services = new ServiceCacheResponse();
    ClassificationSchemeQuery classificationSchemeQuery = new ClassificationSchemeQuery();
    List<String> serviceDataTypeCategoryList = new ArrayList<String>();
    if (ExtArray.hasLength(nodeUUIDs)) {
      List<Element> treeNodes = TreeNodeCache.getTreeNodeCache(request).getTreeNodes(nodeUUIDs);
      if (treeNodes.size() > 0) {
        Element entityNode = treeNodes.get(0);

        String nodeTypeCategory = entityNode.getAttributeValue("NODE_TYPE");
        String serviceDataTypeCategory = entityNode.getAttributeValue("SERVICE_DATA_TYPE_CATEGORY");

        if (nodeTypeCategory != null && serviceDataTypeCategory != null && NodeType.isDataNode(nodeTypeCategory)) {
          try {
            NodeType nodeType = NodeType.valueOf(nodeTypeCategory);
            serviceDataTypeCategory = ServiceDataCategory.revertTo(ServiceDataCategory.fromString(serviceDataTypeCategory));
            classificationSchemeQuery.addKeyValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, serviceDataTypeCategory);
            if ((nodeType.equals(NodeType.ENTITYNODE) && treeNodes.size() > 1) || nodeType.equals(NodeType.RESULTNODE)
                    || nodeType.equals(NodeType.SERVICENODE)) {
              serviceDataTypeCategoryList = Arrays.asList(new String[]{serviceDataTypeCategory});
            }
          } catch (Exception e) {
            e.printStackTrace();
          }
        }
      }
    } else if (category != null && !category.equals(EntityListCategory.UNKNOWN)) {
      String serviceDataTypeCategory = ServiceDataCategory.revertTo(getEntityClassManager().convertEntityListCategoryToServiceDataCategory(category));
      classificationSchemeQuery.addKeyValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, serviceDataTypeCategory);
    }
    if (classificationSchemeQuery.getClassificationSchemeNames().size() > 0) {
      ServiceQuery serviceQuery= new ServiceQuery(classificationSchemeQuery);
      serviceQuery.addAllInputTypeWhichAcceptsList(serviceDataTypeCategoryList);
      serviceQuery.addResultTypes(new String[]{
                TModelCommonNameFactory.HTMLDEFINITION_tMODELNAME,
                TModelCommonNameFactory.PROJECTVIEWDEFINITION_tMODELNAME});
      
      services = ServiceCache.getServiceCache(request).getServices(serviceQuery);
    }
    services.sortServices(ServiceNamingContext.RG_RESOURCE, getRecentServicesDocument());
    return services;
  }

  public void setSearchCategory(EntityListCategory category) {
    this.category = category;
  }

  public String getQueryServiceKey() {
    return queryServiceKey;
  }

  public void setQueryServiceKey(String queryServiceKey) {
    this.queryServiceKey = queryServiceKey;
  }
}

class ResourceView {
  public String name;
  public String key;

  ResourceView(String name, String key) {
    this.name = name;
    this.key = key;
  }
}
