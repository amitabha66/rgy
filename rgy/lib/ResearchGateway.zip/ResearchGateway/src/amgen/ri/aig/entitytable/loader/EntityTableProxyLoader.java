package amgen.ri.aig.entitytable.loader;

import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Workbook;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;
import amgen.ri.aig.entitytable.proxy.EntityTableProxy;
import amgen.ri.aig.util.Utilities;

/**
 * <p>@version $Id: EntityTableProxyLoader.java,v 1.3 2011/06/22 23:05:15 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class EntityTableProxyLoader extends AbstractEntityTableLoader {
    private EntityTableProxy entityTableProxy;
    public EntityTableProxyLoader(AIGBase requestor, EntityTableProxy entityTableProxy) {
        super(requestor, entityTableProxy.getEntityTableType());
        this.entityTableProxy = entityTableProxy;
    }

    /**
     * createEntityTableFromResultNode
     *
     * @param resultNodeKey String
     * @return EntityTable
     * @throws AIGException
     * @todo Implement this
     *   amgen.ri.aig.entitytable.loader.AbstractEntityTableLoader method
     */
    protected EntityTable createEntityTableModel() throws AIGException {
        EntityTable entityTable = new EntityTable(getEntityTableType());
        entityTable.setTableName(getTableName());
        entityTable.setColumnGroups(entityTableProxy.getColumnGroups());
        entityTable.setDataRows(entityTableProxy.getDataRows());
        entityTable.setRowHeightPixels((entityTableProxy.getRowHeightPixels() <= 0 ? (int) Utilities.points2Pixels(150, false) : entityTableProxy.getRowHeightPixels()));
        return entityTable;
    }

    public EntityTable createEntityTableFromWorkbook(Workbook workbook, int serviceDataCategoryColNum, Map<Integer, EntityTableDataType> columnTypes) throws AIGException {
        return null;
    }

    /**
     * Creates a new row in the table given the entityID.
     * Entity IDs can not be duplicated, so if thsi entityID already exists in the table, this returns null.
     * If for any other reason it can not be added, it returns null.
     * Otherwise, it returns the new DataRow
     * @param entityTable EntityTable
     * @param entityID String
     * @return DataRow
     */
    public int addEntitiesToEntityTable(EntityTable entityTable, List<String> entityIDs) throws AIGException {
        return -1;
    }

}
