package amgen.ri.aig.sv;

import java.io.IOException;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.transform.JDOMSource;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.tree.TreeNodeCache;

public class GenerateEntityNodeTooltip extends AIGServlet {
    /**
     * Default constructor
     */
    public GenerateEntityNodeTooltip() {
        super();
    }

    /**
     * Main constructor- used only by the getAIGServlet method
     *
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    private GenerateEntityNodeTooltip(HttpServletRequest request, HttpServletResponse response) {
        super(request, response);
    }

    /**
     * Creates this AIG Servlet object
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return AIGServlet
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new GenerateEntityNodeTooltip(req, resp);
    }

    public void performRequest() throws ServletException, IOException, AIGException {
        String treeNodeUUID = getParameter("uuid");
        Element entityLineage = TreeNodeCache.getTreeNodeCache(request).getTreeNode(treeNodeUUID);

        try {
            if (entityLineage != null) {
                String tooltipXSLT = entityLineage.getAttributeValue("TOOLTIPXSLT");
                if (tooltipXSLT != null) {
                    Document xsltDocument = new SAXBuilder().build(new URL(tooltipXSLT).openStream());
                    JDOMSource xsltSource = new JDOMSource(xsltDocument);
                    TransformerFactory tFactory = TransformerFactory.newInstance();
                    Transformer transformer = tFactory.newTransformer(xsltSource);
                    transformer.transform(new JDOMSource(entityLineage), new StreamResult(response.getWriter()));
                } else {

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Returns the mimetype of the servlet
     */
    protected String getServletMimeType() {
        return "text/html";
    }

}
