package amgen.ri.aig.cache.item;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.aig.preferences.PreferenceManager;

/**
 * @version $id$
 */
public class EntityTableCacheItem extends AbstractCacheItem {

  public EntityTableCacheItem() {
    super(null);
  }

  public EntityTableCacheItem(AIGBase servlet, EntityTable entityTable) {
    this();
    //Load the preferences from the saved preferences
    new PreferenceManager(servlet, entityTable).setPreferences();
    setEntityTable(entityTable);
  }

  public final void setEntityTable(EntityTable entityTable) {
    setCacheObject(entityTable);
    entityTable.setTableKey(getKey());
  }

  public EntityTable getEntityTable() {
    return (EntityTable) getCacheObject();
  }

  public String getEntityTableKey() {
    return getKey();
  }

}
