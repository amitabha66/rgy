package amgen.ri.aig.entitytable;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.sm.structure.ChemMolIDType;
import amgen.ri.aig.sm.structure.ChemMolInput;
import amgen.ri.aig.sm.structure.ChemMolSource;
import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;

public class StructureDataCell extends DataCell {
    static final long serialVersionUID = 2239869781721865326L;
    private String resultKey;

    public StructureDataCell(String compoundID, String resultKey, int imageWidth) {
        super(compoundID, AIGBase.getStructureImageURL(new ChemMolInput(ChemMolSource.ACRF, compoundID, ChemMolIDType.ROOT_NUMBER), imageWidth + "", null, resultKey), imageWidth, imageWidth,
              EntityTableDataType.TEXT);
        this.resultKey = resultKey;
    }

    public void setImageWidth(int imageWidth) {
        super.setImageWidth(imageWidth);
        ChemMolInput chemMolInput = new ChemMolInput(ChemMolSource.ACRF, getValue(), ChemMolIDType.ROOT_NUMBER);
        setImageURL(AIGBase.getStructureImageURL(chemMolInput, imageWidth + "", null, resultKey));
    }

    public void setImageHeight(int imageHeight) {
        super.setImageHeight(imageHeight);
        ChemMolInput chemMolInput = new ChemMolInput(ChemMolSource.ACRF, getValue(), ChemMolIDType.ROOT_NUMBER);
        setImageURL(AIGBase.getStructureImageURL(chemMolInput, imageHeight + "", null, resultKey));
    }

}
