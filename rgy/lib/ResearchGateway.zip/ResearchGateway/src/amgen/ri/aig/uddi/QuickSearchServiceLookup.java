package amgen.ri.aig.uddi;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCacheResponse;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.asf.sa.uddi.CategoryKeyValue;
import amgen.ri.asf.sa.uddi.ClassificationSchemeQuery;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.json.JSONObject;
import amgen.ri.util.Debug;
import amgen.ri.xml.ExtXMLElement;
import java.io.IOException;
import java.util.*;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;

/**
 * @version $Id: QuickSearchServiceLookup.java,v 1.16 2015/03/05 22:26:06 jemcdowe Exp $
 */
public class QuickSearchServiceLookup extends AbstractServiceLookup implements ServiceLookupIF, QueryServiceIF {

  public QuickSearchServiceLookup() {
    super();
  }

  public QuickSearchServiceLookup(AIGServlet requestor) {
    super(requestor);
  }

  public QuickSearchServiceLookup(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  /**
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return TBXServlet @todo Implement this amgen.ri.aig.AIGServlet method
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new QuickSearchServiceLookup(req, resp);
  }

  /**
   *
   * @return String @todo Implement this amgen.ri.aig.AIGServlet method
   */
  @Override
  protected String getServletMimeType() {
    return "text/xml";
  }

  /**
   * Returns the Service as an XML Element which is used when creating the Services XML. May be overridden if the
   * default behavior needs changed.
   *
   * @param searchService ServiceDetails
   * @return Element
   */
  @Override
  protected Element getServiceElement(ServiceDetails searchService) {
    try {
      Document sdXML = searchService.getSDXMLDocument();
      if (sdXML != null) {
        return super.getServiceElement(searchService);
      }
    } catch (Exception e) {
    }
    return null;
  }

  /**
   * Actual work entry stub
   *
   * @throws ServletException
   * @throws IOException
   */
  @Override
  protected void performRequest() throws ServletException, IOException, AIGException {
    try {
      ExtXMLElement.write(getServicesDocument(), response.getWriter());
    } catch (JDOMException ex) {
      ex.printStackTrace();
    }
  }

  public ServiceQuery getServiceQuery() {
    ClassificationSchemeQuery classificationSchemeQuery = new ClassificationSchemeQuery();
    classificationSchemeQuery.addKeyValue(TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME, "Entity Quick Search");

    ServiceQuery serviceQuery = new ServiceQuery(classificationSchemeQuery, new String[]{
      TModelCommonNameFactory.QUERYTREENODESDEFINITION_tMODELNAME, TModelCommonNameFactory.QUERYRGRAWENTITYTABLEDEFINITION_TMODELNAME
    });
    return serviceQuery;
  }

  @Override
  public Collection<ServiceQuery> getCacheServiceQueries() {
    List<ServiceQuery> serviceQueries = new ArrayList<ServiceQuery>();
    serviceQueries.add(getServiceQuery());

    ClassificationSchemeQuery classificationSchemeQuery = new ClassificationSchemeQuery();
    classificationSchemeQuery.addKeyValue(TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME, "Entity Quick Search");

    ServiceQuery serviceQuery = new ServiceQuery(classificationSchemeQuery, TModelCommonNameFactory.QUERYTREENODESDEFINITION_tMODELNAME);
    serviceQueries.add(serviceQuery);

    return serviceQueries;
  }

  @Override
  public Document getServicesDocument() throws JDOMException, AIGException {
    Document servicesDocument = new Document(new Element("Services"));
    Map<EntityListCategory, ServiceDetails> sortedSearchServiceMap = new EnumMap<EntityListCategory, ServiceDetails>(EntityListCategory.class);

    ServiceCacheResponse sortedSearchServices = findAndSortServices(getServiceQuery());

    for (ServiceDetails service : sortedSearchServices) {
      ServiceAttributes serviceAttributes = new ServiceAttributes(service, getEntityClassManager());
      EntityListCategory serviceCategory = serviceAttributes.getFirstEntityListCategory();
      if (!serviceCategory.equals(EntityListCategory.UNKNOWN) && !sortedSearchServiceMap.containsKey(serviceCategory)) {
        sortedSearchServiceMap.put(serviceCategory, service);
      }
    }
    for (EntityListCategory category : sortedSearchServiceMap.keySet()) {
      ServiceDetails service = sortedSearchServiceMap.get(category);
      try {
        if (service.containsUserInAllowedUsers(getSessionLogin().getRemoteUser(), true)) {
          ServiceAttributes serviceAttributes = new ServiceAttributes(service, getEntityClassManager());
          Element searchServiceElement = getServiceElement(service);
          if (searchServiceElement != null) {
            servicesDocument.getRootElement().addContent(searchServiceElement);
            ExtXMLElement.addTextElement(searchServiceElement, "ID", UUID.randomUUID() + "");
            Element nameElement = searchServiceElement.getChild("Name");
            nameElement.setText(serviceAttributes.getName(ServiceNamingContext.RG_QUERY));
            Element descElement = searchServiceElement.getChild("Description");
            descElement.setText(serviceAttributes.getDescription(ServiceNamingContext.RG_QUERY));
            ExtXMLElement.addElement(searchServiceElement, "IconCls", serviceAttributes.getIconClass(ServiceNamingContext.RG_LOFT));

            CategoryKeyValue orgCatValue = serviceAttributes.getOrganizationCategoryKeyValue();
            ExtXMLElement.addTextElement(searchServiceElement, "Category", (orgCatValue == null ? "Other" : orgCatValue.getKeyName()));
            ExtXMLElement.addTextElement(searchServiceElement, "CategoryTag", serviceAttributes.getFirstEntityListCategoryLabel());
            ExtXMLElement.addTextElement(searchServiceElement, "EntityCategory", serviceAttributes.getFirstEntityListCategory() + "");
            ExtXMLElement.addElement(searchServiceElement, "EditableParams", serviceAttributes.countEditableParameters(null) + "");
          }
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

    return servicesDocument;
  }

  @Override
  public JSONObject getServiceRecords() throws JDOMException, AIGException {
    return getServiceRecords(getServicesDocument());
  }
  /*
   protected Document createViewRetrievalServiceDocument() throws Exception {
   Document quickSearchDoc = new Document();
   Element quickSearchServicesEl = new Element("Services");
   quickSearchDoc.addContent(quickSearchServicesEl);
   Element serviceEl = ExtXMLElement.addElement(quickSearchServicesEl, "Service");
   ExtXMLElement.addTextElement(serviceEl, "ServiceKey", "RGViewLoader");
   ExtXMLElement.addTextElement(serviceEl, "Name", "RG View");
   ExtXMLElement.addTextElement(serviceEl, "Organization", "Research Gateway");
   ExtXMLElement.addTextElement(serviceEl, "Contact", "Research Gateway Support");
   ExtXMLElement.addTextElement(serviceEl, "Description", "Open a Research Gateway View");
   ExtXMLElement.addTextElement(serviceEl, "QuickSearchType", "RGViewLoader");
   ExtXMLElement.addTextElement(serviceEl, "QuickSearchParameter", "quickload_view_id");
   ExtXMLElement.addTextElement(serviceEl, "QuickSearchParameterLabel", "View ID");
   ExtXMLElement.addTextElement(serviceEl, "QuickSearchQuery", queryValue);
   return quickSearchDoc;

   }

   protected Document createVQTRetrievalServiceDocument() throws Exception {
   Document quickSearchDoc = new Document();
   Element quickSearchServicesEl = new Element("Services");
   quickSearchDoc.addContent(quickSearchServicesEl);
   Element serviceEl = ExtXMLElement.addElement(quickSearchServicesEl, "Service");
   ExtXMLElement.addTextElement(serviceEl, "ServiceKey", "VQTViewLoader");
   ExtXMLElement.addTextElement(serviceEl, "Name", "VQT Query Retrieval");
   ExtXMLElement.addTextElement(serviceEl, "Organization", "Research Gateway");
   ExtXMLElement.addTextElement(serviceEl, "Contact", "Research Gateway Support");
   ExtXMLElement.addTextElement(serviceEl, "Description", "Open a previous VQT Result");
   ExtXMLElement.addTextElement(serviceEl, "QuickSearchType", "VQTViewLoader");
   ExtXMLElement.addTextElement(serviceEl, "QuickSearchParameter", "query_run_id");
   ExtXMLElement.addTextElement(serviceEl, "QuickSearchParameterLabel", "VQTQuery Run ID");
   ExtXMLElement.addTextElement(serviceEl, "QuickSearchQuery", queryValue);
   return quickSearchDoc;
   }

   protected Document createNameRetrievalServiceDocument() throws Exception {
   Document quickSearchDoc = new Document();
   Element quickSearchServicesEl = new Element("Services");
   quickSearchDoc.addContent(quickSearchServicesEl);
   Element serviceEl = ExtXMLElement.addElement(quickSearchServicesEl, "Service");
   ExtXMLElement.addTextElement(serviceEl, "ServiceKey", "CorporateDirectory");
   ExtXMLElement.addTextElement(serviceEl, "Name", "Search Corporate Directory");
   ExtXMLElement.addTextElement(serviceEl, "Organization", "Research Gateway");
   ExtXMLElement.addTextElement(serviceEl, "Contact", "Research Gateway Support");
   ExtXMLElement.addTextElement(serviceEl, "Description", "Search Corporate Directory");
   ExtXMLElement.addTextElement(serviceEl, "QuickSearchType", "CorporateDirectory");
   ExtXMLElement.addTextElement(serviceEl, "QuickSearchParameter", "name");
   ExtXMLElement.addTextElement(serviceEl, "QuickSearchParameterLabel", "Name");
   ExtXMLElement.addTextElement(serviceEl, "QuickSearchQuery", queryValue);
   return quickSearchDoc;
   }
   */
  /**
   * performServiceLookup
   *
   * @param startingServiceList Document
   * @throws Exception @todo Add the service sort by recent
   *
   * protected void performServiceLookup(Document startingServiceList) throws Exception { Document servicesDoc = new
   * Document(); Element quickSearchServicesEl = new Element("Services"); servicesDoc.addContent(quickSearchServicesEl);
   *
   * if (startingServiceList != null) { List<Element> serviceEls = ExtXMLElement.getXPathElements(startingServiceList,
   * "//Service"); for (Element serviceEl : serviceEls) { quickSearchServicesEl.addContent((Element) serviceEl.clone());
   * } } Collection<ServiceDataCategory> categories =
   * CategoryConversions.selectServiceDataCategoryFromQuery(queryValue); for (ServiceDataCategory category : categories)
   * { boolean match = false; ClassificationSchemeQuery classificationSchemeQuery = new
   * ClassificationSchemeQuery(ClassificationSchemeQuery.AND_ALL_KEYS); switch (category) { case AMGEN_ROOT_ID:
   * classificationSchemeQuery.addKeyValue(TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME, "Compound
   * Quick Search"); match = true; break; case AMGEN_NAME:
   * classificationSchemeQuery.addKeyValue(TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME, "Substance
   * Quick Search"); match = true; break; case ASSAY_IDENTIFIER:
   * classificationSchemeQuery.addKeyValue(TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME, "Assay Quick
   * Search"); match = true; break; case WATSON_STUDY_IDENTIFIER:
   * classificationSchemeQuery.addKeyValue(TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME, "Watson Study
   * Quick Search"); match = true; break; case GALILEO_STUDY_IDENTIFIER:
   * classificationSchemeQuery.addKeyValue(TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME, "Galileo
   * Study Quick Search"); match = true; break; case PROJECT:
   * classificationSchemeQuery.addKeyValue(TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME, "Project
   * Quick Search"); match = true; break; case AMGEN_GENE_IDENTIFIER:
   * classificationSchemeQuery.addKeyValue(TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME, "Gene Quick
   * Search"); match = true; break; } if (match) {
   * //classificationSchemeQuery.addKeyValue(TModelCommonNames.SERVICE_INPUT_CATEGORIZATION_SCHEME, //
   * ServiceDataCategory.revertTo(category)); Element queryResultServiceEls =
   * findAndSortServicesToElement(classificationSchemeQuery,
   * TModelCommonNameFactory.QUERYTREENODESDEFINITION_tMODELNAME); Document queryResultServicesDoc = new
   * Document(queryResultServiceEls); for (ServiceDetails service : getServiceList()) { try { Document sdXML =
   * service.getSDXMLDocument(); if (sdXML != null) { //Input parameter is either the one with Research Gateway Service
   * Input Categorization Scheme= Entity Quick Search Parameter // or Service Input Categorization Scheme=
   * <input type>
   * Element parameterEl = ExtXMLElement.getXPathElement(sdXML, "//Parameter[Category[CategorizationScheme='Research
   * Gateway Service Input Categorization Scheme']" + "[upper-case(KeyValue)='ENTITY QUICK SEARCH PARAMETER']]"); if
   * (parameterEl == null) { parameterEl = ExtXMLElement.getXPathElement(sdXML,
   * "//Parameter[Category[CategorizationScheme='Service Input Categorization Scheme']" + "[upper-case(KeyValue)='" +
   * ServiceDataCategory.revertTo(category).toUpperCase() + "']]"); } if (parameterEl != null) { String parameterName =
   * parameterEl.getChildText("Name"); String parameterLabel = parameterEl.getChildText("Label"); if
   * (ExtString.hasLength(parameterName)) { service.setParameterValue(parameterName, queryValue); if
   * (service.isServiceReady()) { Element quickSearchServiceEl = ExtXMLElement.getXPathElement(queryResultServicesDoc,
   * "/Services/Service[ServiceKey='" + service.getKey() + "']"); if (quickSearchServiceEl != null) { Element
   * updatedQuickSearchServiceEl = (Element) quickSearchServiceEl.clone();
   * ExtXMLElement.addTextElement(updatedQuickSearchServiceEl, "QuickSearchType", "Compound");
   * ExtXMLElement.addTextElement(updatedQuickSearchServiceEl, "QuickSearchParameter", parameterName);
   * ExtXMLElement.addTextElement(updatedQuickSearchServiceEl, "QuickSearchParameterLabel",
   * (ExtString.hasLength(parameterLabel) ? parameterLabel : parameterName));
   * ExtXMLElement.addTextElement(updatedQuickSearchServiceEl, "QuickSearchQuery", queryValue);
   * quickSearchServicesEl.addContent(updatedQuickSearchServiceEl); } } } } } } catch (Exception e) {
   * e.printStackTrace(); } } } } ExtXMLElement.write(quickSearchServicesEl, response.getWriter()); }
   *
   * public String getQueryValue() { return queryValue; }
   */
}

enum QuickSearchType {

  VIEW_RETRIEVAL, VQT_RETRIEVAL, SERVICE, PERSON_RETRIEVAL
}
