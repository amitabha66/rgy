/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.loft;

public enum AppType {
  FAVORITES_TOOL,
  PREFERENCES_TOOL,
  DOCUMENTS_TOOL,
  EXPLORE_TOOL,
  VQT_TOOL,
  LISTS_TOOL,
  PROJECT_VIEW_TOOL,
  PROJECT_VIEW,
  TABLE_IMPORT_TOOL,
  STRUCTURE_SEARCH_TOOL,
  TOOLS,
  WIDGETS,
  FAVORITE,
  SERVICE,
  UNKNOWN;

  public static AppType fromString(String s) {
    try {
      return AppType.valueOf(s.toUpperCase());
    } catch (Exception e) {
      return AppType.UNKNOWN;
    }
  };

  public String getImageCSS() {
    switch (this) {
      case FAVORITES_TOOL:
        return "ix-v0-48-star_yellow";
      case EXPLORE_TOOL:
        return "ix-v0-48-signpost";
      case VQT_TOOL:
        return "ix-v0-48-logic_and";
      case LISTS_TOOL:
        return "ix-v0-48-notebook";
      case PROJECT_VIEW_TOOL:
        return "ix-v0-48-pie-chart_view";
      case PREFERENCES_TOOL:
        return "ix-v0-48-gear_preferences";
      case DOCUMENTS_TOOL:
        return "ix-v0-48-folder_document";
      case TABLE_IMPORT_TOOL:
        return "ix-v0-48-table_sql_create";
      case STRUCTURE_SEARCH_TOOL:
        return "x-rg-48-structure_search";
      case TOOLS:
        return "ix-v0-48-windows";
      case WIDGETS:
        return "ix-v0-48-components";

    }
    return null;
  }

  ;

  public String getAppSelectorName() {
    switch (this) {
      case FAVORITES_TOOL:
        return "Favorites";
      case EXPLORE_TOOL:
        return "Searches";
      case VQT_TOOL:
        return "Saved Queries";
      case LISTS_TOOL:
        return "Lists";
      case PROJECT_VIEW_TOOL:
        return "Project Views";
      case PREFERENCES_TOOL:
        return "Preferences";
      case DOCUMENTS_TOOL:
        return "Documents";
      case TOOLS:
        return "RG Tools";
      case WIDGETS:
        return "Other Apps";
    }
    return null;
  }
; 

  
}