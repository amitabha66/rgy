/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.jsonquery;

import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

/**
 * Calls the generic JSON Statement query engine
 * @author jemcdowe
 */
public class JSONProcQuery {
  public JSONProcQuery() {
  }

  /**
   * Executes a query passing in the given parameter name/value and returning a List of JSONObjects
   * @param queryName
   * @return
   * @throws SQLException 
   */
  public List<JSONObject> executeJSONProcQuery(String queryName, String parameterName, String parameterValue) throws SQLException {
    Map<String, String> parameters= new HashMap<String, String>();
    parameters.put(parameterName, parameterValue);
    return executeJSONProcQuery(queryName, parameters);
  }

  /**
   * Executes a query passing in the given parameters and returning a List of JSONObjects
   * @param queryName
   * @param parameters
   * @return
   * @throws SQLException 
   */
  public List<JSONObject> executeJSONProcQuery(String queryName, Map<String, String> parameters) throws SQLException {
    Connection conn = null;
    Statement stmt = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC.toString());

      Array array = null;
      if (parameters != null && !parameters.isEmpty()) {
        ArrayDescriptor descriptor =
                ArrayDescriptor.createDescriptor("JPROC_PARAMETER", conn);
        List<String> parameterList= new ArrayList<String>();
        for(String pName : parameters.keySet()) {
          parameterList.add(pName+":"+parameters.get(pName));
        }
        array = new ARRAY(descriptor, conn, parameterList.toArray(new String[0]));
      }

      stmt = conn.prepareCall("BEGIN ? := executeJProcQuery(?, ?); END;");
      CallableStatement cs = (CallableStatement) stmt;
      cs.registerOutParameter(1, Types.BLOB);
      cs.setString(2, queryName);
      cs.setArray(3, array);

      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      JSONObject jResults = fromBlob2JSON(resultBlob);
      if (jResults.has("results")) {
        return jResults.getJSONArray("results").asList();
      }
    } catch (JSONException e) {
    } finally {
      OraSQLManager.close(stmt);
      OraSQLManager.close(conn);
    }
    return new ArrayList<JSONObject>();
  }

  private JSONObject fromBlob2JSON(Blob b) throws SQLException {
    InputStream in = null;
    ByteArrayOutputStream bytesOut = null;
    try {
      in = b.getBinaryStream();
      bytesOut = new ByteArrayOutputStream();
      byte[] bytes = new byte[1025];
      int byteCount = -1;
      while ((byteCount = in.read(bytes)) > 0) {
        bytesOut.write(bytes);
      }
      in.close();
      bytesOut.close();
      ObjectInputStream objIN = new ObjectInputStream(new GZIPInputStream(new ByteArrayInputStream(bytesOut.toByteArray())));
      return new JSONObject((String) objIN.readObject());
    } catch (Exception e) {
    } finally {
      try {
        in.close();
      } catch (Exception e) {
      }
      try {
        bytesOut.close();
      } catch (Exception e) {
      }
    }
    return new JSONObject();
  }
}
