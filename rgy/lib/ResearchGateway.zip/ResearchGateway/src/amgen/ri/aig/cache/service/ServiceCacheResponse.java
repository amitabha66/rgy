/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.service;

import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.sv.ServiceAttributes;
import static amgen.ri.aig.uddi.AbstractServiceLookup.RECENT_DATE_FORMAT;
import amgen.ri.asf.sa.uddi.CategoryKeyValue;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.rg.resource.ResourceFactory;
import amgen.ri.util.ExtArray;
import amgen.ri.xml.ExtXMLElement;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.collections.comparators.ComparatorChain;
import org.jdom.Document;
import org.jdom.Element;

/**
 *
 * @author jemcdowe
 */
public class ServiceCacheResponse extends ResourceFactory implements Collection<ServiceDetails>, Serializable {

  static final long serialVersionUID = -6397670780999982305L;

  private List<ServiceDetails> services;

  private boolean sorted;

  public ServiceCacheResponse() {
    services = new ArrayList<ServiceDetails>();
    this.sorted= false;
  }

  public ServiceCacheResponse(Collection<ServiceDetails> services) {
    this();
    this.services.addAll(services);
  }

  public ServiceDetails get(int index) {
    return services.get(index);
  }

  public void sortServices(ServiceNamingContext serviceNamingContext, Document recentServicesDocument) {
    services = ExtArray.sort(services, getServiceSortComparator(serviceNamingContext, recentServicesDocument));
  }

  /**
   * Get the value of sorted
   *
   * @return the value of sorted
   */
  public boolean isSorted() {
    return sorted;
  }

  /**
   * Set the value of sorted
   *
   * @param sorted new value of sorted
   */
  public void setSorted(boolean sorted) {
    this.sorted = sorted;
  }

  /**
   * Returns the comparator to sort the services. The default is by
   * alphabetically by name.
   *
   * @param obj1 Object
   * @param obj2 Object
   * @return int
   */
  private Comparator getServiceSortComparator(final ServiceNamingContext serviceNamingContext, final Document recentServicesDocument) {
    Comparator nameComparator = new Comparator() {
      public int compare(Object obj1, Object obj2) {
        ServiceDetails serviceDetails1 = (ServiceDetails) obj1;
        ServiceDetails serviceDetails2 = (ServiceDetails) obj2;

        String name1 = new ServiceAttributes(serviceDetails1, getEntityClassManager()).getName(serviceNamingContext);
        String name2 = new ServiceAttributes(serviceDetails2, getEntityClassManager()).getName(serviceNamingContext);
        return name1.toUpperCase().compareTo(name2.toUpperCase());
      }
    };
    Comparator lastUsedComparator = new Comparator() {
      public int compare(Object obj1, Object obj2) {
        ServiceDetails serviceDetails1 = (ServiceDetails) obj1;
        ServiceDetails serviceDetails2 = (ServiceDetails) obj2;

        Date d1 = getLastUsedDate(serviceDetails1, recentServicesDocument);
        Date d2 = getLastUsedDate(serviceDetails2, recentServicesDocument);

        if (d1 == null && d2 == null) {
          return 0;
        } else if (d1 != null && d2 == null) {
          return -1;
        } else if (d1 == null && d2 != null) {
          return 1;
        } else {
          return -d1.compareTo(d2);
        }
      }
    };

    Comparator orgKeyComparator = new Comparator() {
      public int compare(Object obj1, Object obj2) {
        ServiceDetails serviceDetails1 = (ServiceDetails) obj1;
        ServiceDetails serviceDetails2 = (ServiceDetails) obj2;

        ServiceAttributes attr1 = new ServiceAttributes(serviceDetails1, getEntityClassManager());
        ServiceAttributes attr2 = new ServiceAttributes(serviceDetails2, getEntityClassManager());

        CategoryKeyValue cat1 = attr1.getOrganizationCategoryKeyValue();
        CategoryKeyValue cat2 = attr2.getOrganizationCategoryKeyValue();

        String keyValue1 = (cat1 == null ? null : cat1.getKeyValue().toUpperCase());
        String keyValue2 = (cat2 == null ? null : cat2.getKeyValue().toUpperCase());

        if (keyValue1 == null && keyValue2 == null) {
          return 0;
        } else if (keyValue1 != null && keyValue2 == null) {
          return -1;
        } else if (keyValue1 == null && keyValue2 != null) {
          return 1;
        } else {
          return keyValue1.compareTo(keyValue2);
        }
      }
    };

    Comparator defaultViewComparator = new Comparator() {
      public int compare(Object obj1, Object obj2) {
        ServiceDetails serviceDetails1 = (ServiceDetails) obj1;
        ServiceDetails serviceDetails2 = (ServiceDetails) obj2;

        ServiceAttributes attr1 = new ServiceAttributes(serviceDetails1, getEntityClassManager());
        ServiceAttributes attr2 = new ServiceAttributes(serviceDetails2, getEntityClassManager());

        boolean isDefView1 = attr1.isEntityDefaultView();
        boolean isDefView2 = attr2.isEntityDefaultView();

        return -((isDefView1 == isDefView2) ? 0 : (isDefView1 ? 1 : -1));
      }
    };

    ComparatorChain comparatorChain = new ComparatorChain();
    comparatorChain.addComparator(defaultViewComparator);
    comparatorChain.addComparator(lastUsedComparator);
    comparatorChain.addComparator(orgKeyComparator);
    comparatorChain.addComparator(nameComparator);

    return comparatorChain;
  }

  /**
   * Returns the last used date of the Service
   *
   * @param service
   * @return
   */
  private Date getLastUsedDate(ServiceDetails service, Document recentServicesDocument) {
    try {
      Element serviceEl = ExtXMLElement.getXPathElement(recentServicesDocument, "/RecentServices/Service[@serviceKey='" + service.getKey() + "']");
      if (serviceEl != null) {
        Date lastUsedDate = RECENT_DATE_FORMAT.parse(serviceEl.getAttributeValue("lastDateCalled"));
        return lastUsedDate;
      }
    } catch (Exception e) {
    }
    return null;
  }

  public int size() {
    return services.size();
  }

  public boolean isEmpty() {
    return services.isEmpty();
  }

  public boolean contains(Object o) {
    return services.contains(o);
  }

  public Iterator<ServiceDetails> iterator() {
    return services.iterator();
  }

  public Object[] toArray() {
    return services.toArray();
  }

  public <T> T[] toArray(T[] a) {
    return services.toArray(a);
  }

  public boolean add(ServiceDetails e) {
    return services.add(e);
  }

  public boolean remove(Object o) {
    return services.remove(o);
  }

  public boolean containsAll(Collection<?> c) {
    return services.containsAll(c);
  }

  public boolean addAll(Collection<? extends ServiceDetails> c) {
    return services.addAll(c);
  }

  public boolean removeAll(Collection<?> c) {
    return services.removeAll(c);
  }

  public boolean retainAll(Collection<?> c) {
    return services.retainAll(c);
  }

  public void clear() {
    services.clear();
  }

}
