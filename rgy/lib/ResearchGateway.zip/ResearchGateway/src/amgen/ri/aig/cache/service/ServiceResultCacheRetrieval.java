package amgen.ri.aig.cache.service;

import amgen.ri.aig.cache.tree.TreeNode;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.rpc.ServiceException;
import javax.xml.transform.OutputKeys;

import org.apache.poi.ss.SpreadsheetVersion;
import org.jdom.Document;
import org.jdom.output.Format;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.cache.item.AbstractCacheItem.ResultRelationshipType;
import amgen.ri.aig.cache.item.CacheItemIF;
import amgen.ri.aig.cache.item.EntityTableCacheItem;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.aig.cache.CacheManagerFactory;
import amgen.ri.aig.cache.CacheType;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.entity.EntityClass;
import amgen.ri.aig.export.ExportUtils;
import amgen.ri.aig.projectview.model.ProjectViewModel;
import amgen.ri.aig.sv.OILServiceParameterInterceptor;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.asf.sa.uddi.BindingDetails;
import amgen.ri.asf.sa.uddi.Categorization;
import amgen.ri.asf.sa.uddi.ClassificationSchemeNames;
import amgen.ri.asf.sa.uddi.CommonKeyValues;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.ServiceParameter;
import amgen.ri.asf.sa.uddi.TModelDetails;
import amgen.ri.asf.sa.uddi.TModelInstanceDetails;
import amgen.ri.excel.ExcelUtils;
import amgen.ri.json.ExtJSON;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import javax.servlet.annotation.WebServlet;

/**
 * @version $Id: ServiceResultCacheRetrieval.java,v 1.7 2012/06/13 22:35:39 cvs
 * Exp $
 */
@WebServlet(name = "ServiceResultCacheRetrieval", urlPatterns = {"/cacheretrieval.go", "/cacheretrieval"})
public class ServiceResultCacheRetrieval extends AIGServlet {
  private String mimetype;

  /**
   * Default constructor
   */
  public ServiceResultCacheRetrieval() {
    super();
  }

  /**
   * Main constructor- used only by the getAIGServlet method
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   */
  private ServiceResultCacheRetrieval(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);

    if (doesParameterExist("serviceKey")) {
      ServiceCache serviceCache = ServiceCache.getServiceCache(request);
      ServiceDetails service = null;
      try {
        service = serviceCache.getService(getParameter("serviceKey"));
      } catch (AIGException ex) {
        ex.printStackTrace();
      }
      if (service != null) {
        Categorization docTypeCategorization = null;
        BindingDetails rawResultBinding = null;
        try {
          rawResultBinding = service.getCommonTypeBinding(ClassificationSchemeNames.EXTENDED_TYPES_CATEGORIZATION_SCHEME,
                  CommonKeyValues.rawResultSpec);
          if (rawResultBinding != null) {
            List<TModelInstanceDetails> tModelInstances = rawResultBinding.getTModelInstances();
            for (TModelInstanceDetails tModelInstance : tModelInstances) {
              TModelDetails tModel = tModelInstance.getTModelDetails();
              docTypeCategorization = TModelCommonNameFactory.getInstance().getCategorizationByName(tModel, TModelCommonNameFactory.RESEARCH_GATEWAY_DOCUMENT_TYPES_SCHEME);

              if (docTypeCategorization != null && docTypeCategorization.hasKeyValues()) {
                break;
              }
            }
          }
        } catch (ServiceException ex1) {
        }
        // CURRENTLY- IF THERE IS A RAWRESULTBINDING, IT IS ASSUMED OT BE EXCEL!!!!

        if (rawResultBinding != null) {
          if (docTypeCategorization != null && docTypeCategorization.hasKeyValues()) {
            mimetype = new ExportUtils().getMimetype(docTypeCategorization);
          } else {
            mimetype = "application/vnd.ms-excel";
          }
        }
      }
    }
    if (mimetype == null) {
      if (doesParameterEqual("output", "xml")) {
        mimetype = "text/xml";
      } else if (doesParameterEqual("output", "html")) {
        mimetype = "text/html";
      } else {
        mimetype = "text/plain";
      }
    }
  }

  /**
   * Creates this AIG Servlet object
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return AIGServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new ServiceResultCacheRetrieval(req, resp);
  }

  /**
   *
   * @return String
   */
  protected String getServletMimeType() {
    return mimetype;
  }

  /**
   *
   * @throws Exception
   */
  protected void performRequest() throws Exception {
    ServiceCache serviceCache = ServiceCache.getServiceCache(request);
    
    String resultKey = getParameter("key");
    String tModelKey = getParameter("tModelKey");
    String tModelName = getParameter("tModelName");
    String bindingKey = getParameter("bindingKey");
    String resultTypeName = getParameter("resultTypeName");
    String resultParameterName = getParameter("resultParameterName");
    String serviceKey = getParameter("serviceKey");
    String sessionID = getParameter("sessionID");
    String cacheID = getParameter("cacheID");

    ServiceResultCacheItem serviceResult = null;
    if (sessionID != null && cacheID != null) {
      serviceResult = (ServiceResultCacheItem) CacheManagerFactory.getCacheManagerInstance(sessionID).get(CacheType.SERVICERESULT, cacheID);
    } else {
      serviceResult = serviceCache.getServiceResult(resultKey);
    }

    if (ExtString.hasLength(serviceKey)) {
      try {
        ServiceDetails service = serviceCache.getService(serviceKey);
        CacheItemIF serviceResultSourceTreeNode = serviceCache.getRelatedServiceResult(resultKey, ResultRelationshipType.SOURCE_TREENODES);
        CacheItemIF serviceResultSourceEntityTable = serviceCache.getRelatedServiceResult(resultKey, ResultRelationshipType.SOURCE_TABLE);
        CacheItemIF serviceResultSourceProjectView = serviceCache.getRelatedServiceResult(resultKey, ResultRelationshipType.SOURCE_PROJECTVIEW);

        if (service != null) {
          ServiceAttributes serviceAttributes = new ServiceAttributes(service, getEntityClassManager());
          OILServiceParameterInterceptor oilInterceptor = serviceAttributes.getListenerByType(OILServiceParameterInterceptor.class);

          if (serviceResultSourceTreeNode != null) {
            TreeNode cachedTreeNode = (TreeNode) serviceResultSourceTreeNode;
            EntityClass entityClass = getEntityClassManager().getEntityClass(cachedTreeNode.getEntityListCategory(getEntityClassManager()));
            oilInterceptor.addEntityClassesToIncludeParameters(entityClass);
          }
          if (serviceResultSourceEntityTable != null) {
            EntityTableCacheItem cachedEntityTable = (EntityTableCacheItem) serviceResultSourceEntityTable;
            EntityClass entityClass = getEntityClassManager().getEntityClass(cachedEntityTable.getEntityTable().getEntityCategory());
            oilInterceptor.addEntityClassesToIncludeParameters(entityClass);
          }
          if (serviceResultSourceProjectView != null) {
            ProjectViewModel projectViewModel = (ProjectViewModel) serviceResultSourceProjectView.getProperty("PROJECTVIEWDETAILS");
            if (projectViewModel != null) {
              EntityClass entityClass = getEntityClassManager().getEntityClass(projectViewModel.getEntityCategory());
              oilInterceptor.addEntityClassesToIncludeParameters(entityClass);
            }
          }

          if (resultParameterName != null) {
            if (serviceResult != null) {
              ServiceParameter resultInputParameter = service.getParameter(resultParameterName);
              if (resultInputParameter != null) {
                resultInputParameter.setValue(serviceResult.getCacheString());
              }
            }
          }
          if (ExtString.in(mimetype, new String[]{
            "text/xml", "text/html", "text/plain"
          })) {
            Document results = executeService2JDocument(service, resultTypeName, true);
            Format format = Format.getCompactFormat();
            format.setOmitDeclaration(true);
            format.setExpandEmptyElements(true);
            ExtXMLElement.write(results, response.getWriter(), format);
          } else if (mimetype.equals("application/vnd.ms-excel")) {
            byte[] resultBytes = (byte[]) executeService(service, null, true);
            SpreadsheetVersion version = ExcelUtils.getSpreadsheetVersion(resultBytes);
            String docName = getParameter("doc_name", "output") + "." + ExcelUtils.getExtension(version);
            response.setContentType(ExcelUtils.getMimetype(version));
            response.addHeader("Content-disposition", "attachment; filename=" + docName.replaceAll("\\s+", "_"));
            response.getOutputStream().write(resultBytes);
          } else {
            byte[] resultBytes = (byte[]) executeService(service, null, true);
            String extension = new ExportUtils().getExtension(mimetype);
            String docName = getParameter("doc_name", "output") + "." + extension;
            response.setContentType(mimetype);
            response.addHeader("Content-disposition", "attachment; filename=" + docName.replaceAll("\\s+", "_"));
            response.getOutputStream().write(resultBytes);
          }
        }
      } catch (Exception e) {
        e.printStackTrace();
        return;
      }
    } else {
      Map<String, String> operationParameters = getParameters(new String[]{
        "key", "tModelKey", "bindingKey", "tModelName", "serviceKey"
      });

      if (serviceResult == null) {
        throw new AIGException("Result key not found", Reason.CACHE_ERROR);
      }
      if (ExtString.hasLength(tModelKey)) {
        TModelDetails tModelDetails = serviceCache.getTModelDetails(tModelKey);
        serviceResult.transformResult(this, tModelDetails, operationParameters, null, response.getWriter());
      } else if (ExtString.hasLength(bindingKey)) {
        BindingDetails bindingDetails = serviceCache.getBindingDetails(bindingKey);
        serviceResult.transformResult(this, bindingDetails, operationParameters, null, response.getWriter());
      } else if (ExtString.hasLength(tModelName)) {
        TModelDetails tModelDetails = serviceCache.getTModelDetailsByName(tModelName);
        Map<String, String> transformerOutputProperties = new HashMap<String, String>();
        transformerOutputProperties.put(OutputKeys.OMIT_XML_DECLARATION, "yes");
        if (!doesParameterEqual("output", "xml")) {
          transformerOutputProperties.put(OutputKeys.METHOD, "text");
          StringWriter writer = new StringWriter();
          serviceResult.transformResult(this, tModelDetails, operationParameters, transformerOutputProperties, writer);
          Object obj = ExtJSON.toJSON(writer.toString());
          if (obj != null) {
            response.getWriter().println(obj);
          } else {
            response.getWriter().println(writer);
          }
        } else {
          serviceResult.transformResult(this, tModelDetails, operationParameters, transformerOutputProperties, response.getWriter());
        }
      } else {
        response.getWriter().write(serviceResult.getCacheString());
      }
    }
  }
}
