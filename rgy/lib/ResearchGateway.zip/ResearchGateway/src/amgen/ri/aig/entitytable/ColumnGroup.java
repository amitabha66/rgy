package amgen.ri.aig.entitytable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.jdom.Element;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;

public class ColumnGroup implements Serializable {
  static final long serialVersionUID = -1781000996631213360L;
  private String header;
  private String align = "center";
  private String index;
  private List<Column> columns;
  private boolean isEntityIDDataIndex;

  public ColumnGroup(String header) {
    this.columns = new ArrayList<Column>();
    this.header = header;
    this.index = UUID.randomUUID().toString();
    this.isEntityIDDataIndex = false;
  }

  public ColumnGroup(Element columnGroupEl, int columnWidth) {
    this(columnGroupEl.getAttributeValue("header"));
    List<Element> columnEls = columnGroupEl.getChildren("Column");
    for (Element columnEl : columnEls) {
      String width = columnEl.getAttributeValue("width");
      if (width != null && width.matches("^[-+]?[0-9]*\\.?[0-9]+(?:[eE][-+]?[0-9]+)?$")) {
        columnWidth = new Double(width).intValue();
      }
      columns.add(new Column(columnEl, columnWidth));
    }
  }

  /**
   * Returns the column group header
   * @return
   */
  public String getHeaderText() {
    return header;
  }

  /**
   * Sets the column group's header
   *
   * @param newColumnHeader String
   */
  public void setHeaderText(String header) {
    this.header = header;
  }
  /**
   * Adds a column to the group and returns it
   * @param column
   * @return 
   */
  public Column addColumn(Column column) {
    columns.add(column);
    return column;
  }
  /**
   * Returns the number of columns
   * @return 
   */
  public int getColumnCount() {
    return columns.size();
  }
  /**
   * Returns a column by its index.
   * @param indx
   * @return 
   */
  public Column getColumn(int indx) {
    return columns.get(indx);
  }
  /**
   * Returns the columns as List
   * @return 
   */
  public List<Column> getColumns() {
    return columns;
  }

  /**
   * Reorders the column according to the provided data index List
   *
   * @param dataIndexes List
   */
  public void updateColumnOrder(List<String> dataIndexes) {
    if (dataIndexes.size() != columns.size()) {
      return;
    }
    List<Column> updatedColumnlist = new ArrayList<Column>();
    for (String dataIndex : dataIndexes) {
      Column updatedColumn = null;
      for (Column column : columns) {
        if (column.getDataIndex().equals(dataIndex)) {
          updatedColumn = column;
          break;
        }
      }
      if (updatedColumn == null) {
        throw new IllegalArgumentException("Unable to find Column " + dataIndex + " " + getHeaderText());
      }
      updatedColumnlist.add(updatedColumn);
    }
    this.columns = updatedColumnlist;
  }
  /**
   * Returns the column group's data index
   * @return 
   */
  public String getDataIndex() {
    return index;
  }

  public JSONObject getJSON() throws JSONException {
    if (header == null && columns.size() > 1) {
      throw new JSONException("Multiple columns require header text");
    }
    if (header == null) {
      header = "&nbsp;";
    }
    JSONObject columnJSON = new JSONObject();
    columnJSON.put("header", header);
    if (header != null && header.length() > 15) {
      columnJSON.put("tooltip", header);
    }
    columnJSON.put("colspan", columns.size());
    columnJSON.put("align", align);
    columnJSON.put("id", index);
    return columnJSON;
  }

  /**
   * Deletes a column
   *
   * @param column Column
   */
  public void deleteColumn(Column column) {
    columns.remove(column);
  }

  /**
   * Returns whether the given object is equal to this one
   * @param obj
   * @return 
   */
  @Override
  public boolean equals(Object obj) {
    if (obj instanceof ColumnGroup) {
      return ((ColumnGroup) obj).index.equals(index);
    }
    return false;
  }

  /**
   * isEntityIDDataIndex
   *
   * @return boolean
   */
  public boolean isEntityIDDataIndex() {
    return isEntityIDDataIndex;
  }

  /**
   * setIsEntityIDDataIndex
   *
   */
  public void setIsEntityIDDataIndex(boolean isEntityIDDataIndex) {
    this.isEntityIDDataIndex = isEntityIDDataIndex;
  }
}
