package amgen.ri.aig.uddi;

import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.item.EntityTableCacheItem;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.entitytable.CellServiceParameter;
import amgen.ri.aig.entitytable.Column;
import amgen.ri.aig.entitytable.DataCell;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.asf.sa.uddi.*;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * Handles drill down service lookups for the Entity Table
 * <p>@version $Id: EntityTableDrillDownServiceLookup.java,v 1.9 2014/09/22 23:39:20 jemcdowe Exp $</p>
 *
 */
public class EntityTableDrillDownServiceLookup extends AbstractDrillDownServiceLookup {
    private EntityTable entityTable;
    EntityListCategory tableType;
    String columnDataIndex;
    int rowIndex;
    Set<CellServiceParameter> cellParameters;


    public EntityTableDrillDownServiceLookup() {
        super();
    }

    public EntityTableDrillDownServiceLookup(HttpServletRequest req, HttpServletResponse resp) {
        super(req, resp);
        String entityTableKey = getParameter("entityTableKey");
        EntityTableCacheItem entityTableCacheItem = ServiceCache.getServiceCache(request).getEntityTableResult(entityTableKey);
        entityTable = entityTableCacheItem.getEntityTable();
        tableType = entityTable.getEntityCategory();
        columnDataIndex = getParameter("columnDataIndex");
        rowIndex = getParameterNumber("pagedRowIndex").intValue();
        Column column = entityTable.getColumnByDataIndex(columnDataIndex);
        DataCell cell = entityTable.getDataRow(entityTable.getEntityID(rowIndex)).getDataCell(entityTable.getColumnIndex(columnDataIndex));
        cellParameters = cell.getCellParameters();

        String drillDownServiceKey = null;
        ServiceDataCategory columnServiceDataCategory = null;
        if (column != null) {
            columnServiceDataCategory = column.getServiceDataCategory();
            drillDownServiceKey = column.getDrillDownServiceKey();
        }
        Map<String, ClassificationSchemeQuery> classificationSchemeQueries = new LinkedHashMap<String, ClassificationSchemeQuery>();
        if (columnServiceDataCategory != null) {
            classificationSchemeQueries.put("s0", new ClassificationSchemeQuery(ClassificationSchemeQuery.AND_ALL_KEYS));
            classificationSchemeQueries.get("s0").addKeyValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, ServiceDataCategory.revertTo(columnServiceDataCategory));

            ServiceDataCategory serviceDataCategory = getEntityClassManager().convertEntityListCategoryToServiceDataCategory(tableType);
            classificationSchemeQueries.put("s1", new ClassificationSchemeQuery(ClassificationSchemeQuery.AND_ALL_KEYS));
            classificationSchemeQueries.get("s1").addKeyValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, ServiceDataCategory.revertTo(serviceDataCategory));
            classificationSchemeQueries.get("s1").addKeyValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, ServiceDataCategory.revertTo(columnServiceDataCategory));
        }
        ServiceDataCategory serviceDataCategory = getEntityClassManager().convertEntityListCategoryToServiceDataCategory(tableType);
        classificationSchemeQueries.put("s2", new ClassificationSchemeQuery(ClassificationSchemeQuery.OR_ALL_KEYS));
        classificationSchemeQueries.get("s2").addKeyValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME,
                ServiceDataCategory.revertTo(serviceDataCategory));

        setCategories(classificationSchemeQueries, drillDownServiceKey);
    }

    /**
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return TBXServlet
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new EntityTableDrillDownServiceLookup(req, resp);
    }

    protected boolean isValidService(ServiceDetails searchService, ClassificationSchemeQuery query) {
        try {
            List<ServiceParameter> parameters = searchService.getParametersNotReady();
            ClassificationSchemeDetails serviceInputClassDetails = getClassificationSchemeDetailsByName(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME);
            if (parameters.isEmpty()) {
                return true;
            }
            for (ServiceParameter parameter : parameters) {
                boolean parameterValid = false;
                List<String> paramKeyValues = parameter.getCategoryKeyValue(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME);
                for (String keyValue : paramKeyValues) {
                    for (String queryKeyValue :
                         query.getClassificationSchemeValues(ClassificationSchemeNames.getName(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME))) {
                        if (serviceInputClassDetails.isa(keyValue, queryKeyValue)) {
                            parameterValid = true;
                        }
                    }
                }
                if (parameter.isCategorizedAs(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME, "Amgen Session Login")) {
                  parameterValid= true;
                }
                if (!parameterValid) {
                    for (CellServiceParameter cellParameter : cellParameters) {
                        for (String classificationSchemeName : cellParameter.getParameterClassificationSchemeNames()) {
                            paramKeyValues = parameter.getCategoryKeyValue(classificationSchemeName);
                            for (String keyValue : paramKeyValues) {
                                for (String cellKeyValue : cellParameter.getParameterCategorizations(classificationSchemeName)) {
                                    if (serviceInputClassDetails.isa(keyValue, cellKeyValue)) {
                                        parameterValid = true;
                                    }
                                }
                            }
                        }
                    }
                }
                if (!parameterValid) {
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public EntityTable getEntityTable() {
        return entityTable;
    }


}
