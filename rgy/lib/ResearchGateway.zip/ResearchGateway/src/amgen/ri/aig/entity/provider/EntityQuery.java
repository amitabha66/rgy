package amgen.ri.aig.entity.provider;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.entity.assay.AssayDetails;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtString;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.jdom.Document;

public class EntityQuery implements EntityDetailsResponseIF {
  private AIGServlet requestor;
  private EntityListCategory entityType;
  private String entityQuery;

  /**
   * Default constructor
   */
  public EntityQuery(AIGServlet requestor) {
    super();
    this.requestor = requestor;
    this.entityQuery = requestor.getParameter("query");
    this.entityType = requestor.getEntityClassManager().convertServiceDataCategoryToEntityListCategory(
            ServiceDataCategory.fromString(requestor.getParameter("type")));
    if (entityType.equals(EntityListCategory.UNKNOWN)) {
      entityType = EntityListCategory.COMPOUNDS;
    }
  }

  public Document getResponseDocument() throws AIGException {
    throw new AIGException("Response type not implemented", Reason.NOT_IMPLEMENTED);
  }

  public JSONObject getResponseJSON() throws AIGException {
    try {
      switch (entityType) {
        case COMPOUNDS:
          throw new AIGException("Response type not implemented", Reason.NOT_IMPLEMENTED);
        case ASSAYS:
          Set<String> onlyResultTypes = null;
          if (requestor.doesParameterExist("only_result_types")) {
            onlyResultTypes = new HashSet();
            String[] onlyResultTypesList = requestor.getParameter("only_result_types").split(",");
            for (String onlyResultType : onlyResultTypesList) {
              if (ExtString.hasTrimmedLength(onlyResultType)) {
                onlyResultTypes.add(onlyResultType.trim());
              }
            }
          }
          Map<String, AssayDetails> assayDetails = AssayDetails.search(requestor, entityQuery, onlyResultTypes);
          JSONObject assayDetailsJObj = new JSONObject();
          JSONArray assayDetailsJArr = new JSONArray();
          assayDetailsJObj.put("results", assayDetailsJArr);
          for (String assayCode : assayDetails.keySet()) {
            if (assayDetailsJArr.length() <= 50) {
              AssayDetails assayDetail = assayDetails.get(assayCode);
              Map assayDetailsMap = assayDetail.getAssayDetails();
              if (((Collection) assayDetailsMap.get("assay_result_types")).size() > 0) {
                assayDetailsJArr.put(new JSONObject(assayDetailsMap));
              }
            }
          }
          if (assayDetails.size() > 50) {
            assayDetailsJObj.put("msg", "More than maximum allowed assays returned.<BR>Displaying only first 50");
          }
          return assayDetailsJObj;
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }
}
