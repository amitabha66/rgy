package amgen.ri.aig.proxy;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.aig.AIGServlet;

public class XMLDataProxy extends DataProxy {
    public XMLDataProxy() {
        super();
    }

    public XMLDataProxy(HttpServletRequest req, HttpServletResponse resp) {
        super(req, resp);
    }

    /**
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return TBXServlet
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new XMLDataProxy(req, resp);
    }

    /**
     *
     * @return String
     */
    protected String getServletMimeType() {
        return "text/xml";
    }

}
