package amgen.ri.aig.log;

import java.io.ObjectStreamException;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;

/**
 * @version $Id: LogRequestType.java,v 1.1 2011/06/17 20:41:26 cvs Exp $
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public enum LogRequestType {
    SESSION, QUERY, NODE_SERVICE, ENTITY_SERVICE, OTHER, DISREGARD;

    public static LogRequestType fromString(String s) {
        if (s == null) {
            return OTHER;
        }
        try {
            s = s.toUpperCase().replaceAll(" ", "_");
            return LogRequestType.valueOf(s);
        } catch (Exception e) {
            return OTHER;
        }
    }

    public static LogRequestType fromRequest(HttpServletRequest request) {
        try {
            URL requestURL = new URL(request.getRequestURL().toString());
            if (requestURL.getFile().equals("/aig/executequeryservice.go")) { //Query Service
                return QUERY;
            } else if (requestURL.getFile().equals("/aig/executeentitynodeservice.go")) { //TreeNode Service
                return NODE_SERVICE;
            } else if (requestURL.getFile().equals("/aig/executeentityservice.go")) { //Entity Service
                return ENTITY_SERVICE;
            } else if (requestURL.getFile().equals("/aig/xmldataproxy.go")) { //Proxy- disregard
                return DISREGARD;
            } else if (requestURL.getFile().equals("/aig/dataproxy.go")) { //Proxy- disregard
                return DISREGARD;
            }
        } catch (Exception e) {}
        return OTHER;
    }

    /**
     * This is necessary to permit Serializable.
     * A Serialized object containing an enum class variable is not de-Serialized properly.
     * This forces de-Serialized enum to be re-created as this enum through the String
     * @return Object
     * @throws ObjectStreamException
     */
    public Object readResolve() throws ObjectStreamException {
        return LogRequestType.fromString(this.toString());
    }

}
