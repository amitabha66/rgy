/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.offline;

import amgen.ri.servlet.ServletBase;
import com.google.common.util.concurrent.SimpleTimeLimiter;
import java.util.concurrent.TimeUnit;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author jemcdowe
 */
@WebServlet(name = "CacheBuilder", urlPatterns = {"/cachebuilder.go", "/cachebuilder"})
public class CacheBuilder extends ServletBase {

  public static final long TIMEOUT_MINS = 20;

  public CacheBuilder() {
  }

  public CacheBuilder(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  @Override
  protected ServletBase getServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new CacheBuilder(req, resp);
  }

  @Override
  protected String getServletMimeType() {
    return "text/plain";
  }

  public void init() {
    super.init();
  }

  public void test() throws Exception {
    performRequest();
  }

  @Override
  protected void performRequest() throws Exception {
    synchronized (this) {
      System.out.println("INIT");
      new SimpleTimeLimiter().callWithTimeout(new CacheBuilderTask(null), TIMEOUT_MINS, TimeUnit.MINUTES, true);
      System.out.println("Im Back!!!");
    }
  }

}
