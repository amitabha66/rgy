package amgen.ri.aig.projectview.filterables;

import org.jdom.Element;
import org.jdom.Namespace;

import amgen.ri.json.JSONObject;

public interface ProjectViewFilterableIF {
    /**
     * getVQTQueryableEl
     *
     * @param uid String
     * @param ns Namespace
     * @return Element
     */
    public Element getVQTQueryableEl(String uid, Namespace ns);

    /**
     * getVQTRetrievableEl
     *
     * @param ns Namespace
     * @return Element
     */
    public Element getVQTRetrievableEl(Namespace ns);

    /**
     * resetFilterable
     */
    public void resetFilterable();

    /**
     * createFilterableJSON
     *
     * @return Object
     */
    public JSONObject createFilterableJSON();

    /**
     * getSort
     *
     * @return String
     */
    public String getSort();

    /**
     * updateFilterable
     *
     * @param filterableJSON JSONObject
     */
    public void updateFilterable(JSONObject filterableJSON);

    /**
     * getName
     *
     * @return String
     */
    public String getName();
    /**
     * getCategory
     *
     * @return String
     */
    public String getCategory();
}
