/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.store;

import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.rdh.Person;
import amgen.ri.aig.sql.RGSQLProvider;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.sql.SQLProvider;
import amgen.ri.util.Debug;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SimplePersonQueryHandler extends StoreRequestHandler {
  public SimplePersonQueryHandler() {
  }

  public SimplePersonQueryHandler(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  @Override
  public JSONObject generateJSONResponse() throws Exception {
    SQLProvider sqlProvider = new RGSQLProvider();
    List<Person> persons = new ArrayList<Person>();
    Connection conn = null;
    try {
      if (doesParameterExist("query", true)) {
        conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC+"");
        String query = getParameter("query").toLowerCase();
        String[] lastFirst = query.split(",");
        if (lastFirst.length == 2 && lastFirst[0].trim().length() > 0 && lastFirst[1].trim().length() > 0) {
          ResultSet rset =
                  OraSQLManager.executeQuery(conn, sqlProvider.getSQLQuery("simple_rdh_person_firstlast_query"),
                  new String[]{"last:" + lastFirst[0].trim() + "%", "first:" + lastFirst[1].trim() + "%"});
          while (rset.next()) {
            persons.add(new Person(rset.getString(1), new OraSQLManager(), null, JDBCNamesType.RG_JDBC+""));
          }
        } else {
          ResultSet rset = OraSQLManager.executeQuery(conn, sqlProvider.getSQLQuery("simple_rdh_person_query"), new String[]{"query:" + query + "%"});
          while (rset.next()) {
            persons.add(new Person(rset.getString(1), new OraSQLManager(), null, JDBCNamesType.RG_JDBC+""));
          }
        }
      } else if (doesParameterExist("username", true)) {
        conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC+"");
        String[] usernames = getParameter("username").toLowerCase().split(",");
        for (String username : usernames) {
          ResultSet rset = OraSQLManager.executeQuery(conn, sqlProvider.getSQLQuery("simple_rdh_person_lookup_bylogin"), new String[]{"amgen_login:" + username});
          while (rset.next()) {
            persons.add(new Person(rset.getString(1), new OraSQLManager(), null, JDBCNamesType.RG_JDBC+""));
          }
          rset.close();
        }
      }
    } finally {
      OraSQLManager.closeResources(conn);
    }
    JSONObject jPersons = new JSONObject();
    if (!persons.isEmpty()) {
      for (Person person : persons) {
        jPersons.append("people", person.getSimplePersonRecord());
      }
    }

    return jPersons;
  }
}
