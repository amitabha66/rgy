package amgen.ri.aig.cache.tree;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.aig.cache.CacheManager;
import amgen.ri.aig.cache.CacheManagerFactory;
import amgen.ri.aig.cache.CacheManagerIF;
import amgen.ri.aig.cache.CacheType;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.entitylist.EntityList;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.util.Debug;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.jdom.Attribute;
import org.jdom.Element;

/**
 * Maintains the treenodes used in the session
 *
 * @version $Id: TreeNodeCache.java,v 1.1 2014/07/08 15:51:47 jemcdowe Exp $
 */
public class TreeNodeCache {
  public static final String TREENODECACHE_SESSIONKEY = "TREENODECACHE_SESSIONKEY";
  public static final String ROOTNODE_UUID = "ROOT";
  private CacheManagerIF cacheMgr;
  private HttpSession session;

  private TreeNodeCache(HttpSession session) throws AIGException {
    super();
    this.session = session;
    cacheMgr = CacheManagerFactory.getCacheManagerInstance(session);
  }

  /**
   * Returns the TreeNodeCache for the session
   *
   * @param request HttpServletRequest
   * @return TreeNodeCache
   */
  public static TreeNodeCache getTreeNodeCache(HttpServletRequest request) throws AIGException {
    return getTreeNodeCache(request.getSession(true));
  }

  /**
   * Returns the TreeNodeCache for the session
   *
   * @param request HttpServletRequest
   * @return TreeNodeCache
   */
  public static TreeNodeCache getTreeNodeCache(HttpSession session) throws AIGException {
    if (session.getAttribute(TREENODECACHE_SESSIONKEY) == null) {
      session.setAttribute(TREENODECACHE_SESSIONKEY, new TreeNodeCache(session));
    }
    return (TreeNodeCache) session.getAttribute(TREENODECACHE_SESSIONKEY);
  }

  /**
   * Adds a TREENODE to the cache. It must have a UUID attribute
   *
   * @param request HttpServletRequest
   * @param treeNode Element
   */
  public void addTreeNode(Element treeNode) throws AIGException {
    String uuid;
    if (treeNode == null || (uuid = treeNode.getAttributeValue("UUID")) == null) {
      Debug.print("WARNING: Invalid treenode.");
      return;
    }
    Element element = new Element(treeNode.getName());
    List<Attribute> attributes = treeNode.getAttributes();
    for (Attribute attribute : attributes) {
      element.setAttribute(attribute.getName(), attribute.getValue());
    }
    NodeType nodeType = NodeType.getNodeType(treeNode);
    cacheMgr.put(CacheType.NODE, uuid, element);

    String parentNodeUUID = treeNode.getAttributeValue("PARENTUUID");
    if (parentNodeUUID == null && nodeType.equals(NodeType.RESULTNODE)) {
      parentNodeUUID = ROOTNODE_UUID;
    }
    if (parentNodeUUID != null) {
      List<String> treeNodeChildren;
      if (cacheMgr.contains(CacheType.NODECHILDREN, parentNodeUUID)) {
        treeNodeChildren = (List) cacheMgr.get(CacheType.NODECHILDREN, parentNodeUUID);
      } else {
        treeNodeChildren = new ArrayList<String>();
      }
      treeNodeChildren.add(uuid);
      cacheMgr.put(CacheType.NODECHILDREN, parentNodeUUID, treeNodeChildren);
      cacheMgr.remove(CacheType.NODESORT, parentNodeUUID);
    }
  }

  /**
   * Renames a TREENODE in the cache.
   * 
   * Returns the update TREENODE from the cache
   */
  public Element renameTreeNode(Element treeNode, String name) throws AIGException {
    String uuid;
    if (treeNode == null || (uuid = treeNode.getAttributeValue("UUID")) == null) {
      Debug.print("WARNING: Invalid treenode.");
      return null;
    }
    return renameTreeNode(uuid, name);
  }

  /**
   * Renames a TREENODE in the cache.
   * 
   * Returns the update TREENODE from the cache
   */
  public Element renameTreeNode(String uuid, String name) throws AIGException {
    Element cachedTreeNode = getTreeNode(uuid);
    if (cachedTreeNode == null) {
      Debug.print("WARNING: Unknown treenode.");
      return null;
    }
    cachedTreeNode.setAttribute("TEXT", name);
    cacheMgr.put(CacheType.NODE, uuid, cachedTreeNode);
    return cachedTreeNode;
  }

  /**
   * Sets the node sort for the children of this node
   *
   * @param uuid String
   * @param childrenSortIndex int[]
   * @throws AIGException
   */
  public void setTreeNodeChildrenSortIndex(String uuid, int[] childrenSortIndex) throws AIGException {
    cacheMgr.put(CacheType.NODESORT, uuid, childrenSortIndex);
  }

  /**
   * Gets the node sort for the children of this node
   *
   * @param uuid String
   * @return int[]
   */
  public int[] getTreeNodeChildrenSortIndex(String uuid) {
    return (int[]) cacheMgr.get(CacheType.NODESORT, uuid);
  }

  /**
   * Sets the node filter for the children of this node
   *
   * @param uuid String
   * @param treeNodeFilter TreeNodeFilter
   * @throws AIGException
   */
  public void setTreeNodeFilter(String uuid, TreeNodeFilter treeNodeFilter) throws AIGException {
    cacheMgr.put(CacheType.NODEFILTER, uuid, treeNodeFilter);
  }

  /**
   * Gets the node filter for the children of this node
   *
   * @param uuid String
   * @return TreeNodeFilter
   */
  public TreeNodeFilter getTreeNodeFilter(String uuid) {
    return (TreeNodeFilter) cacheMgr.get(CacheType.NODEFILTER, uuid);
  }

  /**
   * Gets a TREENODE from the cache using its UUID
   *
   * @param uuid String
   * @return Element
   */
  public Element getTreeNode(String uuid) {
    return (Element) cacheMgr.get(CacheType.NODE, uuid);
  }

  /**
   * Gets a TREENODE from the cache using its UUID as a TreeNode object
   *
   * @param uuid TreeNode
   * @return Element
   */
  public TreeNode getTreeNodeObj(String uuid) {
    Element treeNode = (Element) cacheMgr.get(CacheType.NODE, uuid);
    return (treeNode == null ? null : new TreeNode(treeNode));
  }

  /**
   * Accumumates a List of UUID keys for child treenodes.
   *
   * @param uuid String
   */
  public List<String> getChildTreeNodeKeys(String parentUUID) {
    if (parentUUID == null) {
      return new ArrayList<String>();
    }
    List<String> treeNodeChildren = (List) cacheMgr.get(CacheType.NODECHILDREN, parentUUID);
    if (treeNodeChildren == null) {
      return new ArrayList<String>();
    }
    return treeNodeChildren;
  }

  /**
   * Accumumates a List of UUID keys for child treenodes of the ROOT.
   *
   * @return List
   */
  public List<String> getRootChildTreeNodeKeys() {
    return getChildTreeNodeKeys(ROOTNODE_UUID);
  }

  /**
   * Accumumates a List of UUID keys for child treenodes of the ROOT.
   *
   * @return List
   */
   // @fixme EntityClassManager
  
  public List<String> getRootChildTreeNodeKeys(EntityListCategory category) {
    List<String> rootChildTreeNodeKeys = getRootChildTreeNodeKeys();
    if (category == null) {
      return rootChildTreeNodeKeys;
    }
    EntityClassManager entityClassManager= new EntityClassManager();

    List<String> categoryNodeKeys = new ArrayList<String>();
    if (rootChildTreeNodeKeys != null) {
      for (String rootChildTreeNodeKey : rootChildTreeNodeKeys) {
        Element node = getTreeNode(rootChildTreeNodeKey);
        EntityListCategory nodeCategory = entityClassManager.convertServiceDataCategoryToEntityListCategory(ServiceDataCategory.getServiceDataCategory(node));
        if (nodeCategory.equals(category)) {
          categoryNodeKeys.add(rootChildTreeNodeKey);
        }
      }
    }
    return categoryNodeKeys;
  }

  /**
   * Removes a node and all its childen from the cache
   *
   * @param uuid String
   */
  public int removeTreeNode(String uuid) {
    if (uuid == null) {
      return 0;
    }
    List<String> removeUUIDs = getAllDescendantChildTreeNodeKeys(uuid, new ArrayList<String>());
    removeUUIDs.add(uuid);
    for (String removeUUID : removeUUIDs) {
      Element targetNode = getTreeNode(removeUUID);
      cacheMgr.remove(CacheType.NODE, removeUUID);
    }
    return removeUUIDs.size();
  }

  /**
   * Gets the parent TREENODE from the cache using a child's UUID
   *
   * @param uuid String
   * @return Element
   */
  public Element getParentTreeNode(String uuid) {
    return getParentTreeNode(getTreeNode(uuid));
  }

  /**
   * Gets the parent TREENODE from the cache using a child's UUID
   *
   * @param uuid String
   * @return Element
   */
  public Element getParentTreeNode(Element node) {
    String parentUUID = node.getAttributeValue("PARENTUUID");
    if (parentUUID == null) {
      return null;
    }
    return getTreeNode(parentUUID);
  }

  /**
   * Gets the parent TREENODE from the cache using a child's UUID
   *
   */
  public TreeNode getParentTreeNode(TreeNode treeNode) {
    Element parentNode = getParentTreeNode(treeNode.getNode());
    if (parentNode == null) {
      return null;
    }
    return new TreeNode(parentNode);
  }

  /**
   * Gets the parent TREENODE from the cache using a child's UUID
   *
   * @param uuid String
   * @return Element
   */
  public TreeNode getServiceResultParentTreeNode(TreeNode treeNode) {
    if (treeNode.isNodeType(NodeType.RESULTNODE) || treeNode.isNodeType(NodeType.SERVICENODE)) {
      return treeNode;
    }
    TreeNode parentTreeNode = getParentTreeNode(treeNode);
    if (parentTreeNode == null) {
      return null;
    }
    return getServiceResultParentTreeNode(parentTreeNode);
  }

  /**
   * Gets a List of TREENODE from the cache using it a list of UUIDs
   *
   * @param request HttpServletRequest
   * @param
   * @param List Element
   */
  public List<Element> getTreeNodes(List<String> uuids) {
    List<Element> treeNodes = new ArrayList<Element>();
    for (String uuid : uuids) {
      Element treeNode = getTreeNode(uuid);
      if (treeNode != null) {
        treeNodes.add(treeNode);
      }
    }
    return treeNodes;
  }

  /**
   * Gets a List of TREENODE from the cache using it a list of UUIDs
   *
   * @param request HttpServletRequest
   * @param
   * @param List Element
   */
  public List<Element> getTreeNodes(String[] uuids) {
    List<Element> treeNodes = new ArrayList<Element>();
    for (String uuid : uuids) {
      Element treeNode = getTreeNode(uuid);
      if (treeNode != null) {
        treeNodes.add(treeNode);
      }
    }
    return treeNodes;
  }

  /**
   * Returns the lineage (list of parent entity data) for the given node (uuid)
   *
   * @param treeNode HttpServletRequest
   * @return List
   */
  public List<EntityLineage> getEntityLineage(Element treeNode) {
    return getEntityLineage(treeNode.getAttributeValue("UUID"));
  }

  /**
   * Returns the lineage (list of parent entity data) for the given node (uuid)
   *
   * @param request HttpServletRequest
   * @param uuid String
   * @return List
   */
  public List<EntityLineage> getEntityLineage(String uuid) {
    List<EntityLineage> lineageElements = new ArrayList<EntityLineage>();
    Element baseElement = getTreeNode(uuid);
    if (baseElement != null) {
      Element parentElement = baseElement;
      if (NodeType.isNodeType(parentElement, NodeType.ENTITYNODE)) {
        EntityLineage entityLineage = EntityLineage.getEntityLineageForTreeNode(parentElement);
        lineageElements.add(entityLineage);
      }
      while ((parentElement = getTreeNode(parentElement.getAttributeValue("PARENTUUID"))) != null) {
        if (NodeType.isNodeType(parentElement, NodeType.ENTITYNODE)) {
          EntityLineage entityLineage = EntityLineage.getEntityLineageForTreeNode(parentElement);
          lineageElements.add(entityLineage);
        }
      }
    }
    return lineageElements;
  }

  /**
   * Returns the child lineage for a parent node
   *
   * @param parentUUID String
   * @return List
   */
  public List<EntityLineage> getEntityLineageForChildNodes(String parentUUID) {
    List<EntityLineage> lineageObjs = new ArrayList<EntityLineage>();
    Element parentElement = getTreeNode(parentUUID);
    if (parentElement != null) {
      List<String> childUUIDs = getChildTreeNodeKeys(parentUUID);
      for (String childUUID : childUUIDs) {
        Element childElement = getTreeNode(childUUID);
        EntityLineage lineageObj = EntityLineage.getEntityLineageForTreeNode(childElement);
        if (lineageObj != null) {
          lineageObjs.add(lineageObj);
        }
      }
    }
    return lineageObjs;
  }

  /**
   * Accumumates a List of UUIDs for child treenodes.
   *
   * @param uuid String
   */
  public List<String> getChildTreeNodeKeys(Element parent) {
    return getChildTreeNodeKeys(parent.getAttributeValue("UUID"));
  }

  /**
   * Accumumates a List of UUIDs for all child treenodes of a parent including
   * grandchildren in the List provided.
   *
   * @param uuid String
   * @param uuidList List
   * @return List
   */
  private List<String> getAllDescendantChildTreeNodeKeys(String uuid, List<String> uuidList) {
    Element targetNode = getTreeNode(uuid);
    if (targetNode == null) {
      return uuidList;
    }
    List<String> childKeys = getChildTreeNodeKeys(uuid);
    uuidList.addAll(childKeys);
    for (String childKey : childKeys) {
      getAllDescendantChildTreeNodeKeys(childKey, uuidList);
    }
    return uuidList;
  }

  /**
   * Returns the given entity node's parent service key. This will be from
   * either the node's result or service node. null if not found or the given
   * node is not an entity node.
   *
   * @param uuid String
   * @return String
   */
  public String getEntityNodeParentServiceKey(String uuid) {
    Element node = getTreeNode(uuid);
    if (node == null) {
      return null;
    }
    switch (NodeType.getNodeType(node)) {
      case ENTITYNODE:
        Element sourceNode = null;
        Element parentNode = getParentTreeNode(uuid);
        while (parentNode != null) {
          NodeType parentNodeType = NodeType.getNodeType(parentNode);
          if (parentNodeType.equals(NodeType.RESULTNODE) || parentNodeType.equals(NodeType.SERVICENODE)) {
            ServiceResultCacheItem serviceResultCacheItem = ServiceCache.getServiceCache(session).getServiceResult(parentNode.getAttributeValue("UUID"));
            if (serviceResultCacheItem == null || serviceResultCacheItem.getServiceDetails() == null) {
              return null;
            }
            return serviceResultCacheItem.getServiceDetails().getKey();
          }
          parentNode = getParentTreeNode(parentNode);
        }
        break;
      case SERVICENODE:
      case RESULTNODE:
      default:
        return null;
    }
    return null;
  }

  /**
   * Creates a temporary compound list from a result node returning the list id.
   *
   * @param resultNodeKey String
   * @param requestor AIGServlet
   * @return int
   */
  public int createCompoundListFromResultNode(String resultNodeKey, AIGBase requestor) throws ServletException, AIGException {
    TreeNode resultNode = new TreeNode(getTreeNode(resultNodeKey));
    List<String> entityChildNodeKeys = getChildTreeNodeKeys(resultNodeKey);
    String text = resultNode.getText() + " [" + entityChildNodeKeys.size() + "]";

    EntityList resultNodeEntityList = new EntityList(text, text, resultNode, requestor.getHttpServletRequest(), new OraSQLManager(),
            JDBCNamesType.RG_JDBC+"");
    resultNodeEntityList.setList_type("COMPOUNDS-SESSION");
    if (resultNodeEntityList.isEmpty()) {
      return -1;
    }
    if (resultNodeEntityList.performCommitAll(requestor.getSessionLogin().getRemoteUser()) == 0) {
      return -1;
    }

    return Integer.valueOf(resultNodeEntityList.getIdentifier());
  }
}


