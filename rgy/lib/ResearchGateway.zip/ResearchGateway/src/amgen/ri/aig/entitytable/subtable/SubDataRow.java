package amgen.ri.aig.entitytable.subtable;

import java.util.List;
import java.util.UUID;

import amgen.ri.aig.entitytable.Column;
import amgen.ri.aig.entitytable.DataCell;
import amgen.ri.aig.entitytable.DataRow;
import amgen.ri.aig.entitytable.EntityTableCellFormatterIF;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;

/**
 *
 * Class for encapsulating the data row for a Subtable
 *
 * @version $Id: SubDataRow.java,v 1.1 2011/06/17 20:41:26 cvs Exp $
 *
 */
public class SubDataRow extends DataRow {
    static final long serialVersionUID = -3158929856178546618L;

    public SubDataRow() {
        this(UUID.randomUUID().toString());
    }

    public SubDataRow(String rowID) {
        super(rowID);
    }

    public String getRowID() {
        return getEntityID();
    }

    public void setRowID(String rowID) {
        setEntityID(rowID);
    }

    public JSONObject getJSON(JSONArray fieldJArr, EntityTableCellFormatterIF formatter, List<Column> columns) throws JSONException {
        JSONObject cellsJSON = new JSONObject();
        List<DataCell> dataCells = getDataCells();
        if (fieldJArr.length() != dataCells.size()) {
            throw new JSONException("Invalid field length- " + fieldJArr.length() + " fields " + dataCells.size() + " cells");
        }
        for (int i = 0; i < dataCells.size(); i++) {
            Column column = columns.get(i);
            cellsJSON.put(fieldJArr.getString(i), dataCells.get(i).getJSONValue(formatter, column));
        }
        return cellsJSON;
    }

}
