/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.store;

import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.css.CSSImageRetriever;
import amgen.ri.aig.documents.SavedDocument;
import amgen.ri.aig.loft.AppSelectorManager;
import amgen.ri.aig.loft.RGApp;
import amgen.ri.aig.loft.RGLoftManager;
import amgen.ri.aig.preferences.*;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtImage;
import amgen.ri.util.ExtString;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author jemcdowe
 */
public class RGLoftHandler extends StoreRequestHandler implements PreferenceableIF {
  public enum RGLoftRequestType {
    OWNERAPPS, ADDAPP, REMOVEAPP, RESETAPPS, APPROLES, QUICKAPPS, SAVEQUICKAPPS, UPDATESORT, PREFERENCES, UPDATEPREFERENCES, BACKGROUNDIMG, APPSELECTOR,
    OWNERPAGES, ADDPAGE, RENAMEPAGE, SETDEFAULTPAGE, REMOVEPAGE, TAGPAGE, UNTAGPAGE;

    public static RGLoftRequestType fromString(String s) {
      try {
        return RGLoftRequestType.valueOf(s.toUpperCase());
      } catch (Exception e) {
        return OWNERAPPS;
      }
    }
  };
  protected RGLoftRequestType requestType;
  private String backgroundColor;
  private BufferedImage backgroundImage;
  private String backgroundImagePosition;

  public RGLoftHandler() {
  }

  public RGLoftHandler(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
    requestType = RGLoftRequestType.fromString(getParameter("loftrx"));
    if (requestType.equals(RGLoftRequestType.BACKGROUNDIMG)) {
      responseType = ResponseFormatType.RAW;
    }
  }

  @Override
  protected String getServletMimeType() {
    if (requestType.equals(RGLoftRequestType.BACKGROUNDIMG)) {
      return "image/png";
    }
    return super.getServletMimeType();
  }

  @Override
  public String getPreferenceGroup() {
    return "Launch Pad";
  }

  @Override
  public void setPreference(PreferenceIF preference) {
    if (preference.getPreferenceName().equals("Background Color")) {
      backgroundColor = (String) preference.getPreferenceValue();
    } else if (preference.getPreferenceName().equals("Background Image Position")) {
      backgroundImagePosition = (String) preference.getPreferenceValue();
    } else if (preference.getPreferenceName().equals("Background Image")) {
      if (ExtString.hasLength((String) preference.getPreferenceValue())) {
        Set<String> globalBKImageSelectors = CSSImageRetriever.getInstance().getSelectors("RG.BKImages.css");
        if (globalBKImageSelectors.contains((String) preference.getPreferenceValue())) {
          backgroundImage = CSSImageRetriever.getInstance().getImageForRule((String) preference.getPreferenceValue());
        } else {
          try {
            SavedDocument document = new SavedDocument((String) preference.getPreferenceValue(), new OraSQLManager(), null, JDBCNamesType.RGDOCS_JDBC + "");
            if (document.setData()) {
              backgroundImage = ImageIO.read(document.getFileContents().getBlobStream());
            }
          } catch (Exception e) {
            e.printStackTrace();
          }
        }
      }
    }
  }

  @Override
  public JSONObject generateJSONResponse() throws Exception {
    switch (requestType) {
      case PREFERENCES:
        JSONObject jPrefs = getLoftPreferences();
        return jPrefs;
      case UPDATEPREFERENCES:
        if (doesParameterExist("color", true)) {
          PreferenceIF preference = new PreferenceManager(this, this).getPreference("Background Color");
          if (preference != null && preference instanceof RGPreference) {
            UserPreference userPreference = ((RGPreference) preference).updateUserPreference(getParameter("color"));
            userPreference.performCommit();
          }
        }
        return new JSONObject();
      case UPDATESORT:
        JSONObject jSort = getJSONObjectParameter("sort");
        if (jSort != null) {
          Map<String, Integer> updatedSort = new HashMap<String, Integer>();
          for (Object appId : jSort.asMap().keySet()) {
            try {
              updatedSort.put(appId.toString(), new Integer(jSort.getString(appId.toString())));
            } catch (Exception e) {
              e.printStackTrace();
            }
          }
          new RGLoftManager(this).updateSort(updatedSort);
        }
        return new JSONObject();
      case QUICKAPPS:
        return createResponseJSON("apps", new RGLoftManager(this).getUserQuickAppRecords());
      case SAVEQUICKAPPS:
        return createResponseJSON("apps", new RGLoftManager(this).saveUserQuickAppRecords(getJSONObjectParameter("quickApps")));
      case ADDAPP:
        return new RGLoftManager(this).addApp();
      case REMOVEAPP:
        return new RGLoftManager(this).removeApp();
      case RESETAPPS:
        return createResponseJSON("apps", new RGLoftManager(this).resetAppsToDefaults(getParameter("role", "BASIC")));
      case APPROLES:
        return new RGLoftManager(this).getAppsRoles();
      case OWNERPAGES:
        return new RGLoftManager(this).getLoftPages();
      case ADDPAGE:
        return new RGLoftManager(this).createLoftPage(getParameter("name"), getParameters("appIDs", ","));
      case RENAMEPAGE:
        return new RGLoftManager(this).renameLoftPage(getParameterNumber("pageID", -1).intValue(), getParameter("name"));
      case REMOVEPAGE:
        return new RGLoftManager(this).removeLoftPage(getParameterNumber("pageID", -1).intValue());
      case SETDEFAULTPAGE:
        return new RGLoftManager(this).setDefaultLoftPage(getParameterNumber("pageID", -1).intValue(), doesParameterEqual("setDefaultView", 1));
      case TAGPAGE:
        return new RGLoftManager(this).tagAppWithPage(getParameterNumber("appID", -1).intValue(), getParameterNumber("pageID", -1).intValue());
      case UNTAGPAGE:
        return new RGLoftManager(this).untagAppWithPage(getParameterNumber("appID", -1).intValue(), getParameterNumber("pageID", -1).intValue());
      case APPSELECTOR:
        return new AppSelectorManager(this).getResponse();
      default:
        return createResponseJSON("apps", new RGLoftManager(this).getUserAppRecords());
    }
  }

  @Override
  public void writeRawResponse() throws Exception {
    new PreferenceManager(this, this).setPreferences();
    if (requestType.equals(RGLoftRequestType.BACKGROUNDIMG)) {
      if (backgroundImage != null) {
        try {
          BufferedImage scaledBackgroundImage = backgroundImage;
          double origWidth = backgroundImage.getWidth();
          double origHeight = backgroundImage.getHeight();

          double scaleWidth = getParameterNumber("width", 0).intValue();
          double scaleHeight = getParameterNumber("height", 0).intValue();

          if (!ExtString.hasLength(backgroundImagePosition)
                  || ExtString.equalsIgnoreCase(backgroundImagePosition, "center")
                  || ExtString.equalsIgnoreCase(backgroundImagePosition, "tile")
                  || scaleWidth <= 0
                  || scaleHeight <= 0) {
            ImageIO.write(backgroundImage, "PNG", response.getOutputStream());
            return;
          }

          if (ExtString.equalsIgnoreCase(backgroundImagePosition, "stretch")) {
            scaledBackgroundImage = ExtImage.resize(backgroundImage, (int) Math.rint(scaleWidth), (int) Math.rint(scaleHeight));
            ImageIO.write(scaledBackgroundImage, "PNG", response.getOutputStream());
            return;
          }
          if (origWidth < origHeight) {
            scaledBackgroundImage = ExtImage.fillX(backgroundImage, (int) Math.rint(scaleWidth), (int) Math.rint(scaleHeight), 0);
            ImageIO.write(scaledBackgroundImage, "PNG", response.getOutputStream());
          } else {
            scaledBackgroundImage = ExtImage.fillY(backgroundImage, (int) Math.rint(scaleWidth), (int) Math.rint(scaleHeight), 0);
            ImageIO.write(scaledBackgroundImage, "PNG", response.getOutputStream());
          }
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
    }
  }

  private JSONObject getLoftPreferences() throws Exception {
    new PreferenceManager(this, this).setPreferences();
    JSONObject jPreferences = new JSONObject();
    jPreferences.put("backgroundColor", backgroundColor);

    if (backgroundImage != null) {
      jPreferences.put("tileImage", ExtString.equalsIgnoreCase(backgroundImagePosition, "tile"));
      jPreferences.put("backgroundImage", "/aig/store.go?request=RGAPPS&loftrx=BACKGROUNDIMG");
    }
    return jPreferences;
  }

  private String getAppName(RGApp app) {
    return "Test";
  }
}
