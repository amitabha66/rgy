package amgen.ri.aig.cache.service;

import amgen.ri.aig.cache.service.AbstractServiceCache;
import amgen.ri.aig.cache.tree.TreeNodeCache;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.jdom.Document;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.item.AbstractCacheItem;
import amgen.ri.aig.cache.item.CacheItemIF;
import amgen.ri.aig.cache.item.EntityTableCacheItem;
import amgen.ri.aig.cache.json.JSONCacheItem;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.aig.cache.item.ServiceResultRawCacheItem;
import amgen.ri.aig.cache.CacheType;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.uddi.ServiceQuery;
import amgen.ri.asf.sa.uddi.BindingDetails;
import amgen.ri.asf.sa.uddi.ClassificationSchemeQuery;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.TModelDetails;
import amgen.ri.asf.sa.uddi.UDDIQuery;
import com.google.common.collect.Iterators;
import java.util.*;
import javax.naming.ServiceUnavailableException;
import org.apache.commons.lang.StringUtils;

/**
 * Caches service and service queries in the HttpServletRequest session
 *
 * @version $id$
 */
public class ServiceCache extends AbstractServiceCache {

  /**
   * Returns the ServiceCache for the session
   *
   * @param request HttpServletRequest
   * @return ServiceCache
   */
  public static ServiceCache getServiceCache(HttpServletRequest request) {
    return getServiceCache(request.getSession(false));
  }

  /**
   * Returns the ServiceCache for the session
   *
   * @param request HttpServletRequest
   * @return ServiceCache
   */
  public static ServiceCache getServiceCache(HttpSession session) {
    if (session.getAttribute(SERVICECACHE_SESSIONKEY) == null) {
      try {
        session.setAttribute(SERVICECACHE_SESSIONKEY, new ServiceCache(session));
      } catch (AIGException ex) {
        ex.printStackTrace();
      }
    }
    return (ServiceCache) session.getAttribute(SERVICECACHE_SESSIONKEY);
  }

  /**
   * Returns the ServiceCache for the session
   *
   * @param requestor AIGBase
   * @return ServiceCache
   */
  public static ServiceCache getServiceCache(AIGBase requestor) {
    return getServiceCache(requestor.getHttpServletRequest());
  }

  /**
   * Private constructor use the getServiceCache for singleton access
   */
  private ServiceCache(HttpSession session) throws AIGException {
    super(session);
  }

  /**
   * Returns whether the given service is active
   *
   * @param serviceDetails
   */
  public boolean verifyServiceActive(ServiceDetails serviceDetails) {
    return (serviceDetails == null ? false : verifyServiceActive(serviceDetails.getKey()));
  }

  /**
   * Returns whether the given service identified by its key is active
   *
   * @param serviceDetails
   */
  public boolean verifyServiceActive(String serviceKey) {
    try {
      ServiceDetails service = null;
      if (isServiceOffline(serviceKey)) {
        service = processService(new ServiceDetails(super.getUDDIQuery().getUddiDetails(), serviceKey, true, false));
      } else {
        service = getService(serviceKey);
      }
      boolean statusOK = (service.getStatus(true, SERVICECONNECTION_TIMEOUTMILLIS) == ServiceDetails.STATUS_OK);
      setServiceOffline(serviceKey, !statusOK);
      return statusOK;
    } catch (Exception ex) {
      setServiceOffline(serviceKey, true);
      return false;
    }
  }

  /**
   * Returns the ServiceDetails for the given key- either from cache or by
   * querying the UDDI.
   *
   * Note: This actually returns a copy of the cached ServiceDetails object to
   * avoid any corruption
   *
   * @param serviceKey String
   * @return ServiceDetails
   * @throws amgen.ri.aig.AIGException
   */
  public ServiceDetails getService(String serviceKey) throws AIGException {
    if (isServiceOffline(serviceKey)) {
      throw new AIGException(String.format("Service (%s) is offline", serviceKey), AIGException.Reason.SERVICE_OFFLINE);
    }
    return getService(serviceKey, true, true);
  }

  /**
   * Returns the ServiceDetails for the given key- either from cache or by
   * querying the UDDI and optionally verifying that the service is valid and
   * active .
   *
   * Note: This actually returns a copy of the cached ServiceDetails object to
   * avoid any corruption
   *
   * @param serviceKey String
   * @param verifyService
   * @param setParameters
   * @return ServiceDetails
   * @throws amgen.ri.aig.AIGException
   */
  public ServiceDetails getService(String serviceKey, boolean verifyService, boolean setParameters) throws AIGException {
    if (isServiceOffline(serviceKey)) {
      throw new AIGException(String.format("Service (%s) is offline", serviceKey), AIGException.Reason.SERVICE_OFFLINE);
    }
    try {
      if (serviceKey == null) {
        return null;
      }
      ServiceDetails service = getServiceFromCache(serviceKey, setParameters);
      
      if (verifyService) {
        switch (service.getStatus(false, SERVICECONNECTION_TIMEOUTMILLIS)) {
          case ServiceDetails.STATUS_INVALID:
            throw new ServiceUnavailableException("Service not valid");
          case ServiceDetails.STATUS_INACTIVE:
            throw new ServiceUnavailableException("Service inactive");
        }
      }
      return service;     
    } catch (ServiceUnavailableException e) {
      setServiceOffline(serviceKey, true);
      throw new AIGException(e.getMessage(), AIGException.Reason.SERVICE_OFFLINE);
    } catch (AIGException e) {
      throw e;
    } catch (Exception e) {
      //e.printStackTrace();
      throw new AIGException(AIGException.Reason.UNABLE_TO_RETRIEVE_ENTRY, e);
    }
  }
  


  /**
   * getTModelDetailsByName
   *
   * @param tModelName String
   * @return TModelDetails
   */
  public TModelDetails getTModelDetailsByName(String tModelName) throws AIGException {
    try {
      return TModelDetails.getTModelDetailsByName(getUDDIQuery().getUddiDetails(), tModelName);
    } catch (Exception e) {
      throw new AIGException(AIGException.Reason.UNABLE_TO_RETRIEVE_ENTRY, e);
    }
  }

  /**
   * Returns the TModelDetails for the given key- either from cache or by
   * quering the UDDI.
   *
   * @param tModelKey String
   * @return TModelDetails
   */
  public TModelDetails getTModelDetails(String tModelKey) throws AIGException {
    try {
      if (tModelKey == null) {
        return null;
      }
      TModelDetails tModel = getTModelDetailsFromCache(tModelKey);
      return tModel;
    } catch (Exception e) {
      throw new AIGException(AIGException.Reason.UNABLE_TO_RETRIEVE_ENTRY, e);
    }
  }

  /**
   * Returns the BindingDetails for the given key- either from cache or by
   * querying the UDDI.
   *
   * @param bindingKey String
   * @return BindingDetails
   */
  public BindingDetails getBindingDetails(String bindingKey) throws AIGException {
    try {
      if (bindingKey == null) {
        return null;
      }
      BindingDetails binding = getBindingDetailsFromCache(bindingKey);
      return binding;
    } catch (AIGException e) {
      throw e;
    } catch (Exception e) {
      throw new AIGException(AIGException.Reason.UNABLE_TO_RETRIEVE_ENTRY, e);
    }
  }

  /**
   * Returns the List of service keys for the given ClassificationSchemeQuery
   * either from cache or from a UDDI query. A single service may return more
   * than one result type, but will appear only once.
   *
   * @param serviceQuery ClassificationSchemeQuery
   * @param inputTypeAcceptsList
   * @param resultTypes
   * @return List
   * @throws amgen.ri.aig.AIGException
   */
  public ServiceKeyCacheResponse getServiceKeys(ServiceQuery serviceQuery) throws AIGException {
    try {
      return getServiceKeysByQueryFromCache(serviceQuery);
    } catch (Exception e) {
      throw new AIGException(AIGException.Reason.UNABLE_TO_RETRIEVE_ENTRY, e);
    }
  }


  /**
   * Saves the service results in the cache for the given result key. Returns
   * the saved ServiceResultCacheItem
   *
   * @param resultKey String
   * @param serviceResultCacheItem ServiceResultCacheItem
   * @throws AIGException
   * @return ServiceResultCacheItem
   */
  public ServiceResultCacheItem saveServiceResult(ServiceResultCacheItem serviceResultCacheItem) throws AIGException {
    return (ServiceResultCacheItem) getLocalCacheMgr().put(CacheType.SERVICERESULT, serviceResultCacheItem.getResultKey(), serviceResultCacheItem);
  }

  /**
   * Saves the JSON cache item in the cache. Returns the saved JSONCacheItem
   */
  public JSONCacheItem saveJSONCacheItem(JSONCacheItem jsonCacheItem) throws AIGException {
    return (JSONCacheItem) getLocalCacheMgr().put(CacheType.JSON, jsonCacheItem.getKey(), jsonCacheItem);
  }

  /**
   * Returns the service results saved in the cache for the given result key.
   * null if none exists
   *
   * @param resultKey String
   */
  public ServiceResultCacheItem getServiceResult(String resultKey) {
    if (resultKey == null) {
      return null;
    }
    return (ServiceResultCacheItem) getLocalCacheMgr().get(CacheType.SERVICERESULT, resultKey);
  }

  /**
   * Returns the JSONCacheItem for the given key. null if none exists
   *
   * @param resultKey String
   */
  public JSONCacheItem getJSONCacheItem(String cacheKey) {
    if (cacheKey == null) {
      return null;
    }
    return (JSONCacheItem) getLocalCacheMgr().get(CacheType.JSON, cacheKey);
  }

  /**
   * Removes the JSONCacheItem for the given key.
   *
   * @param resultKey String
   */
  public void clearJSONCacheItem(String cacheKey) {
    if (cacheKey == null) {
      return;
    }
    getLocalCacheMgr().remove(CacheType.JSON, cacheKey);
  }

  /**
   * Returns a related service result saved in the cache for the given a result
   * key and a ResultRelationshipType. null if none exists
   *
   * @param resultKey String
   * @param relationship AbstractCacheItem.ResultRelationshipType
   */
  public CacheItemIF getRelatedServiceResult(String resultKey, AbstractCacheItem.ResultRelationshipType relationship) {
    ServiceResultCacheItem serviceResultCacheItem = getServiceResult(resultKey);
    if (serviceResultCacheItem == null) {
      return null;
    }
    String key = serviceResultCacheItem.getRelatedResultKey(relationship);
    if (StringUtils.isEmpty(key)) {
      return null;
    }
    switch (relationship) {
      case SOURCE_TREENODES:
        try {
          return TreeNodeCache.getTreeNodeCache(getSession()).getTreeNodeObj(key);
        } catch (AIGException ex) {
          return null;
        }
      case SOURCE_TABLE:
        return getEntityTableResult(key);
      default:
        return getServiceResult(key);
    }
  }

  /**
   * Saves an EntityTable cache item for the given result key. If resultKey is
   * null, one is generated. Returns the saved EntityTableCacheItem
   *
   * @param resultKey String
   * @param entityTableCacheItem EntityTableCacheItem
   * @throws AIGException
   * @return EntityTableCacheItem
   */
  public EntityTableCacheItem saveEntityTableResult(EntityTableCacheItem entityTableCacheItem) throws AIGException {
    return (EntityTableCacheItem) getLocalCacheMgr().put(CacheType.ENTITYTABLE, entityTableCacheItem.getKey(), entityTableCacheItem);
  }

  /**
   * Returns the EntityTable cache item for the given result key. null if none
   * exists
   *
   * @param resultKey String
   */
  public EntityTableCacheItem getEntityTableResult(String resultKey) {
    if (resultKey == null) {
      return null;
    }
    return (EntityTableCacheItem) getLocalCacheMgr().get(CacheType.ENTITYTABLE, resultKey);
  }

  /**
   * Gets a ServiceDetails object for the given loosely-coupled service. Such a
   * service has a service key defined in the web.xml as an init parameter in
   * the servlet context
   *
   * @param request HttpServletRequest
   * @param coreServiceCategoryKeyValue String
   * @return ServiceDetails
   * @throws AIGException
   */
  public ServiceDetails getCoreServiceByKeyValue(String coreServiceCategoryKeyValue) throws AIGException {
    ClassificationSchemeQuery classificationSchemeQuery = new ClassificationSchemeQuery();
    classificationSchemeQuery.addKeyValue(TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME, coreServiceCategoryKeyValue);
    ServiceKeyCacheResponse serviceKeys = getServiceKeys(new ServiceQuery(classificationSchemeQuery));
    if (serviceKeys.isEmpty()) {
      throw new AIGException("Unknown service " + coreServiceCategoryKeyValue, AIGException.Reason.UNABLE_TO_SET_SERVICE);
    }
    String serviceKey = Iterators.get(serviceKeys.iterator(), 0, null);
    return getService(serviceKey);
  }

  /**
   * Returns the UDDIQuery object
   *
   * @return UDDIQuery
   */
  public UDDIQuery getUDDIQuery() {
    return super.getUDDIQuery();
  }

  /**
   * Returns the ServiceDetails for the given list of keys- either from cache or
   * by quering the UDDI.
   *
   * Note: This actually returns a copy of the cached ServiceDetails object to
   * avoid any corruption
   *
   * @param serviceKeys
   * @return List<ServiceDetails>
   */
  public ServiceCacheResponse getServices(Collection<String> serviceKeys) throws AIGException {
    if (serviceKeys == null) {
      return new ServiceCacheResponse();
    }
    ServiceCacheResponse serviceDetailsList = new ServiceCacheResponse();
    for (String serviceKey : serviceKeys) {
      try {
        serviceDetailsList.add(getService(serviceKey));
      } catch (Exception e) {
      }
    }
    return serviceDetailsList;
  }

  /**
   * Returns the List of services for the given ClassificationSchemeQuery, input
   * types which must accept arrays, and result types either from cache or from
   * a UDDI query.
   *
   * @param serviceQuery ClassificationSchemeQuery
   * @param inputTypeAcceptsArray String
   * @param resultTypes String[]
   * @return List
   * @throws AIGException
   */
  public ServiceCacheResponse getServices(ServiceQuery serviceQuery) throws AIGException {   
    ServiceKeyCacheResponse serviceKeyCacheResponse = getServiceKeys(serviceQuery);
    ServiceCacheResponse serviceCacheResponse = new ServiceCacheResponse();
    serviceCacheResponse.setSorted(true);
    for (String serviceKey : serviceKeyCacheResponse) {
      if (serviceKeyCacheResponse.hasServiceDetails(serviceKey)) {
        serviceCacheResponse.add(processService(serviceKeyCacheResponse.getServiceDetails(serviceKey)));
        //Debug.print("Service: "+serviceKey+" In response");
      } else {
        //Debug.print("Service: "+serviceKey+" Not in response");
        serviceCacheResponse.setSorted(false);
        ServiceDetails service = null;
        try {
          service = getService(serviceKey, false, true);
        } catch (Exception e) {
          //e.printStackTrace();
        }
        if (service != null) {
          serviceCacheResponse.add(service);
        }
      }
    }
    return serviceCacheResponse;
  }

  /**
   * Saves the service results in the cache for the given result UUID of the
   * given format.
   *
   * @param resultKey String
   * @param serviceResultFormatName String
   * @param serviceResults String
   */
  public ServiceResultCacheItem saveServiceResult(String resultKey, ServiceDetails serviceDetails) throws AIGException {
    ServiceResultCacheItem serviceResultCacheItem = new ServiceResultCacheItem(resultKey);
    serviceResultCacheItem.setServiceDetails(serviceDetails);
    return saveServiceResult(serviceResultCacheItem);
  }

  /**
   * Saves the service results in the cache for the given result UUID of the
   * given format.
   *
   * @param resultKey String
   * @param serviceResultFormatName String
   * @param serviceResults String
   */
  public ServiceResultCacheItem saveServiceResult(String resultKey, ServiceDetails serviceDetails, String serviceResultFormatName, String serviceResults) throws AIGException {
    ServiceResultCacheItem serviceResultCacheItem = new ServiceResultCacheItem(resultKey);
    serviceResultCacheItem.setServiceDetails(serviceDetails);
    serviceResultCacheItem.setResultFormatName(serviceResultFormatName);
    serviceResultCacheItem.setCacheString(serviceResults);
    return saveServiceResult(serviceResultCacheItem);
  }

  /**
   * Saves the service results in the cache for the given result UUID of the
   * given format.
   *
   * @param resultKey String
   * @param serviceResultFormatName String
   * @param serviceResults Document
   */
  public ServiceResultCacheItem saveServiceResult(String resultKey, ServiceDetails serviceDetails, String serviceResultFormatName, Document serviceResults) throws AIGException {
    ServiceResultCacheItem serviceResultCacheItem = new ServiceResultCacheItem(resultKey);
    serviceResultCacheItem.setServiceDetails(serviceDetails);
    serviceResultCacheItem.setResultFormatName(serviceResultFormatName);
    serviceResultCacheItem.setResults(serviceResults);
    return saveServiceResult(serviceResultCacheItem);
  }

  /**
   * Saves the service results in the cache for the given result UUID of the
   * given format.
   *
   * @param resultKey String
   * @param serviceResultFormatName String
   * @param serviceResults Document
   */
  public ServiceResultCacheItem saveServiceResult(String resultKey, ServiceDetails serviceDetails, String serviceResultFormatName, byte[] serviceResults) throws AIGException {
    ServiceResultRawCacheItem serviceResultCacheItem = new ServiceResultRawCacheItem(resultKey);
    serviceResultCacheItem.setServiceDetails(serviceDetails);
    serviceResultCacheItem.setResultFormatName(serviceResultFormatName);
    serviceResultCacheItem.setResults(serviceResults);
    return saveServiceResult(serviceResultCacheItem);
  }

  /**
   * Saves the service results in the cache for the given result UUID of the
   * given format returning the resultKey
   *
   * @param resultKey String
   * @param serviceResultFormatName String
   * @param serviceResults String
   */
  public ServiceResultCacheItem saveServiceResult(ServiceDetails serviceDetails, String serviceResultFormatName, String serviceResults) throws AIGException {
    return saveServiceResult(null, serviceDetails, serviceResultFormatName, serviceResults);
  }

  /**
   * Saves the service results in the cache for the given result UUID of the
   * given format returning the resultKey
   *
   * @param resultKey String
   * @param serviceResultFormatName String
   * @param serviceResults Document
   */
  public ServiceResultCacheItem saveServiceResult(ServiceDetails serviceDetails, String serviceResultFormatName, Document serviceResults) throws AIGException {
    return saveServiceResult(null, serviceDetails, serviceResultFormatName, serviceResults);
  }

  /**
   * Returns the service results saved in the cache for the given result UUID
   * and format. null if none exists
   *
   * @param resultKey String
   * @param serviceResultFormatName String
   */
  public void getServiceResult(String resultKey, OutputStream out) throws IOException {
    ServiceResultCacheItem serviceResultCacheItem = getServiceResult(resultKey);
    if (serviceResultCacheItem != null) {
      serviceResultCacheItem.write(out);
    }
  }

  /**
   * Returns the service results saved in the cache for the given result UUID
   * and format. null if none exists
   *
   * @param resultKey String
   * @param serviceResultFormatName String
   */
  public void getServiceResult(String resultKey, Writer writer) throws IOException {
    ServiceResultCacheItem serviceResultCacheItem = getServiceResult(resultKey);
    if (serviceResultCacheItem != null) {
      serviceResultCacheItem.write(writer);
    }
  }

  /**
   * Returns whether the cache containsInGlobal the resultKey
   *
   * @param resultKey String
   * @return boolean
   */
  public boolean containsResult(String resultKey) {
    return (getServiceResult(resultKey) != null);
  }

  /**
   * Returns whether the cache containsInGlobal the resultKey and a ServiceDetails for
 that entry
   *
   * @param resultKey String
   * @return boolean
   */
  public boolean containsServiceDetailsForResult(String resultKey) {
    return (getServiceResult(resultKey) != null && getServiceResult(resultKey).getServiceDetails() != null);
  }

}
