package amgen.ri.aig.entitytable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import amgen.ri.aig.entitytable.filter.EntityTableFilterIF;

/**
 * <p>@version $Id: ColumnFilter.java,v 1.1 2011/06/17 20:41:19 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class ColumnFilter implements Serializable {
    static final long serialVersionUID = 4930348918867591279L;
    private Map<String, EntityTableFilterIF> columnFilterMap;
    private List<EntityTableFilterIF> columnFilters;

    public ColumnFilter() {
        columnFilters = new ArrayList<EntityTableFilterIF>();
        columnFilterMap = new HashMap<String, EntityTableFilterIF>();
    }

    public void addFilter(String columnDataIndex, EntityTableFilterIF filter) {
        columnFilterMap.put(columnDataIndex, filter);
        columnFilters.add(filter);
    }

    public void removeFilter(String columnDataIndex) {
        EntityTableFilterIF filter = columnFilterMap.remove(columnDataIndex);
        if (filter != null) {
            columnFilters.remove(filter);
        }
    }

    public void clearSort() {
        columnFilters.clear();
        columnFilterMap.clear();
    }

    public boolean match(EntityTable entityTable, DataRow row) {
        for (String columnDataIndex : columnFilterMap.keySet()) {
            int columnIndex = entityTable.getColumnIndex(columnDataIndex);
            if (columnIndex > -1 && columnIndex < row.getDataCells().size()) {
                EntityTableFilterIF filter = columnFilterMap.get(columnDataIndex);
                if (!filter.match(row.getDataCell(columnIndex))) {
                    return false;
                }
            }
        }
        return true;
    }


}
