package amgen.ri.aig.projectview;

import java.io.ObjectStreamException;

import amgen.ri.aig.AIGServlet;

/**
 * Defines an enumeration for ProjectView Operations
 */
public enum ProjectViewOperation {
    //Project View viewer operations
    REFRESH, START, PREVIOUS, NEXT, FIRST, LAST, INDEX, COMPOUNDS,
            FILTERABLES, FILTERLIST, FILTER, COMPOUNDLIST_FILTERSET, COMPOUNDLIST_ID, 
            DOCUMENTS, 
            PAGE_DOCUMENT_COUNT,
            PVPD_DOCUMENTS,
            EXPERIMENTS, EXPORTEXCEL, DEBUG, SETTINGS, COMPOUND_LISTS,
            X_COMPOUNDLIST, RESET_COMPOUNDLIST,
            COMPOUND_INFO, UNKNOWN;

    public static ProjectViewOperation fromString(String s) {
        if (s == null) {
            return UNKNOWN;
        }
        return ProjectViewOperation.valueOf(s.toUpperCase());
    }

    public static ProjectViewOperation getValue(AIGServlet servlet) {
        return ProjectViewOperation.fromString(servlet.getParameter("op"));
    }

    /**
     * This is necessary to permit Serializable.
     * A Serialized object containing an enum class variable is not de-Serialized properly.
     * This forces de-Serialized enum to be re-created as this enum through the String
     * @return Object
     * @throws ObjectStreamException
     */
    public Object readResolve() throws ObjectStreamException {
        return ProjectViewOperation.fromString(this.toString());
    }


}
