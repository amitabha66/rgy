package amgen.ri.aig.uddi;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.service.ServiceCacheResponse;
import amgen.ri.aig.cache.item.EntityTableCacheItem;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.asf.sa.uddi.CategoryKeyValue;
import amgen.ri.asf.sa.uddi.ClassificationSchemeQuery;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.json.JSONObject;
import amgen.ri.xml.ExtXMLElement;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;

/**
 * Looks up services which can ad columns for an entity table
 */
public class EntityTableColumnServiceLookup extends AbstractServiceLookup implements ServiceLookupIF {

  /**
   * Default constructor
   */
  public EntityTableColumnServiceLookup() {
    super();
  }

  public EntityTableColumnServiceLookup(AIGServlet aigServlet) {
    super(aigServlet);
  }

  /**
   * Main constructor- used only by the getAIGServlet method
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   */
  private EntityTableColumnServiceLookup(HttpServletRequest request, HttpServletResponse response) {
    super(request, response);
  }

  /**
   * Creates this AIG Servlet object
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return AIGServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new EntityTableColumnServiceLookup(req, resp);
  }

  /**
   * Actual work entry stub
   *
   * @throws ServletException
   * @throws IOException
   */
  protected void performRequest() throws ServletException, IOException, AIGException {
    try {
      ExtXMLElement.write(getServicesDocument(), response.getWriter());
    } catch (JDOMException ex) {
      ex.printStackTrace();
    }
  }

  /**
   * Returns as a List these services which match the given entity_type
   *
   * @throws JDOMException
   * @throws AIGException
   * @return List
   */
  private ServiceCacheResponse getServices(EntityListCategory entityCategory) throws JDOMException, AIGException {
    ServiceCacheResponse services = new ServiceCacheResponse();
    if (entityCategory.equals(EntityListCategory.UNKNOWN)) {
      return services;
    }
    Collection<ServiceDataCategory> serviceDataCategories = getEntityClassManager().convertEntityListCategoryToServiceDataCategories(entityCategory);
    if (serviceDataCategories.isEmpty()) {
      return services;
    }
    ClassificationSchemeQuery classificationSchemeQuery = new ClassificationSchemeQuery(ClassificationSchemeQuery.OR_ALL_KEYS);
    List<String> serviceDataTypeCategoryList = new ArrayList<String>();
    for (ServiceDataCategory serviceDataCategory : serviceDataCategories) {
      classificationSchemeQuery.addKeyValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, ServiceDataCategory.revertTo(serviceDataCategory));
      serviceDataTypeCategoryList.add(ServiceDataCategory.revertTo(serviceDataCategory));
    }
    ServiceQuery serviceQuery = new ServiceQuery(classificationSchemeQuery, new String[]{TModelCommonNameFactory.ENTITYTABLEDEFINITION_tMODELNAME, TModelCommonNameFactory.ENTITYTABLERAWDEFINITION_tMODELNAME});
    serviceQuery.addAllInputTypeWhichAcceptsList(serviceDataTypeCategoryList);

    services = ServiceCache.getServiceCache(request).getServices(serviceQuery);

    services.sortServices(ServiceNamingContext.RG_COLUMN, getRecentServicesDocument());
    return services;
  }

  @Override
  public JSONObject getServiceRecords() throws JDOMException, AIGException {
    return getServiceRecords(getServicesDocument());
  }

  @Override
  public Document getServicesDocument() throws JDOMException, AIGException {
    Document servicesDocument = new Document(new Element("Services"));
    try {
      String entityTableKey = getParameter("entityTableKey");
      EntityTableCacheItem entityTableCacheItem = ServiceCache.getServiceCache(request).getEntityTableResult(entityTableKey);
      if (entityTableCacheItem != null) {
        EntityListCategory entityListCategory = entityTableCacheItem.getEntityTable().getEntityCategory();
        ServiceCacheResponse services = getServices(entityListCategory);
        for (ServiceDetails service : services) {
          if (service.containsUserInAllowedUsers(getSessionLogin().getRemoteUser(), true)) {
            ServiceAttributes serviceAttributes = new ServiceAttributes(service, getEntityClassManager());
            Element serviceEl = service.getAsElement(false, false);
            servicesDocument.getRootElement().addContent(serviceEl);
            Element nameElement = serviceEl.getChild("Name");
            nameElement.setText(serviceAttributes.getName(ServiceNamingContext.RG_COLUMN));
            Element descElement = serviceEl.getChild("Description");
            descElement.setText(serviceAttributes.getDescription(ServiceNamingContext.RG_COLUMN));
            ExtXMLElement.addTextElement(serviceEl, "ID", UUID.randomUUID() + "");
            ExtXMLElement.addElement(serviceEl, "EditableParams", serviceAttributes.countEditableParameters(entityListCategory) + "");
            ExtXMLElement.addTextElement(serviceEl, "LastUsed", getLastUsedDateString(service));

            CategoryKeyValue orgCatValue = serviceAttributes.getOrganizationCategoryKeyValue();
            ExtXMLElement.addTextElement(serviceEl, "Category", (orgCatValue == null ? "Other" : orgCatValue.getKeyName()));

          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return servicesDocument;
  }
}
