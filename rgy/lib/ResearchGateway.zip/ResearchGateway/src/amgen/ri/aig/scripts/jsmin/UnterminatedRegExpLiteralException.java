package amgen.ri.aig.scripts.jsmin;

/**
 * <p>@version $Id: UnterminatedRegExpLiteralException.java,v 1.1 2011/06/17 20:41:25 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class UnterminatedRegExpLiteralException extends Exception {
    public UnterminatedRegExpLiteralException() {
        super();
    }

    public UnterminatedRegExpLiteralException(String message) {
        super(message);
    }

    public UnterminatedRegExpLiteralException(String message, Throwable cause) {
        super(message, cause);
    }

    public UnterminatedRegExpLiteralException(Throwable cause) {
        super(cause);
    }
}
