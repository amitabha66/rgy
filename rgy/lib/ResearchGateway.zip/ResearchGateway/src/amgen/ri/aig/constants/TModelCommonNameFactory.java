package amgen.ri.aig.constants;

import amgen.ri.asf.sa.uddi.*;
import amgen.ri.rg.config.ConfigurationParameterSource;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.xml.soap.SOAPException;
import org.jdom.JDOMException;

/**
 * @version $Id: TModelCommonNames.java,v 1.2 2012/03/28 05:33:35 cvs Exp
 */
public class TModelCommonNameFactory extends CommonNames {
  public static final String ENTITYPROPERTYDEFINITION_tMODELNAME = "AIG Entity Property Definition";
  public static final String PROJECTVIEWDEFINITION_tMODELNAME = "AIG ProjectView Definition";
  public static final String QUERYTREENODESDEFINITION_tMODELNAME = "QueryTreeNodes Definition";
  public static final String QUERYRGRAWENTITYTABLEDEFINITION_TMODELNAME = "Query RG Raw Entity Table Definition";
  public static final String QUERYENTITYTABLEDEFINITION_tMODELNAME = "Query RG Entity Table Definition";  
  public static final String TREENODESXMLDEFINITION_tMODELNAME = "TreeNodesXML Definition";
  public static final String DOCUMENTRAWDATADEFINITION_tMODELNAME = "Document Raw Data Definition";
  public static final String ENTITYTABLEDEFINITION_tMODELNAME = "AIG Entity Table Definition";
  public static final String ENTITYTABLERAWDEFINITION_tMODELNAME = "RG Raw Entity Table Definition";
  public static final String RGDDHTMLDEFINITION_tMODELNAME = "RG DD HTML Definition";
  public static final String SERVICE_INPUT_CATEGORIZATION_SCHEME =
          ClassificationSchemeNames.getName(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME);
  public static final String EXTENDED_TYPES_CATEGORIZATION_SCHEME =
          ClassificationSchemeNames.getName(ClassificationSchemeNames.EXTENDED_TYPES_CATEGORIZATION_SCHEME);  
  public static final String RESEARCH_GATEWAY_CATEGORIZATION_SCHEME = "Research Gateway Categorization Scheme";
  public static final String RESEARCH_GATEWAY_SERVICEINPUT_CATEGORIZATION_SCHEME = "Research Gateway Service Input Categorization Scheme";
  public static final String RESEARCH_GATEWAY_SERVICE_ORGANIZATION_SCHEME = "Research Gateway Service Organization Scheme";
  public static final String RESEARCH_GATEWAY_ICON_CATEGORIZATION_SCHEME = "Research Gateway Icon Categorization Scheme";  
  public static final String RESEARCH_GATEWAY_EXTERNAL_APPLICATION_PROPERTIES= "Research Gateway External Application Properties";
  
   
  public static final String RESEARCH_GATEWAY_DOCUMENT_TYPES_SCHEME = "Research Gateway Document Types Scheme";
  public static final String RESEARCH_GATEWAY_ENTITY_TYPES_SCHEME = "Research Gateway Entity Type Categorization Scheme";
  public Map<String, String> tModelKeys;
  private static TModelCommonNameFactory instance;

  private TModelCommonNameFactory(UDDIQuery uddiQuery) throws JDOMException, SOAPException, IOException {
    String[] classificationNames = new String[]{
      SERVICE_INPUT_CATEGORIZATION_SCHEME,
      RESEARCH_GATEWAY_CATEGORIZATION_SCHEME,
      RESEARCH_GATEWAY_SERVICEINPUT_CATEGORIZATION_SCHEME,
      RESEARCH_GATEWAY_SERVICE_ORGANIZATION_SCHEME,
      RESEARCH_GATEWAY_DOCUMENT_TYPES_SCHEME,
      RESEARCH_GATEWAY_ENTITY_TYPES_SCHEME
    };
    tModelKeys = new HashMap<String, String>();

    for (String classificationName : classificationNames) {
      TModelDetails tModel = uddiQuery.getClassificationSchemeByName(classificationName);
      if (tModel != null) {
        tModelKeys.put(classificationName, tModel.getKey());
      }
    }
  }

  public static TModelCommonNameFactory init() throws JDOMException, SOAPException, IOException {
    return init(ConfigurationParameterSource.getConfigParameter("UDDI_QUERY_URL"));    
  }

  public static TModelCommonNameFactory init(String uddiURL) throws JDOMException, SOAPException, IOException {
    UDDIQuery uddiQuery;
    if (uddiURL == null) {
      uddiQuery = new UDDIQuery(null);
    } else {
      uddiQuery = new UDDIQuery(new UDDIDetails(uddiURL));
    }
    instance = new TModelCommonNameFactory(uddiQuery);
    return instance;
  }

  public static TModelCommonNameFactory getInstance() {
    if (instance == null) {
      throw new IllegalArgumentException("Factory is not initialized. Must call init() prior to calling getInstance()");
    }
    return instance;
  }

  /**
   * Returns the tModel key for the given tModel name. If it is not available,
   * it looks it up and saves it
   *
   * @param tModelName
   * @return
   */
  public String getTModelKey(String tModelName) {
    if (!tModelKeys.containsKey(tModelName)) {
      try {
        String uddiURL = ConfigurationParameterSource.getConfigParameter("UDDI_QUERY_URL");
        UDDIQuery uddiQuery;
        if (uddiURL == null) {
          uddiQuery = new UDDIQuery(null);
        } else {
          uddiQuery = new UDDIQuery(new UDDIDetails(uddiURL));
        }
        TModelDetails tModel = uddiQuery.getClassificationSchemeByName(tModelName);
        if (tModel != null) {
          tModelKeys.put(tModelName, tModel.getKey());
        }
      } catch (Exception e) {
      }
    }
    return tModelKeys.get(tModelName);
  }

  /**
   * Returns the Categorization for the RegistryEntryDetails by the given
   * classification scheme. This either does this by looking up by its tModel
   * key, if possible, or by RegistryEntryDetails.getCategorizationByName
   *
   * @param registryEntry
   * @param classificationSchemeName
   * @return
   */
  public Categorization getCategorizationByName(RegistryEntryDetails registryEntry, String classificationSchemeName) {
    String classificationSchemeKey = getTModelKey(classificationSchemeName);
    if (classificationSchemeKey != null) {
      return registryEntry.getCategorization(classificationSchemeKey);
    }
    return registryEntry.getCategorizationByName(classificationSchemeName);
  }
}
