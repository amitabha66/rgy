package amgen.ri.aig.entitytable.filter;

import java.io.Serializable;

/**
 * <p>@version $Id: AbstractEntityTableFilter.java,v 1.1 2011/06/17 20:41:26 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public abstract class AbstractEntityTableFilter implements EntityTableFilterIF, Serializable {
    static final long serialVersionUID = -2728920801660335065L;
    public AbstractEntityTableFilter() {
    }

}
