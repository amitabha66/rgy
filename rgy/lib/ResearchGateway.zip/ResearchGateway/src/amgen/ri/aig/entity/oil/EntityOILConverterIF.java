/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.entity.oil;

import amgen.ri.aig.entity.EntityClass;
import amgen.ri.aig.entitytable.DataRow;
import com.google.common.collect.LinkedListMultimap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author jemcdowe
 */
public interface EntityOILConverterIF {
  /**
   * Creates a Map of 
   * LUID      : UIR
   * DRUID     : UIR
   * Pref. Name : UIR
   * The provided IDs can be DRUIDs or LUIDS. It is assumed that the DRUID
   * format is
   * (i|r|s)::code:id
   * where the class character and the code are provided by the EntityOILDetails.
   * Any other value is assumed to by a LUID
   *
   * @param entityClass
   * @param uids
   * @return
   */
  public Map<String,UIR> convert(EntityClass entityClass, List<String> uids);

  /**
   * Creates a Map of
   * LUID      : UIR
   * DRUID     : UIR
   * Pref. Name : UIR
   * The provided IDs can be DRUIDs or LUIDS. It is assumed that the DRUID
   * format is
   * (i|r|s)::code:id
   * where the class character and the code are provided by the EntityOILDetails.
   * Any other value is assumed to by a LUID
   *
   * @param entityClass
   * @param dataRows
   * @return
   */
  LinkedListMultimap<String, DataRow> generateUIRDataRowMap(EntityClass entityClass, List<DataRow> dataRows);

}
