package amgen.ri.aig.projectview;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.wsdl.WSDLException;
import javax.xml.rpc.ServiceException;
import javax.xml.transform.TransformerException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.PrintSetup;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.entity.rgdh.SMCompound;
import amgen.ri.aig.excel.ExcelExporter;
import amgen.ri.aig.projectview.model.ProjectViewModel;
import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.aig.util.Utilities;
import amgen.ri.json.ExtJSON;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;

/**
 * @version $Id: ProjectViewExcelExporter.java,v 1.3 2011/10/24 22:53:07 cvs Exp
 * $
 */
public class ProjectViewExcelExporter extends ExcelExporter {
  private AIGServlet requestor;
  private ProjectViewModel projectViewModel;
  private CellStyle titleStyle;
  private CellStyle sectionHeaderStyle;
  private CellStyle headerStyle;
  private CellStyle rowHeaderStyle;
  private CellStyle rowHeaderAlignTopStyle;
  private CellStyle textStyle;
  private CellStyle textAlignLeftStyle;
  private CellStyle wrapTextStyle;

  public ProjectViewExcelExporter(AIGServlet requestor, ProjectViewModel projectViewModel) {
    this.requestor = requestor;
    this.projectViewModel = projectViewModel;
  }

  public Workbook createHSSFWorkbook(List<String> compoundIDs) {
    Map<Integer, Integer> assaySheetColumnWidths = new HashMap<Integer, Integer>();
    assaySheetColumnWidths.put(0, 25);
    assaySheetColumnWidths.put(1, 35);
    assaySheetColumnWidths.put(2, 11);
    assaySheetColumnWidths.put(3, 23);
    assaySheetColumnWidths.put(4, 20);
    assaySheetColumnWidths.put(5, 25);
    assaySheetColumnWidths.put(6, 20);
    assaySheetColumnWidths.put(7, 20);

    Map<Integer, Integer> pkSheetColumnWidths = new HashMap<Integer, Integer>();
    pkSheetColumnWidths.put(0, 25);
    pkSheetColumnWidths.put(1, 13);
    pkSheetColumnWidths.put(2, 9);
    pkSheetColumnWidths.put(3, 67);
    pkSheetColumnWidths.put(4, 9);
    pkSheetColumnWidths.put(5, 45);    
    pkSheetColumnWidths.put(7, 15);

    Workbook wb = createWorkbook(createHSSFWorkbook());
    for (String compoundID : compoundIDs) {
      try {
        Sheet[] sheets = createSheet(wb, compoundID);
        if (sheets != null && sheets.length == 2) {
          Sheet assaySheet = sheets[0];
          setWidths(assaySheet, assaySheetColumnWidths);
          PrintSetup ps = assaySheet.getPrintSetup();
          assaySheet.setAutobreaks(true);
          ps.setFitWidth((short) 1);
          ps.setFitHeight((short) 3);

          Sheet pkSheet = sheets[1];

          setWidths(pkSheet, pkSheetColumnWidths);
          ps = pkSheet.getPrintSetup();
          pkSheet.setAutobreaks(true);
          ps.setFitWidth((short) 1);
          ps.setFitHeight((short) 3);
        }
      } catch (Exception ex) {
        ex.printStackTrace();
      }
    }
    return wb;
  }

  public Workbook createXSSFWorkbook(List<String> compoundIDs) {
    Workbook wb = createWorkbook(new XSSFWorkbook());
    for (String compoundID : compoundIDs) {
      try {
        Sheet[] sheets = createSheet(wb, compoundID);
        if (sheets != null) {
          //autoSizeAllColumns(sheet);
        }
      } catch (Exception ex) {
        ex.printStackTrace();
      }
    }
    return wb;
  }

  private Workbook createWorkbook(Workbook wb) {
    titleStyle = wb.createCellStyle();
    Font font = wb.createFont();
    titleStyle.setFont(font);
    font.setFontName("Calibri");
    font.setColor(IndexedColors.INDIGO.getIndex());
    font.setFontHeightInPoints((short) 14);
    font.setBoldweight(Font.BOLDWEIGHT_BOLD);

    sectionHeaderStyle = wb.createCellStyle();
    font = wb.createFont();
    sectionHeaderStyle.setFont(font);
    font.setFontName("Calibri");
    font.setColor(IndexedColors.WHITE.getIndex());
    font.setFontHeightInPoints((short) 11);
    font.setBoldweight(Font.BOLDWEIGHT_BOLD);
    sectionHeaderStyle.setAlignment(CellStyle.ALIGN_CENTER);
    sectionHeaderStyle.setFillForegroundColor(IndexedColors.INDIGO.getIndex());
    sectionHeaderStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);

    headerStyle = wb.createCellStyle();
    font = wb.createFont();
    headerStyle.setFont(font);
    font.setFontName("Calibri");
    font.setColor(IndexedColors.BLACK.getIndex());
    font.setFontHeightInPoints((short) 11);
    font.setBoldweight(Font.BOLDWEIGHT_BOLD);

    rowHeaderStyle = wb.createCellStyle();
    font = wb.createFont();
    rowHeaderStyle.setFont(font);
    font.setFontName("Calibri");
    font.setColor(IndexedColors.BLACK.getIndex());
    font.setFontHeightInPoints((short) 11);
    font.setBoldweight(Font.BOLDWEIGHT_BOLD);
    rowHeaderStyle.setFillForegroundColor(IndexedColors.PALE_BLUE.getIndex());
    rowHeaderStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
    rowHeaderStyle.setAlignment(CellStyle.ALIGN_RIGHT);

    rowHeaderAlignTopStyle = wb.createCellStyle();
    font = wb.createFont();
    rowHeaderAlignTopStyle.setFont(font);
    font.setFontName("Calibri");
    font.setColor(IndexedColors.BLACK.getIndex());
    font.setFontHeightInPoints((short) 11);
    font.setBoldweight(Font.BOLDWEIGHT_BOLD);
    rowHeaderAlignTopStyle.setFillForegroundColor(IndexedColors.PALE_BLUE.getIndex());
    rowHeaderAlignTopStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
    rowHeaderAlignTopStyle.setVerticalAlignment(CellStyle.VERTICAL_TOP);
    rowHeaderAlignTopStyle.setAlignment(CellStyle.ALIGN_RIGHT);

    textStyle = wb.createCellStyle();
    font = wb.createFont();
    textStyle.setFont(font);
    font.setFontName("Calibri");
    font.setColor(IndexedColors.BLACK.getIndex());
    font.setFontHeightInPoints((short) 11);
    font.setBoldweight(Font.BOLDWEIGHT_NORMAL);
    textStyle.setAlignment(CellStyle.ALIGN_RIGHT);

    textAlignLeftStyle = wb.createCellStyle();
    font = wb.createFont();
    textAlignLeftStyle.setFont(font);
    font.setFontName("Calibri");
    font.setColor(IndexedColors.BLACK.getIndex());
    font.setFontHeightInPoints((short) 11);
    font.setBoldweight(Font.BOLDWEIGHT_NORMAL);
    textAlignLeftStyle.setAlignment(CellStyle.ALIGN_LEFT);

    wrapTextStyle = wb.createCellStyle();
    font = wb.createFont();
    wrapTextStyle.setFont(font);
    font.setFontName("Calibri");
    font.setColor(IndexedColors.BLACK.getIndex());
    font.setFontHeightInPoints((short) 11);
    font.setBoldweight(Font.BOLDWEIGHT_NORMAL);
    wrapTextStyle.setWrapText(true);
    wrapTextStyle.setVerticalAlignment(CellStyle.VERTICAL_TOP);

    return wb;
  }

  private Sheet[] createSheet(Workbook wb, String compoundID) throws ServiceException, AIGException, TransformerException, IOException, JDOMException, WSDLException, ServletException, JSONException {
    SMCompound smCompound = new SMCompound(compoundID, new OraSQLManager(), null, JDBCNamesType.RGDH_JDBC+"");
    Document compoundInfoDocument = (Document) projectViewModel.getCompoundInfo(requestor, compoundID);
    String molFile = getMOLFile(compoundID);
    Document compoundPageDocument = projectViewModel.getProjectViewPageDocument(requestor, compoundID);
    JSONObject projectPageJSON = projectViewModel.createPageJSON(requestor, compoundPageDocument);

    Map<Integer, List<JSONObject>> assayLists = new LinkedHashMap<Integer, List<JSONObject>>();
    JSONArray assaysJSON = projectPageJSON.getJSONArray("Assay");
    for (int i = 0; i < assaysJSON.length(); i++) {
      JSONObject assayJSON = assaysJSON.getJSONObject(i);
      int assayListID = assayJSON.optInt("list_id");
      if (!assayLists.containsKey(assayListID)) {
        assayLists.put(assayListID, new ArrayList<JSONObject>());
      }
      assayLists.get(assayListID).add(assayJSON);
    }

    int rowCounter;
    Sheet assaySheet = wb.createSheet("Assays- " + compoundID);

    //Sheet Title
    Row row = getRow(assaySheet, 0);
    setCellValue(row, 0, "Project View Summary: " + projectViewModel.getProjectName(), titleStyle);

    //Compound ID
    row = getRow(assaySheet, 1);
    setCellValue(row, 0, "Compound: " + compoundID, headerStyle);

    //Properties Header
    setCellValue(row, 1, "Properties", sectionHeaderStyle);
    assaySheet.addMergedRegion(new CellRangeAddress(row.getRowNum(), row.getRowNum(), 1, 4));
    setCellValue(assaySheet, 2, 0, molFile, null);
    assaySheet.getRow(2).setHeightInPoints(94);

    //Properties
    //name
    setCellValue(assaySheet, 2, 1, "ACD Name (Largest Component)", rowHeaderAlignTopStyle);
    setCellValue(assaySheet, 2, 2, ExtXMLElement.getXPathValue(compoundInfoDocument, "//Property[@category='Compound' and @name='Name (Largest Component)']/@value"), wrapTextStyle);
    assaySheet.addMergedRegion(new CellRangeAddress(2, 2, 2, 4));
    //MW
    setCellValue(assaySheet, 3, 1, "MW", rowHeaderStyle);
    setCellValue(assaySheet, 3, 2, ExtXMLElement.getXPathNumberValue(compoundInfoDocument, "//Property[@category='Compound' and @name='MW']/@value"), textStyle);
    //formula
    setCellValue(assaySheet, 3, 3, "Formula", rowHeaderStyle);
    setCellValue(assaySheet, 3, 4, ExtXMLElement.getXPathValue(compoundInfoDocument, "//Property[@category='Compound' and @name='MF']/@value"), textStyle);
    //cLogP
    setCellValue(assaySheet, 4, 1, "cLogP", rowHeaderStyle);
    setCellValue(assaySheet, 4, 2, ExtXMLElement.getXPathNumberValue(compoundInfoDocument, "//Property[@category='Compound' and @name='logP']/@value"), textStyle);
    //HBA
    setCellValue(assaySheet, 4, 3, "HBA", rowHeaderStyle);
    setCellValue(assaySheet, 4, 4, ExtXMLElement.getXPathNumberValue(compoundInfoDocument, "//Property[@category='Compound' and @name='H Bond Acceptors']/@value"), textStyle);
    //clogD(pH=7.4)
    setCellValue(assaySheet, 5, 1, "clogD(pH=7.4)", rowHeaderStyle);
    setCellValue(assaySheet, 5, 2, ExtXMLElement.getXPathNumberValue(compoundInfoDocument, "//Property[@category='Compound' and @name='logD(pH=7.4)']/@value"), textStyle);
    //HBD
    setCellValue(assaySheet, 5, 3, "HBD", rowHeaderStyle);
    setCellValue(assaySheet, 5, 4, ExtXMLElement.getXPathNumberValue(compoundInfoDocument, "//Property[@category='Compound' and @name='H Bond Donors']/@value"), textStyle);
    //RotatableBonds
    setCellValue(assaySheet, 6, 1, "Rotatable Bonds", rowHeaderStyle);
    setCellValue(assaySheet, 6, 2, ExtXMLElement.getXPathNumberValue(compoundInfoDocument, "//Property[@category='Compound' and @name='Rotatable Bonds']/@value"), textStyle);
    //PSA
    setCellValue(assaySheet, 6, 3, "PSA", rowHeaderStyle);
    setCellValue(assaySheet, 6, 4, ExtXMLElement.getXPathNumberValue(compoundInfoDocument, "//Property[@category='Compound' and @name='PSA']/@value"), textStyle);

    rowCounter = 6;
    //PKa
    if (ExtXMLElement.getXPathValue(compoundInfoDocument, "//Property[@category='Compound' and @name='pKa']/@value") != null) {
      int pKaCount = 1;
      List<String> pkaValues = ExtXMLElement.getXPathValues(compoundInfoDocument, "//Property[@category='Compound' and @name='pKa']/@value");
      for (String pKaValue : pkaValues) {
        if (pKaCount % 2 != 0) {
          rowCounter++;
          setCellValue(assaySheet, rowCounter, 1, "pKa(" + pKaCount + ")", rowHeaderStyle);
          setCellValue(assaySheet, rowCounter, 2, pKaValue, textStyle);
        } else {
          setCellValue(assaySheet, rowCounter, 3, "pKa(" + pKaCount + ")", rowHeaderStyle);
          setCellValue(assaySheet, rowCounter, 4, pKaValue, textStyle);
        }
        pKaCount++;
      }
    } else {
      //PKa
      int pKaCount = 1;
      String pKaValue;
      while ((pKaValue = ExtXMLElement.getXPathValue(compoundInfoDocument, "//Property[@category='Compound' and @name='pKa(" + pKaCount + ")']/@value")) != null) {
        if (pKaCount % 2 != 0) {
          rowCounter++;
          setCellValue(assaySheet, rowCounter, 1, "pKa(" + pKaCount + ")", rowHeaderStyle);
          setCellValue(assaySheet, rowCounter, 2, pKaValue, textStyle);
        } else {
          setCellValue(assaySheet, rowCounter, 3, "pKa(" + pKaCount + ")", rowHeaderStyle);
          setCellValue(assaySheet, rowCounter, 4, pKaValue, textStyle);
        }
        pKaCount++;
        //Something is wrong- kill loop
        if (pKaCount > 10) {
          break;
        }
      }
    }
    rowCounter += 1;
    //Categories
    boolean showBEColumn = projectViewModel.getColumnDisplayed("be");
    boolean showLipEColumn = projectViewModel.getColumnDisplayed("lipe");
    int beColumnIndex = (showBEColumn ? 6 : 0);
    int lipEColumnIndex = (showLipEColumn ? (showBEColumn ? 7 : 6) : 0);

    for (Integer listID : assayLists.keySet()) {
      List<JSONObject> assays = assayLists.get(listID);
      if (assays.size() > 0) {
        rowCounter++;
        setCellValue(assaySheet, rowCounter, 0, assays.get(0).optString("list_name"), sectionHeaderStyle);
        assaySheet.addMergedRegion(new CellRangeAddress(rowCounter, rowCounter, 0, 5 + (showBEColumn ? 1 : 0) + (showLipEColumn ? 1 : 0)));
        rowCounter++;
        setCellValue(assaySheet, rowCounter, 0, "Name", headerStyle);
        assaySheet.addMergedRegion(new CellRangeAddress(rowCounter, rowCounter, 0, 3));
        setCellValue(assaySheet, rowCounter, 4, "Value (" + projectViewModel.getAggregation() + ")", headerStyle);
        setCellValue(assaySheet, rowCounter, 5, "Type", headerStyle);
        if (showBEColumn) {
          setCellValue(assaySheet, rowCounter, beColumnIndex, "Binding Efficiency", headerStyle);
        }
        if (showLipEColumn) {
          setCellValue(assaySheet, rowCounter, lipEColumnIndex, "Lipophilic Efficiency", headerStyle);
        }
        for (JSONObject assay : assays) {
          rowCounter++;
          setCellValue(assaySheet, rowCounter, 0, assay.optString("field_display_name"), textAlignLeftStyle);
          assaySheet.addMergedRegion(new CellRangeAddress(rowCounter, rowCounter, 0, 3));
          if ((ExtString.equals(assay.optString("value"), "0.0") || ExtString.equals(assay.optString("value"), "0"))
                  && ExtString.hasLength(assay.optString("vnt_value")) && assay.optString("vnt_value").startsWith("N/A")) {
            setCellValue(assaySheet, rowCounter, 4, assay.optString("vnt_value"), textStyle);
          } else {
            setCellValue(assaySheet, rowCounter, 4, assay.optString("value"), textStyle);
          }
          setCellValue(assaySheet, rowCounter, 5, assay.optString("result_type"), textStyle);
          if (showBEColumn) {
            double be = Utilities.calculateBindingEfficiency(assay.optString("result_type"), ExtString.toDouble(assay.optString("value")), smCompound);
            setCellValue(assaySheet, rowCounter, beColumnIndex, be, textStyle);
          }
          if (showLipEColumn) {
            double lipe = Utilities.calculateLipophilicEfficiency(assay.optString("result_type"), ExtString.toDouble(assay.optString("value")), smCompound);
            setCellValue(assaySheet, rowCounter, lipEColumnIndex, lipe, textStyle);
          }
        }
      }
    }

    //in vivo PK
    Sheet pkSheet = wb.createSheet("PK- " + compoundID);
    //Sheet Title
    row = getRow(pkSheet, 0);
    setCellValue(row, 0, "Project View invivo PK Summary: " + projectViewModel.getProjectName(), titleStyle);

    //Compound ID
    row = getRow(pkSheet, 1);
    setCellValue(row, 0, "Compound: " + compoundID, headerStyle);

    //Properties Header
    setCellValue(row, 1, "Properties", sectionHeaderStyle);
    pkSheet.addMergedRegion(new CellRangeAddress(row.getRowNum(), row.getRowNum(), 1, 4));
    setCellValue(pkSheet, 2, 0, molFile, null);
    pkSheet.getRow(2).setHeightInPoints(94);

    //Properties
    //name
    setCellValue(pkSheet, 2, 1, "ACD Name (Largest Component)", rowHeaderAlignTopStyle);
    setCellValue(pkSheet, 2, 2, ExtXMLElement.getXPathValue(compoundInfoDocument, "//Property[@category='Compound' and @name='Name (Largest Component)']/@value"), wrapTextStyle);
    pkSheet.addMergedRegion(new CellRangeAddress(2, 2, 2, 4));

    rowCounter = 3;
    setCellValue(pkSheet, rowCounter, 0, "in vivo PK", sectionHeaderStyle);
    pkSheet.addMergedRegion(new CellRangeAddress(rowCounter, rowCounter, 0, 7));
    List<JSONObject> invivoAssays = ExtJSON.toJSONObjectList(projectPageJSON.getJSONArray("InVivo"));
    rowCounter++;

    setCellValue(pkSheet, rowCounter, 0, "Species", headerStyle);
    setCellValue(pkSheet, rowCounter, 1, "Gender", headerStyle);
    setCellValue(pkSheet, rowCounter, 2, "Fed State", headerStyle);
    setCellValue(pkSheet, rowCounter, 3, "Dose (mg/kg)", headerStyle);
    setCellValue(pkSheet, rowCounter, 4, "Route", headerStyle);
    setCellValue(pkSheet, rowCounter, 5, "Vehicle", headerStyle);
    setCellValue(pkSheet, rowCounter, 6, "Value", headerStyle);
    setCellValue(pkSheet, rowCounter, 7, "Parameter", headerStyle);

    Map<String, String> invivoParams = new LinkedHashMap<String, String>();
    invivoParams.put("AUCINF", "AUCinf (\u03BCM·hr)");
    invivoParams.put("AUCT", "AUCt (\u03BCM·hr)");
    invivoParams.put("AUCEXTRAP", "AUC%extrap (%)");
    invivoParams.put("CL", "CL (L/hr/kg)");
    invivoParams.put("CLT", "CLt (L/hr/kg)");
    invivoParams.put("CLF", "CL/F (L/hr/kg)");
    invivoParams.put("CLFT", "CL/Ft (L/hr/kg)");
    invivoParams.put("MRT", "MRT (hr)");
    invivoParams.put("MRTT", "MRTt (hr)");
    invivoParams.put("T12Z", "t1/2,z (hr)");
    invivoParams.put("CMAX", "Cmax (\u03BCM)");
    invivoParams.put("TMAX", "Tmax (hr)");
    invivoParams.put("VSS", "Vss (L/kg)");
    invivoParams.put("VSST", "Vsst (L/kg)");
    invivoParams.put("F", "F (%)");

    for (JSONObject invivoAssay : invivoAssays) {
      for (String invivoParam : invivoParams.keySet()) {
        String resultType = invivoParams.get(invivoParam);
        String paramValue = invivoAssay.optString(invivoParam, "");
        if (ExtString.hasLength(paramValue)) {
          rowCounter++;
          setCellValue(pkSheet, rowCounter, 0, invivoAssay.optString("species", ""), textAlignLeftStyle);
          setCellValue(pkSheet, rowCounter, 1, invivoAssay.optString("gender", ""), textStyle);
          setCellValue(pkSheet, rowCounter, 2, invivoAssay.optString("fedstate", ""), textStyle);
          setCellValue(pkSheet, rowCounter, 3, invivoAssay.optString("dose", ""), textStyle);
          setCellValue(pkSheet, rowCounter, 4, invivoAssay.optString("route", ""), textStyle);
          setCellValue(pkSheet, rowCounter, 5, invivoAssay.optString("vehicle", ""), textAlignLeftStyle);

          setCellValue(pkSheet, rowCounter, 6, paramValue, textStyle);
          setCellValue(pkSheet, rowCounter, 7, resultType, textStyle);
        }
      }
    }
    return new Sheet[]{assaySheet, pkSheet};
  }

  private Row getRow(Sheet sheet, int rowNum) {
    if (sheet.getRow(rowNum) == null) {
      sheet.createRow(rowNum);
    }
    return sheet.getRow(rowNum);
  }

  protected Cell setCellValue(Sheet sheet, int rowNum, int columnIndex, Object value, CellStyle style) {
    Row row = getRow(sheet, rowNum);
    return setCellValue(row, columnIndex, value, style);
  }

  protected Cell setCellValue(Row row, int columnIndex, Object value, CellStyle style) {
    Cell cell = null;
    if (value == null) {
      cell = row.createCell(columnIndex);
      cell.setCellValue("");
    } else if (value instanceof String) {
      cell = row.createCell(columnIndex);
      if (ExtString.isANumber(value.toString())) {
        cell.setCellValue(ExtString.toDouble(value.toString()));
      } else {
        cell.setCellValue((String) value);
      }
    } else if (value instanceof Character) {
      cell = row.createCell(columnIndex);
      cell.setCellValue(value.toString());
    } else if (value instanceof Enum) {
      cell = row.createCell(columnIndex);
      cell.setCellValue(value.toString());
    } else if (value instanceof Number) {
      cell = row.createCell(columnIndex);
      double d = ((Number) value).doubleValue();
      if (Double.isNaN(d) || Double.isInfinite(d)) {
        cell.setCellValue("-");
      } else {
        cell.setCellValue(d);
      }
    } else if (value instanceof Cell) {
      cell = row.createCell(columnIndex);
      Cell sourceCell = (Cell) value;
      switch (sourceCell.getCellType()) {
        case Cell.CELL_TYPE_NUMERIC:
          double numVal = sourceCell.getNumericCellValue();
          cell.setCellValue(numVal);
          break;
        case Cell.CELL_TYPE_ERROR:
          return null;
        case Cell.CELL_TYPE_STRING:
        default:
          String strVal = sourceCell.getStringCellValue();
          cell.setCellValue(strVal);
      }
    }
    if (style != null) {
      cell.setCellStyle(style);
    }
    return cell;
  }

  private String getMOLFile(String compoundID) throws IOException, AIGException {
    AIGSessionLogin sessionLogin = (AIGSessionLogin) requestor.getSessionLogin();
    String smscBaseURL = ConfigurationParameterSource.getConfigParameter("SMSC_BASE_URL");
    String smscURL = smscBaseURL + "/cache.go";

    //http://usto-dapp-aldi1.amgen.com:9090/smsc/cache.go?db=acrf&id=2098055,2319988,2317696,2316984,2317692,2521161,123456&format=xml&direct=1

    Map<String, String> params = new HashMap<String, String>();
    params.put("db", "acrf");
    params.put("id", compoundID);
    params.put("format", "xml");
    params.put("direct", "1");
    params.put("FASF_IDENTITY", sessionLogin.getCypherUser());

    Document structureDocument = ExtXMLElement.toDocument(smscURL, params);

    String xpath = "/Structures/Structure[ID='" + compoundID + "']/MOL";
    if (ExtString.isANumber(compoundID)) {
      xpath = "/Structures/Structure[ID=" + compoundID + "]/MOL";
    }
    Element molEl = ExtXMLElement.getXPathElement(structureDocument, xpath);
    if (molEl == null) {
      return null;
    }
    return molEl.getText();
  }

  protected void setWidths(Sheet sheet, Map<Integer, Integer> columnWidths) {
    Row maxCellRow = null;
    Iterator<Row> rowIterator = sheet.rowIterator();
    while (rowIterator.hasNext()) {
      Row row = rowIterator.next();
      if (maxCellRow == null || maxCellRow.getLastCellNum() < row.getLastCellNum()) {
        maxCellRow = row;
      }
    }
    if (maxCellRow != null) {
      Iterator<Cell> cellIterator = maxCellRow.cellIterator();
      while (cellIterator.hasNext()) {
        Cell cell = cellIterator.next();
        int columnIndex = cell.getColumnIndex();
        if (columnWidths.containsKey(columnIndex)) {
          sheet.setColumnWidth(columnIndex, (int) Math.ceil(256 * (columnWidths.get(columnIndex))));
        }
      }
    }
  }
}
