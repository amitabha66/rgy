package amgen.ri.aig.quick;

public class QuickLaunchItem {
    public String name;
    public String icon;
    public String action;
    public QuickLaunchItem(String name, String icon, String action) {
        this.name = name;
        this.icon = icon;
        this.action = action;
    }
}
