package amgen.ri.aig.entityrules;

import amgen.ri.aig.cache.tree.TreeNode;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.entitylist.EntityListMemberIF;
import amgen.ri.aig.entitylist.GenericEntityListMember;
import amgen.ri.rg.resource.ResourceFactory;
import amgen.ri.util.ExtString;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Class used to enforce business rules when processing nodes or
 * EntityListMembers for an EntityType
 *
 * @version $id$
 */
public abstract class AbstractEntityRules extends ResourceFactory implements EntityRulesIF {
    protected static Pattern ASSAYCODE_PATTERN = Pattern.compile("AA[0-9]+");
    protected static Pattern NUMBER_PATTERN = Pattern.compile("[0-9]+");
    private EntityListCategory entityType;
    /**
     * AbstractEntityRules
     *
     */
    public AbstractEntityRules(EntityListCategory entityType) {
        super();
        if (entityType == null) {
            throw new IllegalArgumentException("EntityType can not be null");
        }
        this.entityType = entityType;
    }

    protected void basicProcessing(TreeNode node) {
        String entityServiceData = node.getServiceData();
        if (!ExtString.hasLength(entityServiceData)) {
            String text = node.getText();
            node.setServiceData(text);
        }
    }

    /**
     * applyEntityRules
     *
     * @param id String
     * @return String
     */
    public String applyEntityRules(String id, ServiceDataCategory memberServiceDataCategory) {
        if (memberServiceDataCategory== null) {
            memberServiceDataCategory= getEntityClassManager().convertEntityListCategoryToServiceDataCategory(getEntityType());
        }
        GenericEntityListMember e = new GenericEntityListMember(id, getEntityClassManager().convertServiceDataCategoryToEntityListCategory(memberServiceDataCategory));
        EntityListMemberIF e2 = applyEntityRules(e, memberServiceDataCategory);
        return (e2 == null ? null : e2.getMember());
    }

    /**
     * Apply EntityRule to a list of IDs and return a Map of
     * Original ID:Translated ID. The default implementation
     * uses the applyEntityRules(String id, ServiceDataCategory memberServiceDataCategory)
     * method to apply the ruls individually. This can be done more efficiently in the
     * individual implementations.
     *
     * @param ids List
     * @param memberServiceDataCategory ServiceDataCategory
     * @return Map
     */
    public Map<String, String> applyEntityRules(Collection<String> ids, ServiceDataCategory memberServiceDataCategory) {
        Map ruleMap = new HashMap<String, String>();
        for (String id : ids) {
            ruleMap.put(id, applyEntityRules(id, memberServiceDataCategory));
        }
        return ruleMap;
    }

    public EntityListCategory getEntityType() {
        return entityType;
    }

}
