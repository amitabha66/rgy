
/*
 *   Rg_Apps
 *   RDBData wrapper class for ACCESS_CONTROL
 *   $Revision: 1.35 $
 *   Created: Jeffrey McDowell, 14 Dec 2011
 *   Modified: $Author: jemcdowe $
 *   $Log
 *
 */
package amgen.ri.aig.loft;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.favorites.*;
import amgen.ri.aig.items.ItemsManager;
import amgen.ri.aig.record.ItemRecord;
import amgen.ri.aig.sobj.ObjectType;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import java.lang.reflect.Field;
import amgen.ri.rdb.*;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import java.sql.Timestamp;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.text.StyledEditorKit;

/**
 * RDBData wrapper class for ACCESS_CONTROL
 *
 * @version $Revision: 1.35 $
 * @author Jeffrey McDowell
 * @author $Author: jemcdowe $
 */
public class RGApp extends RdbData implements Saveable, Removeable {
  protected OraSequenceField rg_app_id;
  protected String owner;
  protected int quick_app_pos;
  protected Timestamp created;
  protected RGAppType rg_app_type;
  protected int sort;
  protected RGAppAttribute[] attributes;
  protected RGPageTag[] pageTags;
  private ItemRecord itemRecord;

  /**
   * Default Constructor
   */
  public RGApp() {
    super();
  }

  /**
   * RdbData Constructor
   */
  public RGApp(String rg_app_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
    this.rg_app_id = new OraSequenceField(rg_app_id);
  }

  /**
   * Constructor which sets the class variables
   */
  public RGApp(String owner, AppType rgAppType, int sort, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
    if (rgAppType.equals(AppType.UNKNOWN)) {
      throw new IllegalArgumentException("App type can not be UNKNOWN");
    }
    this.rg_app_id = new OraSequenceField("RG_APP_SEQ", this);
    this.owner = owner;
    this.quick_app_pos = -1;
    this.rg_app_type = new RGAppType(rgAppType.toString(), sqlManager, logonusername, connectionPool);
    this.sort = sort;
    this.created = new Timestamp(System.currentTimeMillis());
  }

  /**
   * A required method which returns the primary key(s) of the table/RdbData
   * class.
   */
  public String getIdentifier() {
    return rg_app_id + "";
  }

  /**
   * This method is required EXACTLY as written to allow the RdbData
   * architecture access to the class variables.
   */
  protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
    field.set(this, value);
  }

  /**
   * This method is required EXACTLY as written to allow the RdbData
   * architecture access to the class variables.
   */
  protected Object getFieldValue(Field field) throws IllegalAccessException {
    return field.get(this);
  }

  public String getTableName() {
    return "RG_APPS";
  }

  /**
   * Returns the SQL for INSERTing the object in the table
   */
  public String getInsertSQL() {
    return null;
  }

  /**
   * Returns the SQL for UPDATing the object in the table
   */
  public String getUpdateSQL() {
    return null;
  }

  /**
   * Returns the SQL for DELTEing the object/row in the table
   */
  public String getDeleteSQL() {
    return null;
  }

  public int performDelete() {
    RGAppAttribute[] attributes = getAttributes();
    if (attributes != null) {
      for (RGAppAttribute attribute : attributes) {
        attribute.performDelete();
      }
    }
    return super.performDelete();
  }

  public int performCommit() {
    RGAppAttribute[] attributes = getAttributes();
    if (attributes != null) {
      for (RGAppAttribute attribute : attributes) {
        attribute.setData();
        attribute.performCommit();
      }
    }
    return super.performCommit();
  }

  /**
   * Get value for owner
   */
  public String getOwner() {
    return (String) get("owner");
  }

  /**
   * Set value for owner
   */
  public void setOwner(String owner) {
    set("owner", owner);
  }

  /**
   * Sets the sort position in the quick app toolbar. If this is set to -1, this
   * is not a quick app
   */
  public void setQuickAppPos(int quickAppPos) {
    set("quick_app_pos", quickAppPos);
  }

  /**
   * Returns the sort position in the quick app toolbar. If this is set to -1,
   * this is not a quick app
   */
  public int getQuickAppPos() {
    return getAsNumber("quick_app_pos").intValue();
  }

  /**
   * Get value for rg_app_type
   */
  public AppType getAppType() {
    return AppType.fromString(get("rg_app_type").toString());
  }

  /**
   * Get value for rg_app_type
   */
  public RGAppType getRGAppType() {
    return (RGAppType) get("rg_app_type");
  }

  /**
   * Set value for rg_app_type
   */
  public void setAppType(String rg_app_type) {
    RGAppType rgAppType = new RGAppType(rg_app_type, getSQLManager(), getLogonUsername(), getConnectionPool());
    if (!rgAppType.setData()) {
      throw new IllegalArgumentException("Unknown app type");
    }
    set("rg_app_type", rgAppType);
  }

  /**
   * Get value for sort
   */
  public int getSort() {
    return getAsNumber("sort").intValue();
  }

  /**
   * Get value for created
   */
  public Timestamp getCreated() {
    return (Timestamp) get("created");
  }

  /**
   * Set value for sort
   */
  public void setSort(int sort) {
    set("sort", new Integer(sort));
  }

  public RGPageTag[] getRGPageTags() {
    return (RGPageTag[]) get("pageTags");
  }

  public RGAppAttribute[] getAttributes() {
    return (RGAppAttribute[]) get("attributes");
  }

  public RGAppAttribute getAttribute(AppAttributeType attributeType) {
    RGAppAttribute[] attributes = getAttributes();
    if (attributes != null) {
      for (RGAppAttribute attribute : attributes) {
        if (attribute.setData() && ExtString.equals(attribute.getAttributeName(), attributeType.toString())) {
          return attribute;
        }
      }
    }
    return null;
  }

  public String getAttributeValue(AppAttributeType attributeType) {
    RGAppAttribute attr = getAttribute(attributeType);
    if (attr == null) {
      return null;
    }
    return attr.getAttributeValue();
  }

  public RGAppAttribute addAttribute(AppAttributeType attributeType, String attributeValue) {
    setData();
    if (attributes == null) {
      attributes = new RGAppAttribute[0];
    }
    RGAppAttribute[] newAttrs = new RGAppAttribute[attributes.length + 1];
    if (attributes.length > 0) {
      System.arraycopy(attributes, 0, newAttrs, 0, attributes.length);
    }
    newAttrs[newAttrs.length - 1] = new RGAppAttribute(this, attributeType, attributeValue);
    attributes = newAttrs;
    return newAttrs[newAttrs.length - 1];
  }

  public String getImageCSS(AIGBase requestor) {
    AppType appType = getAppType();
    switch (appType) {
      case FAVORITES_TOOL:
      case EXPLORE_TOOL:
      case VQT_TOOL:
      case LISTS_TOOL:
      case PROJECT_VIEW_TOOL:
      case PREFERENCES_TOOL:
      case DOCUMENTS_TOOL:
      case TABLE_IMPORT_TOOL:
      case STRUCTURE_SEARCH_TOOL:
        return appType.getImageCSS();
      case SERVICE:
        String iconCSS = getAttributeValue(AppAttributeType.ICONCLS);
        if (iconCSS != null) {
          return iconCSS;
        }
        try {
          ServiceDetails service = ServiceCache.getServiceCache(requestor).getService(getAttribute(AppAttributeType.SERVICE_KEY).getAttributeValue());
          ServiceAttributes serviceAttr = new ServiceAttributes(service, requestor.getEntityClassManager());
          String iconClass = serviceAttr.getIconClass(ServiceNamingContext.RG_LOFT);
          if (iconClass != null) {
            return iconClass;
          }
        } catch (Exception e) {
          e.printStackTrace();
        }
        return "ix-v0-48-gears_run";
      case FAVORITE:
        if (checkFavorite(requestor)) {
          ItemRecord itemRecord = getItemRecord(requestor);
          if (itemRecord.getItemType().equals(ItemRecord.ItemType.FOLDER)) {
            return "ix-v0-48-folder";
          } else if (itemRecord.isSavedItemType()) {
            FavoriteIF favorite = itemRecord.getItem(requestor);
            if (favorite != null) {
              switch (favorite.getType()) {
                case ENTITYTABLE:
                  return "ix-v0-48-table_sql";
                case LIST:
                  return "ix-v0-48-notebook";
                case PROJECTVIEW:
                  return "ix-v0-48-pie-chart_view";
                case SERVICE:
                  return "ix-v0-48-signpost";
                case UNKNOWN:
                default:
                  return "ix-v0-48-star_yellow";
              }
            }
          }
        }
        break;
    }
    return null;
  }

  public String getFilterSortCategory(AIGBase requestor) {
    AppType appType = getAppType();
    switch (appType) {
      case EXPLORE_TOOL:
        return "TOOL." + "SEARCHES_TOOL";
      case VQT_TOOL:
        return "TOOL." + "VISUAL_QUERIES_TOOL";
      case FAVORITES_TOOL:
      case LISTS_TOOL:
      case PROJECT_VIEW_TOOL:
      case PREFERENCES_TOOL:
      case TABLE_IMPORT_TOOL:
      case STRUCTURE_SEARCH_TOOL:
      case DOCUMENTS_TOOL:
        return "TOOL." + appType;
      case SERVICE:
        String entityCategory= getAttributeValue(AppAttributeType.ENTITY_CATEGORY);
        if (entityCategory!= null) {
          return "SEARCH." + EntityListCategory.fromString(entityCategory);
        }
        try {
          ServiceDetails service = ServiceCache.getServiceCache(requestor).getService(getAttribute(AppAttributeType.SERVICE_KEY).getAttributeValue());
          EntityListCategory serviceEntityListCategory = new ServiceAttributes(service, requestor.getEntityClassManager()).getFirstEntityListCategory();
          return "SEARCH." + (serviceEntityListCategory.equals(EntityListCategory.UNKNOWN) ? "OTHER" : serviceEntityListCategory);
        } catch (Exception e) {
          //e.printStackTrace();
        }
        return "SEARCH.UNKNOWN";
      case FAVORITE:
        if (checkFavorite(requestor)) {
          ItemRecord itemRecord = getItemRecord(requestor);
          if (itemRecord.getItemType().equals(ItemRecord.ItemType.FOLDER)) {
            return "ix-v0-48-folder";
          } else if (itemRecord.isSavedItemType()) {
            FavoriteIF favorite = itemRecord.getItem(requestor);
            if (favorite != null) {
              ObjectType.Type favType = favorite.getType();
              return "FAVORITE." + (favType.equals(ObjectType.Type.UNKNOWN) ? "OTHER" : favType);
            }
          }
        }
        break;
    }
    return null;
  }

  public String getName(AIGBase requestor) {
    String name = getRGAppType().getName();
    if (name != null) {
      return name;
    }
    switch (getAppType()) {
      case SERVICE:
        String serviceName = getAttributeValue(AppAttributeType.NAME);
        if (serviceName != null) {
          return serviceName;
        }
        try {
          ServiceDetails service = ServiceCache.getServiceCache(requestor).getService(getAttribute(AppAttributeType.SERVICE_KEY).getAttributeValue(), false, false);
          return new ServiceAttributes(service, requestor.getEntityClassManager()).getName(new ServiceNamingContext[]{ServiceNamingContext.RG_LAUNCHPAD, ServiceNamingContext.RG_LOFT, ServiceNamingContext.RG_QUERY});
        } catch (Exception e) {
          e.printStackTrace();
        }
        return null;
      case FAVORITE:
        if (checkFavorite(requestor)) {
          return getItemRecord(requestor).getName();
        }
        return null;
      default:
        return "Service";
    }
  }

  public String getDescription(AIGBase requestor) {
    String desc = getRGAppType().getDescription();
    if (desc != null) {
      return desc;
    }
    switch (getAppType()) {
      case SERVICE:
        String serviceDesc = getAttributeValue(AppAttributeType.DESCRIPTION);
        if (serviceDesc != null) {
          return serviceDesc;
        }
        try {
          ServiceDetails service = ServiceCache.getServiceCache(requestor).getService(getAttribute(AppAttributeType.SERVICE_KEY).getAttributeValue(), false, true);
          return new ServiceAttributes(service, requestor.getEntityClassManager()).getDescription(ServiceNamingContext.RG_QUERY);
        } catch (Exception e) {
          e.printStackTrace();
        }
        return null;
      case FAVORITE:
        if (checkFavorite(requestor)) {
          return getItemRecord(requestor).getDescription();
        }
        return null;
      default:
        return "Service";
    }
  }

  public ItemRecord getItemRecord(AIGBase requestor) {
    if (itemRecord != null) {
      return itemRecord;
    }
    switch (getAppType()) {
      case FAVORITE:
        RGAppAttribute attribute = getAttribute(AppAttributeType.FAVORITEFOLDERITEM_ID);
        if (attribute != null) {
          return (itemRecord = new ItemsManager(requestor).getItemRecord(attribute.getAttributeIntegerValue()));
        }
        break;
      case EXPLORE_TOOL:
      case VQT_TOOL:
      case LISTS_TOOL:
      case PROJECT_VIEW_TOOL:
      case PREFERENCES_TOOL:
      case TABLE_IMPORT_TOOL:
      case STRUCTURE_SEARCH_TOOL:
      case DOCUMENTS_TOOL:
      case SERVICE:
      default:
        break;
    }
    return null;
  }

  private boolean checkFavorite(AIGBase requestor) {
    ItemRecord itemRecord = getItemRecord(requestor);
    switch (itemRecord.getItemType()) {
      case FOLDER:
        return true;
      case ITEM:
      case SHARED_ITEM:
        FavoriteIF favorite = itemRecord.getItem(requestor);
        if (favorite != null) {
          return true;
        }
        break;
    }
    return false;
  }

  public boolean isValid(AIGBase requestor) {
    switch (getAppType()) {
      case FAVORITES_TOOL:
      case EXPLORE_TOOL:
      case VQT_TOOL:
      case LISTS_TOOL:
      case PROJECT_VIEW_TOOL:
      case PREFERENCES_TOOL:
      case TABLE_IMPORT_TOOL:
      case STRUCTURE_SEARCH_TOOL:
      case DOCUMENTS_TOOL:
        return true;
      case SERVICE:
        //Do I want to incude this!!
        try {
          return ServiceCache.getServiceCache(requestor).verifyServiceActive(getAttribute(AppAttributeType.SERVICE_KEY).getAttributeValue());
        } catch (Exception e) {
        }
        return true;
      case FAVORITE:
        return checkFavorite(requestor);
      default:
        return false;
    }
  }

  public JSONObject asJSON(AIGBase requestor) throws JSONException {
    //ElapsedTime time= new ElapsedTime(true);
    //time.writeSplit(true);
    JSONObject jApp = new JSONObject();

    jApp.put("id", this.getIdentifier());
    //time.writeSplit(true);
    jApp.put("name", this.getName(requestor));
    //time.writeSplit(true);
    jApp.put("description", this.getDescription(requestor));
    //time.writeSplit(true);
    try {
      jApp.put("created", requestor.getSessionLogin().convertToUserTimeZone(Constants.JSON_DATE_PATTERN, this.getCreated(), TimeZone.getTimeZone("PST")));
    } catch (AIGException ex) {
      Logger.getLogger(RGApp.class.getName()).log(Level.SEVERE, null, ex);
    }
    //time.writeSplit(true);
    jApp.put("type", this.getAppType().toString());
    jApp.put("order", this.getSort());
    jApp.put("quickAppOrder", getQuickAppPos());
    jApp.putOpt("className", this.getImageCSS(requestor));
    jApp.putOpt("filterSortCategory", this.getFilterSortCategory(requestor));
    //time.writeSplit(true);

    if (this.getAttributes() != null) {
      for (RGAppAttribute attribute : this.getAttributes()) {
        JSONObject jAttributeParam = new JSONObject();
        jApp.append("attributes", jAttributeParam);
        jAttributeParam.put(attribute.getAttributeName(), attribute.getAttributeValue());
      }
    }

    if (this.getRGPageTags() != null) {
      for (RGPageTag pageTag : this.getRGPageTags()) {
        jApp.append("page_tags", pageTag.getRGPageID());
      }
    }
    //time.writeSplit(true);


    switch (getAppType()) {
      case FAVORITES_TOOL:
      case EXPLORE_TOOL:
      case VQT_TOOL:
      case LISTS_TOOL:
      case PROJECT_VIEW_TOOL:
      case PREFERENCES_TOOL:
      case DOCUMENTS_TOOL:
      case TABLE_IMPORT_TOOL:
      case STRUCTURE_SEARCH_TOOL:
      case SERVICE:
        break;
      case FAVORITE:
        jApp.put("sourceRecord", getItemRecord(requestor));
        break;
    }
    //time.writeElapsed(true);
    return jApp;
  }
}
