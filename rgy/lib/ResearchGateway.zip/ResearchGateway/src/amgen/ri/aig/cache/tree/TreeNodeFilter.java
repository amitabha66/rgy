package amgen.ri.aig.cache.tree;

import java.io.Serializable;

/**
 * @version $id$
 */
public interface TreeNodeFilter extends Serializable {
    public boolean include(String treeNodeUUID);
}
