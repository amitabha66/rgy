/*
 *   ProjectViewFilterQuery
 *   RDBData wrapper class for PV_FILTER_SORT_QUERIES
 *   $Revision: 1.1 $
 *   Created: Jeffrey McDowell, 15 Oct 2009
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.projectview;


import java.io.Serializable;
import java.lang.reflect.Field;
import java.sql.SQLException;
import java.sql.Timestamp;

import amgen.ri.aig.entitylist.EntityList;
import amgen.ri.rdb.OraSequenceField;
import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.Removeable;
import amgen.ri.rdb.SQLManagerIF;
import amgen.ri.rdb.Saveable;
import amgen.ri.rdb.XMLData;

/**
 *   RDBData wrapper class for PV_FILTER_SORT_QUERIES
 *   @version $Revision: 1.1 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class ProjectViewFilterQuery extends RdbData implements Saveable, Removeable, Serializable {
    protected OraSequenceField pv_filter_sort_id;
    protected XMLData query;
    protected int list_id;
    protected int parent_list_id;
    protected String session_user;
    protected String session_id;
    protected String sort_string;
    protected Timestamp update_date;
    protected String display_name;

    private EntityList list;
    private EntityList parentList;

    /**
     * Default Constructor
     */
    public ProjectViewFilterQuery() {
        super();
    }

    /**
     * RdbData Constructor
     */
    public ProjectViewFilterQuery(String pv_filter_sort_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.pv_filter_sort_id = new OraSequenceField(pv_filter_sort_id);
    }

    /**
     * Constructor which sets the class variables
     */
    public ProjectViewFilterQuery(String query, int list_id, int parent_list_id, String session_user,
                                  String session_id, String sort_string,
                                  SQLManagerIF sqlManager, String logonusername, String connectionPool) throws SQLException {
        super(sqlManager, logonusername, connectionPool);
        this.pv_filter_sort_id = new OraSequenceField("entity_list_seq", this);
        this.query = XMLData.valueOf(query, "query", sqlManager, connectionPool);
        this.list_id = list_id;
        this.parent_list_id = parent_list_id;
        this.session_user = session_user;
        this.session_id = session_id;
        this.sort_string = sort_string;
        this.update_date = new Timestamp(System.currentTimeMillis());
    }

    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return pv_filter_sort_id + "";
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }

    /** This method returns the name of the table. */
    protected String getTableName() {
        return "PV_FILTER_SORT_QUERIES";
    }

    /** Returns the SQL for INSERTing the object in the table */
    public String getInsertSQL() {
        return null;
    }

    /** Returns the SQL for UPDATing the object in the table */
    public String getUpdateSQL() {
        return null;
    }

    /** Returns the SQL for DELTEing the object/row in the table */
    public String getDeleteSQL() {
        return null;
    }

    /** Get value for query */
    public XMLData getQuery() {
        return (XMLData) get("query");
    }

    /** Get value for list_id */
    public int getList_id() {
        return getAsNumber("list_id").intValue();
    }

    /** Get value for parent_list_id */
    public int getParent_list_id() {
        return getAsNumber("parent_list_id").intValue();
    }

    /** Get the result EntityList for the filter */
    public EntityList getResultList() {
        if (list == null) {
            list = new EntityList(getList_id() + "", getSQLManager(), getLogonUsername(), getConnectionPool());
        }
        return list;
    }

    /** Get parent list fo the filter */
    public EntityList getParentList() {
        if (parentList == null) {
            parentList = new EntityList(getParent_list_id() + "", getSQLManager(), getLogonUsername(), getConnectionPool());
        }
        return parentList;
    }

    public String getParentListName() {
        EntityList parentList = getParentList();
        if (parentList != null && parentList.setData()) {
            return parentList.getListName();
        }
        return null;
    }

    /** Get value for session_user */
    public String getSession_user() {
        return (String) get("session_user");
    }

    /** Get value for session_id */
    public String getSession_id() {
        return (String) get("session_id");
    }

    /** Get value for sort_string */
    public String getSort_string() {
        return (String) get("sort_string");
    }

    /**
     * get value for display_name
     */
    public String getDisplay_name() {
        return (String) get("display_name");
    }

    /** Get value for update_date */
    public String getUpdate_date() {
        return (String) get("update_date");
    }

}
