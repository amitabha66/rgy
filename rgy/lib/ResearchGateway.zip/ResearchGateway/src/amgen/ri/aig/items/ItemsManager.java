/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.items;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.favorites.FavoriteFolderItem;
import amgen.ri.aig.favorites.FavoriteIF;
import amgen.ri.ldap.ActiveDirectoryLookup;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.aig.record.ItemRecord;
import amgen.ri.aig.sobj.ObjectType;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.mail.SendMessage;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.rg.config.ContextConfigurationParameters;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.*;
import java.util.*;
import java.util.zip.GZIPInputStream;

/**
 *
 * @author jemcdowe
 */
public class ItemsManager {
  private static final boolean SEND_EMAILS = true;
  private AIGBase requestor;

  public ItemsManager(AIGBase requestor) {
    this.requestor = requestor;
  }

  public JSONArray getFolderItems(int parentFolderID, boolean foldersOnly) {
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN ? := RG_ITEMS.getFolderItems(?, ?, ?); END;");
      cs.registerOutParameter(1, Types.BLOB);
      cs.setInt(2, parentFolderID);
      cs.setString(3, requestor.getSessionLogin().getRemoteUser());
      cs.setInt(4, (foldersOnly ? 1 : 0));

      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      String json = fromBlob2String(resultBlob);
      if (ExtString.hasLength(json)) {
        return new JSONArray(json);
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return new JSONArray();
  }

  public JSONArray getFolderItemsByObjectType(ObjectType.Type objectType) {
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN ? := RG_ITEMS.getFolderItemsByObjectType(?, ?, ?); END;");
      cs.registerOutParameter(1, Types.BLOB);
      cs.setNull(2, Types.VARCHAR);
      cs.setString(3, objectType.toString());
      cs.setString(4, requestor.getSessionLogin().getRemoteUser());

      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      String json = fromBlob2String(resultBlob);
      if (ExtString.hasLength(json)) {
        return new JSONArray(json);
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return new JSONArray();
  }

  public List<ItemRecord> getAllSharesItemRecords() {
    List<ItemRecord> itemRecords = new ArrayList<ItemRecord>();
    List<JSONObject> shares = getAllSharesChildFolderItems().asList();
    for (JSONObject share : shares) {
      try {
        itemRecords.add(new ItemRecord(share));
      } catch (JSONException ex) {
      }
    }
    return itemRecords;
  }

  public JSONArray getAllSharesChildFolderItems() {
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN ? := RG_ITEMS.getAllSharesChildFolderItems(?); END;");
      cs.registerOutParameter(1, Types.BLOB);
      cs.setString(2, requestor.getSessionLogin().getRemoteUser());

      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      String json = fromBlob2String(resultBlob);
      if (ExtString.hasLength(json)) {
        return new JSONArray(json);
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return new JSONArray();
  }

  public JSONArray getAllSharedChildFolderItems() {
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN ? := RG_ITEMS.getAllSharedChildFolderItems(?); END;");
      cs.registerOutParameter(1, Types.BLOB);
      cs.setString(2, requestor.getSessionLogin().getRemoteUser());

      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      String json = fromBlob2String(resultBlob);
      if (ExtString.hasLength(json)) {
        return new JSONArray(json);
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return new JSONArray();
  }

  public JSONArray getAllStarredChildFolderItems() {
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN ? := RG_ITEMS.getAllStarredItems(?); END;");
      cs.registerOutParameter(1, Types.BLOB);
      cs.setString(2, requestor.getSessionLogin().getRemoteUser());

      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      String json = fromBlob2String(resultBlob);
      if (ExtString.hasLength(json)) {
        return new JSONArray(json);
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return new JSONArray();
  }

  public ItemRecord getFolder(int folderID) {
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN ? := RG_ITEMS.getFolder(?, ?); END;");
      cs.registerOutParameter(1, Types.BLOB);
      cs.setInt(2, folderID);
      cs.setString(3, requestor.getSessionLogin().getRemoteUser());

      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      String json = fromBlob2String(resultBlob);
      return new ItemRecord(new JSONArray(json).getJSONObject(0));
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return new ItemRecord();
  }

  public JSONObject getFolderDetails(int folderID) {
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN ? := RG_ITEMS.getFolderDetails(?, ?); END;");
      cs.registerOutParameter(1, Types.BLOB);
      cs.setInt(2, folderID);
      cs.setString(3, requestor.getSessionLogin().getRemoteUser());

      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      String json = fromBlob2String(resultBlob);
      return new JSONObject(json);
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return new JSONObject();
  }

  public ItemRecord getItemRecord(int itemID) {
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN ? := RG_ITEMS.getItemDetails(?, ?); END;");
      cs.registerOutParameter(1, Types.BLOB);
      cs.setInt(2, itemID);
      cs.setString(3, requestor.getSessionLogin().getRemoteUser());

      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      String json = fromBlob2String(resultBlob);
      return new ItemRecord(new JSONObject(json));
    } catch (Exception e) {
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return new ItemRecord();
  }

  public ItemRecord getItemRecordForItemKey(int itemKey, FavoriteFolderItem.ItemType itemType) {
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN ? := RG_ITEMS.getItemDetailsByItemKey(?, ?, ?); END;");
      cs.registerOutParameter(1, Types.BLOB);
      cs.setInt(2, itemKey);
      cs.setString(3, itemType + "");
      cs.setString(4, requestor.getSessionLogin().getRemoteUser());

      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      String json = fromBlob2String(resultBlob);
      return new ItemRecord(new JSONObject(json));
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return new ItemRecord();
  }

  public FavoriteIF getItem(int itemID) {
    return getItemRecord(itemID).getItem(requestor);
  }

  public int moveFolders(List<Integer> folderIDs, int newParentFolderID) {
    Connection conn = null;
    try {
      int results = 0;
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN ? := RG_ITEMS.moveFolder(?, ?, ?); END;");
      cs.registerOutParameter(1, Types.BLOB);
      for (int folderID : folderIDs) {
        cs.setInt(2, folderID);
        cs.setInt(3, newParentFolderID);
        cs.setString(4, requestor.getSessionLogin().getRemoteUser());

        cs.execute();
        Blob resultBlob = cs.getBlob(1);
        String json = fromBlob2String(resultBlob);
        JSONObject jIndResults = new JSONObject(json);
        if (jIndResults.has("results")) {
          int indVal = jIndResults.getInt("results");
          results += indVal;
        }
      }
      cs.close();
      return results;
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return 0;
  }

  public int createFolder(int parentFolderID, String name, String description) {
    Connection conn = null;
    try {
      int results = 0;
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN ? := RG_ITEMS.createFolder(?, ?, ?, ?); END;");
      cs.registerOutParameter(1, Types.BLOB);
      cs.setInt(2, parentFolderID);
      cs.setString(3, name);
      cs.setString(4, description);
      cs.setString(5, requestor.getSessionLogin().getRemoteUser());

      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      String json = fromBlob2String(resultBlob);
      JSONObject jIndResults = new JSONObject(json);
      if (jIndResults.has("results")) {
        int indVal = jIndResults.getInt("results");
        results += indVal;
      }

      cs.close();
      return results;
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return 0;
  }

  public int renameFolder(int folderID, String name, String description) {
    Connection conn = null;
    try {
      int results = 0;
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN ? := RG_ITEMS.renameFolder(?, ?, ?, ?); END;");
      cs.registerOutParameter(1, Types.BLOB);
      cs.setInt(2, folderID);
      cs.setString(3, name);
      cs.setString(4, description);
      cs.setString(5, requestor.getSessionLogin().getRemoteUser());

      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      String json = fromBlob2String(resultBlob);
      JSONObject jIndResults = new JSONObject(json);
      if (jIndResults.has("results")) {
        int indVal = jIndResults.getInt("results");
        results += indVal;
      }

      cs.close();
      return results;
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return 0;
  }

  public int renameItem(int itemID, String name, String description) {
    Connection conn = null;
    try {
      int results = 0;
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN ? := RG_ITEMS.renameItem(?, ?, ?, ?); END;");
      cs.registerOutParameter(1, Types.BLOB);
      cs.setInt(2, itemID);
      cs.setString(3, name);
      cs.setString(4, description);
      cs.setString(5, requestor.getSessionLogin().getRemoteUser());

      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      String json = fromBlob2String(resultBlob);
      JSONObject jIndResults = new JSONObject(json);
      if (jIndResults.has("results")) {
        int indVal = jIndResults.getInt("results");
        results += indVal;
      }
      cs.close();
      return results;
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return 0;
  }

  public int toggleItemStar(int itemID) {
    Connection conn = null;
    try {
      int results = 0;
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN ? := RG_ITEMS.toggleItemStar(?, ?); END;");
      cs.registerOutParameter(1, Types.BLOB);
      cs.setInt(2, itemID);
      cs.setString(3, requestor.getSessionLogin().getRemoteUser());

      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      String json = fromBlob2String(resultBlob);
      JSONObject jIndResults = new JSONObject(json);
      if (jIndResults.has("results")) {
        int indVal = jIndResults.getInt("results");
        results += indVal;
      }
      cs.close();
      return results;
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return 0;
  }

  public int moveFolderItems(List<Integer> itemIDs, int newParentFolderID) {
    Connection conn = null;
    try {
      int results = 0;
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN ? := RG_ITEMS.moveFolderItem(?, ?, ?); END;");
      cs.registerOutParameter(1, Types.BLOB);
      for (int itemID : itemIDs) {
        cs.setInt(2, itemID);
        cs.setInt(3, newParentFolderID);
        cs.setString(4, requestor.getSessionLogin().getRemoteUser());

        cs.execute();
        Blob resultBlob = cs.getBlob(1);
        String json = fromBlob2String(resultBlob);
        JSONObject jIndResults = new JSONObject(json);
        if (jIndResults.has("results")) {
          int indVal = jIndResults.getInt("results");
          results += indVal;
        }
      }
      cs.close();
      return results;
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return 0;
  }

  public int deleteFolders(List<Integer> folderIDs) {
    Connection conn = null;
    try {
      int results = 0;
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN RG_ITEMS.delete_folder(?, ?, ?); END;");
      cs.registerOutParameter(3, Types.VARCHAR);
      for (int folderID : folderIDs) {
        cs.setInt(1, folderID);
        cs.setString(2, requestor.getSessionLogin().getRemoteUser());
        cs.execute();
        String message = cs.getString(3);
      }
      cs.close();
      return results;
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
      syncItemsAsynchronously();
    }
    return 0;
  }

  public int deleteFolderItems(List<Integer> itemIDs) {
    Connection conn = null;
    try {
      int results = 0;
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN RG_ITEMS.delete_folder_item(?, ?, ?); END;");
      cs.registerOutParameter(3, Types.VARCHAR);
      for (int itemID : itemIDs) {
        cs.setInt(1, itemID);
        cs.setString(2, requestor.getSessionLogin().getRemoteUser());

        cs.execute();
        String message = cs.getString(3);
      }
      cs.close();
      return results;
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
      syncItemsAsynchronously();
    }
    return 0;
  }

  public int shareItem(ItemRecord itemRecord, List<String> shareWiths) {
    int count = 0;
    if (itemRecord.exists()) {
      String delimitedShareWith = ExtString.join(shareWiths, ';');
      count += shareItem(itemRecord.getId(), delimitedShareWith);
    }
    return count;
  }

  public int shareItem(ItemRecord itemRecord, String shareWithName) {
    return shareItem(itemRecord.getId(), shareWithName);
  }

  public int shareItem(int itemID, String shareWith) {
    Connection conn = null;
    try {
      int results = 0;
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      CallableStatement cs = conn.prepareCall("BEGIN ? := RG_ITEMS.shareItem(?, ?, ?); END;");
      cs.registerOutParameter(1, Types.BLOB);
      cs.setInt(2, itemID);
      cs.setString(3, shareWith);
      cs.setString(4, requestor.getSessionLogin().getRemoteUser());
      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      String json = fromBlob2String(resultBlob);
      JSONObject jShareResponse = new JSONObject(json);
      
      List<JSONObject> jAdded = jShareResponse.getJSONArray("added").asList();
      List<JSONObject> jRemoved = jShareResponse.getJSONArray("removed").asList();
      Set<String> sharedWiths = new HashSet<String>();

      for (JSONObject jAdd : jAdded) {
        notifyOfSharedItem(itemID, jAdd.getString("name"));
        sharedWiths.add(jAdd.getString("name"));
      }
      if (!sharedWiths.isEmpty()) {
        notifyShareeOfSharedFavorite(itemID, sharedWiths);
      }
      cs.close();
      return results;
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
      syncItemsAsynchronously();
    }
    return 0;
  }

  /**
   * Sends an email to those with whom the favorite as been shared
   *
   * @param sharedFavorites List
   * @throws AIGException
   * @throws MalformedURLException
   */
  public void notifyOfSharedItem(int itemID, String sharedWith) throws AIGException, MalformedURLException, Exception {
    String template = ConfigurationParameterSource.getConfigParameter("shared_favorite_email_template");

    URL url = new URL(requestor.getHttpServletRequest().getRequestURL().toString());
    switch (ContextConfigurationParameters.getInstance().getRGVersion()) {
      case PROD:
        url = new URL("http", url.getHost(), 9090, "/aig/jsp/aig.jsp");
        break;
      default:
        url = new URL("http", url.getHost(), url.getPort(), "/aig/jsp/aig.jsp");
        break;
    }
    PersonRecordIF shareWithRecord = new ActiveDirectoryLookup().lookup(sharedWith);

    JSONObject jDetails = getItemRecord(itemID);
    String name = jDetails.getString("name");
    String desc = jDetails.optString("description", "");

    String subject = "Research Gateway Notification: Shared Item";
    String message = ExtString.applyTemplate(template, new String[]{
              requestor.getSessionLogin().getUserPreferredDisplayName(),
              name, (ExtString.hasLength(desc) ? "(" + desc + ")" : ""),
              url + "?item_id=" + itemID
            });

    SendMessage messenger = new SendMessage(requestor.getHttpServletRequest().getSession(true).getServletContext());
    try {
      // **************************************************************
      // Change the to ACTUAL Send!!!!!!
      if (SEND_EMAILS) {
        messenger.sendHTMLMessage(new String[]{shareWithRecord.getEmail()}, null, null, requestor.getSessionLogin().getActiveDirectoryEntry().getEmail(), subject, message);
      } else {
        Debug.print("Send Message to: " + shareWithRecord.getEmail());
        Debug.print("Subject: " + subject);
        Debug.print("Message: " + message);
      }
      // **************************************************************
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  /**
   * Sends an email to those with whom the favorite as been shared
   *
   * @param sharedFavorites List
   * @throws AIGException
   * @throws MalformedURLException
   */
  public void notifyShareeOfSharedFavorite(int itemID, Collection<String> sharedWiths) throws AIGException, MalformedURLException, Exception {
    String template = ConfigurationParameterSource.getConfigParameter("you_shared_favorite_email_template");

    URL url = new URL(requestor.getHttpServletRequest().getRequestURL().toString());
    switch (ContextConfigurationParameters.getInstance().getRGVersion()) {
      case PROD:
        url = new URL("http", url.getHost(), 9090, "/aig/jsp/aig.jsp");
        break;
      default:
        url = new URL("http", url.getHost(), url.getPort(), "/aig/jsp/aig.jsp");
        break;
    }

    JSONObject jDetails = getItemRecord(itemID);
    String name = jDetails.getString("name");
    String desc = jDetails.optString("description", "");

    Set<String> shareWithDisplayNames = new HashSet<String>();
    for (String sharedWith : sharedWiths) {
      PersonRecordIF shareWithRecord = new ActiveDirectoryLookup().lookup(sharedWith);
      shareWithDisplayNames.add(shareWithRecord.getDisplayName());
    }
    String subject = "Research Gateway Notification: Your Shared Item";
    String message = ExtString.applyTemplate(template, new String[]{
              ExtString.join(shareWithDisplayNames, ";"), name, (ExtString.hasLength(desc) ? "(" + desc + ")" : ""), url + "?item_id=" + itemID
            });

    SendMessage messenger = new SendMessage(requestor.getHttpServletRequest().getSession(true).getServletContext());
    try {

      // **************************************************************
      // Change the to ACTUAL Send!!!!!!
      if (SEND_EMAILS) {
        messenger.sendHTMLMessage(new String[]{requestor.getSessionLogin().getActiveDirectoryEntry().getEmail()}, null, null, requestor.getSessionLogin().getActiveDirectoryEntry().getEmail(), subject, message);
      } else {
        Debug.print("Send Message to: " + requestor.getSessionLogin().getActiveDirectoryEntry().getEmail());
        Debug.print("Subject: " + subject);
        Debug.print("Message: " + message);
      }
      // **************************************************************
    } catch (Exception ex) {
      // ex.printStackTrace();
    }
  }

  public void syncItemsAsynchronously() {
    new Thread(new Runnable() {
      public void run() {
        Connection conn = null;
        try {
          conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
          CallableStatement cs = conn.prepareCall("BEGIN RG_ITEMS.QUICKSYNCFOLDERITEMS; END;");
          cs.execute();
        } catch (Exception e) {
          e.printStackTrace();
        } finally {
          OraSQLManager.closeResources(conn);
        }
      }
    }).start();
  }

  /**
   * Get the value of requestor
   *
   * @return the value of requestor
   */
  public AIGBase getRequestor() {
    return requestor;
  }

  public String fromBlob2String(Blob b) throws SQLException {
    InputStream in = null;
    ByteArrayOutputStream bytesOut = null;
    try {
      in = b.getBinaryStream();
      bytesOut = new ByteArrayOutputStream();
      byte[] bytes = new byte[1025];
      int byteCount = -1;
      while ((byteCount = in.read(bytes)) > 0) {
        bytesOut.write(bytes);
      }
      in.close();
      bytesOut.close();
      ObjectInputStream objIN = new ObjectInputStream(new GZIPInputStream(new ByteArrayInputStream(bytesOut.toByteArray())));
      return (String) objIN.readObject();
    } catch (Exception e) {
    } finally {
      try {
        in.close();
      } catch (Exception e) {
      }
      try {
        bytesOut.close();
      } catch (Exception e) {
      }
    }
    return new String();
  }
}
