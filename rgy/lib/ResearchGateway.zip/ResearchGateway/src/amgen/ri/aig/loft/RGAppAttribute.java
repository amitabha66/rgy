
/*
 *   Rg_App_Attributes
 *   RDBData wrapper class for ACCESS_CONTROL
 *   $Revision: 1.6 $
 *   Created: Jeffrey McDowell, 14 Dec 2011
 *   Modified: $Author: jemcdowe $
 *   $Log
 *
 */
package amgen.ri.aig.loft;

import java.lang.reflect.Field;
import amgen.ri.rdb.*;
import amgen.ri.util.ExtString;

/**
 * RDBData wrapper class for ACCESS_CONTROL
 *
 * @version $Revision: 1.6 $
 * @author Jeffrey McDowell
 * @author $Author: jemcdowe $
 */
public class RGAppAttribute extends RdbData implements Saveable, Removeable {
  protected OraSequenceField rg_app_attribute_id;
  protected int rg_app_id;
  protected String attribute_name;
  protected String attribute_value;

  /**
   * Default Constructor
   */
  public RGAppAttribute() {
    super();
  }

  /**
   * RdbData Constructor
   */
  public RGAppAttribute(String rg_app_attribute_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
    this.rg_app_attribute_id = new OraSequenceField(rg_app_attribute_id);
  }

  /**
   * Constructor which sets the class variables
   */
  public RGAppAttribute(RGApp rgApp, AppAttributeType attributeType, String attribute_value) {
    super(rgApp.getSQLManager(), rgApp.getLogonUsername(), rgApp.getConnectionPool());
    this.rg_app_attribute_id = new OraSequenceField("RG_APP_ATTRIBUTE_SEQ", this);
    this.rg_app_id = new Integer(rgApp.getIdentifier());
    this.attribute_name = attributeType.toString();
    this.attribute_value = attribute_value;
    setIsDataSet(true, true);

  }

  /**
   * A required method which returns the primary key(s) of the table/RdbData
   * class.
   */
  public String getIdentifier() {
    return rg_app_attribute_id + "";
  }

  /**
   * This method is required EXACTLY as written to allow the RdbData
   * architecture access to the class variables.
   */
  protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
    field.set(this, value);
  }

  /**
   * This method is required EXACTLY as written to allow the RdbData
   * architecture access to the class variables.
   */
  protected Object getFieldValue(Field field) throws IllegalAccessException {
    return field.get(this);
  }

  public String getTableName() {
    return "RG_APP_ATTRIBUTES";
  }

  /**
   * Returns the SQL for INSERTing the object in the table
   */
  public String getInsertSQL() {
    return null;
  }

  /**
   * Returns the SQL for UPDATing the object in the table
   */
  public String getUpdateSQL() {
    return null;
  }

  /**
   * Returns the SQL for DELTEing the object/row in the table
   */
  public String getDeleteSQL() {
    return null;
  }

  /**
   * Get value for rg_app_id
   */
  public int getRg_app_id() {
    return getAsNumber("rg_app_id").intValue();
  }

  /**
   * Get value for attribute_name
   */
  public String getAttributeName() {
    return (String) get("attribute_name");
  }

  /**
   * Set value for attribute_name
   */
  public void setAttributeName(String attribute_name) {
    set("attribute_name", attribute_name);
  }

  /**
   * Get value for attribute_value
   */
  public String getAttributeValue() {
    return (String) get("attribute_value");
  }

  /**
   * Get value for attribute_value as an Integer
   */
  public int getAttributeIntegerValue() {
    return ExtString.toInteger(getAttributeValue());
  }

  /**
   * Set value for attribute_value
   */
  public void setAttributeValue(String attribute_value) {
    set("attribute_value", attribute_value);
  }
}
