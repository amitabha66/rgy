package amgen.ri.aig.sm.structure;

import java.io.ObjectStreamException;

public enum ChemMolIDType {
    ROOT_NUMBER, AMGEN_NAME, SUBSTANCE_ID, CDBREGNO, ID, SMILES, MOL, IMAGE, UNKNOWN;

    public static ChemMolIDType fromString(String s) {
        if (s == null) {
            return UNKNOWN;
        }
        try {
            return ChemMolIDType.valueOf(s.toUpperCase());
        } catch (Exception e) {
            return UNKNOWN;
        }
    }

    /**
     * This is necessary to permit Serializable.
     * A Serialized object containing an enum class variable is not de-Serialized properly.
     * This forces de-Serialized enum to be re-created as this enum through the String
     * @return Object
     * @throws ObjectStreamException
     */
    public Object readResolve() throws ObjectStreamException {
        return ChemMolIDType.fromString(this.toString());
    }


}
