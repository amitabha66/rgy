package amgen.ri.aig.projectview.model;

import java.util.ArrayList;
import java.util.List;

import org.jdom.Element;

import amgen.ri.util.ExtString;

/**
 * Contains an assay list used in the project view
 */
public class ProjectViewAssayList extends ProjectViewList {
    private List<ProjectViewAssay> assays;
    private boolean isAuthList;
    private boolean isInvivoPKAuthList;

    protected ProjectViewAssayList(Element viewElement) {
        super(viewElement.getAttributeValue("id"), viewElement.getAttributeValue("name"));
        isAuthList = ExtString.equals(viewElement.getAttributeValue("isAuth"), "true");
        isInvivoPKAuthList= (isAuthList && ExtString.alphaNumericsEqualIgnoreCase(getName(), "in vivo PK"));
        isDefault(true);
        assays = new ArrayList<ProjectViewAssay>();
        List<Element> assayEls = viewElement.getChildren("Assay");
        for (Element assayEl : assayEls) {
            assays.add(new ProjectViewAssay(assayEl));
        }
    }

    public List<ProjectViewAssay> getAssays() {
        return assays;
    }

    public boolean isInvivoPKAuthList() {
        return isInvivoPKAuthList;
    }
}
