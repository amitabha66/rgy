/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.json;

import java.util.Date;

/**
 *
 * @author jemcdowe
 */
public interface JSONCacheItemFilterMatcherIF {  
  public boolean matchDate(Date testDate);

  public boolean matchList(Object testValue);

  public boolean matchNumeric(Double testNumber);

  public boolean matchString(String testString);
}
