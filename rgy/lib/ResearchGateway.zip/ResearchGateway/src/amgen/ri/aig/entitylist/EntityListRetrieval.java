package amgen.ri.aig.entitylist;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.tree.TreeNodeCache;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.CompareTerm;
import amgen.ri.rdb.InCompareTerm;
import amgen.ri.rdb.NullCompareTerm;
import amgen.ri.rdb.RdbDataArray;

public class EntityListRetrieval extends AIGServlet {
    private EntityListRetrievalType entityListRetrievalType;
    public EntityListRetrieval() {
        super();
    }

    public EntityListRetrieval(HttpServletRequest req, HttpServletResponse resp) {
        super(req, resp);
        this.entityListRetrievalType = EntityListRetrievalType.valueOf(req);
    }

    /**
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return TBXServlet
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new EntityListRetrieval(req, resp);
    }

    /**
     *
     * @return String
     */
    protected String getServletMimeType() {
        switch (entityListRetrievalType) {
            case ALL_COMPOUND_LISTS:
                return "text/json";
            default:
                return "text/xml";
        }
    }

    /**
     *
     * @throws Exception
     */
    protected void performRequest() throws Exception {
        try {
            switch (entityListRetrievalType) {
                case ALL_COMPOUND_LISTS:
                    JSONObject compoundLists = getCompoundLists(false);
                    compoundLists.write(response.getWriter());

                    //Debug.print(compoundLists);
                    return;
                default:
                    String listID = getParameter("list_id");
                    String listCategory = getParameter("list_category");
                    Element entityListsEl = new Element("EntityLists");
                    if (listID != null) {
                        EntityList entityList = new EntityList(listID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
                        if (entityList.setData()) {
                            entityListsEl.addContent(entityList.getAsElement(true, request));
                        }
                    } else if (listCategory != null) {
                        CompareTerm userTerm = new CompareTerm("created_by", getSessionLogin().getRemoteUser());
                        CompareTerm categoryTerm = new CompareTerm("list_category", listCategory.toUpperCase());
                        CompareTerm typeTerm = new NullCompareTerm("list_type", true);

                        List<EntityList> lists = new RdbDataArray(EntityList.class, new CompareTerm[] {
                            userTerm, categoryTerm, typeTerm
                        }, new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
                        for (EntityList list : lists) {
                            entityListsEl.addContent(list.getAsElement(request));
                        }
                    } else {
                        CompareTerm userTerm = new CompareTerm("created_by", getSessionLogin().getRemoteUser());
                        CompareTerm typeTerm = new NullCompareTerm("list_type", true);

                        List<EntityList> lists = new RdbDataArray(EntityList.class, new CompareTerm[] {
                            userTerm, typeTerm
                        }, new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
                        for (EntityList list : lists) {
                            entityListsEl.addContent(list.getAsElement(request));
                        }
                    }
                    new XMLOutputter().output(entityListsEl, response.getWriter());
            }
        } catch (Exception e) {
            response.sendError(response.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    /**
     * Gets the user-defined compound lists and load them into the compoundLists and compoundListIDs collections
     * @return Map
     */
    public JSONObject getCompoundLists(boolean includeResultNodes) throws AIGException, JSONException {
        JSONObject compoundLists = new JSONObject();

        if (doesParameterExist("view_id", true)) {
            CompareTerm listCategoryTerm = new InCompareTerm("list_category",
                    new String[] {"COMPOUNDS", "COMPOUNDS-DEFAULT", "COMPOUNDS-SESSION"});
            CompareTerm entityListMembersIDTerm = new CompareTerm("entity_list_members_id", getParameter("view_id"));

            List<EntityList> lists = new RdbDataArray(EntityList.class, new CompareTerm[] {
                listCategoryTerm, entityListMembersIDTerm
            }, new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
            for (EntityList list : lists) {
                if (list.setData()) {
                    JSONObject compoundList = new JSONObject();
                    compoundList.put("compound_list_id", list.getIdentifier());
                    compoundList.put("compound_list_name", list.getListName());
                    compoundList.put("compound_list_type", (list.getListType() == null ? "PRIVATE" : list.getListType()));
                    compoundLists.append("CompoundLists", compoundList);
                }
            }
        }
        //Current COMPOUNDS result sets
        if (includeResultNodes) {
            try {
                TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(getHttpServletRequest());
                List<String> resultNodeKeys = tnCache.getRootChildTreeNodeKeys(EntityListCategory.COMPOUNDS);
                Collections.reverse(resultNodeKeys);
                for (String resultNodeKey : resultNodeKeys) {
                    Element treeNode = tnCache.getTreeNode(resultNodeKey);
                    String treeNodeText = treeNode.getAttributeValue("TEXT");
                    List<String> entityChildNodeKeys = tnCache.getChildTreeNodeKeys(resultNodeKey);
                    String text = treeNodeText + " [" + entityChildNodeKeys.size() + "]";
                    JSONObject compoundList = new JSONObject();
                    compoundList.put("compound_list_id", resultNodeKey);
                    compoundList.put("compound_list_name", text);
                    compoundList.put("compound_list_type", "RESULTNODE");
                    compoundLists.append("CompoundLists", compoundList);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        //Current user's private lists
        Map<Integer, GenericEntityList> listMap =
                EntityList.getBasicEntityListInfo(ServiceDataCategory.AMGEN_ROOT_ID, getSessionLogin().getRemoteUser());
        for (int list_id : listMap.keySet()) {
            GenericEntityList list = listMap.get(list_id);
            JSONObject compoundList = new JSONObject();
            compoundList.put("compound_list_id", list_id + "");
            compoundList.put("compound_list_name", list.getListName());
            compoundList.put("compound_list_type", "PRIVATE");
            compoundLists.append("CompoundLists", compoundList);

        }
        return compoundLists;
    }


}
