package amgen.ri.aig.entityrules;

import java.util.Collection;
import java.util.Map;

import amgen.ri.aig.cache.tree.TreeNode;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.entitylist.EntityListMemberIF;

/**
 * Class used to enforce business rules when processing nodes or
 * EntityListMembers for an EntityType
 *
 * @version $id$
 */
public interface EntityRulesIF {
    public TreeNode applyEntityRules(TreeNode node);

    public EntityListMemberIF applyEntityRules(EntityListMemberIF member, ServiceDataCategory memberServiceDataCategory);

    public String applyEntityRules(String id, ServiceDataCategory memberServiceDataCategory);

    /**
     * Apply EntityRule to a list of IDs and return a Map of
     * Original ID:Translated ID
     *
     * @param ids List
     * @param memberServiceDataCategory ServiceDataCategory
     * @return Map
     */
    public Map<String, String> applyEntityRules(Collection<String> ids, ServiceDataCategory memberServiceDataCategory);
}
