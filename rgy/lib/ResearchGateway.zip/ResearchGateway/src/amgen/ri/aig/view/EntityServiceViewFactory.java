package amgen.ri.aig.view;

import java.util.HashSet;
import java.util.Set;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.projectview.ProjectViewServiceView;

/**
 * Factory used to create the approproiate viewer for the entity service
 */
public class EntityServiceViewFactory {
    public static EntityServiceView getEntityServiceView(AIGServlet aigServlet, String resultTypeName) throws AIGException {
        if (resultTypeName.equalsIgnoreCase(TModelCommonNameFactory.HTMLDEFINITION_tMODELNAME)) {
            return new EntityServiceHTMLView(aigServlet);
        } else if (resultTypeName.equals(TModelCommonNameFactory.PROJECTVIEWDEFINITION_tMODELNAME)) {
            return new ProjectViewServiceView(aigServlet);
        } else if (resultTypeName.equals(TModelCommonNameFactory.MSEXCELXMLDEFINITION_tMODELNAME)) {
            return new EntityServiceExcelView(aigServlet);
        } else if (resultTypeName.equals(TModelCommonNameFactory.RGDDHTMLDEFINITION_tMODELNAME)) {
            return new EntityServiceHTMLView(aigServlet);
        }
        throw new AIGException("RG does not support requested result type", AIGException.Reason.UNABLE_TO_RUN_SERVICE);
    }

    public static Set getResultTypeNames() {
        return new HashSet();
    }

}
