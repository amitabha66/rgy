package amgen.ri.aig.entitytable;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.AIGResponseMessage;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.tree.TreeNodeCache;
import amgen.ri.aig.cache.item.EntityTableCacheItem;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.aig.category.schema2.ExportTargetType;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.entity.assay.AssayResultTypeOperations;
import amgen.ri.aig.entitytable.category.schema2.ColumnType;
import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;
import amgen.ri.aig.entitytable.exporter.EntityTableExport3;
import amgen.ri.aig.entitytable.loader.EntityLoaderFactory;
import amgen.ri.aig.entitytable.loader.EntityTableLoaderIF;
import amgen.ri.aig.export.ExportUtils;
import amgen.ri.aig.favorites.Favorite;
import amgen.ri.aig.favorites.FavoriteFolderItem;
import amgen.ri.aig.favorites.FavoriteManager;
import amgen.ri.aig.image.ChemImageHandler;
import amgen.ri.aig.items.ItemsManager;
import amgen.ri.aig.jawr.JawrLinkRenderer;
import amgen.ri.aig.preferences.PreferenceManager;
import amgen.ri.aig.record.ItemRecord;
import amgen.ri.aig.scripts.AvailableScriptMethods;
import amgen.ri.aig.scripts.SavedScriptsMethods;
import amgen.ri.aig.scripts.XMLSavedScriptMethods;
import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.aig.sobj.ObjectType;
import amgen.ri.aig.sobj.SavedObject;
import amgen.ri.aig.sv.EntityServiceInvoker;
import amgen.ri.asf.sa.uddi.*;
import amgen.ri.html.GenericHTMLElement;
import amgen.ri.html.HTMLElement;
import amgen.ri.html.Image;
import amgen.ri.html.Span;
import amgen.ri.html.Table;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.rg.config.ConfigurationParameterInstanceType;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.util.ExtFile;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.mozilla.javascript.RhinoException;

/**
 * Handler for the EntityTable requests. Request types are defined in the
 * EntityTableRequest enum
 */
public class EntityTableHandler extends AIGServlet {

  private EntityTableRequest entityTableRequest;
  private String entityTableKey;
  private EntityTableCacheItem entityTableCacheItem;

  public EntityTableHandler() {
    super();
  }

  public EntityTableHandler(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
    entityTableRequest = EntityTableRequest.valueOf(request);
    entityTableKey = getParameter("entityTableKey");
    entityTableCacheItem = ServiceCache.getServiceCache(request).getEntityTableResult(entityTableKey);
  }

  /**
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return TBXServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new EntityTableHandler(req, resp);
  }

  /**
   *
   * @return String
   */
  protected String getServletMimeType() {
    switch (entityTableRequest) {
      case EXPORT:
        switch (ExportTargetType.fromString(getParameter("target"))) {
          case EXCEL:
            return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
          case SPOTFIRE:
            return "application/vnd.spotfire.stdf";
          case SDFILE:
            return "chemical/x-mdl-sdfile";
          default:
            return "text/html";
        }
      default:
        return "text/html";
    }
  }

  /**
   *
   * @throws Exception
   */
  protected void performRequest() throws Exception {
    //printRequest();
    AIGSessionLogin sessionLogin = AIGSessionLogin.getAIGSessionLogin(request);
    EntityTableCellFormatterIF defaultFormatter = new DefaultEntityTableCellFormatter();

    //A bunch of common parameters- not all used in every request
    String resultKey = getParameter("resultKey");
    String serviceKey = getParameter("serviceKey");
    String sortDataIndex = getParameter("sort");
    String sortDirection = getParameter("dir");
    String columnDataIndex = getParameter("columnDataIndex");
    String columnGroupDataIndex = getParameter("columnGroupDataIndex");
    String columnGroupHeader = getParameter("columnGroupHeader");
    Number pagedRowIndex = getParameterNumber("pagedRowIndex");
    String newColumnHeader = getParameter("columnHeader");
    String value = getParameter("value");
    String importValues = getParameter("importValues");
    int columnGroupLevel = getParameterNumber("columnGroupLevel", 0).intValue();
    boolean caseSensitive = (getParameter("caseSensitive") == null ? false : getParameter("caseSensitive").equalsIgnoreCase("yes"));
    Number start = getParameterNumber("start");
    Number pageSize = getParameterNumber("limit");
    ServiceDetails service = ServiceCache.getServiceCache(request).getService(serviceKey);

    //Common variables
    EntityTable entityTable;
    JSONObject entityTableConfig;
    JSONObject noResultsJObj;
    SavedObject savedTable;
    Column column;
    DataRow row;
    DataCell cell;
    int columnIndex;

    ServiceDataCategory tableServiceDataCategory = ServiceDataCategory.UNKNOWN;
    if (entityTableCacheItem != null && entityTableCacheItem.getEntityTable() != null) {
      tableServiceDataCategory = getEntityClassManager().convertEntityListCategoryToServiceDataCategory(entityTableCacheItem.getEntityTable().getEntityCategory());
    }
    //Handles Standard Requests
    switch (entityTableRequest) {
      case NEW:
        response.setContentType(getServletMimeType());
        HTMLElement html = createRGHTMLElement("Entity Table", ExtJSVersion.VERSION_3);
        HTMLElement body = (HTMLElement) html.addMemberElement(new GenericHTMLElement("BODY"));
        body.addMemberElement("SCRIPT").setText("document.domain='amgen.com'");
        try {
          entityTableCacheItem = createEntityTable(resultKey, entityTableRequest);
          if (entityTableCacheItem == null) {
            throw new AIGException("Unable To Retrieve Results For Table", Reason.UNABLE_TO_RETRIEVE_ENTRY);
          }
        } catch (Exception e) {
          addCoreExtJsScripts(body, ExtJSVersion.VERSION_3, null);
          fileSetManager.appendScripts(body, "supplemental_imports");

          JawrLinkRenderer jawrLinkRenderer = new JawrLinkRenderer(this);
          jawrLinkRenderer.appendScriptLinks("/bundles/rgcore.js", body);
          jawrLinkRenderer.appendScriptLinks("/bundles/rgmainresources.js", body);
          jawrLinkRenderer.appendScriptLinks("/bundles/rgtableview.js", body);

          body.addMemberElement(AIGResponseMessage.getHTMLErrorElement("EntityTableView", "Entity Table Error", e.getMessage()));
          html.write(response.getWriter());
          e.printStackTrace();
          return;
        }

        HTMLElement loadingDiv = (HTMLElement) body.addMemberElement(new GenericHTMLElement("DIV"));
        loadingDiv.setId("init-loading");
        loadingDiv.setClassName("init-loading");
        Table loadingIndicatorDiv = (Table) loadingDiv.addMemberElement(new Table());
        Table.TableRow tableRow = loadingIndicatorDiv.addRow();
        Table.TableCell tableCell = tableRow.addCell();
        tableCell.addAttribute("VALIGN", "MIDDLE");
        Image loadingIndicatorImg = (Image) tableCell.addMemberElement(new Image("http://rg-resources/ext3/resources/images/default/s.gif"));
        loadingIndicatorImg.setWidth(32);
        loadingIndicatorImg.setHeight(32);
        loadingIndicatorImg.setStyle("margin-right:8px;");
        loadingIndicatorImg.setAlign(Image.ABSMIDDLE);
        loadingIndicatorImg.setClassName("init-loading-img");
        Table.TableCell textCell= tableRow.addCell("init-loading-cell");
        textCell.addAttribute("VALIGN", "MIDDLE");
        textCell.addMemberElement(new Span("Loading View...", "init-loading"));

        addCoreExtJsScripts(body, ExtJSVersion.VERSION_3, null);
        fileSetManager.appendScripts(body, "supplemental_imports");

        JawrLinkRenderer jawrLinkRenderer = new JawrLinkRenderer(this);
        jawrLinkRenderer.appendScriptLinks("/bundles/rgcore.js", body);
        jawrLinkRenderer.appendScriptLinks("/bundles/rgmainresources.js", body);
        jawrLinkRenderer.appendScriptLinks("/bundles/rgtableview.js", body);
        addJsScripts(body, "supplemental_imports.entitytable");

        entityTableConfig = getEntityTableJSON(entityTableCacheItem, resultKey, false);
        entityTableConfig.put("entityTableKey", entityTableCacheItem.getEntityTableKey());

        HTMLElement script = (HTMLElement) body.addMemberElement(new GenericHTMLElement("SCRIPT"));
        StringWriter scriptContents = new StringWriter();
        PrintWriter scriptContentsWriter = new PrintWriter(scriptContents);
        scriptContentsWriter.println("Ext.onReady(function(){var config= {};");
        scriptContentsWriter.println("try {Ext.fly('init-loading').remove();} catch (e) {}");

        scriptContentsWriter.println("createAIGEntityTableViewport(" + entityTableConfig + ");");
        scriptContentsWriter.println("});");
        script.setText(scriptContents.toString());
        HTMLElement script2 = (HTMLElement) body.addMemberElement(new GenericHTMLElement("SCRIPT"));
        script2.setText("var sourceConfigs= " + getSourceConfigs());

        html.write(response.getWriter());
        break;
      case VALUES:
        entityTableCacheItem.getEntityTable().writeTableValuesJSON(start, pageSize, sortDataIndex, sortDirection, caseSensitive, defaultFormatter, response.getWriter());
        break;
      case COLUMNVALUES:
        column = entityTableCacheItem.getEntityTable().getColumnByDataIndex(columnDataIndex);
        entityTable = entityTableCacheItem.getEntityTable();
        if (column != null && entityTable != null) {
          JSONObject jValues = entityTable.getColumnValuesJSON(defaultFormatter, column);
          if (jValues != null) {
            jValues.write(response.getWriter());
            return;
          }
        }
        noResultsJObj = new JSONObject();
        noResultsJObj.put("values", new JSONArray());
        noResultsJObj.write(response.getWriter());
        return;
      case GETCELLIMAGE:
        entityTable = entityTableCacheItem.getEntityTable();
        if (entityTable == null || columnDataIndex == null || Double.isNaN(pagedRowIndex.doubleValue())) {
          return;
        }
        columnIndex = entityTable.getColumnIndex(columnDataIndex);
        if (columnIndex < 0) {
          return;
        }
        column = entityTable.getColumn(columnIndex);
        row = entityTable.getSortedDataRow(pagedRowIndex.intValue());
        if (row == null) {
          return;
        }
        cell = row.getDataCell(columnIndex);
        if (cell == null) {
          return;
        }
        BufferedImage img = entityTable.getCellImage(column, cell, true, this);
        if (img != null) {
          ImageIO.write(img, "png", response.getOutputStream());
        }
        return;
      case DEBUG:
        response.setContentType("text/plain");
        Document debugDoc = entityTableCacheItem.getEntityTable().createDocument(true);
        ExtXMLElement.addTextElement(debugDoc.getRootElement(), "TableJSON",
                entityTableCacheItem.getEntityTable().getEntityTableJSON(false).toString());
        ExtXMLElement.addTextElement(debugDoc.getRootElement(), "PageJSON",
                entityTableCacheItem.getEntityTable().getTableValuesJSON(start, pageSize, sortDataIndex, sortDirection, caseSensitive, defaultFormatter).toString());
        response.getWriter().println(ExtXMLElement.toPrettyString(debugDoc));
        return;
      case UPDATEFORMAT:
        boolean update = false;
        if (doesParameterExist("vnt_toggle")) {
          entityTableCacheItem.getEntityTable().getCurrentFormatter().toggleShowAssaySummary();
          //entityTableCacheItem.getEntityTable().writeTableValuesJSON(start, pageSize, sortDataIndex, sortDirection, caseSensitive, defaultFormatter, response.getWriter());
          update = true;
        } else if (!Double.isNaN(getParameterNumber("row_height").doubleValue())) {
          entityTableCacheItem.getEntityTable().setRowHeightPoints(getParameterNumber("row_height"));
          update = true;
        } else if (doesParameterExist("update_prefs")) {
          update = true;
          //Load the preferences from the saved preferences
          new PreferenceManager(this, entityTableCacheItem.getEntityTable()).setPreferences();
        } else if (getJSONObjectParameter("columnFormat") != null && columnDataIndex != null) {
          column = entityTableCacheItem.getEntityTable().getColumnByDataIndex(columnDataIndex);
          if (column != null) {
            try {
              column.setColumnFormat(new ColumnFormat(getJSONObjectParameter("columnFormat")));
              update = true;
            } catch (Exception e) {
              e.printStackTrace();
              throw new AIGException("Invalid format requested", Reason.INVALID_REQUEST, e);
            }
          }
        }
        if (update) {
          JSONObject entityTableConfig2 = getEntityTableJSON(entityTableCacheItem, resultKey, true);
          entityTableConfig2.write(response.getWriter());
        }
        break;
      case DELETECOLUMN:
        boolean deleteSuccess = false;
        if (columnGroupLevel == 0) {
          deleteSuccess = entityTableCacheItem.getEntityTable().deleteColumn(columnDataIndex);
        } else {
          deleteSuccess = entityTableCacheItem.getEntityTable().deleteColumnGroup(columnDataIndex);
        }
        if (deleteSuccess) {
          JSONObject entityTableConfig2 = getEntityTableJSON(entityTableCacheItem, resultKey, true);
          entityTableConfig2.write(response.getWriter());
        } else {
          noResultsJObj = new JSONObject();
          noResultsJObj.put("noResults", true);
          noResultsJObj.write(response.getWriter());
        }
        break;
      case XCOLUMNHEADER:
        try {
          if (columnGroupLevel == 0) {
            column = entityTableCacheItem.getEntityTable().getColumnByDataIndex(columnDataIndex);
            column.setHeaderText(newColumnHeader);
          } else {
            ColumnGroup columnGroup = entityTableCacheItem.getEntityTable().getColumnGroup(columnDataIndex);
            columnGroup.setHeaderText(newColumnHeader);
          }
          JSONObject entityTableConfig2 = getEntityTableJSON(entityTableCacheItem, resultKey, true);
          entityTableConfig2.write(response.getWriter());
        } catch (Exception e) {
          noResultsJObj = new JSONObject();
          noResultsJObj.put("noResults", true);
          noResultsJObj.write(response.getWriter());
        }
        break;
      case ADDCOLUMNBYSERVICE:
        String addColumnByServiceResultKey = UUID.randomUUID() + "";
        if (service == null) {
          return;
        }
        for (String parameterName : service.getParameterNames()) {
          ServiceParameter serviceParameter = service.getParameter(parameterName);
          String parameterValue = getParameter(parameterName);
          ServiceParameterType serviceParameterType = serviceParameter.getParameterType();
          if (serviceParameterType.equals(serviceParameterType.BOOLEAN)) {
            if (parameterValue == null) {
              service.setParameterValue(parameterName, "false");
            } else if (parameterValue.equalsIgnoreCase("false")) {
              service.setParameterValue(parameterName, "false");
            } else if (parameterValue.equalsIgnoreCase("true")) {
              service.setParameterValue(parameterName, "true");
            } else {
              service.setParameterValue(parameterName, "true");
            }
          } else if (ExtString.hasLength(parameterValue) && serviceParameterType.equals(serviceParameterType.AMGEN_ASSAYRESULT_IDENTIFIER)) {
            List<String> assayCodes = ExtString.splitToList(parameterValue, "\t");
            for (String assayCode : assayCodes) {
              String assayParameter = AssayResultTypeOperations.getInstance().createAssayParameter(assayCode);
              service.addParameterValue(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME, "Assay Identifier", assayParameter);
            }
          } else if (ExtString.hasLength(parameterValue) && !ExtString.equalsIgnoreCase(parameterValue, "undefined")
                  && !parameterValue.equals("Please select a value")) {
            if (serviceParameter.isAcceptsList()) {
              String[] listValues = request.getParameterValues(parameterName);
              for (String listValue : listValues) {
                String[] splitValues = listValue.split(";");
                for (String splitValue : splitValues) {
                  if (ExtString.hasTrimmedLength(splitValue)) {
                    serviceParameter.addValue(splitValue.trim());
                  }
                }
                serviceParameter.setParameterValueSource("list");
              }
            } else {
              service.setParameterValue(parameterName, parameterValue);
            }
          }
        }

        setSecurityServiceParameters(service);
        try {
          EntityServiceInvoker entityServiceInvoker = new EntityServiceInvoker(this);
          entityServiceInvoker.invokeServiceAndCache(service, addColumnByServiceResultKey, tableServiceDataCategory,
                  entityTableCacheItem.getEntityTable().getEntityIDs(), null, true, true);

          ServiceResultCacheItem serviceResultCacheItem = getServiceResultCacheItem(addColumnByServiceResultKey);

          if (entityTableCacheItem.getEntityTable().addServiceResult(this, serviceResultCacheItem)) {
            JSONObject entityTableConfig2 = getEntityTableJSON(entityTableCacheItem, resultKey, false);
            entityTableConfig2.write(response.getWriter());
          } else {
            noResultsJObj = new JSONObject();
            noResultsJObj.put("noResults", true);
            noResultsJObj.write(response.getWriter());
          }
        } catch (Exception e) {
          response.addHeader("RG_ERROR", "Unable to run request: " + e.getMessage());
          noResultsJObj = new JSONObject();
          noResultsJObj.put("noResults", true);
          noResultsJObj.write(response.getWriter());
        }
        break;
      case ADDSTRUCTUREDETAILS:
        if (entityTableCacheItem.getEntityTable().addStructureDetails(this)) {
          JSONObject entityTableConfig2 = getEntityTableJSON(entityTableCacheItem, resultKey, false);
          entityTableConfig2.write(response.getWriter());
        } else {
          noResultsJObj = new JSONObject();
          noResultsJObj.put("noResults", true);
          noResultsJObj.write(response.getWriter());
        }
        break;
      case REFRESHCOLUMN:
        column = entityTableCacheItem.getEntityTable().getColumnByDataIndex(columnDataIndex);
        entityTable = entityTableCacheItem.getEntityTable();
        if (column != null && entityTable != null) {
          switch (column.getColumnType()) {
            case CALCULATED:
              try {
                AvailableScriptMethods availableScriptMethods = getAvailableScriptMethods(entityTable);
                entityTable.reCalculateColumn(columnDataIndex, null, null, availableScriptMethods);
                entityTableConfig = getEntityTableJSON(entityTableCacheItem, resultKey, true);
                entityTableConfig.write(response.getWriter());
              } catch (RhinoException e) {
                JSONObject errorJObj = new JSONObject();
                errorJObj.put("noResults", true);
                errorJObj.put("scriptError", e.getMessage());
                errorJObj.put("calcConfig", getParameter("calccolumn_config"));
                errorJObj.write(response.getWriter());
              } catch (Exception e) {
                e.printStackTrace();
                JSONObject errorJObj = new JSONObject();
                errorJObj.put("noResults", true);
                errorJObj.write(response.getWriter());
              }
              return;
            default:
              break;
          }
        }
        noResultsJObj = new JSONObject();
        noResultsJObj.put("noResults", true);
        noResultsJObj.write(response.getWriter());
        return;
      case LIST:
        List<SavedObject> savedObjects = SavedObject.getSavedObjects(ObjectType.ENTITYTABLE, sessionLogin.getRemoteUser(),
                JDBCNamesType.RG_JDBC + "");
        JSONArray savedObjectsJSArr = new JSONArray();
        if (savedObjects.size() > 0) {
          for (SavedObject savedObject : savedObjects) {
            JSONObject savedObjectJS = new JSONObject();
            savedObjectsJSArr.put(savedObjectJS);
            savedObjectJS.put("id", savedObject.getIdentifier());
            savedObjectJS.put("name", savedObject.getName());
            savedObjectJS.put("description", savedObject.getDescription());
            savedObjectJS.put("created_by", sessionLogin.getUserLedgerDisplayName(savedObject.getCreated_by()));
            savedObjectJS.put("created", sessionLogin.convertToUserTimeZone(DATE_FORMAT, savedObject.getCreated(), sessionLogin.getUsersTimeZone()));
            savedObjectJS.put("modified_by", sessionLogin.getUserLedgerDisplayName(savedObject.getModified_by()));
            savedObjectJS.put("modified", sessionLogin.convertToUserTimeZone(DATE_FORMAT, savedObject.getModified(), sessionLogin.getUsersTimeZone()));
          }
        }
        JSONObject savedObjectsJS = new JSONObject();
        savedObjectsJS.put("saved_objects", savedObjectsJSArr);
        savedObjectsJS.write(response.getWriter());
        break;
      case DELETE:
        List<String> tableIdList = getParameters("table_id");
        String[] tableIds = (String[]) tableIdList.toArray(new String[0]);
        List<SavedObject> deleteSavedObjects = new RdbDataArray(SavedObject.class, tableIds, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");

        JSONArray deleteObjectsJSArr = new JSONArray();
        int countDeleted = 0;
        for (SavedObject deleteSavedObject : deleteSavedObjects) {
          if (deleteSavedObject.performDelete() > 0) {
            countDeleted++;
          }
        }

        JSONObject deleteObjectsJS = new JSONObject();
        deleteObjectsJS.put("deleted_objects", countDeleted);
        deleteObjectsJS.write(response.getWriter());
        break;
      case IMPORT:
        entityTable = entityTableCacheItem.getEntityTable();
        int importCount = 0;

        if (entityTable != null && ExtString.hasLength(importValues)) {
          List<String> importList = ExtString.splitToList(importValues, "[\\r\\n]+");
          EntityTableLoaderIF loader = EntityLoaderFactory.getEntityTableLoader(this, entityTable.getEntityCategory());
          importCount = loader.addEntitiesToEntityTable(entityTable, importList);
        }

        if (importCount > 0) {
          JSONObject entityTableConfig2 = getEntityTableJSON(entityTableCacheItem, resultKey, true);
          entityTableConfig2.write(response.getWriter());
        } else {
          JSONObject noImportJObj = new JSONObject();
          noImportJObj.put("noResults", true);
          noImportJObj.write(response.getWriter());
        }
        break;
      case EXPORT:
        switch (ExportTargetType.fromString(getParameter("target"))) {
          case EXCEL:
            try {
              EntityTableExport3 entityTableExport = new EntityTableExport3(entityTableCacheItem.getEntityTable(), this);
              entityTableExport.exportToExcel();
            } finally {
            }
            break;
          case SPOTFIRE:
            try {
              String exportName = entityTableCacheItem.getEntityTable().getTableName(true);
              if (exportName == null) {
                exportName = "Export";
              }
              Document tableDoc = entityTableCacheItem.getEntityTable().createDocument(true);
              ServiceDetails sfService = getLooselyCoupledServiceDetails("ENTITYTABLE2SPOTFIRE");
              sfService.addParameterValue("xml", ExtXMLElement.toString(tableDoc));
              response.addHeader("Content-disposition", "attachment; filename=" + exportName.replaceAll("\\s+", "_") + ".stdf");
              String stdfFile = sfService.executeService2String();
              response.getWriter().write(stdfFile);
              response.getWriter().flush();
            } finally {
            }
            break;
          case SDFILE:
            try {
              EntityTableExport3 entityTableExport = new EntityTableExport3(entityTableCacheItem.getEntityTable(), this);
              entityTableExport.exportToSDFile();
            } finally {
            }
            break;
          case SERVICE:
            try {
              if (ExtString.hasLength(serviceKey)) {
                ExportUtils exportUtils = new ExportUtils();
                String exportName = entityTableCacheItem.getEntityTable().getTableName(true);
                if (exportName == null) {
                  exportName = "Export";
                }
                Document tableDoc = entityTableCacheItem.getEntityTable().createDocument(true);
                ServiceDetails exportService = ServiceCache.getServiceCache(request).getService(serviceKey);

                Categorization rgCategorization = TModelCommonNameFactory.getInstance().getCategorizationByName(exportService, TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME);
                Categorization docTypeCategorization = null;

                BindingDetails exportBinding = null;
                List<BindingDetails> resultBindings = service.getTypeBinding(TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME, "RG Table Export");
                for (BindingDetails resultBinding : resultBindings) {
                  List<TModelInstanceDetails> tModelInstances = resultBinding.getTModelInstancesByKeyValue(rgCategorization, "RG Table Export");
                  for (TModelInstanceDetails tModelInstance : tModelInstances) {
                    TModelDetails tModel = tModelInstance.getTModelDetails();
                    docTypeCategorization = tModel.getCategorizationByName(TModelCommonNameFactory.RESEARCH_GATEWAY_DOCUMENT_TYPES_SCHEME);
                    if (docTypeCategorization != null && docTypeCategorization.hasKeyValues()) {
                      break;
                    }
                  }
                  if (docTypeCategorization != null && docTypeCategorization.hasKeyValues()) {
                    exportBinding = resultBinding;
                    break;
                  }
                }
                List<ServiceParameter> entityTableXMLParameters = exportService.getParameters(TModelCommonNameFactory.RESEARCH_GATEWAY_SERVICEINPUT_CATEGORIZATION_SCHEME, "Entity Table XML");
                for (ServiceParameter entityTableXMLParameter : entityTableXMLParameters) {
                  entityTableXMLParameter.setValue(ExtXMLElement.toString(tableDoc));
                }
                response.setContentType(exportUtils.getMimetype(docTypeCategorization));
                response.addHeader("Content-disposition", "attachment; filename=" + exportName.trim().replaceAll("\\s+", "_") + "." + exportUtils.getExtension(docTypeCategorization));
                if (exportBinding.containsKeyValue(ClassificationSchemeNames.EXTENDED_TYPES_CATEGORIZATION_SCHEME, CommonKeyValues.rawResultSpec)) {
                  Object exportResults = executeService(exportService, null, true);
                  if (exportResults instanceof String) {
                    response.getWriter().write((String) exportResults);
                    response.getWriter().flush();
                  } else if (exportResults instanceof byte[]) {
                    response.getOutputStream().write((byte[]) exportResults);
                    response.getOutputStream().flush();
                  }
                } else {
                  Document exportResultDoc = executeService2JDocument(exportService, exportBinding, true);;
                  ExtXMLElement.write(exportResultDoc, response.getWriter());
                  response.getWriter().flush();
                }
              }
            } finally {
            }
            break;
        }
        break;
      case SAVE:
        entityTableCacheItem.getEntityTable().prepareForSave();
        if (entityTableCacheItem.getEntityTable().getSavedObject() != null && entityTableCacheItem.getEntityTable().getSavedObject().setData()) {
          if (!sessionLogin.getRemoteUser().equals(entityTableCacheItem.getEntityTable().getSavedObject().getCreated_by())) {
            throw new AIGException("Unable to save to database. Only the table owner can save the table. Please Save As.", Reason.INSUFFICIENT_PRIVLEDGE);
          }
          entityTableCacheItem.getEntityTable().getSavedObject().setSavedObject(entityTableCacheItem.getEntityTable(), sessionLogin);
          if (entityTableCacheItem.getEntityTable().getSavedObject().performCommit() <= 0) {
            throw new AIGException("Unable to save to database", Reason.DATABASE_ERROR);
          }
        } else {
          throw new AIGException("Unable to save to database. Unable to retrieve previous table.", Reason.DATABASE_ERROR);
        }
        break;
      case SAVEAS:
        entityTableCacheItem.getEntityTable().prepareForSave();
        savedTable = new SavedObject(getParameter("name"), getParameter("description"), entityTableCacheItem.getEntityTable().getEntityCategory(), sessionLogin.getRemoteUser(),
                entityTableCacheItem.getEntityTable(), new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
        if (savedTable.performCommit() <= 0) {
          throw new AIGException("Unable to save to database", Reason.DATABASE_ERROR);
        }
        List<String> shareWith = (doesParameterExist("shareWith", true) ? new ArrayList<String>(Arrays.asList(getParameter("shareWith").split(";"))) : new ArrayList<String>());
        ItemsManager itemsManager = new ItemsManager(this);
        FavoriteManager favoriteManager = new FavoriteManager(this);
        Favorite favorite = favoriteManager.createFavorite(savedTable, getParameterNumber("folderID", -1).intValue());
        ItemRecord itemRecord = itemsManager.getItemRecordForItemKey(favorite.getFavoriteID(), FavoriteFolderItem.ItemType.FAVORITE);
        itemsManager.shareItem(itemRecord, shareWith);
        break;
      case MOVEROWTOP:
        row = entityTableCacheItem.getEntityTable().getSortedDataRow(pagedRowIndex.intValue());
        entityTableCacheItem.getEntityTable().moveRowTop(row);
        break;
      case MOVEROWBOTTOM:
        row = entityTableCacheItem.getEntityTable().getSortedDataRow(pagedRowIndex.intValue());
        entityTableCacheItem.getEntityTable().moveRowBottom(row);
        break;
      case GETSELECTABLETEXTFORCELL:
        entityTable = entityTableCacheItem.getEntityTable();
        if (entityTable == null || columnDataIndex == null || Double.isNaN(pagedRowIndex.doubleValue())) {
          return;
        }
        columnIndex = entityTable.getColumnIndex(columnDataIndex);
        if (columnIndex < 0) {
          return;
        }
        column = entityTable.getColumn(columnIndex);
        row = entityTable.getSortedDataRow(pagedRowIndex.intValue());
        if (row == null) {
          return;
        }
        cell = row.getDataCell(columnIndex);
        if (cell == null) {
          return;
        }
        if (column.getDataType().equals(EntityTableDataType.STRUCTURE)) {
          try {
            String compoundID = row.getEntityID();
            String smscURL = new ChemImageHandler().getSMSCURL(request, "acrf", compoundID, "json", null, null, sessionLogin.getRemoteUser());
            String smscResponse = ExtFile.postURL(smscURL, null);
            JSONObject smscResponseJS = new JSONObject(smscResponse);
            if (smscResponseJS.has("mol")) {
              String mol = smscResponseJS.getString("mol");
              mol = mol.replaceFirst("[ \\t\\x0B\\f\\r]*\\n", compoundID + '\n');
              smscResponseJS.put("mol", mol);
            }
            smscResponseJS.put("title", "Structure Details for " + compoundID);
            smscResponseJS.write(response.getWriter());
          } catch (Exception e) {
            e.printStackTrace();
          }
        }
        break;
      case RESETVIEWCONFIG:

        /**
         * This section persists the column configurations Currently, only the
         * column width and
         */
        try {
          entityTable = entityTableCacheItem.getEntityTable();
          if (entityTable == null || !doesParameterExist("column_configs", true)) {
            return;
          }
          JSONObject columnConfigParam = getJSONObjectParameter("column_configs");
          JSONObject tableConfigParam = getJSONObjectParameter("table_config");

          if (tableConfigParam != null) {
            entityTable.setTableConfig(tableConfigParam);
            entityTable.getEntityTableJSON(true);
          }
          if (columnConfigParam != null) {
            entityTable.setColumnsConfig(columnConfigParam);
            entityTable.getEntityTableJSON(true);
          }
          //List<String> updatedColumnGroupOrderDataIndexes= new ArrayList<String>();
          JSONArray columnGroupConfigs = columnConfigParam.getJSONArray("column_groups");
          if (columnGroupConfigs.length() != entityTable.getColumnGroups().size()) {
            return;
          }

          for (int i = 0; i < columnGroupConfigs.length(); i++) {
            JSONObject columnGroupConfig = columnGroupConfigs.getJSONObject(i);
            String dataIndex = columnGroupConfig.getString("index");
            //updatedColumnGroupOrderDataIndexes.add(dataIndex);
            JSONArray columnConfigs = columnGroupConfig.getJSONArray("column_configs");
            ColumnGroup columnGroup = entityTable.getColumnGroup(dataIndex);
            if (columnGroup == null || columnConfigs.length() != columnGroup.getColumnCount()) {
              return;
            }
          }
          //entityTable.updateColumnGroupOrder(updatedColumnGroupOrderDataIndexes);

          for (int i = 0; i < columnGroupConfigs.length(); i++) {
            JSONObject columnGroupConfig = columnGroupConfigs.getJSONObject(i);
            String colGroupDataIndex = columnGroupConfig.getString("index");
            JSONArray columnConfigs = columnGroupConfig.getJSONArray("column_configs");
            //List<String> updatedColumnOrderDataIndexes= new ArrayList<String>();
            for (int j = 0; j < columnConfigs.length(); j++) {
              JSONObject columnConfig = columnConfigs.getJSONObject(j);
              String colDataIndex = columnConfig.getString("dataIndex");
              Column col = entityTable.getColumnByDataIndex(colDataIndex);
              int columnWidth = columnConfig.optInt("width", -1);
              if (columnWidth > -1) {
                col.setWidth(columnWidth);
              }
              if (columnConfig.has("hidden")) {
                col.setHidden(columnConfig.optBoolean("hidden", false));
              }
              //updatedColumnOrderDataIndexes.add(colDataIndex);
            }
            //ColumnGroup columnGroup = entityTable.getColumnGroup(colGroupDataIndex);
            //columnGroup.updateColumnOrder(updatedColumnOrderDataIndexes);
          }

        } catch (Exception e) {
          System.err.println("Failed: " + e);
        }
        break;
    }

    switch (entityTableRequest) {
      case GETAVAILABLEMETHODS:
      case ADDEDITABLECOLUMN:
      case UPDATEEDITABLECELLVALUE:
      case EVALUATECALCULATEDCOLUMN:
      case ADDCALCULATEDCOLUMN:
      case RECALCULATECOLUMN:
      case GETCALCULATEDCOLUMNCONFIG:
        performRequestForEditableColumns();
        break;
    }

  }

  protected JSONObject getEntityTableJSON(EntityTableCacheItem entityTableCacheItem, String resultKey, boolean refresh) throws JSONException {
    JSONObject entityTableConfig = entityTableCacheItem.getEntityTable().getEntityTableJSON(refresh);
    entityTableConfig.put("sourceURL", "/aig/entitytable.go?resultKey=" + resultKey + "&entityTableKey=" + entityTableCacheItem.getEntityTableKey());
    entityTableConfig.put("entityTableKey", entityTableCacheItem.getEntityTableKey());
    return entityTableConfig;
  }

  /**
   *
   * @throws Exception
   */
  protected void performRequestForEditableColumns() throws Exception {
    //A bunch of common parameters- not all used in every request

    String resultKey = getParameter("resultKey");
    String serviceKey = getParameter("serviceKey");
    String columnDataIndex = getParameter("columnDataIndex");
    String columnGroupDataIndex = getParameter("columnGroupDataIndex");
    String columnGroupHeader = getParameter("columnGroupHeader");
    Number pagedRowIndex = getParameterNumber("pagedRowIndex");
    String newColumnHeader = getParameter("columnHeader");
    String value = getParameter("value");

    //Common variables
    EntityTable entityTable;
    JSONObject entityTableConfig;
    Column column;
    DataRow row;
    DataCell cell;
    int columnIndex;

    //Handles Special Column Requests- Editable Columns, Calculated Columns
    entityTable = entityTableCacheItem.getEntityTable();
    if (entityTable == null) {
      return;
    }
    AvailableScriptMethods availableScriptMethods = getAvailableScriptMethods(entityTable);

    switch (entityTableRequest) {
      case GETAVAILABLEMETHODS:
        availableScriptMethods.getMethodsAsJSON().write(response.getWriter());
        break;
      case ADDEDITABLECOLUMN:
        entityTable = entityTableCacheItem.getEntityTable();
        if (entityTable == null) {
          return;
        }
        entityTable.addEditableColumns(newColumnHeader, EntityTableDataType.TEXT);
        entityTableConfig = entityTable.getEntityTableJSON(true);
        entityTableConfig.put("sourceURL", "/aig/entitytable.go?resultKey=" + resultKey + "&entityTableKey=" + entityTableCacheItem.getEntityTableKey());
        entityTableConfig.write(response.getWriter());
        break;
      case UPDATEEDITABLECELLVALUE:
        entityTable = entityTableCacheItem.getEntityTable();
        if (entityTable == null || columnDataIndex == null || Double.isNaN(pagedRowIndex.doubleValue())) {
          return;
        }
        column = entityTable.getColumnByDataIndex(columnDataIndex);
        columnIndex = entityTable.getColumnIndex(columnDataIndex);
        row = entityTable.getSortedDataRow(pagedRowIndex.intValue());
        if (columnIndex < 0 || column == null || !column.getColumnType().equals(ColumnType.EDITABLE) || row == null) {
          return;
        }
        cell = row.getDataCell(columnIndex);
        if (cell == null) {
          return;
        }
        cell.setValue(value);
        break;
      case EVALUATECALCULATEDCOLUMN:
        entityTable = entityTableCacheItem.getEntityTable();
        if (entityTable == null) {
          return;
        }
        try {
          JSONObject calcConfig = new JSONObject(getParameter("calccolumn_config"));
          entityTable.evaluateCalculatedColumn(calcConfig, availableScriptMethods);
          JSONObject successJObj = new JSONObject();
          successJObj.put("Success", getParameter("calccolumn_config"));
          successJObj.write(response.getWriter());
        } catch (Exception e) {
          JSONObject errorJObj = new JSONObject();
          errorJObj.put("noResults", true);
          errorJObj.put("scriptError", e.getMessage());
          errorJObj.put("calcConfig", getParameter("calccolumn_config"));
          errorJObj.write(response.getWriter());
        }
        break;
      case ADDCALCULATEDCOLUMN:
        entityTable = entityTableCacheItem.getEntityTable();
        if (entityTable == null) {
          return;
        }
        try {
          JSONObject calcConfig = new JSONObject(getParameter("calccolumn_config"));
          JSONObject calcFormat = getJSONObjectParameter("calccolumn_format");
          entityTable.addCalculatedColumn(columnGroupHeader, columnGroupDataIndex, newColumnHeader, calcConfig, calcFormat, availableScriptMethods);
          entityTableConfig = entityTable.getEntityTableJSON(true);
          entityTableConfig.put("sourceURL", "/aig/entitytable.go?resultKey=" + resultKey + "&entityTableKey=" + entityTableCacheItem.getEntityTableKey());
          entityTableConfig.write(response.getWriter());
        } catch (RhinoException e) {
          JSONObject errorJObj = new JSONObject();
          errorJObj.put("noResults", true);
          errorJObj.put("scriptError", e.getMessage());
          errorJObj.put("calcConfig", getParameter("calccolumn_config"));
          errorJObj.write(response.getWriter());
        } catch (Exception e) {
          JSONObject errorJObj = new JSONObject();
          errorJObj.put("noResults", true);
          errorJObj.write(response.getWriter());
        }
        break;
      case RECALCULATECOLUMN:
        entityTable = entityTableCacheItem.getEntityTable();
        if (entityTable == null) {
          return;
        }
        try {
          JSONObject calcConfig = null;
          if (doesParameterExist("calccolumn_config", true)) {
            calcConfig = new JSONObject(getParameter("calccolumn_config"));
          }
          JSONObject calcFormat = getJSONObjectParameter("calccolumn_format");
          columnDataIndex = calcConfig.optString("columnDataIndex", "unknown");
          entityTable.reCalculateColumn(columnDataIndex, calcConfig, calcFormat, availableScriptMethods);
          entityTableConfig = entityTable.getEntityTableJSON(true);
          entityTableConfig.put("sourceURL", "/aig/entitytable.go?resultKey=" + resultKey + "&entityTableKey=" + entityTableCacheItem.getEntityTableKey());
          entityTableConfig.write(response.getWriter());
        } catch (RhinoException e) {
          JSONObject errorJObj = new JSONObject();
          errorJObj.put("noResults", true);
          errorJObj.put("scriptError", e.getMessage());
          errorJObj.put("calcConfig", getParameter("calccolumn_config"));
          errorJObj.write(response.getWriter());
        } catch (Exception e) {
          e.printStackTrace();
          JSONObject errorJObj = new JSONObject();
          errorJObj.put("noResults", true);
          errorJObj.write(response.getWriter());
        }
        break;
      case GETCALCULATEDCOLUMNCONFIG:
        entityTable = entityTableCacheItem.getEntityTable();
        if (entityTable == null || columnDataIndex == null) {
          return;
        }
        column = entityTable.getColumnByDataIndex(columnDataIndex);
        JSONObject calcConfig = column.getCalculatedColumnConfig();
        if (calcConfig == null) {
          JSONObject errorJObj = new JSONObject();
          errorJObj.put("noResults", true);
          errorJObj.write(response.getWriter());
        } else {
          calcConfig.put("columnDataIndex", columnDataIndex);
          calcConfig.write(response.getWriter());
        }
        break;
    }
  }

  /**
   * getSourceConfigs
   *
   * @return String
   */
  public JSONObject getSourceConfigs() {
    JSONObject sourceConfigs = new JSONObject();
    try {
      String smscBaseURL = ConfigurationParameterSource.getConfigParameter("SMSC_BASE_URL");
      JSONObject sourceConfig = new JSONObject();
      sourceConfigs.put("acrf", sourceConfig);
//            sourceConfig.put("url", smscBaseURL + "/smsc.go?db=acrf&width=[width]&id=[id]");
      sourceConfig.put("url", "/aig/chemimage?db=acrf&width=[width]&id=[id]");

      ConfigurationParameterInstanceType version = ConfigurationParameterSource.getRGVersion();

      switch (version) {
        case DEV:
          sourceConfig = new JSONObject();
          sourceConfigs.put("smr_molecule", sourceConfig);
          sourceConfig.put("url", smscBaseURL + "/smsc.go?db=smrdev&width=[width]&molecule_id=[id]");
          sourceConfig = new JSONObject();
          sourceConfigs.put("smr_structure", sourceConfig);
          sourceConfig.put("url", smscBaseURL + "/smsc.go?db=smrdev&width=[width]&structure_id=[id]");
          break;
        case TEST:
          sourceConfig = new JSONObject();
          sourceConfigs.put("smr_molecule", sourceConfig);
          sourceConfig.put("url", smscBaseURL + "/smsc.go?db=smrtest&width=[width]&molecule_id=[id]");
          sourceConfig = new JSONObject();
          sourceConfigs.put("smr_structure", sourceConfig);
          sourceConfig.put("url", smscBaseURL + "/smsc.go?db=smrtest&width=[width]&structure_id=[id]");
          break;
        case PROD:
          sourceConfig = new JSONObject();
          sourceConfigs.put("smr_molecule", sourceConfig);
          sourceConfig.put("url", smscBaseURL + "/smsc.go?db=smr&width=[width]&molecule_id=[id]");
          sourceConfig = new JSONObject();
          sourceConfigs.put("smr_structure", sourceConfig);
          sourceConfig.put("url", smscBaseURL + "/smsc.go?db=smr&width=[width]&structure_id=[id]");
          break;
      }

      sourceConfig = new JSONObject();
      sourceConfigs.put("directory", sourceConfig);

      URL imgURL = new URL("http", request.getServerName(), request.getServerPort(), "/aig/staffimage.go");
      sourceConfig.put("url", imgURL + "?login=[login]&staffid=[staffid]&personid=[personid]");

    } catch (Exception e) {
      e.printStackTrace();
    }
    return sourceConfigs;
  }

  /**
   * Creates a new EntityTable or retrieves an EntityTable from the database
   *
   * @param resultKey String
   * @param entityTableRequest EntityTableRequest
   * @throws AIGException
   * @return EntityTableCacheItem
   */
  private EntityTableCacheItem createEntityTable(String resultKey, EntityTableRequest entityTableRequest) throws AIGException {
    TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(request);
    Element parentTreeNode = tnCache.getTreeNode(resultKey);
    if (parentTreeNode == null) {
      return null;
    }
    EntityTableCacheItem entityTableCacheItem = null;
    if (parentTreeNode.getAttributeValue("TABLE_KEY") != null) {
      entityTableCacheItem = ServiceCache.getServiceCache(request).getEntityTableResult(parentTreeNode.getAttributeValue("TABLE_KEY"));
    }
    if (entityTableCacheItem == null) {
      EntityTableLoaderIF entityTableLoader = EntityLoaderFactory.getEntityTableLoader(this, resultKey);
      EntityTable entityTable = entityTableLoader.createEntityTable();
      entityTableCacheItem = ServiceCache.getServiceCache(request).saveEntityTableResult(new EntityTableCacheItem(this, entityTable));
      parentTreeNode.setAttribute("TABLE_KEY", entityTableCacheItem.getKey());
    }
    return entityTableCacheItem;
  }

  private AvailableScriptMethods getAvailableScriptMethods(EntityTable entityTable) {
    String entityTableMethodsDir = ConfigurationParameterSource.getConfigParameter("ENTITY_TABLE_METHODS_DIR");
    File entityTableMethodsDirFile = new File(context.getRealPath(entityTableMethodsDir));
    try {
      AvailableScriptMethods availableScriptMethods = new AvailableScriptMethods(entityTable.getEntityCategory(), ExtXMLElement.toDocument(new File(entityTableMethodsDirFile, "globals.xml")));
      availableScriptMethods.addAvailableScripts(new XMLSavedScriptMethods(entityTable.getEntityCategory(), entityTableMethodsDirFile));
      availableScriptMethods.addAvailableScripts(new SavedScriptsMethods(entityTable.getEntityCategory()));
      return availableScriptMethods;
    } catch (FileNotFoundException ex) {
      ex.printStackTrace();
    }
    return null;
  }

  public EntityTableRequest getEntityTableRequest() {
    return entityTableRequest;
  }
}
