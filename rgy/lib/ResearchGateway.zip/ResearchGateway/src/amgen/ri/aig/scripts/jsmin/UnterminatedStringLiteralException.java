package amgen.ri.aig.scripts.jsmin;

/**
 * <p>@version $Id: UnterminatedStringLiteralException.java,v 1.1 2011/06/17 20:41:26 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class UnterminatedStringLiteralException extends Exception {
    public UnterminatedStringLiteralException() {
        super();
    }

    public UnterminatedStringLiteralException(String message) {
        super(message);
    }

    public UnterminatedStringLiteralException(String message, Throwable cause) {
        super(message, cause);
    }

    public UnterminatedStringLiteralException(Throwable cause) {
        super(cause);
    }
}
