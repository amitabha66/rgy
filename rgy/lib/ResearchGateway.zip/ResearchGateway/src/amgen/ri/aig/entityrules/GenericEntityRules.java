package amgen.ri.aig.entityrules;

import amgen.ri.aig.cache.tree.TreeNode;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.entitylist.EntityListMemberIF;

/**
 * Class used to enforce business rules when processing nodes or
 * EntityListMembers for an EntityType
 *
 * @version $id$
 */
public class GenericEntityRules extends AbstractEntityRules {
    public GenericEntityRules(EntityListCategory entityType) {
        super(entityType);
    }

    /**
     * applyEntityRules
     *
     * @param node TreeNode
     * @param serviceDataCategory ServiceDataCategory
     * @return TreeNode
     * @todo Implement this amgen.ri.aig.entityrules.EntityRulesIF method
     */
    public TreeNode applyEntityRules(TreeNode node) {
        basicProcessing(node);
        return node;
    }

    /**
     * applyEntityRules
     *
     * @param member EntityListMemberIF
     * @return EntityListMemberIF
     */
    public EntityListMemberIF applyEntityRules(EntityListMemberIF member, ServiceDataCategory memberServiceDataCategory) {
        return member;
    }

}
