package amgen.ri.aig.entitytable;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.Set;

import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtBase64;
import amgen.ri.util.ExtImage;

/**
 * @version $Id: DataCell.java,v 1.4 2012/09/11 23:07:35 cvs Exp $
 */
public class DataCell implements Serializable {
  static final long serialVersionUID = 335507219418222091L;
  private Object value;
  private String imageURL;
  private String[] linkoutTokens;
  private JSONArray links;
  private char[] imageBase64;
  private int imageWidth;
  private int imageHeight;
  private Boolean isImageResizable;
  transient BufferedImage image;
  /**
   * Defines additional parameters which are provided to Services during
   * drill-down calls
   */
  private Set<CellServiceParameter> cellParameters;

  public DataCell(Object value) {
    this(value, null, 0, 0, EntityTableDataType.UNSPECIFIED);
  }

  public DataCell(Object value, EntityTableDataType type) {
    this(value, null, 0, 0, type);
  }

  public DataCell(Object value, EntityTableDataType type, int imageWidth) {
    this(value, null, imageWidth, 0, type);
  }

  public DataCell(Object value, String imageURL, int imageWidth, int imageHeight) {
    this(value, imageURL, imageWidth, imageHeight, EntityTableDataType.UNSPECIFIED);
  }

  public DataCell(Object value, String imageURL, int imageWidth, int imageHeight, EntityTableDataType dataType) {
    this.cellParameters = new HashSet<CellServiceParameter>();
    setValue(value, dataType);
    setImageURL(imageURL);
    this.imageWidth = imageWidth;
    this.imageHeight = imageHeight;
    this.isImageResizable = null;
  }

  /**
   * Creates a copy of the source DataCell.
   *
   * @param source DataCell
   */
  public DataCell(DataCell source) {
    if (source != null) {
      this.value = source.value;
      this.imageURL = source.imageURL;
      this.imageWidth = source.imageWidth;
      this.imageHeight = source.imageHeight;
      this.isImageResizable = source.isImageResizable;
    }
  }

  public Object getJSONValue(EntityTableCellFormatterIF formatter, Column column) throws JSONException {
    JSONObject cellJSON = new JSONObject();
    if (imageURL == null) {
      if (linkoutTokens != null && linkoutTokens.length > 0) {
        cellJSON.put("value", getValue(formatter, column));
        cellJSON.put("linkout_tokens", new JSONArray(linkoutTokens));
        return cellJSON;
      }
      if (links != null && links.length() > 0) {
        cellJSON.put("links", links);
        return cellJSON;
      }
      return getValue(formatter, column);
    }
    cellJSON.put("value", getValue(formatter, column));
    cellJSON.put("image", imageURL);

    if (linkoutTokens != null && linkoutTokens.length > 0) {
      cellJSON.put("linkout_tokens", new JSONArray(linkoutTokens));
    }
    if (links != null && links.length() > 0) {
      cellJSON.put("links", links);
    }
    if (imageHeight > 0) {
      cellJSON.put("imageHeight", imageHeight);
    }
    if (imageWidth > 0) {
      cellJSON.put("imageWidth", imageWidth);
    }
    return cellJSON;
  }

  /**
   * Returns the values of the cell which is used to sort the rows. Generally
   * this returns getValue(), but may be different for subclasses.
   *
   * @return Object
   * @param reversedSort boolean
   */
  public Object getSortValue(boolean reversedSort) {
    if (value == null) {
      return null;
    }
    String stringValue = getValue();
    if (stringValue.trim().length() == 0) {
      return null;
    }
    return getValue();
  }

  /**
   * Sets the value converting the value to the given data type
   *
   * @param value Object
   * @param dataType EntityTableDataType
   */
  public void setValue(Object value, EntityTableDataType dataType) {
    switch (dataType) {
      case DOUBLE:
        if (value instanceof String) {
          this.value = toNumber((String) value);
        } else if (value instanceof Number) {
          this.value = ((Number) value).doubleValue();
        } else {
          this.value = value;
        }
        if (!(this.value instanceof Number) || Double.isNaN(((Number) this.value).doubleValue())) {
          this.value = "";
        }
        break;
      case INTEGER:
        if (value instanceof String) {
          this.value = toNumber((String) value);
        } else if (value instanceof Number) {
          this.value = ((Number) value).intValue();
        } else {
          this.value = value;
        }
        if (!(this.value instanceof Number) || Double.isNaN(((Number) this.value).doubleValue())) {
          this.value = "";
        } else {
          this.value = ((Number) this.value).intValue();
        }
        break;
      case DATE:
        if (value instanceof String) {
          this.value = toDate((String) value);
        } else {
          this.value = value;
        }
        if (value == null) {
          this.value = "";
        }
        break;
      case TEXT:
        this.value = (value == null ? "" : value + "");
        break;
      default:
        //if not a String, just set it
        if (!(value instanceof String)) {
          this.value = value;
        } else {
          //See if Number
          this.value = toNumber((String) value);
          //Still String, See if Date
          if (this.value instanceof String) {
            this.value = toDate((String) value);
          }
        }
        break;

    }
  }

  /**
   * Returns the raw value of the cell as a String
   *
   * @return String
   */
  public String getValue() {
    return value + "";
  }

  /**
   * Returns the raw value of the cell
   *
   * @return Object
   */
  public Object getRawValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public String getValue(EntityTableCellFormatterIF formatter, Column column) {
    if (formatter == null) {
      return value + "";
    }
    return formatter.format(column, value, "EntityTable");
  }

  public void setImageWidth(int imageWidth) {
    this.imageWidth = imageWidth;
  }

  public void setImageHeight(int imageHeight) {
    this.imageHeight = imageHeight;
  }

  public void setImageURL(String imageURL) {
    this.imageURL = imageURL;
  }

  public void setLinkoutTokens(String[] linkoutTokens) {
    this.linkoutTokens = linkoutTokens;
  }

  public void setImageResizable(Boolean imageResizable) {
    this.isImageResizable = imageResizable;
  }

  public int getImageWidth() {
    return imageWidth;
  }

  public int getImageHeight() {
    return imageHeight;
  }

  public String getImageURL() {
    return imageURL;
  }

  private char[] getBase64EncodedImage() throws IOException {
    if (imageBase64 == null) {
      imageBase64 = ExtBase64.encodeImageAsPNG(new URL(imageURL), false);
    }
    return imageBase64;
  }

  public BufferedImage getImage() {
    if (image == null) {
      try {
        image = ExtImage.createImageFromBase64(getBase64EncodedImage());
      } catch (Exception ex) {
      }
    }
    return image;
  }

  public BufferedImage getScaledImage(Column column) {
    try {
      BufferedImage img = getImage();
      if (img != null) {
        if ((isImageResizable == null && column.getImageResizable()) || (isImageResizable != null && isImageResizable.booleanValue())) {
          img = ExtImage.resize(image, imageWidth, imageHeight);
        }
        return img;
      }
    } catch (Exception e) {
    }
    return null;
  }

  /**
   * Adds a CellParameter to the cell parameters Set
   *
   * @param cellParameter CellServiceParameter
   */
  public void addCellParameter(CellServiceParameter cellParameter) {
    this.cellParameters.add(cellParameter);
  }

  /**
   * Returns the cell parameters Set
   *
   * @return Set
   */
  public Set<CellServiceParameter> getCellParameters() {
    return cellParameters;
  }

  public String[] getLinkoutTokens() {
    return linkoutTokens;
  }

  public Boolean isImageResizable() {
    return isImageResizable;
  }

  /**
   * Returns a Number if the given string is a parsable number otherwise,
   * returns the String. Try a new Integer, then new Double Returns null if s is
   * null;
   *
   * @param s string
   * @return Number if the string is a parsable number, s otherwise
   */
  public static Object toNumber(String s) {
    try {
      return new Double(s);
    } catch (NumberFormatException e) {
    }

    return s;
  }

  /**
   * Returns a date of the given string is a parsable Date otherwise, returns
   * the String.
   *
   * @param s string
   */
  public static Object toDate(String s) {
    String[] datePatterns = {
      "MM/dd/yyyy hh:mm:ss a", // e.g. 01/01/2007 3:30:05 PM
      "MM/dd/yyyy hh:mm a", // e.g. 01/01/2007 3:30 PM
      "MM/dd/yyyy HH:mm:ss", // e.g. 01/01/2007 15:30:05
      "MM/dd/yyyy HH:mm", // e.g. 01/01/2007 15:30
      "MM/dd/yyyy", // e.g. 01/01/2007

      "MMM dd, yyyy hh:mm:ss a", // e.g. Jan 1, 2007 3:30:05 PM
      "MMM dd, yyyy hh:mm a", // e.g. Jan 1, 2007 3:30 PM
      "MMM dd, yyyy HH:mm:ss", // e.g. Jan 1, 2007 15:30:05
      "MMM dd, yyyy HH:mm", // e.g. Jan 1, 2007 15:30
      "MMM dd, yyyy", // e.g. Jan 1, 2007

      "dd MMM yyyy hh:mm:ss a", // e.g. 1 Jan 2007 3:30:05 PM
      "dd MMM yyyy hh:mm a", // e.g. 1 Jan 2007 3:30 PM
      "dd MMM yyyy HH:mm:ss", // e.g. 1 Jan 2007 15:30:05
      "dd MMM yyyy HH:mm", // e.g. 1 Jan 2007 15:30
      "dd MMM yyyy", // e.g. 1 Jan 2007

      "MMM dd yyyy hh:mm:ss a", // e.g. Jan 1 2007 3:30:05 PM
      "MMM dd yyyy hh:mm a", // e.g. Jan 1 2007 3:30 PM
      "MMM dd yyyy HH:mm:ss", // e.g. Jan 1 2007 15:30:05
      "MMM dd yyyy HH:mm", // e.g. Jan 1 2007 15:30
      "MMM dd yyyy", // e.g. Jan 1 2007
    };
    for (String pattern : datePatterns) {
      try {
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        return format.parse(s);
      } catch (Exception e) {
      }
    }
    return s;
  }

  /**
   * Serializable implementation for any special handling during the
   * deserializing
   *
   * @return Object
   * @throws ObjectStreamException
   */
  public Object readResolve() throws ObjectStreamException {
    DataCell dataCell = (DataCell) this;
    if (dataCell.cellParameters == null) {
      this.cellParameters = new HashSet<CellServiceParameter>();
    }
    return dataCell;
  }

  /**
   * Prepares any data needed in the DataCell prior to saving. Returns true if
   * ready for saving, false otherwise
   *
   * @return boolean
   */
  public boolean prepareForSave() {
    if (imageURL != null) {
      getImage();
    }
    return true;
  }

  public JSONArray getLinks() {
    return links;
  }

  public void setLinks(JSONArray links) {
    this.links = links;
  }
}
