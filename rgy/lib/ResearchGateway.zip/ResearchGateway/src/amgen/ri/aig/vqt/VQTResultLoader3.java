package amgen.ri.aig.vqt;

import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.Writer;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleCallableStatement;
import oracle.sql.CLOB;
import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.entity.EntityClass;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.entity.assay.AssayResultTypeOperations;
import amgen.ri.aig.entitylist.EntityListMemberIF;
import amgen.ri.aig.entitylist.GenericEntityListMember;
import amgen.ri.aig.entitytable.Column;
import amgen.ri.aig.entitytable.ColumnGroup;
import amgen.ri.aig.entitytable.DataCell;
import amgen.ri.aig.entitytable.DataRow;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.aig.entitytable.loader.EntityLoaderFactory;
import amgen.ri.aig.entitytable.proxy.EntityTableProxy;
import amgen.ri.aig.sql.RGSQLProvider;
import amgen.ri.aig.sv.OILServiceParameterInterceptor;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.aig.viz.VisualizationResults;
import amgen.ri.asf.sa.uddi.ClassificationSchemeNames;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.ServiceParameter;
import amgen.ri.asf.sa.uddi.ServiceParameterException;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.sql.SQLProvider;
import amgen.ri.util.ExtObject;
import com.google.common.collect.ArrayListMultimap;
import java.io.IOException;
import java.sql.*;
import amgen.ri.vqtproc.VQTLoaderProc;

/**
 * Loads the results from a VQT query
 */
public class VQTResultLoader3 {
  // SQL for retrieving VQT query information
  private AIGBase requestServlet;
  private int queryRunID;
  private Map<String, Object> queryRunIDVariable;
  private VQTResultsProxy proxyObject;
  private String entityTypeCode;
  private String target;
  private EntityListCategory category;
  private int creator;
  private Date dateCreated;
  private Date dateFinished;
  private int errorID;
  private SQLProvider sqlProvider;

  /**
   * Creates a VQT Loader
   *
   * @param requestServlet AIGServlet
   * @param queryRunID int
   * @throws SQLException
   * @throws AIGException
   */
  public VQTResultLoader3(AIGBase requestServlet, int queryRunID, String target) throws SQLException, AIGException {
    this.requestServlet = requestServlet;
    this.sqlProvider = new RGSQLProvider();
    this.queryRunID = queryRunID;
    queryRunIDVariable = new HashMap<String, Object>();
    queryRunIDVariable.put("query_run_id", queryRunID);

    this.target = target;
    setQueryInformation();
  }

  /**
   * Sets VQT Query Information this includes the entity type, category,
   * creator, date created, date finished, error id, and the entity ID list from
   * the result set
   */
  private void setQueryInformation() throws SQLException, AIGException {
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.VQT_JDBC + "");
      ResultSet queryInfoRset = OraSQLManager.executeQuery(conn, sqlProvider.getSQLQuery("vqt_query_info"), queryRunIDVariable);
      while (queryInfoRset.next()) {
        entityTypeCode = queryInfoRset.getString("ENTITY_TYPE_CODE");
        creator = queryInfoRset.getInt("CREATOR");
        dateCreated = queryInfoRset.getTimestamp("DATE_CREATED");
        dateFinished = queryInfoRset.getTimestamp("DATE_FINISHED");
        errorID = queryInfoRset.getInt("ERROR_ID");
      }
      category = new VQTResultsProxy(-1).getEntityListCategoryFromEntityTypeCode(entityTypeCode);
      if (category.equals(EntityListCategory.UNKNOWN)) {
        throw new AIGException("Unknown entity type: " + entityTypeCode + ". Query Run ID:" + this.queryRunID, Reason.UNKNOWN_ENTITY_TYPE);
      }
    } finally {
      if (conn != null) {
        conn.close();
      }
    }
  }

  /**
   * Creates the entity table from the VQT results
   *
   * @return EntityTable
   * @throws SQLException
   */
  public EntityTable createEntityTable() throws SQLException, IOException, ClassNotFoundException, AIGException, JSONException {
    EntityTable entityTable = null;
    try {
      VQTResultsProxy vqtResultsProxy = getProxyObject();
      entityTable = EntityLoaderFactory.getEntityTableLoader(requestServlet, vqtResultsProxy.getEntityTableProxy()).createEntityTable();
      processEntityTable(entityTable);
    } catch (Exception e) {
      System.err.println("Warning: Error processing VQT result caused by " + e);
    }
    return entityTable;
  }

  /**
   * Creates the VisualizationResults from the VQT results
   *
   */
  public List<VisualizationResults> getVisualizations() throws SQLException, IOException, ClassNotFoundException, AIGException, JSONException {
    List<VisualizationResults> visualizations = new ArrayList<VisualizationResults>();
    try {
      VQTResultsProxy vqtResultsProxy = getProxyObject();
      visualizations.addAll(vqtResultsProxy.getVisualizationResultsProxy().getVizResults());
    } catch (Exception e) {
      System.err.println("Warning: Error processing VQT result caused by " + e);
    }
    return visualizations;
  }

  /**
   * Creates the entity table from the VQT results
   *
   * @return EntityTable
   * @throws SQLException
   */
  public int createEntityTable2ResultCache() throws SQLException {
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.VQT_JDBC + "");
      CLOB configClob = CLOB.createTemporary(conn, true, CLOB.DURATION_SESSION);
      JSONObject vqtLoaderConfig = new JSONObject();
      try {
        ServiceDetails assayResultsService = requestServlet.getLooselyCoupledServiceDetails("ASSAY_RESULTS");
        vqtLoaderConfig.putOpt(VQTLoaderProc.ASSAYRESULTS_DD_SERVICEKEY_KEY, assayResultsService.getKey());
        ServiceDetails acrfPropertiesService = requestServlet.getLooselyCoupledServiceDetails("COMPOUND_ENTITY_PROPERTIES");
        vqtLoaderConfig.putOpt(VQTLoaderProc.COMPOUNDS_DD_SERVICEKEY_KEY, acrfPropertiesService.getKey());
        vqtLoaderConfig.putOpt(VQTLoaderProc.SUBSTANCES_DD_SERVICEKEY_KEY, acrfPropertiesService.getKey());
        vqtLoaderConfig.putOpt("target", target);

        Writer writer = configClob.setCharacterStream(0);
        writer.write(vqtLoaderConfig.toString());
        writer.close();

        String sql = "{?= call VQT.VQT_LOADER.LOAD_ENTITYTABLE2RESULTCACHE(?, ?) }";
        OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(sql);
        cs.registerOutParameter(1, Types.INTEGER);
        cs.setInt(2, queryRunID);
        cs.setCLOB(3, null);
        cs.execute();
        int resultCacheID = cs.getInt(1);
        cs.close();
        return resultCacheID;
      } catch (Exception e) {
        e.printStackTrace();
      }
    } finally {
      if (conn != null) {
        conn.close();
      }
    }
    return -1;
  }

  private VQTResultsProxy getProxyObject() {
    if (proxyObject == null) {
      Connection conn = null;
      OracleCallableStatement stmt = null;
      try {
        conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
        CLOB configClob = CLOB.createTemporary(conn, true, CLOB.DURATION_SESSION);
        JSONObject vqtLoaderConfig = new JSONObject();
        ServiceDetails assayResultsService = requestServlet.getLooselyCoupledServiceDetails("ASSAY_RESULTS");
        if (assayResultsService != null) {
          vqtLoaderConfig.putOpt(VQTLoaderProc.ASSAYRESULTS_DD_SERVICEKEY_KEY, assayResultsService.getKey());
        }
        ServiceDetails acrfPropertiesService = requestServlet.getLooselyCoupledServiceDetails("COMPOUND_ENTITY_PROPERTIES");
        if (acrfPropertiesService != null) {
          vqtLoaderConfig.putOpt(VQTLoaderProc.COMPOUNDS_DD_SERVICEKEY_KEY, acrfPropertiesService.getKey());
          vqtLoaderConfig.putOpt(VQTLoaderProc.SUBSTANCES_DD_SERVICEKEY_KEY, acrfPropertiesService.getKey());
        }
        vqtLoaderConfig.putOpt("target", target);

        Writer writer = configClob.setCharacterStream(0);
        writer.write(vqtLoaderConfig.toString());
        writer.close();

        stmt = (OracleCallableStatement) conn.prepareCall("BEGIN ? := VQT_LOADER.LOAD_VQTRESULTS(?, ?); END;");
        stmt.registerOutParameter(1, Types.BLOB);
        stmt.setInt(2, queryRunID);
        stmt.setClob(3, configClob);
        stmt.execute();

        Blob resultBlob = stmt.getBlob(1);

        InputStream is = resultBlob.getBinaryStream();
        ObjectInputStream oip = new ObjectInputStream(is);
        Object object = oip.readObject();
        oip.close();
        is.close();
        proxyObject = (VQTResultsProxy) object;
      } catch (Exception e) {
        e.printStackTrace();
      } finally {
        OraSQLManager.close(stmt);
        OraSQLManager.close(conn);
      }
    }
    return proxyObject;
  }

  /**
   * processEntityTable
   *
   * @param entityTable EntityTable
   */
  private void processEntityTable(EntityTable entityTable) throws AIGException, ServiceParameterException {
    ServiceCache servicCache = ServiceCache.getServiceCache(requestServlet);
    EntityClassManager entityClassManager = requestServlet.getEntityClassManager();
    EntityListCategory tableEntityCategory = entityTable.getEntityCategory();
    EntityClass tableEntityClass = entityClassManager.getEntityClass(tableEntityCategory);
    EntityClass assayEntityClass = entityClassManager.getEntityClass(ServiceDataCategory.ASSAY_IDENTIFIER);

    if (entityTable.getDataRows().isEmpty()) {
      return;
    }
    //Handle any DR curves
    for (ColumnGroup columnGroup : entityTable.getColumnGroups()) {
      for (Column column : columnGroup.getColumns()) {
        if (column.getServiceDataCategory().equals(ServiceDataCategory.ADW_CURVE)) {
          int columnIndex = entityTable.getColumnIndex(column.getDataIndex());
          ServiceDetails assayCurveResultsService = servicCache.getCoreServiceByKeyValue("ASSAY_RESULT_CURVES");
          ServiceAttributes serviceAttributes = new ServiceAttributes(assayCurveResultsService, requestServlet.getEntityClassManager());
          OILServiceParameterInterceptor oilInterceptor = serviceAttributes.getListenerByType(OILServiceParameterInterceptor.class);
          ArrayListMultimap<EntityClass, ServiceParameter> parametersByEntityClass = serviceAttributes.getServiceParametersByEntityClass();

          String cellValue = entityTable.getDataRows().get(0).getDataCellValue(columnIndex);
          if (cellValue != null) {
            String assayParameterValue = AssayResultTypeOperations.getInstance().createAssayParameter(cellValue);
            if (assayParameterValue != null) {
              List<ServiceParameter> assayParameters = parametersByEntityClass.get(assayEntityClass);
              oilInterceptor.setParametersSetByEntityClass(assayEntityClass, assayParameters);

              for (ServiceParameter assayParameter : assayParameters) {
                assayParameter.setValue(assayParameterValue);
              }
              for (String entityID : entityTable.getEntityIDs()) {
                List<ServiceParameter> substanceParameters = parametersByEntityClass.get(tableEntityClass);
                oilInterceptor.setParametersSetByEntityClass(tableEntityClass, substanceParameters);

                for (ServiceParameter substanceParameter : substanceParameters) {
                  substanceParameter.addValue(entityID);
                }
              }
              Object response = requestServlet.executeService(assayCurveResultsService, null, false);
              if (response != null) {
                EntityTableProxy curveServiceResponseTable = EntityTableProxy.deserializeObject(response);
                if (curveServiceResponseTable != null) {
                  Column curveRespColumn = curveServiceResponseTable.getColumnGroups().get(0).getColumn(0);
                  column.update(curveRespColumn);
                  for (DataRow row : entityTable.getDataRows()) {
                    String entityID = row.getEntityID();
                    DataRow curveRespRow = curveServiceResponseTable.getDataRowMap().get(entityID);
                    if (curveRespRow != null) {
                      DataCell curveRespCell = curveRespRow.getDataCell(0);
                      if (curveRespCell != null) {
                        row.setDataCell((DataCell) ExtObject.copy(curveRespCell), columnIndex);
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    entityTable.getEntityTableJSON(true);
  }

  /**
   * Returns a List of EntityListMemberIFs for the result set
   *
   * @return List
   */
  public List<EntityListMemberIF> getEntityListMembers() {
    List<EntityListMemberIF> members = new ArrayList<EntityListMemberIF>();
    try {
      EntityTable entityTable = createEntityTable();
      switch (entityTable.getEntityCategory()) {
        case PEOPLE:
        case PROJECTS:
          for (DataRow row : entityTable.getDataRows()) {
            String label = row.getEntityID();
            if (row.getDataCells().size() > 0) {
              label = row.getDataCells().get(0).getValue();
            }
            members.add(new GenericEntityListMember(label, row.getEntityID(), null, entityTable.getEntityCategory()));
          }
          break;
        case AMGEN_GENES:
          for (DataRow row : entityTable.getDataRows()) {
            String id = row.getEntityID();
            DataCell symDataCell = row.getDataCell(0);
            DataCell nameDataCell = row.getDataCell(1);
            DataCell speciesDataCell = row.getDataCell(2);
            if (symDataCell != null && nameDataCell != null && speciesDataCell != null) {
              members.add(new GenericEntityListMember(symDataCell.getValue() + " [" + speciesDataCell.getValue() + "]", row.getEntityID(), nameDataCell.getValue(), entityTable.getEntityCategory()));
            }
          }
          break;
        default:
          for (DataRow row : entityTable.getDataRows()) {
            members.add(new GenericEntityListMember(row.getEntityLabel(), row.getEntityID(), row.getEntityDescription(), entityTable.getEntityCategory()));
          }
          break;
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return members;
  }

  /**
   * Query run ID
   *
   * @return int
   */
  public int getQueryRunID() {
    return queryRunID;
  }

  /**
   * Entity type code used by VQT
   *
   * @return String
   */
  public String getEntityTypeCode() {
    return entityTypeCode;
  }

  /**
   * VQT query creator
   *
   * @return int
   */
  public int getCreator() {
    return creator;
  }

  /**
   * Date query created
   *
   * @return Date
   */
  public Date getDateCreated() {
    return dateCreated;
  }

  /**
   * Date query completed
   *
   * @return Date
   */
  public Date getDateFinished() {
    return dateFinished;
  }

  /**
   * Query error ID. null if query returned successfully
   *
   * @return int
   */
  public int getErrorID() {
    return errorID;
  }

  /**
   * Converts the VQT entity type code to an RG ServiceDataCategory enum
   *
   * @param entityTypeCode String
   * @return ServiceDataCategory
   */
  public ServiceDataCategory getServiceDataCategoryFromEntityTypeCode(String entityTypeCode) {
    if (entityTypeCode != null) {
      if (entityTypeCode.equals("SM_LOT")) {
        return ServiceDataCategory.AMGEN_SUBSTANCE_ID;
      }
      if (entityTypeCode.equals("PERSON")) {
        return ServiceDataCategory.AMGEN_LOGIN;
      }
      if (entityTypeCode.equals("ASSAY")) {
        return ServiceDataCategory.ASSAY_IDENTIFIER;
      }
      if (entityTypeCode.equals("PROJECT")) {
        return ServiceDataCategory.PROJECT;
      }
      if (entityTypeCode.equals("COMPOUND")) {
        return ServiceDataCategory.AMGEN_ROOT_ID;
      }
      if (entityTypeCode.equals("CCRUN")) {
        return ServiceDataCategory.CELL_CULTURE_RUN_IDENTIFIER;
      }
    }
    return ServiceDataCategory.UNKNOWN;
  }
}
