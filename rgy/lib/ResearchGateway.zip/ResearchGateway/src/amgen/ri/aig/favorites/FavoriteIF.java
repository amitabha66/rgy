package amgen.ri.aig.favorites;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.sobj.ObjectType;
import java.util.Date;
import java.util.List;

/**
 * <p>@version $Id: FavoriteIF.java,v 1.4 2012/10/16 20:24:26 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public interface FavoriteIF {
  public Date getCreatedDate();

  public String getCreated_by();

  /**
   * Get value for description
   */
  public String getDescription();

  /**
   * Get value for name
   */
  public String getName();

  /**
   * A required method which returns the primary key(s) of the table/RdbData
   * class.
   */
  public String getIdentifier();

  /**
   * Returns the contained Favorite- if Favorite object, return this; if
   * SharedFavorite, getFavorite()
   */
  public Favorite getFavorite();

  /**
   * Returns whether this Favorite is valid an should be included in any lists
   * of Favorites
   *
   * @return boolean
   */
  public boolean isValid(AIGBase requestor);

  /**
   * Returns the EntityListCategory of the favorite
   *
   * @return EntityListCategory
   */
  public EntityListCategory getCategory();

  /**
   * Returns the ObjectType of the favorite
   *
   * @return ObjectType
   */
  public ObjectType getObjectType();

  /**
   * Returns the ObjectType.Type of the favorite
   *
   * @return ObjectType.Type
   */
  public ObjectType.Type getType();

  /**
   * Returns the Object associated with this Favorite. This can vary depending on the ObjectType ENTITYTABLE, SERVICE- SavedObject LIST- EntityList
   * PROJECTVIEW- DHProjectInfo including viewID= view ID as a transient data field
   */
  public Object getFavoriteObject();

  /**
   * Get value for favorite_key
   */
  public FavoriteKey[] getFavoriteKeys();

	public List<String> getFavoriteKeyList();  

}
