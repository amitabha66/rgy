package amgen.ri.aig.cache.tree;

import java.io.ObjectStreamException;

import org.jdom.Element;

/**
 * Node type enumeration
 * @version $id$
 */
public enum NodeType {
    QUERYNODE,
            RESULTNODE,
            SERVICENODE,
            ENTITYNODE,
            PAGEUPNODE,
            PAGEDOWNNODE,
            UNKNOWN;

    /**
     * Returns whether the TreeNode is of the type provided
     *
     * @param treeNode Element
     * @param nodeType NodeType
     * @return boolean
     */
    public static boolean isNodeType(Element treeNode, NodeType nodeType) {
        return getNodeType(treeNode).equals(nodeType);
    }

    /**
     * Returns the NodeType defined in the TreeNode or UNKNOWN if there is none
     * defined
     *
     * @param treeNode Element
     * @return NodeType
     */
    public static NodeType getNodeType(Element treeNode) {
        return (treeNode != null && treeNode.getAttributeValue("NODE_TYPE") != null ? NodeType.valueOf(treeNode.getAttributeValue("NODE_TYPE")) : UNKNOWN);

    }

    /**
     * Returns the NodeType defined in the TreeNode or UNKNOWN if there is none
     * defined
     *
     * @param treeNode Element
     * @return NodeType
     */
    public static NodeType fromString(String nodeType) {
        return (nodeType != null ? NodeType.valueOf(nodeType) : UNKNOWN);

    }

    /**
     * Return whether this node type is a data node- entity, service, or results
     *
     * @param nodeType String
     * @return boolean
     */
    public static boolean isDataNode(String nodeType) {
        return isDataNode(fromString(nodeType));
    }

    /**
     * Return whether this treen ode is a data node- entity, service, or results
     *
     * @param treeNode String
     * @return boolean
     */
    public static boolean isDataNode(Element treeNode) {
        return isDataNode(getNodeType(treeNode));
    }

    /**
     * Return whether this node type is a data node- entity, service, or results
     *
     * @param nodeType String
     * @return boolean
     */
    public static boolean isDataNode(NodeType nodeType) {
        switch (nodeType) {
            case ENTITYNODE:
            case RESULTNODE:
            case SERVICENODE:
                return true;
        }
        return false;
    }

    /**
     * This is necessary to permit Serializable.
     * A Serialized object containing an enum class variable is not de-Serialized properly.
     * This forces de-Serialized enum to be re-created as this enum through the String
     * @return Object
     * @throws ObjectStreamException
     */
    public Object readResolve() throws ObjectStreamException {
        return NodeType.fromString(this.toString());
    }

}
