package amgen.ri.aig.jawr;

import java.io.File;
import java.util.List;
import java.util.Properties;

import javax.servlet.ServletContext;

import net.jawr.web.resource.bundle.factory.util.ConfigPropertiesSource;
import net.jawr.web.resource.bundle.factory.util.ServletContextAware;

import org.jdom.Document;
import org.jdom.Element;

import amgen.ri.xml.ExtXMLElement;

/**
 * Creates a custom JAWR property source
 *
 * @version $Id: JAWRProperties.java,v 1.7 2013/07/09 18:32:09 jemcdowe Exp $
 */
public class JAWRProperties implements ConfigPropertiesSource, ServletContextAware {
  public static String CONFIG_FILENAME = "rg.filesets.definition.xml";

  public JAWRProperties() {
  }

  /**
   * Determine if configuration is changed to reconfigure Jawr during
   * development without having to restart the server.
   *
   * @return boolean
   */
  public boolean configChanged() {
    return false;
  }

  /**
   * Read/modify configuration from the XML property file.
   *
   * @return java.util.Properties
   */
  public Properties getConfigProperties() {
    Properties jawrProperties = new Properties();
    Document jawrDefinitionDoc = ExtXMLElement.toDocument(this.getClass(), CONFIG_FILENAME);
    
    if (jawrDefinitionDoc != null) {
      List<Element> propertyEls = ExtXMLElement.getXPathElements(jawrDefinitionDoc, "/RGFileSets/BundleDefinitions//Property");
      for (Element propertyEl : propertyEls) {
        String name = propertyEl.getAttributeValue("name");
        if (name != null) {
          String value = ExtXMLElement.findTextInElement(propertyEl, "Value");
          if (value != null) {
            jawrProperties.put(name, value);
          }
        }
      }
    }
    return jawrProperties;
  }

  /**
   * Called by the JAWR framework. Used to set the JAWR property file from the
   * ServletContext
   *
   * @param context ServletContext
   */
  public void setServletContext(ServletContext context) {
  }
}
