package amgen.ri.aig.entity.oil;

import amgen.ri.util.HashCodeGenerator;

public class UIR {
  private String uir_druid;
  private String uir_type_code;
  private String uir_luid;
  private String preferred_name;
  private int fHashCode;

  public UIR() {
  }

  public UIR(String uir_druid, String uir_type_code, String uir_luid, String robe_preferred_name) {
    this.uir_druid = uir_druid;
    this.uir_type_code = uir_type_code;
    this.uir_luid = uir_luid;
    this.preferred_name = robe_preferred_name;
  }

  /**
   * Get value for uir_druid
   */
  public String getUir_druid() {
    return uir_druid;
  }

  /**
   * Get value for uir_type_code
   */
  public String getUir_type_code() {
    return uir_type_code;
  }

  /**
   * Get value for uir_luid
   */
  public String getUir_luid() {
    return uir_luid;
  }

  /**
   * Get value for preferred_name
   */
  public String getPreferred_name() {
    return preferred_name;
  }

  /**
   * Set value for uir_druid
   */
  public void setUir_druid(String uir_druid) {
    this.uir_druid = uir_druid;
  }

  /**
   * Set value for uir_type_code
   */
  public void setUir_type_code(String uir_type_code) {
    this.uir_type_code = uir_type_code;
  }

  /**
   * Set value for uir_luid
   */
  public void setUir_luid(String uir_luid) {
    this.uir_luid = uir_luid;
  }

  /**
   * Set value for preferred_name
   */
  public void setPreferred_name(String preferred_name) {
    this.preferred_name = preferred_name;
  }
  

  @Override
  public int hashCode() {
    if (fHashCode == 0) {
      int result = HashCodeGenerator.SEED;
      result = HashCodeGenerator.hash(result, uir_druid);
      fHashCode = result;
    }
    return fHashCode;
  }

  @Override
  public boolean equals(Object obj) {
    if (obj instanceof UIR) {
      return ((UIR) obj).uir_druid.equals(this.uir_druid);
    }
    return false;
  }
  
}