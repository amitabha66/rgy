package amgen.ri.aig.event;

import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.constants.FileConstants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.css.CSSImageRetriever;
import amgen.ri.aig.entity.assay.AssayResultTypeOperations;
import amgen.ri.aig.jmx.RGMBeanAgent;
import amgen.ri.oracle.OraConnectionManagerFactory;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.oracle.OracleDataSourceCache;
import amgen.ri.rg.config.ConfigurationParameterInstanceType;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.rg.config.ContextConfigurationParameters;
import amgen.ri.rg.config.XMLConfigurationParameters;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import java.io.IOException;
import java.sql.Connection;
import java.util.Properties;
import javax.servlet.FilterRegistration;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import org.apache.jcs.engine.control.CompositeCacheManager;
import org.apache.log4j.net.SocketHubAppender;

public class ContextListener implements ServletContextListener {
  public static String CACHE_CONFIG_FILENAME = "jcs_cache.properties";
  private static final String[] LOGGER_NAMES = {"aig", "rgservice", "rgrequest"};
  private SocketHubAppender socketAppender;

  public ContextListener() {
  }

  /**
   * Notification that the servlet context is about to be shut down.
   *
   * @param sce ServletContextEvent @todo Implement this
   * javax.servlet.ServletContextListener method
   */
  public void contextDestroyed(ServletContextEvent sce) {
    if (socketAppender != null) {
      try {
        socketAppender.close();
      } catch (Exception e) {
      }
    }
    //Register RG MBean
    try {
      RGMBeanAgent.unregisterRGMBean();
    } catch (Exception e) {
      e.printStackTrace();
      Debug.print("Unable to unregister RG MBean");
    }

  }

  /**
   * Notification that the web application initialization process is starting.
   * Initialize application-scope objects
   *
   * @param sce ServletContextEvent
   */
  public void contextInitialized(ServletContextEvent sce) {
    Debug.print("RG Context Started");
    System.setProperty("java.awt.headless", "true");
    System.setProperty("http.serviceaccount.properties", FileConstants.RG_SERVICEACCOUNT_PROPERTIES);

    ServletContext context = sce.getServletContext();
    //Initialize Static Instances
    OraConnectionManagerFactory.setOracleConnectionManager(OracleDataSourceCache.getInstance());


    //Test All Connections    
    Connection conn = null;
    for (JDBCNamesType name : JDBCNamesType.values()) {
      try {
        conn = new OraSQLManager().getConnection(name + "");
        conn.close();
      } catch (Throwable t) {
      } finally {
        OraSQLManager.closeResources(conn);
      }
    }

    ContextConfigurationParameters.init(context);
    try {
      CSSImageRetriever.init(context);
    } catch (Exception ex) {
      ex.printStackTrace();
    }

    try {
      XMLConfigurationParameters.init(ContextConfigurationParameters.getInstance());
    } catch (IOException ex1) {
      ex1.printStackTrace();
    }
    try {
      TModelCommonNameFactory.init();
    } catch (Exception ex) {
      ex.printStackTrace();
    }

    AssayResultTypeOperations.init(context);

    //Initialize the Cache system
    try {
      CompositeCacheManager ccm = CompositeCacheManager.getUnconfiguredInstance();
      Properties cacheProperties = new Properties();

      cacheProperties.load(getClass().getClassLoader().getResourceAsStream(CACHE_CONFIG_FILENAME));
      String cacheDir = context.getInitParameter("CACHE_DIR");
      cacheDir = context.getRealPath(cacheDir);
      cacheProperties.setProperty("jcs.auxiliary.DC.attributes.DiskPath", cacheDir);
      ccm.configure(cacheProperties);
    } catch (IOException ex) {
      ex.printStackTrace();
    }
    Debug.print("RG Context Started");

    //Initialize FASF Authenticator
    FilterRegistration fasfFilterRegistration = context.getFilterRegistration("FASFFilter");
    String fasfAuthURL = ConfigurationParameterSource.getConfigParameter("FASF_AUTHENTICATOR_URL");
    String fasfCookieKey = ConfigurationParameterSource.getConfigParameter("FASF_COOKIE_KEY");
    String fasfSessionIdentityCookieKey = ConfigurationParameterSource.getConfigParameter("FASF_SESSION_IDENTITY_COOKIE_KEY");
    String fasfExcludePaths = ConfigurationParameterSource.getConfigParameter("FASF_AUTHENTICATOR_EXCLUDEDPATHS");
    if (!ExtString.hasLength(fasfAuthURL)) {
      throw new IllegalArgumentException("No Authentication URL defined");
    }
    fasfFilterRegistration.setInitParameter("FASF_AUTHENTICATOR_URL", fasfAuthURL);
    if (ExtString.hasLength(fasfCookieKey)) {
      fasfFilterRegistration.setInitParameter("FASF_COOKIE_KEY", fasfCookieKey);
    }
    if (ExtString.hasLength(fasfSessionIdentityCookieKey)) {
      fasfFilterRegistration.setInitParameter("FASF_SESSION_IDENTITY_COOKIE_KEY", fasfSessionIdentityCookieKey);
    }
    if (ExtString.hasLength(fasfExcludePaths)) {
      fasfFilterRegistration.setInitParameter("FASF_AUTHENTICATOR_EXCLUDEDPATHS", fasfExcludePaths);
    }

    //Register RG MBean
    try {
      RGMBeanAgent.registerRGMBean();
    } catch (Exception e) {
      e.printStackTrace();
      Debug.print("Unable to register RG MBean");
    }
    if (ConfigurationParameterSource.getRGVersion().equals(ConfigurationParameterInstanceType.PROD)
       //     || ConfigurationParameterSource.getRGVersion().equals(ConfigurationParameterInstanceType.TEST)
       ) {
      //ServiceCache.initializeKeyGlobalServiceCacheEntries();
    }

  }
}
