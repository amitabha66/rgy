package amgen.ri.aig.projectview.model;

import java.util.ArrayList;
import java.util.List;

import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.entitylist.EntityList;
import amgen.ri.aig.entitylist.EntityListIF;
import amgen.ri.aig.entitylist.EntityListMemberIF;
import amgen.ri.aig.entitylist.EntityListSourceServiceIF;
import amgen.ri.oracle.OraSQLManager;


/**
 * Base class for the project view list objects
 */
public abstract class ProjectViewList implements EntityListIF {
    private String name;
    private String id;
    private boolean isDefault;
    private EntityList entityList;

    protected ProjectViewList(String id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * Returns the name of the list
     *
     * @return String
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the id of the list
     *
     * @return int
     */
    public String getId() {
        return id;
    }

    /**
     * Sets whether this is the default list used by the project view
     *
     */
    public void isDefault(boolean isDefault) {
        this.isDefault = isDefault;
    }

    /**
     * Returns whether this is the default list used by the project view
     *
     * @return boolean
     */
    public boolean isDefault() {
        return isDefault;
    }

    /**
     * Returns the underlying EntityList as an object
     *
     * @return EntityList
     */
    public EntityList getEntityList() {
        if (entityList == null) {
            entityList = new EntityList(getId(), new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
        }
        return entityList;
    }

    /*
     **********************************
     * EntityListIF Implementations
     **********************************
     */

    /**
     * Get value for list_category
     *
     * @return EntityListCategory
     */
    public EntityListCategory getEntityCategory() {
        return getEntityList().getEntityCategory();
    }

    /**
     * Get name for the list
     *
     * @return String
     */
    public String getListName() {
        return getName();
    }

    /**
     * Get description for the list
     *
     * @return String
     */
    public String getListDescription() {
        return getEntityList().getListDescription();
    }

    /**
     * Returns the members of the list
     *
     * @param delimiter String
     * @return String
     */
    public String getListMemberIds(String delimiter) {
        return getEntityList().getListMemberIds(delimiter);
    }

    /**
     *
     * @return String
     */
    public List<String> getListMemberIds() {
        return getEntityList().getListMemberIds();
    }

    /**
     * Returns the members of the list in the provided List
     *
     * @param memberList List
     * @return List
     */
    public List<EntityListMemberIF> getListMembers(List<EntityListMemberIF> memberList) {
        return getEntityList().getListMembers(memberList);
    }

    /**
     * Returns the members of the list in a List
     *
     * @return List
     */
    public List<EntityListMemberIF> getListMembers() {
        return getListMembers(new ArrayList<EntityListMemberIF>());
    }

    /**
     * Returns the number of members in the provided List
     */
    public int getListMemberCount() {
        return getListMembers().size();
    }

    /**
     * Returns whether this list contains a member with this id
     *
     * @param memberID String
     * @return boolean
     */
    public boolean containsMember(EntityListMemberIF member) {
        return getEntityList().containsMember(member);
    }

    /**
     * Returns the service source of the list, if available
     *
     * @return EntityListSourceServiceIF
     */
    public EntityListSourceServiceIF getSourceService() {
        return getEntityList().getSourceService();
    }


}
