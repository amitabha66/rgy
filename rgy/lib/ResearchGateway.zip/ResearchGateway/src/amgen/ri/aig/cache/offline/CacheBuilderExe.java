package amgen.ri.aig.cache.offline;

import amgen.ri.rg.config.XMLConfigurationParameters;
import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.Appender;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.SimpleLayout;

/**
 * Executes the cache update offline (via command line)
 * @author jemcdowe
 */
public class CacheBuilderExe {

  public static void main(String[] args) throws Exception {
    File logFilename = null;
    
    if (args.length > 0) {
      logFilename = new File(args[0]);
    }
    System.setProperty("http.serviceaccount.properties", "/ad.serviceaccount.properties");
    System.setProperty("catalina.home", System.getProperty("user.dir"));
    Logger logger = Logger.getLogger("rgservice");
    Appender appender = logger.getAppender("rgserviceappender");
    logger.removeAppender(appender);

    if (logFilename != null) {
      logger.addAppender(new FileAppender(new PatternLayout("%d{MM/dd/yyyy H:m:s:S},%m%n"), logFilename.getAbsolutePath(), true));
    } else {
      logger.addAppender(new ConsoleAppender(new SimpleLayout()));
    }

    XMLConfigurationParameters.init(logger);
    ExecutorService executor = Executors.newSingleThreadExecutor();
    executor.execute(new CacheBuilderTask(executor, logFilename));
    shutdownAndAwaitTermination(executor);
    // new SimpleTimeLimiter(executor).callWithTimeout(new CacheBuilderTask(executor), CacheBuilder.TIMEOUT_MINS, TimeUnit.MINUTES, true);
  }

  static void shutdownAndAwaitTermination(ExecutorService pool) {
    pool.shutdown(); // Disable new tasks from being submitted
    try {
      // Wait a while for existing tasks to terminate
      if (!pool.awaitTermination(CacheBuilder.TIMEOUT_MINS, TimeUnit.MINUTES)) {
        pool.shutdownNow(); // Cancel currently executing tasks
        // Wait a while for tasks to respond to being cancelled
        if (!pool.awaitTermination(CacheBuilder.TIMEOUT_MINS / 2, TimeUnit.MINUTES)) {
          System.err.println("Pool did not terminate");
        }
      }
    } catch (InterruptedException ie) {
      // (Re-)Cancel if current thread also interrupted
      pool.shutdownNow();
      // Preserve interrupt status
      Thread.currentThread().interrupt();
    }
  }
}
