package amgen.ri.aig.scripts;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Handles the thread pooling for the column calculators,
 *
 * To use:
 * Create the ColumnCalculatorPool
 * Add ColumnCalculatorThread objects. these will begin immediately
 * Call shutdownAndWait() which will block until all the executing threads finish
 *
 * @version $Id: ColumnCalculatorPool.java,v 1.1 2011/06/17 20:41:25 cvs Exp $
 */
public class ColumnCalculatorPool {
    static int DEFAULT_THREADPOOL_SIZE = 10;
    ThreadPoolExecutor tpe;

    /**
     * Creates a new ColumnCalculatorPool
     */
    public ColumnCalculatorPool() {
        this(DEFAULT_THREADPOOL_SIZE);
    }

    /**
     * Creates a new ColumnCalculatorPool
     */
    public ColumnCalculatorPool(int tpSize) {
        super();
        tpe = new ThreadPoolExecutor(tpSize, tpSize, 50000L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue());
    }

    /**
     * Adds and executes a ColumnCalculatorThread
     *
     * @param columnCalculatorThread ColumnCalculatorThread
     */
    public void addColumnCalculatorThread(ColumnCalculatorThread columnCalculatorThread) {
        tpe.execute(columnCalculatorThread);
    }

    /**
     * Completes the pool by issuing a shutdown so no additional threads can be
     * added and blocks until all the executing threads finish
     */
    public void shutdownAndWait() {
        tpe.shutdown();
        while (!tpe.isTerminated()) {
        }

    }

}
