package amgen.ri.aig.uddi;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCacheResponse;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.asf.sa.uddi.*;
import amgen.ri.json.JSONObject;
import amgen.ri.time.ElapsedTime;
import amgen.ri.xml.ExtXMLElement;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;

public class QueryServiceLookup extends AbstractServiceLookup implements ServiceLookupIF, QueryServiceIF {

  /**
   * Default constructor
   */
  public QueryServiceLookup() {
    super();
  }

  public QueryServiceLookup(AIGServlet aigServlet) {
    super(aigServlet);
  }

  /**
   * Main constructor- used only by the getAIGServlet method
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   */
  public QueryServiceLookup(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  /**
   * Returns the getAIGServlet implementation class for the request
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return TBXServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new QueryServiceLookup(req, resp);
  }

  /**
   * Actual work entry stub
   *
   * @throws ServletException
   * @throws IOException
   */
  @Override
  protected void performRequest() throws ServletException, IOException, AIGException {
    try {
      ExtXMLElement.write(getServicesDocument(), response.getWriter());
    } catch (JDOMException ex) {
      ex.printStackTrace();
    }
  }

  /**
   *
   * @return
   */
  public ServiceQuery getServiceQuery() {
    ClassificationSchemeQuery classificationSchemeQuery = new ClassificationSchemeQuery(ClassificationSchemeQuery.OR_ALL_KEYS);
    for (EntityListCategory c : EntityListCategory.values()) {
      classificationSchemeQuery.addKeyValue("Research Gateway Entity Type Categorization Scheme", c.revertToString());
    }
    ServiceQuery serviceQuery = new ServiceQuery(classificationSchemeQuery, new String[]{
      TModelCommonNameFactory.QUERYTREENODESDEFINITION_tMODELNAME, TModelCommonNameFactory.QUERYRGRAWENTITYTABLEDEFINITION_TMODELNAME,
      TModelCommonNameFactory.QUERYENTITYTABLEDEFINITION_tMODELNAME
    });
    return serviceQuery;
  }

  @Override
  public Collection<ServiceQuery> getCacheServiceQueries() {
    List<ServiceQuery> serviceQueries = new ArrayList<ServiceQuery>();
    serviceQueries.add(getServiceQuery());

    ClassificationSchemeQuery classificationSchemeQuery = new ClassificationSchemeQuery();
    for (EntityListCategory c : EntityListCategory.values()) {
      classificationSchemeQuery.addKeyValue("Research Gateway Entity Type Categorization Scheme", c.revertToString());
    }
    ServiceQuery serviceQuery = new ServiceQuery(classificationSchemeQuery, TModelCommonNameFactory.QUERYTREENODESDEFINITION_tMODELNAME);
    serviceQueries.add(serviceQuery);

    serviceQuery = new ServiceQuery(classificationSchemeQuery, TModelCommonNameFactory.QUERYENTITYTABLEDEFINITION_tMODELNAME);
    serviceQueries.add(serviceQuery);

    return serviceQueries;
  }

  @Override
  public Document getServicesDocument() throws JDOMException, AIGException {
    Document servicesDocument = new Document(new Element("Services"));
    //ElapsedTime time = new ElapsedTime(true);
    ServiceCacheResponse sortedSearchServices = findAndSortServices(getServiceQuery());
    // time.writeSplit(true);

    for (ServiceDetails service : sortedSearchServices) {
      try {
        if (service.containsUserInAllowedUsers(getSessionLogin().getRemoteUser(), true)) {
          ServiceAttributes serviceAttributes = new ServiceAttributes(service, getEntityClassManager());
          Element searchServiceElement = getServiceElement(service);
          if (searchServiceElement != null) {
            boolean showResources = true;
            BindingDetails rawTableBinding = service.getResultTypeBinding(TModelCommonNameFactory.QUERYRGRAWENTITYTABLEDEFINITION_TMODELNAME);
            if (rawTableBinding != null || serviceAttributes.getEntityListCategory().size() > 1) {
              showResources = false;
            }
            servicesDocument.getRootElement().addContent(searchServiceElement);
            ExtXMLElement.addTextElement(searchServiceElement, "ID", UUID.randomUUID() + "");
            Element nameElement = searchServiceElement.getChild("Name");
            nameElement.setText(serviceAttributes.getName(ServiceNamingContext.RG_QUERY));
            Element descElement = searchServiceElement.getChild("Description");
            descElement.setText(serviceAttributes.getDescription(ServiceNamingContext.RG_QUERY));
            ExtXMLElement.addElement(searchServiceElement, "IconCls", serviceAttributes.getIconClass(ServiceNamingContext.RG_LOFT));

            CategoryKeyValue orgCatValue = serviceAttributes.getOrganizationCategoryKeyValue();
            ExtXMLElement.addTextElement(searchServiceElement, "Category", (orgCatValue == null ? "Other" : orgCatValue.getKeyName()));
            ExtXMLElement.addTextElement(searchServiceElement, "CategoryTag", serviceAttributes.getFirstEntityListCategoryLabel());
            ExtXMLElement.addTextElement(searchServiceElement, "EntityCategory", serviceAttributes.getFirstEntityListCategory() + "");
            ExtXMLElement.addTextElement(searchServiceElement, "ShowResources", showResources + "");

            ExtXMLElement.addElement(searchServiceElement, "EditableParams", serviceAttributes.countEditableParameters(null) + "");
          }
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    // time.writeSplit(true);

    return servicesDocument;
  }

  @Override
  public JSONObject getServiceRecords() throws JDOMException, AIGException {
    return getServiceRecords(getServicesDocument());
  }
}
