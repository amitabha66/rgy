package amgen.ri.aig.entity.rgdh;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.aig.AIGServlet;
import amgen.ri.json.JSONObject;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;

/**
 * @version $Id: DHAssaySearchHandler.java,v 1.4 2013/05/20 15:52:57 jemcdowe Exp $
 *
 */
public class DHAssaySearchHandler extends AIGServlet {
    public DHAssaySearchHandler() {
        super();
    }

    public DHAssaySearchHandler(HttpServletRequest req, HttpServletResponse resp) {
        super(req, resp);
    }


    /**
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return TBXServlet
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new DHAssaySearchHandler(req, resp);
    }

    /**
     *
     * @return String
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected String getServletMimeType() {
        return "text/json";
    }

    /**
     *
     * @throws Exception
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected void performRequest() throws Exception {
        DHAssayQuery.SearchType searchType= DHAssayQuery.SearchType.RACS;
        try {
            searchType= DHAssayQuery.SearchType.valueOf(getParameter("search_type").toUpperCase());
        } catch(Exception e) {}
        DHAssayQuery assayQuery= new DHAssayQuery(this);
        List<String> limitResultTypes= ExtString.splitToList(getParameter("limit_result_types"), ",\\s*", true);
        List<String> selectResultTypes= ExtString.splitToList(getParameter("select_result_types"), ",\\s*", true);
        JSONObject results = assayQuery.performSearch2JSON(getParameter("query", "").trim(), searchType, limitResultTypes, selectResultTypes);        
        response.getWriter().write(results.toString());
    }


}
