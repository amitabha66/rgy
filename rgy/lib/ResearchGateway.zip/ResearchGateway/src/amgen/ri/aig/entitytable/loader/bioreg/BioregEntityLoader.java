/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.entitytable.loader.bioreg;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.tree.EntityLineage;
import amgen.ri.aig.cache.tree.TreeNode;
import amgen.ri.aig.cache.tree.TreeNodeCache;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.entitytable.Column;
import amgen.ri.aig.entitytable.ColumnGroup;
import amgen.ri.aig.entitytable.DataCell;
import amgen.ri.aig.entitytable.DataRow;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;
import amgen.ri.aig.entitytable.loader.AbstractEntityTableLoader;
import amgen.ri.aig.sv.EntityServiceInvoker;
import amgen.ri.aig.uddi.ServiceQuery;
import amgen.ri.asf.sa.uddi.ClassificationSchemeNames;
import amgen.ri.asf.sa.uddi.ClassificationSchemeQuery;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.util.ExtString;
import com.google.common.collect.Iterables;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.apache.poi.ss.usermodel.Workbook;
import org.jdom.Document;

/**
 * EntityTable loader for Bioreg types
 *
 * @version $Id: BioregEntityLoader.java,v 1.3 2015/12/18 01:01:31 jemcdowe Exp $
 */
public class BioregEntityLoader extends AbstractEntityTableLoader {

  public BioregEntityLoader(AIGBase requestor, EntityListCategory entityCategory, String resultNodeKey) {
    super(requestor, entityCategory, resultNodeKey);
  }

  /**
   * Overrides the createEntityTableFromResultNode to create the EtityTable from a Result Node
   *
   * @param resultNodeKey String
   * @return EntityTable
   * @throws AIGException
   */
  @Override
  public EntityTable createEntityTableFromResultNode(String resultNodeKey) throws AIGException {

    //Create the table
    EntityTable entityTable = new EntityTable(getEntityTableType());
    entityTable.setServiceResultCacheItem(getRequestor().getServiceResultCacheItem(resultNodeKey));
    entityTable.setTableName(getTableName());

    ColumnGroup entityColumnGroup = new ColumnGroup(getEntityClassManager().getEntityClass(getEntityTableType()).getLabel());
    Column idColumn = new Column("BioReg ID");
    Column descColumn = new Column("Description", Column.DEFAULT_WIDTH * 2);

    entityTable.addColumnGroup(entityColumnGroup);
    entityColumnGroup.setIsEntityIDDataIndex(true);
    entityColumnGroup.addColumn(idColumn);
    entityColumnGroup.addColumn(descColumn);
    for (TreeNode childResultNode : getChildResultNodes()) {
      String name = childResultNode.getText();
      String title = childResultNode.getDescription();
      String serviceData = childResultNode.getServiceData();
      addEntityRowToEntityTable(entityTable, serviceData, name, title);
    }

    return entityTable;
  }

  @Override
  public EntityTable createEntityTableFromWorkbook(Workbook workbook, int serviceDataCategoryColNum, Map<Integer, EntityTableDataType> columnTypes) throws AIGException {
/*
    String resultNodeKey = "";

    //Get the TreeNode and Service Caches
    TreeNodeCache tnCache = getRequestor().getTreeNodeCache();
    ServiceCache svCache = getRequestor().getServiceCache();

    //Create a ClassificationSchemeQuery based on the entity table type
    ClassificationSchemeQuery query = new ClassificationSchemeQuery();
    String serviceInputKeyValue = getEntityClassManager().convertEntityListCategoryToServiceDataCategory(getEntityTableType()).revertTo();
    query.addKeyValue(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME, serviceInputKeyValue);
    //Create a service query and pull the property service for the entity type from the ServiceCache
    ServiceQuery serviceQuery = new ServiceQuery(query, TModelCommonNameFactory.ENTITYPROPERTYDEFINITION_tMODELNAME);
    ServiceDetails propertyService = Iterables.getFirst(svCache.getServices(serviceQuery), null);

    if (propertyService != null) {
      
      EntityServiceInvoker invoker= new EntityServiceInvoker((AIGServlet)getRequestor());
      invoker.invokeServiceAndCache(resultNodeKey, resultNodeKey, resultNodeKey, null, true)
      
      
      
      //Set the service parameters using the tree node (resultNodeKey)- easier than setting them directly      
      List<EntityLineage> resultLineage = tnCache.getEntityLineageForChildNodes(resultNodeKey);

      //This assumes each entity node requires a separate service call
      for (EntityLineage entityLineage : resultLineage) {
        getRequestor().setServiceParameters(propertyService, Arrays.asList(entityLineage));
        //Execute the service and transform to the Entity Property Definition, if necessary
        Document propertyResponseDocument = getRequestor().executeService2JDocument(propertyService, TModelCommonNameFactory.ENTITYPROPERTYDEFINITION_tMODELNAME, false);
        //Do something with it :)
      }
    }
*/
    return null;
  }

  /**
   * Creates a new row in the table given the entityID. Entity IDs can not be duplicated, so if thsi entityID already
   * exists in the table, this returns null. If for any other reason it can not be added, it returns null. Otherwise, it
   * returns the new DataRow
   *
   * @param entityTable EntityTable
   * @param entityID String
   * @return DataRow
   */
  public DataRow addEntityRowToEntityTable(EntityTable entityTable, String entityID, String entityLabel, String entityDesc) {
    if (ExtString.hasTrimmedLength(entityID) && ExtString.hasTrimmedLength(entityLabel) && entityTable.getDataRow(entityID) == null) {
      DataRow newDataRow = entityTable.addDataRow(new DataRow(entityID));
      if (newDataRow != null) {
        newDataRow.addDataCell(new DataCell(entityLabel));
        newDataRow.addDataCell((entityDesc == null ? new DataCell("") : new DataCell(entityDesc)));
        return newDataRow;
      }
    }
    return null;
  }

  /**
   * Overrides the createEntityTableFromResultNode to create the EntityTable from a Result Node
   *
   * @param resultNodeKey String
   * @return EntityTable
   * @throws AIGException
   */
  @Override
  public int addEntitiesToEntityTable(EntityTable entityTable, List<String> entityIDs) throws AIGException {
    int importCount = 0;
    for (String entityID : entityIDs) {
      ColumnGroup entityColumnGroup = entityTable.getColumnGroups().get(0);
      DataRow newDataRow = addEntityRowToEntityTable(entityTable, entityID, entityID, "");
      if (newDataRow != null) {
        importCount++;
        for (int i = entityColumnGroup.getColumnCount(); i < entityTable.getColumnCount(); i++) {
          newDataRow.addDataCell(new DataCell(""));
        }
      }
    }
    return importCount;
  }
}
