/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.loft;

/**
 *
 * @author jemcdowe
 */
public enum AppAttributeType {
    NAME,
    DESCRIPTION,
    ICONCLS,
    FAVORITEFOLDERITEM_ID,
    SERVICE_KEY,
    ENTITY_CATEGORY,
    UNKNOWN;
    

  public static AppAttributeType fromString(String s) {
    try {
      return AppAttributeType.valueOf(s.toUpperCase());
    } catch (Exception e) {
      return AppAttributeType.UNKNOWN;
    }
  };    

}
