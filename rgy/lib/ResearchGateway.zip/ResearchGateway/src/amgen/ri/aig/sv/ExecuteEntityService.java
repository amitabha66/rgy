package amgen.ri.aig.sv;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.rpc.ServiceException;

import org.jdom.Document;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.aig.category.schema2.AggregatedViewType;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.view.EntityServiceView;
import amgen.ri.aig.view.EntityServiceViewFactory;
import amgen.ri.asf.sa.uddi.BindingDetails;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.util.Debug;

public class ExecuteEntityService extends AIGServlet {
    private static final String SERVICE_REQUIRES_PARAMETERS_HTML =
            "<span style='font:normal 12px tahoma,arial,helvetica,sans-serif'><table cellpadding='5'><tr><td valign='top'><img src='img/service_params_needed.gif' /></td><td style='text-align:justify;width:300px'>Tool requires additional parameters. Please enter required parameters in Settings tab on the right and press <i>Update</i>.</td></tr></table></span>";

    private String serviceKey;
    private String bindingKey;
    private String resultKey;
    private String resultTypeName;
    private AggregatedViewType aggregatedViewType;
    private boolean refreshCache;

    /**
     * Default constructor
     */
    public ExecuteEntityService() {
        super();
    }

    /**
     * Main constructor- used only by the getAIGServlet method
     *
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    private ExecuteEntityService(HttpServletRequest request, HttpServletResponse response) {
        super(request, response);
        serviceKey = getParameter("serviceKey");
        bindingKey = getParameter("bindingKey");
        resultKey = getParameter("resultKey");
        resultTypeName = getParameter("resultTypeName", TModelCommonNameFactory.HTMLDEFINITION_tMODELNAME);
        aggregatedViewType = AggregatedViewType.fromString(getParameter("view_type"));
        refreshCache = doesParameterExist("refreshCache");
    }

    /**
     * Creates this AIG Servlet object
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return AIGServlet
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new ExecuteEntityService(req, resp);
    }

    /**
     * performRequest
     *
     * @throws ServletException
     * @throws IOException
     * @throws AIGException
     * @todo Implement a default result
     */
    public void performRequest() throws ServletException, IOException, AIGException {
        try {
            ServiceDetails serviceDetails = ServiceCache.getServiceCache(request).getService(serviceKey);
            if (serviceDetails.getResultTypeBinding(TModelCommonNameFactory.PROJECTVIEWDEFINITION_tMODELNAME) != null) {
                resultTypeName = TModelCommonNameFactory.PROJECTVIEWDEFINITION_tMODELNAME;
            }
            //Handle any specified view types
            switch (aggregatedViewType) {
                case ENTITY_TABLE:
                    break;
                case COMPOUND_INFO_VIEW:
                    resultTypeName = TModelCommonNameFactory.HTMLDEFINITION_tMODELNAME;
                    break;
            }
            if (bindingKey != null) {
                BindingDetails resultBinding = serviceDetails.getBinding(bindingKey);
                if (resultBinding == null) {
                    resultTypeName = null;
                } else {
                    resultTypeName = resultBinding.getFirstResultTypeName();
                }
            }
            if (resultTypeName == null) {
                throw new ServiceException("Service does not define requested result");
            }
            ServiceResultCacheItem result = getServiceResultCacheItem(resultKey);
            if (result == null || refreshCache) {
                EntityServiceInvoker invoker = new EntityServiceInvoker(this);
                resultKey = invoker.invokeServiceAndCache();
                result = getServiceResultCacheItem(resultKey);
            }
            EntityServiceView viewer = EntityServiceViewFactory.getEntityServiceView(this, resultTypeName);
            if (viewer.getViewMimetype().equals("text/html")) {
                setNoCache();
            }
            if (result != null) {
                Document resultDocument;
                if (result.getResultFormatName().equals(resultTypeName)) {
                    resultDocument = result.getResultAsDocument();
                } else {
                    resultDocument = result.transformResult(this, resultTypeName, null, true);
                }
                response.setContentType(viewer.getViewMimetype());
                viewer.renderServiceResult(resultDocument, result, serviceDetails, request, response);
            }
        } catch (AIGException e) {
            if (e.getReason().equals(AIGException.Reason.NOT_ALL_PARAMS_SET)) {
                createNeedsParametersHTML().write(response.getWriter());
                return;
            }
        } catch (ServiceException se) {
            se.printStackTrace();
            handleException(new AIGException(AIGException.Reason.NO_RESULTS, se));
        } catch (Exception ex) {
            ex.printStackTrace();
            handleException(new AIGException(" The service requested returned an error or an unknown format." + (ex.getMessage() != null ? " ("+ex.getMessage().replaceAll("\\s+", " ") +")" : ""), AIGException.Reason.UNABLE_TO_RUN_SERVICE, ex));
        }
    }

    /**
     * Returns the mimetype of the servlet
     */
    protected String getServletMimeType() {
        return null;
    }

}
