package amgen.ri.aig.entity.assay;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.CacheManager;
import amgen.ri.aig.cache.CacheManagerFactory;
import amgen.ri.aig.cache.CacheManagerIF;
import amgen.ri.aig.cache.CacheType;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.entitylist.Alias;
import amgen.ri.asf.sa.uddi.ClassificationSchemeNames;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.CompareTerm;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.servlet.SessionLogin;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.util.*;
import javax.xml.rpc.ServiceException;
import org.jdom.Document;
import org.jdom.Element;

/**
 * Contains basic details about an assay
 */
public class AssayDetails {
    private AIGServlet requestor;
    private String assayCode;
    private Alias alias;
    private List<String> selectedResultTypes = new ArrayList<String>();
    private Set<String> onlyResultTypes;
    private Map assayInformation;
    private AssayResultTypeOperations availableResultTypes;
    private int defaultSelectResultType = -1;
    private boolean isValid;


    public AssayDetails(AIGServlet requestor, Alias alias) {
        this(requestor, alias, null);
    }

    public AssayDetails(AIGServlet requestor, Alias alias, Set<String> onlyResultTypes) {
        this.onlyResultTypes = onlyResultTypes;
        this.requestor = requestor;
        availableResultTypes = AssayResultTypeOperations.getInstance();
        this.alias = alias;
        this.onlyResultTypes = null;
        setAssayInformation(alias.getAlias_value());
        setSelectedResultTypes();
    }

    public AssayDetails(AIGServlet requestor, String assayCode) {
        this(requestor, assayCode, null);
    }

    public AssayDetails(AIGServlet requestor, String assayCode, Set<String> onlyResultTypes) {
        this.onlyResultTypes = onlyResultTypes;
        this.requestor = requestor;
        availableResultTypes = AssayResultTypeOperations.getInstance();
        setAssayInformation(assayCode);
        setSelectedResultTypes();
    }


    /**
     * setSelectedResultTypes
     */
    private void setSelectedResultTypes() {
        if (selectedResultTypes.size() > 0) {
            return;
        }

    }

    /**
     * Returns the assay details Map
     *
     * @return Map
     */
    public Map getAssayDetails() {
        return assayInformation;
    }

    /**
     * Returns whether the assay details is valid
     *
     * @return boolean
     */
    public boolean isValid() {
        return isValid;
    }

    /**
     * Retrieve assay information
     *
     * @param inAssayCode String
     * @return Map
     */
    private void setAssayInformation(String extAssayCode) {
        assayInformation = new HashMap();
        try {
          CacheManagerIF cacheMgr= requestor.getCacheManager();
            this.assayCode = extAssayCode.trim();
            if (extAssayCode.indexOf(":") > 0) {
                String[] extAssayCodeFields = extAssayCode.split(":", 2);
                if (extAssayCodeFields.length != 2) {
                    throw new AIGException("Unknown assay code format", Reason.PARAMETER_ERROR);
                }
                this.assayCode = extAssayCodeFields[0];
                String[] resultTypeFields = extAssayCodeFields[1].split(",");
                for (String resultTypeField : resultTypeFields) {
                    resultTypeField = resultTypeField.trim();
                    if (resultTypeField.length() > 0) {
                        selectedResultTypes.add(resultTypeField);
                    }
                }
            }
            isValid = false;
            Document assayDescriptionDoc = (Document)cacheMgr.get(CacheType.ASSAY, this.assayCode);
            if (assayDescriptionDoc == null) {
                ServiceDetails assayPropertiesService = requestor.getLooselyCoupledServiceDetails("ASSAY_ENTITY_PROPERTIES");
                assayPropertiesService.setParameterValue(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME, "Assay Identifier", this.assayCode);
                assayDescriptionDoc = assayPropertiesService.executeService2JDocument();
                cacheMgr.put(CacheType.ASSAY, this.assayCode, assayDescriptionDoc);
            }
            if (assayDescriptionDoc != null) {
                String assayCode = ExtXMLElement.getXPathValue(assayDescriptionDoc, "/com.amgen.aim2.domainobjects.AssayDefinitionWS/assayCode");
                String assayName = ExtXMLElement.getXPathValue(assayDescriptionDoc, "/com.amgen.aim2.domainobjects.AssayDefinitionWS/assayName");
                String assayDesc = ExtXMLElement.getXPathValue(assayDescriptionDoc, "/com.amgen.aim2.domainobjects.AssayDefinitionWS/description");
                String assayClass = ExtXMLElement.getXPathValue(assayDescriptionDoc, "/com.amgen.aim2.domainobjects.AssayDefinitionWS/assayClass");
                String assaySpecies = ExtXMLElement.getXPathValue(assayDescriptionDoc,
                        "/com.amgen.aim2.domainobjects.AssayDefinitionWS/attributeValuePairs/com.amgen.aim2.domainobjects.AttributeValuePairWS[attributeName='Animal Species']/value/valueName");
                assayInformation.put("assay_code", assayCode);
                assayInformation.put("assay_name", assayName);
                assayInformation.put("assay_desc", assayDesc);
                assayInformation.put("assay_species", assaySpecies);
                assayInformation.put("assay_class", assayClass);
                if (getAlias() != null) {
                    assayInformation.put("alias_id", getAlias().getAlias_id());
                    assayInformation.put("assay_alias", getAlias().getAlias_name());
                }
                List<Element>
                        resultTypeEls = ExtXMLElement.getXPathElements(assayDescriptionDoc,
                        "/com.amgen.aim2.domainobjects.AssayDefinitionWS/resultTypes/com.amgen.aim2.domainobjects.AssayResultTypeWS");
                List resultTypesObjs = new ArrayList();
                List resultTypesLists = new ArrayList();
                for (Element resultTypeEl : resultTypeEls) {
                    String unitOfMeasure = resultTypeEl.getChildText("unitOfMeasure");
                    String resultType = resultTypeEl.getChildText("resultType");
                    if (resultType != null) {
                        String assayResultTypeId = resultTypeEl.getChildText("assayResultTypeId");
                        if (onlyResultTypes == null || onlyResultTypes.size() == 0 || onlyResultTypes.contains(resultType)) {
                            Map resultTypeObj = new HashMap();
                            List resultTypeList = new ArrayList();
                            int resultID = availableResultTypes.getResultTypeID(resultType);
                            resultTypeObj.put("result_type_display", resultType + (unitOfMeasure == null ? "" : " (" + unitOfMeasure + ")"));
                            resultTypeObj.put("result_type", resultType);
                            resultTypeObj.put("result_type_id", assayResultTypeId);
                            resultTypeObj.put("result_id", resultID);
                            resultTypesObjs.add(resultTypeObj);

                            resultTypeList.add(resultType);
                            resultTypeList.add(resultID);
                            resultTypesLists.add(resultTypeList);
                            if (availableResultTypes.getResultTypeOrder(resultType) != -1) {
                                if (defaultSelectResultType < 0) {
                                    defaultSelectResultType = availableResultTypes.getResultTypeOrder(resultType);
                                } else {
                                    defaultSelectResultType = Math.min(defaultSelectResultType, availableResultTypes.getResultTypeOrder(resultType));
                                }
                            }
                        }
                    }

                }
                assayInformation.put("result_types", resultTypesObjs);
                assayInformation.put("assay_result_types", resultTypesLists);
                updateSelectedResultTypes();
                isValid = true;
            }
        } catch (Exception e) {}
    }

    private void updateSelectedResultTypes() {
        if (selectedResultTypes.size() > 0) {
            assayInformation.put("selected_result_types", ExtString.join(selectedResultTypes, ","));
        } else if (defaultSelectResultType > -1) {
            assayInformation.put("selected_result_types", availableResultTypes.getResultTypeForOrder(defaultSelectResultType));
        } else if (assayInformation.containsKey("result_types") && ((List) assayInformation.get("result_types")).size() == 1) {
            Map resultTypeObj = (Map) ((List) assayInformation.get("result_types")).get(0);
            if (resultTypeObj.containsKey("result_type")) {
                assayInformation.put("selected_result_types", resultTypeObj.get("result_type"));
            }
        }
    }

    public String getAssayCode() {
        return assayCode;
    }

    public void clearSelectedResultType() {
        selectedResultTypes.clear();
        updateSelectedResultTypes();
    }

    public void addSelectedResultType(String resultType) {
        selectedResultTypes.add(resultType);
        updateSelectedResultTypes();
    }

    public List<String> getSelectedResultTypes() {
        return selectedResultTypes;
    }

    public Alias getAlias() {
        return alias;
    }

    public static Map<String, AssayDetails> search(AIGServlet requestor, String assayQuery, Set<String> onlyResultTypes) throws AIGException {
        AssaySearchType searchType = AssaySearchType.fromString(requestor.getParameter("search_type"));
        SessionLogin sessionLogin = requestor.getSessionLogin();
        Map<String, AssayDetails> assayDetails = new LinkedHashMap<String, AssayDetails>();
        try {
            switch (searchType) {
                case ALIAS_ID:
                    String[] aliasIDs = assayQuery.split(",");
                    for (String aliasID : aliasIDs) {
                        AssayDetails assayDetail = getAssayDetailsFromAliasID(requestor, aliasID, onlyResultTypes);
                        if (assayDetail != null) {
                            assayDetails.put(assayDetail.getAssayCode(), assayDetail);
                        }
                    }
                    break;
                case ASSAY_ID:
                    assayDetails.putAll(getAssayDetailsFromAssayIDs(requestor, assayQuery, onlyResultTypes));
                    break;
                case ALL:
                    assayDetails.putAll(getAssayDetailsFromAssayTerm(requestor, assayQuery, onlyResultTypes));
                case ALIAS: //Fall through to add the alias search to the ALL request
                    List<Alias> aliases = new RdbDataArray(Alias.class, new CompareTerm[] {
                        new CompareTerm("ALIAS_NAME", assayQuery),
                                new CompareTerm("ALIAS_TYPE", "ASSAY"),
                                new CompareTerm("CREATED_BY", sessionLogin.getRemoteUser())
                    }, new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
                    for (Alias alias : aliases) {
                        AssayDetails assayDetail = new AssayDetails(requestor, alias, onlyResultTypes);
                        if (!assayDetails.containsKey(assayDetail.getAssayCode())) {
                            assayDetails.put(assayDetail.getAssayCode(), assayDetail);
                        }
                    }
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return assayDetails;
    }

    /**
     * Returns AssayDetails for an alias ID
     * The alias ID may be of the form <alias ID>[:<Result Type1>,<Result Type2>,...] and is
     * parsed with the provided result types added as selected result types
     * after the search. Otherwise, the selected result types are those defined in the alias
     *
     * @param request HttpServletRequest
     * @param aliasID String
     * @return AssayDetails
     */
    public static AssayDetails getAssayDetailsFromAliasID(AIGServlet request, String aliasID, Set<String> onlyResultTypes) {
        AssayDetails assayDetails = null;
        if (!ExtString.hasLength(aliasID)) {
            return assayDetails;
        }
        List<String> resultTypes = new ArrayList<String>();
        if (aliasID.indexOf(':') > 0) {
            String[] split = aliasID.split(":", 2);
            if (split.length != 2) {
                return assayDetails;
            }
            aliasID = split[0];
            if (ExtString.hasLength(split[1])) {
                String[] split2 = split[1].split(",");
                for (String resultType : resultTypes) {
                    if (ExtString.hasTrimmedLength(resultType)) {
                        resultTypes.add(resultType.trim());
                    }
                }
            }
        }
        Alias alias = new Alias(aliasID.trim(), new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
        if (alias.setData()) {
            assayDetails = new AssayDetails(request, alias, onlyResultTypes);
            if (resultTypes.size() > 0) {
                assayDetails.clearSelectedResultType();
                for (String resultType : resultTypes) {
                    assayDetails.addSelectedResultType(resultType);
                }
            }
        }
        return assayDetails;
    }

    /**
     * Returns AssayDetails from an assay query.
     *
     * @param requestor HttpServletRequest
     * @param assayQuery String
     * @return Map
     */
    public static Map<String, AssayDetails> getAssayDetailsFromAssayTerm(AIGServlet requestor, String assayQuery, Set<String> onlyResultTypes) {
        Map<String, AssayDetails> assayDetails = new LinkedHashMap<String, AssayDetails>();
        try {
            if (assayQuery == null) {
                return assayDetails;
            }
            boolean assayCodesOnly = ExtString.equals(requestor.getParameter("assay_codes_only"), "true");
            Set<String> assayCodes = new HashSet<String>();
            ServiceDetails serviceDetails =  requestor.getLooselyCoupledServiceDetails("ASSAY_SEARCH");
            if (serviceDetails != null) {
                serviceDetails.setParameterValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, "Assay Identifier", assayQuery);
                serviceDetails.setParameterValue("isFlatHierarchy", "false");
            }
            Document result = serviceDetails.executeService2JDocument();
            if (assayCodesOnly) {
                //Add only the Assay Codes
                List<String> assayCodeList = ExtXMLElement.getXPathValues(result,
                        "/com.amgen.aim2.domainobjects.AssayRacsWS-array//com.amgen.aim2.domainobjects.AssayRacsWS/assayCode");
                assayCodeList.removeAll(assayDetails.keySet());
                assayCodes.addAll(assayCodeList);
            } else {
                //Add those assay codes w/o RACs
                List<String> assayCodeList1 = ExtXMLElement.getXPathValues(result,
                        "/com.amgen.aim2.domainobjects.AssayRacsWS-array/com.amgen.aim2.domainobjects.AssayRacsWS[count(racs)=0]/assayCode");
                assayCodeList1.removeAll(assayDetails.keySet());
                assayCodes.addAll(assayCodeList1);
                //Add RACs
                List<String> assayCodeList2 = ExtXMLElement.getXPathValues(result,
                        "/com.amgen.aim2.domainobjects.AssayRacsWS-array/com.amgen.aim2.domainobjects.AssayRacsWS/racs/com.amgen.aim2.domainobjects.AssayRacWS/assayCode");
                assayCodeList2.removeAll(assayDetails.keySet());
                assayCodes.addAll(assayCodeList2);
            }
            for (String assayCode : assayCodes) {
                AssayDetails assayDetail = new AssayDetails(requestor, assayCode, onlyResultTypes);
                if (assayDetail.isValid()) {
                    assayDetails.put(assayCode, assayDetail);
                }
            }
        } catch (ServiceException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return assayDetails;
    }

    /**
     * Returns AssayDetails from from one or more assay IDs. Assay IDs are of
     * the form <ID>[:<Result Type1>,<Result Type2>,...][;<ID>[:<Result
     * Type1>,<Result Type2>,...];...] and are parsed with the provided optional
     * result types added as selected result types.
     *
     * @param request HttpServletRequest
     * @param assayIDParameter String
     * @return Map
     */
    public static Map<String, AssayDetails> getAssayDetailsFromAssayIDs(AIGServlet request, String assayIDParameter, Set<String> onlyResultTypes) {
        Map<String, AssayDetails> assayDetails = new LinkedHashMap<String, AssayDetails>();
        try {
            if (!ExtString.hasLength(assayIDParameter)) {
                return assayDetails;
            }
            String[] assayCodes = assayIDParameter.split(";\\s*");
            for (String assayCode : assayCodes) {
                List<String> resultTypes = new ArrayList<String>();
                if (ExtString.hasLength(assayCode)) {
                    AssayDetails details = new AssayDetails(request, assayCode, onlyResultTypes);
                    if (details.isValid) {
                        assayDetails.put(details.getAssayCode(), details);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return assayDetails;
    }

    public String toString() {
        return assayCode + " (" + alias + ")";
    }
}
