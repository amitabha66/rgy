/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.ora;

import amgen.ri.aig.cache.CacheType;
import amgen.ri.aig.cache.CacheUtils;
import amgen.ri.aig.cache.item.GlobalCacheItem;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.asf.sa.uddi.ClassificationSchemeQuery;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Blob;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.lang.ArrayUtils;
import org.jdom.Document;

/**
 *
 * @author jemcdowe
 */
public class CacheItemDAO {

  private String requestUser;
  private ServiceNamingContext nameContext;

  private String cacheType;
  private String sessionID;
  private String key;
  private List<String> keys;
  private List<String> offlineKeys;
  private boolean offline;
  private boolean success;
  private Object cacheObj;

  private List<String> queryKeys;

  private List<GlobalCacheItem> cacheItems;

  private boolean contains;

  public CacheItemDAO(CacheType cacheType, String sessionID) {
    this.cacheType = cacheType.toString();
    this.cacheItems = new ArrayList<GlobalCacheItem>();
    this.queryKeys = new ArrayList<String>();
    this.sessionID = sessionID;
    this.offline = false;
  }

  public CacheItemDAO(String sessionID) {
    this(CacheType.SERVICE, sessionID);
  }

  public CacheItemDAO(CacheType cacheType, String sessionID, String key) {
    this(cacheType, sessionID);
    this.key = key;
  }

  public CacheItemDAO(CacheType cacheType, String sessionID, String key, Object cacheObj) {
    this(cacheType, sessionID, key);
    this.cacheObj = cacheObj;
  }

  public List<String> getKeys() {
    return keys;
  }

  public void setKeys(Collection<String> keys) {
    this.keys = new ArrayList<String>(keys);
  }

  public List<String> getOfflineKeys() {
    return offlineKeys;
  }

  public void setOfflineKeys(Collection<String> offlineKeys) {
    this.offlineKeys = new ArrayList<String>(offlineKeys);
  }

  /**
   * Get the value of cacheType
   *
   * @return the value of cacheType
   */
  public String getCacheType() {
    return cacheType;
  }

  /**
   * Set the value of cacheType
   *
   * @param cacheType new value of cacheType
   */
  public void setCacheType(String cacheType) {
    this.cacheType = cacheType;
  }

  /**
   * @return the sessionID
   */
  public String getSessionID() {
    return sessionID;
  }

  /**
   * @param sessionID the sessionID to set
   */
  public void setSessionID(String sessionID) {
    this.sessionID = sessionID;
  }

  /**
   * @return the key
   */
  public String getKey() {
    return key;
  }

  /**
   * @param key the key to set
   */
  public void setKey(String key) {
    this.key = key;
  }

  /**
   * Get the value of offline
   *
   * @return the value of offline
   */
  public boolean isOffline() {
    try {
      if (cacheObj instanceof GlobalCacheItem && ((GlobalCacheItem) cacheObj).getCacheObject() instanceof OfflineServiceDetails) {
        return true;
      }
    } catch (Exception e) {
    }
    return offline;
  }

  /**
   * Set the value of offline
   *
   * @param offline new value of offline
   */
  public void setOffline(Integer offline) {
    this.offline = (offline == null || offline != 0);
  }

  /**
   * Get the value of requestUser
   *
   * @return the value of requestUser
   */
  public String getRequestUser() {
    return requestUser;
  }

  /**
   * Set the value of requestUser
   *
   * @param requestUser new value of requestUser
   */
  public void setRequestUser(String requestUser) {
    this.requestUser = requestUser;
  }

  /**
   * Get the value of nameContext
   *
   * @return the value of nameContext
   */
  public String getNameContext() {
    return nameContext.toString().toLowerCase();
  }

  /**
   * Set the value of nameContext
   *
   * @param nameContext new value of nameContext
   */
  public void setNameContext(ServiceNamingContext nameContext) {
    this.nameContext = nameContext;
  }

  /**
   * Get the value of queryKey
   *
   * @return the value of queryKey
   */
  public List<String> getQueryKeys() {
    return queryKeys;
  }

  /**
   * Set the value of queryKey
   *
   * @param queryKey new value of queryKey
   */
  public void setQueryKey(List<String> queryKeys) {
    this.queryKeys.addAll(queryKeys);
  }

  public Multimap<String, ClassificationSchemeQuery> getClassificationSchemeQueries() {
    Multimap<String, ClassificationSchemeQuery> classificationSchemeQueryMap = ArrayListMultimap.create();
    for (String queryKey : getQueryKeys()) {
      Collection<ClassificationSchemeQuery> classificationQueries = CacheUtils.buildQueryFromKey(queryKey);
      for (ClassificationSchemeQuery classificationQuery : classificationQueries) {
        classificationSchemeQueryMap.put(queryKey, classificationQuery);
      }
    }
    return classificationSchemeQueryMap;
  }

  /**
   * Get the value of contains
   *
   * @return the value of contains
   */
  public boolean contains() {
    return contains;
  }

  /**
   * Set the value of contains
   *
   * @param contains new value of contains
   */
  public void setContains(Integer contains) {
    this.contains = (contains != 0);
  }

  /**
   * @return the cacheObj
   */
  public Object getCacheObj() {
    return cacheObj;
  }

  /**
   * Returns the CacheItems List
   *
   * @return
   */
  public List<GlobalCacheItem> getCacheItems() {
    return cacheItems;
  }

  /**
   * Returns the CacheItems Keys as a unique List
   *
   * @return
   */
  public List<String> getCacheItemKeys() {
    Set<String> keys= new LinkedHashSet<String>();
    for(GlobalCacheItem cacheItem : getCacheItems()) {
      keys.add(cacheItem.getKey());
    }
    return new ArrayList<String>(keys);
  }

  /**
   * @param cacheObj the cacheObj to set
   */
  public void setCacheObj(Object cacheObj) {
    this.cacheObj = cacheObj;
    if (cacheObj instanceof GlobalCacheItem) {
      this.cacheItems.clear();
      this.cacheItems.add((GlobalCacheItem) cacheObj);
    }
  }

  public byte[] getResults() throws IOException {
    try {
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      ObjectOutputStream objOut = new ObjectOutputStream(out);
      objOut.writeObject(cacheObj);
      return out.toByteArray();
    } catch (Exception e) {
      e.printStackTrace();
    }
    return new byte[0];
  }

  /**
   * Set the value of results
   *
   * @param results new value of results
   */
  public void setResults(Byte[] results) {
    if (results == null || results.length == 0) {
      return;
    }
    ObjectInputStream objIN = null;
    try {
      objIN = new ObjectInputStream(new ByteArrayInputStream(ArrayUtils.toPrimitive(results)));
      setCacheObj(objIN.readObject());
    } catch (Exception ex) {
      Logger.getLogger(CacheItemDAO.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
      try {
        objIN.close();
      } catch (IOException ex) {
        Logger.getLogger(CacheItemDAO.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
  }

  public Document getXml() {
    try {
      if (cacheObj instanceof GlobalCacheItem && ((GlobalCacheItem) cacheObj).getCacheObject() instanceof ServiceDetails) {
        GlobalCacheItem cacheItem = (GlobalCacheItem) cacheObj;
        ServiceDetails serviceDetails = (ServiceDetails) cacheItem.getCacheObject();

        return new Document(serviceDetails.getAsElement(true, false));
      }
    } catch (Exception e) {
    }
    return null;
  }

  public void setCacheItems(List<Blob> blobs) {
    this.cacheItems.clear();
    this.cacheObj = cacheItems;
    for (Blob blob : blobs) {
      ObjectInputStream objIN = null;
      try {
        objIN = new ObjectInputStream(blob.getBinaryStream());
        this.cacheItems.add((GlobalCacheItem) objIN.readObject());
      } catch (Exception ex) {
        Logger.getLogger(CacheItemDAO.class.getName()).log(Level.SEVERE, null, ex);
      } finally {
        try {
          objIN.close();
        } catch (IOException ex) {
          Logger.getLogger(CacheItemDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
      }
    }
  }

  /**
   * @return the success
   */
  public boolean isSuccess() {
    return success;
  }

  /**
   * @param success the success to set
   */
  public void setSuccess(Integer success) {
    this.success = success.equals(1);
  }
}
