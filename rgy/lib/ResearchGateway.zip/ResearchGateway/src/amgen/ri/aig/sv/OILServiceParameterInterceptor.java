/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.sv;

import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.entity.EntityClass;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.asf.sa.uddi.*;
import amgen.ri.rg.resource.ResourceFactory;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ListMultimap;
import java.util.*;

/**
 *
 * @author jemcdowe
 */
public class OILServiceParameterInterceptor extends ResourceFactory implements ServiceListenerIF {

  private EntityClassManager entityClassManager;
  //Parameters which were set by their defined Entity Class:
  // This specifies specific parameters which to perform any conversion
  private Map<ServiceParameter, EntityClass> parametersSetByEntityClass;
  //Defines an Entity Class which all parameters that are defined get included in 
  // the parametersSetByEntityClass and are therefore converted as necessary.
  // Note- It is possible that a parameter is already included in parametersSetByEntityClass. If
  // so, this does not change that 
  private Set<EntityClass> entityClassToIncludeParameters;

  public OILServiceParameterInterceptor() {
    this(new EntityClassManager());
  }

  public OILServiceParameterInterceptor(EntityClassManager entityClassManager) {
    this.entityClassManager = entityClassManager;
    parametersSetByEntityClass = new HashMap<ServiceParameter, EntityClass>();
    entityClassToIncludeParameters = new HashSet<EntityClass>();
  }

  public void setParametersSetByEntityClass(EntityClass entityClass, List<ServiceParameter> parameters) {
    if (entityClass == null || parameters == null) {
      return;
    }
    for (ServiceParameter parameter : parameters) {
      parametersSetByEntityClass.put(parameter, entityClass);
    }
  }

  public void setParametersSetByEntityClass(EntityClass entityClass, ServiceParameter... parameters) {
    if (entityClass == null || parameters == null) {
      return;
    }
    setParametersSetByEntityClass(entityClass, Arrays.asList(parameters));
  }

  public void setParametersSetByEntityClass(ServiceDataCategory serviceDataCategory, List<ServiceParameter> parameters) {
    if (serviceDataCategory == null || parameters == null) {
      return;
    }
    setParametersSetByEntityClass(entityClassManager.getEntityClass(serviceDataCategory), parameters);
  }

  public void setParametersSetByEntityClass(ServiceDataCategory serviceDataCategory, ServiceParameter... parameters) {
    if (serviceDataCategory == null || parameters == null) {
      return;
    }
    setParametersSetByEntityClass(serviceDataCategory, Arrays.asList(parameters));
  }

  public void setParametersSetByEntityClass(EntityListCategory entityListCategory, List<ServiceParameter> parameters) {
    if (entityListCategory == null || parameters == null) {
      return;
    }
    setParametersSetByEntityClass(entityClassManager.getEntityClass(entityListCategory), parameters);
  }

  public void setParametersSetByEntityClass(EntityListCategory entityListCategory, ServiceParameter... parameters) {
    if (entityListCategory == null || parameters == null) {
      return;
    }
    setParametersSetByEntityClass(entityListCategory, Arrays.asList(parameters));
  }

  public void setParametersSetByEntityClass(ServiceParameterCategory serviceParameterCategory, List<ServiceParameter> parameters) {
    if (serviceParameterCategory == null || parameters == null) {
      return;
    }
    setParametersSetByEntityClass(entityClassManager.getEntityClass(serviceParameterCategory), parameters);
  }

  public void setParametersSetByEntityClass(ServiceParameterCategory serviceParameterCategory, ServiceParameter... parameters) {
    if (serviceParameterCategory == null || parameters == null) {
      return;
    }
    setParametersSetByEntityClass(serviceParameterCategory, Arrays.asList(parameters));
  }

  public boolean serviceStarted(ServiceDetails serviceDetails) {
    //First add any parameters identified by entityClassToIncludeParameters
    // to the parametersSetByEntityClass which are not already in that Collection
    ServiceAttributes serviceAttributes = new ServiceAttributes(serviceDetails, getEntityClassManager());
    ArrayListMultimap<EntityClass, ServiceParameter> entityClassParameterMap = serviceAttributes.getServiceParametersByEntityClass();
    for (EntityClass entityClass : entityClassToIncludeParameters) {
      List<ServiceParameter> serviceParameters = entityClassParameterMap.get(entityClass);
      if (serviceParameters != null) {
        for (ServiceParameter serviceParameter : serviceParameters) {
          if (!parametersSetByEntityClass.containsKey(serviceParameter)) {
            parametersSetByEntityClass.put(serviceParameter, entityClass);
          }
        }
      }
    }
    ListMultimap<EntityClass, ServiceParameter> entityParameters = ArrayListMultimap.create();
    for (ServiceParameter parameterAsSet : parametersSetByEntityClass.keySet()) {
      EntityClass entityClassAsSet = parametersSetByEntityClass.get(parameterAsSet);
      ServiceParameter serviceParameter = serviceDetails.getParameter(parameterAsSet.getParameterName());
      List<EntityClass> entityClasses = entityClassManager.getEntityClasses(serviceParameter);

      EntityClass entityClass = null;
      for (EntityClass ec : entityClasses) {
        if (ec.getEntityCategory().equals(entityClassAsSet.getEntityCategory())) {
          entityClass = ec;
          break;
        }
      }
      if (entityClass != null) {
        entityParameters.put(entityClass, serviceParameter);
      }
    }
    for (EntityClass entityClass : entityParameters.keySet()) {
      try {
        entityClass.convertUID(entityClassManager, entityParameters.get(entityClass));
      } catch (Exception e) {
        e.printStackTrace();
        return false;
      }
    }
    return true;
  }

  public boolean transformStarted(ServiceDetails serviceDetails) {
    return true;
  }

  public void transformEnded(ServiceDetails serviceDetails, ServiceInvocationDetails details) {
  }

  public void serviceEnded(ServiceDetails serviceDetails, ServiceInvocationDetails details) {
  }

  public void serviceFailed(ServiceDetails serviceDetails, ServiceInvocationDetails details) {
  }

  /**
   * @return the entityClassToIncludeParameters
   */
  public Set<EntityClass> getEntityClassToIncludeParameters() {
    return entityClassToIncludeParameters;
  }

  /**
   * @param entityClassToIncludeParameters the entityClassToIncludeParameters to
   * set
   */
  public void addEntityClassesToIncludeParameters(EntityClass... entityClassToIncludeParameters) {
    this.entityClassToIncludeParameters.addAll(Arrays.asList(entityClassToIncludeParameters));
  }
}
