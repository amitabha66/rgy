/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.entitytable.loader.lmr;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.tree.TreeNode;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.entitytable.*;
import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;
import amgen.ri.aig.entitytable.loader.AbstractEntityTableLoader;
import amgen.ri.util.ExtString;
import java.util.List;
import java.util.Map;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * EntityTable loader for LMR types
 *
 * @version $Id: GenericEntityTableLoader.java,v 1.3 2011/06/22 23:05:15 cvs Exp
 * $
 */
public class LMREntityTableLoader extends AbstractEntityTableLoader {
  public LMREntityTableLoader(AIGBase requestor, EntityListCategory entityTableType) {
    this(requestor, entityTableType, null);
  }

  public LMREntityTableLoader(AIGBase requestor, EntityListCategory entityTableType, String resultNodeKey) {
    super(requestor, entityTableType, resultNodeKey);
  }

  /**
   * Overrides the createEntityTableFromResultNode to create the EtityTable from
   * a Result Node
   *
   * @param resultNodeKey String
   * @return EntityTable
   * @throws AIGException
   */
  @Override
  public EntityTable createEntityTableFromResultNode(String resultNodeKey) throws AIGException {
    //Create the table
    EntityTable entityTable = new EntityTable(getEntityTableType());
    entityTable.setServiceResultCacheItem(getRequestor().getServiceResultCacheItem(resultNodeKey));
    entityTable.setTableName(getTableName());

    ColumnGroup entityColumnGroup = new ColumnGroup(getEntityClassManager().getEntityClass(getEntityTableType()).getLabel());
    Column lmrIDColumn = new Column("LMR ID");
    Column nameColumn = new Column("Name", Column.DEFAULT_WIDTH * 2);

    switch (getEntityTableType()) {
      case LMR_PROTEIN_LOTS:
        nameColumn.setHeaderText("Protein Name");
        break;
      case LMR_EXPRESSION_SYSTEMS:
        lmrIDColumn = new Column("Expression System ID");
        nameColumn.setHeaderText("Expression System Name");
        break;
      case LMR_CONSTRUCTS:
        lmrIDColumn = new Column("Construct ID");
        nameColumn.setHeaderText("Construct Name");
        break;
      case LMR_HARVESTS:
        lmrIDColumn = new Column("Harvest ID");
        nameColumn.setHeaderText("Protein Name");
        break;
      case LMR_RECOMBINANT_SEQUENCES:
        lmrIDColumn = new Column("Sequence ID");
        nameColumn.setHeaderText("Sequence Name");
        break;
      case LMR_REQUESTS:
        lmrIDColumn = new Column("Request ID");
        nameColumn.setHeaderText("Request Title");
        break;
      case LMR_SEQUENCE_SETS:
        lmrIDColumn = new Column("Sequence Set ID");
        nameColumn.setHeaderText("Protein Name");
        break;
    }

    if (entityColumnGroup != null) {
      entityTable.addColumnGroup(entityColumnGroup);
      entityColumnGroup.setIsEntityIDDataIndex(true);
      entityColumnGroup.addColumn(lmrIDColumn);
      entityColumnGroup.addColumn(nameColumn);
      for (TreeNode childResultNode : getChildResultNodes()) {
        String name = childResultNode.getText();
        String title = childResultNode.getDescription();
        String serviceData = childResultNode.getServiceData();
        addEntityRowToEntityTable(entityTable, serviceData, name, title);
      }
    }
    return entityTable;
  }

  @Override
  public EntityTable createEntityTableFromWorkbook(Workbook workbook, int serviceDataCategoryColNum, Map<Integer, EntityTableDataType> columnTypes) throws AIGException {
    return null;
  }

  /**
   * Creates a new row in the table given the entityID. Entity IDs can not be
   * duplicated, so if thsi entityID already exists in the table, this returns
   * null. If for any other reason it can not be added, it returns null.
   * Otherwise, it returns the new DataRow
   *
   * @param entityTable EntityTable
   * @param entityID String
   * @return DataRow
   */
  public DataRow addEntityRowToEntityTable(EntityTable entityTable, String entityID, String entityLabel, String entityDesc) {
    if (ExtString.hasTrimmedLength(entityID) && ExtString.hasTrimmedLength(entityLabel) && entityTable.getDataRow(entityID) == null) {
      DataRow newDataRow = entityTable.addDataRow(new DataRow(entityID));
      if (newDataRow != null) {
        newDataRow.addDataCell(new DataCell(entityLabel));
        newDataRow.addDataCell((entityDesc == null ? new DataCell("") : new DataCell(entityDesc)));
        return newDataRow;
      }
    }
    return null;
  }

  /**
   * Overrides the createEntityTableFromResultNode to create the EntityTable
   * from a Result Node
   *
   * @param resultNodeKey String
   * @return EntityTable
   * @throws AIGException
   */
  @Override
  public int addEntitiesToEntityTable(EntityTable entityTable, List<String> entityIDs) throws AIGException {
    int importCount = 0;
    for (String entityID : entityIDs) {
      ColumnGroup entityColumnGroup = entityTable.getColumnGroups().get(0);
      DataRow newDataRow = addEntityRowToEntityTable(entityTable, entityID, entityID, "");
      if (newDataRow != null) {
        importCount++;
        for (int i = entityColumnGroup.getColumnCount(); i < entityTable.getColumnCount(); i++) {
          newDataRow.addDataCell(new DataCell(""));
        }
      }
    }
    return importCount;
  }
}
