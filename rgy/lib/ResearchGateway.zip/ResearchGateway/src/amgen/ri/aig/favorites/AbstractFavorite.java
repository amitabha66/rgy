package amgen.ri.aig.favorites;

import amgen.ri.aig.AIGBase;
import java.io.ObjectStreamException;
import java.lang.reflect.Field;
import java.util.List;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.aig.sobj.ObjectType;
import amgen.ri.aig.sobj.SavedObject;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.CompareTerm;
import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.rdb.SQLManagerIF;
import amgen.ri.xml.ExtXMLElement;
import java.util.ArrayList;
import org.jdom.Document;

/**
 * <p>@version $Id: AbstractFavorite.java,v 1.2 2011/06/21 17:28:57 cvs Exp
 * $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public abstract class AbstractFavorite extends RdbData implements FavoriteIF {
  private Person createdByPerson;

  public AbstractFavorite() {
    super();
  }

  public AbstractFavorite(SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
  }

  /**
   * This method is required EXACTLY as written to allow the RdbData
   * architecture access to the class variables.
   */
  protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
    field.set(this, value);
  }

  /**
   * This method is required EXACTLY as written to allow the RdbData
   * architecture access to the class variables.
   */
  protected Object getFieldValue(Field field) throws IllegalAccessException {
    return field.get(this);
  }

  /**
   * Returns the SQL for INSERTing the object in the table
   */
  public String getInsertSQL() {
    return null;
  }

  /**
   * Returns the SQL for UPDATing the object in the table
   */
  public String getUpdateSQL() {
    return null;
  }

  /**
   * Returns the SQL for DELTEing the object/row in the table
   */
  public String getDeleteSQL() {
    return null;
  }

  /**
   * Returns the FavoriteFolderItem for the Favorite/SharedFavorite. null if
   * none- which is due to it being new
   *
   * @return FavoriteFolderItem
   */
  public FavoriteFolderItem getFavoriteFolderItem() {
    FavoriteFolderItem.ItemType type;
    if (this instanceof Favorite) {
      type = FavoriteFolderItem.ItemType.FAVORITE;
    } else {
      type = FavoriteFolderItem.ItemType.SHARED_FAVORITE;
    }

    List<FavoriteFolderItem> folderItems = new RdbDataArray(FavoriteFolderItem.class, new CompareTerm[]{
              new CompareTerm("OWNED_BY", getCreated_by()), new CompareTerm("ITEM_TYPE", type), new CompareTerm("ITEM_KEY", getIdentifier())
            }, getSQLManager(), getLogonUsername(), getConnectionPool());
    return (folderItems.size() > 0 ? folderItems.get(0) : null);
  }
  /**
   * Returns the CreatedBy person from the Favorite as a Person
   * @return 
   */
  public Person getCreatedByPerson() {
    if (createdByPerson == null) {
      Favorite favorite;
      if (this instanceof Favorite) {
        favorite= (Favorite)this;
      } else {
        favorite= ((SharedFavorite)this).getFavorite();
      }
      this.createdByPerson = Person.getPersonForAmgenLogin(favorite.getCreated_by(), getSQLManager(), getConnectionPool());      
    }
    return createdByPerson;

  }

  /**
   * Returns the EntityListCategory of the favorite
   *
   * @return EntityListCategory
   */
  @Override
  public EntityListCategory getCategory() {
    Favorite favorite = null;
    if (this instanceof Favorite) {
      favorite = (Favorite) this;
    } else if (this instanceof SharedFavorite) {
      favorite = ((SharedFavorite) this).getFavorite();
    }
    return favorite.getCategory();
  }

  /**
   * Returns the ObjectType.Type of the favorite
   *
   * @return ObjectType.Type
   */
  @Override
  public ObjectType.Type getType() {
    if (getObjectType() != null) {
      return getObjectType().getType();
    } else {
      return ObjectType.Type.UNKNOWN;
    }
  }

  /**
   * Returns the EntityTable object of this AbstractFavorite- if it is an
   * EntityTable. Throws an exception otherwise.
   *
   * @return EntityTable
   * @throws AIGException
   */
  public EntityTable getEntityTable() throws AIGException, ObjectStreamException {
    Favorite favorite = null;
    try {
      if (this instanceof Favorite) {
        favorite = (Favorite) this;
      } else if (this instanceof SharedFavorite) {
        favorite = ((SharedFavorite) this).getFavorite();
      }
      JSONObject jFavKey = favorite.getFavoriteKeys()[0].getFavoriteKeyAsJSON();
      SavedObject savedObject = new SavedObject(jFavKey.getString("key"), new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
      if (!savedObject.setData()) {
        throw new AIGException("Unable to load EntityTable", Reason.UNABLE_TO_RETRIEVE_ENTRY);
      }
      if (!savedObject.getObject_type().getType().equals(ObjectType.Type.ENTITYTABLE)) {
        throw new IllegalArgumentException("Unable to load EntityTable- Invalid saved type");
      }
      EntityTable entityTable = (EntityTable) savedObject.getSavedObject();
      entityTable.setTableName(savedObject.getName());
      entityTable.setDescription(savedObject.getDescription());
      entityTable.setSavedObject(savedObject);
      return entityTable;
    } catch (ObjectStreamException ce) {
      throw ce;
    } catch (Exception e) {
      throw new AIGException("Unable to load table", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }
  }

  public boolean isValid(AIGBase requestor) {
    if (getObjectType() != null) {
      switch (getObjectType().getType()) {
        case ENTITYTABLE:
          try {
            getEntityTable();
          } catch (Exception e) {
            return false;
          }
          break;
        case SERVICE:
          try {
            SavedObject savedServiceObject = (SavedObject) getFavoriteObject();
            if (!savedServiceObject.setData()) {
              throw new AIGException("Unable to load saved service", Reason.UNABLE_TO_RETRIEVE_ENTRY);
            }
            Object obj = savedServiceObject.getSavedObject();
            if (obj instanceof Document) {
              Document serviceDoc = (Document) obj;
              return true;
            }
            return false;
          } catch (Exception e) {
            e.printStackTrace();
            return false;
          }

      }
    }
    return true;
  }
  
	/** Get value for favorite_key */
	public List<String> getFavoriteKeyList() {
		List<String> favoriteKeyList = new ArrayList<String>();
		FavoriteKey[] keys = getFavoriteKeys();
		if (keys != null) {
			for (FavoriteKey key : keys) {
				favoriteKeyList.add(key.getFavorite_key());
			}
		}
		return favoriteKeyList;
	}
  
}
