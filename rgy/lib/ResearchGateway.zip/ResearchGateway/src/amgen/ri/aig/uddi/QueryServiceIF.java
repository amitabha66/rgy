/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amgen.ri.aig.uddi;

import java.util.Collection;

/**
 *
 * @author jemcdowe
 */
public interface QueryServiceIF {

  public ServiceQuery getServiceQuery();
  
  /**
   * Returns the ServiceQueries to cache- used only by the Cache system
   * @return 
   */
  public Collection<ServiceQuery> getCacheServiceQueries();
  
}
