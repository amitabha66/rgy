package amgen.ri.aig.scripts;

import java.lang.reflect.InvocationTargetException;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

/**
 * @version $Id: CalculationScriptsIF.java,v 1.1 2011/06/17 20:41:25 cvs Exp $
 * Add scripts to the provided scope
 */
public interface CalculationScriptsIF {
    public void addScripts(Context cx, Scriptable scope) throws InvocationTargetException, InstantiationException, IllegalAccessException;
}
