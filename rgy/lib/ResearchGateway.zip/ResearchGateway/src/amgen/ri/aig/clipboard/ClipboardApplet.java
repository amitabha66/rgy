package amgen.ri.aig.clipboard;

import java.applet.Applet;
import java.awt.HeadlessException;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;

/**
 * Clipboard Applet is a signed applet which allows interaction with the desktop
 * clipboard via javascript.
 * @version $id$
 */
public class ClipboardApplet extends Applet {
    public ClipboardApplet() throws HeadlessException {
        super();
    }

    /**
     * Sets text to the desktop clipboard
     *
     * @param s String
     * @throws PrivilegedActionException
     */
    public void setClipboard(String s) throws PrivilegedActionException {
        AccessController.doPrivileged(new SetClipboardPrivilegedExceptionAction(s));
    }

    /**
     * Retrieves text from the desktop clipboard. Null if empty.
     *
     * @return String
     * @throws PrivilegedActionException
     */
    public String getClipboard() throws PrivilegedActionException {
        Object obj = AccessController.doPrivileged(new PrivilegedExceptionAction() {
            public Object run() throws Exception {
                return new ClipboardTransfer().getClipboardContents();
            }
        });
        return (obj == null ? null : obj + "");
    }

    /**
     * Private class for passing arguments to the clipboard privledged action.
     */
    class SetClipboardPrivilegedExceptionAction implements PrivilegedExceptionAction {
        private String arg;
        public SetClipboardPrivilegedExceptionAction(String arg) {
            this.arg = arg;
        }

        public Object run() throws Exception {
            new ClipboardTransfer().setClipboardContents(arg);
            return null;
        }

    }
}
