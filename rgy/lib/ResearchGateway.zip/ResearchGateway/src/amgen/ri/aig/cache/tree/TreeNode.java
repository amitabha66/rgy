package amgen.ri.aig.cache.tree;

import amgen.ri.aig.cache.item.CacheItemIF;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.util.ExtString;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jdom.Attribute;
import org.jdom.Element;

/**
 * A fly element for retrieving key attributes from a TreeNode element
 *
 * @version $id$
 */
public class TreeNode implements CacheItemIF {
  private Element node;

  /**
   * Create a TreeNode
   *
   * @param node Element
   */
  public TreeNode(Element node) {
    this.node = node;
  }

  /**
   * Whether the wrapped tree node appears to be valid
   *
   * @return boolean
   */
  public boolean isValid() {
    if (node == null) {
      return false;
    }
    if (getKey() == null) {
      return false;
    }
    return (getNodeType().equals(NodeType.UNKNOWN) ? false : true);
  }

  /**
   * Return the source node
   *
   * @return Element
   */
  public Element getNode() {
    return node;
  }

  /**
   * Return the node key (UUID)
   *
   * @return String
   */
  public String getUUID() {
    return getNodeAttribute("UUID");
  }

  /**
   * Return the node key (UUID)
   *
   * @return String
   */
  public String getKey() {
    return getUUID();
  }

  /**
   * Return the node text
   *
   * @return String
   */
  public String getText() {
    return getNodeAttribute("TEXT");
  }

  /**
   * Set the node text
   */
  public void setText(String text) {
    setNodeAttribute("TEXT", text);
  }

  /**
   * Return the node TITLE
   *
   * @return String
   */
  public String getDescription() {
    return getNodeAttribute("TITLE");
  }

  /**
   * Set the node TITLE
   */
  public void setDescription(String description) {
    setNodeAttribute("TITLE", description);
  }

  /**
   * Return the node service data
   *
   * @return String
   */
  public String getServiceData() {
    return getNodeAttribute("SERVICE_DATA");
  }

  /**
   * Set the node service data
   */
  public void setServiceData(String serviceData) {
    setNodeAttribute("SERVICE_DATA", serviceData);
  }

  /**
   * Return the NodeType
   *
   * @return NodeType
   */
  public NodeType getNodeType() {
    return NodeType.getNodeType(node);
  }

  /**
   * Return the ServiceDataCategory
   *
   * @return ServiceDataCategory
   */
  public ServiceDataCategory getServiceDataCategory() {
    return ServiceDataCategory.getServiceDataCategory(node);
  }

  /**
   * Return the EntityListCategory
   *
   * @param entityClassManager
   * @return EntityListCategory
   */
  public EntityListCategory getEntityListCategory(EntityClassManager entityClassManager) {
    return entityClassManager.convertServiceDataCategoryToEntityListCategory(ServiceDataCategory.getServiceDataCategory(node));
  }

  /**
   * Returns whether the node matches the given NodeType
   *
   * @param nodeType NodeType
   * @return boolean
   */
  public boolean isNodeType(NodeType nodeType) {
    return NodeType.isNodeType(node, nodeType);
  }

  /**
   * Returns whether the node matches the given ServiceDataCategory
   *
   * @param category ServiceDataCategory
   * @return boolean
   */
  public boolean isServiceDataCategory(ServiceDataCategory category) {
    return ServiceDataCategory.isServiceDataCategory(node, category);
  }

  /**
   * Method for returning an attribute or null if node is null or the
   * node does not have the attribute
   *
   * @param attrName String
   * @return String
   */
  public String getNodeAttribute(String attrName) {
    return (node == null ? null : node.getAttributeValue(attrName));
  }

  /**
   * Method for setting an attribute value
   *
   * @param attrName String
   * @param attrValue String
   */
  public void setNodeAttribute(String attrName, String attrValue) {
    if (node != null && ExtString.hasLength(attrName) && ExtString.hasLength(attrValue)) {
      node.setAttribute(attrName, attrValue);
    }
  }

  /**
   * setServiceDataCategory
   *
   * @param serviceDataCategory ServiceDataCategory
   */
  public void setServiceDataCategory(ServiceDataCategory serviceDataCategory) {
    setNodeAttribute("SERVICE_DATA_TYPE_CATEGORY", ServiceDataCategory.revertTo(serviceDataCategory));
  }

  /**
   * Returns all Node attributes as a Map
   *
   * @return
   */
  public Map<String, Object> getProperties() {
    Map<String, Object> attributes = new HashMap<String, Object>();
    for (Attribute attribute : (List<Attribute>) node.getAttributes()) {
      attributes.put(attribute.getName(), attribute.getValue());
    }
    return attributes;
  }

  /**
   * Returns a Node attribute
   *
   * @param key
   * @return
   */
  public Object getProperty(String key) {
    return getNodeAttribute(key);
  }

  /**
   * Sets Node attributes
   *
   * @param properties
   */
  public void setProperties(Map<String, Object> properties) {
    for (String name : properties.keySet()) {
      Object value = properties.get(name);
      if (value != null) {
        setNodeAttribute(name, value + "");
      }
    }
  }

  /**
   * Sets a Node attribute
   *
   * @param key
   * @param property
   */
  public void setProperty(String key, Object property) {
    if (property != null) {
      setNodeAttribute(key, property + "");
    }
  }

  /**
   * Returns the Node as an Element- What is actually in the Cache
   *
   * @return
   */
  public Object getCacheObject() {
    return getNode();
  }
}
