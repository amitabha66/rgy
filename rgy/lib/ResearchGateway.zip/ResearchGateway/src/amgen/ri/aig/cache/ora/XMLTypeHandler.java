/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.ora;

import amgen.ri.xml.ExtXMLElement;
import java.io.Reader;
import java.io.Writer;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleResultSet;
import oracle.sql.CLOB;
import oracle.sql.OPAQUE;
import oracle.xdb.XMLType;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.jdom.Document;
import org.jdom.input.SAXBuilder;
import org.jdom.output.DOMOutputter;

/**
 *
 * @author jemcdowe
 */
public class XMLTypeHandler extends BaseTypeHandler<Document> {

    @Override
    public void setNonNullParameter(PreparedStatement ps, int i, Document doc, JdbcType jt) throws SQLException {
        OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement) ps.unwrap(OraclePreparedStatement.class);
        try {
            if (doc != null) {
                oraclePreparedStatement.setCLOB(i, getCLOB(doc, oraclePreparedStatement.getConnection()));
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        oraclePreparedStatement.setNull(i, oracle.jdbc.OracleTypes.OPAQUE, "SYS.XMLTYPE");
    }

    private CLOB getCLOB(Document doc, Connection conn) throws SQLException {
        CLOB tempClob = null;
        try {
            tempClob = CLOB.createTemporary(conn, true, CLOB.DURATION_SESSION);
            tempClob.open(CLOB.MODE_READWRITE);
            Writer tempClobWriter = tempClob.setCharacterStream(0);
            ExtXMLElement.write(doc, tempClobWriter);
            tempClobWriter.flush();
            tempClobWriter.close();
            tempClob.close();
        } catch (SQLException sqlexp) {
            tempClob.freeTemporary();
            sqlexp.printStackTrace();
        } catch (Exception exp) {
            tempClob.freeTemporary();
            exp.printStackTrace();
        }
        return tempClob;
    }

    @Override
    public Document getNullableResult(ResultSet rs, String pName) throws SQLException {
        OracleResultSet oracleResultSet = (OracleResultSet) rs.unwrap(OracleResultSet.class);
        Reader clobReader = null;
        try {
            clobReader = oracleResultSet.getCLOB(pName).getCharacterStream();
            return ExtXMLElement.toDocument(clobReader);
        } finally {
            try {
                clobReader.close();
            } catch (Exception ex) {
                Logger.getLogger(XMLTypeHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Document getNullableResult(ResultSet rs, int indx) throws SQLException {
        OracleResultSet oracleResultSet = (OracleResultSet) rs.unwrap(OracleResultSet.class);
        OPAQUE opaqueValue = oracleResultSet.getOPAQUE(indx);
        if (opaqueValue != null) {
            XMLType xmlResult = XMLType.createXML(opaqueValue);
            return ExtXMLElement.toDocument(xmlResult.getDOM());
        } else {
            return (Document) null;
        }
    }

    @Override
    public Document getNullableResult(CallableStatement cs, int indx) throws SQLException {
        OracleCallableStatement oracleCallableStatement = (OracleCallableStatement) cs.unwrap(OracleCallableStatement.class);
        OPAQUE opaqueValue = oracleCallableStatement.getOPAQUE(indx);
        if (opaqueValue != null) {
            XMLType xmlResult = XMLType.createXML(opaqueValue);
            return ExtXMLElement.toDocument(xmlResult.getDOM());
        } else {
            return (Document) null;
        }
    }

}
