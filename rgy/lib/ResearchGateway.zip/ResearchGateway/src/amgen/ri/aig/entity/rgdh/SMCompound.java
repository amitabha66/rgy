/*
 *   SMCompound
 *   RDBData wrapper class for SMCOMPOUND
 *   $Revision: 1.2 $
 *   Created: Jeffrey McDowell, 30 Mar 2011
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.entity.rgdh;


import java.lang.reflect.Field;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.SQLManagerIF;

/**
 *   RDBData wrapper class for SMCOMPOUND
 *   @version $Revision: 1.2 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class SMCompound extends RdbData {
    protected int root_number;
    protected int compound_id;
    protected double molecular_weight;
    protected String molecular_formula;
    protected java.sql.Date registered_date;
    protected String is_view_restricted;
    protected String is_request_restricted;
    protected int num_hbond_acceptors;
    protected int num_hbond_donors;
    protected int num_rotatable_bonds;
    protected double polar_surface_area;
    protected double clogp;
    protected double clogd_2_0;
    protected double clogd_4_0;
    protected double clogd_6_5;
    protected double clogd_7_4;
    protected double clogd_10_0;
    protected String smiles;

    private int heavyAtomCount= -1;


    /**
     * Default Constructor
     */
    public SMCompound() {
        super();
    }

    /**
     * RdbData Constructor
     */
    public SMCompound(String root_number, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.root_number = Integer.parseInt(root_number);
    }

    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return root_number + "";
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }

    /** This method returns the name of the table. */
    protected String getTableName() {
        return "RGDH.SM_COMPOUND";
    }

    /** Get value for root_number */
    public int getRoot_number() {
        return getAsNumber("root_number", false).intValue();
    }

    /** Get value for compound_id */
    public int getCompound_id() {
        return getAsNumber("compound_id").intValue();
    }

    /** Get value for molecular_weight */
    public double getMolecular_weight() {
        return getAsNumber("molecular_weight").doubleValue();
    }

    /** Get value for molecular_formula */
    public String getMolecular_formula() {
        return (String) get("molecular_formula");
    }

    /** Get value for registered_date */
    public java.sql.Date getRegistered_date() {
        return (java.sql.Date) get("registered_date");
    }

    /** Get value for is_view_restricted */
    public String getIs_view_restricted() {
        return (String) get("is_view_restricted");
    }

    /** Get value for is_request_restricted */
    public String getIs_request_restricted() {
        return (String) get("is_request_restricted");
    }

    /** Get value for num_hbond_acceptors */
    public int getNum_hbond_acceptors() {
        return getAsNumber("num_hbond_acceptors").intValue();
    }

    /** Get value for num_hbond_donors */
    public int getNum_hbond_donors() {
        return getAsNumber("num_hbond_donors").intValue();
    }

    /** Get value for num_rotatable_bonds */
    public int getNum_rotatable_bonds() {
        return getAsNumber("num_rotatable_bonds").intValue();
    }

    /** Get value for polar_surface_area */
    public double getPolar_surface_area() {
        return getAsNumber("polar_surface_area").doubleValue();
    }

    /** Get value for clogp */
    public double getClogp() {
        return getAsNumber("clogp").doubleValue();
    }

    /** Get value for clogd_2_0 */
    public double getClogd_2_0() {
        return getAsNumber("clogd_2_0").doubleValue();
    }

    /** Get value for clogd_4_0 */
    public double getClogd_4_0() {
        return getAsNumber("clogd_4_0").doubleValue();
    }

    /** Get value for clogd_6_5 */
    public double getClogd_6_5() {
        return getAsNumber("clogd_6_5").doubleValue();
    }

    /** Get value for clogd_7_4 */
    public double getClogd_7_4() {
        return getAsNumber("clogd_7_4").doubleValue();
    }

    /** Get value for clogd_10_0 */
    public double getClogd_10_0() {
        return getAsNumber("clogd_10_0").doubleValue();
    }

    /** Get value for smiles */
    public String getSmiles() {
        return (String) get("smiles");
    }

    /**
     * Calculates the number of heavy (non-H) atoms in the formula of the form
     * "<element><count> <element><count>..."
     * Returns -1 if not possible
     *
     * @return int
     */
    public int getHeavyAtomCount() {
        if (heavyAtomCount < 0) {
            Pattern elementPattern = Pattern.compile("([A-Z]{1}[a-z]{0,1})([0-9]{0,})\\s{0,}");
            heavyAtomCount = 0;
            try {
                if (getMolecular_formula() == null) {
                    return -1;
                }
                Matcher elementMatcher = elementPattern.matcher(getMolecular_formula());
                while (elementMatcher.find()) {
                    if (elementMatcher.groupCount() == 2) {
                        String element = elementMatcher.group(1);
                        int count = (elementMatcher.group(2).length() == 0 ? 1 : Integer.valueOf(elementMatcher.group(2)));
                        if (!element.equals("H")) {
                            heavyAtomCount += count;
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        return heavyAtomCount;
    }


}
