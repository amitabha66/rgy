package amgen.ri.aig.favorites;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.cache.tree.NodeType;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.tree.TreeNode;
import amgen.ri.aig.cache.tree.TreeNodeCache;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.entitylist.EntityList;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.aig.items.ItemsManager;
import amgen.ri.aig.record.ItemRecord;
import amgen.ri.aig.sobj.ObjectType;
import amgen.ri.aig.sobj.SavedObject;
import amgen.ri.aig.sql.RGSQLProvider;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.aig.uddi.ServiceLookup;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.servlet.SessionLogin;
import amgen.ri.util.ExtString;
import java.io.IOException;
import java.util.*;
import org.jdom.Document;

/**
 * @version $Id: FavoriteManager.java,v 1.31 2014/07/08 15:51:49 jemcdowe Exp $ not
 * attributable
 */
public class FavoriteManager {
  private AIGBase requestor;
  private RGSQLProvider sqlProvider = new RGSQLProvider();

  public FavoriteManager(AIGBase requestor) {
    this.requestor = requestor;
  }

  /**
   * Create a favorite using the given type, name, description and keys. For
   * types other than project views, the object is looked up to determined the
   * category.
   *
   * @param favoriteTypeName String
   * @param name String
   * @param description String
   * @param favoriteKeys List
   * @param favoriteFolder FavoriteFolder
   * @return Favorite
   * @throws IOException
   * @throws AIGException
   */
  //type, name, description, itemKeys, parentFolderRecord, shareWith
  public Favorite createFavorite(ObjectType.Type type, String name, String description, List<String> favoriteKeys, JSONObject jServiceParams, ItemRecord favoriteFolder, List<String> shareWith)
          throws IOException, AIGException {
    EntityListCategory category = EntityListCategory.UNKNOWN;
    try {
      switch (type) {
        case LIST:
          EntityList entityList = new EntityList(favoriteKeys.get(0), new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
          if (entityList.setData()) {
            category = entityList.getEntityCategory();
          }
          break;
        case ENTITYTABLE:
          SavedObject savedObject = new SavedObject(favoriteKeys.get(0), new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
          if (savedObject.setData()) {
            EntityTable entityTable = (EntityTable) savedObject.getSavedObject();
            category = entityTable.getEntityCategory();
          }
          break;
        case PROJECTVIEW:
          category = EntityListCategory.PROJECTS;
          break;
        case SERVICE:
          if (favoriteKeys.size() == 1) {
            if (jServiceParams != null) {
              return saveServiceFavorite(name, description, favoriteKeys.get(0), jServiceParams, favoriteFolder);
            } else {
              return saveFavorite(name, description, favoriteKeys.get(0), favoriteFolder);
            }
          }
          return null;
        default:
          return null;
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    if (!category.equals(EntityListCategory.UNKNOWN)) {
      return saveFavorite(type, name, description, category, favoriteKeys, favoriteFolder);
    }
    return null;
  }

  /**
   * Create a favorite from a SavedObject
   *
   * @param savedObject SavedObject
   */
  public Favorite createFavorite(SavedObject savedObject, int favoriteFolderID) throws IOException, AIGException {
    ItemsManager itemsManager= new ItemsManager(requestor);
    ItemRecord folderItemRecord= itemsManager.getFolder(favoriteFolderID);
    
    return createFavorite(savedObject.getObject_type().getType(), savedObject.getName(), savedObject.getDescription(), savedObject.getCategory(), savedObject.getIdentifier(), folderItemRecord);
  }

  /**
   * createFavorite
   *
   * @param objectType ObjectType
   * @param string String
   * @param string1 String
   * @param string2 String
   * @return Favorite
   */
  private Favorite createFavorite(ObjectType.Type objectType, String name, String description, EntityListCategory category, String key,
          ItemRecord folderItemRecord) throws AIGException, IOException {
    return saveFavorite(objectType, name, description, category, (List<String>) Arrays.asList(new String[]{
              key
            }), folderItemRecord);
  }

  public Favorite updateFavorite(String favoriteID, String name, String description) {
    Favorite updateFavorite = new Favorite(favoriteID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
    if (!updateFavorite.setData()) {
      throw new IllegalArgumentException("Unable to load favorite");
    }
    if (ExtString.hasTrimmedLength(name)) {
      updateFavorite.setName(name);
    }
    if (ExtString.hasTrimmedLength(description)) {
      updateFavorite.setDescription(description);
    }
    if (updateFavorite.performCommit() == 0) {
      throw new IllegalArgumentException("Unable to update favorite");
    }
    return updateFavorite;
  }

  public Favorite getFavorite(String favoriteID) {
    Favorite favorite = new Favorite(favoriteID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
    if (!favorite.setData()) {
      throw new IllegalArgumentException("Unable to load favorite");
    }
    return favorite;
  }

  private Favorite saveFavorite(ObjectType.Type favoriteType, String name, String description, EntityListCategory category, List<String> favoriteKeys,
          ItemRecord folderItemRecord) throws IOException, AIGException {
    if (favoriteType.equals(ObjectType.SERVICE)) { // Should not
      // be an
      // option
      return null;
    }
    Favorite favorite = new Favorite(name, description, favoriteType, category, favoriteKeys, new OraSQLManager(), requestor.getSessionLogin().getRemoteUser(), JDBCNamesType.RG_JDBC + "");
    if (favorite.performCommitAll() == 0) {
      throw new IllegalArgumentException("Unable to save favorite");
    }
    saveFavoriteFolderItem(favorite, folderItemRecord);
    return favorite;
  }

  /**
   * Saves a TreeNodeList as an EntityList
   *
   * @throws IOException
   */
  private Favorite saveFavorite(String name, String description, String treeNodeUUID, ItemRecord favoriteFolderRecord) throws IOException, AIGException {
    TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(requestor.getHttpServletRequest());
    ServiceCache serviceCache = ServiceCache.getServiceCache(requestor.getHttpServletRequest());
    SessionLogin sessionLogin = requestor.getSessionLogin();
    EntityClassManager entityClassManager= requestor.getEntityClassManager();
    
    
    TreeNode saveNode = tnCache.getTreeNodeObj(treeNodeUUID);
    if (!saveNode.getNodeType().equals(NodeType.RESULTNODE) && !saveNode.getNodeType().equals(NodeType.SERVICENODE)) {
      throw new AIGException("Invalid node type. Only result or service nodes may be saved as favorites.", Reason.PARAMETER_ERROR);
    }
    ServiceDetails serviceDetails = null;
    if (serviceCache.getServiceResult(treeNodeUUID) != null) {
      serviceDetails = serviceCache.getServiceResult(treeNodeUUID).getServiceDetails();
    }
    if (serviceDetails == null) {
      throw new AIGException("Invalid service. Node does not contain a search.", Reason.PARAMETER_ERROR);
    }


    ServiceLookup serviceLookup = new ServiceLookup();
    Document serviceDocument = new Document(serviceDetails.getAsElement());
    serviceDocument.getRootElement().addContent(serviceLookup.getServiceDetailsParameterSet(serviceDetails));
    SavedObject sObj = new SavedObject(name, description, saveNode.getEntityListCategory(entityClassManager), sessionLogin.getRemoteUser(), new FavoriteWrapper(
            serviceDocument, ObjectType.SERVICE), new OraSQLManager(), sessionLogin.getRemoteUser(), JDBCNamesType.RG_JDBC + "");

    if (sObj.performCommit() == 0) {
      throw new AIGException("Unable to save service", Reason.UNABLE_TO_SET_SERVICE);
    }
    Favorite favorite = new Favorite(name, description, sObj.getCategory(), sObj.getObject_type(), sObj.getIdentifier(), new OraSQLManager(), sessionLogin.getRemoteUser(), JDBCNamesType.RG_JDBC + "");
    if (favorite.performCommitAll() == 0) {
      throw new AIGException("Unable to save favorite", Reason.UNABLE_TO_SET_SERVICE);
    }
    saveFavoriteFolderItem(favorite, favoriteFolderRecord);
    return favorite;
  }

  /**
   * Saves a TreeNodeList as an EntityList
   *
   * @throws IOException
   */
  private Favorite saveServiceFavorite(String name, String description, String serviceKey, JSONObject jServiceParams, ItemRecord favoriteFolderRecord) throws IOException, AIGException {
    ServiceCache serviceCache = ServiceCache.getServiceCache(requestor.getHttpServletRequest());
    SessionLogin sessionLogin = requestor.getSessionLogin();
    ServiceDetails serviceDetails = serviceCache.getService(serviceKey);

    if (serviceDetails == null) {
      throw new AIGException("Invalid service. Unable to find search service.", Reason.PARAMETER_ERROR);
    }
    try {
      serviceDetails.setParameterValues(jServiceParams);
    } catch (JSONException ex) {
      ex.printStackTrace();
    }

    ServiceLookup serviceLookup = new ServiceLookup();
    ServiceAttributes serviceAttributes = new ServiceAttributes(serviceDetails, requestor.getEntityClassManager());
    EntityListCategory serviceCategory = serviceAttributes.getFirstEntityListCategory();
    Document serviceDocument = new Document(serviceDetails.getAsElement());
    serviceDocument.getRootElement().addContent(serviceLookup.getServiceDetailsParameterSet(serviceDetails));

    SavedObject sObj = new SavedObject(name, description, serviceCategory, sessionLogin.getRemoteUser(), new FavoriteWrapper(
            serviceDocument, ObjectType.SERVICE), new OraSQLManager(), sessionLogin.getRemoteUser(), JDBCNamesType.RG_JDBC + "");

    if (sObj.performCommit() == 0) {
      throw new AIGException("Unable to save service", Reason.UNABLE_TO_SET_SERVICE);
    }
    Favorite favorite = new Favorite(name, description, sObj.getCategory(), sObj.getObject_type(), sObj.getIdentifier(), new OraSQLManager(), sessionLogin.getRemoteUser(), JDBCNamesType.RG_JDBC + "");
    if (favorite.performCommitAll() == 0) {
      throw new AIGException("Unable to save favorite", Reason.UNABLE_TO_SET_SERVICE);
    }
    saveFavoriteFolderItem(favorite, favoriteFolderRecord);
    return favorite;
  }

  private void saveFavoriteFolderItem(Favorite favorite, ItemRecord folderItemRecord) throws AIGException {
    FavoriteFolder favoriteFolder= FavoriteFolder.getRootFolder(JDBCNamesType.RG_JDBC + "");
    if (folderItemRecord.exists() && folderItemRecord.getItemType().equals(ItemRecord.ItemType.FOLDER)) {
      favoriteFolder= new FavoriteFolder(folderItemRecord.getRecordID(), favorite.getSQLManager(), favorite.getLogonUsername(), favorite.getConnectionPool());
    }
    if (favoriteFolder == null || !favoriteFolder.setData()) {
      favoriteFolder = FavoriteFolder.getRootFolder(JDBCNamesType.RG_JDBC + "");
    }
    if (favoriteFolder != null && favoriteFolder.setData()) {
      FavoriteFolderItem favoriteFolderItem = new FavoriteFolderItem(favorite, favoriteFolder, favorite.getSQLManager(), favorite.getLogonUsername(),
              favorite.getConnectionPool());
      if (favoriteFolderItem.performCommit() == 0) {
        throw new AIGException("Unable to save favorite item to folder", Reason.UNABLE_TO_SET_SERVICE);
      }
    }
  }

  /**
   * Returns the SharedFavorites for the current user. This includes direct
   * shares and those by reference to a group
   *
   * @return Set
   * @throws AIGException
   */
  public Set<ItemRecord> getSharesForUser() throws AIGException {   
    ItemsManager mgr= new ItemsManager(requestor);
    List<ItemRecord> records= mgr.getAllSharesItemRecords();    
    return new LinkedHashSet<ItemRecord>(records);
    /*
    for(ItemRecord r : records) {
      Debug.print(r.getName()+" "+r.getId());
    }
    
    
    Set<SharedFavorite> validShares = new LinkedHashSet<SharedFavorite>();
    try {
      List<SharedFavorite> shares = new RdbDataArray(SharedFavorite.class, new CompareTerm[]{
                new CompareTerm("SHARED_WITH", requestor.getSessionLogin().getRemoteUser()), new CompareTerm("IS_GROUP", "N")
              }, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");

      for (SharedFavorite share : shares) {
        if (share.getFavorite() != null && share.getFavorite().setData()) {
          validShares.add(share);
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    try {
      List<SharedFavorite> shares = new RdbDataArray(SharedFavorite.class, new CompareTerm[]{
                new CompareTerm("IS_GROUP", "Y")
              }, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
      Map<String, List<SharedFavorite>> sharedFavsByGroupAccountMap = new HashMap<String, List<SharedFavorite>>();
      for (SharedFavorite share : shares) {
        Favorite favorite= share.getFavorite();
        if (favorite != null && favorite.setData()) {
          if (!sharedFavsByGroupAccountMap.containsKey(share.getShared_with())) {
            sharedFavsByGroupAccountMap.put(share.getShared_with(), new ArrayList<SharedFavorite>());
          }
          sharedFavsByGroupAccountMap.get(share.getShared_with()).add(share);
        }
      }
      Map<String, Boolean> sharedFavsGroupIsMemberMap = new ActiveDirectoryLookup().isGroupMember(sharedFavsByGroupAccountMap.keySet(), personRecord);

      for (String groupAccountName : sharedFavsGroupIsMemberMap.keySet()) {
        if (sharedFavsGroupIsMemberMap.get(groupAccountName)) {
          List<SharedFavorite> sharedFavs = sharedFavsByGroupAccountMap.get(groupAccountName);
          for (SharedFavorite share : sharedFavs) {
            if (share.getFavorite() != null && share.getFavorite().setData()) {
              validShares.add(share);
            }
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return validShares;*/
  }

  /**
   * Returns the SharedFavorites for the current user. This includes direct
   * shares and those by reference to a group. Returned is a Map of Favorite ID
   * : SharedFavorites
   *
   * @return Set
   * @throws AIGException
   */
  public Map<Integer, ItemRecord> getSharedFavoritesForUserAsFavoriteIDMap() throws AIGException {
    Map<Integer, ItemRecord> sharedFavorites = new HashMap<Integer, ItemRecord>();    
    for(ItemRecord record: getSharesForUser()) {
      Number favID= record.getNumber("item_key_reference");
      if (favID!= null) {
        sharedFavorites.put(favID.intValue(), record);
      }
    }
    return sharedFavorites;
  }
}
