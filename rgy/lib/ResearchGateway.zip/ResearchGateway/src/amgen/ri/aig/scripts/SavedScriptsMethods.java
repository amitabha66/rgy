package amgen.ri.aig.scripts;

import java.util.List;

import org.jdom.Document;
import org.jdom.Element;

import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.CompareTerm;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.xml.ExtXMLElement;

/**
 *
 * DB based script source
 *
 * @version $Id: SavedScriptsMethods.java,v 1.4 2013/04/18 23:04:26 jemcdowe Exp $
 *
 */
public class SavedScriptsMethods extends AbstractScripts implements CalculationMethodsIF {
    private Document methodGroups;

    public SavedScriptsMethods(EntityListCategory entityType) {
        super(entityType, null);
        Element jsObjectsEl = new Element("JSObjects");
        methodGroups = new Document(jsObjectsEl);
        Element availableMethodsEl = ExtXMLElement.addElement(jsObjectsEl, "AvailableMethods");
        CompareTerm[] terms = new CompareTerm[] {
                              new CompareTerm("entity_type", entityType)
        };

        List<RGScript> rgScripts = new RdbDataArray(RGScript.class, terms, "group_name", true, new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
        for (RGScript rgScript : rgScripts) {
            String groupName = rgScript.getGroup_name();
            Element methodGroupEl = ExtXMLElement.getXPathElement(availableMethodsEl, "/JSObjects/AvailableMethods/MethodGroup[Name='" + groupName + "']");

            if (methodGroupEl == null) {
                methodGroupEl = ExtXMLElement.addElement(availableMethodsEl, "MethodGroup");
                methodGroupEl.setAttribute("entity_type", entityType.toString());
                ExtXMLElement.addTextElement(methodGroupEl, "Name", groupName);
                ExtXMLElement.addTextElement(methodGroupEl, "ClassName", rgScript.getJava_class_name());
            }
            Element methodEl = ExtXMLElement.addElement(methodGroupEl, "Method");
            ExtXMLElement.addTextElement(methodEl, "Name", rgScript.getMethod());
            ExtXMLElement.addTextElement(methodEl, "Label", rgScript.getLabel());
            ExtXMLElement.addTextElement(methodEl, "Description", rgScript.getDescription());
            ExtXMLElement.addTextElement(methodEl, "ParameterList", rgScript.getParameters());
            Element codeEl = ExtXMLElement.addTextElement(methodEl, "Code", rgScript.getCode());
            ExtXMLElement.addAttribute(codeEl, "src", rgScript.getSrc_url());
            ExtXMLElement.addTextElement(methodEl, "Help", rgScript.getHelp());
        }
    }

    public Document getMethodDocument() {
        return methodGroups;
    }


}
