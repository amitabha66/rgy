/*
 *   DHAssayInfo
 *   RDBData wrapper class for ABSTRACT_QUERY_ITEM
 *   $Revision: 1.1 $
 *   Created: Jeffrey McDowell, 18 Aug 2009
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.entity.rgdh;


import java.lang.reflect.Field;

import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.SQLManagerIF;

/**
 *   RDBData wrapper class for ABSTRACT_QUERY_ITEM
 *   @version $Revision: 1.1 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class DHAssayInfo extends RdbData {
    protected int rac_id;
    protected int parent;
    protected int assay_key;
    protected int assayrac;
    protected String assay_name;
    protected String assay_type;
    protected String description;
    protected String species;
    protected int assay_info_id;

    /**
     * Default Constructor
     */
    public DHAssayInfo() {
        super();
    }

    /**
     * RdbData Constructor
     */
    public DHAssayInfo(String assay_info_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.assay_info_id = Integer.parseInt(assay_info_id);
    }

    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return assay_info_id + "";
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }

    /** This method returns the name of the table. */
    protected String getTableName() {
        return "DH_ASSAY_INFO";
    }

    /**
     * Returns the primary key fields for the RdbData class which are used to
     * generate the SQL statement(s). If this returns null (the Default), the first field of the class is assumed.
     * The getIdentifier() method must return, in CSV, the matching number of elements as this array if generated SQL is used.
     */
    public String[] getPrimaryKeyFields() {
        return new String[] {"assay_info_id"};
    }

    /** Get value for rac_id */
    public int getRac_id() {
        return getAsNumber("rac_id").intValue();
    }

    /** Get value for parent */
    public int getParent() {
        return getAsNumber("parent").intValue();
    }

    /** Get value for assay_key */
    public int getAssay_key() {
        return getAsNumber("assay_key").intValue();
    }

    /** Get value for assayrac */
    public int getAssayrac() {
        return getAsNumber("assayrac").intValue();
    }

    /** Get value for assay_name */
    public String getAssay_name() {
        return (String) get("assay_name");
    }

    /** Get value for assay_type */
    public String getAssay_type() {
        return (String) get("assay_type");
    }

    /** Get value for description */
    public String getDescription() {
        return (String) get("description");
    }

    /** Get value for species */
    public String getSpecies() {
        return (String) get("species");
    }

    /** Get value for assay_info_id */
    public int getAssay_info_id() {
        return getAsNumber("assay_info_id", false).intValue();
    }

}
