package amgen.ri.aig.vqt;

import java.io.ObjectStreamException;

/**
 * Defines the types of Entities known to AIG
 */
public enum VQTRetrievableTypes {
  AIG_COMPOUND_LIST_MEMBERSHIP,
  MW,
  POLAR_SURFACE_AREA,
  TOTAL_SOLID_AVAILABLE,
  MAX_SOLID_IN_SINGLE_CONTAINER,
  TERMINATION_DATE,
  COMPANY,
  ROOT_NUMBER,
  SUBSTANCE_SALT,
  INVENTORY,
  ORIGIN,
  FIRST_NAME,
  LIQUID_INVENTORY_EXISTS,
  FUNCTION,
  POSITION,
  ORGANIZATION_UNIT,
  MOLECULE_ID,
  STRUCTURE,
  SUBSTANCE_ID,
  SUBSTANCE_DETAILS,
  ASSAY_CODE,
  ASSAY_DESCRIPTION,
  CHEMICAL,
  CLOGD_ACD,
  ASSAY_RESULT_DETAILS,
  HYDROGEN_BOND_DONORS,
  NOTEBOOK_REFERENCE,
  SUBSTANCE_COMMENTS,
  ADMINISTRATIVE,
  SUBSTANCE_STATUS,
  ASSAY_RESULT,
  ASSAY_RESULT_AGGREGATED,
  ASSAY_RESULT_INDIVIDUAL,
  SUBMITTER,
  COST_CENTER_VALUE,
  NUM_OF_LOTS,
  HYDROGEN_BOND_ACCEPTORS,
  ROTATABLE_BONDS,
  EMPLOYEE_GROUP,
  LOCATION,
  SUBSTANCE_COLOR,
  SUBSTANCE_TYPE,
  DATE_COMPOUND_REGISTERED,
  STAFF_ID,
  LOT_NUMBER,
  NAME,
  DESCRIPTION,
  PROJECTS,
  BIOLOGICAL,
  PROPERTIES,
  PHONE_NUMBER,
  PKA,
  MANAGEMENT_CENTER,
  EMPLOYEE_SUB_GROUP,
  ASSAY_NAME,
  LAST_NAME,
  FULL_NAME,
  PROJECT_PICKER_ISMEMBEROF,
  DATE_SUBSTANCE_REGISTERED,
  HIRE_DATE,
  EMPLOYMENT_STATUS,
  MODIFICATION_DATE,
  PERSON_ID,
  COMPOUND_ID,
  SUBSTANCE_SOURCE,
  TYPE,
  COMPOUND_RESTRICTIONS,
  ROOT_LOT,
  CLOGP_ACD,
  PHOTO,
  LOGIN,
  SUBSTANCE_STATE,
  ASSAY_SELECTIVITY,
  DOSE_RESPONSE_CURVE,
  EXPERIMENT_DOSE,
  LMR_EXPRESSION_SYSTEM_ID,
  EXPRESSION_SYSTEM_NAME,
  LMR_PROTEIN_LOT_ID,
  PROTEIN_NAME,
  LMR_HARVEST_ID,
  LMR_HARVEST_NAME,
  LMR_CONSTRUCT_ID,
  LMR_CONSTRUCT_NAME,
  LMR_SEQUENCE_SET_ID,
  LMR_SEQUENCE_SET_NAME,
  LMR_SEQUENCE_ID,
  LMR_SEQUENCE_NAME,
  OFFICIAL_SYMBOL,
  GENE_SPECIES,
  OFFICIAL_NAME,
  CRYSTAL_STRUCTURE,
  REQUEST_ID,
  REQUEST_TITLE,
  DATA_SET_ID,
  DATA_SET_NAME,
  LARGE_MOLECULE_LOT_ID,
  LARGE_MOLECULE_ID,
  UNKNOWN;
  static final long serialVersionUID = 8202349470837544008L;

  public static VQTRetrievableTypes fromString(String s) {
    if (s == null) {
      return UNKNOWN;
    }
    try {
      s = s.toUpperCase().trim();
      if (s.equals("ROOT #")) {
        return ROOT_NUMBER;
      }
      if (s.equals("CLOGD (ACD)")) {
        return CLOGD_ACD;
      }
      if (s.equals("# OF LOTS")) {
        return NUM_OF_LOTS;
      }
      if (s.equals("ROOT#LOT")) {
        return ROOT_LOT;
      }
      if (s.equals("CLOGP (ACD)")) {
        return CLOGP_ACD;
      }
      if (s.equals("ASSAY RESULT (AGGREGATED)")) {
        return ASSAY_RESULT_AGGREGATED;
      }
      if (s.equals("ASSAY RESULT (INDIVIDUAL)")) {
        return ASSAY_RESULT_INDIVIDUAL;
      }
      if (s.startsWith("EXPERIMENT_DOSE")) {
        return EXPERIMENT_DOSE;
      }
      if (s.replace(' ', '_').equals("HARVEST_ID")) {
        return LMR_HARVEST_ID;
      }
      if (s.replace(' ', '_').equals("CONSTRUCT_NAME")) {
        return LMR_CONSTRUCT_NAME;
      }
      if (s.replace(' ', '_').equals("CONSTRUCT_ID")) {
        return LMR_CONSTRUCT_ID;
      }
      if (s.replace(' ', '_').equals("SEQUENCE_NAME")) {
        return LMR_SEQUENCE_NAME;
      }
      if (s.replace(' ', '_').equals("SEQUENCE_ID")) {
        return LMR_SEQUENCE_ID;
      }
      if (s.replace(' ', '_').equals("SEQUENCE_SET_NAME")) {
        return LMR_SEQUENCE_SET_NAME;
      }
      if (s.replace(' ', '_').equals("SEQUENCE_SET_ID")) {
        return LMR_SEQUENCE_SET_ID;
      }
      return VQTRetrievableTypes.valueOf(s.replace(' ', '_'));
    } catch (Exception e) {
      return UNKNOWN;
    }
  }

  /**
   * This is necessary to permit Serializable. A Serialized object containing an
   * enum class variable is not de-Serialized properly. This forces
   * de-Serialized enum to be re-created as this enum through the String
   *
   * @return Object
   * @throws ObjectStreamException
   */
  public Object readResolve() throws ObjectStreamException {
    return VQTRetrievableTypes.fromString(this.toString());
  }
}
