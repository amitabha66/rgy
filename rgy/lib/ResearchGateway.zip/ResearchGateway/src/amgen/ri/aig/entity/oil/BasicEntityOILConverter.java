/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.entity.oil;

/**
 *
 * @author jemcdowe
 */
public class BasicEntityOILConverter extends AbstractEntityOILConverter implements EntityOILConverterIF {
  public BasicEntityOILConverter() {
    super();
  }
}
