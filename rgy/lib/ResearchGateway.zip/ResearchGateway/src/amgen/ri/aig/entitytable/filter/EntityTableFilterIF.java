package amgen.ri.aig.entitytable.filter;

import amgen.ri.aig.entitytable.DataCell;

/**
 * Creates an interface to implement filters in the EntityTable
 *
 * @version $Id: EntityTableFilterIF.java,v 1.1 2011/06/17 20:41:26 cvs Exp $
 */
public interface EntityTableFilterIF {
    public boolean match(DataCell dataCell);

}
