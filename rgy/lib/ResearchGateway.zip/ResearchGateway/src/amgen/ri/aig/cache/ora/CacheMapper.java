/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.ora;

import java.util.List;

/**
 *
 * @author jemcdowe
 */
public interface CacheMapper {

  void clearAllGlobalCache(CacheAdminDao cacheAdminDao);

  void clearGlobalCache(String cacheType);

  void getCacheItem(CacheItemDAO cacheItem);

  void getCacheItems(CacheItemDAO cacheItem);

  void getAllCacheItems(CacheItemDAO cacheItem);

  void getSortedServiceCacheItems(CacheItemDAO cacheItem);

  void putCacheItem(CacheItemDAO cacheItem);

  void getOfflineServiceKeys(CacheItemDAO cacheItem);

  void getQueryKeys(CacheItemDAO cacheItem);

  void removeCacheItem(CacheItemDAO cacheItem);

  void containsCacheItem(CacheItemDAO cacheItem);

  void insertCacheLog(CacheLogDAO cacheLog);

  List<CacheCountsDAO> getCacheCounts();

  CacheStatus getCacheStatus();

}
