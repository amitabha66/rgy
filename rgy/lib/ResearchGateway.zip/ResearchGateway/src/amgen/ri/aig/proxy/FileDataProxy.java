package amgen.ri.aig.proxy;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jdom.Document;

import amgen.ri.aig.AIGServlet;
import amgen.ri.util.ExtFile;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;

/**
 * A DataProxy subclass used for static files. Ensures the request is get and no
 * parameters are written to the connection avoiding IIS 405 error problems
 *
 * @author jemcdowe
 *
 */
public class FileDataProxy extends DataProxy {

  public FileDataProxy() {
    super();
  }

  public FileDataProxy(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  /**
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return TBXServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new FileDataProxy(req, resp);
  }

  /**
   *
   * @return String
   */
  protected String getServletMimeType() {
    return "text/xml";
  }

  /**
   * Handles the servlet request
   *
   * @throws Exception
   */
  protected void performRequest() throws Exception {
    if (!doesParameterExist("src", true)) {
      return;
    }
    URL srcURL = new URL(getParameter("src"));
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    writeResponse(srcURL, null, out);
    out.close();

    if (doesParameterExist("contentType")) {
      response.setContentType(getParameter("contentType"));
    } else {
      Document doc = ExtXMLElement.toDocument(new ByteArrayInputStream(out.toByteArray()));
      if (doc != null) {
        response.setContentType("text/xml");
      } else {
        response.setContentType("application/octet-stream");
      }
    }
    ExtFile.copy(new ByteArrayInputStream(out.toByteArray()), response.getOutputStream());
  }

}
