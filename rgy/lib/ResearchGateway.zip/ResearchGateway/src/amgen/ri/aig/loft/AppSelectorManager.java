/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.loft;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.record.AppRecord;
import amgen.ri.aig.uddi.QueryServiceLookup;
import amgen.ri.aig.uddi.WidgetServiceLookup;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.CompareTerm;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;

/**
 *
 * @author jemcdowe
 */
public class AppSelectorManager extends AbstractLoftManager {
  private AIGServlet requestor;
  private String nodeID;
  private Map<AppType, List<AppRecord>> userCurrentAppsTypeMap;

  public AppSelectorManager(AIGServlet requestor) throws AIGException {
    super(requestor.getSessionLogin());
    this.requestor = requestor;
    nodeID = requestor.getParameter("node", "root");
  }

  public JSONObject getResponse() {
    try {
      //getUserCurrentAppsTypeMap();
      AppType appType = AppType.fromString(nodeID);
      switch (appType) {
        case UNKNOWN:
          return getSelectorRootNodes();
        case TOOLS:
        case EXPLORE_TOOL:
        case WIDGETS:
          return getAppsForSelectorNode(appType);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return new JSONObject();
  }

  private Map<AppType, List<AppRecord>> getUserCurrentAppsTypeMap() throws AIGException {
    if (userCurrentAppsTypeMap == null) {
      userCurrentAppsTypeMap = new EnumMap<AppType, List<AppRecord>>(AppType.class);
      try {
        for (AppRecord app : getUserAppRecords()) {
          AppType appType = app.getType();
          if (!userCurrentAppsTypeMap.containsKey(appType)) {
            userCurrentAppsTypeMap.put(appType, new ArrayList<AppRecord>());
          }
          userCurrentAppsTypeMap.get(appType).add(app);

        }
      } catch (Exception ex) {
        Logger.getLogger(AppSelectorManager.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
    return userCurrentAppsTypeMap;
  }

  private JSONObject findAppInUsersCurrentApps(JSONObject jApp) throws JSONException, AIGException {
    AppAttributeType attributeType = null;
    Map<AppType, List<AppRecord>> currentAppsTypeMap = getUserCurrentAppsTypeMap();
    if (currentAppsTypeMap == null) {
      return null;
    }
    AppType appType = AppType.fromString(jApp.getString("type"));
    List<AppRecord> currentAppsForType = currentAppsTypeMap.get(appType);
    if (!ExtArray.hasLength(currentAppsForType)) {
      return null;
    }
    switch (appType) {
      //Don't know what this is!!
      default:
        return null;

      //First set of App Types can only have 1 on the Launch Pad
      //So just check that there is something in the currentAppsForType
      case FAVORITES_TOOL:
      case PREFERENCES_TOOL:
      case DOCUMENTS_TOOL:
      case EXPLORE_TOOL:
      case VQT_TOOL:
      case LISTS_TOOL:
      case PROJECT_VIEW_TOOL:
      case TABLE_IMPORT_TOOL:
      case STRUCTURE_SEARCH_TOOL:
        return (!currentAppsTypeMap.containsKey(appType) || currentAppsForType.isEmpty() ? null : currentAppsForType.get(0));
      //Second set of App Types can have multiple on the Launch Pad
      //With keys/IDs set by attribute, so set the attributeName and check by 
      //attribute value following the  switch
      case FAVORITE:
        attributeType = AppAttributeType.FAVORITEFOLDERITEM_ID;
        break;
      case SERVICE:
        attributeType = AppAttributeType.SERVICE_KEY;
        break;
    }
    //If the AppType is tested by equivalence of an attribute value, check by the set attributeName
    if (attributeType != null) {
      String attributeValue = getAttribute(jApp, attributeType);
      if (ExtString.hasLength(attributeValue)) {
        for (JSONObject jCurrentApp : currentAppsForType) {
          if (ExtString.equalsIgnoreCase(getAttribute(jCurrentApp, attributeType), attributeValue)) {
            return jCurrentApp;
          }
        }
      }
    }
    return null;
  }

  private JSONObject getSelectorRootNodes() throws JSONException {
    AppType[] rootNodes = {
      AppType.TOOLS,
      AppType.EXPLORE_TOOL,
      AppType.WIDGETS,
      //AppType.DOCUMENTS_TOOL,
      //AppType.LISTS_TOOL,
      //AppType.PROJECT_VIEW_TOOL,
      //AppType.VQT_TOOL
    };

    JSONObject jNodes = new JSONObject();
    for (AppType rootNode : rootNodes) {
      String text = rootNode.getAppSelectorName();
      if (ExtString.hasLength(text)) {
        JSONObject jNode = new JSONObject();
        jNodes.append("nodes", jNode);
        jNode.put("id", rootNode + "");
        jNode.put("text", text);
        jNode.put("iconCls", rootNode.getImageCSS());

        switch (rootNode) {
          case TOOLS:
            jNode.put("disabled", false);
            jNode.put("leaf", true);
            jNode.put("grouped", false);
            break;
          case WIDGETS:
            jNode.put("disabled", false);
            jNode.put("leaf", true);
            jNode.put("grouped", true);
            break;
          case EXPLORE_TOOL:
            jNode.put("disabled", false);
            jNode.put("leaf", true);
            jNode.put("grouped", true);
            break;
          case DOCUMENTS_TOOL:
            jNode.put("disabled", true);
            jNode.put("leaf", true);
            jNode.put("grouped", false);
            break;
          case LISTS_TOOL:
            jNode.put("disabled", true);
            jNode.put("leaf", true);
            jNode.put("grouped", true);
            break;
          case PROJECT_VIEW_TOOL:
            jNode.put("disabled", true);
            jNode.put("leaf", true);
            jNode.put("grouped", false);
            break;
          case VQT_TOOL:
            jNode.put("disabled", true);
            jNode.put("leaf", true);
            jNode.put("grouped", false);
            break;

          case FAVORITES_TOOL:
          case PREFERENCES_TOOL:
          case TABLE_IMPORT_TOOL:
          case STRUCTURE_SEARCH_TOOL:
          case FAVORITE:
          case SERVICE:
          default:
            jNode.put("disabled", true);
            jNode.put("leaf", true);
            jNode.put("grouped", false);
            break;
        }
      }
    }
    return jNodes;
  }

  private JSONObject getAppsForSelectorNode(AppType appType) throws JSONException, JDOMException, AIGException {
    JSONObject jApps = new JSONObject();
    switch (appType) {
      case TOOLS:
        List<RGAppType> coreAppTypes = new RdbDataArray(RGAppType.class,
                new CompareTerm("IS_BASIC_TOOL", "1"),
                new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
       for (int i = 0; i < coreAppTypes.size(); i++) {
          RGAppType coreAppType = coreAppTypes.get(i);

          JSONObject jApp = new JSONObject();
          jApp.put("id", -1 * i);
          jApp.put("name", coreAppType.getName());
          jApp.put("type", coreAppType.getAppType().toString());
          jApp.put("description", coreAppType.getDescription());
          jApp.putOpt("className", coreAppType.getCSSClass());

          JSONObject currentApp = findAppInUsersCurrentApps(jApp);

          jApp.put("onLaunchPad", (currentApp != null));
          if (currentApp != null) {
            jApp.put("id", currentApp.getString("id"));
          }
          jApps.append("apps", jApp);
        }

        break;
      case EXPLORE_TOOL:
        try {
          QueryServiceLookup queryServiceLookup = new QueryServiceLookup(requestor);
          Document servicesDoc = queryServiceLookup.getServicesDocument();

          List<Element> serviceEls = ExtXMLElement.getXPathElements(servicesDoc, "//Service");
          for (Element serviceEl : serviceEls) {
            JSONObject jApp = new JSONObject();
            jApps.append("apps", jApp);
            jApp.put("id", jApps.getJSONArray("apps").length());
            jApp.put("name", serviceEl.getChildText("Name"));
            jApp.put("description", serviceEl.getChildText("Description"));
            jApp.put("type", AppType.SERVICE.toString());
            jApp.putOpt("className", serviceEl.getChildText("IconCls"));
            jApp.putOpt("category", serviceEl.getChildText("CategoryTag"));
            jApp.putOpt("entityCategory", serviceEl.getChildText("EntityCategory"));
            JSONObject jAttributeParam = new JSONObject();
            jApp.append("attributes", jAttributeParam);
            jAttributeParam.putOpt("SERVICE_KEY", serviceEl.getChildText("ServiceKey"));

            JSONObject currentApp = findAppInUsersCurrentApps(jApp);

            jApp.put("onLaunchPad", (currentApp != null));
            if (currentApp != null) {
              jApp.put("id", currentApp.getString("id"));
            }
          }
        } finally {
        }
        break;
      case WIDGETS:
        try {
          WidgetServiceLookup queryServiceLookup = new WidgetServiceLookup(requestor);
          Document servicesDoc = queryServiceLookup.getServicesDocument();
          List<Element> serviceEls = ExtXMLElement.getXPathElements(servicesDoc, "//Service");
          for (Element serviceEl : serviceEls) {
            JSONObject jApp = new JSONObject();
            jApps.append("apps", jApp);
            jApp.put("id", jApps.getJSONArray("apps").length());
            jApp.put("name", serviceEl.getChildText("Name"));
            jApp.put("description", serviceEl.getChildText("Description"));
            jApp.put("type", AppType.SERVICE.toString());
            jApp.putOpt("className", serviceEl.getChildText("IconCls"));
            JSONObject jAttributeParam = new JSONObject();
            jApp.append("attributes", jAttributeParam);
            jAttributeParam.putOpt("SERVICE_KEY", serviceEl.getChildText("ServiceKey"));

            JSONObject currentApp = findAppInUsersCurrentApps(jApp);

            jApp.put("onLaunchPad", (currentApp != null));
            if (currentApp != null) {
              jApp.put("id", currentApp.getString("id"));
            }
          }
        } finally {
        }
        break;
    }
    return jApps;
  }
}
