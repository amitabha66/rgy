package amgen.ri.aig.constants;

import java.io.ObjectStreamException;

/**
 * <p>@version $Id: OperatorType.java,v 1.1 2011/06/17 20:41:24 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public enum OperatorType {
    GREATER, GREATEROREQUAL, LESS, LESSOREQUAL, EQUALS, EXISTS, DOESNOTEXIST, UNKNOWN;

    public static OperatorType fromString(String s) {
        if (s == null) {
            return UNKNOWN;
        }
        s = s.toUpperCase().replaceAll("[^a-zA-Z]+", "");
        if (s.contains("greaterthanorequal")) {
            return GREATER;
        }
        if (s.contains("lessthanorequal")) {
            return LESS;
        }
        if (s.contains("greaterthan")) {
            return GREATER;
        }
        if (s.contains("lessthan")) {
            return LESS;
        }
        if (s.contains("exists")) {
            return EXISTS;
        }
        if (s.contains("equals")) {
            return EQUALS;
        }
        return UNKNOWN;
    }


    /**
     * This is necessary to permit Serializable.
     * A Serialized object containing an enum class variable is not de-Serialized properly.
     * This forces de-Serialized enum to be re-created as this enum through the String
     * @return Object
     * @throws ObjectStreamException
     */
    public Object readResolve() throws ObjectStreamException {
        return OperatorType.valueOf(this.toString());
    }


}
