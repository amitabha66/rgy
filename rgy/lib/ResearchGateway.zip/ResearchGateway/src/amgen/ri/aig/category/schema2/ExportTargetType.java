package amgen.ri.aig.category.schema2;

/**
 * DefinEs the type of export
 *
 * @version $Id: ExportTargetType.java,v 1.3 2012/07/07 00:08:52 cvs Exp $
 */
public enum ExportTargetType {
    EXCEL, SPOTFIRE, SDFILE, SERVICE, UNKNOWN;

    public static ExportTargetType fromString(String s) {
        try {
            return ExportTargetType.valueOf(s.toUpperCase());
        } catch (Exception e) {
            return UNKNOWN;
        }
    }

}
