package amgen.ri.aig;

import java.io.ObjectStreamException;


/**
 * Defines an AIG Exception whcih includes a reason for the exception.
 */
public class AIGException extends Exception {
    private Reason reason;

    public enum Reason {
        UNKNOWN,
                CACHE_ERROR,
                NOT_ALL_PARAMS_SET,
                UNABLE_TO_RETRIEVE_ENTRY,
                UNABLE_TO_SET_SERVICE,
                UNABLE_TO_RUN_SERVICE,
                NO_RESULTS,
                REQUEST_ERROR,
                PARAMETER_ERROR,
                DATABASE_ERROR,
                NO_SESSION_USER,
                NOT_IMPLEMENTED,
                UNKNOWN_ENTITY_TYPE,
                ENTITY_MISMATCH,
                TIMEOUT,
                INVALID_REQUEST,
                INSUFFICIENT_PRIVLEDGE,
                SERVICE_OFFLINE;
        /**
         * This is necessary to permit Serializable.
         * A Serialized object containing an enum class variable is not de-Serialized properly.
         * This forces de-Serialized enum to be re-created as this enum through the String
         * @return Object
         * @throws ObjectStreamException
         */
        public Object readResolve() throws ObjectStreamException {
            return Reason.valueOf(this.toString());
        }
    }


    public AIGException(String message, Reason reason) {
        this(message, reason, null);
    }

    public AIGException(Reason reason, Throwable cause) {
        this("NA", reason, null);
    }

    public AIGException(String message, Reason reason, Throwable cause) {
        super(message, cause);
        this.reason = reason;
    }

    public Reason getReason() {
        return reason;
    }

}
