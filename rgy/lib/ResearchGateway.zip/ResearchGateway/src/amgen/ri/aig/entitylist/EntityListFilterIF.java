/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.entitylist;

/**
 *
 * @author jemcdowe
 */
public interface EntityListFilterIF {
    public boolean match(EntityListMemberIF member);
  
}
