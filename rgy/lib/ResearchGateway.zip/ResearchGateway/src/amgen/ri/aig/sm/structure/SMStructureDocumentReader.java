/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.sm.structure;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.entitytable.DataRow;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtArray;
import java.io.*;
import java.sql.Connection;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.GZIPInputStream;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;
import oracle.sql.CLOB;
import org.apache.commons.io.IOUtils;
import org.jdom.Document;

/**
 *
 * @author jemcdowe
 */
public class SMStructureDocumentReader {
  public String structureExportSQL = "{? = call RG_SMSC.RG.RG_ACRF_STRUCTURE_EXP_BYLOGIN(?, ?)}";
  private AIGBase requestor;

  public SMStructureDocumentReader(AIGBase requestor) {
    this.requestor = requestor;
  }

  /**
   * Returns a Structure Document using the provided DataRows
   *
   * @param cacheCompoundIDs List
   */
  public Document getStructureDocumentFromDataRows(EntityTable entityTable) throws IOException {
    Set<String> ids = new HashSet<String>();
    for (DataRow row : entityTable.getDataRows()) {
      ids.add(row.getEntityID());
    }
    return getStructureDocument(ids);
  }


  /**
   * Returns a Structure Document using the provided IDs
   *
   */
  public Document getStructureDocument(Collection<String> ids) throws IOException {   
    Document structureDoc = null;
    try {
      StringBuilder idBuffer = new StringBuilder();
      for (String id : new HashSet<String>(ids)) {
        if (idBuffer.length() > 0) {
          idBuffer.append(",");
        }
        idBuffer.append(id);
      }     
      InputStream is = new GZIPInputStream(new ByteArrayInputStream(getSerializedStructureDocument(ids)));
      ObjectInputStream oip = new ObjectInputStream(is);
      structureDoc = (Document) oip.readObject();
      is.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
    return structureDoc;
  }

  /**
   * Returns a Structure Document using the provided DataRows
   *
   * @param cacheCompoundIDs List
   */
  public byte[] getSerializedStructureDocumentFromEntityTable(EntityTable entityTable) throws IOException {
    Set<String> ids = new HashSet<String>();
    for (DataRow row : entityTable.getDataRows()) {
      ids.add(row.getEntityID());
    }   
    return getSerializedStructureDocument(ids);
  }


  /**
   * Returns a Structure Document using the provided IDs
   *
   */
  public byte[] getSerializedStructureDocument(Collection<String> ids) throws IOException {
    byte[] bytes = new byte[0];
    Connection conn = null;
    try {
      StringBuilder idBuffer = new StringBuilder();
      for (String id : new HashSet<String>(ids)) {
        if (idBuffer.length() > 0) {
          idBuffer.append(",");
        }
        idBuffer.append(id);
      }
      conn = new OraSQLManager().getConnection(JDBCNamesType.RGSMSCL_JDBC + "");
      CLOB idClob = CLOB.createTemporary(conn, true, CLOB.DURATION_SESSION);
      Writer writer = idClob.setCharacterStream(0);
      writer.write(idBuffer.toString());
      writer.close();

      OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(structureExportSQL);
      cs.registerOutParameter(1, OracleTypes.BLOB);
      cs.setClob(2, idClob);
      cs.setString(3, requestor.getSessionLogin().getRemoteUser());
      cs.execute();      
      bytes = IOUtils.toByteArray(cs.getBlob(1).getBinaryStream());
      cs.close();
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return bytes;
  }
}
