package amgen.ri.aig.sobj;


/**
 * Interface for defining Saveable object types.
 * @version $Id: SaveableIF.java,v 1.2 2011/06/21 17:28:58 cvs Exp $
 */
public interface SaveableIF {
    /**
     * Returns the ObjectType of the Saveable object
     *
     * @return int
     */
    public int getObjectType();

    /**
     * Returns the Saveable object as a byte array
     *
     * @return byte[]
     */
    public byte[] getObjectBytes() throws SaveObjectException;

}
