/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.entity.oil;

import amgen.ri.aig.entity.EntityClass;
import amgen.ri.aig.entitytable.DataRow;
import amgen.ri.util.ExtArray;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.LinkedListMultimap;
import java.io.IOException;
import java.io.Reader;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

/**
 *
 * @author jemcdowe
 */
public abstract class AbstractEntityOILConverter implements EntityOILConverterIF {

  public AbstractEntityOILConverter() {
  }

  /**
   * Creates a Map of
   * LUID : UIR
   * DRUID : UIR
   * Pref. Name : UIR
   * The provided IDs can be DRUIDs or preferred names. It is assumed that the
   * DRUID
   * format is
   * (i|r|s)::code:id
   * where the class character and the code are provided by the
   * EntityOILDetails.
   * Any other value is assumed to by a LUID
   *
   * @param entityClass
   * @param uids
   * @return
   */
  public Map<String, UIR> convert(EntityClass entityClass, List<String> uids) {
    SqlSession sqlSession = null;
    Map<String, UIR> uirMap = new HashMap<String, UIR>();
    if (uids.isEmpty()) {
      return uirMap;
    }
    try {
      sqlSession = getRGDHSqlSession();
      boolean isDruids = entityClass.isDruid(uids.get(0));
      int queryCount = ExtArray.getPages(uids, 1000);

      for (int i = 0; i < queryCount; i++) {
        Set<UIR> uirs = new HashSet<UIR>();

        if (isDruids) {
          uirs.addAll(sqlSession.getMapper(OILMapper.class).getUIRByDruid(ExtArray.getPage(uids, i, 1000), entityClass.getOilCode()));
        } else {
          //uirs.addAll(sqlSession.getMapper(OILMapper.class).getUIRByLuid(ExtArray.getPage(uids, i, 1000), entityClass.getOilCode()));
          uirs.addAll(sqlSession.getMapper(OILMapper.class).getUIRByPreferredName(ExtArray.getPage(uids, i, 1000), entityClass.getOilCode()));
        }
        for (UIR uir : uirs) {
          uirMap.put(uir.getUir_druid(), uir);
          uirMap.put(uir.getUir_luid(), uir);
          uirMap.put(uir.getPreferred_name(), uir);
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      sqlSession.close();
    }
    return uirMap;
  }

  /**
   * Creates a Map of
   * LUID : DataRow
   * DRUID : DataRow
   * Pref. Name : DataRow
   *
   * @param entityClass
   * @param dataRows
   * @return
   */
  public LinkedListMultimap<String, DataRow> generateUIRDataRowMap(EntityClass entityClass, List<DataRow> dataRows) {
    LinkedListMultimap<String, DataRow> map = LinkedListMultimap.create();

    List<String> uids = new ArrayList<String>();
    for (DataRow dataRow : dataRows) {
      uids.add(dataRow.getEntityID());
    }
    Map<String, UIR> uirMap = convert(entityClass, uids);

    for (DataRow dataRow : dataRows) {
      UIR uir = uirMap.get(dataRow.getEntityID());
      if (uir != null) {
        map.put(uir.getUir_druid(), dataRow);
        map.put(uir.getUir_luid(), dataRow);
        map.put(uir.getPreferred_name(), dataRow);
      }
    }
    return map;
  }

  /**
   * Function to create connection with database and to read the xml files used
   * for mapping.
   */
  public SqlSessionFactory getSqlSessionFactory(String factoryID) {
    SqlSessionFactory sqlSessionFactory = null;
    try {
      String resource = "rg.mybatis.config.xml";
      Reader reader = Resources.getResourceAsReader(resource);
      sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader, factoryID);
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
    return sqlSessionFactory;
  }

  public SqlSession getRGDHSqlSession() {
    return getRGDHSqlSession(ExecutorType.SIMPLE);
  }

  public SqlSession getRGDHSqlSession(ExecutorType executorType) {
    return getSqlSessionFactory("rgdh").openSession(executorType);
  }

}
