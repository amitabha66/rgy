package amgen.ri.aig.viz;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author jemcdowe
 */
public class VisualizationResults implements Serializable {
  private int visualizationID;
  private int queryRunID;
  private int queryItemID;

  private String visualizationName;

  private boolean byEntity;

  private String spotfireWebPlayerURL;
  private String spotfireDXPURL;
  private Map<String, String> urlParameters;

  public VisualizationResults(int visualizationID, int queryRunID, int queryItemID, String visualizationName, boolean byEntity, String spotfireWebPlayerURL, String spotfireDXPURL) {
    this(visualizationID, queryRunID, queryItemID, visualizationName, byEntity, spotfireWebPlayerURL, spotfireDXPURL, null);
  }

  public VisualizationResults(int visualizationID, int queryRunID, int queryItemID, String visualizationName, boolean byEntity, String spotfireWebPlayerURL, String spotfireDXPURL, Map<String, String> urlParameters) {
    this.visualizationID = visualizationID;
    this.queryRunID = queryRunID;
    this.queryItemID = queryItemID;
    this.byEntity = byEntity;
    this.visualizationName = visualizationName;
    this.spotfireWebPlayerURL = spotfireWebPlayerURL;
    this.spotfireDXPURL= spotfireDXPURL;
    this.urlParameters = new HashMap<String, String>();
    if (urlParameters != null) {
      this.urlParameters.putAll(urlParameters);
    }
  }

  /**
   * Get the value of queryRunID
   *
   * @return the value of queryRunID
   */
  public int getQueryRunID() {
    return queryRunID;
  }

  /**
   * Get the value of queryItemID
   *
   * @return the value of queryItemID
   */
  public int getQueryItemID() {
    return queryItemID;
  }

  /**
   * Get the value of byEntity
   *
   * @return the value of byEntity
   */
  public boolean isByEntity() {
    return byEntity;
  }

  /**
   * Get the value of spotfireWebPlayerURL
   *
   * @return the value of spotfireWebPlayerURL
   */
  public String getSpotfireWebPlayerURL() {
    return spotfireWebPlayerURL;
  }

  /**
   * Set the value of spotfireWebPlayerURL
   *
   * @param spotfireURL new value of spotfireWebPlayerURL
   */
  public void setSpotfireWebPlayerURL(String spotfireURL) {
    this.spotfireWebPlayerURL = spotfireURL;
  }

  /**
   * @return the urlParameters
   */
  public Map<String, String> getUrlParameters() {
    return urlParameters;
  }

  /**
   * @param urlParameters the urlParameters to set
   */
  public void addUrlParameters(String name, String value) {
    this.urlParameters.put(name, value);
  }

  /**
   * @return the visualizationID
   */
  public int getVisualizationID() {
    return visualizationID;
  }

  /**
   * @return the visualizationName
   */
  public String getVisualizationName() {
    return visualizationName;
  }

  /**
   * @return the spotfireDXPURL
   */
  public String getSpotfireDXPURL() {
    return spotfireDXPURL;
  }

  /**
   * @param spotfireDXPURL the spotfireDXPURL to set
   */
  public void setSpotfireDXPURL(String spotfireDXPURL) {
    this.spotfireDXPURL = spotfireDXPURL;
  }

}
