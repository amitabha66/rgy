package amgen.ri.aig.cache.item;

import java.io.IOException;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.rpc.ServiceException;
import javax.xml.transform.TransformerException;

import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.asf.sa.uddi.BindingDetails;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.ServiceParameter;
import amgen.ri.asf.sa.uddi.TModelDetails;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.util.Set;

/**
 *
 * @version $id$
 */
public class ServiceResultCacheItem extends AbstractCacheItem {
  static final long serialVersionUID = -6346333498420574173L;
  private ServiceDetails serviceDetails;
  private String resultFormatName;

  public ServiceResultCacheItem() {
    this(null);
  }

  public ServiceResultCacheItem(String resultKey) {
    super(resultKey);
  }

  public void setResults(Document resultDocument) {
    setCacheObject(resultDocument);
    setCacheString(new XMLOutputter().outputString(resultDocument));
  }

  public void setServiceDetails(ServiceDetails serviceDetails) {
    this.serviceDetails = serviceDetails;
  }

  public void setResultFormatName(String resultFormatName) {
    this.resultFormatName = resultFormatName;
  }

  public boolean isResultFormatName(String resultFormatName) {
    return (this.resultFormatName != null && resultFormatName != null && this.resultFormatName.equals(resultFormatName));
  }

  public ServiceDetails getServiceDetails() {
    return serviceDetails;
  }

  public String getResultFormatName() {
    return resultFormatName;
  }

  public String getResultKey() {
    return getKey();
  }

  public Document getResultAsDocument() {
    if (getCacheString() == null) {
      return null;
    }
    if (getCacheObject() == null) {
      try {
        setCacheObject(new SAXBuilder().build(new StringReader(getCacheString())));
      } catch (Exception e) {
      }
    }
    return (Document) getCacheObject();
  }

  /**
   * Transforms the result into the format specified by the binding tModel
   * type optionally including the default parameters
   *
   * @param requestor AIGServlet
   * @param resultTypeName String
   * @param parameters List
   * @param includeDefaultParams boolean
   * @return Document
   * @throws IOException
   * @throws TransformerException
   * @throws ServiceException
   */
  public Document transformResult(AIGServlet requestor, String resultTypeName, List<ServiceParameter> parameters, boolean includeDefaultParams) throws IOException, TransformerException,
          ServiceException {
    BindingDetails resultBinding = serviceDetails.getResultTypeBinding(resultTypeName);
    if (resultBinding == null) {
      throw new ServiceException("No result type binding " + resultTypeName);
    }
    if (includeDefaultParams) {
      if (parameters == null) {
        parameters = new ArrayList<ServiceParameter>();
      }
      parameters.add(new ServiceParameter("cacheURL", "/aig/cacheretrieval.go?key=" + getResultKey()));
      parameters.add(new ServiceParameter("RG_VERSION", ConfigurationParameterSource.getRGVersion().toString()));
      parameters.add(new ServiceParameter("RG_BASE", requestor.getRGContextPath()));
      parameters.add(new ServiceParameter("RG_PROXY", requestor.getRGContextPath() + "/dataproxy.go"));
      parameters.add(new ServiceParameter("EXT_BASE", requestor.getRGContextPath() + "/ext"));
      try {
        parameters.add(new ServiceParameter("AMGEN_SESSION_LOGIN", requestor.getSessionLogin().getRemoteUser()));
      } catch (AIGException ex) {
        ex.printStackTrace();
      }
      parameters.add(new ServiceParameter("RG_SERVER", requestor.getHttpServletRequest().getScheme() + "://"
              + requestor.getHttpServletRequest().getServerName() + ":" + requestor.getHttpServletRequest().getServerPort()));
    }
    return transformResult(requestor, resultBinding, parameters);
  }

  /**
   * Transforms the result into the format specified by the binding tModel type
   *
   * @param resultTypeName String
   * @return Document
   * @throws IOException
   * @throws TransformerException
   * @throws ServiceException
   */
  public Document transformResult(AIGServlet requestor, String resultTypeName, List<ServiceParameter> parameters) throws IOException, TransformerException, ServiceException {
    BindingDetails resultBinding = serviceDetails.getResultTypeBinding(resultTypeName);
    if (resultBinding == null) {
      throw new ServiceException("No result type binding " + resultTypeName);
    }
    return transformResult(requestor, resultBinding, parameters);
  }

  /**
   * Transforms the result into the format specified by the binding writing to
   * a Writer
   *
   * @param resultBinding BindingDetails
   * @param parameters Map
   * @param writer Writer
   * @throws IOException
   * @throws TransformerException
   * @throws JDOMException
   */
  public void transformResult(AIGServlet requestor, BindingDetails resultBinding, Map<String, String> parameters, Map<String, String> transformerOutputProperties, Writer writer) throws IOException,
          TransformerException,
          JDOMException {
    List<ServiceParameter> serviceParameters = new ArrayList<ServiceParameter>();
    for (String paramName : parameters.keySet()) {
      serviceParameters.add(new ServiceParameter(paramName, parameters.get(paramName)));
    }
    transformResult(requestor, resultBinding, serviceParameters, transformerOutputProperties, writer);
  }

  /**
   * Transforms the result into the format specified by the tModel writing to
   * a Writer
   *
   * @param tModelDetails TModelDetails
   * @param parameters Map
   * @param writer Writer
   * @throws TransformerException
   * @throws IOException
   * @throws JDOMException
   */
  public void transformResult(AIGServlet requestor, TModelDetails tModelDetails, Map<String, String> parameters, Map<String, String> transformerOutputProperties, Writer writer) throws
          TransformerException, IOException,
          JDOMException {
    List<ServiceParameter> serviceParameters = new ArrayList<ServiceParameter>();
    for (String paramName : parameters.keySet()) {
      serviceParameters.add(new ServiceParameter(paramName, parameters.get(paramName)));
    }
    transformResult(requestor, tModelDetails, serviceParameters, transformerOutputProperties, writer);
  }

  /**
   * Transforms the result into the format specified by the binding
   *
   * @param resultBinding BindingDetails
   * @return Document
   * @throws IOException
   * @throws TransformerException
   */
  public Document transformResult(AIGServlet requestor, BindingDetails resultBinding, List<ServiceParameter> parameters) throws IOException, TransformerException {
    if (requiresTransform(resultBinding)) {
      return serviceDetails.performResultTransform(resultBinding, getResultAsDocument(), parameters);
    }
    return getResultAsDocument();
  }

  /**
   * Transforms the result into the format specified by the binding writing to
   * a Writer
   *
   * @param resultBinding BindingDetails
   * @param parameters List
   * @param writer Writer
   * @throws IOException
   * @throws TransformerException
   * @throws JDOMException
   */
  public void transformResult(AIGServlet requestor, BindingDetails resultBinding, List<ServiceParameter> parameters, Map<String, String> transformerOutputProperties, Writer writer) throws
          IOException,
          TransformerException, JDOMException {
    if (requiresTransform(resultBinding)) {
      serviceDetails.performResultTransform(resultBinding, getCacheString(), parameters, transformerOutputProperties, writer);
    }
    ExtXMLElement.write(getResultAsDocument(), writer);
  }

  /**
   * Transforms the result into the format specified by the tModel writing to
   * a Writer
   *
   * @param tModelDetails TModelDetails
   * @param parameters List
   * @param writer Writer
   * @throws TransformerException
   * @throws IOException
   * @throws JDOMException
   */
  public void transformResult(AIGServlet requestor, TModelDetails tModelDetails, List<ServiceParameter> parameters, Map<String, String> transformerOutputProperties, Writer writer) throws
          TransformerException,
          IOException, JDOMException {
    serviceDetails.performResultTransform(tModelDetails, getCacheString(), parameters, transformerOutputProperties, writer);
    //new ExtTransformer(requestor.getHttpServletRequest(), this).transformResult(tModelDetails, parameters, writer);
  }

  /**
   * Check if a transform is required based on the ServiceDetails default
   * result type
   *
   * @param targetResultBinding BindingDetails
   * @return boolean
   */
  private boolean requiresTransform(BindingDetails targetResultBinding) {
    try {
      BindingDetails serviceDefaultResultTypeBinding = serviceDetails.getDefaultResultTypeBinding();
      if (serviceDefaultResultTypeBinding != null) {
        return !(targetResultBinding.getKey().equals(serviceDefaultResultTypeBinding.getKey()));

        // Set<String> resultTypeNames= serviceDefaultResultTypeBinding.getResultTypeNames();
        //   if (ExtString.equals(serviceDefaultResultTypeBinding.getResultTypeName(),
        //                        targetResultBinding.getResultTypeName())) {
        //       return false;
        //  }
      }
    } catch (ServiceException ex) {
    }

    return true;
  }

  public void write(OutputStream out) throws IOException {
    if (getCacheString() != null) {
      out.write(getCacheString().getBytes());
      out.flush();
    }
  }

  public void write(Writer writer) throws IOException {
    if (getCacheString() != null) {
      writer.write(getCacheString());
      writer.flush();
    }
  }
}
