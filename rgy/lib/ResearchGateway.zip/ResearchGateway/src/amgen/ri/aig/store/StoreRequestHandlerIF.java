/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.store;

import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONObject;
import org.jdom.Document;

/**
 *
 * @author jemcdowe
 */
interface StoreRequestHandlerIF {
  

  public JSONObject generateJSONResponse() throws Exception;
  public JSONArray generateJSONArrayResponse() throws Exception;

  public Document generateXMLResponse() throws Exception;
  
  public void writeRawResponse() throws Exception;  

  public enum ResponseFormatType {
    XML, JSON, JSONARRAY, RAW;

    public static ResponseFormatType fromString(String s) {
      try {
        return ResponseFormatType.valueOf(s.toUpperCase());
      } catch (Exception e) {
        return JSON;
      }
    }
  };
  
}
