/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.entitytable.loader;


import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.tree.TreeNode;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.entitytable.*;
import amgen.ri.aig.preferences.PreferenceManager;

/**
 * Custom EntityTable loader for Cell Culture Runs entities
 * @version $Id: CellCultureRunsTableLoader.java,v 1.2 2014/07/08 15:51:47 jemcdowe Exp $
 */
public class CellCultureRunsTableLoader extends GenericEntityTableLoader {
    public CellCultureRunsTableLoader(AIGBase requestor) {
        this(requestor, null);
    }

    public CellCultureRunsTableLoader(AIGBase requestor, String resultNodeKey) {
        super(requestor, EntityListCategory.CELL_CULTURE_RUNS, resultNodeKey);
    }

    /**
     * Overrides the createEntityTableFromResultNode to create the EtityTable
     * from a Result Node
     *
     * @param resultNodeKey String
     * @return EntityTable
     * @throws AIGException
     */
  @Override
    public EntityTable createEntityTableFromResultNode(String resultNodeKey) throws AIGException {
        //Create the table
        EntityTable entityTable = new EntityTable(EntityListCategory.CELL_CULTURE_RUNS);
        new PreferenceManager(getRequestor(), entityTable).setPreferences();
        entityTable.setServiceResultCacheItem(getRequestor().getServiceResultCacheItem(resultNodeKey));
        entityTable.setTableName(getTableName());

        //Create the entity ColumnGroup
        ColumnGroup ccrGroup = new ColumnGroup("Cell Culture Runs");
        entityTable.addColumnGroup(ccrGroup);
        ccrGroup.setIsEntityIDDataIndex(true);
        Column ccdIDColumn= ccrGroup.addColumn(new Column("CCD ID"));
        ccdIDColumn.setWidth(75);
        Column ccdRunNumberColumn= ccrGroup.addColumn(new Column("Run Number"));
        ccdRunNumberColumn.setWidth(145);

        for (TreeNode childResultNode : getChildResultNodes()) {
            String ccdIDLabel = childResultNode.getText();
            String ccdRunNumber = childResultNode.getDescription();
            String ccdID = childResultNode.getServiceData();
            DataRow dataRow = entityTable.addDataRow(new DataRow(ccdID));
            if (dataRow != null) {
                dataRow.addDataCell(new DataCell(ccdIDLabel));
                dataRow.addDataCell(new DataCell(ccdRunNumber));
            }
        }
        return entityTable;
    }



}
