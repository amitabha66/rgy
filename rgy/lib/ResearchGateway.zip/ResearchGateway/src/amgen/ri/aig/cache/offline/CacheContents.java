package amgen.ri.aig.cache.offline;

import amgen.ri.asf.sa.uddi.ClassificationSchemeQuery;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/**
 * Project: ResearchGateway
 * Created By: Jeff McDowell <jemcdowe@address>
 * Created: Oct 7, 2014
 * Revision : $Id: CacheContents.java,v 1.1 2014/10/14 00:13:13 jemcdowe Exp $
 */
public class CacheContents {
      private Multimap<String, ClassificationSchemeQuery> classificationSchemeQueryMap;
      private Set<String> serviceKeys;

  public CacheContents() {
    this.classificationSchemeQueryMap = ArrayListMultimap.create();
    this.serviceKeys= new HashSet<String>();
    
  }

  /**
   * @return the classificationSchemeQueryMap
   */
  public Multimap<String, ClassificationSchemeQuery> getClassificationSchemeQueryMap() {
    return classificationSchemeQueryMap;
  }

  /**
   * @param classificationSchemeQueryMap the classificationSchemeQueryMap to set
   */
  public void addClassificationSchemeQueryMap(Multimap<String, ClassificationSchemeQuery> classificationSchemeQueryMap) {
    this.classificationSchemeQueryMap.putAll(classificationSchemeQueryMap);
  }

  /**
   * @return the serviceKeys
   */
  public Set<String> getServiceKeys() {
    return serviceKeys;
  }

  /**
   * @param serviceKeys the serviceKeys to set
   */
  public void addServiceKeys(Collection<String> serviceKeys) {
    this.serviceKeys.addAll(serviceKeys);
  }
      
      

}
