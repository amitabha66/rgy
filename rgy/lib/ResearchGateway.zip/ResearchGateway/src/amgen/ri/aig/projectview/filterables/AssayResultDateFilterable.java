package amgen.ri.aig.projectview.filterables;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.jdom.Element;
import org.jdom.Namespace;

import amgen.ri.util.ExtDate;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;

/**
 * Encapsulates a filterables include the VQT ids, name, units, type, group.
 * Also holds the set value, operator and sort
 */
public class AssayResultDateFilterable extends ProjectViewFilterable {
    protected SimpleDateFormat vqtDateFormat= new SimpleDateFormat("dd MMM yyyy");

    /**
     * Creates a normal ProjectViewFilterable
     *
     * @param queryable_id String
     * @param retrievable_id String
     * @param name String
     * @param units String
     * @param type String
     * @param group String
     */
    public AssayResultDateFilterable(String filterable_id, String queryable_id, String retrievable_id, String name, String category, String units, String group) {
        super(filterable_id, queryable_id, retrievable_id, name, category, units, "date", group);
    }
/*
         <queryable uid="set3" id="56" name="Assay Result Date">
             <description>Assayed for AA11817 IC50 IP before Oct 31 2010</description>
             <parameters>
                <parameter>
                   <name>result_type</name>
                   <value>IC50 IP</value>
                </parameter>
                <parameter>
                   <name>date_assayed</name>
                   <value>31 Oct 2010</value>
                   <operator>&lt;</operator>
                </parameter>
                <parameter>
                   <name>assay_code</name>
                   <value>AA11817</value>
                </parameter>
             </parameters>
          </queryable>
*/

    public Element getVQTQueryableEl(String uid, Namespace ns) {
        if (!ExtString.hasLength(getValue())) {
            return null;
        }
        Element queryableEl = new Element("queryable", ns);
        ExtXMLElement.addAttribute(queryableEl, "uid", uid);
        ExtXMLElement.addAttribute(queryableEl, "id", getQueryable_id());
        ExtXMLElement.addAttribute(queryableEl, "name", getName());
        ExtXMLElement.addTextElement(queryableEl, "description", getName() + " " + getValue(), ns);
        Element parametersEl = ExtXMLElement.addElement(queryableEl, "parameters", ns);
        //Single Parameter
        Map<String, String> vqtParameters = getVQTParameters();
        if (vqtParameters.size() > 0) {
            Element parameterEl = ExtXMLElement.addElement(parametersEl, "parameter", ns);
            ExtXMLElement.addTextElement(parameterEl, "name", vqtParameters.keySet().iterator().next(), ns);
            ExtXMLElement.addTextElement(parameterEl, "operator", getOperator(true));
            Date start= ExtDate.toDate(getFilterableParameters().get("start"));
            Date end= ExtDate.toDate(getFilterableParameters().get("end"));
            if (start!= null) {
                ExtXMLElement.addTextElement(parameterEl, "value", vqtDateFormat.format(start), ns);
            }
            if (end!= null) {
                ExtXMLElement.addTextElement(parameterEl, "value", vqtDateFormat.format(end), ns);
            }
        }
        return queryableEl;
    }

}
