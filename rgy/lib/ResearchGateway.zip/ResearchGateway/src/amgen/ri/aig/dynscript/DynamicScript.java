/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.dynscript;

import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.sobj.ObjectType;
import amgen.ri.json.JSONObject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Generates any script additions which are Dynamic.
 * Intended to be added as a SCRIPT tag 
 * 
 * @author jemcdowe
 */
public class DynamicScript extends AIGServlet {
  public DynamicScript() {
  }

  public DynamicScript(AIGServlet aigServlet) {
    super(aigServlet);
  }

  public DynamicScript(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  @Override
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new DynamicScript(req, resp);
  }

  @Override
  protected void performRequest() throws Exception {
    JSONObject categories = new JSONObject();
    for (EntityListCategory category : EntityListCategory.values()) {
      JSONObject jCategory = new JSONObject();
      if (!category.equals(EntityListCategory.UNKNOWN)) {
        jCategory.put(category.toString(), EntityListCategory.revertTo(category));
        categories.append("entities", jCategory);
      }
    }
    for (ObjectType.Type objectType : ObjectType.Type.values()) {
      JSONObject jCategory = new JSONObject();
      if (!objectType.equals(ObjectType.Type.UNKNOWN)) {
        jCategory.put(objectType.toString(), ObjectType.Type .revertTo(objectType));
        categories.append("obj_types", jCategory);
      }
    }

  }

  @Override
  protected String getServletMimeType() {
    return "text/plain";
  }
}