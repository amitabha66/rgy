package amgen.ri.aig.cache.item;

import java.io.Serializable;
import java.util.List;

import amgen.ri.asf.sa.uddi.RegistryEntryDetails;

/**
 * Class for wrapping an item used for persisting in the global cache
 *
 * @version $id$
 */
public class GlobalCacheItem extends AbstractCacheItem implements Serializable {
  static final long serialVersionUID = -513768563599257032L;

  /**
   * Creates a GlobalCacheItem for a ServiceDetails object. This includes the
   * expiration time in minutes.
   *
   * @param serviceDetails ServiceDetails
   */
  public GlobalCacheItem(RegistryEntryDetails entryDetails) {
    super(entryDetails.getKey());
    setCacheObject(entryDetails);
  }

  /**
   * Creates a GlobalCacheItem for a List of service keys. This includes the
   * expiration time in minutes.
   *
   * @param key String
   * @param serviceKeys List
   * @param expirationInMinutes long
   */
  public GlobalCacheItem(String key, List<String> serviceKeys) {
    super(key);
    setCacheObject((Serializable) serviceKeys);
  }
}
