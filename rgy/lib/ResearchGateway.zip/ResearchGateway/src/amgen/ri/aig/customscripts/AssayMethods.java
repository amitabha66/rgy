package amgen.ri.aig.customscripts;


import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.Scriptable;

import amgen.ri.aig.scripts.AbstractScriptMethods;


/**
 * Defines a set of methods to be included in the EntityTable Calculated Columns
 * expressions for manipulating the Assay Summary data structure
 *
 * @version $Id: AssayMethods.java,v 1.2 2011/06/21 17:28:57 cvs Exp $
 */
public class AssayMethods extends AbstractScriptMethods {

    public AssayMethods() {
        super();
    }

    private static NativeObject getAssaySummaryNativeObj(Object obj) {
        try {
            if (obj instanceof NativeObject) {
                NativeObject nativeObj = (NativeObject) obj;
                Object value = nativeObj.getProperty(nativeObj, "className");
                if (value.equals("RGScript.AssaySummary")) {
                    return nativeObj;
                }
            }
        } catch (Exception e) {}
        return null;
    }

    /**
     * JS Function: assay summary standard deviation
     */
    public static Object jsFunction_assayStdDev(Context cx, Scriptable thisObj,
                                                Object[] args, Function funObj) {
        if (args == null || args.length == 0) {
            return Double.NaN;
        }
        NativeObject assaySummaryNativeObj = getAssaySummaryNativeObj(args[0]);
        if (assaySummaryNativeObj == null) {
            return Double.NaN;
        }
        try {
            return getAssaySummaryStdDev(assaySummaryNativeObj);
        } catch (Exception e) {}
        return Double.NaN;
    }

    /**
     * JS Function: assay summary aggregation count
     */
    public static Object jsFunction_assayAggCount(Context cx, Scriptable thisObj,
                                                  Object[] args, Function funObj) {
        if (args == null || args.length == 0) {
            return 0;
        }
        NativeObject assaySummaryNativeObj = getAssaySummaryNativeObj(args[0]);
        if (assaySummaryNativeObj == null) {
            return 0;
        }
        try {
            return getAssaySummaryAggCount(assaySummaryNativeObj);
        } catch (Exception e) {}
        return 0;
    }

    /**
     * JS Function: assay summary observations count
     */
    public static Object jsFunction_assayObsCount(Context cx, Scriptable thisObj,
                                                  Object[] args, Function funObj) {
        if (args == null || args.length == 0) {
            return 0;
        }
        NativeObject assaySummaryNativeObj = getAssaySummaryNativeObj(args[0]);
        if (assaySummaryNativeObj == null) {
            return 0;
        }
        try {
            return getAssaySummaryObjCount(assaySummaryNativeObj);
        } catch (Exception e) {}
        return 0;
    }

    /**
     * JS Function: assay summary modified values
     */
    public static Object jsFunction_assayModValues(Context cx, Scriptable thisObj,
            Object[] args, Function funObj) {
        if (args == null || args.length == 0) {
            return null;
        }
        NativeObject assaySummaryNativeObj = getAssaySummaryNativeObj(args[0]);
        if (assaySummaryNativeObj == null) {
            return null;
        }
        try {
            return getAssaySummaryModifiedValues(assaySummaryNativeObj);
        } catch (Exception e) {}
        return null;
    }


    protected static double getAssaySummaryValue(NativeObject assaySummary) {
        Number value = (Number) assaySummary.getProperty(assaySummary, "value");
        return (value == null ? Double.NaN : value.doubleValue());
    }

    protected static double getAssaySummaryStdDev(NativeObject assaySummary) {
        Number value = (Number) assaySummary.getProperty(assaySummary, "stddev");
        return (value == null ? Double.NaN : value.doubleValue());
    }

    protected static int getAssaySummaryAggCount(NativeObject assaySummary) {
        Number value = (Number) assaySummary.getProperty(assaySummary, "aggregationCount");
        return (value == null ? 0 : value.intValue());
    }

    protected static int getAssaySummaryObjCount(NativeObject assaySummary) {
        Number value = (Number) assaySummary.getProperty(assaySummary, "observationCount");
        return (value == null ? 0 : value.intValue());
    }

    protected static String getAssaySummaryModifiedValues(NativeObject assaySummary) {
        Object value = assaySummary.getProperty(assaySummary, "modifiedValues");
        return (value == null ? null : value.toString());
    }

}
