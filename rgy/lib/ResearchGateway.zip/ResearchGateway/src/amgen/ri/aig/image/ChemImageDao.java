/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.image;

import org.apache.commons.lang.ArrayUtils;

/**
 *
 * @author jemcdowe
 */
public class ChemImageDao {
  private int root;
  private int lot;
  private int substanceID;
  private int componentID;

  private int width;
  private int height;

  private String amgenLogin;

  private byte[] results;

  public ChemImageDao(int root, int lot, int substanceID, int componentID, String amgenLogin, int width, int height) {
    this.root = root;
    this.lot = lot;
    this.substanceID = substanceID;
    this.componentID = componentID;
    this.amgenLogin = amgenLogin;
    this.width = width;
    this.height = height;
  }

  public String getBase64Image() {
    if (results != null) {
      return new String(results);
    } else {
      return null;
    }
  }

  /**
   * Get the value of results
   *
   * @return the value of results
   */
  public byte[] getResults() {
    return results;
  }

  /**
   * Set the value of results
   *
   * @param results new value of results
   */
  public void setResults(Byte[] results) {
    this.results = ArrayUtils.toPrimitive(results);
  }

  /**
   * Get the value of amgenLogin
   *
   * @return the value of amgenLogin
   */
  public String getAmgenLogin() {
    return amgenLogin;
  }

  /**
   * Set the value of amgenLogin
   *
   * @param amgenLogin new value of amgenLogin
   */
  public void setAmgenLogin(String amgenLogin) {
    this.amgenLogin = amgenLogin;
  }

  /**
   * Get the value of componentID
   *
   * @return the value of componentID
   */
  public int getComponentID() {
    return componentID;
  }

  /**
   * Set the value of componentID
   *
   * @param componentID new value of componentID
   */
  public void setComponentID(int componentID) {
    this.componentID = componentID;
  }

  /**
   * Get the value of substanceID
   *
   * @return the value of substanceID
   */
  public int getSubstanceID() {
    return substanceID;
  }

  /**
   * Set the value of substanceID
   *
   * @param substance_id new value of substanceID
   */
  public void setSubstanceID(int substanceID) {
    this.substanceID = substanceID;
  }

  private String imgBase64;

  /**
   * Get the value of imgBase64
   *
   * @return the value of imgBase64
   */
  public String getImgBase64() {
    return imgBase64;
  }

  /**
   * Set the value of imgBase64
   *
   * @param imgBase64 new value of imgBase64
   */
  public void setImgBase64(String imgBase64) {
    this.imgBase64 = imgBase64;
  }

  /**
   * Get the value of lot
   *
   * @return the value of lot
   */
  public int getLot() {
    return lot;
  }

  /**
   * Set the value of lot
   *
   * @param lot new value of lot
   */
  public void setLot(int lot) {
    this.lot = lot;
  }

  /**
   * Get the value of root
   *
   * @return the value of root
   */
  public int getRoot() {
    return root;
  }

  /**
   * Set the value of root
   *
   * @param root new value of root
   */
  public void setRoot(int root) {
    this.root = root;
  }

  /**
   * Get the value of width
   *
   * @return the value of width
   */
  public int getWidth() {
    return width;
  }

  /**
   * Set the value of width
   *
   * @param width new value of width
   */
  public void setWidth(int width) {
    this.width = width;
  }

  /**
   * Get the value of height
   *
   * @return the value of height
   */
  public int getHeight() {
    return height;
  }

  /**
   * Set the value of height
   *
   * @param height new value of height
   */
  public void setHeight(int height) {
    this.height = height;
  }

}
