package amgen.ri.aig.customscripts;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.Scriptable;

import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.entity.rgdh.SMCompound;
import amgen.ri.aig.scripts.AbstractScriptMethods;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.util.ExtString;

/**
 * Custom scripts to calculate Ligand Indexes
 * @version $Id: LigandEfficiencyIndexScripts.java,v 1.3 2012/07/07 00:08:52 cvs Exp $
 *
 */
public class LigandEfficiencyIndexScripts extends AbstractScriptMethods {
    public static final double RT = 0.5925; //Energy value (kcal/mol @ 298.15K)

    public LigandEfficiencyIndexScripts() {
        super();
    }

    /**
     * Calculates the Binding Efficiency (BE) ligand index
     *
     * @param cx Context
     * @param scope Scriptable
     * @param args Object[]
     * @param funcScope Function
     * @return Object
     */
    public static Object jsFunction_BindingEfficiency(Context cx, Scriptable scope,
            Object[] args, Function funcScope) {
        double assayValue = Double.NaN;
        try {
            Scriptable assay = (Scriptable) args[0];
            if (assay.has("value", assay)) {
                String value = assay.get("value", assay) + "";
                assayValue = ExtString.toDouble(value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (Double.isNaN(assayValue)) {
            return Double.NaN;
        }
        String entityID = getEntityID(scope);
        if (entityID == null) {
            return Double.NaN;
        }
        SMCompound smCompound = new SMCompound(entityID, new OraSQLManager(), null, JDBCNamesType.RGDH_JDBC+"");
        if (!smCompound.setData()) {
            return Double.NaN;
        }
        double heavyAtoms =smCompound.getHeavyAtomCount();
        if (heavyAtoms<= 0) {
            return Double.NaN;
        }
        return -RT * Math.log(assayValue * 0.000001) / heavyAtoms;
    }
    /**
     * Calculates the LipE ligand index
     *
     * @param cx Context
     * @param scope Scriptable
     * @param args Object[]
     * @param funcScope Function
     * @return Object
     */
    public static Object jsFunction_LipE(Context cx, Scriptable scope,
            Object[] args, Function funcScope) {
        double assayValue = Double.NaN;
        try {
            Scriptable assay = (Scriptable) args[0];
            if (assay.has("value", assay)) {
                String value = assay.get("value", assay) + "";
                assayValue = ExtString.toDouble(value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (Double.isNaN(assayValue)) {
            return Double.NaN;
        }
        String entityID = getEntityID(scope);
        if (entityID == null) {
            return Double.NaN;
        }
        SMCompound smCompound = new SMCompound(entityID, new OraSQLManager(), null, JDBCNamesType.RGDH_JDBC+"");
        if (!smCompound.setData()) {
            return Double.NaN;
        }
        double logP = smCompound.getClogp();
        if (Double.isNaN(logP)) {
            return Double.NaN;
        }
        return  -Math.log10(assayValue * 0.000001) - logP;
    }

    /**
     * Calculates the Binding Efficiency Index (BEI) ligand index
     *
     * @param cx Context
     * @param scope Scriptable
     * @param args Object[]
     * @param funcScope Function
     * @return Object
     */
    public static Object jsFunction_BindingEfficiencyIndex(Context cx, Scriptable scope,
            Object[] args, Function funcScope) {
        double assayValue = Double.NaN;
        try {
            Scriptable assay = (Scriptable) args[0];
            if (assay.has("value", assay)) {
                String value = assay.get("value", assay) + "";
                assayValue = ExtString.toDouble(value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (Double.isNaN(assayValue)) {
            return Double.NaN;
        }
        String entityID = getEntityID(scope);
        if (entityID == null) {
            return Double.NaN;
        }
        SMCompound smCompound = new SMCompound(entityID, new OraSQLManager(), null, JDBCNamesType.RGDH_JDBC+"");
        if (!smCompound.setData()) {
            return Double.NaN;
        }
        double mw = smCompound.getMolecular_weight();
        if (Double.isNaN(mw)) {
            return Double.NaN;
        }
        return -Math.log10(assayValue * 0.000001) / mw;
    }

    /**
     * Calculates the Surface Efficiency (BE) ligand index
     *
     * @param cx Context
     * @param scope Scriptable
     * @param args Object[]
     * @param funcScope Function
     * @return Object
     */
    public static Object jsFunction_SurfaceEfficiency(Context cx, Scriptable scope,
            Object[] args, Function funcScope) {
        double assayValue = Double.NaN;
        try {
            Scriptable assay = (Scriptable) args[0];
            if (assay.has("value", assay)) {
                String value = assay.get("value", assay) + "";
                assayValue = ExtString.toDouble(value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (Double.isNaN(assayValue)) {
            return Double.NaN;
        }
        String entityID = getEntityID(scope);
        if (entityID == null) {
            return Double.NaN;
        }
        SMCompound smCompound = new SMCompound(entityID, new OraSQLManager(), null, JDBCNamesType.RGDH_JDBC+"");
        if (!smCompound.setData()) {
            return Double.NaN;
        }
        double psa = smCompound.getPolar_surface_area();
        if (Double.isNaN(psa)) {
            return Double.NaN;
        }
        return -Math.log10(assayValue * 0.000001) / psa;
    }
}
