package amgen.ri.aig.entitytable.subtable;

import java.io.Serializable;
import java.util.Comparator;
import java.util.Date;

import amgen.ri.aig.entitytable.DataRow;
import amgen.ri.aig.util.AssaySummaryFormat;
import amgen.ri.util.ExtDate;


public class SubtableColumnComparator implements Comparator, Serializable {

    /**
     * Creates a SubtableColumnComparator for the given column- not to be used in the
     * EntityTable sorting
     *
     * @param columnIndex int
     * @param caseSensitive boolean
     * @param isReversed boolean
     */
    public SubtableColumnComparator() {
    }

    /**
     * Create a comparable value for teh given cell value
     *
     * @param value Object
     * @return Object
     */
    private Object getCompareValue(Object cellValue) {
        if (cellValue == null) {
            return null;
        }
        if (cellValue instanceof Number) {
            return ((Number) cellValue).doubleValue();
        }
        String stringValue = cellValue + "";
        double numericVal = AssaySummaryFormat.valueOf(stringValue);
        if (!Double.isNaN(numericVal)) {
            return numericVal;
        }
        Date date = ExtDate.toDate(stringValue);
        if (date != null) {
            return new Double(date.getTime());
        }
        return stringValue;
    }

    /**
     * Does the comparison depending on the column type- String or number
     *
     * @param o1 Object
     * @param o2 Object
     * @return int
     */
    public int compare(Object o1, Object o2) {
        DataRow row1 = ((DataRow) o1);
        DataRow row2 = ((DataRow) o2);
        Object sortValue1 = row1.getDataCellSortValue(0, false);
        Object sortValue2 = row2.getDataCellSortValue(0, false);
        if (sortValue1 == null || sortValue2 == null) {
            return (sortValue1 == null && sortValue2 == null ? 0 : (sortValue1 == null ? -1 : 1));
        }
        Object compareValue1 = getCompareValue(sortValue1);
        Object compareValue2 = getCompareValue(sortValue2);

        if (compareValue1 instanceof Double && compareValue2 instanceof Double) {
            return Double.compare((Double) compareValue1, (Double) compareValue2);
        }
        String compareString1 = compareValue1.toString().toLowerCase();
        String compareString2 = compareValue2.toString().toLowerCase();

        return compareString1.compareTo(compareString2);
    }


}
