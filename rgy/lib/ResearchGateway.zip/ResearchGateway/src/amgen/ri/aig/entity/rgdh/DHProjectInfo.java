package amgen.ri.aig.entity.rgdh;

import java.lang.reflect.Field;
import java.util.List;

import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.CompareTerm;
import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.rdb.SQLManagerIF;
import amgen.ri.util.ExtString;

/**
 *   RDBData wrapper class for Projects
 *   @version $Revision: 1.3 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class DHProjectInfo extends RdbData {
    protected int project_id;
    protected String name;
    protected String description;
    protected String status;
    protected String stage;
    protected String therapeutic_area;
    protected String modality;

    /**
     * Default Constructor
     */
    public DHProjectInfo() {
        super();
    }

    /**
     * RdbData Constructor
     */
    public DHProjectInfo(String project_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.project_id = Integer.parseInt(project_id);
    }

    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return project_id + "";
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }

    /** This method returns the name of the table. */
    protected String getTableName() {
        return "RGDH.PROJECT";
    }


    /** Get value for name */
    public String getName() {
        return (String)get("name");
    }
    /** Get value for description */
    public String getDescription() {
        return (String)get("description");
    }
    /** Get value for status */
    public String getStatus() {
        return (String)get("status");
    }
    /** Get value for stage */
    public String getStage() {
        return (String)get("stage");
    }
    /** Get value for therapeutic_area */
    public String getTherapeutic_area() {
        return (String)get("therapeutic_area");
    }
    /** Get value for modality */
    public String getModality() {
        return (String)get("modality");
    }

    /**
     * Retrieves a DHProjectInfo object given either a project ID or a project
     * name. Returns null if none is is found
     *
     * @param project String
     * @return DHProjectInfo
     */
    public static DHProjectInfo getProjectInfo(String project) {
        if (ExtString.isAInteger(project)) {
            return new DHProjectInfo(project, new OraSQLManager(), null, JDBCNamesType.RGDH_JDBC+"");
        } else {
            List<DHProjectInfo> projectInfos = new RdbDataArray(DHProjectInfo.class, new CompareTerm("name", project), new OraSQLManager(), null, JDBCNamesType.RGDH_JDBC+"");
            return (projectInfos.size() > 0 ? projectInfos.get(0) : null);
        }
    }
}
