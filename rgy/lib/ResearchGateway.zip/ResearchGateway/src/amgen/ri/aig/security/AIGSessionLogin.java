package amgen.ri.aig.security;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.jdom.Document;
import org.jdom.Element;

import amgen.ri.aig.AIGException;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.filter.SessionFormatter;
import amgen.ri.ldap.ActiveDirectoryLookup;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.aig.preferences.RGPreference;
import amgen.ri.aig.preferences.SpecialUserPreferences;
import amgen.ri.aig.preferences.UserPreference;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.servlet.SessionLogin;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtDate;
import amgen.ri.util.ExtFile;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.util.Collection;

/**
 * <p>
 * @version $Id: AIGSessionLogin.java,v 1.10 2015/05/28 17:24:17 jemcdowe Exp $</p>
 */
public class AIGSessionLogin extends SessionLogin {

  private static Map<String, String> userPreferredDisplayNameMap = new HashMap<String, String>();
  private static Map<String, String> userLedgerDisplayNameMap = new HashMap<String, String>();

  private File tempBaseDir;
  private String rgServerAndPort;
  private SessionFormatter sessionFormatter;
  private PersonRecordIF personRecord;
  private Boolean isAdministrator;

  public AIGSessionLogin(SessionLogin source, HttpServletRequest req) throws ServletException {
    super(source);
    String tempBaseDir = ConfigurationParameterSource.getConfigParameter("temp_dir");
    if (tempBaseDir == null) {
      tempBaseDir = "/WEB-INF/temp/" + req.getSession().getId();
    }
    this.tempBaseDir = new File(req.getSession(true).getServletContext().getRealPath(tempBaseDir + "/" + UUID.randomUUID()));
    this.tempBaseDir.mkdirs();
    this.sessionFormatter = new SessionFormatter();

    try {
      this.personRecord = new ActiveDirectoryLookup().lookup(getRemoteUser());
    } catch (Exception e) {
      e.printStackTrace();
    }

    try {
      rgServerAndPort = req.getServerName() + ":" + req.getServerPort();
    } catch (Exception e) {
    }
  }

  public PersonRecordIF getPersonRecord() {
    return personRecord;
  }

  public boolean isAdministrator() {
    if (isAdministrator == null) {
      isAdministrator = false;
      String administrators = ConfigurationParameterSource.getConfigParameter("RG_ADMINISTRATOR_GROUPS");
      if (administrators != null) {
        List<String> administratorGroups = ExtString.splitToList(administrators, ",");
        try {
          Map<String, Boolean> groupMembershipMap = new ActiveDirectoryLookup().isGroupMember(new HashSet(administratorGroups), personRecord);
          for (Boolean groupMembership : groupMembershipMap.values()) {
            if (groupMembership) {
              isAdministrator = true;
            }
          }
        } catch (Exception ex) {
          ex.printStackTrace();
        }
      }
      administrators = ConfigurationParameterSource.getConfigParameter("RG_ADMINISTRATORS");
      if (administrators != null) {
        List<String> administratorLogins = ExtString.splitToList(administrators, ",");
        if (administratorLogins.contains(getRemoteUser())) {
          isAdministrator = true;
        }
      }
    }
    return isAdministrator;
  }

  /**
   * Returns a Map of special user preferences as Preference UserPreferenceType:UserPreference
   *
   * @return Map
   */
  public Map<SpecialUserPreferences, UserPreference> getSpecialUserPreferences() {
    String specialUserPreferencesSQL = "SELECT UP.USER_PREFERENCE_ID FROM USER_PREFERENCES UP, RG_PREFERENCES RGP WHERE "
            + "UP.RG_PREFERENCE_ID= RGP.RG_PREFERENCE_ID AND RGP.RG_PREFERENCE_GROUP_ID=0 AND UP.USERNAME=?";

    List<UserPreference> userPreferences = new RdbDataArray(UserPreference.class, specialUserPreferencesSQL, new String[]{
      getRemoteUser()
    }, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
    Map<SpecialUserPreferences, UserPreference> userPreferenceMap = new HashMap<SpecialUserPreferences, UserPreference>();
    for (UserPreference userPreference : userPreferences) {
      SpecialUserPreferences prefType = SpecialUserPreferences.fromString(userPreference.getRGPreference().getPreference_name());
      if (!prefType.equals(SpecialUserPreferences.NORMAL)) {
        userPreferenceMap.put(prefType, userPreference);
      }
    }
    return userPreferenceMap;
  }

  /**
   * Returns a Map of special user preferences as Preference UserPreferenceType:UserPreference
   *
   * @return Map
   */
  public UserPreference updateSpecialUserPreferences(SpecialUserPreferences preference, String preferenceValue, Document preferenceDocument) {
    UserPreference userPreference;
    Map<SpecialUserPreferences, UserPreference> userPreferenceMap = getSpecialUserPreferences();
    if (userPreferenceMap.containsKey(preference)) {
      userPreference = userPreferenceMap.get(preference);
      userPreference.set("preference_value", preferenceValue);
      if (preferenceDocument != null) {
        userPreference.set("preference_data", ExtXMLElement.toString(preferenceDocument));
      } else {
        userPreference.set("preference_data", null);
      }
    } else {
      userPreference = new UserPreference(
              RGPreference.valueOf(SpecialUserPreferences.RECENT_SERVICES),
              preferenceValue, (preferenceDocument == null ? "" : ExtXMLElement.toString(preferenceDocument)),
              new OraSQLManager(), getRemoteUser(), JDBCNamesType.RG_JDBC + "");
    }

    if (userPreference.performCommit() > 0) {
      return userPreference;
    }
    return null;
  }

  /**
   * Converts the given Date to the users TimeZone from th PST TimeZone
   *
   * @param dateFormSpecifier String
   * @param date Date
   * @return String
   */
  public String convertToUserTimeZone(String dateFormSpecifier, Date date) {
    return ExtDate.getDateStringDate(dateFormSpecifier, date, TimeZone.getTimeZone("PST"), getUsersTimeZone());
  }

  /**
   * Returns the ledger style display name of the given user
   *
   * @return String
   * @param login String
   */
  public String getUserLedgerDisplayName(String login) {
    if (login.equals(getRemoteUser())) {
      return getUserLedgerDisplayName();
    }
    if (userLedgerDisplayNameMap.containsKey(login)) {
      return userLedgerDisplayNameMap.get(login);
    }
    userLedgerDisplayNameMap.put(login, super.getUserLedgerDisplayName(login));
    return userLedgerDisplayNameMap.get(login);
  }

  /**
   * Returns the standard/preferred style display name of the given user
   *
   * @return String
   * @param login String
   */
  public String getUserPreferredDisplayName(String login) {
    if (login.equals(getRemoteUser())) {
      return getUserPreferredDisplayName();
    }
    if (userPreferredDisplayNameMap.containsKey(login)) {
      return userPreferredDisplayNameMap.get(login);
    }
    userPreferredDisplayNameMap.put(login, super.getUserPreferredDisplayName(login));
    return userPreferredDisplayNameMap.get(login);
  }

  /**
   * Returns the session login information as a JSON object
   *
   * @return JSONObject
   */
  public JSONObject getSessionInfo() {
    JSONObject sessionInfo = new JSONObject();
    try {
      sessionInfo.put("LOGIN", getRemoteUser());
      sessionInfo.put("ISADMINISTRATOR", isAdministrator());
      sessionInfo.put("SHOW_CACHEREFRESH", showCacheRefresh());
      sessionInfo.put("DISPLAY_NAME", getUserLedgerDisplayName());
      sessionInfo.put("IP", getRemoteMachineIP());
      sessionInfo.put("LOCATION", getUserAmgenLocationCode());
      sessionInfo.put("TIMEZONE", getUsersTimeZone().getID());
      sessionInfo.put("SESSION_ID", getSessionID());
    } catch (Exception ex) {
    }
    return sessionInfo;
  }

  /**
   * Create a work directory
   *
   * @return File
   */
  public File createWorkDir() {
    File tempDir = new File(this.tempBaseDir, UUID.randomUUID() + "");
    tempDir.mkdirs();
    tempDir.deleteOnExit();
    return tempDir;
  }

  public void sessionDestroyed() {
    try {
      ExtFile.deepdelete(tempBaseDir);
    } catch (Exception e) {
    }

  }

  /**
   * Retrieves or creates a new AIGSessionLogin from the request
   *
   * @param request HttpServletRequest
   * @return SessionLogin
   * @throws AIGException
   */
  public static AIGSessionLogin getAIGSessionLogin(HttpServletRequest request) {
    try {
      return (AIGSessionLogin) getSessionLogin(request);
    } catch (ServletException ex) {
      return null;
    }
  }

  /**
   * Returns the AIGSessionLogin for the session. If none exists, returns null.
   *
   * @param session HttpSession
   * @return SessionLogin
   */
  public static AIGSessionLogin getAIGSessionLogin(HttpSession session) {
    return (AIGSessionLogin) getSessionLogin(session);
  }

  public SessionFormatter getSessionFormatter() {
    return sessionFormatter;
  }

  public String getRgServerAndPort() {
    return rgServerAndPort;
  }

  public Element getSessionElement() {
    Element sessionEl = new Element("Session");
    ExtXMLElement.addAttribute(sessionEl, "ledger_name", getUserLedgerDisplayName() + "");
    ExtXMLElement.addAttribute(sessionEl, "login", getRemoteUser() + "");
    ExtXMLElement.addAttribute(sessionEl, "last_access", getMillisSinceLastAccess() + "");
    ExtXMLElement.addAttribute(sessionEl, "session_id", getSessionID());
    return sessionEl;

  }

  /**
   * getMillisSinceLastAccess
   *
   * @return String
   */
  public long getMillisSinceLastAccess() {
    if (getLastAccess() == null) {
      return 0;
    }
    return System.currentTimeMillis() - getLastAccess().getTime();
  }

  /**
   * Returns whether the last access has been more than the given number of minutes
   *
   * @return String
   * @param minutes double
   */
  public boolean hasBeenLongerThanMinutesSinceLastAccess(double minutes) {
    double millis = getMillisSinceLastAccess();
    double mins = millis / 60000;
    return (mins > minutes);
  }

  private boolean showCacheRefresh() {
    if (isAdministrator()) {
      return true;
    }
    Map<SpecialUserPreferences, UserPreference> userPreferenceMap = getSpecialUserPreferences();
    UserPreference showCachePreference = userPreferenceMap.get(SpecialUserPreferences.SHOW_CACHE);    
    return (showCachePreference== null ? false : showCachePreference.getPreferenceBooleanValue());
  }

}
