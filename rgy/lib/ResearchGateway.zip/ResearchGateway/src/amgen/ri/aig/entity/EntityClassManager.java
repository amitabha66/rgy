package amgen.ri.aig.entity;

import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.entity.oil.OILMapper;
import amgen.ri.asf.sa.uddi.ClassificationSchemeNames;
import amgen.ri.asf.sa.uddi.ServiceParameter;
import amgen.ri.asf.sa.uddi.ServiceParameterCategory;
import amgen.ri.rg.resource.ResourceFactory;
import amgen.ri.xml.ExtXMLElement;
import com.google.common.collect.Iterables;
import java.util.*;
import org.apache.ibatis.session.SqlSession;
import org.jdom.Document;
import org.jdom.Element;

/**
 * Provides the conversions between EntityListCategory <--> ServiceDataCategory This loads the conversions from the XML
 * at rg.entity.types.xml
 *
 */
public class EntityClassManager extends ResourceFactory {

  private Map<EntityListCategory, EntityClass> entityClasses;
  private Map<ServiceDataCategory, EntityClass> serviceInputCategory2EntityClass;

  /**
   * Create a new RGCategoryConversions
   */
  public EntityClassManager() {
    entityClasses = new EnumMap<EntityListCategory, EntityClass>(EntityListCategory.class);
    serviceInputCategory2EntityClass = new EnumMap<ServiceDataCategory, EntityClass>(ServiceDataCategory.class);
    load();
  }

  /**
   * Loads the XML at rg.entity.types.xml into the maps. Any problems results in an IllegalArgumentException
   */
  private void load() {
    SqlSession sqlSession = null;
    try {
      sqlSession = getRGSqlSession();
      OILMapper entityTypesMapper = sqlSession.getMapper(OILMapper.class);
      Document categoryDoc = entityTypesMapper.getEntityTypeXML().getEntityXMLDocument();

      String defaultSingularStyle = ExtXMLElement.getXPathValue(categoryDoc, "//RGEntityType[@name='DEFAULT']/Style/@singular");
      String defaultPluralStyle = ExtXMLElement.getXPathValue(categoryDoc, "//RGEntityType[@name='DEFAULT']/Style/@plural");
      String defaultLoftStyle = ExtXMLElement.getXPathValue(categoryDoc, "//RGEntityType[@name='DEFAULT']/Style/@loft");

      List<Element> typeEls = ExtXMLElement.getXPathElements(categoryDoc, "//RGEntityType[@name!='DEFAULT']");
      for (Element typeEl : typeEls) {
        String rgTypeName = typeEl.getAttributeValue("name");
        EntityListCategory entityListCategory = EntityListCategory.fromString(rgTypeName);
        if (entityListCategory.equals(EntityListCategory.UNKNOWN)) {
          System.err.println("WARNING: Unknown category name " + rgTypeName);
        } else {
          EntityClass entityClass = new EntityClass(entityListCategory, typeEl, defaultSingularStyle, defaultPluralStyle, defaultLoftStyle);
          entityClasses.put(entityListCategory, entityClass);

          for (ServiceDataCategory serviceInputCategory : entityClass.getServiceInputCategories()) {
            serviceInputCategory2EntityClass.put(serviceInputCategory, entityClass);
          }
        }
      }
    } finally {
      close(sqlSession);
    }
  }

  /**
   * Returns the EntityClass for the given EntityListCategory
   *
   * @param entityCategory
   * @return
   */
  public EntityClass getEntityClass(EntityListCategory entityCategory) {
    return entityClasses.get(entityCategory);
  }

  /**
   * Returns the EntityClass for the given ServiceParameterCategory or null if it does not exists
   *
   * @param serviceParameterCategory
   * @return
   */
  public EntityClass getEntityClass(ServiceParameterCategory serviceParameterCategory) {
    if (serviceParameterCategory == null) {
      return null;
    }
    ServiceDataCategory serviceDataCategory = ServiceDataCategory.fromString(serviceParameterCategory.getKeyValue());
    EntityListCategory entityCategory = convertServiceDataCategoryToEntityListCategory(serviceDataCategory);
    return getEntityClass(entityCategory);
  }

  /**
   * Returns the EntityClass for the given ServiceDataCategory or null if it does not exists
   *
   * @param serviceDataCategory
   * @return
   */
  public EntityClass getEntityClass(ServiceDataCategory serviceDataCategory) {
    if (serviceDataCategory == null) {
      return null;
    }
    EntityListCategory entityCategory = convertServiceDataCategoryToEntityListCategory(serviceDataCategory);
    return getEntityClass(entityCategory);
  }

  /**
   * Returns the EntityClass for the given ServiceParameter or null if the parameter is not categorized.
   *
   * If the parameter has multiple EntityTypes, this only returns the FIRST one.
   *
   * @param serviceParameter
   * @return
   */
  public EntityClass getEntityClass(ServiceParameter serviceParameter) {
    List<EntityClass> entityClassList = getEntityClasses(serviceParameter);
    return (entityClassList.isEmpty() ? null : entityClassList.get(0));
  }

  /**
   * Returns all the EntityClasses for the given ServiceParameter or an Empty List if the parameter is not categorized.
   *
   * @param serviceParameter
   * @return
   */
  public List<EntityClass> getEntityClasses(ServiceParameter serviceParameter) {
    List<EntityClass> entityClassList = new ArrayList<EntityClass>();
    if (serviceParameter == null) {
      return entityClassList;
    }
    List<ServiceParameterCategory> parameterCategories = serviceParameter.getServiceParameterCategories(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME);
    for (ServiceParameterCategory serviceParameterCategory : parameterCategories) {
      entityClassList.add(getEntityClass(serviceParameterCategory));
    }
    return entityClassList;
  }

  /**
   * Convert ServiceDataCategory to EntityListCategory
   *
   * @param serviceDataCategory ServiceDataCategory
   * @return EntityListCategory
   */
  public EntityListCategory convertServiceDataCategoryToEntityListCategory(ServiceDataCategory serviceDataCategory) {
    return (serviceInputCategory2EntityClass.containsKey(serviceDataCategory) ? serviceInputCategory2EntityClass.get(serviceDataCategory).getEntityCategory() : EntityListCategory.UNKNOWN);
  }

  /**
   * Converts EntityListCategory to ServiceDataCategories
   *
   * @param entityType EntityListCategory
   * @return List
   */
  public Collection<ServiceDataCategory> convertEntityListCategoryToServiceDataCategories(EntityListCategory entityType) {
    EntityClass entityClass = getEntityClass(entityType);
    if (entityClass == null) {
      return new ArrayList<ServiceDataCategory>();
    }
    return entityClass.getServiceInputCategories();
  }

  /**
   * Converts an EntityListCategory to the top ServiceDataCategory
   *
   * @param entityType EntityListCategory
   * @return ServiceDataCategory
   */
  public ServiceDataCategory convertEntityListCategoryToServiceDataCategory(EntityListCategory entityType) {
    Collection<ServiceDataCategory> serviceDataCategories = convertEntityListCategoryToServiceDataCategories(entityType);
    if (serviceDataCategories.isEmpty()) {
      return ServiceDataCategory.UNKNOWN;
    }
    return Iterables.getFirst(serviceDataCategories, ServiceDataCategory.UNKNOWN);
  }
}
