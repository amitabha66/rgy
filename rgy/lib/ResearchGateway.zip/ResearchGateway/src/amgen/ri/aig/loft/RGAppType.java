
/*
 *   Rg_App_Attributes
 *   RDBData wrapper class for ACCESS_CONTROL
 *   $Revision: 1.6 $
 *   Created: Jeffrey McDowell, 14 Dec 2011
 *   Modified: $Author: jemcdowe $
 *   $Log
 *
 */
package amgen.ri.aig.loft;

import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.SQLManagerIF;
import java.lang.reflect.Field;

/**
 *   RDBData wrapper class for ACCESS_CONTROL
 *   @version $Revision: 1.6 $
 *   @author Jeffrey McDowell
 *   @author $Author: jemcdowe $
 */
public class RGAppType extends RdbData {
  protected String rg_app_type;
  protected boolean is_basic_tool;
  protected String css_class;
  protected String name;
  protected String name2;
  protected String description; 

  /**
   * Default Constructor
   */
  public RGAppType() {
    super();
  }

  /**
   * RdbData Constructor
   */
  public RGAppType(String rg_app_type, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
    this.rg_app_type = rg_app_type;
  }

  /** A required method which returns the primary key(s) of the table/RdbData class. */
  public String getIdentifier() {
    return rg_app_type;
  }

  /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
  protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
    field.set(this, value);
  }

  /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
  protected Object getFieldValue(Field field) throws IllegalAccessException {
    return field.get(this);
  }

  public String getTableName() {
    return "RG_APP_TYPES";
  }
  
  public AppType getAppType() {
    return AppType.fromString(getIdentifier());
  }

  public String getCSSClass() {
    return getAsString("css_class");
  }

  public String getDescription() {
    return getAsString("description");
  }

  public boolean isBasicTool() {
    return getAsBoolean("is_basic_tool");
  }

  public String getName() {
    return getAsString("name");
  }

  public String getName2() {
    return getAsString("name2");
  }

  
  public String toString() {
    return getIdentifier();
  }
}
