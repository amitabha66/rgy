package amgen.ri.aig.entitytable.category.schema2;

import java.io.ObjectStreamException;

/**
 * @version $Id: EntityTableDataType.java,v 1.2 2015/11/13 23:49:02 jemcdowe Exp $
 */
public enum EntityTableDataType {
    DOUBLE, INTEGER, DATE, ASSAY_SUMMARY, TEXT, IMAGE, STRUCTURE, PERSON, HTML, UNSPECIFIED;

    static final long serialVersionUID = 2625383851797827758L;

    public static EntityTableDataType fromString(String s) {
        if (s == null) {
            return TEXT;
        }
        try {
            s = s.toUpperCase().replaceAll(" ", "_");
            if (s.equals("FLOAT")) {
                return DOUBLE;
            }
            return EntityTableDataType.valueOf(s);
        } catch (Exception e) {
            return TEXT;
        }
    }

    /**
     * This is necessary to permit Serializable.
     * A Serialized object containing an enum class variable is not de-Serialized properly.
     * This forces de-Serialized enum to be re-created as this enum through the String
     * @return Object
     * @throws ObjectStreamException
     */
    public Object readResolve() throws ObjectStreamException {
        return EntityTableDataType.fromString(this.toString());
    }

}
