package amgen.ri.aig.customscripts;

import org.apache.commons.math.stat.StatUtils;
import org.apache.commons.math.stat.descriptive.rank.Percentile;
import org.apache.commons.math.util.ResizableDoubleArray;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.Scriptable;

import amgen.ri.aig.scripts.AbstractScriptMethods;
import amgen.ri.util.ExtString;


/**
 * Defines a set of methods to be included in the EntityTable Calculated Columns
 * expressions
 *
 * @version $Id: StandardMethods.java,v 1.2 2011/06/21 17:28:57 cvs Exp $
 */
public class StandardMethods extends AbstractScriptMethods {

    public StandardMethods() {
        super();
    }

    /**
     * JS Function: standard deviation
     */
    public static Object jsFunction_stddev(Context cx, Scriptable thisObj,
                                           Object[] args, Function funObj) {
        double variance = StatUtils.variance(createDoubleArray(args));
        return (Double.isNaN(variance) ? Double.NaN : Math.sqrt(variance));
    }

    /**
     * JS Function: average
     */
    public static Object jsFunction_average(Context cx, Scriptable thisObj,
                                            Object[] args, Function funObj) {

        return StatUtils.mean(createDoubleArray(args));
    }

    /**
     * JS Function: median
     */
    public static Object jsFunction_median(Context cx, Scriptable thisObj,
                                           Object[] args, Function funObj) {
        return new Percentile().evaluate(createDoubleArray(args), 50);
    }

    /**
     * JS Function: percentile
     */
    public static Object jsFunction_percentile(Context cx, Scriptable thisObj,
                                               Object[] args, Function funObj) {
        double[] values = createDoubleArray(args);
        if (values.length > 1) {
            double[] elementArray = new double[values.length - 1];
            System.arraycopy(values, 0, elementArray, 0, values.length - 1);
            double percentile = values[values.length - 1];
            return new Percentile().evaluate(elementArray, percentile);
        }
        return Double.NaN;
    }

    /**
     * JS Function: log 10
     */
    public static Object jsFunction_log10(Context cx, Scriptable thisObj,
                                          Object[] args, Function funObj) {
        double[] values = createDoubleArray(args);
        return (values.length > 0 ? Math.log10(values[0]) : Double.NaN);
    }

    /**
     * JS Function: natural log
     */
    public static Object jsFunction_logE(Context cx, Scriptable thisObj,
                                         Object[] args, Function funObj) {
        double[] values = createDoubleArray(args);
        return (values.length > 0 ? Math.log(values[0]) : Double.NaN);
    }


    /**
     * Creates a double[] from the given Objects. Any NaN values are not included by default,
     * so the returns array length may not be the same as the input array length
     *
     * @param args Object[]
     * @return double[]
     */
    protected static double[] createDoubleArray(Object[] args) {
        return createDoubleArray(args, 0, args.length);
    }

    /**
     * Creates a double[] from the given Objects. Any NaN values are not
     * included by default, so the returns array length may not be the same as
     * the input array length
     *
     * @param args Object[]
     * @param start int
     * @param end int
     * @return double[]
     */
    protected static double[] createDoubleArray(Object[] args, int start, int end) {
        return createDoubleArray(args, start, end, false);
    }

    /**
     * Creates a double[] from the given Objects optionally including the NaN values.
     *
     * @param args Object[]
     * @param start int
     * @param end int
     * @param includeNaN boolean
     * @return double[]
     */
    protected static double[] createDoubleArray(Object[] args, int start, int end, boolean includeNaN) {
        ResizableDoubleArray values = new ResizableDoubleArray();
        if (args != null) {
            for (int i = start; i < end; i++) {
                if (i >= args.length) {
                    break;
                }
                Double value = getNumber(args[i]);
                if (!Double.isNaN(value) || includeNaN) {
                    values.addElement(value);
                }
            }
        }
        return values.getElements();
    }

    /**
     * Performs a conversion of the given value as follows:
     * If obj is a
     * 1. Number, return the double value
     * 2. String, attempt a Java-based conversion
     * 3. NativeObject:
     * 	Call the valueOf method. If this is a Number, return the double value
     * 	Call the toString method and attempt a Java-based conversion.
     * Otherwise, return NaN
     *
     * @param obj Object
     * @return Double
     */
    protected static Double getNumber(Object obj) {
        if (obj instanceof Number) {
            return ((Number) obj).doubleValue();
        } else if (obj instanceof String) {
            return ExtString.toDouble((String) obj);
        } else if (obj instanceof NativeObject) {
            NativeObject nativeObj = (NativeObject) obj;
            try {
                Object valueOf = nativeObj.callMethod(nativeObj, "valueOf", null);
                if (valueOf instanceof Number) {
                    return ((Number) valueOf).doubleValue();
                } else if (valueOf instanceof String) {
                    return ExtString.toDouble((String) valueOf);
                }
                String stringValueOf = nativeObj.callMethod(nativeObj, "toString", null) + "";
                return ExtString.toDouble(stringValueOf);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return Double.NaN;
    }
}
