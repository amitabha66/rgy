/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.uddi;

import amgen.ri.asf.sa.uddi.ClassificationSchemeQuery;
import amgen.ri.asf.sa.uddi.TModelDetails;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 *
 * @author jemcdowe
 */
public final class ServiceQuery {

  private ClassificationSchemeQuery classificationSchemeQuery;
  private Set<String> resultTypes;
  private Set<String> inputTypeAcceptsList;

  public ServiceQuery(ClassificationSchemeQuery classificationSchemeQuery) {
    this.classificationSchemeQuery = classificationSchemeQuery;
    this.resultTypes = new HashSet<String>();
    this.inputTypeAcceptsList = new HashSet<String>();
  }

  public ServiceQuery(ClassificationSchemeQuery classificationSchemeQuery, String... resultTypes) {
    this(classificationSchemeQuery);
    addResultTypes(resultTypes);
  }

  public void setClassificationSchemeQuery(ClassificationSchemeQuery classificationSchemeQuery) {
    this.classificationSchemeQuery = classificationSchemeQuery;
  }

  public boolean hasResultTypes() {
    return !this.resultTypes.isEmpty();
  }

  public void addResultTypes(String... resultTypes) {
    if (resultTypes != null) {
      this.resultTypes.addAll(Arrays.asList(resultTypes));
    }
  }

  public void addResultTypes(TModelDetails... resultTModels) {
    if (resultTypes != null) {
      for (TModelDetails resultTModel : resultTModels) {
        this.resultTypes.add(resultTModel.getName());
      }
    }
  }

  public void addResultTypes(Collection<TModelDetails> resultTModels) {
    if (resultTypes != null) {
      for (TModelDetails resultTModel : resultTModels) {
        this.resultTypes.add(resultTModel.getName());
      }
    }
  }

  public boolean hasInputTypesWhichAcceptList() {
    return !this.inputTypeAcceptsList.isEmpty();
  }

  public void addInputTypeWhichAcceptsList(String... inputTypes) {
    if (inputTypes != null) {
      this.inputTypeAcceptsList.addAll(Arrays.asList(inputTypes));
    }
  }

  public ClassificationSchemeQuery getClassificationSchemeQuery() {
    return classificationSchemeQuery;
  }

  public Set<String> getResultTypes() {
    return resultTypes;
  }

  public Set<String> getInputTypesWhichAcceptsList() {
    return inputTypeAcceptsList;
  }

  public void addAllInputTypeWhichAcceptsList(Collection<String> inputTypes) {
    inputTypeAcceptsList.addAll(inputTypes);
  }
}
