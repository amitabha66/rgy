package amgen.ri.aig.sv;

import java.io.IOException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.wsdl.WSDLException;
import javax.xml.rpc.ServiceException;
import javax.xml.transform.TransformerException;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.xpath.XPath;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.tree.EntityLineage;
import amgen.ri.aig.cache.tree.NodeType;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.item.AbstractCacheItem.ResultRelationshipType;
import amgen.ri.aig.cache.item.EntityTableCacheItem;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.entity.assay.AssayResultTypeOperations;
import amgen.ri.aig.entitytable.CellServiceParameter;
import amgen.ri.aig.entitytable.Column;
import amgen.ri.aig.entitytable.DataCell;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.aig.listener.RecentServiceUpdater;
import amgen.ri.aig.projectview.model.ProjectViewModel;
import amgen.ri.asf.sa.uddi.BindingDetails;
import amgen.ri.asf.sa.uddi.ClassificationSchemeNames;
import amgen.ri.asf.sa.uddi.CommonKeyValues;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.ServiceParameter;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONObject;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;

/**
 * Invokes an entity service and saves it in the cache. An Entity service is
 * a service which uses a node as input which may include its lineage.
 */
public class EntityServiceInvoker {
  private AIGServlet requestorServlet;

  /**
   * Invokes an EntityServiceInvoker used to invoke an entity service and saves
   * it in the cache. An Entity service is
   * a service which uses a node as input which may include its lineage.
   *
   * @param requestorServlet AIGServlet
   */
  public EntityServiceInvoker(AIGServlet requestorServlet) {
    this.requestorServlet = requestorServlet;
  }

  /**
   * Invoke the entity service and saves the result in the cache returning the
   * result key
   *
   * @return String
   * @throws ServiceException
   * @throws AIGException
   * @throws TransformerException
   * @throws IOException
   * @throws JDOMException
   * @throws RemoteException
   * @throws WSDLException
   */
  public String invokeServiceAndCache() throws ServiceException, AIGException, TransformerException, IOException, JDOMException, RemoteException, WSDLException {
    String serviceKey = requestorServlet.getParameter("serviceKey");
    String serviceParams = requestorServlet.getParameter("serviceParams");
    String resultKey = requestorServlet.getParameter("resultKey");
    String treeNodeKey = requestorServlet.getParameter("treeNodeKey");
    String entityTableKey = requestorServlet.getParameter("entityTableKey");
    String projectViewKey = requestorServlet.getParameter("projectViewResultKey");
    boolean refreshCache = requestorServlet.doesParameterExist("refreshCache");
    Map<String, String> serviceParameters = null;

    if (serviceParams != null) {
      try {
        JSONObject serviceParamMap = new JSONObject(serviceParams);
        serviceParameters = new HashMap<String, String>();
        Iterator keys = serviceParamMap.keys();
        while (keys.hasNext()) {
          String key = keys.next() + "";
          if (serviceParamMap.get(key) != null) {
            serviceParameters.put(key, serviceParamMap.getString(key));
          }
        }
      } catch (Exception e) {
      }
    }
    if (treeNodeKey != null) {
      return invokeServiceAndCache(serviceKey, resultKey, treeNodeKey, serviceParameters, refreshCache);
    }
    ServiceDetails serviceDetails = requestorServlet.getServiceDetails(serviceKey, null);
    ServiceAttributes serviceAttributes = new ServiceAttributes(serviceDetails, requestorServlet.getEntityClassManager());
    OILServiceParameterInterceptor oilInterceptor = serviceAttributes.getListenerByType(OILServiceParameterInterceptor.class);
    EntityTableCacheItem entityTableCacheItem = null;
    ProjectViewModel projectViewModel = null;

    if (entityTableKey != null) {
      EntityClassManager entityClassManager = requestorServlet.getEntityClassManager();
      entityTableCacheItem = ServiceCache.getServiceCache(requestorServlet.getHttpServletRequest()).getEntityTableResult(entityTableKey);
      if (entityTableCacheItem != null) {
        EntityTable entityTable = entityTableCacheItem.getEntityTable();
        if (entityTable != null) {
          Number pagedRowIndex = requestorServlet.getParameterNumber("pagedRowIndex");
          String columnDataIndex = requestorServlet.getParameter("columnDataIndex");
          String entityID = entityTable.getEntityID(pagedRowIndex.intValue());
          DataCell cell = null;
          if (entityID != null) {
            cell = entityTable.getDataRow(entityID).getDataCell(entityTable.getColumnIndex(columnDataIndex));
            List<ServiceDataCategory> entityTableServiceDataCategories = new ArrayList<ServiceDataCategory>(entityClassManager.convertEntityListCategoryToServiceDataCategories(entityTable.getEntityCategory()));
            List<String> serviceDataCategoryKeyValues = ServiceDataCategory.revertTo(entityTableServiceDataCategories);
            List<ServiceParameter> entityServiceParameters = serviceDetails.getParameters(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, serviceDataCategoryKeyValues);
            oilInterceptor.setParametersSetByEntityClass(entityTable.getEntityCategory(), entityServiceParameters);
            for (ServiceParameter serviceParameter : entityServiceParameters) {
              serviceParameter.addValue(entityID);
            }
          }
          Column column = entityTable.getColumnByDataIndex(columnDataIndex);
          if (column != null && column.getServiceDataCategory() != null && column.getServiceData() != null) {
            String columnServiceDataCategoryKeyValue = ServiceDataCategory.revertTo(column.getServiceDataCategory());
            List<ServiceParameter> columnServiceParameters = serviceDetails.getParameters(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, columnServiceDataCategoryKeyValue);
            oilInterceptor.setParametersSetByEntityClass(column.getServiceDataCategory(), columnServiceParameters);
            switch (column.getServiceDataCategory()) {
              case ASSAY_IDENTIFIER:
                String assayID = column.getServiceData();
                String assayParameter = AssayResultTypeOperations.getInstance().createAssayParameter(assayID);
                for (ServiceParameter columnServiceParameter : columnServiceParameters) {
                  columnServiceParameter.addValue(assayParameter);
                }
                break;
              default:
                for (ServiceParameter columnServiceParameter : columnServiceParameters) {
                  columnServiceParameter.addValue(column.getServiceData());
                }
                break;
            }
          }
          if (cell != null) {
            for (CellServiceParameter cellParameter : cell.getCellParameters()) {
              if (cellParameter.getParameterName() != null) {
                ServiceParameter serviceParameter = serviceDetails.getParameter(cellParameter.getParameterName());
                if (cellParameter.getParameterValue() != null && ExtString.hasLength(cellParameter.getParameterValue() + "")) {
                  serviceParameter.setValue(cellParameter.getParameterValue() + "");
                }
              } else {
                Set<String> categorizationNames = cellParameter.getParameterClassificationSchemeNames();
                for (String categorizationName : categorizationNames) {
                  List<ServiceParameter> cellServiceParameters = serviceDetails.getParameters(categorizationName, cellParameter.getParameterCategorizations(categorizationName));
                  for (ServiceParameter serviceParameter : cellServiceParameters) {
                    if (cellParameter.getParameterValue() != null && ExtString.hasLength(cellParameter.getParameterValue() + "")) {
                      serviceParameter.setValue(cellParameter.getParameterValue() + "");
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    if (projectViewKey != null) {
      try {
        projectViewModel = (ProjectViewModel) ServiceCache.getServiceCache(requestorServlet.getHttpServletRequest()).getServiceResult(projectViewKey).getProperty("PROJECTVIEWDETAILS");
      } catch (Exception e) {
      }
    }

    resultKey = invokeServiceAndCache(serviceDetails, resultKey, serviceParameters, refreshCache);
    if (entityTableCacheItem != null) {
      ServiceResultCacheItem serviceResultCacheItem = requestorServlet.getServiceResultCacheItem(resultKey);
      serviceResultCacheItem.addRelatedResultKey(ResultRelationshipType.SOURCE_TABLE, entityTableCacheItem.getKey());
    }
    if (projectViewModel != null) {
      ServiceResultCacheItem serviceResultCacheItem = requestorServlet.getServiceResultCacheItem(resultKey);
      serviceResultCacheItem.addRelatedResultKey(ResultRelationshipType.SOURCE_PROJECTVIEW, projectViewKey);
    }
    return resultKey;
  }

  /**
   * Invoke the entity service and saves the result in the cache returning the
   * result key
   *
   * @param serviceKey String
   * @param resultKey String
   * @param treeNodeKey String
   * @param refreshCache boolean
   * @return String
   * @throws ServiceException
   * @throws AIGException
   * @throws TransformerException
   * @throws IOException
   * @throws JDOMException
   * @throws RemoteException
   * @throws WSDLException
   */
  public String invokeServiceAndCache(String serviceKey, String resultKey, String treeNodeKey, Map<String, String> parameters, boolean refreshCache) throws ServiceException, AIGException,
          TransformerException, IOException, JDOMException, RemoteException, WSDLException {

    String[] treeNodeKeys = treeNodeKey.split(",");
    List<Element> treeNodes = requestorServlet.getTreeNodeCache().getTreeNodes(treeNodeKeys);
    if (treeNodes.isEmpty()) {
      return resultKey;
    }
    Element primaryTreeNode = treeNodes.get(0);
    List<EntityLineage> lineageList = requestorServlet.getTreeNodeCache().getEntityLineage(primaryTreeNode);
    String serviceInputCategorizationScheme = ClassificationSchemeNames.getName(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME);
    NodeType nodeType = NodeType.getNodeType(primaryTreeNode);
    if (NodeType.isDataNode(nodeType)) {
      ServiceDetails serviceDetails = requestorServlet.getServiceDetails(serviceKey, lineageList);
      ServiceAttributes serviceAttributes = new ServiceAttributes(serviceDetails, requestorServlet.getEntityClassManager());
      OILServiceParameterInterceptor oilInterceptor = serviceAttributes.getListenerByType(OILServiceParameterInterceptor.class);

      if (nodeType.equals(NodeType.RESULTNODE) || nodeType.equals(NodeType.SERVICENODE)) {
        List<EntityLineage> childNodeLineageList = requestorServlet.getTreeNodeCache().getEntityLineageForChildNodes(treeNodeKey);
        if (childNodeLineageList.size() > 0) {
          String serviceDataTypeCategory = ServiceDataCategory.revertTo(ServiceDataCategory.getServiceDataCategory(primaryTreeNode));
          List<ServiceParameter> serviceParameters = null;
          serviceParameters = serviceDetails.getParameters(serviceInputCategorizationScheme, serviceDataTypeCategory);
          if (serviceParameters != null) {
            oilInterceptor.setParametersSetByEntityClass(ServiceDataCategory.getServiceDataCategory(primaryTreeNode), serviceParameters);
            for (ServiceParameter serviceParameter : serviceParameters) {
              if (serviceParameter.isAcceptsList()) {
                serviceParameter.clearValues();
                for (EntityLineage childNodeLineage : childNodeLineageList) {
                  serviceParameter.addValue(childNodeLineage.getDataValue());
                }
              } else {
                if (childNodeLineageList.size() > 0) {
                  serviceParameter.addValue(childNodeLineageList.get(0).getDataValue());
                }
              }
            }
          }
        }
      } else if (treeNodes.size() > 1) {
        String serviceDataTypeCategory = ServiceDataCategory.revertTo(ServiceDataCategory.getServiceDataCategory(primaryTreeNode));
        List<ServiceParameter> serviceParameters = null;
        serviceParameters = serviceDetails.getParameters(serviceInputCategorizationScheme, serviceDataTypeCategory);
        if (serviceParameters != null) {
          oilInterceptor.setParametersSetByEntityClass(ServiceDataCategory.getServiceDataCategory(primaryTreeNode), serviceParameters);
          for (ServiceParameter serviceParameter : serviceParameters) {
            if (serviceParameter.isAcceptsList()) {
              serviceParameter.clearValues();
              for (Element treeNode : treeNodes) {
                EntityLineage entiytLineage = EntityLineage.getEntityLineageForTreeNode(treeNode);
                serviceParameter.addValue(entiytLineage.getDataValue());
              }
            }
          }
        }
      }
      setServiceDetailsParameters(serviceDetails, parameters, requestorServlet.getEntityClassManager());
      resultKey = runService(serviceDetails, resultKey, refreshCache, false);
      ServiceResultCacheItem serviceResultCacheItem = requestorServlet.getServiceResultCacheItem(resultKey);
      serviceResultCacheItem.addRelatedResultKey(ResultRelationshipType.SOURCE_TREENODES, treeNodeKeys);
    }
    return resultKey;
  }

  /**
   * Invoke the entity service and saves the result in the cache returning the
   * result key
   *
   * @param serviceDetails ServiceDetails
   * @param resultKey String
   * @param classificationSchemeName ClassificationSchemeNames
   * @param classificationSchemeNameValue String
   * @param classificationSchemeParamValues List
   * @param parameters Map
   * @param refreshCache boolean
   * @throws ServiceException
   * @throws AIGException
   * @throws TransformerException
   * @throws IOException
   * @throws JDOMException
   * @throws RemoteException
   * @throws WSDLException
   * @return String
   */
  public String invokeServiceAndCache(ServiceDetails serviceDetails, String resultKey, ServiceDataCategory serviceDataCategory,
          List<String> classificationSchemeParamValues, Map<String, String> parameters, boolean refreshCache, boolean canUseRawBinding) throws ServiceException,
          AIGException,
          TransformerException, IOException, JDOMException, RemoteException, WSDLException {

    ServiceAttributes serviceAttributes = new ServiceAttributes(serviceDetails, requestorServlet.getEntityClassManager());
    OILServiceParameterInterceptor oilInterceptor = serviceAttributes.getListenerByType(OILServiceParameterInterceptor.class);
    String serviceInputCategorizationScheme = ClassificationSchemeNames.getName(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME);
    String serviceDataTypeCategory = ServiceDataCategory.revertTo(serviceDataCategory);

    List<ServiceParameter> classificationSchemeParameters = serviceDetails.getParameters(serviceInputCategorizationScheme, serviceDataTypeCategory);

    oilInterceptor.setParametersSetByEntityClass(serviceDataCategory, classificationSchemeParameters);

    for (ServiceParameter classificationSchemeParameter : classificationSchemeParameters) {
      classificationSchemeParameter.clearValues();
      for (String classificationSchemeParamValue : classificationSchemeParamValues) {
        classificationSchemeParameter.addValue(classificationSchemeParamValue);
      }
    }
    setServiceDetailsParameters(serviceDetails, parameters, requestorServlet.getEntityClassManager());
    return runService(serviceDetails, resultKey, refreshCache, canUseRawBinding);
  }

  /**
   * Invoke the entity service and saves the result in the cache returning the
   * result key
   *
   * @param refreshCache boolean
   * @param canUseRawBinding String
   * @throws ServiceException
   * @throws AIGException
   * @throws TransformerException
   * @throws IOException
   * @throws JDOMException
   * @throws RemoteException
   * @throws WSDLException
   * @return String
   */
  public String invokeServiceAndCache(Map<String, String> parameters, boolean refreshCache, boolean canUseRawBinding) throws ServiceException,
          AIGException, TransformerException, IOException, JDOMException, RemoteException, WSDLException {
    String serviceKey = requestorServlet.getParameter("serviceKey");
    String serviceParams = requestorServlet.getParameter("serviceParams");
    String resultKey = requestorServlet.getParameter("resultKey");
    Map<String, String> serviceParameters = new HashMap<String, String>();

    if (serviceParams != null) {
      try {
        JSONObject serviceParamMap = new JSONObject(serviceParams);
        Iterator keys = serviceParamMap.keys();
        while (keys.hasNext()) {
          String key = keys.next() + "";
          if (serviceParamMap.get(key) != null) {
            serviceParameters.put(key, serviceParamMap.getString(key));
          }
        }
      } catch (Exception e) {
      }
    }
    if (parameters != null) {
      serviceParameters.putAll(parameters);
    }
    ServiceDetails serviceDetails = requestorServlet.getServiceDetails(serviceKey, null);

    setServiceDetailsParameters(serviceDetails, serviceParameters, requestorServlet.getEntityClassManager());
    return runService(serviceDetails, resultKey, refreshCache, canUseRawBinding);
  }

  /**
   * Invoke the entity service and saves the result in the cache returning the
   * result key
   *
   * @param serviceKey String
   * @param resultKey String
   * @param treeNodeKey String
   * @param refreshCache boolean
   * @return String
   * @throws ServiceException
   * @throws AIGException
   * @throws TransformerException
   * @throws IOException
   * @throws JDOMException
   * @throws RemoteException
   * @throws WSDLException
   */
  public String invokeServiceAndCache(ServiceDetails serviceDetails, String resultKey, Map<String, String> parameters, boolean refreshCache) throws ServiceException, AIGException,
          TransformerException, IOException, JDOMException, RemoteException, WSDLException {

    BindingDetails defaultResultTypeBinding = serviceDetails.getDefaultResultTypeBinding();
    if (defaultResultTypeBinding == null) {
      throw new ServiceException("No default result type found");
    }
    setServiceDetailsParameters(serviceDetails, parameters, requestorServlet.getEntityClassManager());

    Debug.print("Launch service " + serviceDetails.getName());
    if (serviceDetails.isServiceReady()) {
      Debug.print("Service Ready " + serviceDetails.getName());
      String resultDocument = null;
      Debug.print("Source lineage found " + serviceDetails.getName());
      ServiceResultCacheItem serviceResultCacheItem = requestorServlet.getServiceResultCacheItem(resultKey);
      if (serviceResultCacheItem != null && !refreshCache) {
        Debug.print("Found cached result " + serviceResultCacheItem.getResultKey());
        resultDocument = serviceResultCacheItem.getCacheString();
      }
      if (resultDocument == null) {
        if (resultKey == null) {
          resultKey = UUID.randomUUID() + "";
        }
        Debug.print("Launch service " + serviceDetails.getName());
        //
        //Un-Comment to write debug to service logger
        //requestorServlet.logServiceDetailsDebug(serviceDetails);

        resultDocument = serviceDetails.executeService2String();
        requestorServlet.addRequestLogServiceInvocationDetails(serviceDetails);
        //Un-Comment to write ServiceInvocationDetails to service logger
        //requestorServlet.logServiceDetailsDebug(serviceDetails.getServiceInvocationDetails());
        //
        //Un-Comment to write results to service logger
        //requestorServlet.logServiceResultsDebug(resultDocument);

        Debug.print("Save result " + resultKey + " " + defaultResultTypeBinding.getFirstResultTypeName());
        ServiceResultCacheItem savedServiceResultCacheItem = requestorServlet.setServiceResultCacheItem(resultKey, serviceDetails, defaultResultTypeBinding.getFirstResultTypeName(), resultDocument);
        if (serviceResultCacheItem != null) {
          savedServiceResultCacheItem.setProperties(serviceResultCacheItem.getProperties());
        }
      }
    } else {
      requestorServlet.setServiceResultCacheItemForTreeNode(resultKey, serviceDetails);
      throw new AIGException("Not all parameters set", AIGException.Reason.NOT_ALL_PARAMS_SET);
    }
    return resultKey;
  }

  /**
   * Invoke the entity service and saves the result in the cache returning the
   * result key
   *
   * @param serviceDetails ServiceDetails
   * @param resultKey String
   * @param refreshCache boolean
   * @return String
   * @throws ServiceException
   * @throws TransformerException
   * @throws IOException
   * @throws JDOMException
   * @throws RemoteException
   * @throws WSDLException
   * @throws AIGException
   */
  private String runService(ServiceDetails serviceDetails, String resultKey, boolean refreshCache, boolean canUseRawBinding) throws ServiceException, TransformerException, IOException,
          JDOMException, RemoteException, WSDLException, AIGException {
       
    BindingDetails defaultResultTypeBinding = serviceDetails.getDefaultResultTypeBinding();
    
    //List<BindingDetails> entityTableRawBindings= serviceDetails.getBindingByTModelName(TModelCommonNameFactory.ENTITYTABLERAWDEFINITION_tMODELNAME);
    
    if (defaultResultTypeBinding == null && canUseRawBinding) {
      List<BindingDetails> rawBindings = serviceDetails.getTypeBinding(ClassificationSchemeNames.EXTENDED_TYPES_CATEGORIZATION_SCHEME, CommonKeyValues.rawResultSpec);
      if (rawBindings.size() > 0) {
        defaultResultTypeBinding = rawBindings.get(0);
      }
    }
    if (defaultResultTypeBinding == null) {
      throw new ServiceException("No default result type found");
    }
    
    
    
    serviceDetails.addListener(new RecentServiceUpdater(this.requestorServlet));

    Debug.print("Launch service " + serviceDetails.getName());
    if (serviceDetails.isServiceReady()) {
      Debug.print("Service Ready " + serviceDetails.getName());
      Document resultDocument = null;
      Debug.print("Source lineage found " + serviceDetails.getName());

      ServiceResultCacheItem serviceResultCacheItem = requestorServlet.getServiceResultCacheItem(resultKey);
      if (defaultResultTypeBinding.isRawResultSpec()) {
        if (serviceResultCacheItem != null && !refreshCache) {
          Debug.print("Found cached result " + serviceResultCacheItem.getResultKey());
        } else {
          if (serviceResultCacheItem == null) {
            if (resultKey == null) {
              resultKey = UUID.randomUUID() + "";
            }
            //requestorServlet.logServiceDetailsDebug(serviceDetails);
            Debug.print("Launch service " + serviceDetails.getName() + " [" + serviceDetails.getKey() + "]");
            Object results = serviceDetails.executeService();
            requestorServlet.addRequestLogServiceInvocationDetails(serviceDetails);
            Debug.print("Save result " + resultKey + " " + defaultResultTypeBinding.getFirstResultTypeName());
            requestorServlet.setServiceResultCacheItem(resultKey, serviceDetails, defaultResultTypeBinding.getFirstResultTypeName(), results);
          }
        }
      } else {
        if (serviceResultCacheItem != null && !refreshCache) {
          Debug.print("Found cached result " + serviceResultCacheItem.getResultKey());
          resultDocument = serviceResultCacheItem.getResultAsDocument();
        }
        if (resultDocument == null) {
          if (resultKey == null) {
            resultKey = UUID.randomUUID() + "";
          }
          //requestorServlet.logServiceDetailsDebug(serviceDetails);
          Debug.print("Launch service " + serviceDetails.getName() + " [" + serviceDetails.getKey() + "]");
          resultDocument = serviceDetails.executeService2JDocument();
          requestorServlet.addRequestLogServiceInvocationDetails(serviceDetails);
          Debug.print("Save result " + resultKey + " " + defaultResultTypeBinding.getFirstResultTypeName());
          requestorServlet.setServiceResultCacheItem(resultKey, serviceDetails, defaultResultTypeBinding.getFirstResultTypeName(), resultDocument);
        }
        try {
          String title = serviceDetails.getServiceDisplayName("tbxnode");
          XPath headXPath = XPath.newInstance("//head");
          Element headElement = (Element) headXPath.selectSingleNode(resultDocument);
          if (headElement != null) {
            Element titleElement = headElement.getChild("title");
            if (titleElement == null) {
              titleElement = new Element("title");
              headElement.addContent(titleElement);
            }
            titleElement.setText(title);
          }
        } catch (Exception e) {
        }
      }
    } else {
      requestorServlet.setServiceResultCacheItemForTreeNode(resultKey, serviceDetails);
      throw new AIGException("Not all parameters set", AIGException.Reason.NOT_ALL_PARAMS_SET);
    }
    return resultKey;
  }

  public static void setServiceDetailsParameters(ServiceDetails serviceDetails, Map<String, ?> parameters, EntityClassManager entityClassManager) {
    ServiceAttributes serviceAttributes = new ServiceAttributes(serviceDetails, entityClassManager);
    OILServiceParameterInterceptor oilInterceptor = serviceAttributes.getListenerByType(OILServiceParameterInterceptor.class);
    if (parameters != null && parameters.size() > 0) {
      Pattern parameterNamePattern = Pattern.compile("\\[([\\w\\s]+)\\]");
      for (String parameterName : parameters.keySet()) {
        Matcher parameterNameMatcher = parameterNamePattern.matcher(parameterName);
        if (parameterNameMatcher.matches()) {
          String parameterKeyValue = parameterNameMatcher.group(1);
          ServiceDataCategory parameterServiceDataCategory = ServiceDataCategory.fromString(parameterKeyValue);
          List<ServiceParameter> serviceParameters;
          switch (parameterServiceDataCategory) {
            case ASSAY_IDENTIFIER:
              String assayID = parameters.get(parameterName) + "";
              String assayParameter = AssayResultTypeOperations.getInstance().createAssayParameter(assayID);
              serviceParameters = serviceDetails.getParameters(
                      ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME,
                      ServiceDataCategory.revertTo(parameterServiceDataCategory));
              oilInterceptor.setParametersSetByEntityClass(parameterServiceDataCategory, serviceParameters);
              for (ServiceParameter serviceParameter : serviceParameters) {
                serviceParameter.setValueFromString(assayParameter);
              }
              break;
            case UNKNOWN:
              break;
            default:
              serviceParameters = serviceDetails.getParameters(
                      ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME,
                      ServiceDataCategory.revertTo(parameterServiceDataCategory));
              oilInterceptor.setParametersSetByEntityClass(parameterServiceDataCategory, serviceParameters);
              for (ServiceParameter serviceParameter : serviceParameters) {
                serviceParameter.setValueFromString(parameters.get(parameterName) + "");
              }
              break;
          }
        } else {
          ServiceParameter serviceParameter = serviceDetails.getParameter(parameterName);
          if (serviceParameter != null) {
            List<String> keyValues = serviceParameter.getCategoryKeyValue(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME);
            List<ServiceDataCategory> parameterCategories = ServiceDataCategory.fromString(keyValues);
            boolean isAssayIdentifier = false;
            for (ServiceDataCategory parameterCategory : parameterCategories) {
              if (parameterCategory.equals(ServiceDataCategory.ASSAY_IDENTIFIER)) {
                isAssayIdentifier = true;
              }
            }
            if (isAssayIdentifier) {
              String assayID = parameters.get(parameterName) + "";
              String assayParameter = AssayResultTypeOperations.getInstance().createAssayParameter(assayID);
              serviceParameter.setValueFromString(assayParameter);
            } else {
              if (parameters.get(parameterName) instanceof JSONArray) {
                JSONArray jsonArrayParameter = (JSONArray) parameters.get(parameterName);
                if (serviceParameter.isAcceptsList()) {
                  serviceParameter.clearValues();
                  for (int i = 0; i < jsonArrayParameter.length(); i++) {
                    serviceParameter.addValue(jsonArrayParameter.optString(i));
                  }
                } else {
                  serviceParameter.setValueFromString(parameters.get(parameterName) + "");
                }
              } else {
                serviceParameter.setValueFromString(parameters.get(parameterName) + "");
              }
            }
          }
        }
      }
    }

  }
}
