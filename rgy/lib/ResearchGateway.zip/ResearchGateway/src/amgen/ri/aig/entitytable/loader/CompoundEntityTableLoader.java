package amgen.ri.aig.entitytable.loader;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.category.schema2.EntityListCategory;

/**
 * Custom EntityTable loader for Compound entities
 * @version $Id: CompoundEntityTableLoader.java,v 1.2 2011/06/21 17:28:57 cvs Exp $
 */
public class CompoundEntityTableLoader extends StructureEntityTableLoader {
    public CompoundEntityTableLoader(AIGBase requestor) {
        this(requestor, null);
    }

    public CompoundEntityTableLoader(AIGBase requestor, String resultNodeKey) {
        super(requestor, EntityListCategory.COMPOUNDS, resultNodeKey);
    }

}
