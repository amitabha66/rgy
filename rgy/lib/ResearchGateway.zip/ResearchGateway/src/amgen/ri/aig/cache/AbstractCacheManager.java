/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.item.GlobalCacheItem;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import java.util.Collection;
import java.util.List;
import javax.servlet.http.HttpSession;

/**
 *
 * @author jemcdowe
 */
public abstract class AbstractCacheManager implements CacheManagerIF {

  public AbstractCacheManager() {
  }

  /**
   * Returns whether the Cache containsInGlobal the given key in the group and
   * hierarchy
   *
   * @param session HttpSession
   * @param cacheType CacheType
   * @param key String
   * @return boolean
   */
  public boolean contains(CacheType cacheType, String key) {
    return get(cacheType, key) != null;
  }


  /**
   * Returns whether the Cache contains the given key in the group and hierarchy and is of type cls
   *
   * @param cacheType CacheType
   * @param cls
   * @param key String
   * @return boolean
   */
  public boolean contains(CacheType cacheType, String key, Class cls) {
    Object obj= get(cacheType, key);
    return (obj!= null && cls.isInstance(obj));
  }

  public Object get(CacheType cacheType, String key) {
    return get(cacheType, key);
  }

  public Object put(CacheType cacheType, String key, Object obj) throws AIGException {
    return put(cacheType, key, obj);
  }

  public Object put(CacheType cacheType, GlobalCacheItem globalCacheItem) throws AIGException {
    return put(cacheType, globalCacheItem.getKey(), globalCacheItem);    
  }

  public List<ServiceDetails> getAllSortedServices(Collection<String> keys, ServiceNamingContext nameContext, boolean removeOfflineServices) {
    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  }
}
