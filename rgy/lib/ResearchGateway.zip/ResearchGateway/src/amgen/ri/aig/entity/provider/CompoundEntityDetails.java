package amgen.ri.aig.entity.provider;

import java.util.Arrays;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.ServiceParameter;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;


/**
 * Returns all compound details for a root number
 */
public class CompoundEntityDetails extends AbstractEntityDetails {
    private String rootNumber;
    private String componentID;
    private boolean noStructure;
    private ServiceCache serviceCache;


    /**
     * Default constructor
     */
    public CompoundEntityDetails(AIGServlet requestor) {
        super(requestor, EntityListCategory.COMPOUNDS);
        serviceCache = ServiceCache.getServiceCache(requestor.getHttpServletRequest());
        this.rootNumber = requestor.getParameter("id");
        this.componentID = requestor.getParameter("component_id");
        this.noStructure = requestor.doesParameterExist("nostructure");
    }

    /**
     * Default constructor
     */
    public CompoundEntityDetails(AIGServlet requestor, String rootNumber, String componentID, boolean showStructure) {
        super(requestor, EntityListCategory.COMPOUNDS);
        serviceCache = ServiceCache.getServiceCache(requestor.getHttpServletRequest());
        this.rootNumber = rootNumber;
        this.componentID = componentID;
        this.noStructure = !showStructure;
    }


    public Document getResponseDocument() throws AIGException {
        Element entityDetailsEl = null;
        try {
            ServiceDetails compoundPropertiesService = getRequestor().getLooselyCoupledServiceDetails("COMPOUND_ENTITY_PROPERTIES");
            List<ServiceParameter> parameters =
                    compoundPropertiesService.getParameters(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME,
                    "Amgen Root ID");
            for (ServiceParameter parameter : parameters) {
                parameter.setValueFromString(rootNumber);
            }
            if (ExtString.hasTrimmedLength(componentID)) {
                List<ServiceParameter> componentParameters =
                        compoundPropertiesService.getParameters(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME,
                        "Amgen Component ID");
                for (ServiceParameter parameter : componentParameters) {
                    parameter.setValueFromString(componentID);
                }
            }
            ServiceParameter includeStructuresParameter = new ServiceParameter("include_structures", (noStructure ? "false" : "true"));
            Document doc = compoundPropertiesService.executeService2JDocument(TModelCommonNameFactory.ENTITYPROPERTYDEFINITION_tMODELNAME, Arrays.asList(new ServiceParameter[] {includeStructuresParameter}));
            getRequestor().addRequestLogServiceInvocationDetails(compoundPropertiesService);

            if (doc != null) {
                entityDetailsEl = doc.detachRootElement();
            }
            if (entityDetailsEl != null) {
                List<Element> propertyEls = ExtXMLElement.getXPathElements(entityDetailsEl, "//Property");
                for (int i = 0; i < propertyEls.size(); i++) {
                    Element propertyEl = propertyEls.get(i);
                    propertyEl.setAttribute("order", i + "");
                }
                return new Document(entityDetailsEl);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public JSONObject getResponseJSON() throws AIGException {
        try {
            ServiceDetails compoundPropertiesService = getRequestor().getLooselyCoupledServiceDetails("COMPOUND_ENTITY_PROPERTIES");
            List<ServiceParameter> parameters =
                    compoundPropertiesService.getParameters(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, "Amgen Root ID");
            for (ServiceParameter parameter : parameters) {
                parameter.setValueFromString(rootNumber);
            }
            if (ExtString.hasTrimmedLength(componentID)) {
                List<ServiceParameter> componentParameters =
                        compoundPropertiesService.getParameters(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, "Amgen Component ID");
                for (ServiceParameter parameter : componentParameters) {
                    parameter.setValueFromString(componentID);
                }
            }
            Document compoundPropertiesDocument = compoundPropertiesService.executeService2JDocument();
            return new CompoundPropertiesJSONObject(compoundPropertiesDocument, componentID, !noStructure).getCompoundPropertiesJSONObject();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }


}


/**
 * Used to create a JSONOject from a CompoundProperties XML document
 *
 * @author not attributable
 * @version 1.0
 */
class CompoundPropertiesJSONObject {
    private Document compoundPropertiesDoc;
    private JSONObject compoundPropertiesJSONObject;

    /**
     * Create a CompoundPropertiesJSONObject object. Provided are the
     * CompoundProperties document, a specific component ID (null for all
     * components), and whether to include the structure image URL in the
     * JSONObject
     *
     * @param compoundPropertiesDoc Document
     * @param componentID String
     * @param includeStructure boolean
     */
    public CompoundPropertiesJSONObject(Document compoundPropertiesDoc, String componentID, boolean includeStructure) throws
        JSONException {
        //try {
        this.compoundPropertiesDoc = compoundPropertiesDoc;
        compoundPropertiesJSONObject = createCompoundPropertiesAsJSON(componentID, includeStructure);
        if (compoundPropertiesJSONObject == null) {
            compoundPropertiesJSONObject = new JSONObject();
        }

    }

    /**
     * Creates the CompoundProperties JSONObject
     *
     * @param componentID String
     * @param includeStructure boolean
     * @return JSONObject
     * @throws Exception
     */
    private JSONObject createCompoundPropertiesAsJSON(String componentID, boolean includeStructure) throws
        JSONException {
        if (compoundPropertiesDoc != null) {
            Element compoundEl = ExtXMLElement.getXPathElement(compoundPropertiesDoc, "//Compound[1]");
            JSONObject componentJSON = new JSONObject();
            List<Element> propertyEls = ExtXMLElement.getXPathElements(compoundPropertiesDoc, "//Property");
            for (int i = 0; i < propertyEls.size(); i++) {
                Element propertyEl = propertyEls.get(i);
                propertyEl.setAttribute("order", i + "");
            }

            Element componentEl = null;
            if (componentID != null) {
                componentEl = ExtXMLElement.getXPathElement(compoundPropertiesDoc,
                    "//Component[@curr_component='" + componentID + "']");
            } else {
                componentEl = ExtXMLElement.getXPathElement(compoundPropertiesDoc, "//Component[1]");
            }
            if (componentEl != null) {
                String root_number = componentEl.getAttributeValue("root_number");
                String currComponentID = componentEl.getAttributeValue("curr_component");
                String nextComponentID = componentEl.getAttributeValue("next_component");
                String prevComponentID = componentEl.getAttributeValue("prev_component");
                String componentIndex = componentEl.getAttributeValue("component_index");
                String componentCount = componentEl.getAttributeValue("component_count");
                componentJSON.put("root_number", root_number);
                componentJSON.put("curr_component", currComponentID);
                componentJSON.put("next_component", nextComponentID);
                componentJSON.put("prev_component", prevComponentID);
                componentJSON.put("component_index", componentIndex);
                componentJSON.put("component_count", componentCount);

                JSONArray propertiesJSONArr = new JSONArray();
                componentJSON.put("Properties", propertiesJSONArr);
                if (includeStructure) {
                    addProperty(propertiesJSONArr, "Structure", root_number, null, null, null, "Compound",
                                "/aig/chemimage?db=acrf&width=150&height=150&rootnumber=" + root_number);
                }
                addProperty(propertiesJSONArr, "Root", root_number, "string", null, null, "Compound");
                addProperty(propertiesJSONArr, "Name", compoundEl,
                            "Component[@component_role='Parent'] [1]/Property[@name='ACDName']/@value", null, null, null,
                            "Compound");

                List<Element>
                    parentComponentEls = ExtXMLElement.getXPathElements(compoundEl,
                    "Component[@component_role='Parent'] [1]/Property[not(@name='Root' or @name='ACDName')]");
                for (Element parentComponentEl : parentComponentEls) {
                    addProperty(propertiesJSONArr, parentComponentEl.getAttributeValue("name"),
                                parentComponentEl.getAttributeValue("value"),
                                parentComponentEl.getAttributeValue("type"), null, null, "Compound");
                }
                List<Element> substanceEls = ExtXMLElement.getXPathElements(compoundEl, "Substances/Substance");
                for (Element substanceEl : substanceEls) {
                    String lotCategory = root_number + "#" + substanceEl.getAttributeValue("Lot");

                    addProperty(propertiesJSONArr, "Date Registered", substanceEl.getAttributeValue("DateReg"), "date",
                                "Y-m-d", null, lotCategory);
                    addProperty(propertiesJSONArr, "Source", substanceEl.getAttributeValue("Source"), null, null, null,
                                lotCategory);
                    int parentCount = ExtXMLElement.getXPathValues(substanceEl,
                        "Component[@component_role='Parent']").size();
                    int saltCount = ExtXMLElement.getXPathValues(substanceEl,
                        "Component[@component_role='Salt']").size();

                    addProperty(propertiesJSONArr, "Components",
                                "Parent(s): " + parentCount + ", Salt(s): " + saltCount, null, null, null, lotCategory);
                    addProperty(propertiesJSONArr, "Effective MW", substanceEl.getAttributeValue("MW"), null, null, null,
                                lotCategory);
                    addProperty(propertiesJSONArr, "State", substanceEl.getAttributeValue("SubstanceState"), null, null, null,
                                lotCategory);

                    String purity = substanceEl.getAttributeValue("Purity");
                    if (ExtString.hasLength(purity)) {
                        addProperty(propertiesJSONArr, "ACRF Purity", purity, null, null, null, lotCategory);
                    }

                    String acrfComments = substanceEl.getAttributeValue("ACRFComments");
                    if (ExtString.hasLength(acrfComments)) {
                        addProperty(propertiesJSONArr, "ACRF Comments", acrfComments, null, null, null, lotCategory);
                    }

                    String stereoComments = substanceEl.getAttributeValue("StereochemistryComments");
                    if (ExtString.hasLength(stereoComments)) {
                        addProperty(propertiesJSONArr, "Stereochemistry Comments", stereoComments, null, null, null,
                                    lotCategory);
                    }

                    List<Element> projectEls = ExtXMLElement.getXPathElements(substanceEl, "Project");
                    for (int i = 0; i < projectEls.size(); i++) {
                        Element projectEl = projectEls.get(i);
                        String color = "#ffffff";
                        if (projectEls.size() > 1) {
                            color = (i % 2 == 0 ? "#efefef" : "dddddd");
                        }
                        addProperty(propertiesJSONArr, "Project", projectEl.getAttributeValue("Name"), null, null,
                                    color, lotCategory);
                        addProperty(propertiesJSONArr, "Therapeutic Area", projectEl.getAttributeValue("TA"), null, null,
                                    color, lotCategory);
                        addProperty(propertiesJSONArr, "Stage", projectEl.getAttributeValue("Stage"), null, null, color,
                                    lotCategory);
                    }
                    Element chemistEl = ExtXMLElement.getXPathElement(substanceEl, "Chemist");
                    if (chemistEl != null) {
                        String chemist = chemistEl.getAttributeValue("firstName") + " " +
                                         chemistEl.getAttributeValue("lastName");
                        addProperty(propertiesJSONArr, "Chemist", chemist, null, null, null, lotCategory);
                    }
                    Element notebookEl = ExtXMLElement.getXPathElement(substanceEl, "Notebook");
                    if (notebookEl != null) {
                        addProperty(propertiesJSONArr, "Company", notebookEl.getAttributeValue("Company"), null, null, null,
                                    lotCategory);
                        addProperty(propertiesJSONArr, "Type", notebookEl.getAttributeValue("Type"), null, null, null,
                                    lotCategory);
                        addProperty(propertiesJSONArr, "Notebook",
                                    notebookEl.getAttributeValue("NB") + "-" +
                                    notebookEl.getAttributeValue("Page") + "-" +
                                    notebookEl.getAttributeValue("Position"), null, null, null, lotCategory);
                    }
                    List<Element> substComponentEls = ExtXMLElement.getXPathElements(substanceEl, "Component");
                    for (int i = 0; i < substComponentEls.size(); i++) {
                        Element substComponentEl = substComponentEls.get(i);
                        String compCatName = lotCategory + " Component " + (i + 1) + "/" + substComponentEls.size() +
                                             " (" +
                                             substComponentEl.getAttributeValue("component_role") + ")";
                        String currSubstComponentID = substComponentEl.getAttributeValue("curr_component");
                        if (includeStructure) {
                            addProperty(propertiesJSONArr, "Structure", currSubstComponentID, null, null, null,
                                        compCatName,
                                        "/aig/chemimage?db=acrf_component&width=150&height=150&component_id=" +
                                        currSubstComponentID);
                        }
                        addProperty(propertiesJSONArr, "Name",
                                    substComponentEl, "Property[@name='ACDName']/@value", null, null, null,
                                    compCatName);
                        List<Element>
                            substPropertiesEls = ExtXMLElement.getXPathElements(substComponentEl,
                            "Property[not(@name='Root' or @name='ACDName')]");
                        for (Element substPropertiesEl : substPropertiesEls) {
                            addProperty(propertiesJSONArr, substPropertiesEl.getAttributeValue("name"),
                                        substPropertiesEl.getAttributeValue("value"),
                                        substPropertiesEl.getAttributeValue("type"), null, null, compCatName);
                        }
                    }
                }
                return componentJSON;
            }
        }
        return null;
    }

    /**
     * Adds a Property JSONObject to the JSONArray
     *
     * @param array JSONArray
     * @param name String
     * @param value String
     * @param type String
     * @param format String
     * @param color String
     * @param category String
     */
    private void addProperty(JSONArray array, String name, String value, String type, String format, String color,
                             String category) {
        addProperty(array, name, value, type, format, color, category, null);
    }

    /**
     * Adds a Property JSONObject to the JSONArray
     *
     * @param array JSONArray
     * @param name String
     * @param el Element
     * @param valueXPath String
     * @param type String
     * @param format String
     * @param color String
     * @param category String
     */
    private void addProperty(JSONArray array, String name, Element el, String valueXPath, String type, String format,
                             String color, String category) {
        addProperty(array, name, ExtXMLElement.getXPathValue(el, valueXPath), type, format, color, category, null);
    }

    /**
     * Adds a Property JSONObject to the JSONArray
     *
     * @param array JSONArray
     * @param name String
     * @param value String
     * @param type String
     * @param format String
     * @param color String
     * @param category String
     * @param imageURL String
     */
    private void addProperty(JSONArray array, String name, String value, String type, String format, String color,
                             String category, String imageURL) {
        JSONObject property = createProperty(name, value, type, format, color, category, imageURL);
        if (property != null) {
            array.put(property);
        }
    }

    /**
     * Adds a Property JSONObject to the JSONArray
     *
     * @param name String
     * @param value String
     * @param type String
     * @param format String
     * @param color String
     * @param category String
     * @param imageURL String
     * @return JSONObject
     */
    private JSONObject createProperty(String name, String value, String type, String format, String color,
                                      String category, String imageURL) {
        if (name != null && value != null) {
            try {
                JSONObject obj = new JSONObject();
                if (name != null) {
                    obj.put("name", name);
                }
                if (value != null) {
                    obj.put("value", value);
                }
                if (type != null) {
                    obj.put("type", type);
                }
                if (format != null) {
                    obj.put("format", format);
                }
                if (color != null) {
                    obj.put("color", color);
                }
                if (category != null) {
                    obj.put("category", category);
                }
                if (imageURL != null) {
                    obj.put("imageURL", imageURL);
                }
                return obj;
            } catch (Exception e) {}
        }
        return null;

    }

    /**
     * Returns the CompoundProperties JSONObject
     *
     * @return JSONObject
     */
    public JSONObject getCompoundPropertiesJSONObject() {
        return compoundPropertiesJSONObject;
    }

}

