package amgen.ri.aig.entitytable.proxy;

import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.entitytable.Column;
import amgen.ri.aig.entitytable.ColumnGroup;
import amgen.ri.aig.entitytable.DataCell;
import amgen.ri.aig.entitytable.DataRow;
import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;
import amgen.ri.aig.entitytable.subtable.SubtableDataCell;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.*;
import org.jdom.Document;
import org.jdom.Element;

/**
 * This class is used as a proxy for retrieving the results of the VQT pivot done
 * in a Java stored procedure. The resulting object is then serialized and sent via a BLOB
 * to the calling process and de-serialized for use.
 *
 */
public class EntityTableProxy implements Serializable, Iterable<DataRow> {
    static final long serialVersionUID = 2769815443876926347L;
    private static final int MAX_ROWS = 10000;
    private EntityListCategory entityTableType;
    private List<ColumnGroup> columnGroups; //List of ColumnGroups in the table
    private List<DataRow> dataRows; //List of DataRows in the table
    private Map<String, DataRow> dataRowMap; //Map of Entity ID:DataRows in the table
    private int rowHeightPixels = -1; //Defines the row height in pixels. Used only to define image heights

    private int maxRows = MAX_ROWS;
    private Map<String, Document> proxyMessages;

    public EntityTableProxy(EntityListCategory entityTableType) {
        this(entityTableType, MAX_ROWS);
    }

    public EntityTableProxy(EntityListCategory entityTableType, int maxRows) {
        this.entityTableType = entityTableType;
        this.maxRows = maxRows;
        columnGroups = new ArrayList<ColumnGroup>();
        dataRows = new ArrayList<DataRow>();
        dataRowMap = new HashMap<String, DataRow>();
    }

    public EntityListCategory getEntityTableType() {
        return entityTableType;
    }

    public List<DataRow> getDataRows() {
        return dataRows;
    }

    public List<ColumnGroup> getColumnGroups() {
        return columnGroups;
    }

    public int getColumnCount() {
        int count = 0;
        for (ColumnGroup columnGroup : getColumnGroups()) {
            count += columnGroup.getColumnCount();
        }
        return count;
    }

    public Map<String, DataRow> getDataRowMap() {
        return dataRowMap;
    }

    public ColumnGroup addColumnGroup(ColumnGroup columnGroup) {
        columnGroups.add(columnGroup);
        return columnGroup;
    }

    /**
     * Deletes a column its data index. If the column is the only member of a column
     * group, it call deleteColumnGroup().
     * Also, removes the sort if there is a dependency on the column
     *
     * @param columnDataIndex String
     * @return boolean
     */
    public boolean deleteColumn(String columnDataIndex) {
        DeleteColumnGroup deleteColumnGroup = DeleteColumnGroup.createDeleteColumnGroupByDataIndex(this, columnDataIndex);
        if (deleteColumnGroup == null) {
            return false;
        }
        if (deleteColumnGroup.columnGroup.getColumnCount() == 1) {
            return deleteColumnGroup(columnDataIndex);
        }
        deleteColumnGroup.columnGroup.deleteColumn(deleteColumnGroup.column);
        deleteCells(deleteColumnGroup.columnPosition, 1);
        return true;
    }

    /**
     * Deletes a column group given a column member's data index.
     * Also, removes the sort if there is a dependency on a member column
     *
     * @param columnDataIndex String
     * @return boolean
     */
    public boolean deleteColumnGroup(String memberColumnDataIndex) {
        DeleteColumnGroup deleteColumnGroup = DeleteColumnGroup.createDeleteColumnGroupByDataIndex(this, memberColumnDataIndex);
        if (deleteColumnGroup == null) {
            return false;
        }
        columnGroups.remove(deleteColumnGroup.columnGroup);
        deleteCells(deleteColumnGroup.columnGroupPosition, deleteColumnGroup.columnGroup.getColumnCount());
        return true;
    }

    /**
     * Delete data cells in the table from [deleteCellStart, deleteCellStart + deleteCellCount)
     *
     * @param deleteCellStart int
     * @param deleteCellCount int
     */
    private void deleteCells(int deleteCellStart, int deleteCellCount) {
        for (DataRow row : dataRows) {
            for (int i = 0; i < deleteCellCount; i++) {
                row.deleteColumn(deleteCellStart);
            }
        }
    }

    /**
     * Adds a DataRow to the table. Returns null if table reached the MAX_ROWS
     *
     * @param dataRow DataRow
     * @return DataRow
     */
    public DataRow addDataRow(DataRow dataRow) {
        if (dataRows.size() >= maxRows) {
            return null;
        }
        dataRows.add(dataRow);
        dataRowMap.put(dataRow.getEntityID(), dataRow);
        return dataRow;
    }


    /**
     * Returns the column index of a column by its data index
     *
     * @param dataIndex String
     * @return int
     */
    public int getColumnIndex(String dataIndex) {
        int index = -1;
        for (ColumnGroup columnGroup : columnGroups) {
            for (Column column : columnGroup.getColumns()) {
                index++;
                if (column.getDataIndex().equals(dataIndex)) {
                    return index;
                }
            }
        }
        return -1;
    }

    /**
     * Returns the column index of a column
     *
     * @param c Column
     * @return int
     */
    public int getColumnIndex(Column c) {
        int index = -1;
        for (ColumnGroup columnGroup : columnGroups) {
            for (Column column : columnGroup.getColumns()) {
                index++;
                if (column == c) {
                    return index;
                }
            }
        }
        return -1;
    }

    /**
     * Returns the column ColumnGroup of a column
     *
     * @param c Column
     * @return ColumnGroup
     */
    public ColumnGroup getColumnGroup(Column c) {
        for (ColumnGroup columnGroup : columnGroups) {
            for (Column column : columnGroup.getColumns()) {
                if (column == c) {
                    return columnGroup;
                }
            }
        }
        return null;
    }

    public void setColumnGroups(List<ColumnGroup> columnGroups) {
        this.columnGroups = columnGroups;
    }

    public void setDataRows(List<DataRow> dataRows) {
        this.dataRows = dataRows;
        this.dataRowMap = new HashMap<String, DataRow>();
        for (DataRow row : dataRows) {
            this.dataRowMap.put(row.getEntityID(), row);
        }
    }

    /**
     * Returns the current row height in pixels
     *
     * @return int
     */
    public int getRowHeightPixels() {
        return rowHeightPixels;
    }

    public int getMaxRows() {
        return maxRows;
    }

    /**
     * Sets the current row height in pixels
     *
     * @param rowHeightPixels int
     */
    public void setRowHeightPixels(int rowHeightPixels) {
        this.rowHeightPixels = rowHeightPixels;
    }

    public void setMaxRows(int maxRows) {
        this.maxRows = maxRows;
    }

    /**
     * Returns the DataRow Iterator for the Iterable interface
     *
     * @return Iterator
     */
    public Iterator<DataRow> iterator() {
        return dataRows.iterator();
    }

    /**
     * Returns a message passed from the proxy source
     *
     * @param key String
     * @return Document
     */
    public Document getProxyMessage(String key) {
        if (proxyMessages == null) {
            return null;
        }
        return proxyMessages.get(key);
    }

    /**
     * Sets a proxy message.
     * Proxy messages are XML documents containing any information passed from
     * source to target.
     *
     * @param key String
     * @param message Document
     */
    public void setProxyMessage(String key, Document message) {
        if (proxyMessages == null) {
            proxyMessages = new HashMap<String, Document>();
        }
        proxyMessages.put(key, message);
    }

    /**
     * Creates an XML Document from this model optionally including the DataRows
     * and DataCells
     *
     * @param includeData boolean
     * @return Document
     */
    public Document createDocument(boolean includeData) {
        Document entityTableDoc = new Document();
        Element entityTableEl = new Element("EntityTable");
        entityTableDoc.addContent(entityTableEl);
        ExtXMLElement.addAttribute(entityTableEl, "name",getEntityTableType().toString());
        ExtXMLElement.addAttribute(entityTableEl, "category", getEntityTableType().toString());
        for (ColumnGroup columnGroup : columnGroups) {
            Element columnGroupEl = ExtXMLElement.addElement(entityTableEl, "ColumnGroup");
            ExtXMLElement.addAttribute(columnGroupEl, "header", columnGroup.getHeaderText());
            for (Column column : columnGroup.getColumns()) {
                Element columnEl = ExtXMLElement.addElement(columnGroupEl, "Column");
                ExtXMLElement.addAttribute(columnEl, "header", column.getHeaderText());
                ExtXMLElement.addAttribute(columnEl, "type", (column.getDataType() == null ? EntityTableDataType.TEXT : column.getDataType()).toString());
                ExtXMLElement.addAttribute(columnEl, "format", (column.getColumnFormat() == null ? null : column.getColumnFormat().getJSON().toString()));
                ExtXMLElement.addAttribute(columnEl, "linkoutTemplate", column.getLinkoutTemplateURL());
                ExtXMLElement.addAttribute(columnEl, "SERVICE_DATA_TYPE_CATEGORY", (column.getServiceDataCategory() == null ? null : column.getServiceDataCategory() + ""));
                ExtXMLElement.addAttribute(columnEl, "SERVICE_DATA", column.getServiceData());
                ExtXMLElement.addAttribute(columnEl, "RELATED_SERVICE_KEY", column.getDrillDownServiceKey());
            }
        }
        if (includeData) {
            for (DataRow row : getDataRows()) {
                Element rowEl = ExtXMLElement.addElement(entityTableEl, "Row");
                ExtXMLElement.addAttribute(rowEl, "entity_id", row.getEntityID());
                for (DataCell cell : row.getDataCells()) {
                    if (cell instanceof SubtableDataCell) {
                        SubtableDataCell subtableDataCell = (SubtableDataCell) cell;
                        Element cellEl = ExtXMLElement.addElement(rowEl, "TableCell");
                        for (DataRow stRow : subtableDataCell.getRows()) {
                            Element stRowEl = ExtXMLElement.addElement(cellEl, "Row");
                            for (DataCell stCell : stRow.getDataCells()) {
                                ExtXMLElement.addElement(stRowEl, "Cell", stCell.getValue());
                            }
                        }
                        ExtXMLElement.addAttribute(rowEl, "entity_id", row.getEntityID());
                    } else {
                        Element cellEl = ExtXMLElement.addElement(rowEl, "Cell", cell.getValue());
                        ExtXMLElement.addAttribute(cellEl, "image_url", cell.getImageURL());
                        if (cell.getLinkoutTokens() != null && cell.getLinkoutTokens().length > 0) {
                            ExtXMLElement.addAttribute(cellEl, "linkoutTokens", ExtString.join(cell.getLinkoutTokens(), ','));
                        }
                    }
                }
            }
        }
        return entityTableDoc;

    }
    /**
     * Deserialize a byte[] Object into an EntityTableProxy object. Returns null
     * if anything goes wrong.
     *
     * @param entityTableProxyObj Object
     * @return EntityTableProxy
     */
    public static EntityTableProxy deserializeObject(Object entityTableProxyObj) {
        if (entityTableProxyObj == null || !(entityTableProxyObj instanceof byte[])) {
            return null;
        }

        try {
            byte[] entityTableBytes = (byte[]) entityTableProxyObj;
            ByteArrayInputStream is = new ByteArrayInputStream(entityTableBytes);

            ObjectInputStream oip = new ObjectInputStream(is);
            Object object = oip.readObject();
            oip.close();
            is.close();
            return (EntityTableProxy) object;
        } catch (Exception e) {
            System.err.println("Unable to deserialize object. Caused by " + e);
        }
        return null;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("Type: " + entityTableType + "\n");
        sb.append("ColumnGroups: " + columnGroups.size() + "\n");
        sb.append("Columns: " + getColumnCount() + "\n");
        sb.append("Rows: " + getDataRows().size() + "\n");

        return sb.toString();

    }


}


/**
 * Hold information related to deleting a column or group.
 * This includes the
 * column's data index (used to find the delete column or group)
 * column group
 * column
 * column position- 0-index position in the table of the column
 * column group position- 0-index position of the first column of the group in the table
 *
 * The DeleteColumnGroup is created by a static so everything gets set correctly from the table
 *
 */
class DeleteColumnGroup {
    public String columnDataIndex;
    public ColumnGroup columnGroup;
    public Column column;
    public int columnPosition;
    public int columnGroupPosition;

    /**
     * Private constructor used by the createDeleteColumnGroupByDataIndex method
     *
     * @param columnGroup ColumnGroup
     * @param column Column
     * @param columnPosition int
     */
    private DeleteColumnGroup(ColumnGroup columnGroup, Column column, int columnPosition) {
        this.columnGroup = columnGroup;
        this.column = column;
        this.columnPosition = columnPosition;
    }

    /**
     * Private method for setting the column group start used by the
     * createDeleteColumnGroupByDataIndex method
     *
     * @param entityTable EntityTable
     */
    private void setColumnGroupStart(EntityTableProxy entityTable) {
        int startColumnGroupPosition = -1;
        if (this.columnGroup != null) {
            for (ColumnGroup columnGroup : entityTable.getColumnGroups()) {
                for (Column column : columnGroup.getColumns()) {
                    startColumnGroupPosition++;
                    if (columnGroup == this.columnGroup) {
                        this.columnGroupPosition = startColumnGroupPosition;
                        return;
                    }
                }
            }
        }
    }


    /**
     * Creates a DeleteColumnGroup using a column data index to find th columns,
     * groups, positions, and sort dependencies in the table
     *
     * @param entityTable EntityTable
     * @param columnDataIndex String
     * @return DeleteColumnGroup
     */
    static DeleteColumnGroup createDeleteColumnGroupByDataIndex(EntityTableProxy entityTable, String columnDataIndex) {
        int position = -1;
        for (ColumnGroup columnGroup : entityTable.getColumnGroups()) {
            for (Column column : columnGroup.getColumns()) {
                position++;
                //Found the member column for the column group
                if (column.getDataIndex().equals(columnDataIndex)) {
                    //Set the DeleteColumnGroup
                    DeleteColumnGroup deleteColumnGroup = new DeleteColumnGroup(columnGroup, column, position);
                    //Set the data index
                    deleteColumnGroup.columnDataIndex = columnDataIndex;
                    //Set the column start
                    deleteColumnGroup.setColumnGroupStart(entityTable);
                    return deleteColumnGroup;
                }
            }
        }
        return null;
    }
}
