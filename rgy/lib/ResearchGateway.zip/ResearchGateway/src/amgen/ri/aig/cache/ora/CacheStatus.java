/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.ora;

import java.sql.Timestamp;

/**
 *
 * @author jemcdowe
 */
public class CacheStatus {

  private Timestamp cacheUpdateStart;
  private Timestamp cacheUpdateEnd;
  private int keysUpdated;
  private int servicesUpdated;

  public CacheStatus() {
  }

  /**
   * @return the cacheUpdateStart
   */
  public Timestamp getCacheUpdateStart() {
    return cacheUpdateStart;
  }

  /**
   * @param cacheUpdateStart the cacheUpdateStart to set
   */
  public void setCacheUpdateStart(Timestamp cacheUpdateStart) {
    this.cacheUpdateStart = cacheUpdateStart;
  }

  /**
   * @return the cacheUpdateEnd
   */
  public Timestamp getCacheUpdateEnd() {
    return cacheUpdateEnd;
  }

  /**
   * @param cacheUpdateEnd the cacheUpdateEnd to set
   */
  public void setCacheUpdateEnd(Timestamp cacheUpdateEnd) {
    this.cacheUpdateEnd = cacheUpdateEnd;
  }

  /**
   * @return the keysUpdated
   */
  public int getKeysUpdated() {
    return keysUpdated;
  }

  /**
   * @param keysUpdated the keysUpdated to set
   */
  public void setKeysUpdated(int keysUpdated) {
    this.keysUpdated = keysUpdated;
  }

  /**
   * @return the servicesUpdated
   */
  public int getServicesUpdated() {
    return servicesUpdated;
  }

  /**
   * @param servicesUpdated the servicesUpdated to set
   */
  public void setServicesUpdated(int servicesUpdated) {
    this.servicesUpdated = servicesUpdated;
  }

}
