package amgen.ri.aig.entitylist;

import amgen.ri.aig.category.schema2.EntityListCategory;
import java.util.Map;

/**
 * Interface for an EntityListMember
 */
public interface EntityListMemberIF extends EntityIF {
    /**
     * Returns the member of the EntityList- i.e. the identifier
     *
     * @return String
     */
    public String getMember();

    /**
     * Returns the label of the EntityList
     *
     * @return String
     */
    public String getLabel();

    /**
     * Returns the EntityListCategory of the member
     */
    public EntityListCategory getEntityCategory();

    /**
     * Returns whether this member has a default result when loaded into the
     * entity tree
     *
     * @return boolean
     */
    public String getDefaultViewServiceKey();

    /**
     * Returns any parameters used to create a default result when loaded into the
     * entity tree
     *
     * @return Map
     */
    public Map<String, Object> getDefaultViewServiceParameters();
}
