package amgen.ri.aig.session;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.entitylist.EntityList;
import amgen.ri.aig.favorites.Favorite;
import amgen.ri.aig.favorites.FavoriteFolderItem;
import amgen.ri.aig.favorites.FavoriteIF;
import amgen.ri.aig.preferences.PreferenceIF;
import amgen.ri.aig.preferences.PreferenceManager;
import amgen.ri.aig.preferences.PreferenceableIF;
import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.aig.sobj.ObjectType;
import amgen.ri.aig.sobj.SavedObject;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.ServiceParameter;
import amgen.ri.html.GenericHTMLElement;
import amgen.ri.html.HTMLElement;
import amgen.ri.json.ExtJSON;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rg.resource.ResourceFactory;
import amgen.ri.util.ExtBase64;
import amgen.ri.util.ExtString;
import java.util.Collection;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * @version $Id: SessionStartViewLoader.java,v 1.8 2012/07/07 00:08:52 cvs
 * Exp $</p>
 *
 * <p>
 * </p>
 *
 * <p>
 * </p>
 *
 * <p>
 * </p> not attributable
 */
public class SessionStartViewLoader extends ResourceFactory implements PreferenceableIF {
  private enum RGLoadComponent {
    VQT, FAVORITES,
    TABLEIMPORT,
    DOCUMENTS,
    EXPLORE,
    LISTS,
    PROJECTVIEWS,
    STRUCTURESEARCH,
    NONE;

    public static RGLoadComponent fromString(String s) {
      try {
        return RGLoadComponent.valueOf(s.toUpperCase());
      } catch (Exception e) {
      }
      return NONE;
    }

    private static RGLoadComponent firstFromStrings(Collection<String> names) {
      for (String name : names) {
        if (!RGLoadComponent.fromString(name).equals(RGLoadComponent.NONE)) {
          return RGLoadComponent.fromString(name);
        }
      }
      return RGLoadComponent.NONE;
    }
  }
  private AIGSessionLogin sessionLogin;
  private HttpServletRequest request;

  private RGLoadComponent loadComponent;
  private SavedObject loadObject;
  private FavoriteIF loadFavorite;
  private EntityList loadList;
  private ServiceDetails serviceDetails;
  private String queryRunID;
  private JSONObject serviceParams;
  private int loadDelayMillis;

  public SessionStartViewLoader(HttpServletRequest request) {
    this.request = request;
    sessionLogin = AIGSessionLogin.getAIGSessionLogin(request);
    this.loadDelayMillis = 50;
    new PreferenceManager(sessionLogin, this).setPreferences();

    this.loadComponent = RGLoadComponent.firstFromStrings(request.getParameterMap().keySet());
    String listID = getParameter("list_id");
    String tableID = getParameter("table_id");
    String favoriteID = getParameter("favorite_id");
    String itemID = getParameter("item_id");
    String serviceKey = getParameter("serviceKey");
    String serviceParams = getParameter("serviceParams");
    queryRunID = getParameter("query_run_id");

    if (ExtString.hasLength(serviceParams)) {
      this.serviceParams = (JSONObject) ExtJSON.toJSON(serviceParams);
    }

    if (ExtString.hasLength(itemID)) {
      FavoriteFolderItem favoriteFolderItem = new FavoriteFolderItem(itemID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
      if (favoriteFolderItem.setData()) {
        loadFavorite = favoriteFolderItem.getItem();
      }
    }
    if (ExtString.hasLength(favoriteID)) {
      Favorite favObject = new Favorite(favoriteID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
      if (favObject.setData()) {
        loadFavorite = favObject;
      }
    }
    if (loadFavorite == null && ExtString.hasLength(tableID)) {
      SavedObject tableObject = new SavedObject(tableID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
      if (tableObject.setData() && tableObject.getObject_type().getTypeID() == ObjectType.ENTITYTABLE) {
        loadObject = tableObject;
      }
    }
    if (loadObject == null && ExtString.hasLength(listID)) {
      EntityList entityList = new EntityList(listID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
      if (entityList.setData()) {
        loadList = entityList;
      }
    }
    if (loadObject == null && loadList == null && ExtString.hasLength(serviceKey)) {
      try {
        this.serviceDetails = ServiceCache.getServiceCache(request).getService(serviceKey);
      } catch (AIGException ex) {
        ex.printStackTrace();
      }
    }
  }

  public HTMLElement createLoadScript() {
    HTMLElement script = new GenericHTMLElement("SCRIPT");
    try {
      JSONObject loadTaskArgs = new JSONObject();
      if (loadFavorite != null) {
        switch (loadFavorite.getObjectType().getTypeID()) {
          case ObjectType.ENTITYTABLE:
            if (loadFavorite.getFavoriteKeys().length > 0) {
              loadTaskArgs.put("table_id", loadFavorite.getFavoriteKeys()[0].getFavorite_key());
              loadTaskArgs.put("list_name", loadFavorite.getName());
              loadTaskArgs.put("progress_title", "Loading " + loadFavorite.getName());
            }
            break;
          case ObjectType.PROJECTVIEW:
            if (loadFavorite.getFavoriteKeys().length > 0) {
              JSONObject pvDetails = new JSONObject(loadFavorite.getFavoriteKeys()[0].getFavorite_key());
              loadTaskArgs.put("view_id", pvDetails.get("viewID"));
              loadTaskArgs.put("project", pvDetails.get("project"));
              loadTaskArgs.put("progress_title", "Loading " + loadFavorite.getName());
            }
            break;
          case ObjectType.LIST:
            if (loadFavorite.getFavoriteKeys().length > 0) {
              loadTaskArgs.put("list_id", loadFavorite.getFavoriteKeys()[0].getFavorite_key());
              loadTaskArgs.put("list_name", loadFavorite.getName());
              loadTaskArgs.put("progress_title", "Loading " + loadFavorite.getName());
            }
            break;
          case ObjectType.SERVICE:
            if (loadFavorite.getFavoriteKeys().length > 0) {
              loadTaskArgs.put("saved_service_id", loadFavorite.getFavoriteKeys()[0].getFavorite_key());
              loadTaskArgs.put("list_name", loadFavorite.getName());
              loadTaskArgs.put("progress_title", "Loading " + loadFavorite.getName());
            }
            break;
        }
      }

      if (loadObject != null) {
        switch (loadObject.getObject_type().getTypeID()) {
          case ObjectType.ENTITYTABLE:
            loadTaskArgs.put("table_id", loadObject.getIdentifier());
            loadTaskArgs.put("list_name", loadObject.getName());
            loadTaskArgs.put("progress_title", "Loading " + loadObject.getName());
            break;
          case ObjectType.PROJECTVIEW:
            loadTaskArgs.put("table_id", loadObject.getIdentifier());
            loadTaskArgs.put("list_name", loadObject.getName());
            loadTaskArgs.put("progress_title", "Loading " + loadObject.getName());
        }
      } else if (loadList != null) {
        loadTaskArgs.put("list_id", loadList.getIdentifier());
        loadTaskArgs.put("list_name", loadList.getName());
        loadTaskArgs.put("progress_title", "Loading " + loadList.getName());
      } else if (serviceDetails != null) {
        boolean loadOnly = (getParameter("xrg_lo") != null);
        ServiceAttributes serviceAttr = new ServiceAttributes(serviceDetails, getEntityClassManager());

        loadTaskArgs.put("serviceRecord", serviceAttr.getServiceRecord());
        if (serviceParams != null) {
          loadTaskArgs.put("service_params", ExtJSON.encodeJSON(serviceParams));
        } else {
          serviceParams = new JSONObject();
          Collection<ServiceParameter> serviceParameters = serviceDetails.getParameters();
          for (ServiceParameter serviceParameter : serviceParameters) {
            String value = getParameter(serviceParameter.getParameterName());
            if (ExtString.hasLength(value)) {
              serviceParams.put(serviceParameter.getParameterName(), value);
              serviceParameter.setValueFromString(value);
            }
          }
          loadTaskArgs.put("service_params", ExtJSON.encodeJSON(serviceParams));
        }
        script.appendContentLine("loadLaunchPad= false;");

        if (!loadOnly) {
          if (!serviceDetails.isServiceReady()) {
            loadOnly = true;
          }
        }
        if (loadOnly) {
          JSONObject jServiceRecord = serviceAttr.getServiceRecord();
          if (serviceParams != null && serviceParams.length() > 0) {
            jServiceRecord.put("InitialParameterValues", serviceParams);
          }
          boolean hideResources = (getParameter("xrg_hr") != null);
          String loadScript
                  = "AIG.entityTreePanel.on('render', function() {"
                  + "var obj= new RG.Service.Launcher({showResources: " + !hideResources + "});"
                  + "AIG.Security.reloadSMToken();"
                  + "obj.launchAndExecuteService.defer(" + loadDelayMillis + ", obj, ['" + jServiceRecord + "']);"
                  + "});";

          script.appendContentLine(loadScript);
        } else {
          String loadScript
                  = "AIG.entityTreePanel.on('render', function() {"
                  + "var obj= new RG.Service.Launcher();"
                  + "obj.executeLaunchService.defer(" + loadDelayMillis + ", obj, ['" + serviceAttr.getServiceRecord() + "', '" + ExtJSON.encodeJSON(serviceParams) + "']);"
                  + "});";
          script.appendContentLine(loadScript);
        }
        return script;
      } else if (ExtString.hasLength(queryRunID)) {
        String loadScript
                = "AIG.entityTreePanel.on('render', function() {"
                + "var obj= new RG.Service.Launcher();"
                + "obj.loadQueryResultFromQueryRunID.defer(" + loadDelayMillis + ", obj, ['" + queryRunID + "']);"
                + "});";
        script.appendContentLine(loadScript);
        script.appendContentLine("loadLaunchPad= false;");
        return script;
      }

      if (loadTaskArgs.length() > 0) {
        script.appendContentLine("loadLaunchPad= false;");
        String loadScript;
        if (loadFavorite != null) {
          loadScript
                  = "AIG.entityTreePanel.on('render', function() {"
                  + "var obj= new RG.Loft.AppLauncher();"
                  + "obj.launchFavoriteByIDHandler.defer(" + loadDelayMillis + ", obj, ['" + loadFavorite.getIdentifier() + "']);"
                  + "});";
        } else {
          loadScript = "AIG.entityTreePanel.on('render', function() {"
                  + "RG.Load.loadEntityList.defer(" + loadDelayMillis + ", this, [" + loadTaskArgs + "]);"
                  + "});";
        }
        script.appendContentLine(loadScript);
      }

      String componentLoadScript = null;
      switch (loadComponent) {
        case VQT:
          componentLoadScript
                  = "AIG.entityTreePanel.on('render', function() {"
                  + "var obj= new RG.Loft.AppLauncher();"
                  + "obj.launchVQTToolHandler.defer(" + loadDelayMillis + ", obj);"
                  + "});";
          break;
        case FAVORITES:
          componentLoadScript
                  = "AIG.entityTreePanel.on('render', function() {"
                  + "var obj= new RG.Loft.AppLauncher();"
                  + "obj.launchFavoritesToolHandler.defer(" + loadDelayMillis + ", obj);"
                  + "});";
          break;
        case TABLEIMPORT:
          componentLoadScript
                  = "AIG.entityTreePanel.on('render', function() {"
                  + "var obj= new RG.Loft.AppLauncher();"
                  + "obj.launchTableImportToolHandler.defer(" + loadDelayMillis + ", obj);"
                  + "});";
          break;
        case DOCUMENTS:
          componentLoadScript
                  = "AIG.entityTreePanel.on('render', function() {"
                  + "var obj= new RG.Loft.AppLauncher();"
                  + "obj.launchDocumentsToolHandler.defer(" + loadDelayMillis + ", obj);"
                  + "});";
          break;
        case EXPLORE:
          componentLoadScript
                  = "AIG.entityTreePanel.on('render', function() {"
                  + "var obj= new RG.Loft.AppLauncher();"
                  + "obj.launchExploreToolHandler.defer(" + loadDelayMillis + ", obj);"
                  + "});";
          break;
        case LISTS:
          componentLoadScript
                  = "AIG.entityTreePanel.on('render', function() {"
                  + "var obj= new RG.Loft.AppLauncher();"
                  + "obj.launchListToolHandler.defer(" + loadDelayMillis + ", obj);"
                  + "});";
          break;
        case PROJECTVIEWS:
          componentLoadScript
                  = "AIG.entityTreePanel.on('render', function() {"
                  + "var obj= new RG.Loft.AppLauncher();"
                  + "obj.launchProjectViewToolHandler.defer(" + loadDelayMillis + ", obj);"
                  + "});";
          break;
        case STRUCTURESEARCH:
          componentLoadScript
                  = "AIG.entityTreePanel.on('render', function() {"
                  + "var obj= new RG.Loft.AppLauncher();"
                  + "obj.launchStructureSearchToolHandler.defer(" + loadDelayMillis + ", obj);"
                  + "});";
          break;
      }

      if (componentLoadScript != null) {
        script.appendContentLine(componentLoadScript);
        script.appendContentLine("loadLaunchPad= false;");
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return script;
  }

  private String getParameter(String parameterName) {
    String base64 = request.getParameter("xrg_p");
    if (base64 != null) {
      try {
        JSONObject json2 = new JSONObject(new String(ExtBase64.decode(base64)));
        if (json2.has(parameterName)) {
          return json2.getString(parameterName);
        }
      } catch (Exception ex) {
      }
    }
    return request.getParameter(parameterName);

  }

  /**
   * Returns the PreferenceGroup for this PreferenceableIF object
   *
   * @return String
   */
  public String getPreferenceGroup() {
    return "Startup";
  }

  /**
   * Sets a Preference in this PreferenceableIF object
   *
   * @param preference PreferenceIF
   */
  public void setPreference(PreferenceIF preference) {
  }
}
