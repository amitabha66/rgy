package amgen.ri.aig.sv;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.asf.sa.uddi.ServiceDetails;

public class ExecuteViewService extends AIGServlet {
    /**
     * Default constructor
     */
    public ExecuteViewService() {
        super();
    }

    /**
     * Main constructor- used only by the getAIGServlet method
     *
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    private ExecuteViewService(HttpServletRequest request, HttpServletResponse response) {
        super(request, response);
    }

    /**
     * Creates this AIG Servlet object
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return AIGServlet
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new ExecuteViewService(req, resp);
    }

    /**
     * Performs the query request- either from the input from a form or a list
     *
     * @throws ServletException
     * @throws IOException
     */
    protected void performRequest() throws ServletException, IOException {
        Object resultsObj = null;
        try {
            String projectName = getParameter("projectName");
            ServiceDetails serviceDetails = null;
            if (getParameter("serviceKey") != null) {
                serviceDetails = ServiceCache.getServiceCache(request).getService(getParameter("serviceKey"));
                serviceDetails.setParameterValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, "Project", projectName);

                setSecurityServiceParameters(serviceDetails);

                for (String parameterName : serviceDetails.getParameterNames()) {
                    String parameterValue = getParameter(parameterName);
                    if (parameterValue != null && parameterValue.trim().length() > 0) {
                        serviceDetails.setParameterValue(parameterName, parameterValue);
                    }
                }
            }
            if (serviceDetails != null && serviceDetails.isServiceReady()) {
                String resultTypeBinding = getParameter("resultType");
                if (serviceDetails.isDefaultResultTypeBinding(resultTypeBinding)) {
                    resultsObj = serviceDetails.executeService();
                    addRequestLogServiceInvocationDetails(serviceDetails);
                } else {
                    if (resultTypeBinding == null || serviceDetails.getResultTypeBinding(resultTypeBinding) != null) {
                        if (resultTypeBinding != null) {
                            resultsObj = serviceDetails.executeService2JDocument(resultTypeBinding);
                            addRequestLogServiceInvocationDetails(serviceDetails);
                        } else {
                            resultsObj = serviceDetails.executeService2JDocument();
                            addRequestLogServiceInvocationDetails(serviceDetails);
                        }
                    }
                }
                if (resultsObj != null) {
                    if (resultsObj instanceof String) {
                        response.getWriter().write((String) resultsObj);
                    } else if (resultsObj instanceof byte[]) {
                        response.getOutputStream().write((byte[]) resultsObj);
                    } else if (resultsObj instanceof Document) {
                        new XMLOutputter().output((Document) resultsObj, response.getWriter());
                    } else if (resultsObj instanceof Element) {
                        new XMLOutputter().output((Element) resultsObj, response.getWriter());
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Returns the mimetype of the servlet
     */
    protected String getServletMimeType() {
        return "text/xml";
    }

}
