package amgen.ri.aig.scripts;

import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

import amgen.ri.aig.entitytable.DataRow;

/**
 * <p>@version $Id: AbstractScriptMethods.java,v 1.2 2011/06/21 17:28:58 cvs Exp $</p>
 */
public abstract class AbstractScriptMethods extends ScriptableObject {

    public AbstractScriptMethods() {}

    /**
     * Returns the name of this JavaScript class- Not actually used
     */
    public String getClassName() {
        return this.getClass().getSimpleName();
    }

    /**
     * Returns the the RGObjs JS object which is added to all script calls at the top
     * of the scope hierarchy. Null if not available.
     *
     * @param scope Scriptable
     * @return Scriptable
     */
    public static Scriptable getRGObjs(Scriptable scope) {
        if (scope != null) {
            if (scope.has("RGObjs", scope)) {
                return (Scriptable) scope.get("RGObjs", scope);
            }
            return getRGObjs(scope.getParentScope());
        }
        return null;
    }

    /**
     * Returns the the DataRow from the RGObjs JS object which is added to all script calls at the top
     * of the scope hierarchy. Null if not available.
     *
     * @param scope Scriptable
     * @return DataRow
     */
    public static DataRow getDataRow(Scriptable scope) {
        Scriptable rgObjs = getRGObjs(scope);
        if (rgObjs != null && rgObjs.has("dataRow", rgObjs)) {
            return (DataRow) rgObjs.get("dataRow", rgObjs);
        }
        return null;
    }

    /**
     * Returns the the EntityID from the RGObjs JS object which is added to all script calls at the top
     * of the scope hierarchy. Null if not available.
     *
     * @param scope Scriptable
     * @return String
     */
    public static String getEntityID(Scriptable scope) {
        Scriptable rgObjs = getRGObjs(scope);
        if (rgObjs != null && rgObjs.has("entityID", rgObjs)) {
            return (String) rgObjs.get("entityID", rgObjs);
        }
        return null;
    }

}
