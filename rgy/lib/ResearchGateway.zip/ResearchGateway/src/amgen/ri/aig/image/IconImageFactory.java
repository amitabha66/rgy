/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.image;

import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.css.CSSImageRetriever;
import amgen.ri.util.ExtImage;
import java.awt.image.BufferedImage;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author jemcdowe
 */
public class IconImageFactory extends AIGServlet {
  enum IconType {
    LIST, SCALE, UNKNOWN;

    public static IconType fromString(String s) {
      try {
        return IconType.valueOf(s.toUpperCase());
      } catch (Exception e) {
        return UNKNOWN;
      }
    }
  };
  public final String LIST_BASE_IMG = "img/default_entitylist.gif";
  //public final String TEST_BASE_DIR = "C:/Development/JProjects2/ResearchGateway/WebContent/";

  public IconImageFactory(AIGServlet aigServlet) {
    super(aigServlet);
  }

  public IconImageFactory(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  public IconImageFactory() {
  }

  @Override
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new IconImageFactory(req, resp);
  }

  @Override
  protected void performRequest() throws Exception {
    try {
      IconType iconType = IconType.fromString(getParameter("type"));
      CSSImageRetriever cssImageRetriever = CSSImageRetriever.getInstance();
      EntityListCategory category = EntityListCategory.fromString(getParameter("category"));
      ImageBadger badger = null;

      if (iconType.equals(IconType.UNKNOWN) && doesParameterExist("img")) {
        iconType = IconType.SCALE;
      }

      switch (iconType) {
        case LIST:
          badger = new ImageBadger(cssImageRetriever.getBackgroundImageforRule("list_base"), cssImageRetriever.getBackgroundImageForType(category));
          badger.badge(ImageBadger.BadgeLocation.UPPER_LEFT, response.getOutputStream());
          break;
        case SCALE:
          URL imageURL = cssImageRetriever.getBackgroundImageforRule(getParameter("img"));
          if (imageURL == null) {
            throw new IllegalArgumentException("Unable to find image");
          }
          int width = getParameterNumber("width", 16).intValue();
          int height = getParameterNumber("height", width).intValue();
          try {
            BufferedImage parentImg = ImageIO.read(imageURL.openStream());
            BufferedImage scaledImage = ExtImage.scale(parentImg, width, height, 0);
            ImageIO.write(scaledImage, "png", response.getOutputStream());
          } catch (Exception e) {
            e.printStackTrace();
          }
          break;
        default:
          URL badgeURL = (category.equals(EntityListCategory.UNKNOWN) ? cssImageRetriever.getBackgroundImageforRule(getParameter("badge"))
                  : cssImageRetriever.getBackgroundImageForType(category));
          if (badgeURL == null) {
            throw new IllegalArgumentException("Unable to find badge image for "+getParameter("badge"));
          }
          URL baseURL = cssImageRetriever.getBackgroundImageforRule(getParameter("base"));
          if (baseURL == null) {
            throw new IllegalArgumentException("Unable to find base image for "+getParameter("base"));
          }
          badger = new ImageBadger(baseURL, badgeURL);
          badger.badge(ImageBadger.BadgeLocation.fromString(getParameter("location")), response.getOutputStream());
          break;
      }
    } catch (Exception e) {
      response.sendError(HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
    }
  }

  @Override
  protected String getServletMimeType() {
    return "image/png";
  }
  
}
