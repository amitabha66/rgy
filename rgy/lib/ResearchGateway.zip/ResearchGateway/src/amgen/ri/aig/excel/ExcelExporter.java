package amgen.ri.aig.excel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.Transparency;
import java.awt.font.FontRenderContext;
import java.awt.font.TextAttribute;
import java.awt.font.TextLayout;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.text.AttributedString;
import java.util.Iterator;

import javax.imageio.ImageIO;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Picture;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import sun.awt.image.BufferedImageGraphicsConfig;
import amgen.ri.util.ExtImage;
import amgen.ri.util.ExtString;
import java.io.FileOutputStream;
import org.apache.commons.io.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFDrawing;

/**
 * Base class for Excel Exporting classes
 *
 * @version $Id: ExcelExporter.java,v 1.3 2014/10/02 22:55:22 jemcdowe Exp $
 */
public abstract class ExcelExporter {

    public static final char DEFAULT_CHAR = '0';
    public static final int UNIT_OFFSET_LENGTH = 7;
    public static final int[] UNIT_OFFSET_MAP = new int[] {0, 36, 73, 109, 146, 182, 219};

    private Workbook wb;

    int defaultCharPixelWidth = -1;
    int defaultCharPixelHeight = -1;
    int defaultFontPointHeight = -1;

    public ExcelExporter() {
    }

    public Workbook createHSSFWorkbook() {
        return (wb = new HSSFWorkbook());
    }

    public Workbook createXSSFWorkbook() {
        return (wb = new XSSFWorkbook());
    }

    public Workbook getCurrentWorkbook() {
        return wb;
    }

    public int getDefaultCharacterPixelWidth() {
        if (defaultCharPixelWidth == -1) {
            AttributedString str;
            TextLayout layout;
            FontRenderContext frc = new FontRenderContext(null, true, true);
            Font defaultFont = wb.getFontAt((short) 0);
            str = new AttributedString("" + DEFAULT_CHAR);
            str.addAttribute(TextAttribute.FAMILY, defaultFont.getFontName(), 0, 1);
            str.addAttribute(TextAttribute.SIZE, new Float(defaultFont.getFontHeightInPoints()));
            if (defaultFont.getBoldweight() == Font.BOLDWEIGHT_BOLD) {
                str.addAttribute(TextAttribute.WEIGHT, TextAttribute.WEIGHT_BOLD, 0, 1);
            }
            if (defaultFont.getItalic()) {
                str.addAttribute(TextAttribute.POSTURE, TextAttribute.POSTURE_OBLIQUE, 0, 1);
            }
            if (defaultFont.getUnderline() == Font.U_SINGLE) {
                str.addAttribute(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON, 0, 1);
            }
            layout = new TextLayout(str.getIterator(), frc);
            defaultFontPointHeight = defaultFont.getFontHeightInPoints();
            defaultCharPixelWidth = (int) layout.getAdvance();
            defaultCharPixelHeight = (int) (layout.getAscent() + layout.getDescent());
        }
        return defaultCharPixelWidth;
    }

    public int getDefaultCharacterPixelHeight() {
        if (defaultCharPixelHeight == -1) {
            getDefaultCharacterPixelWidth();
        }
        return defaultCharPixelHeight;
    }

    public int getDefaultCharacterPointHeight() {
        if (defaultFontPointHeight == -1) {
            getDefaultCharacterPixelWidth();
        }
        return defaultFontPointHeight;
    }

    /**
     * Sets the given column width using pixels.
     * Note since Excel uses character widths, this gets converted using the
     * default font.
     *
     * @param sheet Sheet
     * @param columnIndex int
     * @param pixels double
     */
    public void setColumnWidthInPixels(Sheet sheet, int columnIndex, double pixels) {
        double charWidth = pixels / getDefaultCharacterPixelWidth();
        int colWidth = (int) Math.ceil(charWidth * 256);
        sheet.setColumnWidth(columnIndex, colWidth);
    }

    /**
     * Sets the given cell's column width using pixels.
     * Note since Excel uses character widths, this gets converted using the
     * default font.
     *
     * @param sheet Sheet
     * @param cell Cell
     * @param pixels double
     */
    public void setColumnWidthInPixels(Sheet sheet, Cell cell, double pixels) {
        setColumnWidthInPixels(sheet, cell.getColumnIndex(), pixels);
    }

    /**
     * Sets the given row height using pixels.
     * Note since Excel uses points, this gets converted using the default font.
     *
     * @param row Row
     * @param pixels double
     */
    public void setRowHeightInPixels(Row row, double pixels) {
        double pointHeight = pixels * getDefaultCharacterPointHeight() / getDefaultCharacterPixelHeight();
        row.setHeightInPoints((float) pointHeight);
    }

    /**
     * Sets the given column width using pixels if the current width is less than the width provided.
     * Note since Excel uses character widths, this gets converted using the
     * default font.
     *
     * @param sheet Sheet
     * @param columnIndex int
     * @param pixels double
     */
    public void setMinimumColumnWidthInPixels(Sheet sheet, int columnIndex, double pixels) {
        double charWidth = pixels / getDefaultCharacterPixelWidth();
        int colWidth = (int) Math.ceil(charWidth * 256);
        int currentColWidth= sheet.getColumnWidth(columnIndex);
        if (currentColWidth< colWidth) {
            sheet.setColumnWidth(columnIndex, colWidth);
        }
    }

    /**
     * Sets the given cell's column width using pixels if the current width is less than the width provided.
     * Note since Excel uses character widths, this gets converted using the
     * default font.
     *
     * @param sheet Sheet
     * @param cell Cell
     * @param pixels double
     */
    public void setMinimumColumnWidthInPixels(Sheet sheet, Cell cell, double pixels) {
        setMinimumColumnWidthInPixels(sheet, cell.getColumnIndex(), pixels);
    }

    /**
     * Sets the given row height using pixels if the current height is less than the height provided.
     * Note since Excel uses points, this gets converted using the default font.
     *
     * @param row Row
     * @param pixels double
     */
    public void setMinimumRowHeightInPixels(Row row, double pixels) {
        double pointHeight = pixels * getDefaultCharacterPointHeight() / getDefaultCharacterPixelHeight();
        float rowHeight= (float)pointHeight;
        float currentRowHeight= row.getHeightInPoints();
        if (currentRowHeight< rowHeight) {
            row.setHeightInPoints(rowHeight);
        }
    }


    public void autoSizeAllColumns(Sheet sheet) {
        Row maxCellRow = null;
        Iterator<Row> rowIterator = sheet.rowIterator();
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            if (maxCellRow == null || maxCellRow.getLastCellNum() < row.getLastCellNum()) {
                maxCellRow = row;
            }
        }
        if (maxCellRow != null) {
            Iterator<Cell> cellIterator = maxCellRow.cellIterator();
            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                sheet.autoSizeColumn(cell.getColumnIndex());
            }
        }
    }


    protected void setCellValue(Cell xlDataCell, String value) {
        if (ExtString.hasLength(value)) {
            if (value.length() < 32767) {
                xlDataCell.setCellValue(StringEscapeUtils.unescapeXml(value));
            } else {
                xlDataCell.setCellValue("Data too large.");
            }
        } else {
            xlDataCell.setCellValue("");
        }
    }

    /**
     * setCellImage
     *
     * @param xlDataCell Cell
     * @param wb Workbook
     * @param sheet Sheet
     * @param drawing Drawing
     * @param imageURL String
     */
    public Picture setCellImage(Cell xlDataCell, Workbook wb, Sheet sheet, Drawing drawing, BufferedImage image, Dimension scaleTo) throws IOException {
        BufferedImage outputImage = image;
        if (scaleTo== null) {
            outputImage = ExtImage.scale(image, image.getWidth(), image.getHeight(), 10);
        } else {
            outputImage = ExtImage.scale(image, scaleTo.width, scaleTo.height, 10);
        }

        ByteArrayOutputStream imageBytes = new ByteArrayOutputStream();
        Dimension dimensions = new Dimension(outputImage.getWidth(), outputImage.getHeight());
        ImageIO.write(outputImage, "png", imageBytes);
        
        setMinimumRowHeightInPixels(xlDataCell.getRow(), dimensions.getHeight());
        setMinimumColumnWidthInPixels(sheet, xlDataCell, dimensions.getWidth());
        int pictureIdx = wb.addPicture(imageBytes.toByteArray(), Workbook.PICTURE_TYPE_PNG);
        CreationHelper helper = wb.getCreationHelper();
        //add a picture shape
        ClientAnchor anchor = helper.createClientAnchor();
        anchor.setAnchorType(ClientAnchor.MOVE_AND_RESIZE);
        //set top-left corner of the picture,
        //subsequent call of Picture#resize() will operate relative to it
        anchor.setCol1(xlDataCell.getColumnIndex());
        anchor.setRow1(xlDataCell.getRow().getRowNum());        
        
        //anchor.setCol2(xlDataCell.getColumnIndex()+1);
        //anchor.setRow2(xlDataCell.getRow().getRowNum()+1);        
        Picture pict = drawing.createPicture(anchor, pictureIdx);
        //pict.resize();
        //auto-size picture relative to its top-left corner
        return pict;
    }

    public Dimension drawImage(URL source, OutputStream out) throws IOException {
        BufferedImage img = ImageIO.read(source);
        //BufferedImage finalImg= createCompatibleImage(img);
        BufferedImage compatImg = createCompatibleImage(img);
        ImageIO.write(compatImg, "png", out);
        return new Dimension(compatImg.getWidth(), compatImg.getHeight());
    }

    private BufferedImage createCompatibleImage(BufferedImage image) {
        GraphicsConfiguration gc = BufferedImageGraphicsConfig.getConfig(image);
        int w = image.getWidth();
        int h = image.getHeight();
        BufferedImage result = gc.createCompatibleImage(w + 10, h + 10, Transparency.TRANSLUCENT);
        Graphics2D g2 = result.createGraphics();
        g2.drawImage(image, 5, 5, w, h, Color.WHITE, null);
        g2.dispose();
        return result;
    }
    
}
