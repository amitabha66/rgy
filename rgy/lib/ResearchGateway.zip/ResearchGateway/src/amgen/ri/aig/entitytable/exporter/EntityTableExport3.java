package amgen.ri.aig.entitytable.exporter;

import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import org.apache.poi.POIXMLProperties;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Picture;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jdom.Document;
import org.jdom.Element;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.image.StaffImage;
import amgen.ri.rg.config.ConfigurationParameterInstanceType;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.aig.entitytable.*;
import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;
import amgen.ri.aig.entitytable.subtable.SubDataRow;
import amgen.ri.aig.entitytable.subtable.SubtableDataCell;
import amgen.ri.aig.excel.ExcelExporter;
import amgen.ri.aig.image.StructureImageGenerator;
import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.aig.util.AssaySummaryFormat;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.security.FASFEncrypter;
import amgen.ri.util.ExtObject;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.io.*;
import org.apache.poi.xssf.usermodel.XSSFPicture;

/**
 * Exports an Entity Table to a downloadable document format. For instance, MS
 * Excel
 */
public class EntityTableExport3 extends ExcelExporter {

  public static final int STRUCTURE_BUFFER_SIZE = 500;
  private AIGServlet requestor;
  private AIGSessionLogin sessionLogin;
  private StructureImageGenerator structureImageGenerator;
  private EntityTable entityTable;
  private JSONObject imageSourceConfig;
  private boolean showAssaySummary;
  private Document structureBufferDocument;
  private String chemicalStructureFormat;
  private CellStyle columnGroupHeaderXLStyle;
  private CellStyle columnHeaderXLStyle;
  private CellStyle compoundXLStyle;
  private CellStyle wrappedXLStyle;
  private String fasfUser;

  public EntityTableExport3(EntityTable entityTable, EntityTableHandler requestor) throws AIGException {
    this.entityTable = entityTable;
    this.imageSourceConfig = requestor.getSourceConfigs();
    this.requestor = requestor;
    this.sessionLogin = (AIGSessionLogin) requestor.getSessionLogin();
    try {
      this.fasfUser = ExtString.escape(new FASFEncrypter().encrypt(sessionLogin.getRemoteUser()));
    } catch (Exception ex) {
    }
    //Create the data rows
    this.chemicalStructureFormat = entityTable.getExportOptions().get("Include Chemical Structures");
    this.structureImageGenerator = new StructureImageGenerator(this.requestor);

    String assaySummaryPreference = entityTable.getExportOptions().get("Assay Result Format");
    if (ExtString.equals(assaySummaryPreference, "As Displayed")) {
      this.showAssaySummary = entityTable.getCurrentFormatter().isShowAssaySummary();
    } else if (ExtString.equals(assaySummaryPreference, "Value")) {
      this.showAssaySummary = false;
    } else {
      this.showAssaySummary = true;
    }
  }

  public void exportToExcel() throws IOException, AIGException, JSONException {
    Workbook wb = createExcel();
    String resultName = entityTable.getTableName(true);
    if (resultName == null) {
      resultName = "Export";
    }
    if (wb instanceof HSSFWorkbook) {
      requestor.getHttpServletResponse().setContentType("application/vnd.ms-excel");
      requestor.getHttpServletResponse().addHeader("Content-disposition", "attachment; filename=" + resultName.replaceAll("\\s+", "_") + ".xls");
    } else {
      requestor.getHttpServletResponse().setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
      requestor.getHttpServletResponse().addHeader("Content-disposition", "attachment; filename=" + resultName.replaceAll("\\s+", "_") + ".xlsx");
    }
    OutputStream out = requestor.getHttpServletResponse().getOutputStream();
    wb.write(out);
    out.flush();
  }

  public void exportToSDFile() throws IOException, AIGException, JSONException {
    String EOL = "\r\n";
    String resultName = entityTable.getTableName(true);
    if (resultName == null) {
      resultName = "Export";
    }
    requestor.getHttpServletResponse().setContentType("chemical/x-mdl-sdfile");
    requestor.getHttpServletResponse().addHeader("Content-disposition", "attachment; filename=" + resultName.replaceAll("\\s+", "_") + ".sdf");

    PrintWriter writer = requestor.getHttpServletResponse().getWriter();

    List<DataRow> dataRows = entityTable.getSortedAndFilteredDataRows();

    for (int rowIndex = 0; rowIndex < dataRows.size(); rowIndex++) {
      DataRow dataRow = dataRows.get(rowIndex);
      String mol = null;
      switch (entityTable.getEntityCategory()) {
        case COMPOUNDS:
        case SUBSTANCES:
          if (structureBufferDocument == null) {
            structureBufferDocument = entityTable.getStructureDocument(requestor);
          }
          break;
        default:
          if (rowIndex % STRUCTURE_BUFFER_SIZE == 0) {
            setStructureBufferDocument(dataRows, rowIndex, "xml");
          }
          break;
      }
      Element structureEl = getStructure(dataRow.getEntityID());

      if (structureEl != null && ExtString.hasLength(structureEl.getChildText("MOL"))
              && ExtXMLElement.getXPathElement(structureEl, "./Access[@code=0]") == null) {
        mol = structureEl.getChildText("MOL");
      }
      if (ExtString.hasLength(mol)) {
        writer.print(mol.replaceAll("\\r\\n", "\n").replaceAll("\\n", "\r\n") + EOL);
        writer.print("> <Unique_ID>" + EOL);
        writer.print(dataRow.getEntityID() + EOL);
        writer.print(EOL);

        for (int columnIndex = 0; columnIndex < dataRow.getDataCells().size(); columnIndex++) {
          Column column = entityTable.getColumn(columnIndex);
          String header = column.getHeaderText();
          EntityTableDataType dataType = column.getDataType();
          DataCell dataCell = dataRow.getDataCell(columnIndex);
          if (!(dataCell instanceof SubtableDataCell)) {
            switch (dataType) {
              case DOUBLE:
              case INTEGER:
              case DATE:
              case TEXT:
                writer.print("> <" + header + ">" + EOL);
                writer.print(dataCell.getValue() + EOL);
                writer.print(EOL);
                break;
              case ASSAY_SUMMARY:
                Object dataCellRawValue = dataCell.getRawValue();
                if (dataCellRawValue != null && !dataCellRawValue.equals("null")) {
                  String value = getAssaySummaryValue(dataCellRawValue);
                  writer.print("> <" + header + ">" + EOL);
                  writer.print(value + EOL);
                  writer.print(EOL);
                }
                break;
              default:
                break;
            }
          }
        }
        writer.print("$$$$" + EOL);
      }
    }
    writer.flush();
  }

  /**
   * Creates the Workbook object
   *
   * @return Workbook
   * @throws IOException
   * @throws AIGException
   * @throws JSONException
   */
  public Workbook createExcel() throws IOException, AIGException, JSONException {
    Workbook wb = createXSSFWorkbook();

    //Workbook wb = createXSSFWorkbook();
    if (wb instanceof XSSFWorkbook) {
      POIXMLProperties xlProperties = ((XSSFWorkbook) wb).getProperties();
      POIXMLProperties.CoreProperties xlCoreProperties = xlProperties.getCoreProperties();
      xlCoreProperties.setCategory("RGTableExport:" + entityTable.getEntityCategory());
    } else {
      HSSFWorkbook hssfWb = (HSSFWorkbook) wb;
      hssfWb.createInformationProperties();
      hssfWb.getDocumentSummaryInformation().setCategory("RGTableExport:" + entityTable.getEntityCategory());
    }

    columnGroupHeaderXLStyle = wb.createCellStyle();
    Font columnGroupHeaderXLFont = wb.createFont();
    columnGroupHeaderXLFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
    columnGroupHeaderXLStyle.setFont(columnGroupHeaderXLFont);
    columnGroupHeaderXLStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
    columnGroupHeaderXLStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
    columnGroupHeaderXLStyle.setBorderBottom(CellStyle.BORDER_THIN);
    columnGroupHeaderXLStyle.setBottomBorderColor(IndexedColors.GREY_80_PERCENT.getIndex());
    columnGroupHeaderXLStyle.setBorderLeft(CellStyle.BORDER_THIN);
    columnGroupHeaderXLStyle.setLeftBorderColor(IndexedColors.GREY_80_PERCENT.getIndex());
    columnGroupHeaderXLStyle.setBorderRight(CellStyle.BORDER_THIN);
    columnGroupHeaderXLStyle.setRightBorderColor(IndexedColors.GREY_80_PERCENT.getIndex());
    columnGroupHeaderXLStyle.setBorderTop(CellStyle.BORDER_THIN);
    columnGroupHeaderXLStyle.setTopBorderColor(IndexedColors.GREY_80_PERCENT.getIndex());

    columnHeaderXLStyle = wb.createCellStyle();
    Font columnHeaderXLFont = wb.createFont();
    columnHeaderXLFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
    columnHeaderXLStyle.setFont(columnHeaderXLFont);
    columnHeaderXLStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
    columnHeaderXLStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
    columnHeaderXLStyle.setBorderBottom(CellStyle.BORDER_THIN);
    columnHeaderXLStyle.setBottomBorderColor(IndexedColors.GREY_80_PERCENT.getIndex());
    columnHeaderXLStyle.setBorderLeft(CellStyle.BORDER_THIN);
    columnHeaderXLStyle.setLeftBorderColor(IndexedColors.GREY_80_PERCENT.getIndex());
    columnHeaderXLStyle.setBorderRight(CellStyle.BORDER_THIN);
    columnHeaderXLStyle.setRightBorderColor(IndexedColors.GREY_80_PERCENT.getIndex());
    columnHeaderXLStyle.setBorderTop(CellStyle.BORDER_THIN);
    columnHeaderXLStyle.setTopBorderColor(IndexedColors.GREY_80_PERCENT.getIndex());

    compoundXLStyle = wb.createCellStyle();
    compoundXLStyle.setWrapText(true);

    wrappedXLStyle = wb.createCellStyle();
    wrappedXLStyle.setWrapText(true);

    //Create the worksheet
    Sheet sheet = wb.createSheet(ExtString.truncate(entityTable.getTableName(true), 30, false));
    //Create a DrawingPatriarch for the worksheet
    Drawing drawing = sheet.createDrawingPatriarch();

    //Create the Column Group Header Row
    Row columnGroupHeaderXLRow = sheet.createRow(0);
    //Create the Column Header Row
    Row columnHeaderXLRow = sheet.createRow(1);

    //Setup the column headers
    JSONObject tableConfig = entityTable.getEntityTableJSON(true);

    List<JSONObject> jColumnGroups = tableConfig.getJSONArray("columngroups").asList();
    List<String> etFieldDataIndexes = tableConfig.getJSONArray("fields").asList();
    List<ExcelColumn> excelColumns = new ArrayList<ExcelColumn>();

    for (JSONObject jColumnGroup : jColumnGroups) {
      boolean groupDisplayed = false;
      List<JSONObject> jColumns = jColumnGroup.getJSONArray("columns").asList();

      for (JSONObject jColumn : jColumns) {
        EntityTableDataType dataType = EntityTableDataType.fromString(jColumn.optString("type", "unknown"));
        boolean hidden = jColumn.getBoolean("hidden");
        //If the type is STRUCTURE and chemicalStructureFormat is None, set as hidden
        if (dataType.equals(EntityTableDataType.STRUCTURE) && chemicalStructureFormat.equals("None")) {
          hidden = true;
        }
        if (!hidden) {
          groupDisplayed = true;
        }
      }
      if (groupDisplayed) {
        int startColumn = (excelColumns.isEmpty() ? 0 : excelColumns.get(excelColumns.size() - 1).getColumnIndex() + 1);
        Cell columnGroupHeaderXLCell = columnGroupHeaderXLRow.createCell(startColumn);
        columnGroupHeaderXLCell.setCellStyle(columnGroupHeaderXLStyle);
        columnGroupHeaderXLCell.setCellValue(jColumnGroup.getString("header"));
        for (JSONObject jColumn : jColumns) {
          EntityTableDataType dataType = EntityTableDataType.fromString(jColumn.optString("type", "unknown"));
          boolean hidden = jColumn.getBoolean("hidden");

          //If the type is STRUCTURE and chemicalStructureFormat is None, set as hidden
          if (dataType.equals(EntityTableDataType.STRUCTURE) && chemicalStructureFormat.equals("None")) {
            hidden = true;
          }

          if (!hidden) {
            int colIndex = (excelColumns.isEmpty() ? 0 : excelColumns.get(excelColumns.size() - 1).getColumnIndex() + 1);
            Cell columnHeaderXLCell = columnHeaderXLRow.createCell(colIndex);
            columnHeaderXLCell.setCellStyle(columnHeaderXLStyle);
            columnHeaderXLCell.setCellValue(jColumn.getString("header"));
            excelColumns.add(new ExcelColumn(jColumn, columnHeaderXLCell));
          }
        }
        int colIndex = (excelColumns.isEmpty() ? 0 : excelColumns.get(excelColumns.size() - 1).getColumnIndex() + 1);
        CellRangeAddress columnGroupHeaderXLRange = new CellRangeAddress(0, 0, startColumn, colIndex - 1);
        sheet.addMergedRegion(columnGroupHeaderXLRange);
      }
    }

    //Loop through the data rows
    List<DataRow> dataRows = entityTable.getSortedAndFilteredDataRows();
    int rowCounter = 2;
    for (int rowIndex = 0; rowIndex < dataRows.size(); rowIndex++) {
      DataRow dataRow = dataRows.get(rowIndex);
      Map<String, DataCell> dataCells = dataRow.getDataCellByDataIndexMap(etFieldDataIndexes);
      Row xlRow = sheet.createRow(rowCounter++);
      for (ExcelColumn excelColumn : excelColumns) {
        String dataIndex = excelColumn.getDataIndex();
        int colIndx = excelColumn.getColumnIndex();
        DataCell dataCell = dataCells.get(dataIndex);
        Object value = dataCell.getRawValue();
        EntityTableDataType dataType = excelColumn.dataType;
        switch (dataType) {
          case DOUBLE:
          case INTEGER:
            addNumericCell(xlRow, excelColumn, dataCell);
            break;
          case DATE:
            addDateCell(xlRow, excelColumn, dataCell);
            break;
          case ASSAY_SUMMARY:
            addAssaySummaryCell(xlRow, excelColumn, dataCell);
            break;
          case IMAGE:
            addImageCell(wb, sheet, xlRow, drawing, excelColumn, dataCell);
            break;
          case STRUCTURE:
            addStructureCell(wb, sheet, xlRow, drawing, excelColumn, dataRows, rowIndex);
            break;
          case PERSON:
            addPersonImageCell(wb, sheet, xlRow, drawing, excelColumn, dataRows, rowIndex);
            break;
          case UNSPECIFIED:
          case TEXT:
            addTextCell(xlRow, excelColumn, dataCell);
            break;
        }

      }
    }
    setWorksheetHeights(wb, sheet, excelColumns);
    return wb;
  }

  private boolean addNumericCell(Row row, ExcelColumn column, DataCell dataCell) {
    if (dataCell == null) {
      return false;
    }
    if (dataCell instanceof SubtableDataCell) {
      SubtableDataCell subtableDataCell = (SubtableDataCell) dataCell;
      String subtableDataCellData = getSubtableCellData(column, subtableDataCell);
      Cell cell = addCell(row, column, subtableDataCellData);
      return (cell != null);
    } else {
      Object value = dataCell.getRawValue();
      if (value == null || value.equals("null")) {
        return false;
      }
      Cell cell = addCell(row, column, value);
      return (cell != null);
    }
  }

  private boolean addDateCell(Row row, ExcelColumn column, DataCell dataCell) {
    if (dataCell == null) {
      return false;
    }
    int colIndx = column.getColumnIndex();
    if (dataCell instanceof SubtableDataCell) {
      SubtableDataCell subtableDataCell = (SubtableDataCell) dataCell;
      String subtableDataCellData = getSubtableCellData(column, subtableDataCell);
      Cell cell = addCell(row, column, subtableDataCellData);
      return (cell != null);
    } else {
      Object value = dataCell.getRawValue();
      if (value == null || value.equals("null")) {
        return false;
      }
      Date d = ExtObject.toDate(value);
      if (d == null) {
        Cell cell = addCell(row, column, value);
        return (cell != null);
      }
      Cell cell = getCell(row, colIndx);
      cell.setCellValue(d);
      return true;
    }
  }

  private boolean addAssaySummaryCell(Row row, ExcelColumn column, DataCell dataCell) {
    if (dataCell == null) {
      return false;
    }
    int colIndx = column.getColumnIndex();
    if (dataCell instanceof SubtableDataCell) {
      SubtableDataCell subtableDataCell = (SubtableDataCell) dataCell;
      String subtableDataCellData = getSubtableCellData(column, subtableDataCell);
      Cell cell = addCell(row, column, subtableDataCellData);
      return (cell != null);
    } else {
      Object value = dataCell.getRawValue();
      if (value == null || value.equals("null")) {
        return false;
      }
      String displayValue = getAssaySummaryValue(value);
      Cell cell = addCell(row, column, displayValue);
      return (cell != null);
    }
  }

  private boolean addImageCell(Workbook wb, Sheet sheet, Row row, Drawing drawing, ExcelColumn column, DataCell dataCell) {
    if (dataCell == null) {
      return false;
    }
    int colIndx = column.getColumnIndex();
    if (dataCell instanceof SubtableDataCell) {
      SubtableDataCell subtableDataCell = (SubtableDataCell) dataCell;
      String subtableDataCellData = getSubtableCellData(column, subtableDataCell);
      Cell cell = addCell(row, column, subtableDataCellData);
      return (cell != null);
    } else {
      BufferedImage image = entityTable.getCellImage(column.getDataIndex(), dataCell, false, null);
      if (image != null) {
        try {
          Picture pict = setCellImage(getCell(row, colIndx), wb, sheet, drawing, image, new Dimension(150, 150));
//column.setImageDimensionsForRow(row, new Dimension(image.getWidth(), image.getHeight()));
          column.setImageDimensionsForRow(row, pict);
          return true;
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
      Object value = dataCell.getRawValue();
      Cell cell = addCell(row, column, value);
      return (cell != null);
    }
  }

  private void addStructureCell(Workbook wb, Sheet sheet, Row xlRow, Drawing drawing, ExcelColumn excelColumn, List<DataRow> dataRows, int rowIndex) throws IOException {
    String mol = null;
    switch (entityTable.getEntityCategory()) {
      case COMPOUNDS:
      case SUBSTANCES:
        if (structureBufferDocument == null) {
          structureBufferDocument = entityTable.getStructureDocument(requestor);
        }
        break;
      default:
        if (rowIndex % STRUCTURE_BUFFER_SIZE == 0) {
          setStructureBufferDocument(dataRows, rowIndex, "xml");
        }
        break;
    }
    int colIndx = excelColumn.getColumnIndex();
    Cell cell = getCell(xlRow, colIndx);
    Element structureEl = getStructure(dataRows.get(rowIndex).getEntityID());

    if (structureEl == null || !ExtString.hasLength(structureEl.getChildText("MOL"))) {
      cell.setCellValue("Structure Unavailable");
      cell.setCellStyle(compoundXLStyle);
      return;
    } else if (ExtXMLElement.getXPathElement(structureEl, "./Access[@code=0]") != null) {
      cell.setCellValue("Structure Restricted");
      cell.setCellStyle(compoundXLStyle);
      return;
    }

    if (chemicalStructureFormat.equals("Image")) {
      BufferedImage image = structureImageGenerator.createImageFromMolFile(structureEl.getChildText("MOL"),
              entityTable.getRowHeightPixels(), entityTable.getRowHeightPixels());
      Picture pict = setCellImage(cell, wb, sheet, drawing, image, null);
      excelColumn.setImageDimensionsForRow(xlRow, pict);
    } else {
      String molFile = structureEl.getChildText("MOL");
      molFile = molFile.replaceFirst(".*\\n", dataRows.get(rowIndex).getEntityID() + "\n");
      cell.setCellValue(molFile);
      cell.setCellStyle(compoundXLStyle);
    }
  }

  private boolean addPersonImageCell(Workbook wb, Sheet sheet, Row row, Drawing drawing, ExcelColumn column, List<DataRow> dataRows, int dataRowIndex) throws IOException, JSONException {
    int colIndx = column.getColumnIndex();
    String entityID = dataRows.get(dataRowIndex).getEntityID();
    String source = column.getSource("person");
    String url = this.imageSourceConfig.getJSONObject(source).getString("url");
    url = url.replace("[login]", ExtString.escape(entityID));

    try {
      BufferedImage image = ImageIO.read(new URL(new StaffImage().getStaffImageURL(requestor, entityID, null, null)));
      Picture pict = setCellImage(getCell(row, colIndx), wb, sheet, drawing, image, new Dimension(entityTable.getRowHeightPixels(), entityTable.getRowHeightPixels()));
      column.setImageDimensionsForRow(row, pict);
    } catch (SQLException ex) {
      ex.printStackTrace();
    }
    return true;
  }

  private boolean addTextCell(Row row, ExcelColumn column, DataCell dataCell) {
    if (dataCell == null) {
      return false;
    }
    int colIndx = column.getColumnIndex();
    if (dataCell instanceof SubtableDataCell) {
      SubtableDataCell subtableDataCell = (SubtableDataCell) dataCell;
      String subtableDataCellData = getSubtableCellData(column, subtableDataCell);
      Cell cell = addCell(row, column, subtableDataCellData);
      return (cell != null);
    } else {
      Object value = dataCell.getRawValue();
      Cell cell = addCell(row, column, value);
      return (cell != null);
    }
  }

  private Cell addCell(Row row, ExcelColumn column, Object data) {
    if (data == null) {
      return null;
    }
    int colIndx = column.getColumnIndex();
    Cell cell = getCell(row, colIndx);
    if (isNumber(data.toString())) {
      double value = ExtObject.toDouble(data);
      if (!Double.isNaN(value)) {
        cell.setCellValue(value);
      }
      return cell;
    }
    String value = data.toString();
    String[] lines = value.split("[\\r\\n]+");
    if (lines.length > 1) {
      cell.setCellStyle(wrappedXLStyle);
      column.setLineHeightForRow(row, lines.length + 1);
    }

    cell.setCellValue(value);
    return cell;
  }

  /**
   * Processes an Assay Summary value to show either the full VNT or just the
   * value. Returns the processed value.
   *
   * @param value String
   * @return String
   */
  private String getAssaySummaryValue(Object value) {
    if (value == null) {
      return null;
    }
    String processedValue = null;
    if (!showAssaySummary) {
      AssaySummaryFormat assaySummaryFormat = new AssaySummaryFormat(value + "");
      if (!Double.isNaN(assaySummaryFormat.getValue())) {
        processedValue = assaySummaryFormat.getValue() + "";
      } else if (ExtString.hasLength(assaySummaryFormat.getModifiedValues())) {
        processedValue = assaySummaryFormat.getModifiedValues();
      }
    } else {
      processedValue = value + "";
    }
    return processedValue;
  }

  private String getSubtableCellData(ExcelColumn column, SubtableDataCell dataCell) {
    StringBuffer displayValue = new StringBuffer();
    for (SubDataRow row : dataCell.getRows()) {
      DataCell cell = row.getDataCell(0);
      if (displayValue.length() > 0) {
        displayValue.append("\n");
      }
      String value = cell.getRawValue() + "";
      if (column.dataType.equals(EntityTableDataType.ASSAY_SUMMARY)) {
        value = getAssaySummaryValue(cell.getRawValue());
      }
      if (value == null || value.equals("null")) {
        displayValue.append("-");
      } else {
        displayValue.append(value);
      }
    }
    return displayValue.toString();
  }

  private Cell getCell(Row row, int colIndx) {
    Cell cell = row.getCell(colIndx);
    if (cell == null) {
      cell = row.createCell(colIndx);
    }
    return cell;
  }

  /**
   * cacheStructures
   *
   * @param cacheCompoundIDs List
   */
  private void setStructureBufferDocument(List<DataRow> dataRows, int startIndex, String format) throws IOException {
    List<String> cacheStructureIDs = new ArrayList<String>(STRUCTURE_BUFFER_SIZE);
    int endIndex = startIndex + STRUCTURE_BUFFER_SIZE;

    for (int i = startIndex; i < endIndex; i++) {
      if (i < dataRows.size()) {
        DataRow row = dataRows.get(i);
        cacheStructureIDs.add(row.getEntityID());
      }
    }
    ConfigurationParameterInstanceType version = ConfigurationParameterSource.getRGVersion();

    String smscBaseURL = ConfigurationParameterSource.getConfigParameter("SMSC_BASE_URL");
    String smscURL = smscBaseURL + "/cache.go";
    Map<String, String> params = new HashMap<String, String>();
    switch (entityTable.getEntityCategory()) {
      case COMPOUNDS:
      case SUBSTANCES:
        params.put("db", "acrf");
        break;
      case SMR_MOLECULES:
      case SMR_STRUCTURES:
        switch (version) {
          case DEV:
            params.put("db", "smrdev");
            break;
          case TEST:
            params.put("db", "smrtest");
            break;
          case PROD:
            params.put("db", "smr");
            break;
        }
        break;
    }
    switch (entityTable.getEntityCategory()) {
      case COMPOUNDS:
      case SUBSTANCES:
        params.put("id", ExtString.join(cacheStructureIDs, ","));
        break;
      case SMR_MOLECULES:
        params.put("molecule_id", ExtString.join(cacheStructureIDs, ","));
        break;
      case SMR_STRUCTURES:
        params.put("structure_id", ExtString.join(cacheStructureIDs, ","));
        break;
    }
    params.put("format", format);
    params.put("direct", "1");
    params.put("FASF_IDENTITY", sessionLogin.getCypherUser());
    structureBufferDocument = ExtXMLElement.toDocument(smscURL, params);
  }

  /**
   * cacheStructures
   *
   * @param cacheCompoundIDs List
   */
  private Element getStructure(String structureID) throws IOException {
    if (structureBufferDocument != null) {
      String structureXPath = "/Structures/Structure[ID='" + structureID + "']";
      if (ExtString.isAInteger(structureID)) {
        structureXPath = "/Structures/Structure[ID=" + ((int) ExtString.toDouble(structureID)) + "]";
      } else if (ExtString.isANumber(structureID)) {
        structureXPath = "/Structures/Structure[ID=" + structureID + "]";
      }
      Element structureEl = ExtXMLElement.getXPathElement(structureBufferDocument, structureXPath);
      if (ExtXMLElement.getXPathElement(structureEl, "./Access[@code=0]") != null) {
        return null; // "Structure Restricted";
      }
      return structureEl;
    }
    return null;
  }

  private void setWorksheetHeights(Workbook wb, Sheet sheet, List<ExcelColumn> excelColumns) {
    for (ExcelColumn excelColumn : excelColumns) {
      if (!excelColumn.hasImage()) {
        sheet.autoSizeColumn(excelColumn.getColumnIndex());
      } else {
        sheet.setColumnWidth(excelColumn.getColumnIndex(), 32*256);        
      }
    }
    for (ExcelColumn excelColumn : excelColumns) {
      if (excelColumn.hasImage()) {
        for (Picture pict : excelColumn.imageDimensions.values()) {
          pict.resize();
        }
      }
    }
  }

  public EntityTable getEntityTable() {
    return entityTable;
  }

  /**
   * Returns whether the given export preference equals the given value
   *
   * @param preference String
   * @param value String
   * @return boolean
   */
  public boolean doesExportOptionsEqual(String preference, String value) {
    if (getEntityTable().getExportOptions() == null) {
      return false;
    }
    if (!getEntityTable().getExportOptions().containsKey(preference)) {
      return false;
    }
    return getEntityTable().getExportOptions().get(preference).equalsIgnoreCase(value);
  }

  public boolean isNumber(String s) {
    return s.matches("^[-+]?[0-9]*\\.?[0-9]+(?:[eE][-+]?[0-9]+)?$");

  }
}

class ExcelColumn {

  public JSONObject etColumn;
  public Cell headerCell;
  public EntityTableDataType dataType;
  private boolean hasImage;
  private Map<Integer, Integer> lineHeights;
  public Map<Integer, Picture> imageDimensions;

  public ExcelColumn(JSONObject etColumn, Cell headerCell) {
    this.etColumn = etColumn;
    this.headerCell = headerCell;
    this.hasImage = false;
    this.dataType = EntityTableDataType.fromString(etColumn.optString("type", "unknown"));
    this.lineHeights = new HashMap<Integer, Integer>();
    this.imageDimensions = new HashMap<Integer, Picture>();
  }

  public String getSource(String sourceName) {
    try {
      return etColumn.getJSONObject("source").getJSONObject(sourceName).getString("imgsource_id");
    } catch (JSONException ex) {
      return null;
    }

  }

  public void setLineHeightForRow(Row row, int lineHeight) {
    lineHeights.put(row.getRowNum(), lineHeight);
  }

  public Map<Integer, Integer> getLineHeights() {
    return lineHeights;
  }

  /**
   * getImageDimensions
   *
   */
  public boolean hasImage() {
    return hasImage;
  }

  /**
   * setImageDimensions
   *
   * @param dimension Dimension
   */
  public void setImageDimensionsForRow(Row row, Picture rowPicture) {
    imageDimensions.put(row.getRowNum(), rowPicture);
    hasImage = (rowPicture != null);
  }

  /**
   * getDataIndex
   *
   * @return String
   */
  public String getDataIndex() {
    try {
      return etColumn.getString("dataIndex");
    } catch (JSONException ex) {
    }
    return "";
  }

  /**
   * getColumnIndex
   *
   * @return int
   */
  public int getColumnIndex() {
    return headerCell.getColumnIndex();
  }
}
