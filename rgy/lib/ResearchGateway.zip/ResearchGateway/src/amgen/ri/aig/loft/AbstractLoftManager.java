/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.loft;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.jsonquery.JSONProcQuery;
import amgen.ri.aig.record.AppRecord;
import amgen.ri.aig.sql.RGSQLProvider;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.ExtOracle;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.servlet.SessionLogin;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OracleCallableStatement;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

/**
 *
 * @author jemcdowe
 */
public abstract class AbstractLoftManager {
  private SessionLogin sessionLogin;

  public AbstractLoftManager(SessionLogin sessionLogin) {
    this.sessionLogin = sessionLogin;
  }

  /**
   * @return the requestor
   */
  public SessionLogin getSessionLogin() {
    return sessionLogin;
  }

  public String getRequestUser() {
    return getSessionLogin().getRemoteUser();
  }

  public List<AppRecord> getUserAppRecords() {   
    List<AppRecord> appRecords = new ArrayList<AppRecord>();
    Connection conn = null;
    CallableStatement stmt = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC.toString());
      stmt = conn.prepareCall("BEGIN ? := RG_LOFT.getAllUserApps(?); END;");
      stmt.registerOutParameter(1, Types.BLOB);
      stmt.setString(2, getRequestUser());
      stmt.execute();
      Blob resultBlob = stmt.getBlob(1);
      String json = (String) ExtOracle.readObjectFromBlob(resultBlob, true);
      List<JSONObject> jApps = new JSONArray(json).asList();
      for (JSONObject jApp : jApps) {
        appRecords.add(new AppRecord(jApp));
      }
    } catch (Exception e) {
    } finally {
      OraSQLManager.close(stmt);
      OraSQLManager.close(conn);
    }
    return appRecords;
  }

  public List<AppRecord> getUserAppRecords(int... ids) {
    List<AppRecord> appRecords = new ArrayList<AppRecord>();
    List<AppRecord> allAppRecords = getUserAppRecords();
    for (int id : ids) {
      for (AppRecord appRecord : allAppRecords) {
        if (appRecord.getId() == id) {
          appRecords.add(appRecord);
        }
      }
    }
    return appRecords;
  }

  public List<AppRecord> getUserQuickAppRecords() throws Exception {
    List<AppRecord> appRecords = new ArrayList<AppRecord>();
    Connection conn = null;
    CallableStatement stmt = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC.toString());
      stmt = conn.prepareCall("BEGIN ? := RG_LOFT.getAllUserQuickApps(?); END;");
      stmt.registerOutParameter(1, Types.BLOB);
      stmt.setString(2, getRequestUser());
      stmt.execute();
      Blob resultBlob = stmt.getBlob(1);
      String json = (String) ExtOracle.readObjectFromBlob(resultBlob, true);
      List<JSONObject> jApps = new JSONArray(json).asList();
      for (JSONObject jApp : jApps) {
        appRecords.add(new AppRecord(jApp));
      }
    } finally {
      OraSQLManager.close(stmt);
      OraSQLManager.close(conn);
    }
    return appRecords;
  }

  public List<AppRecord> saveUserQuickAppRecords(JSONObject quickApps) throws Exception {
    if (quickApps == null || !quickApps.has("ids")) {
      return getUserQuickAppRecords();
    }
    JSONArray quickAppIDs = quickApps.getJSONArray("ids");
    List<Integer> quickAppIDSet = new ArrayList<Integer>();
    for (int i = 0; i < quickAppIDs.length(); i++) {
      quickAppIDSet.add(quickAppIDs.getInt(i));
    }
    Connection conn = null;
    CallableStatement stmt = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC.toString());
      ArrayDescriptor descriptor = ArrayDescriptor.createDescriptor("NUM_TABLE_T", conn);
      Integer[] ids = (Integer[]) quickAppIDSet.toArray(new Integer[0]);
      Array quickAppIDArray = new ARRAY(descriptor, conn, ids);
      stmt = conn.prepareCall("BEGIN RG_LOFT.setQuickApps(?, ?); END;");
      stmt.setArray(1, quickAppIDArray);
      stmt.setString(2, getRequestUser());
      stmt.execute();
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.close(stmt);
      OraSQLManager.close(conn);
    }
    return getUserQuickAppRecords();
  }

  public JSONObject removeApp(int appID) throws Exception {
    Connection conn = null;
    CallableStatement stmt = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC.toString());
      stmt = conn.prepareCall("BEGIN RG_LOFT.deleteLoftApp(?, ?); END;");
      stmt.setInt(1, appID);
      stmt.setString(2, getRequestUser());
      stmt.execute();
    } finally {
      OraSQLManager.close(stmt);
      OraSQLManager.close(conn);
    }
    return new JSONObject();
  }


  protected String getAttribute(JSONObject jApp, AppAttributeType attrType) {
    try {
      JSONArray jAttributes = jApp.getJSONArray("attributes");
      for (int i = 0; i < jAttributes.length(); i++) {
        JSONObject jAttribute = jAttributes.getJSONObject(i);
        if (jAttribute.has(attrType + "")) {
          return jAttribute.getString(attrType + "");
        }
      }
    } catch (JSONException ex) {
    }
    return null;
  }

  public synchronized List<AppRecord> resetAppsToDefaults(String role) throws AIGException {
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall("begin RG_LOFT.resetLoftItems(:amgen_login, :rg_app_role); end;");
      cs.setStringAtName("amgen_login", getRequestUser());
      cs.setStringAtName("rg_app_role", role);

      cs.executeUpdate();
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return getUserAppRecords();
  }

  /**
   * Returns the available app roles in the Db
   *
   * @return
   * @throws AIGException
   */
  public JSONObject getAppsRoles() throws AIGException {
    JSONObject jRoles = new JSONObject();
    RGSQLProvider sqlProvider = new RGSQLProvider();
    String sql = sqlProvider.getSQL("get_launchpad_app_roles");

    Connection conn = null;
    try {
      jRoles.put("roles", new JSONArray());
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      PreparedStatement stmt = conn.prepareStatement(sql);
      ResultSet rset = stmt.executeQuery();
      while (rset.next()) {
        JSONObject jRole = new JSONObject();
        jRole.put("role", rset.getString(1));
        jRoles.append("roles", jRole);
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return jRoles;
  }

  public JSONObject getLoftPages() throws AIGException {
    JSONObject jPages = new JSONObject();
    try {
      JSONProcQuery query = new JSONProcQuery();
      List<JSONObject> jPageList = query.executeJSONProcQuery("LP_PAGESBYOWNER", "owner", getRequestUser());
      jPages.put("pages", new JSONArray(jPageList));
    } catch (Exception ex) {
      Logger.getLogger(AbstractLoftManager.class.getName()).log(Level.SEVERE, null, ex);
    }
    return jPages;
  }

  /**
   * for an optional JSONArray member of the jObj JSONObject, returns the
   * JSONArray for the key or an empty JSONArray if the key does not exist
   *
   * @param jObj
   * @param key
   * @return
   */
  protected JSONArray optJSONArray(JSONObject jObj, String key) {
    JSONArray jArr = jObj.optJSONArray(key);
    return (jArr == null ? new JSONArray() : jArr);
  }
}
