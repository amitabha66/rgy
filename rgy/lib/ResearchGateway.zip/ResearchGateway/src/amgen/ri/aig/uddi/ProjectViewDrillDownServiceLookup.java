package amgen.ri.aig.uddi;

import amgen.ri.aig.AIGException;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.asf.sa.uddi.ClassificationSchemeQuery;
import amgen.ri.json.JSONObject;
import org.jdom.Document;
import org.jdom.JDOMException;

/**
 * <p>@version $Id: ProjectViewDrillDownServiceLookup.java,v 1.4 2012/07/13 23:05:48 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class ProjectViewDrillDownServiceLookup extends AbstractDrillDownServiceLookup {
    public ProjectViewDrillDownServiceLookup() {
        super();
    }

    public ProjectViewDrillDownServiceLookup(HttpServletRequest req, HttpServletResponse resp) {
        super(req, resp);
        Map<String, ClassificationSchemeQuery> classificationSchemeQueries = new LinkedHashMap<String, ClassificationSchemeQuery>();
        if (doesParameterExist("aacode", true)) {
            classificationSchemeQueries.put("assay", new ClassificationSchemeQuery(ClassificationSchemeQuery.AND_ALL_KEYS));
            classificationSchemeQueries.get("assay").addKeyValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME,
                    ServiceDataCategory.revertTo(ServiceDataCategory.ASSAY_IDENTIFIER));
            classificationSchemeQueries.get("assay").addKeyValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME,
                    ServiceDataCategory.revertTo(ServiceDataCategory.AMGEN_ROOT_ID));
        }
        classificationSchemeQueries.put("compound", new ClassificationSchemeQuery(ClassificationSchemeQuery.OR_ALL_KEYS));
        classificationSchemeQueries.get("compound").addKeyValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME,
                ServiceDataCategory.revertTo(ServiceDataCategory.AMGEN_ROOT_ID));
        setCategories(classificationSchemeQueries, null);
    }

    /**
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return TBXServlet
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new ProjectViewDrillDownServiceLookup(req, resp);
    }

}
