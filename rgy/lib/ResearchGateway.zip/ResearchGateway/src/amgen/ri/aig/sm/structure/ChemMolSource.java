package amgen.ri.aig.sm.structure;

import java.io.ObjectStreamException;

public enum ChemMolSource {
    ACRF,
            ACRF_COMPOUNDR,
            ACRF_COMPONENT,
            ACRF_LARGEST_COMPONENT,
            COMBICHEM_LIBRARY,
            MDLTOX,
            MDDR,
            GVK,
            SMR,
            ACD,
            ACDSC,
            CMC,
            SMILES,
            MOL,
            IMAGE,
            UNKNOWN;

    public static ChemMolSource fromString(String s) {
        if (s == null) {
            return UNKNOWN;
        }
        try {
            return ChemMolSource.valueOf(s.toUpperCase());
        } catch (Exception e) {
            return UNKNOWN;
        }
    }

    /**
     * This is necessary to permit Serializable.
     * A Serialized object containing an enum class variable is not de-Serialized properly.
     * This forces de-Serialized enum to be re-created as this enum through the String
     * @return Object
     * @throws ObjectStreamException
     */
    public Object readResolve() throws ObjectStreamException {
        return ChemMolSource.fromString(this.toString());
    }


}
