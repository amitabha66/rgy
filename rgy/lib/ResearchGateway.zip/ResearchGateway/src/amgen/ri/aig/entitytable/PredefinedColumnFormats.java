package amgen.ri.aig.entitytable;

import java.util.HashMap;
import java.util.Map;

import amgen.ri.aig.entitytable.ColumnFormat.NotationType;
import amgen.ri.util.ExtString;

/**
 * <p>@version $Id: PredefinedColumnFormats.java,v 1.1 2011/06/17 20:41:19 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class PredefinedColumnFormats {
    Map<String, String> dateFormats;
    public PredefinedColumnFormats() {
        super();
        dateFormats = new HashMap<String, String>();
        dateFormats.put("01/01/2007 3:30:05 PM", "MM/dd/yyyy hh:mm:ss a");
        dateFormats.put("01/01/2007 3:30 PM", "MM/dd/yyyy hh:mm a");
        dateFormats.put("01/01/2007 15:30:05", "MM/dd/yyyy HH:mm:ss");
        dateFormats.put("01/01/2007 15:30", "MM/dd/yyyy HH:mm");
        dateFormats.put("01/01/2007", "MM/dd/yyyy");
        dateFormats.put("Jan 1, 2007 3:30:05 PM", "MMM dd, yyyy hh:mm:ss a");
        dateFormats.put("Jan 1, 2007 3:30 PM", "MMM dd, yyyy hh:mm a");
        dateFormats.put("Jan 1, 2007 15:30:05", "MMM dd, yyyy HH:mm:ss");
        dateFormats.put("Jan 1, 2007 15:30", "MMM dd, yyyy HH:mm");
        dateFormats.put("Jan 1, 2007", "MMM dd, yyyy");
        dateFormats.put("1 Jan 2007 3:30:05 PM", "dd MMM yyyy hh:mm:ss a");
        dateFormats.put("1 Jan 2007 3:30 PM", "dd MMM yyyy hh:mm a");
        dateFormats.put("1 Jan 2007 15:30:05", "dd MMM yyyy HH:mm:ss");
        dateFormats.put("1 Jan 2007 15:30", "dd MMM yyyy HH:mm");
        dateFormats.put("1 Jan 2007", "dd MMM yyyy");
        dateFormats.put("Jan 1 2007 3:30:05 PM", "MMM dd yyyy hh:mm:ss a");
        dateFormats.put("Jan 1 2007 3:30 PM", "MMM dd yyyy hh:mm a");
        dateFormats.put("Jan 1 2007 15:30:05", "MMM dd yyyy HH:mm:ss");
        dateFormats.put("Jan 1 2007 15:30", "MMM dd yyyy HH:mm");
        dateFormats.put("Jan 1 2007", "MMM dd yyyy");
        dateFormats.put("3:30 PM", "hh:mm a");
        dateFormats.put("3:30:05 PM", "hh:mm:ss a");
        dateFormats.put("15:30", "HH:mm");
        dateFormats.put("15:30:05", "HH:mm:ss");
    }


    public String getDateFormat(String key) {
        return dateFormats.get(key);
    }


    /**
     * buildFormat
     *
     * @param formatType FormatType
     * @param i int
     * @param string String
     * @return String
     */
    public String buildDecimalFormat(int decimals, NotationType notation) {
        switch (notation) {
            case SCIENTIFIC:
                if (decimals == 0) {
                    return "0E0";
                }
                return "0" + "." + ExtString.repeat("0", decimals, "") + "E0";
            case ENGINEERING:
                if (decimals == 0) {
                    return "##0E0";
                }
                return "##0" + "." + ExtString.repeat("#", decimals, "") + "E0";
            case PERCENTAGE:
                if (decimals == 0) {
                    return "0%";
                }
                return "0" + "." + ExtString.repeat("0", decimals, "") + "%";
            case STANDARD:
            default:
                if (decimals == 0) {
                    return "0";
                }
                return "0" + "." + ExtString.repeat("0", decimals, "");
        }
    }

}
