package amgen.ri.aig.scripts;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;

import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.customscripts.AssayMethods;
import amgen.ri.aig.customscripts.LigandEfficiencyIndexScripts;
import amgen.ri.aig.customscripts.StandardMethods;
import amgen.ri.xml.ExtXMLElement;


/**
 *
 * XML File based script source
 * @version $Id: XMLSavedScriptMethods.java,v 1.2 2011/06/21 17:28:58 cvs Exp $
 *
 */
public class XMLSavedScriptMethods extends AbstractScripts implements CalculationMethodsIF {
    private Document methodsDocument;

    public XMLSavedScriptMethods(EntityListCategory entityType, File xmlFileDir) throws FileNotFoundException {
        super(entityType, xmlFileDir);
        Element globalObjectsEl = new Element("GlobalObjects");
        Element availableMethodsEl = new Element("AvailableMethods");
        if (xmlFileDir.isDirectory()) {
            File[] scriptFiles = xmlFileDir.listFiles(new FilenameFilter() {
                public boolean accept(File parent, String name) {
                    return (name.endsWith(".xml"));
                }
            });
            for (File scriptFile : scriptFiles) {
                Document scriptDoc = ExtXMLElement.toDocument(scriptFile);
                if (scriptDoc != null) {
                    List<Element> methodGroupsEls = ExtXMLElement.getXPathElements(scriptDoc, "/JSObjects/AvailableMethods/MethodGroup");
                    for (Element methodGroupsEl : methodGroupsEls) {
                        availableMethodsEl.addContent((Element) methodGroupsEl.clone());
                    }
                }
            }
        }
        Element jsObjectsEl = new Element("JSObjects");
        jsObjectsEl.addContent(globalObjectsEl);
        jsObjectsEl.addContent(availableMethodsEl);
        this.methodsDocument = new Document(jsObjectsEl);
    }

    /**
     * Just using this to force JBuilder to see dependencies & include in the war
     * DO NOT REMOVE!!!
     */
    private XMLSavedScriptMethods() {
        super(null, null);
        new AssayMethods();
        new StandardMethods();
        new LigandEfficiencyIndexScripts();
    }

    public Document getMethodDocument() {
        return methodsDocument;
    }

}
