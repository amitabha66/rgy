package amgen.ri.aig.entitylist;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>@version $Id: EntityListRetrievalType.java,v 1.1 2011/06/17 20:41:19 cvs Exp $</p>
 */
public enum EntityListRetrievalType {
    ALL_COMPOUND_LISTS, LISTS;


    public static EntityListRetrievalType fromString(String s) {
        if (s == null) {
            return LISTS;
        }
        try {
            return EntityListRetrievalType.valueOf(s.toUpperCase());
        } catch (Exception e) {
            return LISTS;
        }
    }

    /**
     * valueOf
     *
     * @return EntityListRetrievalType
     */
    public static EntityListRetrievalType valueOf(HttpServletRequest request) {
        return EntityListRetrievalType.fromString(request.getParameter("op"));
    }

}
