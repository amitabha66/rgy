package amgen.ri.aig.sv;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.tree.NodeType;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.entitylist.EntityListFilterIF;
import amgen.ri.aig.entitylist.EntityListIF;
import amgen.ri.aig.entitylist.EntityListMemberIF;
import amgen.ri.aig.entitylist.EntityListSourceServiceIF;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.ServiceParameterException;
import amgen.ri.json.JSONObject;
import amgen.ri.xml.ExtXMLElement;
import java.io.IOException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.wsdl.WSDLException;
import javax.xml.rpc.ServiceException;
import javax.xml.transform.TransformerException;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;

/**
 * Class used to load a list into the cache returning the requested type
 *
 * @author not attributable
 * @version 1.0
 */
public class EntityListLoader extends AIGBase {
  /**
   * Default constructor
   */
  public EntityListLoader() {
    super();
  }

  /**
   * Creates a LoadEntityList
   *
   * @param req HttpServletRequest
   */
  public EntityListLoader(HttpServletRequest req) {
    super(req);
  }

  /**
   * Loads a EntityListIF object into cache and returns the ResultNode
   *
   * @param entityList EntityListIF
   * @throws AIGException
   * @throws ServiceParameterException
   * @throws ServiceException
   * @throws TransformerException
   * @throws IOException
   * @throws JDOMException
   * @throws RemoteException
   * @throws WSDLException
   * @return Element
   */
  public Document loadAsResultNode(EntityListIF entityList, ServiceDetails serviceDetails) throws AIGException, ServiceParameterException, ServiceException, TransformerException, IOException,
          JDOMException, RemoteException, WSDLException {
    return loadAsResultNode(entityList, null, serviceDetails);
  }

  /**
   * Loads a EntityListIF object into cache and returns the ResultNode
   *
   * @param entityList EntityListIF
   * @throws AIGException
   * @throws ServiceParameterException
   * @throws ServiceException
   * @throws TransformerException
   * @throws IOException
   * @throws JDOMException
   * @throws RemoteException
   * @throws WSDLException
   * @return Element
   */
  public Document loadAsResultNode(EntityListIF entityList, EntityListFilterIF entityListFilter, ServiceDetails serviceDetails) throws AIGException, ServiceParameterException, ServiceException, TransformerException, IOException,
          JDOMException, RemoteException, WSDLException {
    ServiceDataCategory listServiceCategory = getEntityClassManager().convertEntityListCategoryToServiceDataCategory(entityList.getEntityCategory());
    if (!listServiceCategory.equals(ServiceDataCategory.UNKNOWN)) {
      Element resultTreeNodesEl = new Element("TREENODES");
      String serviceDataTypeCategory = ServiceDataCategory.revertTo(listServiceCategory);
      List<EntityListMemberIF> listMembers = entityList.getListMembers(new ArrayList<EntityListMemberIF>());
      if (entityListFilter != null) {
        List<EntityListMemberIF> filteredListMembers = new ArrayList<EntityListMemberIF>();
        for (EntityListMemberIF member : listMembers) {
          if (entityListFilter.match(member)) {
            filteredListMembers.add(member);
          }
        }
        listMembers = filteredListMembers;
      }
      if (listMembers.size() > 0) {
        if (listMembers.size() > 10000) {
          listMembers = listMembers.subList(0, 10000);
        }
        Element resultTreeNodeEl = ExtXMLElement.addElement(resultTreeNodesEl, "TREENODE");
        ExtXMLElement.addAttribute(resultTreeNodeEl, "TEXT", entityList.getListName());
        ExtXMLElement.addAttribute(resultTreeNodeEl, "TITLE", entityList.getListDescription());
        if (entityList instanceof EntityTable) {
          EntityTable entityTable = (EntityTable) entityList;
          ExtXMLElement.addAttribute(resultTreeNodeEl, "TABLE_KEY", entityTable.getTableKey());
        }
        for (EntityListMemberIF listMember : listMembers) {
          Element treeNodeEl = ExtXMLElement.addElement(resultTreeNodeEl, "TREENODE");
          ExtXMLElement.addAttribute(treeNodeEl, "TEXT", listMember.getLabel());
          ExtXMLElement.addAttribute(treeNodeEl, "TITLE", listMember.getDescription());
          ExtXMLElement.addAttribute(treeNodeEl, "SERVICE_DATA", listMember.getMember());
          ExtXMLElement.addAttribute(treeNodeEl, "SERVICE_DATA_TYPE_CATEGORY", serviceDataTypeCategory);
          if (listMember.getDefaultViewServiceKey() != null) {
            ExtXMLElement.addAttribute(treeNodeEl, "DEFAULT_VIEW_KEY", listMember.getDefaultViewServiceKey());
            if (listMember.getDefaultViewServiceParameters() != null) {
              ExtXMLElement.addAttribute(treeNodeEl, "DEFAULT_VIEW_PARAMS", (new JSONObject(listMember.getDefaultViewServiceParameters())).toString());
            }
          }
        }
        Element searchResultNode = processTreeNodes(resultTreeNodeEl, null, NodeType.RESULTNODE, listServiceCategory, null, null);
        //Commented out because already cached by processTreeNodes
        //TreeNodeCache.getTreeNodeCache(request).addTreeNode(searchResultNode);
        EntityListSourceServiceIF sourceService = entityList.getSourceService();
        ServiceDetails sourceServiceDetails = (sourceService == null ? null : sourceService.getServiceDetails(ServiceCache.getServiceCache(request)));
        setServiceResultCacheItem(searchResultNode.getAttributeValue("UUID"), sourceServiceDetails, TModelCommonNameFactory.TREENODESXMLDEFINITION_tMODELNAME, new Document(resultTreeNodesEl));
        if (sourceService != null && sourceService.getServiceKey() != null) {
          ExtXMLElement.addAttribute(searchResultNode, "SERVICE_KEY", sourceService.getServiceKey());
        } else if (serviceDetails != null) {
          ExtXMLElement.addAttribute(searchResultNode, "SERVICE_KEY", serviceDetails.getServiceKey());
        }
        return new Document(searchResultNode);
      }
    }
    return new Document(new Element("TREENODES"));
  }
}
