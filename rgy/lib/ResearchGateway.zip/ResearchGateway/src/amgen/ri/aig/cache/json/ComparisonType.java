/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.json;

/**
 *
 * @author jemcdowe
 */
public enum ComparisonType {
  EQ, LT, GT;

  public static ComparisonType fromString(String s) {
    try {
      return ComparisonType.valueOf(s.toUpperCase());
    } catch (Exception e) {
      return ComparisonType.EQ;
    }
  }
};