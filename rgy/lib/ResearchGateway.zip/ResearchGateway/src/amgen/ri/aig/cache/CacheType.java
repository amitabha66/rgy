package amgen.ri.aig.cache;

import java.io.ObjectStreamException;

/**
 * Defines the Cache Type
 *
 * @version $id$
 *
 */
public enum CacheType {

  SERVICE,
  SERVICEQUERY,
  SERVICERESULT,
  ENTITYTABLE,
  NODE,
  NODECHILDREN,
  NODESORT,
  NODEFILTER,
  ASSAY,
  TMODEL,
  BINDING,
  JSON,
  UNKNOWN;

  public static CacheType fromString(String s) {
    if (s == null) {
      return UNKNOWN;
    }
    try {
      return CacheType.valueOf(s.toUpperCase());
    } catch (Exception e) {
      return UNKNOWN;
    }
  }

  /**
   * This is necessary to permit Serializable. A Serialized object containing an
   * enum class variable is not de-Serialized properly. This forces
   * de-Serialized enum to be re-created as this enum through the String
   *
   * @return Object
   * @throws ObjectStreamException
   */
  public Object readResolve() throws ObjectStreamException {
    return CacheType.fromString(this.toString());
  }

}
