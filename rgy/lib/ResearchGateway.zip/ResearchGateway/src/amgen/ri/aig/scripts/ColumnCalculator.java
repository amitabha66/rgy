package amgen.ri.aig.scripts;

import java.lang.reflect.InvocationTargetException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.RhinoException;
import org.mozilla.javascript.Scriptable;

import amgen.ri.aig.entitytable.Column;
import amgen.ri.aig.entitytable.DataCell;
import amgen.ri.aig.entitytable.DataRow;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;
import amgen.ri.util.ExtString;

/**
 * <p>@version $Id: ColumnCalculator.java,v 1.3 2011/06/22 23:05:15 cvs Exp $</p>
 *
 */
public class ColumnCalculator {
    private ScriptMainFunction mainScript;
    private CalculationScriptsIF availableScriptMethods;
    private boolean simple;
    private String scriptVariableName = "rgColumnReferenceVariable";
    private int scriptVariableCounter = 0;


    public ColumnCalculator(EntityTable entityTable, CalculationScriptsIF availableScriptMethods,
                            String javascriptSource, CalculationType calculationType) throws
            IllegalAccessException, InstantiationException, InvocationTargetException, RhinoException {
        this.availableScriptMethods = availableScriptMethods;
        this.simple = simple;
        switch (calculationType) {
            case FUNCTION:
            case EXPRESSION:
                this.mainScript = processExpressionScript(javascriptSource, entityTable);
                break;
            case ADVANCED:
                this.mainScript = processAdvancedScript(javascriptSource, entityTable);
                break;
            default:
                throw new IllegalArgumentException("Unknown script type");
        }
        evaluate();
    }

    /**
     * Processes the given script Expression source returning a ScriptMainFunction object. This is used as the entry stub in the script call.
     *
     * @param javascriptSource String
     * @return String
     */
    private ScriptMainFunction processExpressionScript(String javascriptSource, EntityTable entityTable) {
        String mainFunction = createScriptVariable();
        String processedJS = javascriptSource;
        LinkedHashMap<String, String> dependentColumnData = new LinkedHashMap();
        for (Column column : entityTable.getColumns()) {
            if (javascriptSource.contains("<" + column.getDataIndex() + ">")) {
                String varName = createScriptVariable();
                processedJS = processedJS.replaceAll("<" + column.getDataIndex() + ">", varName);
                dependentColumnData.put(varName, column.getDataIndex());
            }
        }
        StringBuffer processedJSFunction = new StringBuffer();
        processedJSFunction.append("function " + mainFunction + " (");
        if (dependentColumnData.size() > 0) {
            processedJSFunction.append(ExtString.join(dependentColumnData.keySet(), ","));
        }
        processedJSFunction.append(") {");
        processedJSFunction.append("return " + processedJS);
        processedJSFunction.append("}");

        return new ScriptMainFunction(mainFunction, dependentColumnData, processedJSFunction.toString());
    }

    /**
     * Processes the given script Advanced source returning a ScriptMainFunction object. This is used as the entry stub in the script call.
     *
     * @param javascriptSource String
     * @return String
     */
    private ScriptMainFunction processAdvancedScript(String javascriptSource, EntityTable entityTable) {
        String mainFunction = createScriptVariable();
        String processedJS = javascriptSource;
        LinkedHashMap<String, String> dependentColumnData = new LinkedHashMap();
        for (Column column : entityTable.getColumns()) {
            if (javascriptSource.contains("<" + column.getDataIndex() + ">")) {
                String varName = createScriptVariable();
                processedJS = processedJS.replaceAll("<" + column.getDataIndex() + ">", varName);
                dependentColumnData.put(varName, column.getDataIndex());
            }
        }
        StringBuffer processedJSFunction = new StringBuffer();
        processedJSFunction.append("function " + mainFunction + " (");
        if (dependentColumnData.size() > 0) {
            processedJSFunction.append(ExtString.join(dependentColumnData.keySet(), ","));
        }
        processedJSFunction.append(") {");
        processedJSFunction.append(processedJS);
        processedJSFunction.append("}");

        return new ScriptMainFunction(mainFunction, dependentColumnData, processedJSFunction.toString());

    }

    /**
     * Does an Evaluate of the complete script to identify any syntax errors
     *
     * @throws RhinoException
     * @throws InvocationTargetException
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public void evaluate() throws RhinoException, InvocationTargetException, InstantiationException, IllegalAccessException {
        Context cx = Context.enter();
        try {
            Scriptable scope = cx.initStandardObjects();
            if (availableScriptMethods != null) {
                availableScriptMethods.addScripts(cx, scope);
            }
            cx.evaluateString(scope, mainScript.getJsSource(), "Input ", 1, null);
        } finally {
            cx.exit();
        }
    }

    /**
     * Performs a quick test of the complete script on the first 10 rows of the table to identify any major calculation errors
     *
     * @param entityTable EntityTable
     * @return EntityTableDataType
     * @throws InvocationTargetException
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public EntityTableDataType testScript(EntityTable entityTable) throws InvocationTargetException, InstantiationException, IllegalAccessException {
        EntityTableDataType dataTypeGuess = EntityTableDataType.TEXT;

        if (entityTable.getDataRows().size() <= 0) {
            return dataTypeGuess;
        }
        Scriptable mainScope = buildMainScope(entityTable);
        int testCounter = 0;

        for (DataRow dataRow : entityTable.getDataRows()) {
            EntityTableDataType returnedDataType = new ColumnCalculatorThread(mainScope, mainScript, entityTable, dataRow, null, null).runScript();
            if (!returnedDataType.equals(EntityTableDataType.TEXT)) {
                dataTypeGuess = returnedDataType;
            }
            if (testCounter++ >= 10) {
                break;
            }
        }
        return dataTypeGuess;
    }

    /**
     * Calculates a script for a new column
     *
     * @param entityTable EntityTable
     * @param newTargetColumnIndex int
     * @param dataType EntityTableDataType
     * @throws InvocationTargetException
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public void calculateNew(EntityTable entityTable, int newTargetColumnIndex, EntityTableDataType dataType) throws InvocationTargetException, InstantiationException, IllegalAccessException {
        ColumnCalculatorPool pool = new ColumnCalculatorPool();
        for (int i = 0; i < entityTable.getDataRows().size(); i++) {
            Scriptable mainScope = buildMainScope(entityTable);
            DataRow dataRow = entityTable.getDataRows().get(i);
            DataCell resultDataCell = dataRow.insertDataCell(new DataCell(""), newTargetColumnIndex);
            pool.addColumnCalculatorThread(new ColumnCalculatorThread(mainScope, mainScript, entityTable, dataRow, resultDataCell, dataType));
        }
        pool.shutdownAndWait();
    }

    /**
     * Recalculates the script on a given Column identified by its DataIndex
     *
     * @param entityTable EntityTable
     * @param targetColumnDataIndex String
     * @param dataType EntityTableDataType
     * @throws InvocationTargetException
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public void reCalculate(EntityTable entityTable, String targetColumnDataIndex, EntityTableDataType dataType) throws InvocationTargetException, InstantiationException, IllegalAccessException {
        int targetColumnIndex = -1;
        if (targetColumnDataIndex != null) {
            targetColumnIndex = entityTable.getColumnIndex(targetColumnDataIndex);
        }
        if (targetColumnIndex < 0) {
            throw new IllegalArgumentException("Column for recalculating no found");
        }
        ColumnCalculatorPool pool = new ColumnCalculatorPool();
        for (int i = 0; i < entityTable.getDataRows().size(); i++) {
            Scriptable mainScope = buildMainScope(entityTable);
            DataRow dataRow = entityTable.getDataRows().get(i);
            DataCell resultDataCell = dataRow.getDataCell(targetColumnIndex);
            pool.addColumnCalculatorThread(new ColumnCalculatorThread(mainScope, mainScript, entityTable, dataRow, resultDataCell, dataType));
        }
    }

    /**
     * Creates a unique script variable using an incrementing counter- not
     * Threadsafe, nor does it need to be
     *
     * @return String
     */
    private String createScriptVariable() {
        return scriptVariableName + (scriptVariableCounter++);
    }


    /**
     * Builds the main scope Scriptable object which contains the globals and
     * custom script
     *
     * @param entityTable EntityTable
     * @return Scriptable
     * @throws IllegalAccessException
     * @throws InstantiationException
     * @throws InvocationTargetException
     */
    private Scriptable buildMainScope(EntityTable entityTable) throws IllegalAccessException, InstantiationException, InvocationTargetException {
        Context jsContext = Context.enter();
        Scriptable mainScope = jsContext.initStandardObjects();
        Scriptable rgObjs = jsContext.newObject(mainScope);
        mainScope.put("RGObjs", mainScope, rgObjs);
        rgObjs.put("entityTable", rgObjs, entityTable);

        try {
            if (availableScriptMethods != null) {
                availableScriptMethods.addScripts(jsContext, mainScope);
            }
            jsContext.evaluateString(mainScope, mainScript.getJsSource(), "Input ", 1, null);
        } finally {
            jsContext.exit();
        }
        return mainScope;
    }
}


class ScriptMainFunction {
    private String entryFunction;
    private String jsSource;
    private LinkedHashMap<String, String> dependentColumnData;

    public ScriptMainFunction(String entryFunction, LinkedHashMap<String, String> dependentColumnData, String jsSource) {
        this.entryFunction = entryFunction;
        this.jsSource = jsSource;
        this.dependentColumnData = dependentColumnData;
    }

    public String getEntryFunction() {
        return entryFunction;
    }

    public String getJsSource() {
        return jsSource;
    }

    public Map<String, String> getDependentColumnData() {
        return dependentColumnData;
    }

    public String toString() {
        return getJsSource();
    }
}
