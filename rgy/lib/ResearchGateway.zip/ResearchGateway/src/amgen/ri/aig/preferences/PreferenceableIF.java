package amgen.ri.aig.preferences;

/**
 * Defined object which can be updated by RGPreferences
 * @version $Id: PreferenceableIF.java,v 1.1 2011/06/17 20:41:25 cvs Exp $
 */
public interface PreferenceableIF {
    /**
     * Returns the PreferenceGroup for this PreferenceableIF object
     *
     * @return String
     */
    public String getPreferenceGroup();

    /**
     * Sets a Preference in this PreferenceableIF object
     * @param preference PreferenceIF
     */
    public void setPreference(PreferenceIF preference);
}
