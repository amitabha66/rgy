/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.items;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.json.JSONCacheItem;
import amgen.ri.aig.cache.json.JSONCacheItemFilter;
import amgen.ri.aig.cache.json.JSONCacheItemFilterMatcherIF;
import amgen.ri.aig.cache.json.JSONCacheItemFilterSet;
import amgen.ri.aig.favorites.Favorite;
import amgen.ri.aig.favorites.FavoriteFolderItem;
import amgen.ri.aig.favorites.FavoriteManager;
import amgen.ri.aig.preferences.*;
import amgen.ri.aig.record.ItemRecord;
import amgen.ri.aig.sobj.ObjectType;
import amgen.ri.aig.store.StoreRequestHandler;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtString;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author jemcdowe
 */
public class ItemsHandler extends StoreRequestHandler implements PreferenceableIF {
  public enum Request {
    TREE, FOLDER, ITEMDETAILS, SEARCHFOLDERS, OPERATION;

    public static Request fromString(String s) {
      try {
        return valueOf(s.toUpperCase().replaceAll("\\s+", "_"));
      } catch (Exception e) {
        return TREE;
      }
    }
  };
  private Request rx;

  public enum Operation {
    MOVE, MOVE_ALL, DELETE, DELETE_ALL, RENAME, SHARE, NEWFOLDER, CREATE, STAR, NONE;

    public static Operation fromString(String s) {
      try {
        return valueOf(s.toUpperCase().replaceAll("\\s+", "_"));
      } catch (Exception e) {
        return NONE;
      }
    }
  }
  private Operation op;
  private String defaultSortColumn;
  private String defaultSortDir;

  public ItemsHandler(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
    rx = Request.fromString(getParameter("rx"));
    op = Operation.fromString(getParameter("op"));
    if (!op.equals(Operation.NONE)) {
      rx = Request.OPERATION;
    }
    switch (rx) {
      case TREE:
      case SEARCHFOLDERS:
        this.responseType = ResponseFormatType.JSONARRAY;
        break;
      case FOLDER:
      case OPERATION:
      case ITEMDETAILS:
        this.responseType = ResponseFormatType.JSON;
        break;
    }
  }

  @Override
  public JSONArray generateJSONArrayResponse() throws Exception {
    switch (rx) {
      case TREE:
        int nodeID = (doesParameterEqual("node", "root") ? -1
                : getParameterNumber("node", -9999999).intValue());

        if (nodeID == -9999999) {
          throw new IllegalArgumentException("Invalid node requested");
        }
        return new ItemsManager(this).getFolderItems(nodeID, doesParameterExist("folders_only"));
      case SEARCHFOLDERS:
        JSONArray jSearchFolders = new JSONArray();
        jSearchFolders.put(createTreeNode("starred", "Starred Items", true, "ix-v0-16-star_yellow"));
        jSearchFolders.put(createTreeNode("sharee", "Shared With Me", true, "ix-v0-16-earth_view"));
        jSearchFolders.put(createTreeNode("shared", "Shared Items", true, "ix-v0-16-earth_add"));
        jSearchFolders.put(createTreeNode(ObjectType.Type.DOCUMENT.toString(), "Documents", true, "ix-v0-16-folder_document"));
        jSearchFolders.put(createTreeNode(ObjectType.Type.LIST.toString(), "Lists", true, "ix-v0-16-notebook"));
        jSearchFolders.put(createTreeNode(ObjectType.Type.ENTITYTABLE.toString(), "Tables", true, "ix-v0-16-table_sql"));
        jSearchFolders.put(createTreeNode(ObjectType.Type.VQT_QUERY.toString(), "VQT Queries", true, "ix-v0-16-colors"));
        return jSearchFolders;
    }
    return new JSONArray();
  }

  @Override
  public JSONObject generateJSONResponse() throws Exception {
    ServiceCache sessionCache = ServiceCache.getServiceCache(this);

    int folderID = getParameterNumber("folder_id", -1).intValue();
    int itemID = getParameterNumber("item_id", -1).intValue();

    String cacheID = getParameter("cacheID");
    boolean refreshCache = doesParameterEqual("refresh", "true");
    if (refreshCache) {
      sessionCache.clearJSONCacheItem(cacheID);
    }
    switch (rx) {
      case FOLDER:
        String node = getParameter("node");
        if (node == null) {
          return new JSONObject();
        }
        if (node.equals("root")) {
          node = "-1";
        }

        JSONObject jPageResults = new JSONObject();

        int start = getParameterNumber("start", 0).intValue();
        int page = getParameterNumber("limit", 25).intValue();
        final String sort = getParameter("sort", defaultSortColumn);
        final String dir = getParameter("dir", (defaultSortDir == null ? "ASC" : defaultSortDir));

        JSONCacheItemFilterSet filterSet = new JSONCacheItemFilterSet(this);
        for (final JSONCacheItemFilter filter : filterSet) {
          if (filter.getField().equals("starred")) {
            filter.setFilterMatcher(new JSONCacheItemFilterMatcherIF() {
              public boolean matchDate(Date testDate) {
                throw new UnsupportedOperationException("Not supported.");
              }

              public boolean matchList(Object testValue) {
                String strTestValue = (testValue.toString().equalsIgnoreCase("true") ? "STARRED" : "NOT STARRED");
                for (Object value : filter.getValues()) {
                  String v = value.toString();
                  if (v.equals(strTestValue)) {
                    return true;
                  }
                }
                return false;
              }

              public boolean matchNumeric(Double testNumber) {
                throw new UnsupportedOperationException("Not supported.");
              }

              public boolean matchString(String testString) {
                throw new UnsupportedOperationException("Not supported.");
              }
            });
          }
        }
        JSONCacheItem jCachedResults = (JSONCacheItem) sessionCache.getJSONCacheItem(cacheID);

        if (jCachedResults == null || !jCachedResults.getNode().equals(node)) {
          JSONObject jFolder = new JSONObject();
          jFolder.put("children", new JSONArray());
          if (ExtString.isAInteger(node)) {
            jFolder.put("children", new ItemsManager(this).getFolderItems(ExtString.toInteger(node), doesParameterExist("folders_only")));
          } else if (!ObjectType.Type.fromString(node).equals(ObjectType.Type.UNKNOWN)) {
            ObjectType.Type objType = ObjectType.Type.fromString(node);
            jFolder.put("children", new ItemsManager(this).getFolderItemsByObjectType(objType));
          } else if (node.equals("sharee")) {
            jFolder.put("children", new ItemsManager(this).getAllSharesChildFolderItems());
          } else if (node.equals("shared")) {
            jFolder.put("children", new ItemsManager(this).getAllSharedChildFolderItems());
          } else if (node.equals("starred")) {
            jFolder.put("children", new ItemsManager(this).getAllStarredChildFolderItems());
          }
          jCachedResults = new JSONCacheItem(cacheID, jFolder, "children");
          jCachedResults.setNode(node);
          sessionCache.saveJSONCacheItem(jCachedResults);
        }

        JSONObject jResults = jCachedResults.getSortedFilteredData(sort, dir, filterSet);
        List results =(jResults== null ? new ArrayList() : jResults.getJSONArray(jCachedResults.getResultKey()).asList());
        int end = Math.min(start + page, results.size());
        List subResults = results.subList(start, end);
        jPageResults.put("total", results.size());
        jPageResults.put(jCachedResults.getResultKey(), new JSONArray(subResults));
        savePreferences();
        return jPageResults;
      case ITEMDETAILS:
        JSONObject jItemDetails = new JSONObject();
        if (folderID > -1) {
          jItemDetails.put("children", new ItemsManager(this).getFolderDetails(folderID));
        } else if (itemID > -1) {
          jItemDetails.put("children", new ItemsManager(this).getItemRecord(itemID));
        }
        return jItemDetails;
      case OPERATION:
        try {
          JSONObject jOperationResults = handleOperation();
          sessionCache.clearJSONCacheItem(cacheID);
          return jOperationResults;
        } catch (Exception e) {
          e.printStackTrace();
        }
    }
    throw new IllegalArgumentException("Should not be able to get here");
  }

  public String getPreferenceGroup() {
    return "Favorites";
  }

  public void setPreference(PreferenceIF preference) {
    if (preference.getPreferenceName().equalsIgnoreCase("Default Folder Sorting")) {
      if (preference.getPreferenceValue()!= null) {
        String[] fields = preference.getPreferenceValue().toString().split(":");
        if (fields.length == 2) {
          defaultSortColumn = fields[0].trim();
          defaultSortDir = fields[1].trim().toUpperCase();
        }
      }
    }
  }

  private void savePreferences() {
    String sort = getParameter("sort");
    String dir = getParameter("dir", "ASC");
    if ((!ExtString.equals(sort, defaultSortColumn) || !ExtString.equals(dir, defaultSortDir))
            && ExtString.hasTrimmedLength(sort)
            && ExtString.hasTrimmedLength(dir)) {
      savePreferences("Default Folder Sorting", sort + ":" + dir);
    }
  }

  private JSONObject handleOperation() throws JSONException, IOException, AIGException {
    JSONObject jResults = new JSONObject();
    jResults.put("results", 0);

    List<Integer> folderIDs = new ArrayList<Integer>();
    List<Integer> itemIDs = new ArrayList<Integer>();

    for (String id : getParameter("folder_ids", "").split(",")) {
      if (ExtString.isAInteger(id)) {
        folderIDs.add(ExtString.toInteger(id));
      }
    }
    for (String id : getParameter("item_ids", "").split(",")) {
      if (ExtString.isAInteger(id)) {
        itemIDs.add(ExtString.toInteger(id));
      }
    }
    String newParentFolder = getParameter("newparent_node");
    if (newParentFolder == null) {
      newParentFolder = "0";
    }
    if (newParentFolder.equals("root")) {
      newParentFolder = "-1";
    }
    int newParentFolderID = ExtString.toInteger(newParentFolder);

    String name = getParameter("name");
    String description = getParameter("desc");
    ItemsManager itemsManager = new ItemsManager(this);
    switch (op) {
      case MOVE:
      case MOVE_ALL:
        if (newParentFolderID == 0) {
          return jResults;
        }
        int folderResults = itemsManager.moveFolders(folderIDs, newParentFolderID);
        int itemResults = itemsManager.moveFolderItems(itemIDs, newParentFolderID);
        jResults.put("results", folderResults + itemResults);
        break;
      case STAR:
        for (int itemID : itemIDs) {
          int currentResultsValue = jResults.getInt("results");
          int renameItemResults = itemsManager.toggleItemStar(itemID);
          jResults.put("results", currentResultsValue + renameItemResults + renameItemResults);
        }
        break;
      case DELETE:
      case DELETE_ALL:
        int deleteFolderResults = itemsManager.deleteFolders(folderIDs);
        int deleteItemResults = itemsManager.deleteFolderItems(itemIDs);
        jResults.put("results", deleteFolderResults + deleteItemResults);
        break;
      case NEWFOLDER:
        if (newParentFolderID == 0 || !ExtString.hasLength(name)) {
          return jResults;
        }
        int newFolderResults = itemsManager.createFolder(newParentFolderID, name, description);
        jResults.put("results", newFolderResults);
        break;
      case RENAME:
        for (int folderID : folderIDs) {
          int currentResultsValue = jResults.getInt("results");
          int renameFolderResults = itemsManager.renameFolder(folderID, name, description);
          jResults.put("results", currentResultsValue + renameFolderResults);
        }
        for (int itemID : itemIDs) {
          int currentResultsValue = jResults.getInt("results");
          int renameItemResults = itemsManager.renameItem(itemID, name, description);
          jResults.put("results", currentResultsValue + renameItemResults + renameItemResults);
        }
        break;
      case SHARE:
        for (int itemID : itemIDs) {
          int currentResultsValue = jResults.getInt("results");
          int renameItemResults = itemsManager.shareItem(itemID, getParameter("shareWith"));
          jResults.put("results", currentResultsValue + renameItemResults + renameItemResults);
        }
        break;
      case CREATE:
        JSONObject newFolderItem = createNewItem();
        jResults.put("item", newFolderItem);
        break;
    }
    return jResults;

  }

  private ItemRecord createNewItem() throws IOException, AIGException {
    ItemsManager itemsManager = new ItemsManager(this);
    String name = getParameter("name");
    String description = getParameter("description");
    ObjectType.Type type = ObjectType.Type.fromString(getParameter("favorite_type"));
    List<String> itemKeys = getParameters("key[0-9]*");
    List<String> shareWith = (doesParameterExist("shareWith", true) ? new ArrayList<String>(Arrays.asList(getParameter("shareWith").split(";"))) : new ArrayList<String>());
    JSONObject jServiceParams = getJSONObjectParameter("serviceParams");
    ItemRecord parentFolderRecord = itemsManager.getFolder(getParameterNumber("folderID", -1).intValue());

    FavoriteManager favoriteManager = new FavoriteManager(this);
    Favorite favorite = favoriteManager.createFavorite(type, name, description, itemKeys, jServiceParams, parentFolderRecord, shareWith);
    ItemRecord itemRecord = itemsManager.getItemRecordForItemKey(favorite.getFavoriteID(), FavoriteFolderItem.ItemType.FAVORITE);
    itemsManager.shareItem(itemRecord, shareWith);
    return itemRecord;
  }

  private JSONObject createTreeNode(String id, String text, boolean leaf, String iconCls) throws JSONException {
    JSONObject jNode = new JSONObject();
    if (id != null) {
      jNode.put("id", id);
    }
    if (text != null) {
      jNode.put("text", text);
    }
    jNode.put("leaf", leaf);
    if (iconCls != null) {
      jNode.put("iconCls", iconCls);
    }
    return jNode;
  }
}
