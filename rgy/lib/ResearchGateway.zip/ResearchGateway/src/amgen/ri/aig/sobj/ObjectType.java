/*
 *   ObjectType
 *   RDBData wrapper class for ObjectType
 *   $Revision: 1.3 $
 *   Created: Jeffrey McDowell, 22 Apr 2009
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.sobj;

import java.lang.reflect.Field;
import java.util.List;

import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.CompareTerm;
import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.rdb.SQLManagerIF;

/**
 * RDBData wrapper class for ObjectType
 *
 * @version $Revision: 1.3 $
 * @author Jeffrey McDowell
 * @author $Author: cvs $
 */
public class ObjectType extends RdbData {
  public static final int LIST = 0;
  public static final int ENTITYTABLE = 1;
  public static final int PROJECTVIEW = 2;
  public static final int SERVICE = 3;
  public static final int DOCUMENT = 4;
  public static final int VQT_QUERY = 5;

  public enum Type {
    LIST, ENTITYTABLE, PROJECTVIEW, SERVICE, UNKNOWN, VQT_QUERY, DOCUMENT;

    public static String revertTo(Type type) {
      switch (type) {
        case LIST:
          return "List";
        case ENTITYTABLE:
          return "Table";
        case PROJECTVIEW:
          return "Project View";
        case SERVICE:
          return "Search";
        case DOCUMENT:
          return "Document";
        case VQT_QUERY:
          return "VQT Query";
        default:
          return "Unknown";
      }
    }

    public static Type fromString(String type) {
      try {
        return Type.valueOf(type.replaceAll("\\s+", "_").toUpperCase());
      } catch (Exception e) {
        return UNKNOWN;
      }
    }
  }
  protected int object_type_id;
  protected String object_type_name;
  protected String label;

  /**
   * Default Constructor
   */
  public ObjectType() {
    super();
  }

  /**
   * RdbData Constructor
   */
  public ObjectType(String object_type_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
    this.object_type_id = Integer.parseInt(object_type_id);
  }

  /**
   * A required method which returns the primary key(s) of the table/RdbData
   * class.
   */
  public String getIdentifier() {
    return object_type_id + "";
  }

  /**
   * This method is required EXACTLY as written to allow the RdbData
   * architecture access to the class variables.
   */
  protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
    field.set(this, value);
  }

  /**
   * This method is required EXACTLY as written to allow the RdbData
   * architecture access to the class variables.
   */
  protected Object getFieldValue(Field field) throws IllegalAccessException {
    return field.get(this);
  }

  /**
   * This method returns the name of the table.
   */
  protected String getTableName() {
    return "OBJECT_TYPES";
  }

  public int getTypeID() {
    return getAsNumber("object_type_id", false).intValue();
  }

  public Type getType() {
    switch (getTypeID()) {
      case LIST:
        return Type.LIST;
      case ENTITYTABLE:
        return Type.ENTITYTABLE;
      case PROJECTVIEW:
        return Type.PROJECTVIEW;
      case SERVICE:
        return Type.SERVICE;
      default:
        return Type.UNKNOWN;
    }
  }

  /**
   * Get value for object_type_name
   */
  public String getName() {
    return (String) get("object_type_name");
  }

  /**
   * Gets the label field
   *
   * @return String
   */
  public String getLabel() {
    return (String) get("label");
  }

  /**
   * Gets the ObjectType for a name or null if not found
   *
   * @param name String
   * @param connectionPool String
   * @return ObjectType
   */
  public static ObjectType getObjectType(String name, String connectionPool) {
    if (name != null) {
      name = name.toUpperCase();
      List<ObjectType> objectTypes = new RdbDataArray(ObjectType.class, new CompareTerm[]{
                new CompareTerm("object_type_name", name)
              }, new OraSQLManager(), null, connectionPool);
      if (objectTypes.size() > 0) {
        return objectTypes.get(0);
      }
    }
    return null;
  }

  /**
   * Returns whether this ObjectType matches the given type id. Use the class
   * statics for comparisons.
   *
   * @param type int
   * @return boolean
   */
  public boolean isA(int type) {
    return (getTypeID() == type);
  }
}
