package amgen.ri.aig.projectview.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jdom.Element;

import amgen.ri.aig.entity.assay.AssayResultTypeOperations;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;


/**
 * @version $Id: ProjectViewAssayResult.java,v 1.6 2013/07/09 18:32:09 jemcdowe Exp $
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class ProjectViewAssayResult implements Serializable {
    private String resultType;
    private String resultTypeDisplay;
    private int resultTypeID;
    private String name;
    private String value;
    private Double stdDev;
    private Double n;
    private Double t;
    private int pid;
    private Map<String, String> aggregatedValues;
    private Element resultEl;

    /**
     * Creates a ProjectViewAssayResult using the Property Element
     *
     * <Property n_value="0.0107" t_value=".0146|.0169|.00753|.00374" value="0.0107" type="Float" name="IC50 IP" display_name="IC50 IP(&#xB5;M)">
     *     <stat_result>
     *         <stat_type value="0.0107" unit="" text_value="0.0107" name="Mean" />
     *         <stat_type value="4.0" unit="" text_value="4.0" name="n" />
     *         <stat_type value="0.00611" unit="" text_value="0.00611" name="STD" />
     *         <stat_type value="0.0169" unit="" text_value="0.0169" name="Max" />
     *         <stat_type value="0.00374" unit="" text_value="0.00374" name="Min" />
     *         <stat_type value="0.0146" unit="" text_value="0.0146" name="Median" />
     *         <stat_type value="4.0" unit="" text_value="4.0" name="t" />
     *     </stat_result>
     * </Property>
     *
     * @param resultEl Element
     */
    public ProjectViewAssayResult(Element resultEl) {
        super();
        this.resultEl = resultEl;
        aggregatedValues = new HashMap<String, String>();
        stdDev = ExtXMLElement.getXPathNumberValue(resultEl, "stat_result/stat_type[@name='STD']/@value").doubleValue();
        n = ExtXMLElement.getXPathNumberValue(resultEl, "stat_result/stat_type[@name='n']/@value").doubleValue();
        t = ExtXMLElement.getXPathNumberValue(resultEl, "stat_result/stat_type[@name='t']/@value").doubleValue();
        double pid = ExtXMLElement.getXPathNumberValue(resultEl, "pid").doubleValue();
        this.pid = (int) (Double.isNaN(pid) ? 0 : pid);

        value = resultEl.getAttributeValue("value");
        resultType = resultEl.getAttributeValue("type");
        name = resultEl.getAttributeValue("name");
        if (!ExtString.hasLength(resultType) && ExtString.hasLength(name)) {
            resultType = name;
        }
        List<Element> aggregatedValueEls = ExtXMLElement.getXPathElements(resultEl, "stat_result/stat_type");
        for (Element aggregatedValueEl : aggregatedValueEls) {
            aggregatedValues.put(aggregatedValueEl.getAttributeValue("name").toLowerCase(), aggregatedValueEl.getAttributeValue("text_value"));
        }

//--------------------------------------------------------------

        //This is the section that needs updated. The XML should contain the result type ID!!!

        double result_type_id = ExtXMLElement.getXPathNumberValue(resultEl, "@result_type_id").doubleValue();
        if (!Double.isNaN(result_type_id)) {
            resultTypeID = (int) result_type_id;
        } else {
            try {
                Pattern p = Pattern.compile("([\\p{Print} ]+)(\\(([\\p{ASCII}\\P{InGreek}\\p{InGreek}]+)\\))");
                Matcher m = p.matcher(resultType);
                if (m.matches()) {
                    String rt = m.group(1);
                    resultTypeID = AssayResultTypeOperations.getInstance().getResultTypeID(rt.trim());
                } else {
                    resultTypeID = AssayResultTypeOperations.getInstance().getResultTypeID(resultType.trim());
                }
            } catch (Exception e) {
                e.printStackTrace();
                resultTypeID = 0;
            }
            resultEl.setAttribute("result_type_id", resultTypeID + "");
        }

//--------------------------------------------------------------
    }


    public Element getResultEl() {
        return resultEl;
    }

    public String getResultType() {
        return resultType;
    }

    public String getResultTypeDisplay() {
        return (ExtString.hasLength(resultTypeDisplay) ? resultTypeDisplay : getResultType());
    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }

    public double getStdDev() {
        return stdDev;
    }

    public int getN() {
        return (Double.isNaN(n) ? -1 : n.intValue());
    }

    public int getT() {
        return (Double.isNaN(t) ? -1 : t.intValue());
    }

    public String getAggregatedValue(String aggregation) {
        return aggregatedValues.get(aggregation.toLowerCase());
    }

    public int getPid() {
        return pid;
    }

    public int getResultTypeID() {
        return resultTypeID;
    }

    /**
     * Returns whether the value contains only modified values
     *
     * @return boolean
     */
    public boolean onlyModifiedValues() {
        if (ExtString.hasLength(getValue()) && getValue().startsWith("N/A")) {
            return true;
        }
        return false;
    }

    /**
     * getVNTValue
     *
     * @return String
     */
    public String getVNTSuffix() {
        if (Double.isNaN(getStdDev()) || getN() < 0 || getT() < 0) {
            return null;
        }
        if (getN() == 1) {
            return "(n=" + getN() + ", t=" + getT() + ")";
        }
        return "± " + getStdDev() + " (n=" + getN() + ", t=" + getT() + ")";
    }
}
