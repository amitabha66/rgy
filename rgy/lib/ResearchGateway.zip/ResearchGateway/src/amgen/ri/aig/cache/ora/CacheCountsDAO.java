/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.ora;

/**
 *
 * @author jemcdowe
 */
public class CacheCountsDAO {
 private String cacheType;
 private int numType;
 private int offLine;

  public CacheCountsDAO() {
  }

  /**
   * @return the cacheType
   */
  public String getCacheType() {
    return cacheType;
  }

  /**
   * @param cacheType the cacheType to set
   */
  public void setCacheType(String cacheType) {
    this.cacheType = cacheType;
  }

  /**
   * @return the numType
   */
  public int getNumType() {
    return numType;
  }

  /**
   * @param numType the numType to set
   */
  public void setNumType(int numType) {
    this.numType = numType;
  }

  /**
   * @return the offLine
   */
  public int getOffLine() {
    return offLine;
  }

  /**
   * @param offLine the offLine to set
   */
  public void setOffLine(int offLine) {
    this.offLine = offLine;
  }
 
  
}
