package amgen.ri.aig.category.schema2;

import java.io.ObjectStreamException;

/**
 * Defines the types of Lists available in AIG
 */
public enum EntityListCategory {
  COMPOUNDS,
  SUBSTANCES,
  SMR_MOLECULES,
  SMR_STRUCTURES,
  SMR_COMPONENTS,
  LM_COMPOUNDS,
  LM_SUBSTANCES,
  LMR_EXPRESSION_SYSTEMS,
  LMR_PROTEIN_LOTS,
  LMR_CONSTRUCTS,
  LMR_RECOMBINANT_SEQUENCES,
  LMR_SEQUENCE_SETS,
  LMR_HARVESTS,
  LMR_REQUESTS,
  PROJECTS,
  AMGEN_DRUG_TARGETS,
  ASSAYS,
  LOGICAL_ASSAYS,
  LOGICAL_ASSAY_TYPES,
  ASSAY_TYPES,
  PLATES,
  MOSAIC_PLATES,
  AMGEN_GENES,
  RNAI_MOLECULES,
  RNAI_EXPERIMENTS,
  GENES,
  EXPERIMENTS,
  PEOPLE,
  STUDIES,
  WATSON_STUDIES,
  GALILEO_STUDIES,
  STUDY_LOG_IN_VIVO_STUDIES,
  AMES_MUTAGENIC_RESULTS,  
  NOTEBOOKS,
  DOCUMENTS,
  FOLDERS,
  DATES,
  DATA_ANALYSES,
  CAST_EXPERIMENTS,
  SECRETED_PROTEINS,
  CONSTRUCTS,
  CONSTRUCT_LOTS,
  CONSTRUCT_STUDIES,
  CELL_CULTURE_RUNS,
  ARRAY_SERVER_PROJECTS,
  WATSON_PK_STUDIES,
  WATSON_TK_STUDIES,
  WATSON_PD_STUDIES,
  SQUID_NUCLEOTIDE_SEQUENCES,
  SQUID_PROTEIN_SEQUENCES,
  NUCLEOTIDE_ACCESSION_NUMBERS,
  PROTEIN_ACCESSION_NUMBERS,
  PATHWAYS,
  OMICS_PROJECTS,
  OMICS_DATASETS,
  OMICS_SAMPLESETS,
  OMICS_SAMPLES,
  GENOMIC_PROFILING_DATASETS,
  BIOLOGICAL_STRUCTURES,
  PROTEIN_SEQUENCES,
  MODIFIED_LARGE_MOLECULES,  
  LARGE_MOLECULES,
  UNKNOWN;
  static final long serialVersionUID = 2281662231225747576L;

  public static EntityListCategory fromString(String s) {
    if (s == null) {
      return UNKNOWN;
    }
    try {
      if (s.startsWith("COMPOUNDS-")) {
        return COMPOUNDS;
      }
      return EntityListCategory.valueOf(s.replaceAll("\\s+", "_").toUpperCase());
    } catch (Exception e) {
      return UNKNOWN;
    }
  }

  /**
   * Returns the category as defined in the "Service Input Categorization
   * Scheme"
   * from the ServiceDataCategory
   *
   * @param s String
   * @return String
   */
  public String revertToString() {
    switch (this) {
      case UNKNOWN:
        return "Results";
    }
    String[] words = this.toString().split("_");
    StringBuffer sb = new StringBuffer();
    for (String word : words) {
      switch (word.length()) {
        case (0):
        case (1):
        case (2):
        case (3):
          word = word.toUpperCase();
          break;
        default:
          if (word.equalsIgnoreCase("cast")) {
            word = word.toUpperCase();
          } else if (word.equalsIgnoreCase("RNAI")) {
            word = "RNAi";
          } else {
            word = Character.toUpperCase(word.charAt(0)) + word.substring(1).toLowerCase();
          }
          break;
      }
      sb.append((sb.length() > 0 ? " " : "") + word);
    }
    return sb.toString();
  }

  /**
   * Returns the category as defined in the "Service Input Categorization
   * Scheme"
   * from the ServiceDataCategory
   *
   * @param s String
   * @return String
   */
  public static String revertTo(EntityListCategory entityListCategory) {
    switch (entityListCategory) {
      case UNKNOWN:
        return "Results";
    }
    String[] words = entityListCategory.toString().split("_");
    StringBuffer sb = new StringBuffer();
    for (String word : words) {
      switch (word.length()) {
        case (0):
        case (1):
        case (2):
        case (3):
          word = word.toUpperCase();
          break;
        default:
          if (word.equalsIgnoreCase("cast")) {
            word = word.toUpperCase();
          } else if (word.equalsIgnoreCase("RNAI")) {
            word = "RNAi";
          } else {
            word = Character.toUpperCase(word.charAt(0)) + word.substring(1).toLowerCase();
          }
          break;
      }
      sb.append((sb.length() > 0 ? " " : "") + word);
    }
    return sb.toString();
  }

  /**
   * This is necessary to permit Serializable.
   * A Serialized object containing an enum class variable is not de-Serialized
   * properly.
   * This forces de-Serialized enum to be re-created as this enum through the
   * String
   *
   * @return Object
   * @throws ObjectStreamException
   */
  public Object readResolve() throws ObjectStreamException {
    return EntityListCategory.fromString(this.toString());
  }
}
