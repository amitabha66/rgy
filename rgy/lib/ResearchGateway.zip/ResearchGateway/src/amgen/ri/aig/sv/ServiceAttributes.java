package amgen.ri.aig.sv;

import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.entity.EntityClass;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.asf.sa.uddi.*;
import amgen.ri.json.JSONObject;
import amgen.ri.rg.resource.ResourceFactory;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import com.google.common.collect.ArrayListMultimap;
import java.net.URL;
import java.util.*;
import org.apache.commons.lang.ArrayUtils;
import org.jdom.Element;

/**
 * Returns basic attributes- name, description, icon class, ... for a given service
 *
 * @author jemcdowe
 */
public class ServiceAttributes extends ResourceFactory {

  private ServiceDetails serviceDetails;
  private Map<String, String> nameMap;
  private Map<String, String> descMap;

  /**
   * Creates a ServiceAttributes object
   *
   * @param serviceDetails
   */
  public ServiceAttributes(ServiceDetails serviceDetails) {
    this(serviceDetails, null);
  }

  /**
   * Creates a ServiceAttributes object
   *
   * @param serviceDetails
   */
  public ServiceAttributes(ServiceDetails serviceDetails, EntityClassManager entityClassManager) {
    super(entityClassManager);
    this.serviceDetails = serviceDetails;
    this.nameMap = serviceDetails.getNames();
    this.descMap = serviceDetails.getDescriptions();
  }

  /**
   * Returns a service name for the first context in the array of ServiceNamingContext
   *
   * @param namingContexts ServiceNamingContext
   * @return String
   */
  public String getName(ServiceNamingContext... namingContexts) {
    for (ServiceNamingContext namingContext : namingContexts) {
      if (nameMap.containsKey(namingContext.toString())) {
        return nameMap.get(namingContext.toString());
      }
      if (nameMap.containsKey(namingContext.toString().toLowerCase())) {
        return nameMap.get(namingContext.toString().toLowerCase());
      }
    }
    return serviceDetails.getName();
  }

  /**
   * Returns a service description for a given context
   *
   * @param namingContext ServiceNamingContext
   * @return String
   */
  public String getDescription(ServiceNamingContext namingContext) {
    if (namingContext != null) {
      if (descMap.containsKey(namingContext.toString())) {
        return descMap.get(namingContext.toString());
      }
      if (descMap.containsKey(namingContext.toString().toLowerCase())) {
        return descMap.get(namingContext.toString().toLowerCase());
      }
    }
    return serviceDetails.getDescription();
  }

  public String getIconClass(ServiceNamingContext serviceNamingContext) {
    return getIconClass(serviceNamingContext, (isWidget() ? Constants.DEFAULT_WIDGET_ICON : null));
  }

  public String getIconClass(ServiceNamingContext serviceNamingContext, String defaultIconClass) {
    if (serviceNamingContext.equals(ServiceNamingContext.RG_LOFT)) {
      String loftStyle = null;
      if (isServiceVQTEngine()) {
        loftStyle = "ix-v0-16-logic_and";
      }

      Categorization categorization = TModelCommonNameFactory.getInstance().getCategorizationByName(serviceDetails, TModelCommonNameFactory.RESEARCH_GATEWAY_ICON_CATEGORIZATION_SCHEME);
      if (categorization != null && categorization.hasKeyValues()) {
        String[] keyValues = categorization.getKeyValues();
        if (keyValues != null && keyValues.length > 0) {
          loftStyle = keyValues[0];
        }
      }
      if (loftStyle != null) {
        if (!loftStyle.matches("^ix-v0-[0-9]+-") && !loftStyle.matches("^rg-[0-9]+-\\p{Print}+") && !loftStyle.matches("^x-\\p{Print}+")) {
          loftStyle = "ix-v0-16-" + loftStyle;
        }
      }

      if (loftStyle == null) {
        List<EntityListCategory> categories = getEntityListCategory();
        if (!categories.isEmpty()) {
          loftStyle = getEntityClassManager().getEntityClass(categories.get(0)).getLoftStyle();
        }
        loftStyle = serviceDetails.getContextValue("IconClass", null, loftStyle);
      }

      if (ExtString.hasLength(loftStyle)) {
        return loftStyle.replaceFirst("-[0-9]+-", "-48-");
      }
    }
    return defaultIconClass;
  }

  /**
   * Attempts to find the Service's EntityListCategory by looking first into the RESEARCH_GATEWAY_ENTITY_TYPES_SCHEME
   * and then in the SERVICE_INPUT_CATEGORIZATION_SCHEME
   *
   * @return
   */
  public List<EntityListCategory> getEntityListCategory() {
    List<EntityListCategory> categories = new ArrayList<EntityListCategory>();
    String rgEntityTypesSchemeKey = TModelCommonNameFactory.getInstance().getTModelKey(TModelCommonNameFactory.RESEARCH_GATEWAY_ENTITY_TYPES_SCHEME);
    Categorization rgEntityTypesCategorization = serviceDetails.getCategorization(rgEntityTypesSchemeKey);
    if (rgEntityTypesCategorization != null) {
      String[] keyValues = rgEntityTypesCategorization.getKeyValues();
      if (ExtArray.hasLength(keyValues)) {
        for (String keyValue : keyValues) {
          EntityListCategory category = EntityListCategory.fromString(keyValue);
          if (!category.equals(EntityListCategory.UNKNOWN)) {
            categories.add(category);
          }
        }
        return categories;
      }
    }
    String serviceInputSchemeKey = TModelCommonNameFactory.getInstance().getTModelKey(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME);
    Categorization serviceInputCategorization = serviceDetails.getCategorization(serviceInputSchemeKey);
    if (serviceInputCategorization != null) {
      String[] keyValues = serviceInputCategorization.getKeyValues();
      if (ExtArray.hasLength(keyValues)) {
        for (String keyValue : keyValues) {
          EntityListCategory category = EntityListCategory.fromString(keyValue);
          if (!category.equals(EntityListCategory.UNKNOWN)) {
            categories.add(category);
          }
        }
        return categories;
      }
    }
    categories.clear();
    return categories;
  }

  /**
   * Returns the Service's first EntityListCategory
   *
   * @return
   */
  public EntityListCategory getFirstEntityListCategory() {
    List<EntityListCategory> categories = getEntityListCategory();
    if (categories.isEmpty()) {
      return EntityListCategory.UNKNOWN;
    }
    return categories.get(0);
  }

  /**
   * Returns the Service's first EntityListCategory retrieved by getEntityListCategory() as a Label i.e.
   * EntityListCategory.revertTo(getEntityListCategory())
   *
   * @return
   */
  public String getFirstEntityListCategoryLabel() {
    EntityListCategory firstCategory = getFirstEntityListCategory();
    if (firstCategory.equals(EntityListCategory.UNKNOWN)) {
      return null;
    }
    return EntityListCategory.revertTo(firstCategory);
  }

  /**
   * Returns the Research Gateway Service Organization Scheme Categorization
   *
   * @return
   */
  public CategoryKeyValue getOrganizationCategoryKeyValue() {
    //String rgOrgCatSchemeTModelKey= TModelCommonNameFactory.getInstance().getTModelKey(TModelCommonNameFactory.RESEARCH_GATEWAY_SERVICE_ORGANIZATION_SCHEME);

    //Categorization categorization = serviceDetails.getCategorization(rgOrgCatSchemeTModelKey);
    Categorization categorization = TModelCommonNameFactory.getInstance().getCategorizationByName(serviceDetails, TModelCommonNameFactory.RESEARCH_GATEWAY_SERVICE_ORGANIZATION_SCHEME);
    if (categorization != null && categorization.hasKeyValues()) {
      String[] keyValues = categorization.getKeyValues();
      if (keyValues != null && keyValues.length > 0) {
        return categorization.getCategoryKeyValue(TModelCommonNameFactory.RESEARCH_GATEWAY_SERVICE_ORGANIZATION_SCHEME, keyValues[0]);
      }
    }
    return null;
  }

  /**
   * Returns the whether service is a default view- i.e. Research Gateway Categorization= EntityDefaultView
   */
  public boolean isEntityDefaultView() {
    Categorization categorization
            = TModelCommonNameFactory.getInstance().getCategorizationByName(serviceDetails, TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME);
    if (categorization != null && categorization.hasKeyValues()) {
      String[] keyValues = categorization.getKeyValues();
      if (ExtArray.hasLength(keyValues)) {
        for (String keyValue : keyValues) {
          if (keyValue.equals("Entity Default View")) {
            return true;
          }
        }
      }
    }
    return false;
  }

  /**
   * Returns the service's default result tModel or null if it cannot determine it
   */
  public TModelDetails getDefaultResultType() {
    try {
      String key = TModelCommonNameFactory.getInstance().getTModelKey(TModelCommonNameFactory.EXTENDED_TYPES_CATEGORIZATION_SCHEME);
      List<TModelInstanceDetails> tModelInstances = serviceDetails.getDefaultResultTypeBinding().getTModelInstancesByKeyValue(key, CommonKeyValues.xsdResultSpec);
      return tModelInstances.get(0).getTModelDetails();
    } catch (Exception ex) {
    }
    return null;
  }

  public <T extends ServiceListenerIF> T getListenerByType(Class<T> type) {
    for (ServiceListenerIF listener : serviceDetails.getListeners()) {
      if (listener.getClass().isAssignableFrom(type)) {
        return (T) listener;
      }
    }
    return null;
  }

  /**
   * Returns if the service is the VQT Engine by its service key
   *
   * @return
   */
  public boolean isServiceVQTEngine() {
    String tModelKey = TModelCommonNameFactory.getInstance().getTModelKey(TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME);
    return serviceDetails.containsKeyValue(tModelKey, "VQTENGINE");
  }

  /**
   * Whether this service is a Widget
   *
   * @return
   */
  public boolean isWidget() {
    try {
      String tModelKey = TModelCommonNameFactory.getInstance().getTModelKey(TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME);
      return serviceDetails.containsKeyValue(tModelKey, "RG Service Application");
    } catch (Exception ex) {
      return false;
    }
  }

  /**
   * Returns properties for the Widget
   *
   * @return
   */
  public List<String> getWidgetProperties() {
    List<String> keyValueList = new ArrayList<String>();
    Categorization cat = serviceDetails.getCategorizationByName(TModelCommonNameFactory.RESEARCH_GATEWAY_EXTERNAL_APPLICATION_PROPERTIES);
    if (cat != null) {
      String[] keyValues = cat.getKeyValues();
      for (String keyValue : keyValues) {
        keyValueList.add(keyValue.toUpperCase().replaceAll("\\s+", "_"));
      }
    }
    return keyValueList;
  }

  /**
   * If this service is a Widget, returns its URL
   *
   * @return
   */
  public URL getWidgetURL() {
    try {
      if (isWidget()) {
        List<BindingDetails> bindings = serviceDetails.getBindingByTModelName(CommonNames.HTMLDEFINITION_tMODELNAME);
        if (!bindings.isEmpty()) {
          return bindings.get(0).getAccessPoint();
        }
        String url = ExtXMLElement.getXPathValue(serviceDetails.getSDXMLDocument(), "//Application[0]/Source[@type='html_document']");
        boolean targetBlank = !ExtXMLElement.getXPathElements(serviceDetails.getSDXMLDocument(), "//Application[0]/Target[@blank='true']").isEmpty();
        return new URL(url + (targetBlank ? "@blank" : ""));
      }
    } catch (Exception ex) {
    }
    return null;
  }

  /**
   * Returns if the service parameter set is saveable
   *
   * @return
   */
  public boolean isServiceParametersSaveable() {
    return serviceDetails.isParametersSaveable();
  }

  public int countEditableParameters(EntityListCategory ignoreType) {
    if (isWidget()) {
      return 0;
    }
    Set<ServiceParameter> editableParameters = new HashSet<ServiceParameter>();
    ArrayListMultimap<ServiceDataCategory, ServiceParameter> serviceParamByTypeMap = getServiceParametersByServiceDataCategory();
    List<ServiceParameter> serviceParameters;
    for (ServiceDataCategory paramServiceDataCategory : serviceParamByTypeMap.keySet()) {
      switch (paramServiceDataCategory) {
        case AMGEN_SESSION_LOGIN:
        case AMGEN_SESSION_LOGIN_FASF_ENCRYPTED:
        case SESSION_IDENTIFIER:
          break;
        case UNKNOWN:
          serviceParameters = serviceParamByTypeMap.get(paramServiceDataCategory);
          for (ServiceParameter serviceParameter : serviceParameters) {
            if (serviceParameter.isEditable()) {
              editableParameters.add(serviceParameter);
            }
          }
          break;
        default:
          if (ignoreType == null || !isServiceDataCategoryInEntityCategory(paramServiceDataCategory, ignoreType)) {
            serviceParameters = serviceParamByTypeMap.get(paramServiceDataCategory);
            for (ServiceParameter serviceParameter : serviceParameters) {
              if (serviceParameter.isEditable()) {
                editableParameters.add(serviceParameter);
              }
            }
          }
          break;
      }
    }
    return editableParameters.size();
  }

  /**
   * Whether this service specifically allows recursion in the DataItems panel
   *
   * @return
   */
  public boolean allowRecursion() {
    try {
      return ExtString.equalsIgnoreCase(ExtXMLElement.getXPathValue(serviceDetails.getSDXMLDocument(), "/Service/RGExtensions/AllowRecursion"), "true");
    } catch (Exception ex) {
      return false;
    }
  }

  /**
   * Returns the service's ServiceParameter in a map of lists keys by their ServiceDataCategory
   *
   * @param service ServiceDetails
   * @return Map
   */
  public ArrayListMultimap<ServiceDataCategory, ServiceParameter> getServiceParametersByServiceDataCategory() {
    ArrayListMultimap<ServiceDataCategory, ServiceParameter> serviceMap = ArrayListMultimap.create();

    Collection<ServiceParameter> editableParameters = serviceDetails.getEditableParameters();
    for (ServiceParameter serviceParameter : editableParameters) {
      List<String> keyValues = serviceParameter.getCategoryKeyValue(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME);
      if (keyValues.isEmpty()) {
        serviceMap.put(ServiceDataCategory.UNKNOWN, serviceParameter);
      } else {
        for (String keyValue : keyValues) {
          ServiceDataCategory paramServiceDataCategory = ServiceDataCategory.fromString(keyValue);
          serviceMap.put(paramServiceDataCategory, serviceParameter);
        }
      }
    }
    return serviceMap;
  }

  /**
   * Returns a Multimap of the services parameter organized by its defined Entity Class.
   *
   * NOTE: A parameter can be defined by multiple Entity Classes, so a parameter can appear in more than one Entity
   * Class keys
   *
   * @return Map
   */
  public ArrayListMultimap<EntityClass, ServiceParameter> getServiceParametersByEntityClass() {
    ArrayListMultimap<EntityClass, ServiceParameter> parameterMap = ArrayListMultimap.create();

    Collection<ServiceParameter> editableParameters = serviceDetails.getParameters();
    for (ServiceParameter serviceParameter : editableParameters) {
      List<ServiceDataCategory> parameterServiceDataCategories = ServiceDataCategory.fromString(serviceParameter.getCategoryKeyValue(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME));
      for (ServiceDataCategory parameterServiceDataCategory : parameterServiceDataCategories) {
        parameterMap.put(getEntityClassManager().getEntityClass(parameterServiceDataCategory), serviceParameter);
      }
    }
    return parameterMap;
  }

  /**
   * Returns whether the ServiceDataCategory is a EntityListCategory. This ensures the degeneracies are checked.
   *
   * @param serviceDataCategory ServiceDataCategory
   * @param entityListCategory EntityListCategory
   * @return EntityListCategory
   */
  public boolean isServiceDataCategoryInEntityCategory(ServiceDataCategory serviceDataCategory, EntityListCategory entityListCategory) {
    if (serviceDataCategory == null || entityListCategory == null) {
      return false;
    }
    if (getEntityClassManager().convertServiceDataCategoryToEntityListCategory(serviceDataCategory).equals(entityListCategory)) {
      return true;
    }
    switch (serviceDataCategory) {
      case AMGEN_IDENTIFIER:
        if (entityListCategory.equals(EntityListCategory.COMPOUNDS) || entityListCategory.equals(EntityListCategory.SUBSTANCES)) {
          return true;
        }
        return false;
    }
    return false;
  }

  public JSONObject getServiceRecord() {
    JSONObject jService = new JSONObject();
    try {
      Element serviceEl = serviceDetails.getAsElement();
      String category = serviceEl.getChildTextNormalize("Category");
      String categoryTag = serviceEl.getChildTextNormalize("CategoryTag");
      String entityCategory = serviceEl.getChildTextNormalize("EntityCategory");

      if (!ExtString.hasLength(category)) {
        CategoryKeyValue orgCatValue = getOrganizationCategoryKeyValue();
        category = (orgCatValue == null ? "Other" : orgCatValue.getKeyName());
      }
      if (!ExtString.hasLength(categoryTag)) {
        categoryTag = getFirstEntityListCategoryLabel();
      }
      if (!ExtString.hasLength(entityCategory)) {
        EntityListCategory entityCategoryType = getFirstEntityListCategory();
        entityCategory = (entityCategoryType == null ? null : entityCategoryType.toString());
      }

      jService.putOpt("ServiceKey", serviceEl.getChildTextNormalize("ServiceKey"));
      jService.putOpt("Name", serviceEl.getChildTextNormalize("Name"));
      jService.putOpt("Organization", serviceEl.getChildTextNormalize("Organization"));
      jService.putOpt("Contact", serviceEl.getChildTextNormalize("Contact"));
      jService.putOpt("Description", serviceEl.getChildTextNormalize("Description"));;
      jService.putOpt("Icon", serviceEl.getChildTextNormalize("Icon"));
      jService.putOpt("IconCls", serviceEl.getChildTextNormalize("IconCls"));
      jService.putOpt("Category", category);
      jService.putOpt("CategoryTag", categoryTag);
      jService.putOpt("EntityCategory", entityCategory);
      jService.putOpt("LastUsed", serviceEl.getChildTextNormalize("LastUsed"));
      jService.putOpt("IsVQT", ExtString.equalsIgnoreCase(serviceEl.getChildText("IsVQT"), "true"));
      jService.putOpt("IsWidget", ExtString.equalsIgnoreCase(serviceEl.getChildText("IsWidget"), "true"));
      jService.putOpt("ShowResources", !ExtString.equalsIgnoreCase(serviceEl.getChildText("ShowResources"), "false"));
      jService.putOpt("IsParametersSaveable", ExtString.equalsIgnoreCase(serviceEl.getChildText("IsParametersSaveable"), "true"));
      jService.putOpt("IsDefaultView", ExtString.equalsIgnoreCase(serviceEl.getChildText("IsDefaultView"), "true"));
      jService.putOpt("FolderItemID", serviceEl.getChildTextNormalize("FolderItemID"));
      if (serviceEl.getChildText("EditableParams") != null) {
        jService.putOpt("EditableParams", (int) ExtString.toDouble(serviceEl.getChildText("EditableParams"), 0));
      } else {
        jService.putOpt("EditableParams", countEditableParameters(null));
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return jService;
  }

}
