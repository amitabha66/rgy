package amgen.ri.aig.entitytable.filter;

import java.io.Serializable;

import amgen.ri.aig.constants.OperatorType;
import amgen.ri.aig.entitytable.DataCell;
import amgen.ri.util.ExtString;

/**
 * <p>@version $Id: NumericFilter.java,v 1.1 2011/06/17 20:41:26 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class NumericFilter extends AbstractEntityTableFilter implements EntityTableFilterIF, Serializable {
    static final long serialVersionUID = -3074513820734483383L;
    private OperatorType operator;
    private Double filterNumericValue;


    public NumericFilter(OperatorType operator, Double value) {
        super();
        this.operator = operator;
        this.filterNumericValue = (value == null ? Double.NaN : value);
    }

    /**
     * match
     *
     * @param dataCell DataCell
     * @return boolean
     * @todo Implement this
     *   amgen.ri.aig.entitytable.filter.EntityTableFilterIF method
     */
    public boolean match(DataCell dataCell) {
        Object value = dataCell.getSortValue(false);
        double cellNumericValue = ExtString.toDouble((value == null ? null : value.toString()));

        switch (operator) {
            case GREATER:
                if (Double.isNaN(cellNumericValue) || Double.isNaN(filterNumericValue)) {
                    return false;
                }
                return (cellNumericValue > filterNumericValue);
            case GREATEROREQUAL:
                if (Double.isNaN(cellNumericValue) || Double.isNaN(filterNumericValue)) {
                    return false;
                }
                return (cellNumericValue >= filterNumericValue);
            case LESS:
                if (Double.isNaN(cellNumericValue) || Double.isNaN(filterNumericValue)) {
                    return false;
                }
                return (cellNumericValue < filterNumericValue);
            case LESSOREQUAL:
                if (Double.isNaN(cellNumericValue) || Double.isNaN(filterNumericValue)) {
                    return false;
                }
                return (cellNumericValue <= filterNumericValue);
            case EQUALS:
                if (Double.isNaN(cellNumericValue) || Double.isNaN(filterNumericValue)) {
                    return false;
                }
                return (cellNumericValue == filterNumericValue);
            case EXISTS:
                return (!Double.isNaN(cellNumericValue));
            case DOESNOTEXIST:
                return (Double.isNaN(cellNumericValue));
            default:
                return false;
        }
    }
}
