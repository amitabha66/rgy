package amgen.ri.aig.quick;

import java.io.ObjectStreamException;

/**
 * Enumeration for the QuickLaunch Requests
 */
public enum QuickLaunchRequest {
    LIST, UNKNOWN;

    public static QuickLaunchRequest fromString(String s) {
        if (s == null) {
            return LIST;
        }
        try {
            return QuickLaunchRequest.valueOf(s.toUpperCase());
        } catch (Exception e) {
            return UNKNOWN;
        }
    }

    /**
     * This is necessary to permit Serializable.
     * A Serialized object containing an enum class variable is not de-Serialized properly.
     * This forces de-Serialized enum to be re-created as this enum through the String
     * @return Object
     * @throws ObjectStreamException
     */
    public Object readResolve() throws ObjectStreamException {
        return QuickLaunchRequest.fromString(this.toString());
    }

}
