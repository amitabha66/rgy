package amgen.ri.aig.sv;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.tree.EntityLineage;
import amgen.ri.aig.cache.tree.NodeType;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.tree.TreeNodeCache;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.ServiceParameter;
import amgen.ri.asf.sa.uddi.ServiceParameterCategory;
import amgen.ri.util.ExtString;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;
import org.jdom.xpath.XPath;

public class ExecuteEntityNodeService extends AIGServlet {
  protected SAXBuilder saxBuilder;

  /**
   * Default constructor
   */
  public ExecuteEntityNodeService() {
    super();
  }

  /**
   * Main constructor- used only by the getAIGServlet method
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   */
  private ExecuteEntityNodeService(HttpServletRequest request, HttpServletResponse response) {
    super(request, response);
  }

  /**
   * Creates this AIG Servlet object
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return AIGServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new ExecuteEntityNodeService(req, resp);
  }

  public void performRequest() throws ServletException, IOException, AIGException {
    response.setContentType("text/xml");
    String serviceKey = getParameter("key");
    String entityServiceData = getParameter("data");
    String serviceNodeUUID = getParameter("uuid");
    String entityType = getParameter("datatype");
    List<EntityLineage> lineageList = TreeNodeCache.getTreeNodeCache(request).getEntityLineage(serviceNodeUUID);
    //Indicates the level in the tree any parameters have been set from lineage elements (-1= none, 0= parent, 1= grandparent, ...)
    int maxRecursionLevel = -1;

    try {
      Element serviceNode = TreeNodeCache.getTreeNodeCache(request).getTreeNode(serviceNodeUUID);
      Document treeNodesResultDocument = new Document(new Element("TREENODES"));
      ServiceDetails serviceDetails = ServiceCache.getServiceCache(request).getService(serviceKey);
      ServiceAttributes serviceAttributes= new ServiceAttributes(serviceDetails, getEntityClassManager());
      OILServiceParameterInterceptor oilInterceptor= serviceAttributes.getListenerByType(OILServiceParameterInterceptor.class);

      for (int i = 0; i < lineageList.size(); i++) {
        EntityLineage lineageElement = lineageList.get(i);
        String parameterServiceInputKeyValue= ServiceDataCategory.revertTo(lineageElement.getServiceDataCategory());
        List<ServiceParameter> parametersLocal = serviceDetails.getParameters(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, parameterServiceInputKeyValue);
        for (ServiceParameter parameter : parametersLocal) {
          ServiceParameterCategory parameterCategory = parameter.getServiceParameterCategory(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, parameterServiceInputKeyValue);
          String recursion = (parameterCategory == null || parameterCategory.getRecursion() == null ? "all" : parameterCategory.getRecursion());
          boolean setParameterFromLineage = true;

          if (parameter.getParameterValueSource().equals("lineage")) { //Parameter already set from lineage
            setParameterFromLineage = false;
            //There exists a ServiceParameterCategory for Categorization Scheme/keyValue, so check it
            //Set all categorized parameters from lineage
          } else if (recursion.equals("none")) {
            setParameterFromLineage = false;
          } else if (parameterCategory != null && ExtString.equals(parameterCategory.getRecursion(), "all")) {
            setParameterFromLineage = true;
            //Set categorized parameters from the parent only (i==0)
          } else if (parameterCategory != null && ExtString.equals(parameterCategory.getRecursion(), "parent")) {
            setParameterFromLineage = (i == 0 ? true : false);
          }

          if (setParameterFromLineage) {
            parameter.setValueFromString(lineageElement.getDataValue());
            parameter.setParameterValueSource("lineage");
            maxRecursionLevel = Math.max(maxRecursionLevel, i);
            oilInterceptor.setParametersSetByEntityClass(parameterCategory, parameter);
          }
        }
      }
      setSecurityServiceParameters(serviceDetails);


      //Sets any Amgen Site parameters
            /*
       * List<ServiceParameter> amgenSiteParameters =
       * serviceDetails.getParameters("Service Input Categorization Scheme",
       * "Amgen Site"); if (amgenSiteParameters != null) { for (ServiceParameter
       * amgenSiteParameter : amgenSiteParameters) {
       * amgenSiteParameter.setValueFromString(getSessionLogin().getUserAmgenLocationCode().toString());
       * amgenSiteParameter.setParameterValueSource("session"); } }
       */

      /*
       * --------------- COULD BE CLEANED UP TO BETTER USE THE CACHE
       * --------------
       */

      if (serviceDetails.isServiceReady()) {
        treeNodesResultDocument = serviceDetails.executeService2JDocument(TModelCommonNameFactory.TREENODESXMLDEFINITION_tMODELNAME);
        addRequestLogServiceInvocationDetails(serviceDetails);
      } else {
        throw new IllegalArgumentException("Not all parameters set");
      }
      XPath resultEntityTreeNodesXPath = XPath.newInstance("//TREENODE[@SERVICE_DATA_TYPE_CATEGORY]");
      List<Element> resultEntityTreeNodes = resultEntityTreeNodesXPath.selectNodes(treeNodesResultDocument);
      if (resultEntityTreeNodes.size() > 0) {
        ServiceDataCategory serviceDataCategory = ServiceDataCategory.getServiceDataCategory(resultEntityTreeNodes.get(0));
        //Element searchResultNode = processResultNodes(serviceNode, treeNodesResultDocument.getRootElement().getChildren("TREENODE"), NodeType.SERVICENODE, serviceDataCategory, null, serviceNodeUUID);
        serviceNode.setAttribute("RECURSION", maxRecursionLevel + "");
        Element searchResultNode = processTreeNodes(serviceNode, treeNodesResultDocument.getRootElement().getChildren("TREENODE"), NodeType.SERVICENODE, serviceDataCategory, null,
                serviceNodeUUID);

        setServiceResultCacheItem(serviceNodeUUID, serviceDetails, TModelCommonNameFactory.TREENODESXMLDEFINITION_tMODELNAME, treeNodesResultDocument);
        new XMLOutputter().output(searchResultNode, response.getWriter());
      }
    } catch (Exception e) {
      e.printStackTrace();
      response.getWriter().println("<TREENODES />");
    }
  }

  /**
   * Returns the mimetype of the servlet
   */
  protected String getServletMimeType() {
    return "text/xml";
  }
}
