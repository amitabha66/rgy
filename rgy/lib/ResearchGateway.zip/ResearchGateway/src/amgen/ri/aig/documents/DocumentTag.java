/*
 *   DocumentTag
 *   RDBData wrapper class for ABSTRACT_QUERY_ITEM
 *   $Revision: 1.1 $
 *   Created: Jeffrey McDowell, 27 Apr 2009
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.documents;


import java.lang.reflect.Field;

import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.SQLManagerIF;

/**
 *   RDBData wrapper class for ABSTRACT_QUERY_ITEM
 *   @version $Revision: 1.1 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class DocumentTag extends RdbData {
    protected int tag_id;
    protected int document_id;
    protected String tag_type;
    protected String tag_value;
    protected int active;

    /**
     * Default Constructor
     */
    public DocumentTag() {
        super();
    }

    /**
     * RdbData Constructor
     */
    public DocumentTag(String tag_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.tag_id = Integer.parseInt(tag_id);
    }

    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return tag_id + "";
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }

    /** This method returns the name of the table. */
    protected String getTableName() {
        return "DOCUMENTTAGS";
    }

    /**
     * Returns the primary key fields for the RdbData class which are used to
     * generate the SQL statement(s). If this returns null (the Default), the first field of the class is assumed.
     * The getIdentifier() method must return, in CSV, the matching number of elements as this array if generated SQL is used.
     */
    public String[] getPrimaryKeyFields() {
        return new String[] {"tag_id"};
    }

    /** Get value for tag_id */
    public int getTag_id() {
        return getAsNumber("tag_id", false).intValue();
    }

    /** Get value for document_id */
    public int getDocument_id() {
        return getAsNumber("document_id").intValue();
    }

    /** Get value for tag_type */
    public String getTag_type() {
        return (String) get("tag_type");
    }

    /** Get value for tag_value */
    public String getTag_value() {
        return (String) get("tag_value");
    }

    /** Get value for active */
    public int getActive() {
        return getAsNumber("active").intValue();
    }

}
