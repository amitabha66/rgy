/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.json;

import amgen.ri.util.Debug;
import java.util.Date;
import java.util.Calendar;

/**
 *
 * @author jemcdowe
 */
public class DefaultJSONCacheItemFilterMatcher implements JSONCacheItemFilterMatcherIF {
  private JSONCacheItemFilter filter;
  private Calendar cal;


  public DefaultJSONCacheItemFilterMatcher(JSONCacheItemFilter filter) {
    this.filter= filter;
    cal= Calendar.getInstance();
  }
  
  /**
   * Performs a match of the date.
   * Note that for the equals, this only compares month, day, year- not time!!
   * @param testDate
   * @return 
   */
  public boolean matchDate(Date testDate) {
    Date dateValue = (Date) filter.getValues().get(0);
    switch (filter.getComparisonType()) {
      case LT:
        return (testDate.compareTo(dateValue) < 0);
      case GT:
        return (testDate.compareTo(dateValue) > 0);
      case EQ:
      default:
        int testMonth;
        int testDay;
        int testYear;
        
        int month;
        int day;
        int year;  
        
        cal.setTime(testDate);
        testMonth= cal.get(Calendar.MONTH);
        testDay= cal.get(Calendar.DAY_OF_MONTH);
        testYear= cal.get(Calendar.YEAR);
        
        cal.setTime(dateValue);
        month= cal.get(Calendar.MONTH);
        day= cal.get(Calendar.DAY_OF_MONTH);
        year= cal.get(Calendar.YEAR);
        
        return (testMonth== month && testDay== day && testYear== year);
    }
  }

  public boolean matchList(Object testValue) {
    String upperTestValue = testValue.toString().toUpperCase();
    for (Object value : filter.getValues()) {
      String v = value.toString();
      if (v.equals(upperTestValue)) {
        return true;
      }
    }
    return false;
  }

  public boolean matchNumeric(Double testNumber) {
    Double dateValue = (Double) filter.getValues().get(0);
    switch (filter.getComparisonType()) {
      case LT:
        return (testNumber.compareTo(dateValue) < 0);
      case GT:
        return (testNumber.compareTo(dateValue) > 0);
      case EQ:
      default:
        return (testNumber.compareTo(dateValue) == 0);
    }
  }

  public boolean matchString(String testString) {
    String stringValue = (String) filter.getValues().get(0);
    stringValue= stringValue.toLowerCase();
    testString= testString.toLowerCase();
    switch (filter.getComparisonType()) {
      case LT:
        return (testString.compareTo(stringValue) < 0);
      case GT:
        return (testString.compareTo(stringValue) > 0);
      case EQ:
      default:
        for (Object value : filter.getValues()) {
          String v = value.toString().toLowerCase();
          if (testString.contains(v)) {
            return true;
          }
        }
        return false;
    }
  }
}