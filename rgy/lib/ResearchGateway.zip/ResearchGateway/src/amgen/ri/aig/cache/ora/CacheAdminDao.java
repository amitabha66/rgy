package amgen.ri.aig.cache.ora;

/**
 * Project: ResearchGateway
 * Created By: Jeff McDowell <jemcdowe@address>
 * Created: Oct 6, 2014
 * Revision : $Id: CacheAdminDao.java,v 1.1 2014/10/14 00:13:13 jemcdowe Exp $
 */
public class CacheAdminDao {
private boolean success;
  public CacheAdminDao() {
  }

  /**
   * @return the success
   */
  public boolean isSuccess() {
    return success;
  }

  /**
   * @param success the success to set
   */
  public void setSuccess(Integer success) {
    this.success = success.equals(1);
  }

}
