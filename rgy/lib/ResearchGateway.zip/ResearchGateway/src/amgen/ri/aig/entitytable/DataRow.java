package amgen.ri.aig.entitytable;

import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.util.Debug;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class DataRow implements Serializable {
  static final long serialVersionUID = 7777639493469991466L;
  private String entityID;
  private String entityLabel;
  
  private String entityDescription;

  private Integer entityLabelColNum;
  private List<DataCell> dataCells;

  public DataRow(String entityID) {
    this(entityID, null, null);
  }

  public DataRow(String entityID, String entityLabel) {
    this(entityID, entityLabel, null);
  }

  public DataRow(String entityID, int entityLabelColNum) {
    this(entityID, null, entityLabelColNum);
  }

  private DataRow(String entityID, String entityLabel, Integer entityLabelColNum) {
    this.entityID = entityID;
    this.entityLabel = entityLabel;
    this.entityLabelColNum = entityLabelColNum;
    this.dataCells = new ArrayList<DataCell>();
  }

  public String getEntityID() {
    return entityID;
  }

  /**
   * Adds a DataCell to the Rows
   *
   * @param dataCell DataCell
   * @return DataCell
   */
  public DataCell addDataCell(DataCell dataCell) {
    dataCells.add(dataCell);
    return dataCell;
  }

  /**
   * Inserts a DataCell to the Row shifting the values at that index and higher
   *
   * @param dataCell DataCell
   * @param index int
   * @return DataCell
   */
  public DataCell insertDataCell(DataCell dataCell, int index) {
    dataCells.add(index, dataCell);
    return dataCell;
  }

  /**
   * Adds a DataCell to the Rows
   *
   * @param dataCells List
   */
  public int addDataCells(List<DataCell> newDataCells) {
    dataCells.addAll(newDataCells);
    return newDataCells.size();
  }

  /**
   * Sets an existing DataCell to a new DataCell
   *
   * @param dataCell DataCell
   * @param index int
   * @return DataCell
   */
  public DataCell setDataCell(DataCell dataCell, int index) {
    dataCells.set(index, dataCell);
    return dataCell;
  }

  /**
   * Gets all DataCells as a List
   *
   * @return List
   */
  public List<DataCell> getDataCells() {
    return dataCells;
  }

  public String getEntityLabel() {
    return entityLabel;
  }

  public void setEntityLabel(String entityLabel) {
    this.entityLabel= entityLabel;
  }

  public Integer getEntityLabelColNum() {
    return entityLabelColNum;
  }

  /**
   * Gets the DataCell at the given index
   *
   * @param columnIndex int
   * @return DataCell
   */
  public DataCell getDataCell(int columnIndex) {
    if (columnIndex < 0 || columnIndex >= dataCells.size()) {
      return null;
    }
    return dataCells.get(columnIndex);
  }

  /**
   * Returns the raw value for cell in the row at the given column index which
   * is saved as a String. See DataCell.getValue()
   *
   * @param columnIndex int
   * @return String
   */
  public String getDataCellValue(int columnIndex) {
    DataCell dataCell = getDataCell(columnIndex);
    return (dataCell == null ? null : dataCell.getValue());
  }

  /**
   * Returns the sort value for cell in the row at the given column index. This
   * is
   * generally the same as getDataCellValue(), but may be different for DataCell
   * subclasses. See DataCell.getSortValue()
   *
   * @param columnIndex int
   * @return String
   */
  public Object getDataCellSortValue(int columnIndex, boolean reversedSort) {
    DataCell dataCell = getDataCell(columnIndex);
    return (dataCell == null ? null : dataCell.getSortValue(reversedSort));
  }

  public void deleteColumn(int columnIndex) {
    if (columnIndex < 0 || columnIndex >= dataCells.size()) {
      return;
    }
    dataCells.remove(columnIndex);
  }

  /**
   * Gets the Values JSONObj for the row
   *
   * @param fieldJArr JSONArray
   * @param formatter EntityTableCellFormatterIF
   * @param columns List
   * @return JSONObject
   * @throws JSONException
   */
  public JSONObject getJSON(JSONArray fieldJArr, EntityTableCellFormatterIF formatter, List<Column> columns) throws JSONException {
    JSONObject cellsJSON = new JSONObject();
    if (fieldJArr.length() != dataCells.size()) {
      throw new JSONException(getEntityID() + ": Invalid field length- " + fieldJArr.length() + " fields " + dataCells.size() + " cells");
    }
    for (int i = 0; i < dataCells.size(); i++) {
      Column column = columns.get(i);
      cellsJSON.put(fieldJArr.getString(i), dataCells.get(i).getJSONValue(formatter, column));
    }
                

    return cellsJSON;
  }

  /**
   * Gets the Values JSONObj for the row for a specific set of Columns
   *
   * @param fieldJArr JSONArray
   * @param formatter EntityTableCellFormatterIF
   * @param columns List
   * @return JSONObject
   * @throws JSONException
   */
  public JSONObject getColumnFilteredJSON(EntityTableCellFormatterIF formatter, List<Column> columns) throws JSONException {
    JSONObject cellsJSON = new JSONObject();
    List<String> dataIndexes = new ArrayList<String>();
    for (Column column : columns) {
      dataIndexes.add(column.getDataIndex());
    }
    Map<String, DataCell> dataCells = getDataCellByDataIndexMap(dataIndexes);
    for (int i = 0; i < columns.size(); i++) {
      Column column = columns.get(i);
      cellsJSON.put(column.getDataIndex(), dataCells.get(column.getDataIndex()).getJSONValue(formatter, column));
    }
    return cellsJSON;
  }

  /**
   * Creates a Map of ColumnDataIndex:DataCell when the DataIndexes are
   * provided
   *
   * @param dataIndexes List
   * @return Map
   */
  public Map<String, DataCell> getDataCellByDataIndexMap(List<String> dataIndexes) {
    Map<String, DataCell> dataCellMap = new LinkedHashMap<String, DataCell>();
    if (dataIndexes.size() != dataCells.size()) {
      throw new IllegalArgumentException(getEntityID() + ": Invalid field length- " + dataIndexes.size() + " fields " + dataCells.size() + " cells");
    }
    for (int i = 0; i < dataCells.size(); i++) {
      dataCellMap.put(dataIndexes.get(i), dataCells.get(i));
    }
    return dataCellMap;
  }

  /**
   * setEntityID
   *
   * @param newEntityID String
   */
  public void setEntityID(String newEntityID) {
    this.entityID = newEntityID;
  }

  /**
   * Get the value of entityDescription
   *
   * @return the value of entityDescription
   */
  public String getEntityDescription() {
    return entityDescription;
  }

  /**
   * Set the value of entityDescription
   *
   * @param entityDescription new value of entityDescription
   */
  public void setEntityDescription(String entityDescription) {
    this.entityDescription = entityDescription;
  }
  /**
   * Prepares any data needed in the DataRow prior to saving.
   * Returns true if ready for saving, false otherwise
   *
   * @return boolean
   */
  public boolean prepareForSave() {
    for (DataCell cell : getDataCells()) {
      if (!cell.prepareForSave()) {
        return false;
      }
    }
    return true;
  }
}
