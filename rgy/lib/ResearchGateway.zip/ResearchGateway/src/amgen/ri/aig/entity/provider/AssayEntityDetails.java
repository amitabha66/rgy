package amgen.ri.aig.entity.provider;

import java.util.List;
import java.util.Map;

import org.jdom.Document;
import org.jdom.Element;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.entity.assay.AssayDetails;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;

public class AssayEntityDetails extends AbstractEntityDetails {
    private String assayID;
    private boolean noStructure;
    private ServiceCache serviceCache;

    /**
     * Default constructor
     */
    public AssayEntityDetails(AIGServlet requestor) {
        super(requestor, EntityListCategory.ASSAYS);
        serviceCache = ServiceCache.getServiceCache(requestor.getHttpServletRequest());
        this.assayID = requestor.getParameter("id").replaceFirst("^AA", "");
    }

    public Document getResponseDocument() throws AIGException {
        Element entityDetailsEl = null;
        try {
            ServiceDetails assayPropertiesService = getRequestor().getLooselyCoupledServiceDetails("ASSAY_ENTITY_PROPERTIES");
            assayPropertiesService.setParameterValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, "Assay Identifier", assayID);
            entityDetailsEl = assayPropertiesService.executeService2JDocument(TModelCommonNameFactory.ENTITYPROPERTYDEFINITION_tMODELNAME).detachRootElement();
            getRequestor().addRequestLogServiceInvocationDetails(assayPropertiesService);

            if (entityDetailsEl != null) {
                List<Element> propertyEls = ExtXMLElement.getXPathElements(entityDetailsEl, "//Property");
                for (int i = 0; i < propertyEls.size(); i++) {
                    Element propertyEl = propertyEls.get(i);
                    /*
                     * THIS IS TO SUPPORT THE DATE RETURNED BY AIM SERVICE WHICH IS FORMATTED dd-MM-y
                     */
                    if (ExtString.equalsIgnoreCase(propertyEl.getAttributeValue("type"), "date")) {
                        propertyEl.setAttribute("format", "d-n-y");
                    }
                    propertyEl.setAttribute("order", i + "");
                }
                return new Document(entityDetailsEl);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public JSONObject getResponseJSON() throws AIGException {
        try {
            AssayDetails assayDetails = new AssayDetails(getRequestor(), assayID);
            Map assayDetailsMap = assayDetails.getAssayDetails();
            return new JSONObject(assayDetailsMap);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


}
