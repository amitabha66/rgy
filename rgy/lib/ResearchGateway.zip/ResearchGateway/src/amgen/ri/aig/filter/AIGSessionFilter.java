package amgen.ri.aig.filter;

import amgen.ri.aig.loft.AbstractLoftManager;
import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import amgen.ri.aig.log.RGSessionLogger;
import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.servlet.CookieSourceIF;
import amgen.ri.servlet.GenericCookieSource;
import amgen.ri.servlet.SessionLogin;
import amgen.ri.util.Debug;
import javax.servlet.*;

public class AIGSessionFilter implements Filter {
  private FilterConfig filterConfig = null;
  private Set<String> sessionIndependentFiles; //Defines files which do not need a session to provide
  private URL redirectURL; //Used when this does a universal re-direct (not used much)

  public AIGSessionFilter() {
    sessionIndependentFiles = new HashSet<String>();
  }

  /**
   * Called by the web container to indicate to a filter that it is being
   * taken out of service.
   *
   */
  public void destroy() {
  }

  /**
   * The
   * <code>doFilter</code> method of the Filter is called by the
   * container each time a request/response pair is passed through the
   * chain due to a client request for a resource at the end of the chain.
   *
   * @param request ServletRequest
   * @param response ServletResponse
   * @param chain FilterChain
   * @throws IOException
   * @throws ServletException
   */
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
    if (filterConfig == null) {
      return;
    }
    HttpServletRequest req = (HttpServletRequest) request;
    HttpServletResponse resp = (HttpServletResponse) response;
    HttpSession session = req.getSession(false);
    if (session == null) {
      chain.doFilter(request, response);
      return;
    }
    if (redirectURL != null) {
      URL requestURL = new URL(req.getRequestURL().toString());
      String requestURLFile = requestURL.getFile();

      String redirectURLFile = redirectURL.toString();
      if (requestURLFile.startsWith("/aig/") && requestURLFile.endsWith(".go")) {
        redirectURLFile = redirectURLFile.replaceAll("/aig$", requestURLFile);
      } else {
        redirectURLFile = redirectURLFile + "/jsp/aig.jsp";
      }
      String query = req.getQueryString();
      redirectURLFile = redirectURLFile + ((query != null && query.length() > 0) ? "?" + query : "");
      resp.sendRedirect(redirectURLFile);      
      return;
    }

    String requestString = req.getRequestURL().toString();
    if (!requestString.endsWith("go") && !requestString.endsWith("jsp") && !requestString.endsWith("chemimage")) {
      chain.doFilter(request, response);
      return;
    }
    if (requestString.endsWith("cacheretrieval.go") && req.getParameter("sessionID") != null) {
      chain.doFilter(request, response);
      return;
    }
    if (requestString.endsWith("sessionpinger.go")) { //Skip other filter stuff if just session pinger
      chain.doFilter(request, response);
      return;
    }
    URL requestURL = null;
    try {
      requestURL = new URL(requestString);
    } catch (Exception e) {
      e.printStackTrace();
    }
    if (requestURL == null || requestURL.getFile() == null) {
      chain.doFilter(request, response);
      return;
    }
    SessionLogin sessionLogin = SessionLogin.getSessionLogin(req);
    if (!sessionLogin.getSessionID().equals(req.getSession().getId()) && requestString.endsWith("go")) {
      resp.sendError(725, "Session Expired");
      return;
    }

    if (sessionLogin == null) {
      chain.doFilter(request, response);
      return;
    }
    if (!(sessionLogin instanceof AIGSessionLogin)) {
      sessionLogin = sessionLogin.updateSessionLogin(req, AIGSessionLogin.class);
    }

    CookieSourceIF cookieSource;
    if (request instanceof CookieSourceIF) {
      cookieSource = (CookieSourceIF) request;
    } else {
      cookieSource = new GenericCookieSource(req);
    }
    if (cookieSource.hasCookieWithLength("CURR_SMSESSION")) {
      sessionLogin.setSMTokens(cookieSource.getCookie("CURR_SMSESSION").getValue(), null);
    }

    sessionLogin.updateLastAccess();
    RGSessionLogger rgLogger = new RGSessionLogger();
    rgLogger.startRequestLog(req);    

    try {
      chain.doFilter(request, response);
    } catch (Exception e) {
      rgLogger.completeRequestLog(req, e);
      e.printStackTrace();
      throw new ServletException(e);
    }
    rgLogger.completeRequestLog(req, null);
  }

  /**
   * Called by the web container to indicate to a filter that it is being
   * placed into service.
   *
   * @param filterConfig FilterConfig
   * @throws ServletException
   */
  public void init(FilterConfig filterConfig) throws ServletException {
    this.filterConfig = filterConfig;

    Enumeration<String> initParams = filterConfig.getInitParameterNames();
    while (initParams.hasMoreElements()) {
      String initParam = initParams.nextElement();
      if (initParam.startsWith("custom_scripts")) {
        String sessionIndFiles = filterConfig.getInitParameter(initParam);
        if (sessionIndFiles != null) {
          String[] sessionIndFileArr = sessionIndFiles.split(",");
          for (String sessionIndFile : sessionIndFileArr) {
            sessionIndependentFiles.add(sessionIndFile.trim());
          }
        }
      }
    }

    try {
      redirectURL = new URL(filterConfig.getServletContext().getInitParameter("redirect"));
    } catch (Exception e) {
      redirectURL = null;
    }
  }
  
}
