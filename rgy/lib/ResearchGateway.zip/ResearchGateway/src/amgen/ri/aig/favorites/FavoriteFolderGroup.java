
/*
 *   FavoriteFolderGroup
 *   RDBData wrapper class for TOAD_PLAN_TABLE
 *   $Revision: 1.2 $
 *   Created: Jeffrey McDowell, 14 Apr 2011
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.favorites;


import java.lang.reflect.Field;

import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.SQLManagerIF;

/**
 *   RDBData wrapper class for TOAD_PLAN_TABLE
 *   @version $Revision: 1.2 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class FavoriteFolderGroup extends RdbData {
    protected String favorites_folder_group_id;
    protected String description;

    /**
     * Default Constructor
     */
    public FavoriteFolderGroup() {
        super();
    }
    /**
     * RdbData Constructor
     */
    public FavoriteFolderGroup(String favorites_folder_group_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.favorites_folder_group_id= favorites_folder_group_id;
    }

    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return favorites_folder_group_id;
    }
    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }
    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }
    /** This method returns the name of the table. */
    protected String getTableName() {
        return "FAVORITES_FOLDER_GROUP";
    }
    /**
     * Returns the primary key fields for the RdbData class which are used to
     * generate the SQL statement(s). If this returns null (the Default), the first field of the class is assumed.
     * The getIdentifier() method must return, in CSV, the matching number of elements as this array if generated SQL is used.
     */
    public String[] getPrimaryKeyFields() {
        return new String[] {"favorites_folder_group_id"};
    }
    /** Get value for favorites_folder_group_id */
    public String getFavorites_folder_group_id() {
        return (String)get("favorites_folder_group_id", false);
    }
    /** Get value for description */
    public String getDescription() {
        return (String)get("description");
    }

}
