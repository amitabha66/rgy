/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.json;

import amgen.ri.aig.cache.item.AbstractCacheItem;
import amgen.ri.aig.constants.Constants;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 *
 * Maintains a cached result object and any sorting to the object
 *
 * @author jemcdowe
 */
public class JSONCacheItem extends AbstractCacheItem {
  private JSONObject jBaseObj;
  private String jsonResultKey = null;
  private int resultCount;
  private Map<String, JSONObject> sortJObjsMap;
  private String node;

  public JSONCacheItem(String cacheID, JSONObject jBaseObj, String jsonResultKey) throws JSONException {
    super(cacheID);
    this.jBaseObj = jBaseObj;
    if (!jBaseObj.has(jsonResultKey)) {
      throw new IllegalArgumentException("No results returned.");
    }
    this.jsonResultKey = jsonResultKey;
    resultCount = this.jBaseObj.getJSONArray(jsonResultKey).asList().size();
    sortJObjsMap = new HashMap<String, JSONObject>();
  }

  public JSONObject getData() {
    return jBaseObj;
  }

  public String getResultKey() {
    return jsonResultKey;
  }

  public int getResultCount() {
    return resultCount;
  }

  public String getNode() {
    return node;
  }

  public void setNode(String node) {
    this.node = node;
  }

  public JSONObject getSortedData(String sortField, String direction) {    
    if (sortField == null || sortField.length() == 0) {
      return getData();
    }
    if (direction == null) {
      direction = "asc";
    }
    String sortKey = new String(sortField + "." + direction).toLowerCase();
    if (!sortJObjsMap.containsKey(sortKey)) {
      try {
        final String sort = sortField;
        final boolean asc = direction.equalsIgnoreCase("asc");
        List results = getData().getJSONArray(jsonResultKey).asList();

        if (!results.isEmpty()) {
          JSONObject ar = null;
          for (Object obj : results) {
            if (obj != null) {
              ar = (JSONObject) obj;
              if (ar.has(sort)) {
                break;
              }
            }
          }
          if (ar != null) {
            final SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.JSON_DATE_PATTERN);

            final boolean isDate = (getDate(ar, sortField, dateFormat) != null);

            JSONObject[] obj = (JSONObject[]) results.toArray(new JSONObject[0]);
            Arrays.sort(obj, new Comparator() {
              public int compare(Object o1, Object o2) {
                try {
                  JSONObject jObj1 = (JSONObject) o1;
                  JSONObject jObj2 = (JSONObject) o2;
                  Object v1 = jObj1.opt(sort);
                  Object v2 = jObj2.opt(sort);

                  if (v1 != null && v2 != null) {
                    if (v1 instanceof Number && v2 instanceof Number) {
                      double d1 = ((Number) v1).doubleValue();
                      double d2 = ((Number) v2).doubleValue();
                      return (asc ? 1 : -1) * Double.compare(d1, d2);
                    } else if (v1 instanceof Date && v2 instanceof Date) {
                      Date d1 = (Date) v1;
                      Date d2 = (Date) v2;
                      long t1 = d1.getTime();
                      long t2 = d2.getTime();
                      return (asc ? 1 : -1) * Long.compare(t1, t2);
                    } else if (isDate) {
                      Date d1 = getDate(jObj1, sort, dateFormat);
                      Date d2 = getDate(jObj2, sort, dateFormat);
                      if (d1 == null && d2 == null) {
                        return 0;
                      } else if (d1 == null && d2 != null) {
                        return (asc ? 1 : -1);
                      } else if (d2 == null && d1 != null) {
                        return (asc ? -1 : 1);
                      } else {
                        long t1 = d1.getTime();
                        long t2 = d2.getTime();
                        return (asc ? 1 : -1) * Double.compare(t1, t2);
                      }
                    } else {
                      //Just sort by String
                      String s1 = v1.toString().toLowerCase();
                      String s2 = v2.toString().toLowerCase();
                      return (asc ? 1 : -1) * s1.compareTo(s2);
                    }
                  } else if (v1 == null && v2 != null) {
                    return (asc ? 1 : -1);
                  } else if (v2 == null && v1 != null) {
                    return (asc ? -1 : 1);
                  } else {
                    return 0;
                  }
                } catch (Exception e) {
                  e.printStackTrace();
                }
                return 0;
              }
            });
            List sortedList = Arrays.asList(obj);
            JSONObject sortedJObj = new JSONObject();
            sortedJObj.put(getResultKey(), new JSONArray(sortedList));
            sortJObjsMap.put(sortKey, sortedJObj);
          }
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return sortJObjsMap.get(sortKey);
  }

  public JSONObject getSortedFilteredData(String sortField, String direction, JSONCacheItemFilterSet filterSet) {
    JSONObject jSortedObj = getSortedData(sortField, direction);
    if (filterSet == null || filterSet.isEmpty()) {
      return jSortedObj;
    }
    try {
      List<JSONObject> filteredJObjs = new ArrayList<JSONObject>();

      List<JSONObject> sortedJObjs = jSortedObj.getJSONArray(getResultKey()).asList();
      for (JSONObject sortedJObj : sortedJObjs) {
        boolean match = true;
        for (JSONCacheItemFilter filter : filterSet) {
          Object v1 = sortedJObj.opt(filter.getField());
          if (v1== null || !filter.match(v1)) {
            match = false;
            break;
          }
        }
        if (match) {
          filteredJObjs.add(sortedJObj);
        }
      }
      JSONObject filteredJObj = new JSONObject();
      filteredJObj.put(getResultKey(), new JSONArray(filteredJObjs));
      return filteredJObj;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return jSortedObj;
  }

  private Date getDate(JSONObject json, String fieldName, SimpleDateFormat dateFormat) {
    try {
      String value = json.getString(fieldName);
      Date d = dateFormat.parse(value);
      if (d != null) {
        return d;
      }
    } catch (Exception e) {
    }
    return null;

  }
}
