/*
 *   AIGLog
 *   RDBData wrapper class for AIG_LOG
 *   $Revision: 1.1 $
 *   Created: Jeffrey McDowell, 08 Dec 2008
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.log;


import java.lang.reflect.Field;

import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.SQLManagerIF;

/**
 *   RDBData wrapper class for AIG_LOG
 *   @version $Revision: 1.1 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class AIGLog extends RdbData {
    protected int id;
    protected String session_id;
    protected String username;
    protected String service_type;
    protected String service_key;
    protected java.sql.Date request_date;
    protected String host;
    protected String remote_host;

    /**
     * Default Constructor
     */
    public AIGLog() {
        super();
    }

    /**
     * RdbData Constructor
     */
    public AIGLog(String id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.id = Integer.parseInt(id);
    }

    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return id + "";
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }

    /** This method returns the name of the table. */
    protected String getTableName() {
        return "AIG_LOG";
    }

    /**
     * Returns the primary key fields for the RdbData class which are used to
     * generate the SQL statement(s). If this returns null (the Default), the first field of the class is assumed.
     * The getIdentifier() method must return, in CSV, the matching number of elements as this array if generated SQL is used.
     */
    public String[] getPrimaryKeyFields() {
        return new String[] {"id"};
    }

    /** Get value for id */
    public int getId() {
        return getAsNumber("id", false).intValue();
    }

    /** Get value for session_id */
    public String getSession_id() {
        return (String) get("session_id");
    }

    /** Get value for username */
    public String getUsername() {
        return (String) get("username");
    }

    /** Get value for service_type */
    public String getService_type() {
        return (String) get("service_type");
    }

    /** Get value for service_key */
    public String getService_key() {
        return (String) get("service_key");
    }

    /** Get value for request_date */
    public java.sql.Date getRequest_date() {
        return (java.sql.Date) get("request_date");
    }

    /** Get value for host */
    public String getHost() {
        return (String) get("host");
    }

    /** Get value for remote_host */
    public String getRemote_host() {
        return (String) get("remote_host");
    }


}
