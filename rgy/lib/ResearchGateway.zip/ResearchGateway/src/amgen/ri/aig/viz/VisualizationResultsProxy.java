package amgen.ri.aig.viz;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Proxy object for containing the Collection of VisualizationResults
 * @author jemcdowe
 */
public class VisualizationResultsProxy implements Serializable, Iterable<VisualizationResults> {
  private List<VisualizationResults> vizResults;

  public VisualizationResultsProxy() {
    vizResults = new ArrayList<VisualizationResults>();
  }

  /**
   * @return the vizResults
   */
  public List<VisualizationResults> getVizResults() {
    return vizResults;
  }

  /**
   * @param vizResults the vizResults to set
   */
  public void addVizResults(VisualizationResults vizResults) {
    this.getVizResults().add(vizResults);
  }

  /**
   * Iterator for the Collection
   *
   * @return
   */
  public Iterator<VisualizationResults> iterator() {
    return getVizResults().iterator();
  }
}
