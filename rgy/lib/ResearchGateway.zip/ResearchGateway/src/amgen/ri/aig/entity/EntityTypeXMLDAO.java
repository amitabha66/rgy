/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amgen.ri.aig.entity;

import amgen.ri.xml.ExtXMLElement;
import org.jdom.Document;

/**
 *
 * @author jemcdowe
 */
public class EntityTypeXMLDAO {
  
  private String entity_xml;

  /**
   * Get the value of entity_xml
   *
   * @return the value of entity_xml
   */
  public Document getEntityXMLDocument() {
    return ExtXMLElement.toDocument(entity_xml);
  }

  /**
   * Set the value of entity_xml
   *
   * @param entity_xml new value of entity_xml
   */
  public void setEntity_xml(String entity_xml) {
    this.entity_xml = entity_xml;
  }

}
