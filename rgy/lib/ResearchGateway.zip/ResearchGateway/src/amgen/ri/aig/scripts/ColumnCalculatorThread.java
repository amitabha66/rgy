package amgen.ri.aig.scripts;

import java.util.ArrayList;
import java.util.List;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.Scriptable;

import amgen.ri.aig.entitytable.Column;
import amgen.ri.aig.entitytable.DataCell;
import amgen.ri.aig.entitytable.DataRow;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;
import amgen.ri.aig.entitytable.subtable.SubDataRow;
import amgen.ri.aig.entitytable.subtable.SubtableDataCell;
import amgen.ri.aig.util.AssaySummaryFormat;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtString;

/**
 *
 * Runnable Class which runs the script for a single row in the EntityTable.
 *
 *@version $Id: ColumnCalculatorThread.java,v 1.3 2011/06/22 23:05:15 cvs Exp $
 */
public class ColumnCalculatorThread implements Runnable {
    private Scriptable mainScope;
    private ScriptMainFunction mainScript;
    private EntityTable entityTable;
    private DataRow dataRow;
    private DataCell resultDataCell;
    private EntityTableDataType dataType;
    private String scriptVariableName = "rgThreadReferenceVariable";
    private int scriptVariableCounter = 0;
    public static int count = 0;

    public int keyCount;


    public ColumnCalculatorThread(Scriptable mainScope, ScriptMainFunction mainScript, EntityTable entityTable, DataRow dataRow, DataCell resultDataCell, EntityTableDataType dataType) {
        this.mainScope = mainScope;
        this.mainScript = mainScript;
        this.entityTable = entityTable;
        this.dataRow = dataRow;
        this.resultDataCell = resultDataCell;
        this.dataType = (dataType == null ? EntityTableDataType.TEXT : dataType);
        keyCount = (count++);
    }

    public void run() {
        runScript();
    }

    public EntityTableDataType runScript() {
        Context cx = Context.enter();
        try {
            Scriptable threadScope = cx.newObject(mainScope);
            threadScope.setPrototype(mainScope);
            threadScope.setParentScope(null);

            Scriptable rgObjs = (Scriptable) mainScope.get("RGObjs", mainScope);
            rgObjs.put("dataRow", rgObjs, dataRow);
            rgObjs.put("entityID", rgObjs, dataRow.getEntityID());

            StringBuffer declarations = new StringBuffer();
            List<Object> functionArgs = new ArrayList();
            for (String varName : mainScript.getDependentColumnData().keySet()) {
                String dataIndex = mainScript.getDependentColumnData().get(varName);
                int columnIndex = entityTable.getColumnIndex(dataIndex);
                Column column = entityTable.getColumn(columnIndex);
                DataCell cell = dataRow.getDataCell(columnIndex);
                functionArgs.add(createCellValueDeclaration(declarations, column, cell));
            }
            functionArgs.add(createEntityIDDeclaration(declarations));
            String wrapperFunction = createScriptVariable();
            StringBuffer body = new StringBuffer();

            body.append("function " + wrapperFunction + " () {");
            body.append(declarations);
            body.append("return " + mainScript.getEntryFunction() + "(" + ExtString.join(functionArgs, ",") + ")");
            body.append("}");

            cx.evaluateString(threadScope, body.toString(), "Input ", 1, null);
            Function main = (Function) threadScope.get(wrapperFunction, threadScope);
            Object result = main.call(cx, threadScope, threadScope, new Object[0]);
            if (resultDataCell != null) {
                resultDataCell.setValue(Context.toString(result), dataType);
                return dataType;
            } else {
                String value = Context.toString(result);
                if (ExtString.isANumber(value)) {
                    return EntityTableDataType.DOUBLE;
                } else {
                    return EntityTableDataType.TEXT;
                }
            }
        } finally {
            Context.exit();
        }
    }

    private String createCellValueDeclaration(StringBuffer declarations, Column column, DataCell cell) {
        String scriptVariable = createScriptVariable();
        String value = cell.getValue();
        if (value == null) {
            declarations.append("var " + scriptVariable + "= null;");
            return scriptVariable;
        }
        if (cell instanceof SubtableDataCell) {
            declarations.append("var " + scriptVariable + "= [];");
            SubtableDataCell subDataCell = (SubtableDataCell) cell;
            for (SubDataRow subDataRow : subDataCell.getRows()) {
                String subDataValue = subDataRow.getDataCell(0).getValue();
                switch (column.getDataType()) {
                    case INTEGER:
                        int intVal = 0;
                        if (ExtString.isANumber(subDataValue)) {
                            intVal = new Double(subDataValue).intValue();
                        }
                        declarations.append(scriptVariable + ".push(" + intVal + ");");
                        break;
                    case DOUBLE:
                        double doubleVal = 0;
                        if (ExtString.isANumber(subDataValue)) {
                            doubleVal = new Double(subDataValue).doubleValue();
                        }
                        declarations.append(scriptVariable + ".push(" + doubleVal + ");");
                        break;
                    case DATE:
                        declarations.append(scriptVariable + ".push('" + subDataValue.replaceAll("'", "\\'") + "');");
                        break;
                    case ASSAY_SUMMARY:
                        AssaySummaryFormat summaryFormat = new AssaySummaryFormat(subDataValue);
                        String assaySummaryObj = "new RGScript.AssaySummary(" +
                                                 summaryFormat.getValue() + ", " +
                                                 summaryFormat.getStddev() + ", " +
                                                 summaryFormat.getAggregationCount() + ", " +
                                                 summaryFormat.getObservationCount() + ", " +
                                                 (ExtString.hasLength(summaryFormat.getModifiedValues()) ? '"' + summaryFormat.getModifiedValues() + '"' : "null") + ")";
                        declarations.append(scriptVariable + ".push(" + assaySummaryObj + ");");
                        break;
                    default:
                        if (ExtString.isANumber(subDataValue)) {
                            doubleVal = ExtString.toDouble(subDataValue);
                            declarations.append(scriptVariable + ".push(" + doubleVal + ");");
                        } else {
                            declarations.append(scriptVariable + ".push('" + subDataValue.replaceAll("'", "\\'") + "');");
                        }
                        break;
                }
            }
            return scriptVariable;
        }

        switch (column.getDataType()) {
            case INTEGER:
                int intVal = 0;
                if (ExtString.isANumber(value)) {
                    intVal = new Double(value).intValue();
                }
                declarations.append("var " + scriptVariable + "= " + intVal + ";");
                return scriptVariable;
            case DOUBLE:
                double doubleVal = 0;
                if (ExtString.isANumber(value)) {
                    doubleVal = new Double(value).doubleValue();
                }
                declarations.append("var " + scriptVariable + "= " + doubleVal + ";");
                return scriptVariable;
            case DATE:
                declarations.append("var " + scriptVariable + "= '" + value.replaceAll("'", "\\'") + "';");
                return scriptVariable;
            case ASSAY_SUMMARY:
                AssaySummaryFormat summaryFormat = new AssaySummaryFormat(value);
                String assaySummaryObj = "new RGScript.AssaySummary(" +
                                         summaryFormat.getValue() + ", " +
                                         summaryFormat.getStddev() + ", " +
                                         summaryFormat.getAggregationCount() + ", " +
                                         summaryFormat.getObservationCount() + ", " +
                                         (ExtString.hasLength(summaryFormat.getModifiedValues()) ? '"' + summaryFormat.getModifiedValues() + '"' : "null") + ")";
                declarations.append("var " + scriptVariable + "= " + assaySummaryObj + ";");
                return scriptVariable;
            default:
                if (ExtString.isANumber(value)) {
                    doubleVal = ExtString.toDouble(value);
                    declarations.append("var " + scriptVariable + "= " + doubleVal + ";");
                } else {
                    declarations.append("var " + scriptVariable + "= '" + value.replaceAll("'", "\\'") + "';");
                }
                return scriptVariable;
        }
    }

    private String createEntityIDDeclaration(StringBuffer declarations) {
        JSONObject entityDeclaration = new JSONObject();
        try {
            entityDeclaration.put("id", dataRow.getEntityID());
        } catch (JSONException ex) {
        }
        declarations.append("var rgEntity=" + entityDeclaration + ";");
        return "rgEntity";
    }

    private String createScriptVariable() {
        return scriptVariableName + (scriptVariableCounter++);
    }

}
