package amgen.ri.aig.entitytable;

import java.text.DecimalFormat;

import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;
import amgen.ri.aig.util.AssaySummaryFormat;
import amgen.ri.util.ExtString;

/**
 * @version $Id: DefaultEntityTableCellFormatter.java,v 1.2 2011/06/22 23:05:15 cvs Exp $
 */
public class DefaultEntityTableCellFormatter implements EntityTableCellFormatterIF {
    private DecimalFormat integerFormat = new DecimalFormat("0");
    private DecimalFormat fourDecimalFixedFormat = new DecimalFormat("0.####");
    private DecimalFormat fourDecimalScientficFormat = new DecimalFormat("0.####E0");
    private boolean showAssaySummary;


    public DefaultEntityTableCellFormatter() {
        this.showAssaySummary = true;
    }

    /**
     * format
     *
     * @param value Object
     * @param string String
     * @return String
     * @todo Need to fix this!!
     */
    public String format(Column column, Object value, String source) {
        if (value == null) {
            return "";
        }
        ColumnFormat columnFormat = column.getColumnFormat();
        EntityTableDataType columnDataType = (column == null ? EntityTableDataType.TEXT : column.getDataType());
        switch (columnDataType) {
            case ASSAY_SUMMARY:
                AssaySummaryFormat assaySummaryFormat = new AssaySummaryFormat(value + "");
                if (showAssaySummary) {
                    return assaySummaryFormat.getAssaySummary(columnFormat);
                } else if (!Double.isNaN(assaySummaryFormat.getValue())) {
                    return assaySummaryFormat.getValue(columnFormat);
                } else if (ExtString.hasLength(assaySummaryFormat.getModifiedValues())) {
                    return assaySummaryFormat.getModifiedValues();
                } else {
                    return value + "";
                }
            case INTEGER:
                if (columnFormat != null) {
                    return columnFormat.getFormatterValue(value);
                }
                if (value instanceof Number) {
                    return integerFormat.format(value);
                } else {
                    double v = ExtString.toDouble(value + "");
                    if (!Double.isNaN(v)) {
                        return fourDecimalFixedFormat.format(v);
                    }
                }
                break;
            case DOUBLE:
                if (columnFormat != null) {
                    return columnFormat.getFormatterValue(value);
                }
                if (value instanceof Number) {
                    return fourDecimalFixedFormat.format(value);
                } else {
                    double v = ExtString.toDouble(value + "");
                    if (!Double.isNaN(v)) {
                        return fourDecimalFixedFormat.format(v);
                    }
                }
                break;
            case DATE:
                if (columnFormat != null) {
                    return columnFormat.getFormatterValue(value);
                }
                break;
            default:
                break;
        }

        if (columnFormat != null) {
            return columnFormat.getFormatterValue(value);
        }

        if (value instanceof Integer || value instanceof Long) {
            return integerFormat.format(value);
        } else if (value instanceof Number) {
            return fourDecimalFixedFormat.format(value);
        }
        return value + "";
    }

    /**
     * Sets whether to show assay summary columns in Assay Summary format, or
     * just number format
     *
     * @param showAssaySummary boolean
     */
    public void setShowAssaySummary(boolean showAssaySummary) {
        this.showAssaySummary = showAssaySummary;
    }

    /**
     * Returns whether to show assay summary columns in Assay Summary format, or
     * just number format
     *
     * @return boolean
     */
    public boolean isShowAssaySummary() {
        return showAssaySummary;
    }

    /**
     * toggleShowAssaySummary
     */
    public void toggleShowAssaySummary() {
        this.showAssaySummary = !this.showAssaySummary;
    }

    public String format(Object value, String source) {
        if (value == null) {
            return value + "";
        }
        if (value instanceof Integer) {
            return integerFormat.format(value);
        }
        if (value instanceof Number) {
            return fourDecimalFixedFormat.format(value);
        }
        return value + "";
    }

}
