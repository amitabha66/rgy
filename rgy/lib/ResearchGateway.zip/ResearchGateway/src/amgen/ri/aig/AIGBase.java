package amgen.ri.aig;

import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.cache.CacheManagerFactory;
import amgen.ri.aig.cache.CacheManagerIF;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.tree.EntityLineage;
import amgen.ri.aig.cache.tree.NodeType;
import amgen.ri.aig.cache.tree.TreeNode;
import amgen.ri.aig.cache.tree.TreeNodeCache;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.entity.EntityClass;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.entityrules.EntityRulesFactory;
import amgen.ri.aig.entityrules.EntityRulesIF;
import amgen.ri.aig.event.FASFParameterEncoder;
import amgen.ri.aig.jawr.JAWRProperties;
import amgen.ri.aig.preferences.SpecialUserPreferences;
import amgen.ri.aig.preferences.UserPreference;
import amgen.ri.aig.record.AbstractRecord;
import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.aig.sm.structure.ChemMolInput;
import amgen.ri.aig.sv.EntityServiceInvoker;
import amgen.ri.aig.sv.OILServiceParameterInterceptor;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.asf.sa.security.FASFIdentitySecurityToken;
import amgen.ri.asf.sa.security.FASFSecurityToken;
import amgen.ri.asf.sa.security.SecurityTokenIF;
import amgen.ri.asf.sa.security.SiteMinderSessionSecurityToken;
import amgen.ri.asf.sa.uddi.BindingDetails;
import amgen.ri.asf.sa.uddi.ClassificationSchemeDetails;
import amgen.ri.asf.sa.uddi.ClassificationSchemeNames;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.ServiceInvocationDetails;
import amgen.ri.asf.sa.uddi.ServiceParameter;
import amgen.ri.asf.sa.uddi.ServiceParameterException;
import amgen.ri.asf.sa.uddi.ServiceParameterType;
import amgen.ri.asf.sa.uddi.UDDIDetails;
import amgen.ri.csv.CSVReader;
import amgen.ri.excel.ExcelUtils;
import amgen.ri.json.ExtJSON;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.ldap.AmgenEnterpriseEntry;
import amgen.ri.ldap.AmgenEnterpriseLookup;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.security.FASFEncrypter;
import amgen.ri.security.FASFIdentity;
import amgen.ri.servlet.CookieSourceIF;
import amgen.ri.servlet.GenericCookieSource;
import amgen.ri.servlet.SessionLogin;
import amgen.ri.time.ElapsedTime;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtFile;
import amgen.ri.util.ExtNet;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.awt.image.BufferedImage;
import java.io.*;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.wsdl.WSDLException;
import javax.xml.rpc.ServiceException;
import javax.xml.transform.TransformerException;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileItemStream;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.fileupload.util.Streams;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.log4j.Logger;
import org.apache.poi.ss.SpreadsheetVersion;
import org.apache.poi.ss.usermodel.Workbook;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

/**
 * Defines a base class for all servlet-related classes in AIG. Actual servlet must extend the AIGServlet class
 */
public abstract class AIGBase extends HttpServlet {

  public enum MethodType {

    GET, POST, UNKNOWN;

    public static MethodType fromRequest(HttpServletRequest req) {
      try {
        return MethodType.valueOf(req.getMethod());
      } catch (Exception e) {
        return UNKNOWN;
      }
    }
  };
  public static Logger rgLogger = Logger.getLogger("rg");
  public static Logger serviceLogger = Logger.getLogger("rgservice");
  public static final String VALUE_SEPARATOR = ";";
  public static final String DATE_FORMAT = "hh:mm a MMM dd yyyy zzz";
  protected HttpServletRequest request;
  protected ServletContext context;
  protected boolean alwaysUseServiceCache = false;
  protected Map<String, String> parameters;
  protected Map<String, byte[]> inStreamParams;
  private boolean isMultiPartRequest;
  private MethodType requestType;
  private CookieSourceIF cookies;
  private EntityClassManager entityClassManager;
  protected Map<ClassificationSchemeNames, ClassificationSchemeDetails> classificationSchemeDetails;
  protected Format usASCIIFormat = Format.getCompactFormat();
  protected Format expandElementsFormat = Format.getCompactFormat();
  private ElapsedTime time;
  protected Map<SpecialUserPreferences, UserPreference> userPreferences;

  /**
   * Default constructor
   */
  public AIGBase() {
    super();
    this.entityClassManager = new EntityClassManager();
    new FASFParameterEncoder();
    usASCIIFormat.setEncoding("US-ASCII");
    usASCIIFormat.setOmitEncoding(true);

    expandElementsFormat.setOmitEncoding(true);
    expandElementsFormat.setExpandEmptyElements(true);

    this.parameters = new HashMap<String, String>();
    this.classificationSchemeDetails = new HashMap<ClassificationSchemeNames, ClassificationSchemeDetails>();
    this.inStreamParams = new HashMap<String, byte[]>();
  }

  /**
   * Standard constructor which creates a new AIGBase
   *
   * @param req HttpServletRequest
   */
  public AIGBase(HttpServletRequest req) {
    this();
    this.request = req;
    try {
      this.request.setCharacterEncoding("UTF-8");
    } catch (UnsupportedEncodingException ex) {
    }
    context = this.request.getSession(false).getServletContext();
    String alwaysUseServiceCache = context.getInitParameter("USE_SERVICE_CACHE");
    this.alwaysUseServiceCache = (alwaysUseServiceCache == null ? false : alwaysUseServiceCache.equalsIgnoreCase("true"));
    setParameters();
  }

  /**
   * Returns whether the request is from an MS IE browser
   *
   * @return boolean
   */
  public boolean isMSIE() {
    String ua = request.getHeader("User-Agent");
    return (ua != null && ua.toUpperCase().indexOf("MSIE") != -1);
  }

  /**
   * Returns whether the request is from a Firefox browser
   *
   * @return boolean
   */
  public boolean isFirefox() {
    String ua = request.getHeader("User-Agent");
    return (ua != null && ua.toUpperCase().indexOf("FIREFOX/") != -1);
  }

  /**
   * Returns a Cookie of a given name
   *
   * @param cookieName String
   * @return Cookie
   */
  public Cookie getCookie(String cookieName) {
    if (cookies == null) {
      cookies = new GenericCookieSource(request);
    }
    return cookies.getCookie(cookieName);
  }

  /**
   * Returns a Cookie of a given name
   *
   * @param cookieName String
   * @return Cookie
   */
  public CookieSourceIF getCookies() {
    if (cookies == null) {
      cookies = new GenericCookieSource(request);
    }
    return cookies;
  }

  public void setParameters() {
    isMultiPartRequest = false;
    try {
      if (ServletFileUpload.isMultipartContent(request)) {
        isMultiPartRequest = true;
        // Create a new file upload handler
        ServletFileUpload upload = new ServletFileUpload();
        // Parse the request
        FileItemIterator iter = upload.getItemIterator(request);
        while (iter.hasNext()) {
          FileItemStream item = iter.next();
          String name = item.getFieldName();
          if (item.isFormField()) {
            String value = Streams.asString(item.openStream(), "UTF-8");
            if (ExtString.hasTrimmedLength(value)) {
              if (parameters.containsKey(name)) {
                parameters.put(name, parameters.get(name) + VALUE_SEPARATOR + value);
              } else {
                parameters.put(name, value);
              }
            }
          } else {
            parameters.put(name, item.getName());
            InputStream in = item.openStream();
            inStreamParams.put(name, ExtFile.readStream(in));
          }
        }
      } else {
        Enumeration<String> paramNames = request.getParameterNames();
        while (paramNames.hasMoreElements()) {
          String paramName = paramNames.nextElement();
          String[] values = request.getParameterValues(paramName);
          if (values != null && values.length > 1) {
            for (String value : values) {
              if (ExtString.hasTrimmedLength(value)) {
                if (parameters.containsKey(paramName)) {
                  parameters.put(paramName, parameters.get(paramName) + VALUE_SEPARATOR + value);
                } else {
                  parameters.put(paramName, value);
                }
              }
            }
            if (!parameters.containsKey(paramName)) {
              parameters.put(paramName, request.getParameter(paramName));
            }
          } else {
            parameters.put(paramName, request.getParameter(paramName));
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Returns the default image showing "No Image Available"
   *
   * @return BufferedImage
   */
  public BufferedImage getDefaultNoImage() {
    try {
      return ImageIO.read(new File(getServletContext().getRealPath("img/no_image.gif")));
    } catch (IOException ex) {
      return null;
    }
  }

  /**
   * Returns a URL used to retrieve an image of the structure of an Amgen compound
   *
   * @param rootID String
   * @param lot String
   * @param width String
   * @param height String
   * @return URL
   */
  public static String getStructureImageURL(ChemMolInput chemMolInput, String width, String height) {
    return getStructureImageURL(chemMolInput, width, height, null);
  }

  /**
   * Returns a URL used to retrieve an image of the structure of an Amgen compound with an optional result key
   *
   * @param rootID String
   * @param lot String
   * @param width String
   * @param height String
   * @param resultKey String
   * @return URL
   */
  public static String getStructureImageURL(ChemMolInput chemMolInput, String width, String height, String resultKey) {
    if (width == null) {
      width = "150";
    }
    if (height == null) {
      height = width;
    }
    String baseURL = "/aig/chemimage?crop=1&width=" + width + "&height=" + height + "&" + chemMolInput.getSource();
    if (resultKey != null) {
      baseURL += "&resultKey=" + resultKey;
    }
    String query = null;

    switch (chemMolInput.getType()) {
      case UNKNOWN:
        throw new IllegalArgumentException("Unknown ChemMolIDType");
      case AMGEN_NAME:
        if (chemMolInput.getInput().length > 1) {
          query = "rootnumber=" + chemMolInput.getInput()[0] + "&lot=" + chemMolInput.getInput()[1];
          break;
        }
      // Fall through
      case ROOT_NUMBER:
        if (chemMolInput.getInput()[0].indexOf('#') > 0) {
          String[] rootLot = chemMolInput.getInput()[0].split("#");
          query = "rootnumber=" + rootLot[0] + "&lot=" + rootLot[1];
        } else {
          query = "rootnumber=" + chemMolInput.getInput()[0];
        }
        break;
      case SUBSTANCE_ID:
        query = "substanceid=" + chemMolInput.getInput()[0];
        break;
      case CDBREGNO:
        query = "cdbregno=" + chemMolInput.getInput()[0];
        break;
      case ID:
        query = "rootnumber=" + chemMolInput.getInput()[0];
        break;
      case SMILES:
        query = "smi=" + chemMolInput.getInput()[0];
        break;
    }

    return baseURL + "&" + query;
  }

  /**
   * Returns a URL used to retrieve an image of a staff member
   *
   * @param loginName String
   * @param width String
   * @param height String
   * @return URL
   */
  public String getStaffImageURL(String login) {
    return request.getContextPath() + "/staffimage.go?login=" + login;
  }

  /**
   * Returns the parameter names as a set
   *
   * @return Set
   */
  public Set<String> getParameterNames() {
    return parameters.keySet();
  }

  /**
   * Returns the parameter map
   *
   * @return Map<String,String>
   */
  public Map<String, String> getParameterMap() {
    return parameters;
  }

  /**
   * Gets a Workbook object from a multipart Request
   *
   * @param parameterName String
   * @return Workbook
   */
  public Workbook getWorkbookFromRequest(String parameterName) {
    Workbook wb = null;
    try {
      String fileName = getParameter(parameterName);
      if (fileName.endsWith(".csv")) {
        wb = CSVReader.toWorkbook(getParameterInputStream(parameterName), Charset.forName("UTF-8"), SpreadsheetVersion.EXCEL2007);
      } else {
        byte[] bytes = ExtFile.readStream(getParameterInputStream(parameterName));
        wb = ExcelUtils.readWorkbook(bytes);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return wb;
  }

  /**
   * Creates a URL for this webapp including protocol://host:port/file
   *
   * @param file String
   * @return URL
   * @throws MalformedURLException
   */
  public URL getServerURL(String file) throws MalformedURLException {
    if (!file.startsWith("/")) {
      file = request.getContextPath() + "/" + file;
    }
    return new URL(request.getScheme(), request.getServerName(), request.getServerPort(), file);
  }

  /**
   * Returns the RG context path
   *
   * @return String
   */
  public String getRGContextPath() {
    return request.getContextPath();
  }

  /**
   * Gets the request as a full url
   *
   * @return String
   */
  public String getRequestURL() {
    StringBuffer url = new StringBuffer(request.getRequestURI());
    if (getParameterNames().size() > 0) {
      StringBuffer params = new StringBuffer();
      for (String paramName : getParameterNames()) {
        if (params.length() > 0) {
          params.append("&");
        }
        params.append(paramName + "=" + getParameter(paramName));
      }
      url.append("?" + params);
    }
    return url.toString();
  }

  /**
   * Returns the HttpServletRequest
   *
   * @return HttpServletRequest
   */
  public HttpServletRequest getHttpServletRequest() {
    return request;
  }

  /**
   * Returns the HttpSession
   *
   * @return HttpServletRequest
   */
  public HttpSession getHttpSession() {
    return request.getSession(false);
  }

  /**
   * Gets a session attribute value for the given key, returning defaultValue is none exists
   *
   * @param key
   * @param defaultValue
   * @return
   */
  public Object getSessionAttribute(String key, Object defaultValue) {
    if (getHttpSession().getAttribute(key) != null) {
      return getHttpSession().getAttribute(key);
    } else {
      return setSessionAttribute(key, defaultValue);
    }
  }

  /**
   * Sets a session attribute for the given key overwriting any currently set. Returns the new value.
   *
   * @param key
   * @param value
   * @return
   */
  public Object setSessionAttribute(String key, Object value) {
    getHttpSession().setAttribute(key, value);
    return getHttpSession().getAttribute(key);
  }

  public MethodType getMethodType() {
    return MethodType.fromRequest(request);
  }

  /**
   * Returns the ServletContext
   *
   * @return HttpServletRequest
   */
  public ServletContext getServletContext() {
    return context;
  }

  /**
   * Returns the value of a parameter
   *
   * @param parameterName String
   * @return String
   */
  public String getParameter(String parameterName) {
    return parameters.get(parameterName);
  }

  /**
   * Returns the parameter as a JSON array or null is not a properly formatted JSON array
   *
   * @param parameterName String
   * @return JSONArray
   */
  public JSONArray getJSONArrayParameter(String parameterName) {
    try {
      return (JSONArray) ExtJSON.toJSON(getParameter(parameterName));
    } catch (Exception e) {
    }
    return null;
  }

  /**
   * Returns the parameter as a JSON object or null is not a properly formatted JSON object
   *
   * @param parameterName String
   * @return JSONObject
   */
  public JSONObject getJSONObjectParameter(String parameterName) {
    try {
      return (JSONObject) ExtJSON.toJSON(getParameter(parameterName));
    } catch (Exception e) {
    }
    return null;
  }

  /**
   * Returns whether the parameter as a JSON array
   *
   * @param parameterName String
   * @return boolean
   */
  public boolean isParameterJSONArray(String parameterName) {
    return (getJSONArrayParameter(parameterName) != null);
  }

  /**
   * Returns the whether parameter as a JSON object
   *
   * @param parameterName String
   * @return boolean
   */
  public boolean isParameterJSONObject(String parameterName) {
    return (getJSONObjectParameter(parameterName) != null);
  }

  /**
   * Returns the value of a parameter or the default value
   *
   * @param parameterName String
   * @param defaultValue String
   * @return String
   */
  public String getParameter(String parameterName, String defaultValue) {
    return (parameters.get(parameterName) == null ? defaultValue : parameters.get(parameterName));
  }

  /**
   * Returns all parameter values with names that match the regex
   *
   * @param parameterNameRegEx String
   * @return List
   */
  public List<String> getParameters(String parameterNameRegEx) {
    List<String> paramValues = new ArrayList<String>();
    Pattern pattern = Pattern.compile(parameterNameRegEx);

    for (String paramName : parameters.keySet()) {
      if (pattern.matcher(paramName).matches()) {
        paramValues.add(getParameter(paramName));
      }
    }
    return paramValues;
  }

  /**
   * Returns all parameter values with names that match the regex which may be delimited by a delimiter regex
   *
   * @param parameterNameRegEx String
   * @param delimiterRegEx String
   * @return List
   */
  public List<String> getParameters(String parameterNameRegEx, String delimiterRegEx) {
    List<String> paramValues = new ArrayList<String>();
    List<String> paramValuesBeforeSplit = getParameters(parameterNameRegEx);

    for (String value : paramValuesBeforeSplit) {
      String[] split = value.split(delimiterRegEx);
      for (String splitValue : split) {
        if (ExtString.hasTrimmedLength(splitValue)) {
          paramValues.add(splitValue);
        }
      }
    }
    return paramValues;
  }

  /**
   * Returns the value of a parameter as a Number or NaN if not possible
   *
   * @param parameterName String
   * @return String
   */
  public Number getParameterNumber(String parameterName) {
    return getParameterNumber(parameterName, Double.NaN);
  }

  /**
   * Returns the value of a parameter as a Number or a default value if not possible
   *
   * @param parameterName String
   * @param defaultValue double
   * @return String
   */
  public Number getParameterNumber(String parameterName, double defaultValue) {
    String paramValue = getParameter(parameterName);
    if (paramValue != null) {
      try {
        return new Double(parameters.get(parameterName));
      } catch (Exception e) {
      }
    }
    return defaultValue;
  }

  /**
   * Returns the value of a parameter as a Number or NaN if not possible. Assumes a x-www-form-urlencoded request.
   *
   * @param request HttpServletRequest
   * @param parameterName String
   * @return String
   */
  public static Number getParameterNumber(HttpServletRequest request, String parameterName) {
    String paramValue = request.getParameter(parameterName);
    if (paramValue != null) {
      try {
        return new Double(paramValue);
      } catch (Exception e) {
      }
    }
    return Double.NaN;
  }

  /**
   * Returns whether a parameter equals a given value
   *
   * @param parameterName String
   * @param testValue String
   * @return boolean
   */
  public boolean doesParameterEqual(String parameterName, String testValue) {
    return (getParameter(parameterName) != null && getParameter(parameterName).equals(testValue));
  }

  /**
   * Returns whether a parameter equals a given value numerically. If the parameter is not a number or the testValue is
   * null or NaN, this returns false.
   *
   * @param parameterName String
   * @param testValue String
   * @return boolean
   */
  public boolean doesParameterEqual(String parameterName, Number testValue) {
    double val = getParameterNumber(parameterName).doubleValue();
    if (Double.isNaN(val) || testValue == null || Double.isNaN(testValue.doubleValue())) {
      return false;
    }
    return (val == testValue.doubleValue());
  }

  /**
   * Returns whether a parameter exists
   *
   * @param parameterName String
   * @return boolean
   */
  public boolean doesParameterExist(String parameterName) {
    return (getParameter(parameterName) != null);
  }

  /**
   * Returns true if the parameter does not exist or has zero- trimmed length
   *
   * @param parameterName String
   * @return boolean
   */
  public boolean isParameterEmpty(String parameterName) {
    return !ExtString.hasTrimmedLength(getParameter("query"));
  }

  /**
   * Returns whether a parameter exists and optionally have non-zero length (excluding whitespace)
   *
   * @param parameterName String
   * @return boolean
   */
  public boolean doesParameterExist(String parameterName, boolean notZeroLength) {
    if (notZeroLength) {
      return (getParameter(parameterName) != null && getParameter(parameterName).trim().length() > 0);
    }
    return doesParameterExist(parameterName);
  }

  /**
   * Creates HRef using a url string from an init parameter. This method checks for values in
   * <initParamName>.<AIG_VERSION> then <initParamName>
   * Definitions beginning with an http are assumed full urls. Definitions beginning with a '/' are prepended with the
   * context path. Otherwise, those are prepended with the <context path>/defaultFolder
   *
   * @param request HttpServletRequest
   * @param initParamName String
   * @param defaultFolder String
   * @return String
   */
  public static String createHRefFromInitParameter(HttpServletRequest request, String initParamName, String defaultFolder) {
    String initParamValue = ConfigurationParameterSource.getConfigParameter(initParamName);
    String contextPath = request.getContextPath();
    if (initParamValue.startsWith("http")) {
      return initParamValue;
    }
    if (initParamValue.startsWith("/")) {
      return contextPath + initParamValue;
    } else {
      return contextPath + "/" + defaultFolder + "/" + initParamValue;
    }
  }

  /**
   * Returns the session login information object
   *
   * @return SessionLogin
   */
  public SessionLogin getSessionLogin() throws AIGException {
    try {
      return SessionLogin.getSessionLogin(request);
    } catch (Exception e) {
      throw new AIGException(Reason.NO_SESSION_USER, e);
    }
  }

  public FASFIdentitySecurityToken getUpdatedFASFToken() {
    FASFIdentity fasfIdentity = null;
    Cookie cookie = getCookie("RG_IDENTITY_DEV");
    if (cookie == null) {
      cookie = getCookie("RG_IDENTITY_TEST");
    }
    if (cookie == null) {
      cookie = getCookie("RG_IDENTITY_PROD");
    }
    if (cookie != null) {
      try {
        fasfIdentity = new FASFEncrypter().decryptFASFIdentity(ExtString.unescape(cookie.getValue()));
      } catch (Exception e) {
      }
    }
    if (fasfIdentity != null) {
      fasfIdentity.setSessionID(getHttpServletRequest().getSession().getId());
      fasfIdentity.setSessionStart(getHttpServletRequest().getSession().getCreationTime());
      fasfIdentity.setLastAccess(getHttpServletRequest().getSession().getLastAccessedTime());
      fasfIdentity.setAttribute("RG_INSTANCE", ConfigurationParameterSource.getRGVersion() + "");
      FASFIdentitySecurityToken fasfToken = new FASFIdentitySecurityToken(fasfIdentity);
      fasfToken.setCookieName("RG_IDENTITY");
      return fasfToken;
    }
    return null;
  }

  /**
   * Returns the current set of security tokens for requests
   *
   * @return
   */
  protected List<SecurityTokenIF> getSecurityTokens() {
    List<SecurityTokenIF> securityTokens = new ArrayList<SecurityTokenIF>();

    // Add the security cookie tokens
    // first siteminder
    try {
      SiteMinderSessionSecurityToken siteMinderSessionSecurityToken = new SiteMinderSessionSecurityToken(getSessionLogin());
      if (ExtString.hasLength(siteMinderSessionSecurityToken.getToken())) {
        securityTokens.add(siteMinderSessionSecurityToken);
      }
    } catch (Exception e) {
    }
    //Default FASF Cookie
    try {
      SecurityTokenIF defaultFasfToken = new FASFSecurityToken(getSessionLogin());
      if (ExtString.hasLength(defaultFasfToken.getToken())) {
        securityTokens.add(defaultFasfToken);
      }
    } catch (Exception e) {
    }
    // RG/FASF token which needs properly updated
    FASFIdentitySecurityToken fasfToken = getUpdatedFASFToken();
    FASFIdentity fasfIdentity = null;

    try {
      fasfIdentity = new FASFEncrypter().decryptFASFIdentity(fasfToken.getToken());
    } catch (Exception e) {
    }
    if (fasfIdentity != null) {
      fasfIdentity.setSessionID(request.getSession().getId());
      fasfIdentity.setSessionStart(request.getSession().getCreationTime());
      fasfIdentity.setLastAccess(request.getSession().getLastAccessedTime());
      fasfToken = new FASFIdentitySecurityToken(fasfIdentity);
      fasfToken.setCookieName("RG_IDENTITY");
    }
    if (fasfToken != null) {
      if (ExtString.hasLength(fasfToken.getToken())) {
        securityTokens.add(fasfToken);
      }
    }
    return securityTokens;
  }

  public ExtNet getHttpClient() {
    return getHttpClient(10000, getSecurityTokens());
  }

  public ExtNet getHttpClient(int connectionTimeoutMillis) {
    return getHttpClient(connectionTimeoutMillis, getSecurityTokens());
  }

  public ExtNet getHttpClient(int connectionTimeoutMillis, Collection<SecurityTokenIF> securityTokens) {
    ExtNet extNet;
    FASFIdentitySecurityToken fasfIdentitySecurityToken = (FASFIdentitySecurityToken) CollectionUtils.find(securityTokens, new Predicate() {
      public boolean evaluate(Object object) {
        return (object instanceof FASFIdentitySecurityToken);
      }
    });
    if (fasfIdentitySecurityToken == null) {
      extNet = new ExtNet(System.getProperty("http.serviceaccount.properties"));
    } else {
      extNet = new ExtNet(fasfIdentitySecurityToken.getIdentity());
    }
    for (SecurityTokenIF token : securityTokens) {
      if (!(token instanceof FASFIdentitySecurityToken)) {
        String escapedToken = ExtString.escape(token.getToken());
        BasicClientCookie cookie = new BasicClientCookie(token.getCookieName(), escapedToken);
        cookie.setPath("/");
        cookie.setDomain("amgen.com");
        Calendar c = Calendar.getInstance();
        c.add(Calendar.YEAR, 1);
        cookie.setExpiryDate(c.getTime());
        extNet.addCookie(cookie);
      }
    }
    extNet.setConnectionTimeout(connectionTimeoutMillis);
    return extNet;
  }

  /**
   * Returns the user's preferences for a give type or null if not set
   *
   * @param preferenceType UserPreferenceType
   * @return UserPreferences
   */
  public UserPreference getUserPreferences(SpecialUserPreferences preferenceType) {
    try {
      if (userPreferences == null) {
        userPreferences = ((AIGSessionLogin) getSessionLogin()).getSpecialUserPreferences();
      }
      return userPreferences.get(preferenceType);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  public UserPreference updateUserPreferences(SpecialUserPreferences preference, String preferenceValue, Document preferenceDocument) {
    try {
      return ((AIGSessionLogin) getSessionLogin()).updateSpecialUserPreferences(preference, preferenceValue, preferenceDocument);
    } catch (Exception ex) {
      ex.printStackTrace();
    }
    return null;

  }

  public InputStream getParameterInputStream(String parameterName) {
    if (inStreamParams.containsKey(parameterName)) {
      return new ByteArrayInputStream(inStreamParams.get(parameterName));
    } else {
      return null;
    }
  }

  /**
   * Overrides the GET method by simply calling doPost
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @throws ServletException
   * @throws IOException
   */
  protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    doPost(req, resp);
  }

  /**
   * Overrides the POST method. This method throws an immediate ServletException. Servlets must extend the AIGServlet
   * class
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @throws ServletException
   * @throws IOException
   */
  protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    throw new ServletException("AIG Servlet must extend AIGServlet");
  }

  /**
   * Returns the servlet parameter names optionally excluding parameters
   *
   * @param excludeParameters List
   * @return Map
   */
  protected List<String> getParameterNames(String[] excludeParameters) {
    return getParameterNames(Arrays.asList(excludeParameters));
  }

  /**
   * Returns the servlet parameter names optionally excluding parameters
   *
   * @param excludeParameters List
   * @return Map
   */
  protected List<String> getParameterNames(List<String> excludeParameters) {
    List<String> paramNames = new ArrayList<String>(getParameterNames());
    paramNames.removeAll(excludeParameters);
    return paramNames;
  }

  /**
   * Returns the servlet parameters optionally excluding parameters
   *
   * @param excludeParameters List
   * @return Map
   */
  protected Map<String, String> getParametersArray(String[] excludeParameters) {
    return getParametersArray(Arrays.asList(excludeParameters));
  }

  /**
   * Returns the servlet parameters optionally excluding parameters
   *
   * @param excludeParameters List
   * @return Map
   */
  protected Map<String, String> getParametersArray(List<String> excludeParameters) {
    Map<String, String> params = new HashMap<String, String>();
    List<String> paramNames = getParameterNames(excludeParameters);
    for (String paramName : paramNames) {
      params.put(paramName, getParameter(paramName));
    }
    return params;
  }

  /**
   * Returns the servlet parameters optionally excluding parameters
   *
   * @param excludeParameters List
   * @return Map
   */
  protected Map<String, String> getParameters(String[] excludeParameters) {
    return getParameters(Arrays.asList(excludeParameters));
  }

  /**
   * Returns the servlet parameters optionally excluding parameters
   *
   * @param excludeParameters List
   * @return Map
   */
  protected Map<String, String> getParameters(List<String> excludeParameters) {
    Map<String, String> params = new HashMap<String, String>();
    List<String> paramNames = getParameterNames(excludeParameters);
    for (String paramName : paramNames) {
      params.put(paramName, getParameter(paramName));
    }
    return params;
  }

  /**
   * Returns a ServiceDetails object for the given service key
   *
   * @param serviceKey String
   * @throws AIGException
   * @return ServiceDetails
   */
  public ServiceDetails getServiceDetails(String serviceKey) throws AIGException {
    return ServiceCache.getServiceCache(request).getService(serviceKey);
  }

  /**
   * Returns a ServiceDetails object for the given service key and if entityLineage is not null, setting the entities
   * form the lineage and amgen login parameters
   *
   * @param serviceKey String
   * @param entityLineage List
   * @return ServiceDetails
   * @throws JDOMException
   * @throws SOAPException
   * @throws IOException
   * @throws ServiceParameterException
   */
  public ServiceDetails getServiceDetails(String serviceKey, List<EntityLineage> entityLineage) throws AIGException {
    ServiceDetails serviceDetails = ServiceCache.getServiceCache(request).getService(serviceKey);
    return setServiceParameters(serviceDetails, entityLineage);
  }

  /**
   * Returns a ServiceDetails object for the given service key setting the amgen login parameters
   *
   * @param initParamName String
   * @return ServiceDetails
   * @throws AIGException
   */
  public ServiceDetails getLooselyCoupledServiceDetails(String initParamName) throws AIGException {
    try {
      ServiceDetails serviceDetails = ServiceCache.getServiceCache(request).getCoreServiceByKeyValue(initParamName);
      return setServiceParameters(serviceDetails, null);
    } catch (Exception e) {
    }
    return null;
  }

  /**
   * Sets the parameters in the ServiceDetails object from up to 3 sources: 1. The given EntityLineage list 2. The
   * current login information 3. The current request parameter collection
   *
   * @param serviceDetails ServiceDetails
   * @param entityLineage List
   * @return ServiceDetails
   * @throws AIGException
   */
  public ServiceDetails setServiceParameters(ServiceDetails serviceDetails, List<EntityLineage> entityLineage) throws AIGException {
    Pattern parameterNamePattern = Pattern.compile("(\\w+)\\[([\\w ]+)\\]");

    ServiceAttributes serviceAttributes = new ServiceAttributes(serviceDetails, getEntityClassManager());
    OILServiceParameterInterceptor oilInterceptor = serviceAttributes.getListenerByType(OILServiceParameterInterceptor.class);

    Map<String, String> requestServiceParameters = getParametersArray(new String[]{
      "key", "data", "serviceKey"
    });

    try {
      if (entityLineage != null) {
        for (EntityLineage lineageElement : entityLineage) {
          String serviceDataTypeCategory = ServiceDataCategory.revertTo(lineageElement.getServiceDataCategory());
          List<ServiceParameter> parameterList = serviceDetails.getParameters(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, serviceDataTypeCategory);
          for (ServiceParameter parameter : parameterList) {
            if (!parameter.getParameterValueSource().equals("lineage")) {
              parameter.setValueFromString(lineageElement.getDataValue());
              parameter.setParameterValueSource("lineage");
              oilInterceptor.setParametersSetByEntityClass(lineageElement.getServiceDataCategory(), parameter);
            }
          }
        }
      }
      setSecurityServiceParameters(serviceDetails);
      // Sets any Amgen Site parameters
			/*
       * List<ServiceParameter> amgenSiteParameters =
       * serviceDetails.getParameters("Service Input Categorization Scheme",
       * "Amgen Site"); if (amgenSiteParameters != null) { for (ServiceParameter
       * amgenSiteParameter : amgenSiteParameters) {
       * amgenSiteParameter.setValueFromString(getSessionLogin().getUserAmgenLocationCode().toString());
       * amgenSiteParameter.setParameterValueSource("session"); } }
       */
      // Set any parameters not previously set using parameters in the request
      for (String requestParameterName : requestServiceParameters.keySet()) {
        String parameterName = requestParameterName;
        ServiceDataCategory parameterCategory = ServiceDataCategory.UNKNOWN;

        Matcher parameterNameMatcher = parameterNamePattern.matcher(parameterName);
        if (parameterNameMatcher.matches()) {
          parameterName = parameterNameMatcher.group(1);
          parameterCategory = ServiceDataCategory.fromString(parameterNameMatcher.group(2));
        }
        ServiceParameter parameter = serviceDetails.getParameter(parameterName);
        if (parameter != null) {
          ServiceParameterType serviceParameterType = parameter.getParameterType();
          if (!parameter.getParameterValueSource().equals("lineage") && !parameter.getParameterValueSource().equals("list")) {
            if (parameter.getCategoryKeyValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME) == null
                    || !parameter.getCategoryKeyValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME).contains("Amgen Session Login")) {
              Set<ServiceDataCategory> keyValues = new HashSet<ServiceDataCategory>(ServiceDataCategory.fromString(parameter.getCategoryKeyValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME)));
              String parameterValue = requestServiceParameters.get(parameterName);

              if (!parameterCategory.equals(ServiceDataCategory.UNKNOWN) && keyValues.contains(parameterCategory)) {
                oilInterceptor.setParametersSetByEntityClass(getEntityClassManager().getEntityClass(parameterCategory), parameter);
              }
              if (ExtString.hasTrimmedLength(parameterValue) && !parameterValue.equals("Please select a value")) {
                switch (serviceParameterType) {
                  case FILE:
                    String tempBaseDir = ConfigurationParameterSource.getConfigParameter(Constants.FILE_UPLOAD_DIRECTORY);
                    File uploadDir = new File(tempBaseDir);
                    File inFile = new File(parameterValue.replaceAll("\\\\", "/"));
                    serviceDetails.setFileParameterValue(parameterName, inFile.getName(), uploadDir, getParameterInputStream(parameterName));
                    break;
                  default:
                    parameter.setValueFromString(parameterValue);
                    break;
                }
              }
            }
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
      throw new AIGException(AIGException.Reason.UNABLE_TO_SET_SERVICE, e);
    }
    return serviceDetails;
  }

  public void setSecurityServiceParameters(ServiceDetails serviceDetails) throws AIGException {
    if (serviceDetails == null) {
      return;
    }
    // Sets any Amgen Session Login parameters
    List<ServiceParameter> amgenSessionLoginParameters = serviceDetails.getParameters(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, "Amgen Session Login");
    if (amgenSessionLoginParameters != null) {
      for (ServiceParameter amgenSessionLoginParameter : amgenSessionLoginParameters) {
        amgenSessionLoginParameter.setValueFromString(getSessionLogin().getRemoteUser());
        amgenSessionLoginParameter.setParameterValueSource("session");
      }
    }
    // Sets any SiteMinder Session Token parameters
    List<ServiceParameter> siteMinderSessionTokenParameters = serviceDetails.getParameters(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, "SiteMinder Session Token");
    if (siteMinderSessionTokenParameters != null) {
      for (ServiceParameter siteMinderTokenParameter : siteMinderSessionTokenParameters) {
        siteMinderTokenParameter.setValueFromString(getSessionLogin().getSmSessionToken());
        siteMinderTokenParameter.setParameterValueSource("session");
      }
    }
    // Sets any SiteMinder Session Identity parameters
    List<ServiceParameter> siteMinderIdentityTokenParameters = serviceDetails.getParameters(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, "SiteMinder Identity Token");
    if (siteMinderIdentityTokenParameters != null) {
      for (ServiceParameter siteMinderTokenParameter : siteMinderIdentityTokenParameters) {
        siteMinderTokenParameter.setValueFromString(getSessionLogin().getSmIdentityToken());
        siteMinderTokenParameter.setParameterValueSource("session");
      }
    }
    try {
      // Sets any Amgen Session Login FASF Encrypted parameters
      List<ServiceParameter> amgenSessionLoginFASFEncryptedParameters = serviceDetails.getParameters(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, "Amgen Session Login FASF Encrypted");
      if (amgenSessionLoginFASFEncryptedParameters != null) {
        FASFEncrypter fasfEncrypter = new FASFEncrypter();
        for (ServiceParameter amgenSessionLoginParameter : amgenSessionLoginFASFEncryptedParameters) {
          amgenSessionLoginParameter.setValueFromString(fasfEncrypter.encrypt(getSessionLogin().getRemoteUser()));
          amgenSessionLoginParameter.setParameterValueSource("session");
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
      throw new AIGException(AIGException.Reason.UNABLE_TO_SET_SERVICE, e);
    }
  }

  /**
   * Executes a service optionally setting parameters passed in as a Map<String,String> and calling the
   * setServiceParameters method. This returns the raw result Object from the service call. This also sets the service
   * log information
   *
   * @param service ServiceDetails
   * @param parameters Map
   * @param setParameters boolean
   * @return Document
   * @throws AIGException
   */
  public Object executeService(ServiceDetails service, Map<String, ?> parameters, boolean setParameters) throws AIGException {
    try {
      if (parameters != null) {
        EntityServiceInvoker.setServiceDetailsParameters(service, parameters, getEntityClassManager());
      }
      if (setParameters) {
        setServiceParameters(service, null);
      }
      Object resultDoc = service.executeService();
      addRequestLogServiceInvocationDetails(service);
      return resultDoc;
    } catch (Exception e) {
      e.printStackTrace();
      throw new AIGException(Reason.UNABLE_TO_RUN_SERVICE, e);
    }
  }

  /**
   * Executes a service optionally calling the setServiceParameters method. This returns a JDOM Document in the format
   * requested, if possible This also sets the service log information
   *
   * @param service ServiceDetails
   * @param resultTypeName String
   * @param setParameters boolean
   * @return Document
   * @throws AIGException
   * @throws TransformerException
   * @throws IOException
   * @throws JDOMException
   * @throws RemoteException
   * @throws ServiceException
   * @throws WSDLException
   */
  public Document executeService2JDocument(ServiceDetails service, String resultTypeName, boolean setParameters) throws AIGException {
    try {
      if (setParameters) {
        setServiceParameters(service, null);
      }
      Document resultDoc = service.executeService2JDocument(resultTypeName, getStandardTransformParameters());
      addRequestLogServiceInvocationDetails(service);
      return resultDoc;
    } catch (Exception e) {
      e.printStackTrace();
      throw new AIGException(Reason.UNABLE_TO_RUN_SERVICE, e);
    }
  }

  /**
   * Executes a service optionally calling the setServiceParameters method. This returns a JDOM Document in the format
   * requested, if possible This also sets the service log information
   *
   * @param service ServiceDetails
   * @param resultTypeName String
   * @param setParameters boolean
   * @return Document
   * @throws AIGException
   * @throws TransformerException
   * @throws IOException
   * @throws JDOMException
   * @throws RemoteException
   * @throws ServiceException
   * @throws WSDLException
   */
  public Document executeService2JDocument(ServiceDetails service, boolean setParameters) throws AIGException {
    try {
      if (setParameters) {
        setServiceParameters(service, null);
      }
      Document resultDoc = service.executeService2JDocument(getStandardTransformParameters());
      addRequestLogServiceInvocationDetails(service);
      return resultDoc;
    } catch (Exception e) {
      e.printStackTrace();
      throw new AIGException(Reason.UNABLE_TO_RUN_SERVICE, e);
    }
  }

  /**
   * Executes a service optionally calling the setServiceParameters method. This returns a JDOM Document in the format
   * requested, if possible This also sets the service log information
   *
   * @param service ServiceDetails
   * @param resultBinding String
   * @param setParameters boolean
   * @return Document
   * @throws AIGException
   */
  public Document executeService2JDocument(ServiceDetails service, BindingDetails resultBinding, boolean setParameters) throws AIGException {
    try {
      if (setParameters) {
        setServiceParameters(service, null);
      }
      Document resultDoc = service.executeService2JDocument(resultBinding, getStandardTransformParameters());
      addRequestLogServiceInvocationDetails(service);
      return resultDoc;
    } catch (Exception e) {
      e.printStackTrace();
      throw new AIGException(Reason.UNABLE_TO_RUN_SERVICE, e);
    }
  }

  /**
   * Executes a service, first retrieving it from the service cache, optionally calling the setServiceParameters method.
   * This returns a JDOM Document in the format requested, if possible This also sets the service log information
   *
   * @param serviceKey String
   * @param resultTypeName String
   * @param setParameters boolean
   * @throws AIGException
   * @throws TransformerException
   * @throws IOException
   * @throws JDOMException
   * @throws RemoteException
   * @throws ServiceException
   * @throws WSDLException
   * @return Document
   */
  public Document executeService2JDocument(String serviceKey, String resultTypeName, boolean setParameters) throws AIGException, TransformerException, IOException, JDOMException, RemoteException,
          ServiceException, WSDLException {
    ServiceDetails service = ServiceCache.getServiceCache(this).getService(serviceKey);
    if (service == null) {
      throw new AIGException("Unknown sevice", Reason.UNABLE_TO_RUN_SERVICE);
    }
    if (setParameters) {
      setServiceParameters(service, null);
    }
    // logServiceDetailsDebug(service);
    Document resultDoc = service.executeService2JDocument(resultTypeName, getStandardTransformParameters());
    addRequestLogServiceInvocationDetails(service);
    return resultDoc;
  }

  /**
   * Returns the basic List of parameters used in RG Transforms
   *
   * @return List
   */
  public List<ServiceParameter> getStandardTransformParameters() {
    List<ServiceParameter> parameters = new ArrayList<ServiceParameter>();
    parameters.add(new ServiceParameter("RG_VERSION", ConfigurationParameterSource.getRGVersion().toString()));
    parameters.add(new ServiceParameter("RG_BASE", getRGContextPath()));
    parameters.add(new ServiceParameter("EXT_BASE", getRGContextPath() + "/ext"));
    try {
      parameters.add(new ServiceParameter("AMGEN_SESSION_LOGIN", getSessionLogin().getRemoteUser()));
    } catch (AIGException ex) {
      ex.printStackTrace();
    }
    parameters.add(new ServiceParameter("RG_SERVER", getHttpServletRequest().getScheme() + "://" + getHttpServletRequest().getServerName() + ":" + getHttpServletRequest().getServerPort()));
    return parameters;
  }

  /**
   * Returns a ServiceResultCacheItem for the result key
   *
   * @param resultKey String
   * @return ServiceResultCacheItem
   */
  public ServiceResultCacheItem getServiceResultCacheItem(String resultKey) {
    return ServiceCache.getServiceCache(request).getServiceResult(resultKey);
  }

  /**
   * Sets a ServiceResultCacheItem of the given result key and format
   *
   * @param resultKey String
   * @param serviceDetails ServiceDetails
   * @param resultFormatName String
   * @param results Object
   * @return ServiceResultCacheItem
   */
  public ServiceResultCacheItem setServiceResultCacheItem(String resultKey, ServiceDetails serviceDetails, String resultFormatName, Object results) {
    ServiceResultCacheItem serviceResultCacheItem = null;
    try {
      if (results == null) {
        return null;
      } else if (results instanceof String) {
        serviceResultCacheItem = ServiceCache.getServiceCache(request).saveServiceResult(resultKey, serviceDetails, resultFormatName, (String) results);
      } else if (results instanceof Document) {
        serviceResultCacheItem = ServiceCache.getServiceCache(request).saveServiceResult(resultKey, serviceDetails, resultFormatName, (Document) results);
      } else if (results instanceof byte[]) {
        serviceResultCacheItem = ServiceCache.getServiceCache(request).saveServiceResult(resultKey, serviceDetails, resultFormatName, (byte[]) results);
      } else {
        return null;
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return serviceResultCacheItem;
  }

  /**
   * Returns a ServiceResultCacheItem of the given result format for the given treenode
   *
   * @param resultKey String
   * @param serviceDetails ServiceDetails
   * @return ServiceResultCacheItem
   */
  public ServiceResultCacheItem setServiceResultCacheItemForTreeNode(String resultKey, ServiceDetails serviceDetails) throws AIGException {
    return ServiceCache.getServiceCache(request).saveServiceResult(resultKey, serviceDetails);
  }

  /**
   * Returns a ClassificationSchemeDetails by its name
   *
   * @param name ClassificationSchemeNames
   * @return ClassificationSchemeDetails
   */
  public ClassificationSchemeDetails getClassificationSchemeDetailsByName(ClassificationSchemeNames name) {
    if (!classificationSchemeDetails.containsKey(name)) {
      UDDIDetails uddiDetails = ServiceCache.getServiceCache(this).getUDDIQuery().getUddiDetails();
      try {
        ClassificationSchemeDetails serviceInputClassificationSchemeDetails = ClassificationSchemeDetails.getClassificationSchemeDetailsByName(uddiDetails, ClassificationSchemeNames.getName(name));
        classificationSchemeDetails.put(name, serviceInputClassificationSchemeDetails);
      } catch (Exception ex) {
      }
    }
    return classificationSchemeDetails.get(name);
  }

  /**
   * Helper method for getting the TreeNodeCache
   *
   * @return TreeNodeCache
   */
  public TreeNodeCache getTreeNodeCache() throws AIGException {
    return TreeNodeCache.getTreeNodeCache(request);
  }

  /**
   * Helper method for getting the ServiceCache
   *
   * @return ServiceCache
   */
  public ServiceCache getServiceCache() throws AIGException {
    return ServiceCache.getServiceCache(request);
  }

  /**
   * addIfNotNull
   *
   * @param invivoDataObj JSONObject
   * @param string String
   * @param string1 String
   */
  public static void addIfNotNull(JSONObject invivoDataObj, String name, String value) {
    if (value != null) {
      try {
        invivoDataObj.put(name, value);
      } catch (JSONException ex) {
      }
    }
  }

  /**
   * addIfNotNull
   *
   * @param invivoDataObj JSONObject
   * @param string String
   * @param string1 String
   */
  public static void addIfNotNull(JSONObject invivoDataObj, String name, JSONObject value) {
    if (value != null) {
      try {
        invivoDataObj.put(name, value);
      } catch (JSONException ex) {
      }
    }
  }

  /**
   * addIfNotNull
   *
   * @param map JSONObject
   * @param name String
   * @param value String
   */
  public static void addIfNotNull(Map map, String name, Object value) {
    if (value != null) {
      map.put(name, value);
    }
  }

  /**
   * returns whether to always use the service cache for results
   *
   * @return boolean
   */
  protected boolean getAlwaysUseServiceCache() {
    return alwaysUseServiceCache;
  }

  public boolean isIsMultiPartRequest() {
    return isMultiPartRequest;
  }

  /**
   * Returns the full path for the servlet given a relative path
   *
   * @param relativePath String
   * @return URL
   */
  protected URL createContextURL(String relativePath) {
    try {
      return new URL("http", request.getServerName(), request.getServerPort(), request.getContextPath() + "/" + relativePath);
    } catch (MalformedURLException ex) {
      ex.printStackTrace();
      return null;
    }
  }

  protected Element processTreeNodes(Element resultNode, List<Element> resultChildNodes, NodeType nodeType, ServiceDataCategory resultDataCategory,
          String parentNodeUUID, String uuid) throws AIGException {
    uuid = (uuid == null ? UUID.randomUUID() + "" : uuid);
    EntityClassManager entityClassManager = getEntityClassManager();
    EntityListCategory entityListCategory = entityClassManager.convertServiceDataCategoryToEntityListCategory(resultDataCategory);

    Element cachedResultNode = ExtXMLElement.copyAttributes(resultNode, new Element("TREENODE"));

    if (resultChildNodes == null) {
      resultChildNodes = resultNode.getChildren("TREENODE");
    }
    if (parentNodeUUID != null) {
      cachedResultNode.setAttribute("PARENTUUID", parentNodeUUID);
    }
    switch (nodeType) {
      case QUERYNODE:
        break;
      case RESULTNODE:
        cachedResultNode.setAttribute("UUID", uuid);
        cachedResultNode.setAttribute("EXPANDED", "true");
        cachedResultNode.setAttribute("NODE_TYPE", NodeType.RESULTNODE + "");
        cachedResultNode.setAttribute("TREENODESRC", request.getContextPath() + "/treenodecacheretrieval.go?uuid=" + uuid);
        cachedResultNode.setAttribute("SERVICE_DATA_TYPE_CATEGORY", resultDataCategory + "");
        cachedResultNode.setAttribute("ENTITY_CATEGORY", entityListCategory + "");
        cachedResultNode.setAttribute("IMAGE", entityClassManager.getEntityClass(entityListCategory).getPluralStyle());
        cachedResultNode.setAttribute("SINGULAR", entityClassManager.getEntityClass(entityListCategory).getSingularStyle());
        cachedResultNode.setAttribute("PLURAL", entityClassManager.getEntityClass(entityListCategory).getPluralStyle());

        if (!ExtString.hasLength(cachedResultNode.getAttributeValue("TEXT"))) {
          cachedResultNode.setAttribute("TEXT", entityClassManager.getEntityClass(entityListCategory).getLabel());
        }

        // if (doesParameterExist("list_id", true)) {
        // EntityList entityList = new EntityList(getParameter("list_id"), new OraSQLManager(), null, AIG_JDBC_CONTEXTPARAM_NAME);
        // ExtXMLElement.addAttribute(cachedResultNode, "TEXT", entityList.getName(), cachedResultNode.getAttributeValue("TEXT"));
        // }
        break;
      case ENTITYNODE:
        EntityListCategory resultEntityType = entityClassManager.convertServiceDataCategoryToEntityListCategory(resultDataCategory);
        TreeNode entityTreeNode = new TreeNode(cachedResultNode);
        EntityRulesIF entityRules = EntityRulesFactory.getInstance().getEntityRules(resultEntityType);
        TreeNode processedEntityTreeNode = entityRules.applyEntityRules(entityTreeNode);
        if (processedEntityTreeNode == null) {
          return null;
        }
        cachedResultNode = processedEntityTreeNode.getNode();

        EntityListCategory entityNodeListCategory = processedEntityTreeNode.getEntityListCategory(entityClassManager);
        EntityClass entityClass = entityClassManager.getEntityClass(entityNodeListCategory);

        cachedResultNode.setAttribute("IMAGE", entityClass.getSingularStyle());
        cachedResultNode.setAttribute("SINGULAR", entityClass.getSingularStyle());
        cachedResultNode.setAttribute("PLURAL", entityClass.getPluralStyle());
        cachedResultNode.setAttribute("NODE_TYPE", NodeType.ENTITYNODE + "");
        cachedResultNode.setAttribute("ENTITY_CATEGORY", entityListCategory + "");
        cachedResultNode.setAttribute("UUID", uuid);
        if (resultChildNodes.size() > 0) {
          cachedResultNode.setAttribute("TREENODESRC", request.getContextPath() + "/treenodecacheretrieval.go?uuid=" + uuid);
        } else {
          cachedResultNode.setAttribute("TREENODESRC", request.getContextPath() + "/entityservicelookup.go?datatype=" + processedEntityTreeNode.getServiceDataCategory() + "&data="
                  + ExtString.escape(processedEntityTreeNode.getServiceData()) + "&uuid=" + uuid);
        }
        break;
      case SERVICENODE:
        cachedResultNode.setAttribute("UUID", uuid);
        cachedResultNode.setAttribute("EXPANDED", "true");
        cachedResultNode.setAttribute("NODE_TYPE", NodeType.SERVICENODE + "");
        cachedResultNode.setAttribute("TREENODESRC", request.getContextPath() + "/treenodecacheretrieval.go?uuid=" + uuid);
        cachedResultNode.setAttribute("SERVICE_DATA_TYPE_CATEGORY", resultDataCategory + "");
        cachedResultNode.setAttribute("ENTITY_CATEGORY", entityListCategory + "");
        cachedResultNode.setAttribute("IMAGE", entityClassManager.getEntityClass(entityListCategory).getPluralStyle());
        cachedResultNode.setAttribute("SINGULAR", entityClassManager.getEntityClass(entityListCategory).getSingularStyle());
        cachedResultNode.setAttribute("PLURAL", entityClassManager.getEntityClass(entityListCategory).getPluralStyle());

        break;
    }

    if (resultChildNodes.size() > 0) {
      cachedResultNode.setAttribute("PAGE", "1");
      cachedResultNode.setAttribute("PAGESIZE", "50");
    }
    TreeNodeCache.getTreeNodeCache(request).addTreeNode(cachedResultNode);
    for (Element resultChildNode : resultChildNodes) {
      String resultChildNodeEntityDataTypeCategory = resultChildNode.getAttributeValue("SERVICE_DATA_TYPE_CATEGORY");
      int childCount = resultChildNode.getChildren("TREENODE").size();
      if (childCount > 0 && resultChildNodeEntityDataTypeCategory == null) {
        ServiceDataCategory firstResultChildNodeEntityDataTypeCategory = ServiceDataCategory.getServiceDataCategory((Element) resultChildNode.getChildren().get(0));
        if (!firstResultChildNodeEntityDataTypeCategory.equals(ServiceDataCategory.UNKNOWN)) {
          processTreeNodes(resultChildNode, null, NodeType.RESULTNODE, firstResultChildNodeEntityDataTypeCategory, uuid, null);
        } else {
          processTreeNodes(resultChildNode, null, NodeType.ENTITYNODE, firstResultChildNodeEntityDataTypeCategory, uuid, null);
        }
      } else {
        processTreeNodes(resultChildNode, null, NodeType.ENTITYNODE, ServiceDataCategory.getServiceDataCategory(resultChildNode), uuid, null);
      }
    }
    return cachedResultNode;
  }

  /**
   * Returns the AmgenEnterpriseEntry for the given UID
   *
   * @param uid
   * @return
   */
  public static AmgenEnterpriseEntry getAmgenEnterpriseEntryFromUID(String uid) {
    try {
      return new AmgenEnterpriseLookup().lookupByUID(uid);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  /**
   * Returns a common EntityClassManager
   *
   * @return the rgCategoryConversions
   */
  public EntityClassManager getEntityClassManager() {
    return entityClassManager;
  }

  /**
   * Returns a CacheManagerIF
   *
   */
  public CacheManagerIF getCacheManager() throws AIGException {
    return CacheManagerFactory.getCacheManagerInstance(getHttpSession());
  }

  /**
   * Prints the query parameters for debugging
   */
  public void printRequest() {
    Debug.print("REQUEST", true, false);
    Debug.print(request.getRequestURI());
    Debug.print(request.getQueryString());
    Debug.print(request.getMethod());
    Set<String> requestParameterNames = getParameterNames();
    for (String paramName : requestParameterNames) {
      Debug.print(paramName + "=" + getParameter(paramName));
    }
    Debug.print("---");
  }

  /**
   * Creates a JSONObject response from the given Collection of AbstractRecords. This is done by appending the
   * resultField key with the elements of the Collection
   *
   * @param resultField
   * @param records
   * @return
   */
  protected JSONObject createResponseJSON(String resultField, Collection<? extends AbstractRecord> records) {
    JSONObject jResults = new JSONObject();
    for (AbstractRecord record : records) {
      try {
        jResults.append(resultField, record);
      } catch (JSONException ex) {
      }
    }
    return jResults;
  }

  /**
   * Prints the query parameters for debugging
   *
   * @param request HttpServletRequest
   */
  public static void printRequest(HttpServletRequest request) {
    Debug.print("REQUEST", true, false);
    Debug.print(request.getRequestURI());
    Debug.print(request.getQueryString());
    Debug.print(request.getMethod());
    Map<String, String[]> requestParameters = request.getParameterMap();
    for (String paramName : requestParameters.keySet()) {
      Debug.print(paramName + "=" + requestParameters.get(paramName)[0]);
    }
    Debug.print("---");
  }

  public ElapsedTime getDebugTimer() {
    return (time == null ? (time = new ElapsedTime()) : time);
  }

  /**
   * Logs the query parameters for debugging
   *
   * @param request HttpServletRequest
   */
  public void logRequest() {
    logRequest(request);
  }

  /**
   * Logs the query parameters for debugging
   *
   * @param request HttpServletRequest
   */
  public static void logRequest(HttpServletRequest request) {
    try {
      StringWriter str = new StringWriter();
      PrintWriter writer = new PrintWriter(str);
      Debug.print(writer, "REQUEST", true, false);
      Debug.print(writer, request.getRequestURI());
      Debug.print(writer, request.getQueryString());
      Debug.print(writer, request.getMethod());
      Map<String, String[]> requestParameters = request.getParameterMap();
      for (String paramName : requestParameters.keySet()) {
        Debug.print(writer, paramName + "=" + requestParameters.get(paramName)[0]);
      }
      Debug.print(writer, "---");
      rgLogger.debug(str);
    } catch (Exception ex) {
    }
  }

  public static void printXMLDebugDoc(Document e) {
    try {
      System.err.println(new XMLOutputter(Format.getPrettyFormat()).outputString(e));
      System.err.flush();
    } catch (Exception ex) {
    }
  }

  public static void printXMLDebugDoc(Element e) {
    try {
      System.err.println(new XMLOutputter(Format.getPrettyFormat()).outputString(e));
      System.err.flush();
    } catch (Exception ex) {
    }
  }

  public static void logServiceDetailsDebug(ServiceDetails sd) { // This one
    try {
      serviceLogger.debug("Service Invocation\n" + sd);
    } catch (Exception ex) {
    }
  }

  public static void logServiceDetailsDebug(ServiceInvocationDetails sd) {
    try {
      serviceLogger.debug("Service Invocation Details\n" + sd);
    } catch (Exception ex) {
    }
  }

  /**
   * printServiceResultsDebug
   *
   * @param resultDocument Document
   */
  public void logServiceResultsDebug(Document resultDocument) {
    try {
      serviceLogger.debug(ExtXMLElement.toPrettyString(resultDocument));
    } catch (Exception ex) {
    }
  }

  /**
   * logServiceResultsDebug
   *
   * @param results ServiceResultCacheItem
   */
  public void logServiceResultsDebug(ServiceResultCacheItem results) {
    try {
      serviceLogger.debug(ExtXMLElement.toPrettyString(results.getResultAsDocument()));
    } catch (Exception ex) {
    }
  }

  public void logToRGLog(Object msg) {
    Debug.print(msg);
    rgLogger.debug(msg);
  }

  public void log(Object msg, Throwable t) {
    rgLogger.debug(msg, t);
  }

  /**
   * Set the ServiceKey reported in the log
   *
   * @param string String
   */
  public void addRequestLogServiceInvocationDetails(ServiceDetails service) {
    if (service != null) {
      if (request.getAttribute("amgen.ri.aig.log.RGSessionLogger.serviceInvocationDetailsList") == null) {
        request.setAttribute("amgen.ri.aig.log.RGSessionLogger.serviceInvocationDetailsList", new ArrayList<ServiceInvocationDetails>());
      }
      List<ServiceInvocationDetails> serviceInvocationDetailsList = (List<ServiceInvocationDetails>) request.getAttribute("amgen.ri.aig.log.RGSessionLogger.serviceInvocationDetailsList");
      serviceInvocationDetailsList.add(service.getServiceInvocationDetails());
    }
  }

  /**
   * Function to create connection with database and to read the xml files used for mapping.
   */
  public SqlSessionFactory getSqlSessionFactory(String factoryID) {
    SqlSessionFactory sqlSessionFactory = null;
    try {
      String resource = "rg.mybatis.config.xml";
      Reader reader = Resources.getResourceAsReader(resource);
      sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader, factoryID);
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
    return sqlSessionFactory;
  }

  public SqlSession getRGDHSqlSession() {
    return getRGDHSqlSession(ExecutorType.SIMPLE);
  }

  public SqlSession getRGDHSqlSession(ExecutorType executorType) {
    return getSqlSessionFactory("rgdh").openSession(executorType);
  }

  public static void close(SqlSession sqlSession) {
    if (sqlSession != null) {
      try {
        sqlSession.close();
      } catch (Throwable t) {
      }
    }
  }

  public static void close(Statement stmt) {
    if (stmt != null) {
      try {
        stmt.close();
      } catch (Throwable t) {
      }
    }
  }

  public static void close(Connection conn) {
    if (conn != null) {
      try {
        conn.close();
      } catch (Throwable t) {
      }
    }
  }

  public static void close(ResultSet rset) {
    if (rset != null) {
      try {
        rset.close();
      } catch (Throwable t) {
      }
    }
  }

  /**
   * Just using this to force JBuilder to see dependencies & include in the war DO NOT REMOVE!!!
   */
  private AIGBase(boolean notforuse) {
    new JAWRProperties();
  }
}
