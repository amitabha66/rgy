package amgen.ri.aig.category.schema2;

import java.io.ObjectStreamException;

/**
 * Defines the types of Aggregated View available in AIG
 */
public enum AggregatedViewType {
    PROJECT_VIEW, ENTITY_TABLE, COMPOUND_INFO_VIEW, UNKNOWN;


    public static AggregatedViewType fromString(String s) {
        if (s == null) {
            return UNKNOWN;
        }
        try {
            return AggregatedViewType.valueOf(s.toUpperCase().replace(' ', '_'));
        } catch (Exception e) {
            return UNKNOWN;
        }
    }

    /**
     * This is necessary to permit Serializable.
     * A Serialized object containing an enum class variable is not de-Serialized properly.
     * This forces de-Serialized enum to be re-created as this enum through the String
     * @return Object
     * @throws ObjectStreamException
     */
    public Object readResolve() throws ObjectStreamException {
        return AggregatedViewType.fromString(this.toString());
    }

}
