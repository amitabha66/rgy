/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.ora;

import java.sql.Timestamp;

/**
 * DAO for the Cache Log
 * @author jemcdowe
 */
public class CacheLogDAO {
  private Timestamp cacheUpdateStart;
  private Timestamp cacheUpdateEnd;
  private int keysUpdated;
  private int servicesUpdated;

  public CacheLogDAO() {
    this.cacheUpdateStart = new Timestamp(System.currentTimeMillis());
  }

  /**
   * @return the cacheUpdateStart
   */
  public Timestamp getCacheUpdateStart() {
    return cacheUpdateStart;
  }

  /**
   * @return the cacheUpdateEnd
   */
  public Timestamp getCacheUpdateEnd() {
    return cacheUpdateEnd;
  }

  /**
   * @return the keysUpdated
   */
  public int getKeysUpdated() {
    return keysUpdated;
  }

  /**
   * @return the servicesUpdated
   */
  public int getServicesUpdated() {
    return servicesUpdated;
  }

  /**
   * @param keysUpdated the keysUpdated to set
   */
  public void setKeysUpdated(int keysUpdated) {
    this.keysUpdated = keysUpdated;
  }

  /**
   * @param servicesUpdated the servicesUpdated to set
   */
  public void setServicesUpdated(int servicesUpdated) {
    this.servicesUpdated = servicesUpdated;
  }

  public void setCacheUpdateEnd() {
    this.cacheUpdateEnd= new Timestamp(System.currentTimeMillis());
  }

}
