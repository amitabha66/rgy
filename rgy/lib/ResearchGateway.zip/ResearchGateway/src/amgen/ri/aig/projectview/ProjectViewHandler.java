package amgen.ri.aig.projectview;

import java.io.IOException;
import java.util.Arrays;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Workbook;
import org.jdom.Document;
import org.jdom.Element;

import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.projectview.filterables.AssayFilterable;
import amgen.ri.aig.projectview.filterables.ProjectViewFilterableIF;
import amgen.ri.aig.projectview.filterables.ProjectViewFilterables;
import amgen.ri.aig.projectview.model.ProjectViewCompoundList;
import amgen.ri.aig.projectview.model.ProjectViewFilter;
import amgen.ri.aig.projectview.model.ProjectViewModel;
import amgen.ri.asf.sa.uddi.ClassificationSchemeNames;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONObject;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;

/**
 * Handler for requests from the ProjectView viewer
 *
 * @version $Id: ProjectViewHandler.java,v 1.5 2013/05/20 15:52:57 jemcdowe Exp
 * $
 */
public class ProjectViewHandler extends AIGServlet {
  /**
   * Holds the viewer request
   */
  private ProjectViewOperation projectViewOperationRequest;

  /**
   * Default constructor
   */
  public ProjectViewHandler() {
    super();
  }

  public ProjectViewHandler(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
    projectViewOperationRequest = ProjectViewOperation.getValue(this);
  }

  /**
   * Creates this AIG Servlet object
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return AIGServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new ProjectViewHandler(req, resp);
  }

  /**
   * Handles the servlet request
   *
   * @throws ServletException
   * @throws IOException
   */
  public void performRequest() throws ServletException, IOException {
    response.setContentType(getServletMimeType());
    ServiceResultCacheItem projectViewResult = getServiceResultCacheItem(getParameter("resultKey"));
    if (projectViewResult == null) {
      return;
    }
    try {
      //updateModel();
      ServiceDetails pvServiceDetails = projectViewResult.getServiceDetails();
      ProjectViewModel projViewModel = (ProjectViewModel) projectViewResult.getProperty("PROJECTVIEWDETAILS");
      /*
       *******************************************************************
       * OPERATION REQUEST TYPE 1:
       * Returns information about the view
       *
       *******************************************************************
       */
      JSONObject settings = new JSONObject();
      switch (projectViewOperationRequest) {
        case SETTINGS:
          for (String viewID : projViewModel.getAvailableViewIDs()) {
            JSONObject availableView = new JSONObject();
            availableView.put("view_list_id", viewID);
            availableView.put("view_list_name", projViewModel.getAvailableView(viewID).getName());
            settings.append("Views", availableView);
          }
          settings.put("CurrentView", projViewModel.getCurrentViewID());
          settings.put("TiledLayoutColumnCount", projViewModel.getTiledLayoutColumnCount());
          settings.put("CurrentCompoundList", projViewModel.getCompoundListID());
          settings.put("ViewLayout", projViewModel.getCurrentViewLayout());
          settings.put("Aggregation", projViewModel.getAggregation());
          settings.put("SD_Column", (projViewModel.getColumnDisplayed("stddev") ? "display" : "not"));
          settings.put("BE_Column", (projViewModel.getColumnDisplayed("be") ? "display" : "not"));

          settings.put("NumberFormat", projViewModel.getNumberFormat());
          settings.put("FractionalDigits", projViewModel.getFractionalDigits());
          settings.put("Project", projViewModel.getProjectName());
          settings.write(response.getWriter());
          return;
        case COMPOUND_LISTS:
          Map<String, ProjectViewCompoundList> compoundLists = projViewModel.getCompoundLists(this);
          for (String listID : compoundLists.keySet()) {
            ProjectViewCompoundList compoundList = compoundLists.get(listID);
            JSONObject availCompoundList = new JSONObject();
            availCompoundList.put("compound_list_id", listID);
            availCompoundList.put("compound_list_name", compoundList.getListName());
            availCompoundList.put("compound_list_type", (compoundList.getListType() == null ? "PRIVATE" : compoundList.getListType()));
            settings.append("CompoundLists", availCompoundList);
          }
          settings.write(response.getWriter());
          return;
        case FILTERABLES:
          response.setContentType("text/plain");
          ProjectViewFilterables filterables = new ProjectViewFilterables(this, null, projViewModel);
          if (doesParameterExist("node", true)) {
            if (doesParameterEqual("node", "filters")) {
              JSONArray categories = filterables.getFilterableCategoriesJSON();
              categories.write(response.getWriter());
            } else {
              JSONArray jCategoryFilterables = filterables.getFilterablesJSON(getParameter("node"));
              jCategoryFilterables.write(response.getWriter());
            }
            return;
          } else if (doesParameterEqual("filter_group", "Assay Results")) {
            JSONObject filterablesJSON = new JSONObject();
            for (ProjectViewFilterableIF filterable : filterables.getFilterables()) {
              if (filterable instanceof AssayFilterable) {
                AssayFilterable assayFilterable = (AssayFilterable) filterable;
                if (doesParameterEqual("assay_code", assayFilterable.getAssay().getAssayCode())
                        && (doesParameterEqual("result_type", assayFilterable.getAssayResults().getResultType())
                        || doesParameterEqual("result_type_id", assayFilterable.getAssayResults().getResultTypeID()))) {
                  filterablesJSON.append("Filterables", assayFilterable.createFilterableJSON());
                  filterablesJSON.write(response.getWriter());
                  return;
                }
              }
            }
          } else if (doesParameterEqual("filter_group", "Compound Properties")) {
            JSONObject filterablesJSON = new JSONObject();
            for (ProjectViewFilterableIF filterable : filterables.getFilterables(getParameter("filter_group"))) {
              if (doesParameterEqual("filterable_name", filterable.getName())) {
                filterablesJSON.append("Filterables", filterable.createFilterableJSON());
                filterablesJSON.write(response.getWriter());
                return;
              }
            }
          }
          JSONObject filterablesJSON = new JSONObject();
          filterablesJSON.put("Filterables", new JSONArray());
          filterablesJSON.write(response.getWriter());
          return;
        case FILTERLIST:
          projViewModel.getFiltersJSON().write(response.getWriter());
          return;
        case COMPOUNDLIST_FILTERSET:
          JSONObject filterSet = new JSONObject();
          ProjectViewFilter filter = projViewModel.getFilterByCompoundList();
          if (filter != null) {
            filterSet.put("filterset", filter.getFilterables().getFilterSetJSON());
          } else {
            filterSet.put("filterset", new JSONArray());
          }
          response.getWriter().println(filterSet);
          return;
      }

      /*
       *******************************************************************
       * OPERATION REQUEST TYPE 2:
       * Options return data used by the view which are not
       * page-related assay data
       *******************************************************************
       */
      switch (projectViewOperationRequest) {
        case REFRESH:
          response.setContentType("text/html");
          ProjectViewServiceView entityServiceAIGProjectView = new ProjectViewServiceView(this);
          entityServiceAIGProjectView.renderServiceResult(projViewModel.getProjectViewDocument(),
                  projectViewResult, pvServiceDetails, request, response);
          return;
        case COMPOUND_INFO:
          response.setContentType("text/xml");
          Document compoundInfoDoc = projViewModel.getCurrentCompoundInfo(this);
          ExtXMLElement.write(compoundInfoDoc, response.getWriter());
          return;
        case DOCUMENTS:
          ServiceDetails documentService = getLooselyCoupledServiceDetails("PROJECTVIEW_DOCUMENTS");
          if (documentService != null) {
            setServiceParameters(documentService, null);
            documentService.setParameterValue(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME, ServiceDataCategory.revertTo(ServiceDataCategory.PROJECT),
                    projViewModel.getProjectName());
            documentService.setParameterValue(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME, ServiceDataCategory.revertTo(ServiceDataCategory.AMGEN_ROOT_ID),
                    projViewModel.getCompoundID());
            Document htmlDocument = executeService2JDocument(documentService, TModelCommonNameFactory.HTMLDEFINITION_tMODELNAME, false);
            ExtXMLElement.write(htmlDocument, response.getWriter(), expandElementsFormat);
          }
          return;
        case PAGE_DOCUMENT_COUNT:
          ServiceDetails documentCountService = getLooselyCoupledServiceDetails("PROJECTVIEW_DOCUMENTCOUNT");
          if (documentCountService != null) {
            documentCountService.setParameterValue(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME,
                    ServiceDataCategory.revertTo(ServiceDataCategory.AMGEN_ROOT_ID),
                    projViewModel.getCompoundID());
            documentCountService.setParameterValue(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME,
                    ServiceDataCategory.revertTo(ServiceDataCategory.PROJECT),
                    projViewModel.getProjectId() + "");
            Document documentCount = documentCountService.executeService2JDocument("DocumentCountByTag Result");

            JSONObject obj = new JSONObject();
            obj.put("projectDocumentCount", ExtString.toDouble(documentCount.getRootElement().getChildText("Project")));
            obj.put("compoundDocumentCount", documentCount.getRootElement().getChildText("Compound"));
            obj.put("totalCount", documentCount.getRootElement().getChildText("TotalCount"));
            response.getWriter().println(obj);
          }
          return;
        case EXPERIMENTS:
          String listID = getParameter("list_id");
          String assayID = getParameter("assay_id");
          String resultType = getParameter("result_type");

          JSONObject expResults = projViewModel.createExperimentJSON(this, listID, assayID, resultType);
          if (expResults != null) {
            expResults.write(response.getWriter());
          }
          return;
        case COMPOUNDLIST_ID:
          int compoundListID = -1;
          if (doesParameterExist("compound_list_id", true) && doesParameterExist("compound_list_type", true)) {
            if (doesParameterEqual("compound_list_type", "RESULTNODE")) {
              compoundListID = projViewModel.createCompoundListFromResultNode(getParameter("compound_list_id"), this);
            } else if (doesParameterEqual("compound_list_type", "VQT")) {
              compoundListID = projViewModel.createCompoundListFromVQT(getParameter("compound_list_id"), this);
            } else if (doesParameterEqual("compound_list_type", "FILTER")) {
              ProjectViewFilter filterQuery = projViewModel.getFilter(getParameter("compound_list_id"));
              if (filterQuery != null) {
                compoundListID = filterQuery.getPvFilterQuery().getList_id();
              }
            } else {
              compoundListID = getParameterNumber("compound_list_id", -1).intValue();
            }
          }
          JSONObject obj = new JSONObject();
          obj.put("list_id", compoundListID);
          response.getWriter().println(obj);
          return;
        case EXPORTEXCEL:
          String[] cmpdRqIDs = new String[]{projViewModel.getCompoundID()};
          if (doesParameterExist("compounds", true)) {
            cmpdRqIDs = getParameter("compounds").trim().split("[\\s,;]+");
          }
          response.setContentType("application/vnd.ms-excel");
          response.addHeader("Content-disposition", "attachment; filename=" + projViewModel.getProjectName().replaceAll("\\s+", "_") + ".xls");

          ProjectViewExcelExporter exporter = new ProjectViewExcelExporter(this, projViewModel);
          Workbook wb = exporter.createHSSFWorkbook(Arrays.asList(cmpdRqIDs));
          wb.write(response.getOutputStream());
          response.getOutputStream().flush();
          return;
        case DEBUG:
          Document viewDoc = projViewModel.getProjectViewDocument();
          Element viewEl = (Element) viewDoc.getRootElement().clone();

          Document pageDoc = projViewModel.getProjectViewPageDocument();
          Element pageEl = (Element) pageDoc.getRootElement().clone();

          Element pvEl = new Element("ProjectView");

          Element viewParentEl = ExtXMLElement.addElement(pvEl, "View");
          viewParentEl.addContent(viewEl);

          Element pageParentEl = ExtXMLElement.addElement(pvEl, "Page");
          pageParentEl.addContent(pageEl);

          ExtXMLElement.addElement(pageEl, "VIEW", projViewModel.createViewJSON().toString());
          ExtXMLElement.addElement(pageEl, "PAGE", projViewModel.createPageJSON(this).toString());

          response.setContentType("text/plain");
          ExtXMLElement.write(new Document(pvEl), response.getWriter());
          return;
      }

      /*
       *******************************************************************
       * OPERATION REQUEST TYPE 3:
       * Options return data used by the view which are page-related
       * assay data
       *******************************************************************
       */
      JSONObject result = null;
      switch (projectViewOperationRequest) {
        case START:
        case PREVIOUS:
        case NEXT:
        case FIRST:
        case LAST:
        case INDEX:
        case RESET_COMPOUNDLIST:
        case COMPOUNDS:
        case X_COMPOUNDLIST:
          if (!projViewModel.pageProjectViewModel(this, projectViewOperationRequest)) {
            getPagingError("Page empty").write(response.getWriter());
            return;
          }
          break;
        case FILTER:
          if (!projViewModel.pageProjectViewModel(this, projectViewOperationRequest)) {
            getPagingError("No results returned by filter").write(response.getWriter());
            return;
          }
          break;
        default:
          break;
      }

      //Common JSON creator for updates
      //logToRGLog(time.getSplit(true));
      result = projViewModel.createPageJSON(this);
      result.write(response.getWriter());
    } catch (Exception e) {
      e.printStackTrace();
      throw new ServletException(e);
    }
  }

  /**
   * getPagingError
   *
   * @param errorMessage String
   * @return Object
   */
  private JSONObject getPagingError(String errorMessage) {
    JSONObject obj = new JSONObject();
    obj.addIfNotNull("error", errorMessage);
    return obj;
  }

  /**
   * Returns the mimetype of the servlet
   */
  protected String getServletMimeType() {
    switch (projectViewOperationRequest) {
      case DOCUMENTS:
        return "text/html";
      default:
        return "application/json";
    }
  }
}
