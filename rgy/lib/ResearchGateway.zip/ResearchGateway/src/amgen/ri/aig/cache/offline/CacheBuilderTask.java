package amgen.ri.aig.cache.offline;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.CacheType;
import amgen.ri.aig.cache.CacheUtils;
import amgen.ri.aig.cache.item.GlobalCacheItem;
import amgen.ri.aig.cache.ora.CacheAdminDao;
import amgen.ri.aig.cache.ora.CacheItemDAO;
import amgen.ri.aig.cache.ora.CacheLogDAO;
import amgen.ri.aig.cache.ora.CacheMapper;
import amgen.ri.aig.cache.ora.OfflineServiceDetails;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.aig.uddi.QueryServiceIF;
import amgen.ri.aig.uddi.QueryServiceLookup;
import amgen.ri.aig.uddi.QuickSearchServiceLookup;
import amgen.ri.aig.uddi.ServiceQuery;
import amgen.ri.aig.uddi.WidgetServiceLookup;
import amgen.ri.asf.sa.uddi.ClassificationSchemeQuery;
import amgen.ri.asf.sa.uddi.RegistryEntryDetails;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.UDDIDetails;
import amgen.ri.asf.sa.uddi.UDDIQuery;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.rg.resource.ResourceFactory;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtObject;
import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.xml.rpc.ServiceException;
import javax.xml.soap.SOAPException;
import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.jcs.utils.timing.ElapsedTimer;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.SimpleLayout;
import org.jdom.JDOMException;

/**
 *
 * @author jemcdowe
 */
public class CacheBuilderTask implements Callable<CacheLogDAO>, Runnable {

  private final Class[] queryServiceClasses = {
    QuickSearchServiceLookup.class,
    QueryServiceLookup.class,
    WidgetServiceLookup.class
  };

  private UDDIQuery uddiQuery;
  private CacheLogDAO cacheLogDAO;
  private ExecutorService executor;
  private File logFile;

  public CacheBuilderTask(File logFile) throws MalformedURLException, JDOMException, SOAPException, IOException {
    String uddiURL = ConfigurationParameterSource.getConfigParameter("UDDI_QUERY_URL");
    this.logFile = logFile;
    if (uddiURL == null) {
      uddiQuery = new UDDIQuery(null);
    } else {
      uddiQuery = new UDDIQuery(new UDDIDetails(uddiURL));
    }
    TModelCommonNameFactory.init(uddiURL);
  }

  CacheBuilderTask(ExecutorService executor, File logFile) throws JDOMException, SOAPException, IOException {
    this(logFile);
    this.executor = executor;
  }

  public CacheLogDAO call() throws Exception {
    run();
    return cacheLogDAO;
  }

  public void run() {
    Logger logger = Logger.getLogger(this.getClass());
    //FileAppender appender= new FileAppender(new PatternLayout("%m%n"), "/temp/unable2connectservices.txt");
    //logger.addAppender(appender);
    if (logFile != null) {
      try {
        logger.addAppender(new FileAppender(new PatternLayout("%d{MM/dd/yyyy H:m:s:S},%m%n"), logFile.getAbsolutePath(), true));
      } catch (IOException ex) {
        java.util.logging.Logger.getLogger(CacheBuilderTask.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
      }
    } else {
      logger.addAppender(new ConsoleAppender(new PatternLayout("%d{MM/dd/yyyy H:m:s:S},%m%n")));
    }
    logger.setLevel(Level.INFO);
    cacheLogDAO = new CacheLogDAO();
    ElapsedTimer timer = new ElapsedTimer();
    logger.info("Start Update");
    logger.info("Using- " + uddiQuery.getUddiDetails().getInquireURI());
    ResourceFactory resourceImpl = new CacheBuilderResourceFactory();
    SqlSession sqlSession = null;
    boolean performCommit = true;
    try {
      sqlSession = resourceImpl.getSqlSession("rg-direct");
      //Load Key:ClassificationSchemeQuery map from the db
      CacheContents cacheContents = getCacheContents(sqlSession);

      //Add Key:ClassificationSchemeQuery map from queryServiceClasses
      for (Class queryServiceClass : queryServiceClasses) {
        QueryServiceIF queryService = (QueryServiceIF) queryServiceClass.getConstructor(new Class[0]).newInstance(new Object[0]);
        Collection<ServiceQuery> serviceQueries = queryService.getCacheServiceQueries();
        for (ServiceQuery serviceQuery : serviceQueries) {
          if (serviceQuery != null) {
            Set<ClassificationSchemeQuery> queries = new HashSet<ClassificationSchemeQuery>();
            String key = CacheUtils.constructQueryKey(serviceQuery);

            if (serviceQuery.hasResultTypes()) {
              for (String resultType : serviceQuery.getResultTypes()) {
                ClassificationSchemeQuery query = (ClassificationSchemeQuery) ExtObject.copy(serviceQuery.getClassificationSchemeQuery());
                query.setResultType(resultType);
                queries.add(query);
              }
            } else {
              queries.add(serviceQuery.getClassificationSchemeQuery());
            }
            cacheContents.getClassificationSchemeQueryMap().replaceValues(key, queries);
          }
        }
      }

      if (!clearCache(sqlSession)) {
        performCommit = false;
        throw new SQLException("Caching already in progress");
      }

      Set<String> uddiQueryServiceKeys = new HashSet<String>();
      uddiQuery.setMsgLogger(logger);
      int queryKeyCounter = 0;
      for (String queryKey : cacheContents.getClassificationSchemeQueryMap().keySet()) {
        Set<String> serviceKeys = new HashSet<String>();
        for (ClassificationSchemeQuery query : cacheContents.getClassificationSchemeQueryMap().get(queryKey)) {
          logger.info("Executing Query..");
          CacheUtils.logQuery(query, logger);
          List<String> keys = uddiQuery.findServiceKeys(query, query.getResultType(), true);
          logger.info("Returned " + keys.size() + " keys\n");
          logger.info("\t" + StringUtils.join(keys, ";") + "\n");
          serviceKeys.addAll(uddiQuery.findServiceKeys(query, query.getResultType(), true));
          queryKeyCounter++;
        }
        putInCache(sqlSession, CacheType.SERVICEQUERY, new GlobalCacheItem(queryKey, new ArrayList<String>(serviceKeys)));
        uddiQueryServiceKeys.addAll(serviceKeys);
        //logger.info(queryKey + "\n" + serviceKeys);
      }
      cacheLogDAO.setKeysUpdated(queryKeyCounter);
      logger.info("Loading " + uddiQueryServiceKeys.size() + " UDDI Query Services..");
      int serviceCounter = addServicesToCache(uddiQueryServiceKeys, true, sqlSession, logger);

      Set<String> otherServiceKeys = new HashSet<String>(cacheContents.getServiceKeys());
      otherServiceKeys.removeAll(uddiQueryServiceKeys);
      logger.info("Loading " + otherServiceKeys.size() + " Other Services..");
      serviceCounter += addServicesToCache(otherServiceKeys, false, sqlSession, logger);

      cacheLogDAO.setServicesUpdated(serviceCounter);
      cacheLogDAO.setCacheUpdateEnd();
      sqlSession.getMapper(CacheMapper.class).insertCacheLog(cacheLogDAO);
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      if (performCommit) {
        resourceImpl.commitAndClose(sqlSession);
        logger.info("Update Complete. [" + timer.getElapsedTime() / 1000 / 60 + " min]");
      } else {
        resourceImpl.close(sqlSession);
        logger.info("Update Cancelled. [" + timer.getElapsedTime() / 1000 / 60 + " min]");
      }
      if (executor != null) {
        executor.shutdownNow();
      }
    }
  }

  private int addServicesToCache(Collection<String> serviceKeys, boolean saveOfflineServices, SqlSession sqlSession, Logger logger) throws AIGException {
    int serviceCounter = 0;
    for (String serviceKey : serviceKeys) {
      try {
        ServiceDetails serviceDetails = new ServiceDetails(uddiQuery.getUddiDetails(), serviceKey);
        serviceDetails.setMessageLogger(logger);

        ServiceAttributes serviceAttributes = new ServiceAttributes(serviceDetails);
        if (serviceAttributes.isWidget()) {
          if (checkURLActive(serviceDetails, serviceAttributes, 10000)) {
            putInCache(sqlSession, CacheType.SERVICE, new GlobalCacheItem(serviceDetails));
            logger.info("Added " + serviceDetails + "to cache.");
            serviceCounter++;
          }
        } else if (serviceDetails.isActive(10000) && serviceDetails.isSDValid()) {
          putInCache(sqlSession, CacheType.SERVICE, new GlobalCacheItem(serviceDetails));
          logger.info("Added " + serviceDetails + "to cache.");
          serviceCounter++;
        } else {
          throw new ServiceException("");
        }
      } catch (Exception e) {
        logger.info("Offline " + serviceKey);
        if (saveOfflineServices) {
          OfflineServiceDetails offlineServiceDetails = new OfflineServiceDetails(serviceKey);
          putInCache(sqlSession, CacheType.SERVICE, new GlobalCacheItem(offlineServiceDetails));
        }
      }
    }
    return serviceCounter;
  }

  private CacheContents getCacheContents(SqlSession sqlSession) {
    CacheContents cacheContents = new CacheContents();
    CacheMapper mapper = sqlSession.getMapper(CacheMapper.class);
    CacheItemDAO item = new CacheItemDAO("GLOBAL");
    mapper.getQueryKeys(item);
    cacheContents.addClassificationSchemeQueryMap(item.getClassificationSchemeQueries());

    CacheItemDAO items = new CacheItemDAO("GLOBAL");
    mapper.getAllCacheItems(items);
    cacheContents.addServiceKeys(items.getCacheItemKeys());

    return cacheContents;
  }

  private void putInCache(SqlSession sqlSession, CacheType cacheType, GlobalCacheItem obj) throws AIGException {
    CacheMapper mapper = sqlSession.getMapper(CacheMapper.class);
    CacheItemDAO item = new CacheItemDAO(cacheType, "GLOBAL", obj.getKey(), obj);

    mapper.putCacheItem(item);
  }

  private boolean clearCache(SqlSession sqlSession) throws AIGException {
    CacheMapper mapper = sqlSession.getMapper(CacheMapper.class);
    CacheAdminDao cacheAdminDao = new CacheAdminDao();
    mapper.clearAllGlobalCache(cacheAdminDao);
    return cacheAdminDao.isSuccess();
  }

  private boolean checkURLActive(RegistryEntryDetails registryEntry, ServiceAttributes serviceAttributes, int connectionTimeoutMillis) throws IOException {
    int responseCode = HttpURLConnection.HTTP_BAD_REQUEST;
    if (serviceAttributes.isWidget()) {
      try {
        responseCode = registryEntry.getHttpResponseCode(serviceAttributes.getWidgetURL(), connectionTimeoutMillis);
      } catch (SSLPeerUnverifiedException ssle) {
        //Problem with the cert- but let it pass
        responseCode = HttpURLConnection.HTTP_UNAUTHORIZED;
      }
    }
    //getMessageLogger().debug("Testing: (" + this + ") url=" + overviewDocumentURL + " Response code: " + responseCode);
    boolean success;
    switch (responseCode) {
      //Definately BAD
      //4xx Client Errors- Failure Responses
      case HttpURLConnection.HTTP_BAD_REQUEST: //HTTP Status-Code 400: Bad Request.
      case HttpURLConnection.HTTP_PAYMENT_REQUIRED: //HTTP Status-Code 402: Payment Required.
      case HttpURLConnection.HTTP_FORBIDDEN: //HTTP Status-Code 403: Forbidden.
      case HttpURLConnection.HTTP_NOT_FOUND: //HTTP Status-Code 404: Not Found.
      case HttpURLConnection.HTTP_BAD_METHOD: //HTTP Status-Code 405: Method Not Allowed.
      case HttpURLConnection.HTTP_NOT_ACCEPTABLE: //HTTP Status-Code 406: Not Acceptable.
      case HttpURLConnection.HTTP_PROXY_AUTH: //HTTP Status-Code 407: Proxy Authentication Required.
      case HttpURLConnection.HTTP_CLIENT_TIMEOUT: //HTTP Status-Code 408: Request Time-Out.
      case HttpURLConnection.HTTP_CONFLICT: //HTTP Status-Code 409: Conflict.
      case HttpURLConnection.HTTP_GONE: //HTTP Status-Code 410: Gone.
      case HttpURLConnection.HTTP_LENGTH_REQUIRED: //HTTP Status-Code 411: Length Required.
      case HttpURLConnection.HTTP_PRECON_FAILED: //HTTP Status-Code 412: Precondition Failed.
      case HttpURLConnection.HTTP_ENTITY_TOO_LARGE: //HTTP Status-Code 413: Request Entity Too Large.
      case HttpURLConnection.HTTP_REQ_TOO_LONG: //HTTP Status-Code 414: Request-URI Too Large.
      case HttpURLConnection.HTTP_UNSUPPORTED_TYPE: //HTTP Status-Code 415: Unsupported Media Type.
        success = false;
        break;

      //Definately BAD
      //5xx Client Errors- Failure Responses         
      case HttpURLConnection.HTTP_NOT_IMPLEMENTED: //HTTP Status-Code 501: Not Implemented.
      case HttpURLConnection.HTTP_BAD_GATEWAY: //HTTP Status-Code 502: Bad Gateway.
      case HttpURLConnection.HTTP_UNAVAILABLE: //HTTP Status-Code 503: Service Unavailable.
      case HttpURLConnection.HTTP_GATEWAY_TIMEOUT: //HTTP Status-Code 504: Gateway Timeout.
      case HttpURLConnection.HTTP_VERSION: //HTTP Status-Code 505: HTTP Version Not Supported.     
        success = false;
        break;

      //Probably OK
      //4xx Client Errors- Acceptable Responses
      case HttpURLConnection.HTTP_UNAUTHORIZED: //HTTP Status-Code 401: Unauthorized. Acceptable because the execute call should set the auth.
        success = true;
        break;

      //Maybe OK        
      //5xx Client Errors- Acceptable Responses          
      case HttpURLConnection.HTTP_INTERNAL_ERROR: //HTTP Status-Code 500: Internal Server Error.
        success = true;
        break;

      //All Good
      //Other Client Status- Acceptable Responses
      default:
        success = true;
        break;
    }
    return success;
  }
}
