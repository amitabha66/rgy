
/*
 *   UserPreferenceGroup
 *   RDBData wrapper class for UserPreferenceGroup
 *   $Revision: 1.2 $
 *   Created: Jeffrey McDowell, 25 Oct 2010
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.preferences;


import java.lang.reflect.Field;

import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.SQLManagerIF;

/**
 *   RDBData wrapper class for RGPreferenceGroup. These are the groups of RG preferences. Note that
 *   RGPreferenceGroup with rg_preference_group_id=0 are system preferences
 *   @version $Revision: 1.2 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class RGPreferenceGroup extends RdbData {
    protected int rg_preference_group_id;
    protected String preference_group;
    protected int display_order;
    protected String editable;

    /**
     * Default Constructor
     */
    public RGPreferenceGroup() {
        super();
    }
    /**
     * RdbData Constructor
     */
    public RGPreferenceGroup(String rg_preference_group_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.rg_preference_group_id= Integer.parseInt(rg_preference_group_id);
    }

    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return rg_preference_group_id+"";
    }
    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }
    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }
    /** This method returns the name of the table. */
    protected String getTableName() {
        return "RG_PREFERENCE_GROUP";
    }

    /** Get value for preference_group */
    public String getPreference_group() {
        return (String)get("preference_group");
    }
    /** Get value for editable */
    public String getEditable() {
        return (String)get("editable");
    }

}
