package amgen.ri.aig.entity.assay;

import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletContext;
import org.jdom.Document;
import org.jdom.Element;

/**
 * Handle Assay Result Type Operations-
 * 1. Ordering
 * 2. Result type name - ID mapping
 *
 * @version $Id: AssayResultTypeOperations.java,v 1.1 2013/07/09 18:32:09 jemcdowe Exp $
 */
public class AssayResultTypeOperations {
    private static final String[] RESULT_TYPE_ORDERING = new String[] {
            "IC50 IP", "IC50 IP external", "IC50 external", "IC50 flank",
            "IC50 flank external", "IC50 transit", "IC50 transit external",
            "IC50 est.",
            "EC50 IP", "EC50 IP external", "EC50 external", "EC50 flank",
            "EC50 transit", "EC50 transit external", "EC50 est.",
            "POC", "POC external",
            "%Bound", "%Bound external",
            "%Inhib", "%Inhib external",
            "%Turnover", "%Turnover external",
            "CL in vitro", "CL in vitro external",
            "Solubility"
    };
    private URL assayResultTypesURL;
    private boolean assayDataSet;
    private Map<String, Integer> resultTypeOrderingMap;
    private Map<String, Integer> resultType2IDMap;
    private Map<Integer, String> resultID2TypeMap;

    private static AssayResultTypeOperations instance;


    /**
     * Private constructor for the static instance
     *
     * @param context ServletContext
     */
    private AssayResultTypeOperations(ServletContext context) {
        resultTypeOrderingMap = new HashMap<String, Integer>();
        for (int i = 0; i < RESULT_TYPE_ORDERING.length; i++) {
            resultTypeOrderingMap.put(RESULT_TYPE_ORDERING[i], i);
        }
        try {
            assayResultTypesURL = new URL(ConfigurationParameterSource.getConfigParameter("ASSAY_RESULT_TYPES"));
        } catch (MalformedURLException ex) {
            System.err.println("WARNING: Unable to load assay result types Data");
        }
        assayDataSet = false;
    }
    /**
     * Private constructor for the static instance
     *
     * @param context ServletContext
     */
    private AssayResultTypeOperations(URL assayResultTypesURL) {
        resultTypeOrderingMap = new HashMap<String, Integer>();
        for (int i = 0; i < RESULT_TYPE_ORDERING.length; i++) {
            resultTypeOrderingMap.put(RESULT_TYPE_ORDERING[i], i);
        }
        this.assayResultTypesURL= assayResultTypesURL;
        assayDataSet = false;
    }

    /**
     * Initialize the static instance- call once by the ContextListener
     *
     * @param context ServletContext
     * @return AssayResultTypeOperations
     */
    public static AssayResultTypeOperations init(ServletContext context) {
        if (instance == null) {
            instance = new AssayResultTypeOperations(context);
        }
        return instance;
    }
    /**
     * Initialize the static instance- call once by the ContextListener
     *
     * @param context ServletContext
     * @return AssayResultTypeOperations
     */
    public static AssayResultTypeOperations init(URL assayResultTypesURL) {
        if (instance == null) {
            instance = new AssayResultTypeOperations(assayResultTypesURL);
        }
        return instance;
    }

    /**
     * Get the static instance
     *
     * @return AssayResultTypeOperations
     */
    public static AssayResultTypeOperations getInstance() {
        if (instance == null) {
            throw new IllegalArgumentException("AssayResultTypeOperations not initialized.");
        }
        if (!instance.assayDataSet) {
            instance.setAssayResults();
        }
        return instance;
    }

    /**
     * Sets the result name:id, id:name maps
     *
     * @param context ServletContext
     */
    private synchronized void setAssayResults() {
        if (resultType2IDMap == null || resultID2TypeMap == null) {
            resultType2IDMap = new HashMap<String, Integer>();
            resultID2TypeMap = new HashMap<Integer, String>();
            try {
                Document resultTypeDoc = ExtXMLElement.toDocument(assayResultTypesURL);
                List<Element> optionEls = ExtXMLElement.getXPathElements(resultTypeDoc, "//Option");
                for (Element optionEl : optionEls) {
                    String resultType = optionEl.getChildText("Label").trim();
                    String resultTypeID = optionEl.getChildText("Value");
                    resultType2IDMap.put(resultType, new Integer(resultTypeID));
                    resultID2TypeMap.put(new Integer(resultTypeID), resultType);
                }
            } catch (Exception e) {
                System.err.println("Unable to load result types. " + e);
            }
        }
        assayDataSet = true;
    }

    /**
     * Gets s ResultType for an id
     *
     * @param resultTypeID int
     * @return String
     */
    public String getResultType(int resultTypeID) {
        return resultID2TypeMap.get(resultTypeID);
    }

    /**
     * Converts a list if result types to result ids. If any are integers and in the resultID2TypeMap, they are added as well
     *
     * @param resultTypes int
     * @return String
     */
    public List<Integer> toResultTypeIDs(List<String> resultTypes) {
        List<Integer> resultIDs= new ArrayList<Integer>();
        if (resultTypes!= null) {
            for (String resultType : resultTypes) {
                if (resultType2IDMap.containsKey(resultType)) {
                    resultIDs.add(resultType2IDMap.get(resultType));
                } else if (ExtString.isAInteger(resultType) && resultID2TypeMap.containsKey(ExtString.toInteger(resultType))) {
                    resultIDs.add(ExtString.toInteger(resultType));
                }
            }
        }
        return resultIDs;
    }

    /**
     * Verifies a list of result types. If any values are Integers, this checks
     * and in the resultID2TypeMap, they are added as well as the result type
     * names returning a verified List.
     *
     * @param resultTypes int
     * @return String
     */
    public List<String> verifyResultTypes(List<String> resultTypes) {
        List<String> verifiedResults= new ArrayList<String>();
        if (resultTypes!= null) {
            for (String resultType : resultTypes) {
                if (ExtString.isAInteger(resultType) && resultID2TypeMap.containsKey(ExtString.toInteger(resultType))) {
                    verifiedResults.add(resultID2TypeMap.get(ExtString.toInteger(resultType)));
                } else if (resultType2IDMap.containsKey(resultType)) {
                    verifiedResults.add(resultType);
                }
            }
        }
        return verifiedResults;
    }
    /**
     * Verifies a list of result types IDs returning a verified List.
     */
    public List<Integer> verifyResultTypeIDs(List<Integer> resultTypeIDs) {
        List<Integer> verifiedResults= new ArrayList<Integer>();
        if (resultTypeIDs!= null) {
            for (Integer resultType : resultTypeIDs) {
                if (resultID2TypeMap.containsKey(resultType)) {
                    verifiedResults.add(resultType);
                }
            }
        }
        return verifiedResults;
    }

    /**
     * Gets an id for a ResultType
     *
     * @param resultType String
     * @return int
     */
    public int getResultTypeID(String resultType) {
        return (resultType2IDMap.containsKey(resultType) ? resultType2IDMap.get(resultType) : 0);
    }

    /**
     * Gets the ResultType order for a ResultType
     *
     * @param resultType String
     * @return int
     */
    public int getResultTypeOrder(String resultType) {
        return (resultTypeOrderingMap.containsKey(resultType) ? resultTypeOrderingMap.get(resultType) : -1);
    }

    /**
     * Gets the ResultType order for an order index
     *
     * @param orderIndex int
     * @return String
     */
    public String getResultTypeForOrder(int orderIndex) {
        if (orderIndex >= 0 && orderIndex < RESULT_TYPE_ORDERING.length) {
            return RESULT_TYPE_ORDERING[orderIndex];
        }
        return null;
    }

    /**
     * Creates an assay parameter from an input of the form
     * assaycode:resulttype;assaycode:resulttype1,resulttype2,resulttype3
     * converting to
     * assaycode:resulttypeID;assaycode:resulttypeID1,resulttypeID2,resulttypeID3
     *
     *
     * @param parameter String
     * @return String
     */
    public String createAssayParameter(String parameter) {
        String assayParameter = null;
        List<String> assayCodes = ExtString.splitToList(parameter, ";");
        for (String assayCode : assayCodes) {
            String[] codeResultTypes = assayCode.trim().split(":");
            switch (codeResultTypes.length) {
                case 1:
                    assayParameter = ExtString.addToDelimitedList(assayParameter, assayCode, " ");
                    break;
                case 2:
                    List<String> resultTypes = ExtString.splitToList(codeResultTypes[1], ",");
                    List<Integer> resultTypeIDs = new ArrayList<Integer>();
                    for (String resultType : resultTypes) {
                        if (ExtString.isANumber(resultType)) {
                            resultTypeIDs.add(((Number) ExtString.toNumber(resultType)).intValue());
                        } else {                         
                            int resultTypeID = getResultTypeID(resultType.trim());
                            if (resultTypeID !=0) {
                                resultTypeIDs.add(resultTypeID);
                            }
                        }
                    }
                    assayParameter = ExtString.addToDelimitedList(assayParameter, codeResultTypes[0] + ":" + ExtString.join(resultTypeIDs, ','), ";");
                    break;
                default:
                    break;
            }
        }
        return assayParameter;
    }


}
