package amgen.ri.aig.cache.item;

import amgen.ri.xml.ExtXMLElement;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Iterables;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.jdom.Document;

/**
 * Base class for cache items
 *
 * @version $id$
 */
public abstract class AbstractCacheItem implements CacheItemIF, Serializable {
  static final long serialVersionUID = 8679797546524632816L;

  public enum ResultRelationshipType {
    RAW,
    SOURCE_TREENODES,
    SOURCE_TABLE,
    SOURCE_PROJECTVIEW
  };
  private String key;
  private Serializable cacheObject;
  private String cacheString;
  private Map<String, Object> properties;
  private ArrayListMultimap<ResultRelationshipType, String> relatedResultKeyMap; //Map of related AbstractCacheItem keys (relationship: List<keys>)
  private Date cacheDate;
  //Archived items (required for old, saved objects)
  private Map<ResultRelationshipType, String> relatedResultKey;

  public AbstractCacheItem() {
    this(null);
  }

  public AbstractCacheItem(String key) {
    properties = new HashMap();
    relatedResultKeyMap = ArrayListMultimap.create();
    if (key == null) {
      key = UUID.randomUUID() + "";
    }
    this.key = key;
  }

  public void setCacheObject(Serializable cacheObject) {
    this.cacheObject = cacheObject;
  }

  public String getKey() {
    return key;
  }

  public Object getCacheObject() {
    return cacheObject;
  }

  public Map<String, Object> getProperties() {
    return properties;
  }

  public String getCacheString() {
    return cacheString;
  }

  public byte[] getResultBytes() {
    if (getCacheObject() != null) {
      if (getCacheObject() instanceof byte[]) {
        return (byte[]) getCacheObject();
      } else if (getCacheObject() instanceof String) {
        return ((String) getCacheObject()).getBytes();
      } else if (getCacheObject() instanceof Document) {
        return ExtXMLElement.toString((Document) getCacheObject()).getBytes();
      }
    }
    return new byte[0];
  }

  public Date getCacheDate() {
    return cacheDate;
  }

  public Object getProperty(String key) {
    return properties.get(key);
  }

  public void setProperty(String key, Object property) {
    this.properties.put(key, property);
  }

  public void setProperties(Map<String, Object> properties) {
    if (properties != null) {
      this.properties = properties;
    }
  }

  public void setCacheString(String cacheString) {
    this.cacheString = cacheString;
  }

  public void setCacheDate() {
    this.cacheDate = new Date();
  }

  /**
   * Gets the first related result keys
   *
   * @return the value of relatedResultKey
   */
  public String getRelatedResultKey(ResultRelationshipType relationship) {
    return Iterables.getFirst(relatedResultKeyMap.get(relationship), null);
  }

  /**
   * Get all related result keys or an empty List if none
   *
   * @return the value of relatedResultKey
   */
  public List<String> getRelatedResultKeys(ResultRelationshipType relationship) {
    return (relatedResultKeyMap.containsKey(relationship) ? relatedResultKeyMap.get(relationship) : new ArrayList<String>());
  }

  /**
   * Adds the keys of a related result
   */
  public void addRelatedResultKey(ResultRelationshipType relationship, String... relatedResultKey) {
    this.relatedResultKeyMap.putAll(relationship, Arrays.asList(relatedResultKey));
  }
}
