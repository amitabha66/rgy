/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.constants;

import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jemcdowe
 */
public final class FileConstants {
  public static final String RG_SERVICEACCOUNT_PROPERTIES = "/ad.serviceaccount.properties";

  /**
   * Returns the RG_SERVICEACCOUNT_PROPERTIES as a Properties object
   * @return 
   */
  public static Properties getRGServiceAccountProperties() {
    try {
      Properties serviceAccountProperties = new Properties();
      serviceAccountProperties.load(FileConstants.class.getResourceAsStream(FileConstants.RG_SERVICEACCOUNT_PROPERTIES));
      return serviceAccountProperties;
    } catch (IOException ex) {
      Logger.getLogger(FileConstants.class.getName()).log(Level.SEVERE, null, ex);
    }
    return null;
  }
}
