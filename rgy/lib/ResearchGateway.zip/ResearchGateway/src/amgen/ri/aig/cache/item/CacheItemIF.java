/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.item;

import java.util.Map;

/**
 *
 * @author jemcdowe
 */
public interface CacheItemIF {

  String getKey();

  Map<String, Object> getProperties();

  Object getProperty(String key);

  void setProperties(Map<String, Object> properties);

  void setProperty(String key, Object property);

  Object getCacheObject();
  
}
