/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache;

import amgen.ri.aig.uddi.ServiceQuery;
import amgen.ri.asf.sa.uddi.ClassificationSchemeQuery;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 *
 * @author jemcdowe
 */
public class CacheUtils {

  /**
   * Constructs a canonical key for the query.
   * This uses a series of TreeSets to maintain natural order and create a canonical key
   *
   * @param serviceQuery
   * @param inputTypeAcceptsArray
   * @param resultTypes
   * @return 
   */
  public static String constructQueryKey(ClassificationSchemeQuery serviceQuery, List<String> inputTypeAcceptsArray, String... resultTypes) {
    StringBuilder key = new StringBuilder();

    //Qualifiers
    key.append("KQ:(");
    Set<String> findQualifierSet = new TreeSet<String>();
    for (String findQualifier : serviceQuery.getFindQualifies()) {
      findQualifierSet.add(findQualifier);
    }
    key.append(StringUtils.join(findQualifierSet, '|'));
    key.append(")");

    //Classification Query
    key.append("CQ:(");
    Set<String> cqBuilder = new TreeSet<String>();
    for (String classficationSchemeName : serviceQuery.getClassificationSchemeNames()) {
      Set<String> values = new TreeSet<String>(serviceQuery.getClassificationSchemeValues(classficationSchemeName));
      cqBuilder.add(classficationSchemeName + "=" + StringUtils.join(values, '|'));
    }
    key.append(StringUtils.join(cqBuilder, '+'));
    key.append(")");
    
    //ResultTypes
    key.append("RT:(");
    if (resultTypes != null) {
      Set<String> resultTypesSet = new TreeSet<String>(Arrays.asList(resultTypes));
      key.append(StringUtils.join(resultTypesSet, '|'));
    }
    key.append(")");
    
    //Parameters which accept arrays
    key.append("ARR:(");
    if (inputTypeAcceptsArray != null) {
      Set<String> inputTypeAcceptsArraySet = new TreeSet<String>(inputTypeAcceptsArray);
      key.append(StringUtils.join(inputTypeAcceptsArraySet, '|'));
    }
    key.append(")");
    
    return key.toString();
  }
  
 /**
   * Constructs a canonical key for the query.
   * This uses a series of TreeSets to maintain natural order and create a canonical key
   *
   * @param serviceQuery
   * @param inputTypeAcceptsArray
   * @param resultTypes
   * @return 
   */
  public static String constructQueryKey(ServiceQuery serviceQuery) {
    StringBuilder key = new StringBuilder();

    //Qualifiers
    key.append("KQ:(");
    Set<String> findQualifierSet = new TreeSet<String>();
    for (String findQualifier : serviceQuery.getClassificationSchemeQuery().getFindQualifies()) {
      findQualifierSet.add(findQualifier);
    }
    key.append(StringUtils.join(findQualifierSet, '|'));
    key.append(")");

    //Classification Query
    key.append("CQ:(");
    Set<String> cqBuilder = new TreeSet<String>();
    for (String classficationSchemeName : serviceQuery.getClassificationSchemeQuery().getClassificationSchemeNames()) {
      Set<String> values = new TreeSet<String>(serviceQuery.getClassificationSchemeQuery().getClassificationSchemeValues(classficationSchemeName));
      cqBuilder.add(classficationSchemeName + "=" + StringUtils.join(values, '|'));
    }
    key.append(StringUtils.join(cqBuilder, '+'));
    key.append(")");
    
    //ResultTypes
    key.append("RT:(");
    if (serviceQuery.hasResultTypes()) {
      Set<String> resultTypesSet = new TreeSet<String>(serviceQuery.getResultTypes());
      key.append(StringUtils.join(resultTypesSet, '|'));
    }
    key.append(")");
    
    //Parameters which accept arrays
    key.append("ARR:(");
    if (serviceQuery.hasInputTypesWhichAcceptList()) {
      Set<String> inputTypeAcceptsArraySet = new TreeSet<String>(serviceQuery.getInputTypesWhichAcceptsList());
      key.append(StringUtils.join(inputTypeAcceptsArraySet, '|'));
    }
    key.append(")");
    
    return key.toString();
  }  

  /**
   * Builds ClassificationSchemeQuerys from the given query key
   * @param queryKey
   * @return
   */
  public static Collection<ClassificationSchemeQuery> buildQueryFromKey(String queryKey) {
    Pattern keyPattern = Pattern.compile("KQ:\\((.*?)\\)CQ:\\((.*?)\\)RT:\\((.*?)\\)ARR:\\((.*)\\)");
    Matcher keyMatcher = keyPattern.matcher(queryKey);

    if (!keyMatcher.matches()) {
      return null;
    }
    String kq = keyMatcher.group(1);
    String cq = keyMatcher.group(2);
    String rt = keyMatcher.group(3);
    String arrGroups = keyMatcher.group(4);

    List<ClassificationSchemeQuery> queries = new ArrayList<ClassificationSchemeQuery>();

    if (StringUtils.isNotEmpty(rt)) {
      String[] rts = rt.split("\\|");
      for (String rt1 : rts) {
        ClassificationSchemeQuery classificationSchemeQuery = new ClassificationSchemeQuery();
        classificationSchemeQuery.setResultType(rt1);
        queries.add(classificationSchemeQuery);
      }
    }
    if (queries.isEmpty()) {
      queries.add(new ClassificationSchemeQuery());
    }
    if (StringUtils.isNotEmpty(kq)) {
      String[] kqs = kq.split("\\|");
      for (String kq1 : kqs) {
        for (ClassificationSchemeQuery query : queries) {
          query.addFindQualifier(kq1);
        }
      }
    }
    if (StringUtils.isNotEmpty(cq)) {
      String[] cqs = cq.split("\\+");
      for (String cq1 : cqs) {
        String[] c = cq1.split("=", 2);
        if (c.length == 2) {
          String categoryName = c[0];
          String[] categoryValues = c[1].split("\\|");
          for (ClassificationSchemeQuery query : queries) {
            for (String categoryValue : categoryValues) {
              query.addKeyValue(categoryName, categoryValue);
            }
          }
        }
      }
    }
    if (StringUtils.isNotEmpty(arrGroups)) {
      String[] arrs = arrGroups.split("\\|");
      for (String arr1 : arrs) {
        for (ClassificationSchemeQuery query : queries) {
          query.addInputTypeAcceptsArray(arr1);
        }
      }
    }
    return queries;
  }  
  
  

  public static void printQuery(ClassificationSchemeQuery query) {
    System.out.println("FQ: " + query.getFindQualifies());
    Set<String> classificationNames = query.getClassificationSchemeNames();
    for (String classificationName : classificationNames) {
      Set<String> values = query.getClassificationSchemeValues(classificationName);
      System.out.println("CQ: " + classificationName + "=" + values);
    }
    System.out.println("RT: " + query.getResultType());
    System.out.println("AR: " + query.getInputTypeAcceptsArray());
  }
  
  public static void logQuery(ClassificationSchemeQuery query, Logger logger) {
    logger.info("FQ: " + query.getFindQualifies());
    Set<String> classificationNames = query.getClassificationSchemeNames();
    for (String classificationName : classificationNames) {
      Set<String> values = query.getClassificationSchemeValues(classificationName);
      logger.info("CQ: " + classificationName + "=" + values);
    }
    logger.info("RT: " + query.getResultType());
    logger.info("AR: " + query.getInputTypeAcceptsArray());
  }
}
