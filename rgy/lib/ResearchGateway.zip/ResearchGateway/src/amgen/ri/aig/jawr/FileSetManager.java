package amgen.ri.aig.jawr;

import java.io.FileNotFoundException;
import java.io.Writer;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.jdom.Document;
import org.jdom.Element;

import amgen.ri.aig.AIGBase;
import amgen.ri.rg.config.ConfigurationParameterInstanceType;
import amgen.ri.rg.config.ContextConfigurationParameters;
import amgen.ri.html.GenericHTMLElement;
import amgen.ri.html.HTMLElement;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import amgen.ri.xml.XMLElement;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletContext;

/**
 * <p>
 * @version $Id: FileSetManager.java,v 1.9 2015/01/30 22:52:48 jemcdowe Exp $</p>
 *
 * <p>
 * </p>
 *
 * <p>
 * </p>
 *
 * <p>
 * </p> not attributable
 */
public class FileSetManager {

  public static String CONFIG_FILENAME = "rg.filesets.definition.xml";
  private HttpServletRequest request;
  private JawrLinkRenderer jawrLinkRenderer;
  private Document fileSetDoc;

  public FileSetManager() throws FileNotFoundException {
    fileSetDoc = ExtXMLElement.toDocument(this.getClass(), CONFIG_FILENAME);
    if (fileSetDoc == null) {
      throw new FileNotFoundException("Unable to load " + CONFIG_FILENAME);
    }
  }

  public FileSetManager(AIGBase requestor) throws FileNotFoundException {
    this(requestor.getHttpServletRequest());
  }

  public FileSetManager(HttpServletRequest request) throws FileNotFoundException {
    this.request = request;
    this.jawrLinkRenderer = new JawrLinkRenderer(request);
    fileSetDoc = ExtXMLElement.toDocument(this.getClass(), CONFIG_FILENAME);
    if (fileSetDoc == null) {
      throw new FileNotFoundException("Unable to load " + CONFIG_FILENAME);
    }
  }

  public void writeScripts(Writer writer, String fileSetName) {
    HTMLElement parentEl = new GenericHTMLElement("parent");
    appendScripts(parentEl, fileSetName);
    for (XMLElement scriptEl : parentEl.getMembers()) {
      scriptEl.write(writer);
    }
  }

  public void writeStyles(Writer writer, String fileSetName) {
    HTMLElement parentEl = new GenericHTMLElement("parent");
    appendStyles(parentEl, fileSetName);
    for (XMLElement cssLinkEl : parentEl.getMembers()) {
      cssLinkEl.write(writer);
    }
  }

  public void appendScripts(HTMLElement parentEl, String fileSetName) {
    ConfigurationParameterInstanceType rgVersion = ContextConfigurationParameters.getInstance().getRGVersion();
    Element fileSetEl;
    Element versionFileSetEl = ExtXMLElement.getXPathElement(fileSetDoc, "/RGFileSets/JSFileSets/FileSet[@name='" + fileSetName + "'][@version='" + rgVersion.toString().toLowerCase() + "']");
    if (versionFileSetEl != null) {
      fileSetEl = versionFileSetEl;
    } else {
      Element globalFileSetEl = ExtXMLElement.getXPathElement(fileSetDoc, "/RGFileSets/JSFileSets/FileSet[@name='" + fileSetName + "']");
      fileSetEl = globalFileSetEl;
    }
    if (fileSetEl != null) {
      String fileSetBaseDir = fileSetEl.getAttributeValue("baseDir");
      List<Element> fileListEls = fileSetEl.getChildren("filelist");
      for (Element fileListEl : fileListEls) {
        String dir = fileListEl.getAttributeValue("dir");
        List<Element> fileEls = fileListEl.getChildren("file");
        for (Element fileEl : fileEls) {
          String fileName = fileEl.getAttributeValue("name");
          boolean isBundle = ExtXMLElement.getAttributeBoolean(fileEl, "bundle");
          if (ExtString.hasLength(fileName)) {
            if (isBundle) {
              jawrLinkRenderer.appendScriptLinks(fileName, parentEl);
            } else {
              if (!fileName.startsWith("http://")) {
                StringBuffer filePath = new StringBuffer(request.getContextPath());
                if (ExtString.hasLength(fileSetBaseDir)) {
                  filePath.append(fileSetBaseDir + "/");
                }
                if (ExtString.hasLength(dir)) {
                  filePath.append(dir + "/");
                }
                filePath.append(fileName);
                fileName = filePath.toString();
              }
              HTMLElement script = new GenericHTMLElement("script");
              script.addAttribute("type", "text/javascript");
              if (!fileName.matches(".*\\?.*")) {
                fileName = fileName + "?r=" + new Random().nextInt(750000);
              }
              script.addAttribute("src", fileName);
              parentEl.addMemberElement(script);
            }
          }
        }
      }
    } else {
      System.err.println("Unable to find JS FileSet " + fileSetName);
    }
  }

  public void appendStyles(HTMLElement parentEl, String fileSetName) {
    ConfigurationParameterInstanceType rgVersion = ContextConfigurationParameters.getInstance().getRGVersion();
    Element fileSetEl;
    Element versionFileSetEl = ExtXMLElement.getXPathElement(fileSetDoc, "/RGFileSets/CSSFileSets/FileSet[@name='" + fileSetName + "'][@version='" + rgVersion.toString().toLowerCase() + "']");
    if (versionFileSetEl != null) {
      fileSetEl = versionFileSetEl;
    } else {
      Element globalFileSetEl = ExtXMLElement.getXPathElement(fileSetDoc, "/RGFileSets/CSSFileSets/FileSet[@name='" + fileSetName + "']");
      fileSetEl = globalFileSetEl;
    }
    if (fileSetEl != null) {
      String fileSetBaseDir = fileSetEl.getAttributeValue("baseDir");
      List<Element> fileListEls = fileSetEl.getChildren("filelist");
      for (Element fileListEl : fileListEls) {
        String dir = fileListEl.getAttributeValue("dir");
        List<Element> fileEls = fileListEl.getChildren("file");
        for (Element fileEl : fileEls) {
          String fileName = fileEl.getAttributeValue("name");
          boolean isBundle = ExtXMLElement.getAttributeBoolean(fileEl, "bundle");
          if (ExtString.hasLength(fileName)) {
            if (isBundle) {
              jawrLinkRenderer.appendStyleLinks(fileName, parentEl);
            } else {
              if (!fileName.startsWith("http://")) {
                StringBuffer filePath = new StringBuffer(request.getContextPath());
                if (ExtString.hasLength(fileSetBaseDir)) {
                  filePath.append(fileSetBaseDir + "/");
                }
                if (ExtString.hasLength(dir)) {
                  filePath.append(dir + "/");
                }
                filePath.append(fileName);
                fileName = filePath.toString();
              }
              HTMLElement cssLink = new GenericHTMLElement("link");
              cssLink.addAttribute("rel", "stylesheet");
              cssLink.addAttribute("type", "text/css");
              if (!fileName.matches(".*\\?.*")) {
                fileName = fileName + "?r=" + new Random().nextInt(750000);
              }
              cssLink.addAttribute("href", fileName);
              parentEl.addMemberElement(cssLink);
            }
          }
        }
      }
    } else {
      System.err.println("Unable to find CSS FileSet " + fileSetName);
    }
  }

  public List<URL> getStyles(ServletContext context, String fileSetName) {
    List<URL> styleURLs = new ArrayList<URL>();
    ConfigurationParameterInstanceType rgVersion = ContextConfigurationParameters.getInstance().getRGVersion();
    Element fileSetEl;
    Element versionFileSetEl = ExtXMLElement.getXPathElement(fileSetDoc, "/RGFileSets/CSSFileSets/FileSet[@name='" + fileSetName + "'][@version='" + rgVersion.toString().toLowerCase() + "']");
    if (versionFileSetEl != null) {
      fileSetEl = versionFileSetEl;
    } else {
      Element globalFileSetEl = ExtXMLElement.getXPathElement(fileSetDoc, "/RGFileSets/CSSFileSets/FileSet[@name='" + fileSetName + "']");
      fileSetEl = globalFileSetEl;
    }
    if (fileSetEl != null) {
      String fileSetBaseDir = fileSetEl.getAttributeValue("baseDir");
      List<Element> fileListEls = fileSetEl.getChildren("filelist");
      for (Element fileListEl : fileListEls) {
        String dir = fileListEl.getAttributeValue("dir");
        List<Element> fileEls = fileListEl.getChildren("file");
        for (Element fileEl : fileEls) {
          String fileName = fileEl.getAttributeValue("name");
          if (ExtString.hasLength(fileName)) {

            if (!fileName.startsWith("http://")) {
              StringBuffer filePath = new StringBuffer(context.getContextPath());
              if (ExtString.hasLength(fileSetBaseDir)) {
                filePath.append(fileSetBaseDir + "/");
              }
              if (ExtString.hasLength(dir)) {
                filePath.append(dir + "/");
              }
              filePath.append(fileName);
              fileName = filePath.toString();
            }
            try {
              styleURLs.add(new URL(fileName));
            } catch (MalformedURLException ex) {
              Logger.getLogger(FileSetManager.class.getName()).log(Level.SEVERE, null, ex);
            }
          }
        }
      }
    }
    return styleURLs;
  }
}
