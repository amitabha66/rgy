package amgen.ri.aig.uddi;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jdom.Document;
import org.jdom.Element;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.service.ServiceCacheResponse;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.favorites.FavoriteIF;
import amgen.ri.aig.items.ItemsManager;
import amgen.ri.aig.preferences.SpecialUserPreferences;
import amgen.ri.aig.preferences.UserPreference;
import amgen.ri.aig.record.ItemRecord;
import amgen.ri.aig.sobj.ObjectType;
import amgen.ri.aig.sobj.SavedObject;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.asf.sa.uddi.*;
import amgen.ri.json.ExtJSON;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONObject;
import amgen.ri.time.ElapsedTime;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.text.ParseException;
import java.util.*;
import javax.xml.rpc.ServiceException;
import org.apache.commons.collections.comparators.ComparatorChain;
import org.jdom.CDATA;
import org.jdom.JDOMException;

public abstract class AbstractServiceLookup extends AIGServlet {

  public static final SimpleDateFormat RECENT_DATE_FORMAT = new SimpleDateFormat(Constants.SIMPLE_DATE_PATTERN);
  public static final int RECENT_USAGE_DAYS_CUTOFF = 14;
  private UserPreference recentServices;

  /**
   * Default constructor
   */
  public AbstractServiceLookup() {
    super();
  }

  /**
   * Main constructor- used only by the getAIGServlet method
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   */
  public AbstractServiceLookup(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  /**
   * Main constructor- used only by the getAIGServlet method
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   */
  public AbstractServiceLookup(AIGServlet aigServlet) {
    super(aigServlet);
  }

  /**
   * Returns the mimetype of the servlet
   */
  protected String getServletMimeType() {
    return "text/xml";
  }

  /**
   * Performs the UDDI search for the request, sorts the results, and returns them as a List
   *
   * @param classificationSchemeQuery ClassificationSchemeQuery
   * @param resultName String
   * @throws ServletException
   * @throws IOException
   * @throws AIGException
   * @return List
   */
  protected ServiceCacheResponse findAndSortServices(ServiceQuery serviceQuery) throws AIGException {
    ServiceCacheResponse discoveredServices = ServiceCache.getServiceCache(request).getServices(serviceQuery);
    List<ServiceDetails> invalidSearchServices = new ArrayList<ServiceDetails>();
    for (ServiceDetails discoveredService : discoveredServices) {
      if (!isValidService(discoveredService, serviceQuery)) {
        invalidSearchServices.add(discoveredService);
      }
    }
    discoveredServices.removeAll(invalidSearchServices);
    if (!discoveredServices.isSorted()) {
      discoveredServices.sortServices(ServiceNamingContext.RG_QUERY, getRecentServicesDocument());
    }
    return discoveredServices;
  }

  /**
   * Returns whether the service should be included in the lookup list. Default implementation returns true. Override
   * for custom implementation.
   *
   * @param discoveredService ServiceDetails
   * @return boolean
   */
  protected boolean isValidService(ServiceDetails searchService, ServiceQuery query) {
    return true;
  }

  /**
   * Performs the UDDI search for the request, sorts the results, and returns them as an Element
   *
   * @return Element
   * @throws ServletException
   * @throws IOException
   * @throws AIGException
   */
  protected Element findAndSortServicesToElement(ServiceQuery serviceQuery) throws AIGException {
    ServiceCacheResponse sortedSearchServices = findAndSortServices(serviceQuery);

    Element servicesElement = new Element("Services");
    for (ServiceDetails searchService : sortedSearchServices) {
      try {
        if (searchService.containsUserInAllowedUsers(getSessionLogin().getRemoteUser(), true)) {
          Element searchServiceElement = getServiceElement(searchService);
          if (searchServiceElement != null) {
            ServiceAttributes serviceAttributes = new ServiceAttributes(searchService, getEntityClassManager());

            Element nameElement = searchServiceElement.getChild("Name");
            nameElement.setText(serviceAttributes.getName(ServiceNamingContext.RG_QUERY));
            Element descElement = searchServiceElement.getChild("Description");
            descElement.setText(serviceAttributes.getDescription(ServiceNamingContext.RG_QUERY));
            ExtXMLElement.addTextElement(searchServiceElement, "RecentTag", (isRecentService(searchService, RECENT_USAGE_DAYS_CUTOFF) ? "Recent" : "All"));
            ExtXMLElement.addTextElement(searchServiceElement, "LastUsed", getLastUsedDateString(searchService));

            servicesElement.addContent(searchServiceElement);
          }
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return servicesElement;
  }

  /**
   * Returns the Service as an XML Element which is used when creating the Services XML. May be overridden if the
   * default behavior needs changed.
   *
   * @param searchService ServiceDetails
   * @return Element
   */
  protected Element getServiceElement(ServiceDetails searchService) {
    if (searchService != null) {
      Element serviceEl = searchService.getAsElement();
      ExtXMLElement.addTextElement(serviceEl, "LastUsed", getLastUsedDateString(searchService));

      List<BindingDetails> formBindings = searchService.getBindingByTModelName("Demo RG Form");
      if (formBindings.size() > 0) {
        ExtXMLElement.addTextElement(serviceEl, "FormURL", formBindings.get(0).getTModelInstances().get(0).getTModelDetails().getOverviewDocumentURL() + "");
      }
      return serviceEl;
    }
    return null;
  }

  /**
   * Returns the Services a single XML Document
   *
   * @return
   * @throws JDOMException
   * @throws AIGException
   */
  public abstract Document getServicesDocument() throws JDOMException, AIGException;

  /**
   * Filters the Services document using the provided XPath. The XPath must return Service elements
   *
   * @param xpathServiceFilter
   * @return
   * @throws JDOMException
   * @throws AIGException
   */
  public Document getServicesDocument(String xpathServiceFilter) throws JDOMException, AIGException {
    Document servicesDoc = getServicesDocument();
    Document filteredServicesDoc = new Document(new Element("Services"));
    List<Element> serviceEls = ExtXMLElement.getXPathElements(servicesDoc, xpathServiceFilter);
    for (Element serviceEl : serviceEls) {
      filteredServicesDoc.getRootElement().addContent((Element) serviceEl.clone());
    }
    return filteredServicesDoc;
  }

  /**
   * Converts the Services document to JSON
   *
   * @param serviceDoc
   * @return
   */
  public JSONObject getServiceRecords(Document serviceDoc) {
    JSONObject jServices = new JSONObject();
    try {
      List<Element> serviceEls = ExtXMLElement.getXPathElements(serviceDoc, "//Service");
      for (Element serviceEl : serviceEls) {
        JSONObject jService = new JSONObject();
        jServices.append("services", jService);
        jService.putOpt("ServiceKey", serviceEl.getChildTextNormalize("ServiceKey"));
        jService.putOpt("Name", serviceEl.getChildTextNormalize("Name"));
        jService.putOpt("Organization", serviceEl.getChildTextNormalize("Organization"));
        jService.putOpt("Contact", serviceEl.getChildTextNormalize("Contact"));
        jService.putOpt("Description", serviceEl.getChildTextNormalize("Description"));
        jService.putOpt("Icon", serviceEl.getChildTextNormalize("Icon"));
        jService.putOpt("IconCls", serviceEl.getChildTextNormalize("IconCls"));
        jService.putOpt("Category", serviceEl.getChildTextNormalize("Category"));
        jService.putOpt("CategoryTag", serviceEl.getChildTextNormalize("CategoryTag"));
        jService.putOpt("EntityCategory", serviceEl.getChildTextNormalize("EntityCategory"));
        jService.putOpt("LastUsed", serviceEl.getChildTextNormalize("LastUsed"));
        jService.putOpt("IsVQT", ExtString.equalsIgnoreCase(serviceEl.getChildText("IsVQT"), "true"));
        jService.putOpt("IsWidget", ExtString.equalsIgnoreCase(serviceEl.getChildText("IsWidget"), "true"));
        jService.putOpt("WidgetURL", serviceEl.getChildTextNormalize("WidgetURL"));
        jService.putOpt("WidgetProperties", ExtXMLElement.getXPathValues(serviceEl, "//WidgetProperty"));
        

        jService.putOpt("ShowResources", !ExtString.equalsIgnoreCase(serviceEl.getChildText("ShowResources"), "false"));
        jService.putOpt("IsParametersSaveable", ExtString.equalsIgnoreCase(serviceEl.getChildText("IsParametersSaveable"), "true"));
        jService.putOpt("IsDefaultView", ExtString.equalsIgnoreCase(serviceEl.getChildText("IsDefaultView"), "true"));
        jService.putOpt("FolderItemID", serviceEl.getChildTextNormalize("FolderItemID"));
        jService.putOpt("EditableParams", (int) ExtString.toDouble(serviceEl.getChildText("EditableParams"), 0));
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return jServices;
  }

  protected UserPreference getRecentServices() {
    if (recentServices == null) {
      recentServices = getUserPreferences(SpecialUserPreferences.RECENT_SERVICES);
    }
    return recentServices;
  }

  /**
   * Returns a Map of the recent services
   *
   * @return
   * @throws AIGException
   */
  protected Map<String, ServiceDetails> getRecentServiceDetails() throws AIGException {
    Map<String, ServiceDetails> recentServicesMap = new LinkedHashMap<String, ServiceDetails>();
    ServiceCacheResponse recentServicesList = ServiceCache.getServiceCache(this).getServices(getRecentServiceKeys());
    for (ServiceDetails service : recentServicesList) {
      recentServicesMap.put(service.getKey(), service);
    }
    return recentServicesMap;
  }

  /**
   * returns whether the service has been used in the 14 days
   *
   * @param service
   * @return
   */
  protected boolean isRecentService(ServiceDetails service, int days) {
    Date lastUsedDate = getLastUsedDate(service);
    if (lastUsedDate != null) {
      if (System.currentTimeMillis() - lastUsedDate.getTime() < (days * 24 * 60 * 60 * 1000)) {
        return true;
      }
    }
    return false;
  }

  /**
   * Checks if the provided ServiceDetails is a recent service and if so, sets any saved parameters. returns the
   * provided ServiceDetails object
   *
   * @param serviceDetails
   * @return
   */
  protected ServiceDetails setRecentParameters(ServiceDetails serviceDetails) {
    if (serviceDetails == null || !isRecentService(serviceDetails, RECENT_USAGE_DAYS_CUTOFF)) {
      return serviceDetails;
    }
    List<Element> parameterEls = ExtXMLElement.getXPathElements(getRecentServicesDocument(),
            "/RecentServices/Service[@serviceKey='" + serviceDetails.getKey() + "']/ParameterSet/Parameter");
    return setServiceDetailsParameters(serviceDetails, parameterEls, true);
  }

  /**
   * Checks if the provided ServiceDetails is a recent service and if so, sets any saved parameters. returns the
   * provided ServiceDetails object
   *
   * @param serviceDetails
   * @return
   */
  protected Document getRecentParameters(ServiceDetails serviceDetails) {
    if (serviceDetails == null || !isRecentService(serviceDetails, RECENT_USAGE_DAYS_CUTOFF)) {
      return null;
    }
    Element serviceEl = ExtXMLElement.getXPathElement(getRecentServicesDocument(),
            "/RecentServices/Service[@serviceKey='" + serviceDetails.getKey() + "']");
    if (serviceEl == null) {
      return null;
    }
    return new Document((Element) serviceEl.clone());
  }

  /**
   * Returns the last used date of the Service
   *
   * @param service
   * @return
   */
  protected Date getLastUsedDate(ServiceDetails service) {
    try {
      Element serviceEl = ExtXMLElement.getXPathElement(getRecentServicesDocument(), "/RecentServices/Service[@serviceKey='" + service.getKey() + "']");
      if (serviceEl != null) {
        Date lastUsedDate = RECENT_DATE_FORMAT.parse(serviceEl.getAttributeValue("lastDateCalled"));
        return lastUsedDate;
      }
    } catch (Exception e) {
    }
    return null;
  }

  /**
   * Returns the last used date of the Service
   *
   * @param service
   * @return
   */
  protected String getLastUsedDateString(ServiceDetails service) {
    try {
      Element serviceEl = ExtXMLElement.getXPathElement(getRecentServicesDocument(), "/RecentServices/Service[@serviceKey='" + service.getKey() + "']");
      if (serviceEl != null) {
        Date lastUsedDate = RECENT_DATE_FORMAT.parse(serviceEl.getAttributeValue("lastDateCalled"));
        return this.getSessionLogin().convertToUserTimeZone(Constants.JSON_DATE_PATTERN, lastUsedDate, TimeZone.getTimeZone("PST"));
      }
    } catch (Exception e) {
    }
    return null;
  }

  protected Collection<String> getRecentServiceKeys() {
    List<String> recentServiceKeys = new ArrayList<String>();
    try {
      TreeSet<Element> serviceEls = new TreeSet<Element>(new Comparator() {
        public int compare(Object o1, Object o2) {
          try {
            Element sE1 = (Element) o1;
            Element sE2 = (Element) o2;
            Date d1 = RECENT_DATE_FORMAT.parse(sE1.getAttributeValue("lastDateCalled"));
            Date d2 = RECENT_DATE_FORMAT.parse(sE2.getAttributeValue("lastDateCalled"));
            return -d1.compareTo(d2);
          } catch (ParseException ex) {
          }
          return 0;
        }
      });
      serviceEls.addAll(ExtXMLElement.getXPathElements(getRecentServicesDocument(), "/RecentServices/Service"));
      for (Element serviceEl : serviceEls) {
        Date lastUsedDate = RECENT_DATE_FORMAT.parse(serviceEl.getAttributeValue("lastDateCalled"));
        if (System.currentTimeMillis() - lastUsedDate.getTime() < (14 * 24 * 60 * 60 * 1000)) {
          recentServiceKeys.add(serviceEl.getAttributeValue("serviceKey"));
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return recentServiceKeys;
  }

  /**
   * Returns the Recent service XML document. If none, returns an empty
   * <RecentServices/>
   *
   * @return
   */
  protected Document getRecentServicesDocument() {
    try {
      UserPreference localRecentServices = getRecentServices();
      return (localRecentServices == null || localRecentServices.getPreferenceDataDocument() == null
              ? ExtXMLElement.toDocument("<RecentServices/>") : localRecentServices.getPreferenceDataDocument());
    } catch (Exception e) {
      e.printStackTrace();
    }
    return ExtXMLElement.toDocument("<RecentServices/>");
  }

  /**
   * Returns a Document containing a <Service> element for the given serviceKey if it is in the
   * <RecentServices> document for the users
   *
   * @return
   */
  protected Document getRecentServiceDocument(String serviceKey) {
    if (serviceKey != null) {
      try {
        Element serviceEl = ExtXMLElement.getXPathElement(getRecentServicesDocument(), "/RecentServices/Service[@serviceKey='" + serviceKey + "']");
        if (serviceEl != null) {
          return new Document((Element) serviceEl.clone());
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return null;
  }

  /**
   * Returns a ServiceDetails object for the given FavoriteFolderItem ID
   *
   * @param folderItemID
   * @return
   */
  public ServiceDetails getServiceDetailsFromFavoriteFolderItem(int folderItemID, boolean includeParameterValues) {
    try {
      Document savedServiceDocument = getSavedServiceDocument(folderItemID);
      if (savedServiceDocument != null) {
        String serviceKey = ExtXMLElement.getXPathValue(savedServiceDocument, "//ServiceKey");
        ServiceDetails serviceDetails = ServiceCache.getServiceCache(request).getService(serviceKey);
        if (includeParameterValues) {
          List<Element> parameterEls = ExtXMLElement.getXPathElements(savedServiceDocument, "//ParameterSet/Parameter");
          setServiceDetailsParameters(serviceDetails, parameterEls, false);
        }
        return serviceDetails;
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  /**
   * Returns a saved ServiceDetails Document object for the given FavoriteFolderItem ID or null if it does not exists
   *
   * @param folderItemID
   * @return
   */
  public Document getSavedServiceDocument(int folderItemID) {
    try {
      ItemsManager mgr = new ItemsManager(this);
      ItemRecord itemRecord = mgr.getItemRecord(folderItemID);
      if (itemRecord.exists() && itemRecord.equalsIgnoreCase("subtype", "SERVICE")) {
        FavoriteIF favorite = itemRecord.getItem(this);
        Object favoriteTarget = favorite.getFavoriteObject();
        if (favoriteTarget != null && favoriteTarget instanceof SavedObject && favorite.getObjectType().getTypeID() == ObjectType.SERVICE) {
          SavedObject savedServiceObject = (SavedObject) favoriteTarget;
          if (!savedServiceObject.setData()) {
            throw new AIGException("Unable to load saved service", AIGException.Reason.UNABLE_TO_RETRIEVE_ENTRY);
          }
          return (Document) savedServiceObject.getSavedObject();
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  /**
   * Returns a ServiceDetails XML Document for the given FavoriteFolderItem ID
   *
   * @param folderItemID
   * @return
   */
  public Document getServiceDocumentFromFavoriteFolderItem(int folderItemID, boolean includeParameterValues) {
    ServiceDetails serviceDetails = getServiceDetailsFromFavoriteFolderItem(folderItemID, includeParameterValues);
    if (serviceDetails == null) {
      return null;
    }
    Document serviceDoc = new Document(serviceDetails.getAsElement());
    try {
      ExtXMLElement.addTextElement(serviceDoc.getRootElement(), "SDBinding", serviceDetails.getSDURL() + "");
    } catch (ServiceException ex) {
      ex.printStackTrace();
    }
    ExtXMLElement.addTextElement(serviceDoc.getRootElement(), "FolderItemID", folderItemID + "");

    return serviceDoc;
  }

  /**
   * Sets the parameters in the given ServiceDetails using the given Parameter Elements as a List, optionally excluding
   * non-editable parameters
   *
   * @param serviceDetails
   * @param parameterEls
   * @param excludeNotEditableParameters
   * @return
   */
  protected ServiceDetails setServiceDetailsParameters(ServiceDetails serviceDetails, List<Element> parameterEls, boolean excludeNotEditableParameters) {
    try {
      if (ExtArray.hasLength(parameterEls)) {
        for (Element parameterEl : parameterEls) {
          String parameterName = parameterEl.getChildText("Name");
          JSONArray jParameterValues = (JSONArray) ExtJSON.toJSON(parameterEl.getChildText("Value"));
          if (jParameterValues != null) {
            ServiceParameter serviceParameter = serviceDetails.getParameter(parameterName);
            if (serviceParameter != null && (!excludeNotEditableParameters || serviceParameter.getEditable())) {
              serviceParameter.setRawValues(jParameterValues.asList());
            }
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return serviceDetails;
  }

  /**
   * Returns the given ServiceDetails object parameters and values as a ParameterSet Element This excludes parameters
   * set by lineage, session, or default and those categorized as SERVICE_INPUT_CATEGORIZATION_SCHEME= "Amgen Session
   * Login"
   *
   * @param serviceDetails
   * @return
   */
  public Element getServiceDetailsParameterSet(ServiceDetails serviceDetails) {
    Element parameterSetEl = new Element("ParameterSet");
    Collection<ServiceParameter> serviceParameters = serviceDetails.getParameters();
    for (ServiceParameter serviceParameter : serviceParameters) {
      //
      // Only include parameters and values which match the following:
      // 1. Has a set value (NOT one merely set by defaults)
      // 2. Has a value not set by (a) lineage, (b) session attributes, (c) defaults- which should be handled by (1)
      // 3. NOT categorized as SERVICE_INPUT_CATEGORIZATION_SCHEME="Amgen Session Login"
      //
      if (serviceParameter.hasSetValue()
              && (!ExtString.hasLength(serviceParameter.getParameterValueSource())
              || !ExtString.in(serviceParameter.getParameterValueSource(), new String[]{"lineage", "session", "default"}))
              && !serviceParameter.isCategorizedAs(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME, "Amgen Session Login")) {
        Element parameterEl = ExtXMLElement.addElement(parameterSetEl, "Parameter");
        ExtXMLElement.addElement(parameterEl, "Name", serviceParameter.getParameterName());
        Element valueEl = ExtXMLElement.addElement(parameterEl, "Value");
        valueEl.addContent(new CDATA((new JSONArray(serviceParameter.getRawValues()).toString())));
      }
    }
    return parameterSetEl;
  }

  /**
   * getRankedCategoryKeyValues
   *
   * @param services List
   * @return List
   */
  protected List<CategoryKeyValue> getRankedCategoryKeyValues(ServiceCacheResponse services) throws AIGException {
    class CategoryKeyValueHelper {

      CategoryKeyValue categoryKeyValue;
      int count = 0;

      CategoryKeyValueHelper(CategoryKeyValue categoryKeyValue) {
        this.categoryKeyValue = categoryKeyValue;
      }
    }
    Map<String, CategoryKeyValueHelper> categoryKeyValueCounts = new HashMap<String, CategoryKeyValueHelper>();
    for (ServiceDetails service : services) {
      if (service.containsUserInAllowedUsers(getSessionLogin().getRemoteUser(), true)) {
        ServiceAttributes serviceAttributes = new ServiceAttributes(service, getEntityClassManager());
        CategoryKeyValue orgCatValue = serviceAttributes.getOrganizationCategoryKeyValue();
        if (orgCatValue != null) {
          if (!categoryKeyValueCounts.containsKey(orgCatValue.getKeyValue())) {
            CategoryKeyValueHelper categoryKeyValueHelper = new CategoryKeyValueHelper(orgCatValue);
            categoryKeyValueCounts.put(orgCatValue.getKeyValue(), categoryKeyValueHelper);
          }
          if (isRecentService(service, RECENT_USAGE_DAYS_CUTOFF)) {
            categoryKeyValueCounts.get(orgCatValue.getKeyValue()).count++;
          }
        }
      }
    }
    List<CategoryKeyValueHelper> rankedCategoryKeyValueHelpers = new ArrayList<CategoryKeyValueHelper>(categoryKeyValueCounts.values());
    int[] order = ExtArray.quicksort(rankedCategoryKeyValueHelpers, new Comparator() {
      public int compare(Object obj1, Object obj2) {
        CategoryKeyValueHelper c1 = (CategoryKeyValueHelper) obj1;
        CategoryKeyValueHelper c2 = (CategoryKeyValueHelper) obj2;
        return (c1.count < c2.count ? 1 : (c1.count == c2.count ? 0 : -1));
      }
    });
    List<CategoryKeyValue> rankedCategoryKeyValues = new ArrayList<CategoryKeyValue>();
    for (int i = 0; i < order.length; i++) {
      rankedCategoryKeyValues.add(rankedCategoryKeyValueHelpers.get(order[i]).categoryKeyValue);
    }
    return rankedCategoryKeyValues;
  }

  protected Map<String, Integer> getCategoryKeyValueRanks(ServiceCacheResponse services) throws AIGException {
    Map<String, Integer> categoryKeyValueRanks = new HashMap<String, Integer>();
    List<CategoryKeyValue> categoryKeyValues = getRankedCategoryKeyValues(services);

    for (int i = 0; i < categoryKeyValues.size(); i++) {
      CategoryKeyValue categoryKeyValue = categoryKeyValues.get(i);
      categoryKeyValueRanks.put(categoryKeyValue.getKeyValue(), i);
    }
    return categoryKeyValueRanks;
  }

}
