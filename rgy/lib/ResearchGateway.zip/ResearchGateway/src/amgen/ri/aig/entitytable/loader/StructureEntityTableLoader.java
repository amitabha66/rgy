package amgen.ri.aig.entitytable.loader;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.tree.TreeNode;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.entityrules.EntityRulesFactory;
import amgen.ri.aig.entityrules.EntityRulesIF;
import amgen.ri.aig.entitytable.Column;
import amgen.ri.aig.entitytable.ColumnGroup;
import amgen.ri.aig.entitytable.DataCell;
import amgen.ri.aig.entitytable.DataRow;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;
import amgen.ri.aig.util.Utilities;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.excel.ExcelUtils;
import amgen.ri.util.ExtString;

/**
 * EntityTable loader for ACRF Compounds or Substances
 * @version $Id: StructureEntityTableLoader.java,v 1.5 2014/07/08 15:51:47 jemcdowe Exp $
 */
public abstract class StructureEntityTableLoader extends AbstractEntityTableLoader {
  private String acrfServiceKey;

  public StructureEntityTableLoader(AIGBase requestor, EntityListCategory tableCategory, String resultNodeKey) {
    super(requestor, tableCategory, resultNodeKey);

    try {
      ServiceDetails service = requestor.getLooselyCoupledServiceDetails("COMPOUND_ENTITY_PROPERTIES");
      acrfServiceKey = service.getKey();
    } catch (Exception e) {
    }
  }

  /**
   * Overrides the createEntityTableFromResultNode to create the EntityTable
   * from a Result Node
   *
   * @param resultNodeKey String
   * @return EntityTable
   * @throws AIGException
   */
  public EntityTable createEntityTableFromResultNode(String resultNodeKey) throws AIGException {
    EntityTable entityTable = buildEntityTableFromResultNode(resultNodeKey);
    addResultRows(entityTable);
    return entityTable;
  }
  /**
   * Builds the entity table without adding the result rows
   * @param resultNodeKey
   * @return
   * @throws AIGException 
   */
  protected EntityTable buildEntityTableFromResultNode(String resultNodeKey) throws AIGException {
    if (!getEntityTableType().equals(EntityListCategory.COMPOUNDS) && !getEntityTableType().equals(EntityListCategory.SUBSTANCES)
            && !getEntityTableType().equals(EntityListCategory.SMR_MOLECULES)) {
      throw new AIGException("ACRFEntryEntityTableLoader only valid for ACRF entities", AIGException.Reason.ENTITY_MISMATCH);
    }
    //Setup the Table
    EntityTable entityTable = new EntityTable(getEntityTableType());
    entityTable.setServiceResultCacheItem(getRequestor().getServiceResultCacheItem(resultNodeKey));
    entityTable.setTableName(getTableName());

    //Add the Entity ID Column Group
    ColumnGroup entityColumnGroup = new ColumnGroup("Compound");
    entityTable.addColumnGroup(entityColumnGroup);
    entityColumnGroup.setIsEntityIDDataIndex(true);
    Double pixels = Utilities.points2Pixels(150, false);
    entityTable.setRowHeightPixels(pixels.intValue());
    Column entityColumn = new Column("ID", EntityTableDataType.INTEGER, null, 75);
    entityColumnGroup.addColumn(entityColumn);
    Column structureColumn = new Column("Structure", EntityTableDataType.STRUCTURE, pixels.intValue());
    entityColumnGroup.addColumn(structureColumn);

    EntityTableDataType idDataType = EntityTableDataType.TEXT;
    switch (getEntityTableType()) {
      case COMPOUNDS:
        entityColumnGroup.setHeaderText("Compound");
        idDataType = EntityTableDataType.INTEGER;
        entityColumn.setDrillDownServiceKey(getAcrfServiceKey());
        structureColumn.setDrillDownServiceKey(getAcrfServiceKey());
        break;
      case SUBSTANCES:
        entityColumnGroup.setHeaderText("Substance");
        idDataType = EntityTableDataType.TEXT;
        entityColumn.setDrillDownServiceKey(getAcrfServiceKey());
        structureColumn.setDrillDownServiceKey(getAcrfServiceKey());
        break;
      case SMR_MOLECULES:
        entityColumnGroup.setHeaderText("Molecule");
        idDataType = EntityTableDataType.INTEGER;
        break;
    }
    entityColumn.setDataType(idDataType);

    return entityTable;
  }
  /**
   * Adds the result rows to the EntityTable
   * @param entityTable
   * @throws AIGException 
   */
  protected EntityTable addResultRows(EntityTable entityTable) throws AIGException {
    //Add the rows
    for (TreeNode childResultNode : getChildResultNodes()) {
      String compoundID = childResultNode.getText();
      String serviceData = childResultNode.getServiceData();
      addEntityRowToEntityTable(entityTable, serviceData, compoundID);
    }
    return entityTable;
  }

  /**
   * Overrides the createEntityTableFromResultNode to create the EntityTable
   * from a Result Node
   *
   * @param resultNodeKey String
   * @return EntityTable
   * @throws AIGException
   */
  public EntityTable createEntityTableFromWorkbook(Workbook workbook, int serviceDataCategoryColNum, Map<Integer, EntityTableDataType> columnTypes) throws AIGException {
    if (!getEntityTableType().equals(EntityListCategory.COMPOUNDS) && !getEntityTableType().equals(EntityListCategory.SUBSTANCES)
            && !getEntityTableType().equals(EntityListCategory.SMR_MOLECULES)) {
      throw new AIGException("Only valid for structure entities", AIGException.Reason.ENTITY_MISMATCH);
    }
    //Setup the Table
    EntityTable entityTable = new EntityTable(getEntityTableType());
    entityTable.setTableName(getTableName());

    //Add the Entity ID Column Group
    ColumnGroup entityColumnGroup = new ColumnGroup("Compound");
    entityTable.addColumnGroup(entityColumnGroup);
    entityColumnGroup.setIsEntityIDDataIndex(true);
    Double pixels = Utilities.points2Pixels(150, false);
    entityTable.setRowHeightPixels(pixels.intValue());
    Column entityColumn = new Column("ID", EntityTableDataType.INTEGER, null, 75);
    entityColumnGroup.addColumn(entityColumn);
    Column structureColumn = new Column("Structure", EntityTableDataType.STRUCTURE, pixels.intValue());
    entityColumnGroup.addColumn(structureColumn);

    EntityTableDataType idDataType = EntityTableDataType.TEXT;
    switch (getEntityTableType()) {
      case COMPOUNDS:
        entityColumnGroup.setHeaderText("Compound");
        idDataType = EntityTableDataType.INTEGER;
        entityColumn.setDrillDownServiceKey(getAcrfServiceKey());
        structureColumn.setDrillDownServiceKey(getAcrfServiceKey());
        break;
      case SUBSTANCES:
        entityColumnGroup.setHeaderText("Substance");
        idDataType = EntityTableDataType.TEXT;
        entityColumn.setDrillDownServiceKey(getAcrfServiceKey());
        structureColumn.setDrillDownServiceKey(getAcrfServiceKey());
        break;
      case SMR_MOLECULES:
        entityColumnGroup.setHeaderText("Molecule");
        idDataType = EntityTableDataType.INTEGER;
        break;
    }
    entityColumn.setDataType(idDataType);

    Sheet importSheet = workbook.getSheetAt(0);
    Row headerRow = importSheet.getRow(0);
    List<Integer> importColumns = new ArrayList<Integer>();

    for (int col = 0; col < headerRow.getPhysicalNumberOfCells(); col++) {
      if (col != serviceDataCategoryColNum) {
        String header = ExcelUtils.getCellStringValue(headerRow, col);
        EntityTableDataType dataType = EntityTableDataType.UNSPECIFIED;
        if (columnTypes != null) {
          dataType = columnTypes.get(col);
        }
        if (!dataType.equals(EntityTableDataType.UNSPECIFIED)) {
          ColumnGroup columnGroup = new ColumnGroup(header);
          entityTable.addColumnGroup(columnGroup);

          Column column = new Column(header, dataType);
          columnGroup.addColumn(column);
          importColumns.add(col);
        }
      }
    }

    for (int row = 1; row < importSheet.getPhysicalNumberOfRows(); row++) {
      Row importRow = importSheet.getRow(row);
      String compoundID = ExcelUtils.getCellStringValue(importRow, serviceDataCategoryColNum);
      DataRow dataRow = addEntityRowToEntityTable(entityTable, compoundID, compoundID);
      if (dataRow != null) {
        for (int col : importColumns) {
          EntityTableDataType dataType = EntityTableDataType.UNSPECIFIED;
          if (columnTypes != null) {
            dataType = columnTypes.get(col);
          }
          String importValue = ExcelUtils.getCellStringValue(importRow, col);
          dataRow.addDataCell(new DataCell(importValue, dataType));
        }
      }
    }
    return entityTable;
  }

  /**
   * Overrides the createEntityTableFromResultNode to create the EntityTable
   * from a Result Node
   *
   * @param resultNodeKey String
   * @return EntityTable
   * @throws AIGException
   */
  public int addEntitiesToEntityTable(EntityTable entityTable, List<String> entityIDs) throws AIGException {
    int importCount = 0;

    for (String entityID : entityIDs) {
      ColumnGroup entityColumnGroup = entityTable.getColumnGroups().get(0);
      DataRow newDataRow = addEntityRowToEntityTable(entityTable, entityID, entityID);
      if (newDataRow != null) {
        importCount++;
        for (int i = entityColumnGroup.getColumnCount(); i < entityTable.getColumnCount(); i++) {
          newDataRow.addDataCell(new DataCell(""));
        }
      }
    }
    return importCount;
  }

  /**
   * Creates a new row in the table given the entityID.
   * Entity IDs can not be duplicated, so if thsi entityID already exists in the table, this returns null.
   * If for any other reason it can not be added, it returns null.
   * Otherwise, it returns the new DataRow
   * @param entityTable EntityTable
   * @param entityID String
   * @return DataRow
   */
  public DataRow addEntityRowToEntityTable(EntityTable entityTable, String entityID, String entityLabel) {
    if (ExtString.hasTrimmedLength(entityID) && entityTable.getDataRow(entityID) == null) {
      EntityRulesIF entityRules = null;

      entityRules = EntityRulesFactory.getInstance().getEntityRules(EntityListCategory.COMPOUNDS);
      switch (getEntityTableType()) {
        case COMPOUNDS:
          entityRules = EntityRulesFactory.getInstance().getEntityRules(EntityListCategory.COMPOUNDS);
          break;
        case SMR_MOLECULES:
          entityRules = EntityRulesFactory.getInstance().getEntityRules(EntityListCategory.SMR_MOLECULES);
          break;
        case SUBSTANCES:
          entityRules = EntityRulesFactory.getInstance().getEntityRules(EntityListCategory.SUBSTANCES);
          break;
      }

      if (entityRules != null) {
        String processedID = entityRules.applyEntityRules(entityID, null);
        if (processedID != null) {
          DataRow newDataRow = entityTable.addDataRow(new DataRow(processedID));
          if (newDataRow != null) {
            switch (getEntityTableType()) {
              case COMPOUNDS:
              case SMR_MOLECULES:
                newDataRow.addDataCell(new DataCell(processedID, EntityTableDataType.INTEGER));
                break;
              case SUBSTANCES:
                newDataRow.addDataCell(new DataCell(processedID, EntityTableDataType.TEXT));
            }
            newDataRow.addDataCell(new DataCell(processedID, EntityTableDataType.STRUCTURE));
          }
          return newDataRow;
        }
      }
    }
    return null;
  }

  /**
   * Returns the serviceKey for the ACRF properties service
   *
   * @return String
   */
  public String getAcrfServiceKey() {
    return acrfServiceKey;
  }
}
