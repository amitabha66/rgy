package amgen.ri.aig.log;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import amgen.ri.asf.sa.uddi.ServiceInvocationDetails;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.servlet.ServletBase;
import amgen.ri.servlet.SessionLogin;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;

/**
 * Handles logging requests to the RG log,
 * The log table:
 *
 * CREATE TABLE AIGDEV.RG_LOG (
 * REQUEST_ID VARCHAR2(50) PRIMARY KEY,
 * SESSION_ID VARCHAR2(50),
 * REQUEST_USER VARCHAR2(50),
 * HOST VARCHAR2(50),
 * REMOTE_HOST VARCHAR2(50),
 * REQUEST_TYPE VARCHAR2(50),
 * SERVICE_KEY VARCHAR2(50),
 * REQUEST_DATE DATE,
 * ELAPSED_MILLIS INTEGER,
 * ERROR_STRING VARCHAR2(4000)
 * )
 * TABLESPACE APP_DATA
 * PCTUSED 0
 * PCTFREE 10
 * INITRANS 1
 * MAXTRANS 255
 * STORAGE (
 * INITIAL 5M
 * NEXT 1M
 * MINEXTENTS 1
 * MAXEXTENTS UNLIMITED
 * PCTINCREASE 0
 * BUFFER_POOL DEFAULT
 * )
 * LOGGING
 * NOCOMPRESS
 * NOCACHE
 * NOPARALLEL
 * MONITORING;
 *
 */
public class RGSessionLogger {
  /**
   * Creates an RGSessionLogger
   *
   * @param logJDBCConnectionPool String
   */
  public RGSessionLogger() {
  }

  private String getJDBC(HttpSession session) {
    return (String) session.getAttribute("amgen.ri.aig.log.RGSessionLogger.jdbc");

  }

  /**
   * Enters the session start log record in the log
   *
   * @param req HttpServletRequest
   */
  public void insertSessionStartLog(HttpSession session) {
    try {
      LogEntry logEntry = new LogEntry(session.getId(), new OraSQLManager(), getJDBC(session));
      logEntry.performCommit();
      session.setAttribute("amgen.ri.aig.log.RGSessionLogger.sessionRequestID", logEntry.getIdentifier());
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  /**
   * Enters the session start log record in the log
   *
   * @param req HttpServletRequest
   */
  public void updateSessionEndLog(HttpSession session) {
    try {
      String requestID = (String) session.getAttribute("amgen.ri.aig.log.RGSessionLogger.sessionRequestID");
      LogEntry logEntry = new LogEntry(requestID, new OraSQLManager(), getJDBC(session));
      if (!logEntry.setData()) {
        return;
      }
      Timestamp startTime = logEntry.getRequestDate();
      SessionLogin sessionLogin = SessionLogin.getSessionLogin(session);
      String requestUser = (sessionLogin == null ? "Unknown" : sessionLogin.getRemoteUser());
      logEntry.setRequestUser(requestUser);
      logEntry.setElapsedMillis();
      logEntry.performCommit();
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  /**
   * Enters the initial log record in the log
   *
   * @param req HttpServletRequest
   */
  public void startRequestLog(HttpServletRequest req) {
    SessionLogin sessionLogin = SessionLogin.getSessionLogin(req.getSession());
    String requestID = UUID.randomUUID() + "";
    LogRequestType requestType = LogRequestType.fromRequest(req);
    if (requestType.equals(LogRequestType.DISREGARD)) {
      return;
    }
    String requestString = null;
    LogEntry logEntry = new LogEntry(req.getSession().getId(), sessionLogin.getRemoteUser(),
            req.getLocalName(), req.getRemoteHost(), requestType, new OraSQLManager(), getJDBC(req.getSession()));
    logEntry.getIdentifier();
    req.setAttribute("amgen.ri.aig.log.RGSessionLogger.requestLogEntry", logEntry);
  }

  /**
   * Updates the request enty with the completed request elapsed time
   *
   * @param req HttpServletRequest
   */
  public void completeRequestLog(HttpServletRequest req, Exception err) {
    try {
      LogEntry logEntry = (LogEntry) req.getAttribute("amgen.ri.aig.log.RGSessionLogger.requestLogEntry");
      if (logEntry == null) {
        return;
      }
      String errorString = null;
      if (err != null) {
        StringWriter sWriter = new StringWriter();
        err.printStackTrace(new PrintWriter(sWriter));
        logEntry.setErrorString(err.toString() + ", " + sWriter);
      }
      String requestString = ServletBase.getRequestURL(req);
      if (requestString != null && ExtString.length(requestString) < 3000) {
        logEntry.setRequestString(requestString);
      }
      List<ServiceInvocationDetails> serviceInvocationDetailsList = (List<ServiceInvocationDetails>) req.getAttribute("amgen.ri.aig.log.RGSessionLogger.serviceInvocationDetailsList");
      if (serviceInvocationDetailsList != null && serviceInvocationDetailsList.size() > 0) {
        ServiceInvocationDetails serviceInvocationDetails = serviceInvocationDetailsList.get(serviceInvocationDetailsList.size() - 1);
        logEntry.setServiceKey(serviceInvocationDetails.getServiceKey());
        logEntry.setServiceInvokeMillis(serviceInvocationDetails.getInnvocationTimeMillis());
        logEntry.setServiceTransformMillis(serviceInvocationDetails.getTransformTimeMillis());
      }
      logEntry.setElapsedMillis();
      logEntry.performCommit();
      if (serviceInvocationDetailsList != null && serviceInvocationDetailsList.size() > 1) {
        for (int i = 0; i < serviceInvocationDetailsList.size() - 1; i++) {
          LogEntry additionalServiceLogEntry = new LogEntry(logEntry);
          additionalServiceLogEntry.setServiceKey(serviceInvocationDetailsList.get(i).getServiceKey());
          additionalServiceLogEntry.setServiceInvokeMillis(serviceInvocationDetailsList.get(i).getInnvocationTimeMillis());
          additionalServiceLogEntry.setServiceTransformMillis(serviceInvocationDetailsList.get(i).getTransformTimeMillis());
          additionalServiceLogEntry.performCommit(false);
        }
      }
      LogEntry sessionLogEntry = logEntry.updateSessionLogEntry();
      if (sessionLogEntry != null) {
        sessionLogEntry.performCommit(false);
      }
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }
}
