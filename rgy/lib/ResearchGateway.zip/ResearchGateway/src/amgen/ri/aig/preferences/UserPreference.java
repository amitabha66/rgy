package amgen.ri.aig.preferences;

/**
 * <p>@version $Id: UserPreference.java,v 1.4 2012/01/03 21:53:09 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Field;

import org.jdom.Document;

import amgen.ri.rdb.ClobData;
import amgen.ri.rdb.LobSaveable;
import amgen.ri.rdb.OraSequenceField;
import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.SQLManagerIF;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;

/**
 *   RDBData wrapper class for UserPreferences. These are the values for RGPreferences
 *   @version $Revision: 1.4 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class UserPreference extends RdbData implements LobSaveable, PreferenceIF {
  protected OraSequenceField user_preference_id;
  protected String username;
  protected String preference_value;
  protected ClobData preference_data;
  protected RGPreference rg_preference_id;

  /**
   * Default Constructor
   */
  public UserPreference() {
    super();
  }

  /**
   * RdbData Constructor
   */
  public UserPreference(String id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
    this.user_preference_id = new OraSequenceField(id);
  }

  /**
   * RdbData Constructor
   */
  public UserPreference(RGPreference rgPreference, String preferenceValue, String preferenceData, SQLManagerIF sqlManager, String username, String connectionPool) {
    super(sqlManager, username, connectionPool);
    this.setIsDataSet(true, true);
    this.user_preference_id = new OraSequenceField("preference_seq", this);
    this.username = username;
    this.rg_preference_id = rgPreference;
    this.preference_value = preferenceValue;
    this.preference_data = new ClobData(preferenceData);
  }

  /** A required method which returns the primary key(s) of the table/RdbData class. */
  public String getIdentifier() {
    return user_preference_id + "";
  }

  /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
  protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
    field.set(this, value);
  }

  /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
  protected Object getFieldValue(Field field) throws IllegalAccessException {
    return field.get(this);
  }

  /** This method returns the name of the table. */
  protected String getTableName() {
    return "USER_PREFERENCES";
  }

  /** Get value for username */
  public String getUsername() {
    return (String) get("username");
  }

  /** Get value for RGPreference */
  public RGPreference getRGPreference() {
    return (RGPreference) get("rg_preference_id");
  }

  /** Get value for preference_value */
  public String getPreference_value() {
    return (String) get("preference_value");
  }

  /** Get value for preference_data */
  public ClobData getPreference_data() {
    return (ClobData) get("preference_data");
  }
  
  public String getPreferenceData() {
    ClobData clobData= getPreference_data();
    return (clobData== null ? null : clobData.toString());
  }

  /** Get value for preference_data as a JDOM Document*/
  public Document getPreferenceDataDocument() {
    return ExtXMLElement.toDocument(getPreference_data().toString());
  }

  public void setPreferenceData(Document preferenceDataDocument) {
    set("preference_data", ExtXMLElement.toString(preferenceDataDocument));
  }

  public void setPreferenceValue(String preferenceValue) {
    set("preference_value", preferenceValue);
  }

  /** Returns the SQL for INSERTing the object in the table */
  public String getInsertSQL() {
    return null;
  }

  /** Returns the SQL for UPDATing the object in the table */
  public String getUpdateSQL() {
    return null;
  }

  /**
   * Returns the DELETE statement for removing this entry from the database
   */
  public String getDeleteSQL() {
    return null;
  }

  /** Returns the SQL statement which selects for the LOB */
  public String getSelectLobSQL(String fieldName) {
    return null;
  }

  /** Returns a reader which will stream the Clob data */
  public Reader getClobReader(String fieldName) {
    if (fieldName.equals("preference_data")) {
      return ((ClobData) get("preference_data", false)).getClobReader();
    }
    return null;
  }

  /** Returns an inputstream which will stream the Blob data */
  public InputStream getBlobStream(String fieldName) {
    return null;
  }


  /*
   * PreferenceIF Implementations
   */
  /**
   * Returns the Preference name
   * @return String
   */
  public String getPreferenceName() {
    return getRGPreference().getPreference_name();
  }

  /**
   * Returns the Preference Value
   * @return Object
   */
  public Object getPreferenceValue() {
    return getPreference_value();
  }

  /**
   * Tests whether the preference value is not null and equals Yes or True (case-insensitive)
   * Returns false otherwise.
   * @return 
   */
  public boolean getPreferenceBooleanValue() {
    Object value= getPreferenceValue();
    if (value== null) {
      return false;
    }
    return (ExtString.anyIsEqualIgnoreCase(new String[] {"Yes", "True"}, value.toString()));
  }  

  /**
   * Is the current value the default value
   * @return 
   */
  public boolean isDefault() {
    Object value = getPreferenceValue();
    Object defaultValue = getRGPreference().getPreferenceDefaultValue();
    if (value == null || defaultValue == null) {
      return false;
    }
    return (value.equals(defaultValue));
  }
}
