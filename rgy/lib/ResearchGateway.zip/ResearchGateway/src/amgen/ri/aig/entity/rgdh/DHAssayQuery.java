package amgen.ri.aig.entity.rgdh;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleResultSet;
import oracle.xdb.XMLType;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.DOMBuilder;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.entity.assay.AssayResultTypeOperations;
import amgen.ri.aig.entitylist.Alias;
import amgen.ri.aig.sql.RGSQLProvider;
import amgen.ri.json.ExtJSON;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.CompareTerm;
import amgen.ri.rdb.InCompareTerm;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.sql.SQLQuery;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;

/**
 * @version $Id: DHAssayQuery.java,v 1.9 2013/07/09 18:32:09 jemcdowe Exp $
 *
 */
public class DHAssayQuery {
    public enum SearchType {
        ALIAS_ID, ASSAY_ID, RACS, PARENTS
    }


    public enum ContextIndexSectionNames {
        RACID, AACODE, ASSAYNAME, DESCRIPTION, MOLECULARSPECIES, PARENT
    }

    private RGSQLProvider sqlProvider;

    public DHAssayQuery(AIGBase servlet) {
        this.sqlProvider = new RGSQLProvider();
    }

    public JSONObject performSearch2JSON(String query, SearchType searchType, List<String> resultTypes, List<String> selectResultTypes) throws SQLException, JSONException {
        Document assayResultDoc = performSearch(query, searchType, resultTypes);        
        return getAssayJSON(assayResultDoc, selectResultTypes);
    }

    private JSONObject getAssayJSON(Document assayDoc, List<String> selectResultTypes) throws JSONException {
        JSONObject assaysJSON = new JSONObject();
        List<Element> assayEls = ExtXMLElement.getXPathElements(assayDoc, "//Assay");
        for (Element assayEl : assayEls) {
            JSONObject assayObj = getAssayJSON(assayEl, selectResultTypes);
            if (assayObj != null) {
                assaysJSON.append("results", assayObj);
            }
        }
        return assaysJSON;
    }

    private JSONObject getAssayJSON(Element assayEl, List<String> selectResultTypes) throws JSONException {
        AssayResultTypeOperations availableResultTypes = AssayResultTypeOperations.getInstance();
        selectResultTypes = availableResultTypes.verifyResultTypes(selectResultTypes);
        String defaultSelectResultType = null;
        int defaultSelectedResultTypeIndex = -1;

        JSONObject assayJSON = new JSONObject();

        String assayCode = assayEl.getChildText("AssayID");
        boolean isRAC = !ExtString.equals(assayEl.getChildText("IsRAC"), "N");

        if (ExtString.hasLength(assayCode)) {
            assayCode = (assayCode.startsWith("AA") ? assayCode : "AA" + assayCode);
        }
        ExtJSON.addIfNotNull(assayJSON, "assay_code", assayCode);
        ExtJSON.addIfNotNull(assayJSON, "assay_class", (isRAC ? "RAC" : "PARENT"));

        ExtJSON.addIfNotNull(assayJSON, "assay_name", assayEl.getChildText("AssayName"));
        ExtJSON.addIfNotNull(assayJSON, "assay_desc", assayEl.getChildText("Description"));
        ExtJSON.addIfNotNull(assayJSON, "assay_species", assayEl.getChildText("Species"));
        ExtJSON.addIfNotNull(assayJSON, "alias_id", assayEl.getAttributeValue("alias_id"));
        ExtJSON.addIfNotNull(assayJSON, "assay_alias", assayEl.getAttributeValue("alias_name"));
        List<Element> resultTypesEls = ExtXMLElement.getXPathElements(assayEl, "ResultTypes");
        for (Element resultTypeEl : resultTypesEls) {
            JSONObject resultTypeJSON = new JSONObject();
            assayJSON.append("assay_result_types", resultTypeJSON);

            String resultType = resultTypeEl.getAttributeValue("result_type");
            String description = resultTypeEl.getAttributeValue("description");
            String resultCount = resultTypeEl.getAttributeValue("result_count");
            String resultID = resultTypeEl.getAttributeValue("result_type_id");
            String unit = resultTypeEl.getAttributeValue("unit");

            String resultTypeDisplay = resultType + (unit == null ? "" : " (" + unit + ")");

            ExtJSON.addIfNotNull(resultTypeJSON, "result_type_display", resultTypeDisplay);
            ExtJSON.addIfNotNull(resultTypeJSON, "result_type", resultType);
            ExtJSON.addIfNotNull(resultTypeJSON, "result_desc", description);
            ExtJSON.addIfNotNull(resultTypeJSON, "result_count", resultCount);
            ExtJSON.addIfNotNull(resultTypeJSON, "result_id", resultID);
            ExtJSON.addIfNotNull(resultTypeJSON, "result_unit", unit);

            if (defaultSelectResultType == null) {
                defaultSelectResultType = resultType;
                defaultSelectedResultTypeIndex = availableResultTypes.getResultTypeOrder(resultType);
            } else {
                if (availableResultTypes.getResultTypeOrder(resultType) != -1 && availableResultTypes.getResultTypeOrder(resultType) < defaultSelectedResultTypeIndex) {
                    defaultSelectResultType = resultType;
                    defaultSelectedResultTypeIndex = availableResultTypes.getResultTypeOrder(resultType);
                }
            }
            if (selectResultTypes != null && (selectResultTypes.contains(resultType) || selectResultTypes.contains(resultID) || selectResultTypes.contains(resultType.replace(',', ';')))) {
                String selectedResultsTypes = assayJSON.optString("selected_result_types", "");
                String updatedSelectedResultsTypes = resultType;
                if (ExtString.hasLength(selectedResultsTypes)) {
                    updatedSelectedResultsTypes = selectedResultsTypes + "," + resultType.replace(',', ';');
                }
                assayJSON.put("selected_result_types", updatedSelectedResultsTypes);
            }
        }

        if (!assayJSON.has("selected_result_types") && defaultSelectResultType != null) {
            assayJSON.put("selected_result_types", defaultSelectResultType);
        }
        return assayJSON;
    }

    public Document performSearch(String query, SearchType searchType, List<String> resultTypes) throws SQLException {
        AssayResultTypeOperations assayResultTypeOperations = AssayResultTypeOperations.getInstance();
        Pattern assayCodePattern = Pattern.compile("(AA){0,1}([0-9]+)(?::([\\w %]+(?:,[\\w %]+){0,})+){0,1}");

        int matchedAssayID = -1;
        List<Integer> resultTypeIDs = null;
        Matcher assayCodeMatcher = assayCodePattern.matcher(query);
        if (assayCodeMatcher.matches()) {
            resultTypeIDs = new ArrayList<Integer>(assayResultTypeOperations.toResultTypeIDs(resultTypes));
            String queryResultTypes = assayCodeMatcher.group(3);
            if (ExtString.isAInteger(assayCodeMatcher.group(2))) {
                matchedAssayID = ExtString.toInteger(assayCodeMatcher.group(2));
                if (ExtString.hasLength(queryResultTypes)) {
                    List<String> searchResultTypes = (resultTypes == null ? new ArrayList<String>() : new ArrayList(resultTypes));
                    searchResultTypes.addAll(Arrays.asList(queryResultTypes.split(",\\s*")));
                    resultTypeIDs = AssayResultTypeOperations.getInstance().toResultTypeIDs(searchResultTypes);
                }
            }
        }
        Connection rgdhConn = null;
        try {
            rgdhConn = new OraSQLManager().getConnection(JDBCNamesType.RGDH_JDBC+"");

            switch (searchType) {
                case ALIAS_ID:
                    return getAssayElementsFromAliasIDs(rgdhConn, query);
                case ASSAY_ID:
                    if (matchedAssayID != -1) {
                        return getAssays(rgdhConn, matchedAssayID, resultTypeIDs);
                    } else {
                        return new Document(new Element("Assays"));
                    }
                case RACS:
                    if (matchedAssayID != -1) {
                        return getRACs(rgdhConn, matchedAssayID, resultTypeIDs);
                    }
                    return getRACs(rgdhConn, performAssayTextSearch(rgdhConn, query), resultTypeIDs);
                case PARENTS:
                    if (matchedAssayID != -1) {
                        return getParentAssays(rgdhConn, matchedAssayID, resultTypeIDs);
                    }
                    return getParentAssays(rgdhConn, performAssayTextSearch(rgdhConn, query), resultTypeIDs);
            }
        } finally {
            OraSQLManager.closeResources(rgdhConn);
        }
        return new Document(new Element("Assays"));
    }

    public Document getAssays(Connection rgdhConn, int assayID, List<Integer> resultTypes) throws SQLException {
        List<Integer> assayIDList = new ArrayList<Integer>();
        assayIDList.add(assayID);
        return getAssays(rgdhConn, assayIDList, resultTypes);
    }


    public List<Integer> performAssayTextSearch(Connection rgdhConn, String query) throws SQLException {
        List<Integer> assayIDs = new ArrayList<Integer>();
        StringBuffer contextQuery = new StringBuffer();
        for (ContextIndexSectionNames sectionName : ContextIndexSectionNames.values()) {
            if (contextQuery.length() > 0) {
                contextQuery.append(" OR ");
            }
            contextQuery.append("(" + query + " WITHIN " + sectionName + ")");
        }
        if (contextQuery.length() > 0) {
            SQLQuery assayQuery = sqlProvider.getSQLQuery("assays_text_search");
            OraclePreparedStatement stmt = (OraclePreparedStatement) rgdhConn.prepareStatement(assayQuery.getSql());
            stmt.setStringAtName("context_query", contextQuery.toString());
            OracleResultSet rset = (OracleResultSet) stmt.executeQuery();
            while (rset.next()) {
                assayIDs.add(rset.getInt("assay_id"));
            }
            stmt.close();
        }
        return assayIDs;
    }

    public Document getRACs(Connection rgdhConn, int assayID, List<Integer> resultTypes) throws SQLException {
        List<Integer> assayIDs = new ArrayList<Integer>();
        assayIDs.add(assayID);
        return getRACs(rgdhConn, assayIDs, resultTypes);
    }

    public Document getRACs(Connection rgdhConn, List<Integer> assayIDs, List<Integer> resultTypes) throws SQLException {
        Document assaysDocument = new Document(new Element("Assays"));
        if (!ExtArray.hasLength(assayIDs)) {
        	return assaysDocument;
        }
        String assaySQL;
        if (ExtArray.hasLength(resultTypes)) {
            SQLQuery assayQuery = sqlProvider.getSQLQuery("assays_for_assay_id_filter_result_types");
            assaySQL = assayQuery.getSql().replaceAll(":assay_id", ExtString.join(assayIDs, ','));
            assaySQL = assaySQL.replaceAll(":result_type_key", ExtString.join(resultTypes, ','));
        } else {
            SQLQuery assayQuery = sqlProvider.getSQLQuery("assays_for_assay_id");
            assaySQL = assayQuery.getSql().replace(":assay_id", ExtString.join(assayIDs, ','));
        }
        OraclePreparedStatement stmt = (OraclePreparedStatement) rgdhConn.prepareStatement(assaySQL);
        stmt.setStringAtName("is_rac", "Y");
        OracleResultSet rset = (OracleResultSet) stmt.executeQuery();
        if (rset.next()) {
            XMLType xml = (XMLType) rset.getObject(1);
            org.w3c.dom.Document w3Doc = xml.getDOM();
            assaysDocument = new DOMBuilder().build(w3Doc);
        }
        stmt.close();
        return assaysDocument;
    }

    public Document getParentAssays(Connection rgdhConn, int assayID, List<Integer> resultTypes) throws SQLException {
        List<Integer> assayIDs = new ArrayList<Integer>();
        assayIDs.add(assayID);
        return getParentAssays(rgdhConn, assayIDs, resultTypes);
    }

    public Document getParentAssays(Connection rgdhConn, List<Integer> assayIDs, List<Integer> resultTypes) throws SQLException {
        Document assaysDocument = new Document(new Element("Assays"));
        String assaySQL;
        if (ExtArray.hasLength(resultTypes)) {
            SQLQuery assayQuery = sqlProvider.getSQLQuery("assays_for_assay_id_filter_result_types");
            assaySQL = assayQuery.getSql().replaceAll(":assay_id", ExtString.join(assayIDs, ','));
            assaySQL = assaySQL.replaceAll(":result_type_key", ExtString.join(resultTypes, ','));
        } else {
            SQLQuery assayQuery = sqlProvider.getSQLQuery("assays_for_assay_id");
            assaySQL = assayQuery.getSql().replaceAll(":assay_id", ExtString.join(assayIDs, ','));
        }
        OraclePreparedStatement stmt = (OraclePreparedStatement) rgdhConn.prepareStatement(assaySQL);
        stmt.setStringAtName("is_rac", "N");
        OracleResultSet rset = (OracleResultSet) stmt.executeQuery();
        if (rset.next()) {
            XMLType xml = (XMLType) rset.getObject(1);
            org.w3c.dom.Document w3Doc = xml.getDOM();
            assaysDocument = new DOMBuilder().build(w3Doc);
        }
        stmt.close();
        return assaysDocument;
    }

    public Document getAssays(Connection rgdhConn, List<Integer> assayIDs, List<Integer> resultTypes) throws SQLException {
        Document assaysDocument = new Document(new Element("Assays"));
        String assaySQL;
        if (ExtArray.hasLength(resultTypes)) {
            SQLQuery assayQuery = sqlProvider.getSQLQuery("assay_from_assay_id_filter_result_types");
            assaySQL = assayQuery.getSql().replaceAll(":assay_id", ExtString.join(assayIDs, ','));
            assaySQL = assaySQL.replaceAll(":result_type_key", ExtString.join(resultTypes, ','));
        } else {
            SQLQuery assayQuery = sqlProvider.getSQLQuery("assay_from_assay_id");
            assaySQL = assayQuery.getSql().replaceAll(":assay_id", ExtString.join(assayIDs, ','));
        }
        OraclePreparedStatement stmt = (OraclePreparedStatement) rgdhConn.prepareStatement(assaySQL);
        OracleResultSet rset = (OracleResultSet) stmt.executeQuery();
        if (rset.next()) {
            XMLType xml = (XMLType) rset.getObject(1);
            org.w3c.dom.Document w3Doc = xml.getDOM();
            assaysDocument = new DOMBuilder().build(w3Doc);
        }
        stmt.close();
        return assaysDocument;
    }

    /**
     * Returns AssayDetails for an alias ID
     * The alias ID may be of the form <alias ID>[:<Result Type1>,<Result Type2>,...] and is
     * parsed with the provided result types added as selected result types
     * after the search. Otherwise, the selected result types are those defined in the alias
     *
     * @param request HttpServletRequest
     * @param aliasID String
     * @return AssayDetails
     */
    public Document getAssayElementsFromAliasIDs(Connection rgdhConn, String aliasIDs) throws SQLException {
        Document assaysDocument = new Document(new Element("Assays"));

        List<Alias> aliasResults = new RdbDataArray(Alias.class, new CompareTerm[] {
            new InCompareTerm("ALIAS_ID", aliasIDs.split(",")),
                    new CompareTerm("ALIAS_TYPE", "ASSAY")
        }, new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");

        for (Alias alias : aliasResults) {
            if (alias.setData()) {
                String aliasValue = alias.getAlias_value();
                String[] assayIDSplit = aliasValue.split(":", 2);
                int assayID = 0;
                List<Integer> resultTypeIDs = new ArrayList<Integer>();

                if (assayIDSplit.length > 0) {
                    assayIDSplit[0] = assayIDSplit[0].replaceFirst("AA", "");
                    if (ExtString.isAInteger(assayIDSplit[0])) {
                        assayID = ExtString.toInteger(assayIDSplit[0]);
                    }
                }
                if (assayIDSplit.length > 1) {
                    List<String> resultTypes = Arrays.asList(assayIDSplit[1].split(","));
                    resultTypeIDs = AssayResultTypeOperations.getInstance().toResultTypeIDs(resultTypes);
                }
                if (assayID != 0) {
                    Document resultAssaysDocument = getAssays(rgdhConn, assayID, resultTypeIDs);
                    List<Element> assayEls = ExtXMLElement.getXPathElements(resultAssaysDocument, "//Assay[count(ResultTypes)> 0");
                    for (Element assayEl : assayEls) {
                        if (ExtString.hasLength(alias.getIdentifier()) && ExtString.hasLength(alias.getAlias_name())) {
                            assayEl.setAttribute("alias_id", alias.getIdentifier());
                            assayEl.setAttribute("alias_name", alias.getAlias_name());
                        }
                        assaysDocument.getRootElement().addContent((Element) assayEl.clone());
                    }
                }
            }
        }
        return assaysDocument;
    }

    /**
     * Returns AssayDetails for an alias ID
     * The alias ID may be of the form <alias ID>[:<Result Type1>,<Result Type2>,...] and is
     * parsed with the provided result types added as selected result types
     * after the search. Otherwise, the selected result types are those defined in the alias
     *
     * @param request HttpServletRequest
     * @param aliasID String
     * @return AssayDetails
     */
    public Document getAssayElementsFromAliasName(Connection rgdhConn, String aliasName) throws SQLException {
        Document assaysDocument = new Document(new Element("Assays"));

        List<Alias> aliasResults = new RdbDataArray(Alias.class, new CompareTerm[] {
            new CompareTerm("UPPER(REGEXP_REPLACE(ALIAS_NAME, '[^[:alnum:]]', ''))", aliasName.toUpperCase().replaceAll("[^\\p{Alnum}]", "")),
                    new CompareTerm("ALIAS_TYPE", "ASSAY")
        }, new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");

        for (Alias alias : aliasResults) {
            if (alias.setData()) {
                String aliasValue = alias.getAlias_value();
                String[] assayIDSplit = aliasValue.split(":", 2);
                int assayID = 0;
                List<Integer> resultTypeIDs = new ArrayList<Integer>();

                if (assayIDSplit.length > 0) {
                    assayIDSplit[0] = assayIDSplit[0].replaceFirst("AA", "");
                    if (ExtString.isAInteger(assayIDSplit[0])) {
                        assayID = ExtString.toInteger(assayIDSplit[0]);
                    }
                }
                if (assayIDSplit.length > 1) {
                    List<String> resultTypes = Arrays.asList(assayIDSplit[1].split(","));
                    resultTypeIDs = AssayResultTypeOperations.getInstance().toResultTypeIDs(resultTypes);
                }
                if (assayID != 0) {
                    Document resultAssaysDocument = getAssays(rgdhConn, assayID, resultTypeIDs);
                    List<Element> assayEls = ExtXMLElement.getXPathElements(resultAssaysDocument, "//Assay[count(ResultTypes)> 0");
                    for (Element assayEl : assayEls) {
                        if (ExtString.hasLength(alias.getIdentifier()) && ExtString.hasLength(alias.getAlias_name())) {
                            assayEl.setAttribute("alias_id", alias.getIdentifier());
                            assayEl.setAttribute("alias_name", alias.getAlias_name());
                        }
                        assaysDocument.getRootElement().addContent((Element) assayEl.clone());
                    }
                }
            }
        }
        return assaysDocument;
    }

}
