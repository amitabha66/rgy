package amgen.ri.aig.entity.provider;

import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;

public abstract class AbstractEntityDetails implements EntityDetailsResponseIF {
    private AIGServlet requestor;
    private EntityListCategory entityType;

    /**
     * Default constructor
     */
    public AbstractEntityDetails(AIGServlet requestor, EntityListCategory entityType) {
        super();
        this.requestor = requestor;
        this.entityType = entityType;
    }

    public static AbstractEntityDetails getEntityDetails(AIGServlet requestor) {
        EntityListCategory entityType = requestor.getEntityClassManager().convertServiceDataCategoryToEntityListCategory(ServiceDataCategory.fromString(requestor.getParameter("type")));
        switch (entityType) {
            case COMPOUNDS:
                return new CompoundEntityDetails(requestor);
            case ASSAYS:
                return new AssayEntityDetails(requestor);
            default:
                return null;
        }
    }


    protected AIGServlet getRequestor() {
        return requestor;
    }


}
