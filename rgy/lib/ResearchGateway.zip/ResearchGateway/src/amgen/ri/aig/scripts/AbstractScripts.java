package amgen.ri.aig.scripts;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.jdom.Element;
import org.mozilla.javascript.Context;

import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;

/**
 * Common methods for Script sources
 *
 * @version $Id: AbstractScripts.java,v 1.2 2011/06/21 17:28:58 cvs Exp $
 *
 */
public abstract class AbstractScripts implements CalculationMethodsIF {
    private EntityListCategory entityType;
    private File scriptFileDir;


    /**
     * Creates a new AbstractScripts object from subclasses
     *
     * @param entityType EntityListCategory
     * @param scriptFileDir File
     */
    public AbstractScripts(EntityListCategory entityType, File scriptFileDir) {
        this.entityType = entityType;
        this.scriptFileDir = scriptFileDir;
    }

    /**
     * Returns the EntityListCategory for the requested scripts
     *
     * @return EntityListCategory
     */
    public EntityListCategory getEntityListCategory() {
        return entityType;
    }

    /**
     * Returns the source script directory. This is the directory searched for
     * JS sources included as relative paths
     *
     * @return File
     */
    public File getScriptFileDir() {
        return scriptFileDir;
    }

    public List<Element> getMethodGroups(EntityListCategory entityType) {
        if (getMethodDocument() == null) {
            return new ArrayList<Element>();
        }
        return ExtXMLElement.getXPathElements(getMethodDocument(), "//MethodGroup[count(@entity_type)=0 or upper-case(@entity_type)='" + entityType + "']");
    }

    /**
     * Returns the Methods in a given MethodGroup
     *
     * @param methodGroupEl Element
     * @return List
     */
    public List<Element> getMethodsForGroup(Element methodGroupEl) {
        if (getMethodDocument() == null || methodGroupEl == null) {
            return new ArrayList<Element>();
        }
        return ExtXMLElement.getXPathElements(methodGroupEl, "Method[count(@entity_type)=0 or upper-case(@entity_type)='" + getEntityListCategory() + "']");
    }

    /**
     * Returns the available methods as a JSON object in the format:
     * {
     *   methods: [
     *     method_name:          <method_name>
     *     method_label:         <method_label>
     *     method_description:   <method_description>
     *     method_help:          <method_help>
     *     method_parmeter_list: <method_parmeter_list>
     *     method_group:         <method_group>
     *   ]
     * }
     *
     * @return JSONObject
     */
    public JSONObject getMethodsAsJSON() {
        JSONObject methodsJSON = new JSONObject();
        List<Element> methodGroupEls = getMethodGroups(getEntityListCategory());
        for (Element methodGroupEl : methodGroupEls) {
            String methodGroupName = methodGroupEl.getChildText("Name");
            String className = methodGroupEl.getChildText("ClassName");
            if (ExtString.hasLength(className)) {
                Class scriptClass = getScriptMethodsClass(className);
                if (scriptClass == null) {
                    continue;
                }
            }
            List<Element> methodEls = getMethodsForGroup(methodGroupEl);
            for (Element method : methodEls) {
                String methodName = method.getChildText("Name");
                String methodLabel = method.getChildText("Label");
                methodLabel = (ExtString.hasLength(methodLabel) ? methodLabel : methodName);
                String methodDescription = method.getChildText("Description");
                String methodParameterList = method.getChildText("ParameterList");
                String methodHelp = method.getChildText("Help");
                JSONObject methodJSON = new JSONObject();
                try {
                    methodJSON.put("method_name", methodName);
                    methodJSON.put("method_label", methodLabel);
                    methodJSON.put("method_description", methodDescription);
                    methodJSON.put("method_help", methodHelp);
                    methodJSON.put("method_parmeter_list", methodParameterList);
                    methodJSON.put("method_group", methodGroupName);
                    methodsJSON.append("methods", methodJSON);
                } catch (JSONException ex) {
                }
            }
        }
        return methodsJSON;
    }


    /**
     * Confirms that the script is syntactically correct. This does not ensure
     * that the script is error-free, just that it does not have syntax errors
     * that will keep the interpreter from the compiling.
     *
     * @param name String
     * @param code String
     * @return boolean
     */
    public boolean validScriptSource(String name, String code) {
        Context cx = Context.enter();
        try {
            cx.compileString(code, name, 1, null);
        } catch (Exception e) {
            System.err.println("WARNING: Unable to load script method " + name + " due to a syntax error. " + e);
            return false;
        } finally {
            // Exit from the context.
            Context.exit();
        }
        return true;
    }

    /**
     * Returns the Class for a given class name. Returns a null if it can not be
     * loaded.
     *
     * @param className String
     * @return Class
     */
    protected Class getScriptMethodsClass(String className) {
        try {
            Class clazz = Class.forName(className);
            if (clazz.getSuperclass() != AbstractScriptMethods.class) {
                throw new NoClassDefFoundError("Script classes must extend " + AbstractScriptMethods.class);
            }
            return clazz;
        } catch (Exception ex) {
            System.err.println("Unable to load script class " + className + ". " + ex);
        }
        return null;
    }


}
