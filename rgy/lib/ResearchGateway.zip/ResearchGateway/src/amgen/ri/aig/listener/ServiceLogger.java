package amgen.ri.aig.listener;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.ServiceInvocationDetails;
import amgen.ri.asf.sa.uddi.ServiceListenerIF;
import amgen.ri.ldap.AmgenLocationCode;
import amgen.ri.servlet.SessionLogin;
import amgen.ri.util.Debug;
import amgen.ri.util.PrintfFormat;

/**
 * A service listener which handles logging information about service calls
 *
 * @version $Id: ServiceLogger.java,v 1.4 2015/03/24 21:14:27 jemcdowe Exp $
 */
public class ServiceLogger implements ServiceListenerIF {

  public static Logger logger = Logger.getLogger("rgservice");
  public static Logger serviceErrorLogger = Logger.getLogger("rgserviceerror");
  private String sessionKey = "Unknown";
  private String sessionUser = "Unknown";
  private String sessionLogin = "Unknown";
  private AmgenLocationCode sessionLocation = AmgenLocationCode.USTO;
  private String hostName = "Unknown";
  private PrintfFormat pf = new PrintfFormat("\nr%s  %s\n%s (%s)\n%s\n");

  public ServiceLogger(HttpSession session) {
    try {
      this.sessionKey = session.getId();
      SessionLogin sessionLoginUser = SessionLogin.getSessionLogin(session);
      if (sessionLoginUser != null) {
        this.sessionLogin = sessionLoginUser.getRemoteUser();
        this.sessionUser = sessionLoginUser.getUserLedgerDisplayName();
        this.sessionLocation = sessionLoginUser.getUserAmgenLocationCode();
      }
      if (sessionLoginUser instanceof AIGSessionLogin) {
        this.hostName = ((AIGSessionLogin) sessionLoginUser).getAIGSessionLogin(session).getRgServerAndPort();
      }
    } catch (Exception e) {
      System.err.println("Error setting up ServiceLogger. " + e);
    }
  }

  /**
   * serviceStarted
   *
   * @param serviceDetails ServiceDetails
   */
  public boolean serviceStarted(ServiceDetails serviceDetails) {
    return true;
  }

  /**
   * transformStarted
   *
   * @param serviceDetails ServiceDetails
   * @return boolean
   */
  public boolean transformStarted(ServiceDetails serviceDetails) {
    return true;
  }

  /**
   * transformEnded
   *
   * @param serviceDetails ServiceDetails
   * @param details ServiceInvocationDetails
   */
  public void transformEnded(ServiceDetails serviceDetails, ServiceInvocationDetails details) {
    if (serviceDetails != null) {
      write2Logger(serviceDetails, details);
    }
  }

  /**
   * serviceEnded
   *
   * @param serviceDetails ServiceDetails
   */
  public void serviceEnded(ServiceDetails serviceDetails, ServiceInvocationDetails details) {
    if (serviceDetails != null) {
      write2Logger(serviceDetails, details);
    }
  }

  public void serviceFailed(ServiceDetails serviceDetails, ServiceInvocationDetails details) {
    if (serviceDetails != null) {
      write2Logger(serviceDetails, details);
    }
  }

  private void write2Logger(ServiceDetails serviceDetails, ServiceInvocationDetails details) {
    if (details == null || logger == null) {
      return;
    }
    try {
      String message = String.format("\nSession: %s (%s), %s [%s]\nServer: %s\n%s\n%s", new Object[]{
        sessionUser,
        sessionLogin,
        sessionLocation.toString(),
        sessionKey,
        hostName,
        details.toString(),
        serviceDetails.getDebug()});

      logger.debug(message, details.getFailureException());

      if (details.getFailureException() != null) {
        serviceErrorLogger.error(message, details.getFailureException());
      }
    } catch (Exception e) {
      //e.printStackTrace();
      System.err.println("Error writing to ServiceLogger. " + e);
    }
  }

}
