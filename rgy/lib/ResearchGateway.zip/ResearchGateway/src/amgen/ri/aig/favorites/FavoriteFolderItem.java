/*
 *   FavoriteFolderItem
 *   RDBData wrapper class for ACCESS_CONTROL
 *   $Revision: 1.7 $
 *   Created: Jeffrey McDowell, 14 Apr 2011
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.favorites;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.rdb.*;
import amgen.ri.security.IdentityIF;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtString;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

/**
 * RDBData wrapper class for ACCESS_CONTROL
 *
 * @version $Revision: 1.7 $
 * @author Jeffrey McDowell
 * @author $Author: cvs $
 */
public class FavoriteFolderItem extends AbstractFavoriteFolderItem implements Saveable, Removeable, FavoriteFolderItemIF {
  protected OraSequenceField favorites_folder_item_id;
  protected String owned_by;
  protected String item_type;
  protected int item_key;
  protected FavoriteFolder folder_id;
  private FavoriteIF item;
  private Person createdByPerson;
  private Person modifiedByPerson;

  public enum ItemType {
    FAVORITE, SHARED_FAVORITE, UNKNOWN
  }

  /**
   * Default Constructor
   */
  public FavoriteFolderItem() {
    super();
  }

  /**
   * RdbData Constructor
   */
  public FavoriteFolderItem(String favorites_folder_item_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
    this.favorites_folder_item_id = new OraSequenceField(favorites_folder_item_id);
  }

  /**
   * Constructor which sets the class variables
   */
  public FavoriteFolderItem(FavoriteIF favorite, FavoriteFolder parentFolder, SQLManagerIF sqlManager, String ownedBy, String connectionPool) {
    super(sqlManager, ownedBy, connectionPool);
    if (parentFolder == null) {
      throw new IllegalArgumentException("Parent folder can not be null");
    }
    if (parentFolder.getFolderID() > 0 && !ExtString.equals(parentFolder.getCreatedBy(), favorite.getCreated_by())) {
      throw new IllegalArgumentException("Can not create a folder item in a folder owned by another user");
    }
    this.favorites_folder_item_id = new OraSequenceField("favorite_folders_seq", this);
    this.owned_by = ownedBy;

    if (favorite instanceof Favorite) {
      this.item_type = ItemType.FAVORITE.toString();
    } else if (favorite instanceof SharedFavorite) {
      this.item_type = ItemType.SHARED_FAVORITE.toString();
    } else {
      throw new IllegalArgumentException("Unknown favorite type");
    }

    this.folder_id = parentFolder;
    this.item_key = ExtString.toInteger(favorite.getIdentifier());
  }

  /**
   * A required method which returns the primary key(s) of the table/RdbData
   * class.
   */
  public String getIdentifier() {
    return favorites_folder_item_id + "";
  }

  /**
   * This method returns the name of the table.
   */
  protected String getTableName() {
    return "FAVORITES_FOLDER_ITEM";
  }

  /**
   * Get value for favorites_folder_item_id
   */
  public int getFavorites_folder_item_id() {
    return getAsNumber("favorites_folder_item_id", false).intValue();
  }

  /**
   * Set value for favorites_folder_item_id
   */
  public void setFavorites_folder_item_id(int favorites_folder_item_id) {
    set("favorites_folder_item_id", new Integer(favorites_folder_item_id));
  }

  /**
   * Returns owned_by
   *
   * @return String
   */
  public String getOwnedBy() {
    return (String) get("owned_by");
  }

  /**
   * Get value for item_type
   */
  public ItemType getItem_type() {
    try {
      return ItemType.valueOf((String) get("item_type"));
    } catch (Exception e) {
      return ItemType.UNKNOWN;
    }
  }

  /**
   * Set value for item_type
   */
  public void setItem_type(String item_type) {
    set("item_type", item_type);
  }

  /**
   * Get value for item_key
   */
  public int getItem_key() {
    return getAsNumber("item_key").intValue();
  }

  /**
   * Set value for item_key
   */
  public void setItem_key(int item_key) {
    set("item_key", new Integer(item_key));
  }

  public FavoriteIF getItem() {
    if (item == null) {
      switch (getItem_type()) {
        case FAVORITE:
          item = new Favorite(getItem_key() + "", getSQLManager(), getLogonUsername(), getConnectionPool());
          break;
        case SHARED_FAVORITE:
          item = new SharedFavorite(getItem_key() + "", getSQLManager(), getLogonUsername(), getConnectionPool());
          break;
        case UNKNOWN:
          throw new IllegalArgumentException("Unknon item type- "+ get("item_type"));
      }
    }
    return item;
  }

  public String getName() {
    FavoriteIF item = getItem();
    if (item == null) {
      return null;
    }
    return item.getName();
  }

  public String getDescription() {
    FavoriteIF item = getItem();
    if (item == null) {
      return null;
    }
    return item.getDescription();
  }

  public String getCreatedBy() {
    FavoriteIF item = getItem();
    if (item == null) {
      return null;
    }
    return item.getCreated_by();
  }

  public Date getCreated() {
    FavoriteIF item = getItem();
    if (item == null) {
      return null;
    }
    return item.getCreatedDate();
  }

  /**
   * Returns whether this Favorite is valid an should be included in any lists
   * of Favorites
   *
   * @return boolean
   */
  public boolean isValid(AIGBase requestor) {    
    return (setData() && getItem().isValid(requestor));
  }
  /**
   * Returns the FolderItem as a JSON object
   * @param identity
   * @return
   * @throws JSONException 
   */
  public JSONObject asJSON(IdentityIF identity) {
    JSONObject jFolderItem = new JSONObject();
    try {
    jFolderItem.put("id", getIdentifier());
    jFolderItem.put("parent_id", getFolder().getFolderID());
    jFolderItem.put("name", getName());
    jFolderItem.put("text", getName());
    jFolderItem.putOpt("description", getDescription());
    jFolderItem.put("created_by", (getCreatedByPerson() == null ? null : getCreatedByPerson().getFirst() + " "
            + getCreatedByPerson().getLast()));
    String createdDate = identity.convertToUserTimeZone("MM/dd/yyyy hh:mm:ss a", (getCreated() == null ? new Date()
            : getCreated()), TimeZone.getTimeZone("PST"));
    jFolderItem.put("created", createdDate);
    jFolderItem.putOpt("is_owner", getCreatedBy().equals(identity.getUsername()));


    jFolderItem.put("modified_by", (getCreatedByPerson() == null ? null : getCreatedByPerson().getFirst() + " "
            + getCreatedByPerson().getLast()));
    String modifiedDate = identity.convertToUserTimeZone("MM/dd/yyyy hh:mm:ss a", getCreated(), TimeZone.getTimeZone("PST"));
    jFolderItem.put("modified", modifiedDate);
    jFolderItem.put("leaf", true);
    Favorite favorite = null;
    try {
      switch (getItem_type()) {
        case FAVORITE:
          jFolderItem.put("type", "ITEM");
          jFolderItem.putOpt("can_delete", getCreatedBy().equals(identity.getUsername()));
          favorite = (Favorite) getItem();
          break;
        case SHARED_FAVORITE:
          jFolderItem.put("type", "SHARED_ITEM");
          SharedFavorite sharedFavorite = (SharedFavorite) getItem();
          jFolderItem.putOpt("can_delete", sharedFavorite.getShared_with().equals(identity.getUsername()));
          String sharedDate = identity.convertToUserTimeZone("MM/dd/yyyy hh:mm:ss a", sharedFavorite.getSharedDate(), TimeZone.getTimeZone("PST"));
          jFolderItem.putOpt("shared", sharedDate);
          favorite = sharedFavorite.getFavorite();
          break;
      }
    } catch (Exception e) {
    }
    if (favorite != null) {
      jFolderItem.put("subtype", favorite.getObjectType().getType().toString());
      jFolderItem.put("category", favorite.getCategory());
      switch (favorite.getCategory()) {
        case SQUID_NUCLEOTIDE_SEQUENCES:
          jFolderItem.put("category_label", "Nucleotide Sequences");
          break;
        case SQUID_PROTEIN_SEQUENCES:
          jFolderItem.put("category_label", "Protein Sequences");
          break;
        case AMGEN_GENES:
          jFolderItem.put("category_label", "Genes");
          break;
        default:
          jFolderItem.put("category_label", EntityListCategory.revertTo(favorite.getCategory()));
          break;
      }

      switch (favorite.getObjectType().getType()) {
        case LIST:
          jFolderItem.put("iconCls", "list-fav");
          break;
        case ENTITYTABLE:
          jFolderItem.put("iconCls", "table-fav");
          break;
        case PROJECTVIEW:
          jFolderItem.put("iconCls", "view-fav");
          break;
        case SERVICE:
          jFolderItem.put("iconCls", "service-fav");
          break;
      }
      SharedFavorite[] shares = favorite.getShares();
      if (ExtArray.hasLength(shares)) {
        List<String> shareUsernames = new ArrayList<String>();
        for (SharedFavorite share : shares) {
          shareUsernames.add(share.getShared_with());
        }
        jFolderItem.put("shared_with", ExtString.join(shareUsernames, ','));
      }
    }
    } catch(JSONException e) {
      e.printStackTrace();
    }
    return jFolderItem;
  }

  /**
   * Gets the created_by as a Person
   */
  public Person getCreatedByPerson() {
    if (getCreatedBy() == null) {
      return null;
    }
    if (createdByPerson == null) {
      createdByPerson = Person.getPersonForAmgenLogin(getCreatedBy(), getSQLManager(), getConnectionPool());
    }
    return createdByPerson;
  }

  /**
   * Get value for folder_id
   */
  public FavoriteFolder getFolder() {
    return (FavoriteFolder) get("folder_id");
  }

  /**
   * Set value for parent_folder_id
   */
  public void setParentFolder(FavoriteFolder parentFolder) {
    if (parentFolder.equals(getFolder())) {
      throw new IllegalArgumentException("Folder already the parent folder");
    }
    set("folder_id", parentFolder);
  }

  public int performDelete(boolean deleteItem, String sessionLogin) {
    int itemDeleteCount = 0;
    if (deleteItem) {
      switch (getItem_type()) {
        case FAVORITE:
          itemDeleteCount += ((Favorite) getItem()).performDelete(sessionLogin);
          break;
        case SHARED_FAVORITE:
          itemDeleteCount += ((SharedFavorite) getItem()).performDelete(sessionLogin);
          break;
      }
    }
    int folderItemDeleteCount = super.performDelete();
    return folderItemDeleteCount + itemDeleteCount;
  }

  public int performCommit() {
    int itemCount = 0;
    RdbData item = (RdbData) getItem();
    if (item.setData()) {
      itemCount += item.performCommit();
    }
    return super.performCommit() + itemCount;
  }
}
