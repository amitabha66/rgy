package amgen.ri.aig.sv;

import java.io.ObjectStreamException;

import amgen.ri.aig.AIGServlet;
import amgen.ri.util.ExtString;

/**
 * Enumeration for the Query service request
 */
public enum ExecuteQueryRequest {
    RUN_QUERYSERVICE, RUN_QUICKSEARCH, RUN_STRUCTURESEARCH, RUN_SAVEDSERVICE, LOAD_LIST, LOAD_TABLE, LOAD_LIST_FROM_PROJECTVIEW,
            LOAD_VIEW, QUICKLOAD_VIEW, RUN_VQT, RUN_VQT_COUNT, VQT_FOLDERITEMS,
            LOAD_FAVORITE_FOLDERITEM,
            UNKNOWN;


    public static ExecuteQueryRequest fromString(String s) {
        if (s == null) {
            return UNKNOWN;
        }
        return ExecuteQueryRequest.valueOf(s.toUpperCase());
    }

    public static ExecuteQueryRequest getValue(AIGServlet servlet) {
        if (ExtString.anyIsEqualIgnoreCase(new String[] {"VQTViewLoader", "RGViewLoader"}, servlet.getParameter("serviceKey"))) {
            return QUICKLOAD_VIEW;
        }
        if (servlet.doesParameterExist("view_id", true)) {
            return LOAD_VIEW;
        }        
        if (servlet.doesParameterExist("quick_search")) {
            return RUN_QUICKSEARCH;
        }
        if (servlet.doesParameterExist("list_id", true)) {
            return LOAD_LIST;
        }
        if (servlet.doesParameterExist("table_id", true)) {
            return LOAD_TABLE;
        }

        if (servlet.doesParameterExist("saved_service_id", true)) {
            return RUN_SAVEDSERVICE;
        }
        if (servlet.doesParameterExist("pv_resultKey", true)) {
            return LOAD_LIST_FROM_PROJECTVIEW;
        }
        if (servlet.doesParameterExist("serviceKey", true)) {
            if (servlet.doesParameterEqual("serviceKey", "structure_search")) {
                return RUN_STRUCTURESEARCH;
            }
            return RUN_QUERYSERVICE;
        }
        if (servlet.doesParameterExist("mqe")) {
            return RUN_VQT;
        }
        if (servlet.doesParameterExist("vqt_resultcount")) {
            return RUN_VQT_COUNT;
        }
        if (servlet.doesParameterExist("vqt") && servlet.doesParameterExist("node")) {
            return VQT_FOLDERITEMS;
        }
        if (servlet.doesParameterExist("favorite_folderitem_id")) {
            return LOAD_FAVORITE_FOLDERITEM;
        }

        return UNKNOWN;
    }

    /**
     * This is necessary to permit Serializable.
     * A Serialized object containing an enum class variable is not de-Serialized properly.
     * This forces de-Serialized enum to be re-created as this enum through the String
     * @return Object
     * @throws ObjectStreamException
     */
    public Object readResolve() throws ObjectStreamException {
        return ExecuteQueryRequest.fromString(this.toString());
    }

}
