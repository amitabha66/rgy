package amgen.ri.aig.entity.provider;

import org.jdom.Document;

import amgen.ri.aig.AIGException;
import amgen.ri.json.JSONObject;

public interface EntityDetailsResponseIF {
    /**
     * Returns the response as a JDOM element
     *
     * @return Element
     * @throws AIGException
     */
    public Document getResponseDocument() throws AIGException;

    /**
     * Returns the response as a JSONObject
     *
     * @return JSONObject
     * @throws AIGException
     */
    public JSONObject getResponseJSON() throws AIGException;
}
