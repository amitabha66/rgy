/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.loft;

import java.lang.reflect.Field;
import amgen.ri.rdb.*;
/**
 *
 * @author jemcdowe
 */
public class RGPageTag extends RdbData {
  protected int rg_app_pagetags_id;
  protected int rg_app_id;
  protected int rg_page_id; 

  /**
   * Default Constructor
   */
  public RGPageTag() {
    super();
  }

  /**
   * RdbData Constructor
   */
  public RGPageTag(String rg_app_pagetags_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
    this.rg_app_pagetags_id = new Integer(rg_app_pagetags_id);
  }

  /** A required method which returns the primary key(s) of the table/RdbData class. */
  public String getIdentifier() {
    return rg_app_pagetags_id+"";
  }

  /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
  protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
    field.set(this, value);
  }

  /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
  protected Object getFieldValue(Field field) throws IllegalAccessException {
    return field.get(this);
  }

  @Override
  public String getTableName() {
    return "RG_APP_PAGETAGS";
  }
  
  public int getRGAppID() {
    return getAsNumber("rg_app_id").intValue();
  }
  
  public int getRGPageID() {
    return getAsNumber("rg_page_id").intValue();
  }
  
}
