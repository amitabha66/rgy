package amgen.ri.aig.cache.mgr;

import java.io.ObjectStreamException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.CacheManager;
import amgen.ri.aig.cache.CacheManagerFactory;
import amgen.ri.aig.cache.CacheType;
import amgen.ri.json.JSONObject;
import javax.servlet.annotation.WebServlet;

/**
 * Servlet endpoint to manage the global cache
 *
 * @version $id$
 */
@WebServlet(name = "ManageSessionCache", urlPatterns = {"/managesessioncache.go", "/managesessioncache"})
public class ManageSessionCache extends AIGServlet {

  enum ManageSessionCacheType {

    STATS, REMOVEALLOBJECTS, REMOVERESULTOBJECTS, UNKNOWN;

    public static ManageSessionCacheType fromString(String s) {
      if (s == null) {
        return UNKNOWN;
      }
      try {
        return ManageSessionCacheType.valueOf(s.toUpperCase());
      } catch (Exception e) {
        return UNKNOWN;
      }
    }

    /**
     * This is necessary to permit Serializable. A Serialized object containing
     * an enum class variable is not de-Serialized properly. This forces
     * de-Serialized enum to be re-created as this enum through the String
     *
     * @return Object
     * @throws ObjectStreamException
     */
    public Object readResolve() throws ObjectStreamException {
      return ManageSessionCacheType.fromString(this.toString());
    }

  }

  public ManageSessionCache() {
    super();
  }

  public ManageSessionCache(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  /**
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return TBXServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new ManageSessionCache(req, resp);
  }

  /**
   *
   * @return String
   */
  protected String getServletMimeType() {
    switch (ManageSessionCacheType.fromString(getParameter("req"))) {
      case STATS:
        return "text/json";
      default:
        return "text/xml";
    }
  }

  /**
   *
   * @throws Exception
   */
  protected void performRequest() throws Exception {
    setNoCache();
    int deleteCount = 0;
    switch (ManageSessionCacheType.fromString(getParameter("req"))) {
      case STATS:
        JSONObject json = new JSONObject();
        json.put("statistics", CacheManagerFactory.getCacheManagerInstance(getHttpSession()).getStats());
        response.getWriter().println(json);
        return;
      case REMOVERESULTOBJECTS:
        String keys = getParameter("keys");
        if (keys != null) {
          List<String> keyList = Arrays.asList(keys.split("\\s*,\\s*"));
          deleteCount = keyList.size();
          CacheManagerFactory.getCacheManagerInstance(getHttpSession()).remove(CacheType.SERVICERESULT, keyList);
        }
        break;
      case REMOVEALLOBJECTS:
        CacheManagerFactory.getCacheManagerInstance(getHttpSession()).removeSessionCache(request.getSession());
        deleteCount = 1;
        break;
    }
    response.getWriter().write("<RESPONSE><DELETED_ITEMS>" + deleteCount + "</DELETED_ITEMS></RESPONSE>");
  }
}
