/*
 *   FavoriteFolder
 *   RDBData wrapper class for TOAD_PLAN_TABLE
 *   $Revision: 1.8 $
 *   Created: Jeffrey McDowell, 14 Apr 2011
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.favorites;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.CompareTerm;
import amgen.ri.rdb.OraSequenceField;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.rdb.Removeable;
import amgen.ri.rdb.SQLManagerIF;
import amgen.ri.rdb.Saveable;
import amgen.ri.security.IdentityIF;
import amgen.ri.security.SessionIdentityIF;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtString;
import amgen.ri.util.HashCodeGenerator;
import java.util.ArrayList;
import java.util.TimeZone;

/**
 * RDBData wrapper class for TOAD_PLAN_TABLE
 *
 * @version $Revision: 1.8 $
 * @author Jeffrey McDowell
 * @author $Author: cvs $
 */
public class FavoriteFolder extends AbstractFavoriteFolderItem implements Saveable, Removeable, FavoriteFolderItemIF {
  public enum SpecialFolderType {
    ROOT, INCOMING, CATEGORY, NORMAL;

    public static SpecialFolderType getSpecialFolderTypeByID(int id) {
      switch (id) {
        case -3:
          return SpecialFolderType.CATEGORY;
        case -2:
          return SpecialFolderType.INCOMING;
        case -1:
          return SpecialFolderType.ROOT;
        default:
          return SpecialFolderType.NORMAL;
      }
    }
  };
  protected OraSequenceField folder_id;
  protected String name;
  protected String description;
  protected String created_by;
  protected Timestamp created;
  protected String modified_by;
  protected Timestamp modified;
  protected FavoriteFolder parent_folder_id;
  private Person createdByPerson;
  private Person modifiedByPerson;
  private SpecialFolderType specialFolderType = SpecialFolderType.NORMAL;
  private int fHashCode;

  /**
   * Default Constructor
   */
  public FavoriteFolder() {
    super();
  }

  /**
   * RdbData Constructor
   */
  public FavoriteFolder(String folder_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
    this.folder_id = new OraSequenceField(folder_id);
  }

  /**
   * Constructor which sets the class variables
   */
  public FavoriteFolder(String name, String description, String created_by, FavoriteFolder parentFolder, SQLManagerIF sqlManager, String connectionPool) {
    super(sqlManager, created_by, connectionPool);

    if (parentFolder == null) {
      throw new IllegalArgumentException("Parent folder can not be null");
    }
    if (parentFolder.getFolderID() > 0 && !ExtString.equals(parentFolder.getCreatedBy(), created_by)) {
      throw new IllegalArgumentException("Can not create a folder in a folder owned by another user");
    }

    this.folder_id = new OraSequenceField("favorite_folders_seq", this);
    this.name = (ExtString.hasTrimmedLength(name) ? name : "Folder");
    this.description = description;
    this.created_by = created_by;
    this.created = new Timestamp(System.currentTimeMillis());
    this.modified_by = created_by;
    this.modified = this.created;
    this.parent_folder_id = parentFolder;
  }

  /**
   * Special Constructor used to set internal folders
   */
  protected FavoriteFolder(String folder_id, String name, String description, String created_by, FavoriteFolder parentFolder, SQLManagerIF sqlManager, String connectionPool) {
    this(name, description, created_by, parentFolder, sqlManager, connectionPool);
    this.folder_id = new OraSequenceField(folder_id);
    setIsDataSet(true, true);
  }

  /**
   * A required method which returns the primary key(s) of the table/RdbData
   * class.
   */
  public String getIdentifier() {
    return folder_id + "";
  }

  /**
   * A required method which returns the primary key(s) of the table/RdbData
   * class.
   */
  public int getFolderID() {
    return folder_id.intValue();
  }

  /**
   * This method returns the name of the table.
   */
  protected String getTableName() {
    return "FAVORITES_FOLDER";
  }

  /**
   * Get value for name
   */
  public String getName() {
    return (String) get("name");
  }

  /**
   * Set value for name
   */
  public void setName(String name) {
    set("name", name);
  }

  /**
   * Get value for description
   */
  public String getDescription() {
    return (String) get("description");
  }

  /**
   * Set value for description
   */
  public void setDescription(String description) {
    set("description", description);
  }

  /**
   * Get value for created_by
   */
  public String getCreatedBy() {
    return (String) get("created_by");
  }

  /**
   * Returns the owner of the folder
   */
  public String getOwnedBy() {
    return getCreatedBy();
  }

  /**
   * Gets the created_by as a Person
   */
  public Person getCreatedByPerson() {
    if (getCreatedBy() == null) {
      return null;
    }
    if (createdByPerson == null) {
      createdByPerson = Person.getPersonForAmgenLogin(getCreatedBy(), getSQLManager(), getConnectionPool());
    }
    return createdByPerson;
  }

  /**
   * Get value for created
   */
  public Date getCreated() {
    return (Timestamp) get("created");
  }

  /**
   * Get value for modified_by
   */
  public String getModifiedBy() {
    return (String) get("modified_by");
  }

  /**
   * Gets the created_by as a Person
   */
  public Person getModifiedByPerson() {
    if (getModifiedBy() == null) {
      return null;
    }
    if (modifiedByPerson == null) {
      modifiedByPerson = Person.getPersonForAmgenLogin(getModifiedBy(), getSQLManager(), getConnectionPool());
    }
    return modifiedByPerson;
  }

  /**
   * Set value for modified_by
   */
  public void setModified_by(String modified_by) {
    set("modified_by", modified_by);
  }

  /**
   * Get value for modified
   */
  public Date getModified() {
    return (Timestamp) get("modified");
  }

  /**
   * Set value for modified
   */
  public void setModified(String modified) {
    set("modified", modified);
  }

  /**
   * Get value for parent_folder_id
   */
  public FavoriteFolder getParentFolder() {
    return (FavoriteFolder) get("parent_folder_id");
  }

  /**
   * Set value for parent_folder_id
   */
  public void setParentFolder(FavoriteFolder parentFolder) {
    if (getFolderID() < 0) {
      throw new IllegalArgumentException("Can not move system folders");
    }
    if (parentFolder.equals(this)) {
      throw new IllegalArgumentException("Folder can not be the parent of itself");
    }
    if (parentFolder.equals(getParentFolder())) {
      throw new IllegalArgumentException("Folder already the parent folder");
    }
    if (parentFolder.getChildLevelOf(this) > 0) {
      throw new IllegalArgumentException("Folder cannot move to a subfolder");
    }
    set("parent_folder_id", parentFolder);
  }

  /**
   * Returns whether this Favorite is valid an should be included in any lists
   * of Favorites
   *
   * @return boolean
   */
  public boolean isValid(AIGBase requestor) {
    return setData();
  }

  public JSONObject asJSON(IdentityIF identity) {
    JSONObject jFolderItem = new JSONObject();
    try {
      jFolderItem.put("id", getIdentifier());
      jFolderItem.put("parent_id", getParentFolder().getFolderID());
      jFolderItem.put("name", getName());
      jFolderItem.put("text", getName());
      jFolderItem.putOpt("description", getDescription());
      jFolderItem.put("created_by", (getCreatedByPerson() == null ? null : getCreatedByPerson().getFirst() + " "
              + getCreatedByPerson().getLast()));
      String createdDate = identity.convertToUserTimeZone("MM/dd/yyyy hh:mm:ss a", (getCreated() == null ? new Date()
              : getCreated()), TimeZone.getTimeZone("PST"));
      jFolderItem.put("created", createdDate);
      jFolderItem.putOpt("is_owner", getCreatedBy().equals(identity.getUsername()));

      jFolderItem.put("type", "FOLDER");
      jFolderItem.put("subtype", getSpecialType());

      jFolderItem.put("leaf", !canHaveChildFolders());
      jFolderItem.put("modified_by", (getModifiedByPerson() == null ? null : getModifiedByPerson().getFirst() + " "
              + getModifiedByPerson().getLast()));
      String modifiedDate = identity.convertToUserTimeZone("MM/dd/yyyy hh:mm:ss a", (getModified() == null ? new Date() : getModified()), TimeZone.getTimeZone("PST"));
      jFolderItem.put("modified", modifiedDate);
    } catch (JSONException e) {
      e.printStackTrace();
    }

    return jFolderItem;
  }

  public int performDelete(String requestUser, FavoriteFolder rootFolder) {
    if (getFolderID() <= 0) {
      throw new IllegalArgumentException("Can not delete system folders");
    }
    if (!ExtString.equals(getCreatedBy(), requestUser)) {
      throw new SecurityException("Unable to delete folder not owned by you");
    }
    int deleteCount = 0;
    List<FavoriteFolderItem> childFolderItems = new RdbDataArray(FavoriteFolderItem.class, new CompareTerm("folder_id", getIdentifier()), getSQLManager(),
            getLogonUsername(), getConnectionPool());
    List<FavoriteFolder> childFolders = new RdbDataArray(FavoriteFolder.class, new CompareTerm("parent_folder_id", getIdentifier()), getSQLManager(),
            getLogonUsername(), getConnectionPool());

    for (FavoriteFolderItem childFolderItem : childFolderItems) {
      try {
        deleteCount += childFolderItem.performDelete(true, requestUser);
      } catch (IllegalArgumentException e) {
        childFolderItem.setParentFolder(rootFolder);
        if (childFolderItem.performCommit() <= 0) {
          throw new IllegalArgumentException("Unable to move item");
        }
      }
    }

    for (FavoriteFolder childFolder : childFolders) {
      deleteCount += childFolder.performDelete(requestUser, rootFolder);
    }

    deleteCount += super.performDelete();
    return deleteCount;
  }

  public int hashCode() {
    if (fHashCode == 0) {
      int result = HashCodeGenerator.SEED;
      result = HashCodeGenerator.hash(result, folder_id.intValue());
      fHashCode = result;
    }
    return fHashCode;
  }

  public boolean equals(Object obj) {
    if (obj instanceof FavoriteFolder) {
      return (((FavoriteFolder) obj).folder_id.intValue() == this.folder_id.intValue());
    }
    return false;
  }

  public static FavoriteFolder getRootFolder(String connectionPool) {
    return getSpecialFolderType(SpecialFolderType.ROOT, connectionPool);
  }

  public static FavoriteFolder getSpecialFolderType(SpecialFolderType type, String connectionPool) {
    switch (type) {
      case INCOMING:
        FavoriteFolder incoming = new FavoriteFolder("-2", new OraSQLManager(), null, connectionPool);
        incoming.specialFolderType = SpecialFolderType.INCOMING;
        return incoming;
      case CATEGORY:
        FavoriteFolder category = new FavoriteFolder("-3", "Category", "Compounds", "root",
                getSpecialFolderType(SpecialFolderType.ROOT, connectionPool), new OraSQLManager(), connectionPool);
        category.specialFolderType = SpecialFolderType.CATEGORY;

        return category;
      case ROOT:
        FavoriteFolder root = new FavoriteFolder("-1", new OraSQLManager(), null, connectionPool);
        root.specialFolderType = SpecialFolderType.ROOT;
        return root;
    }
    return null;
  }

  public SpecialFolderType getSpecialType() {
    return specialFolderType;
  }

  public boolean canHaveChildFolders() {
    return !(getSpecialType().equals(SpecialFolderType.INCOMING));
  }

  public boolean isRoot() {
    return (getSpecialType().equals(SpecialFolderType.ROOT));
  }

  public boolean isSpecialType() {
    return (!getSpecialType().equals(SpecialFolderType.NORMAL));
  }
}
