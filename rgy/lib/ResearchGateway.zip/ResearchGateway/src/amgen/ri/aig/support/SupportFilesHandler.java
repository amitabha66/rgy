package amgen.ri.aig.support;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.aig.AIGServlet;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONObject;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;

/**
 * @version $Id: SupportFilesHandler.java,v 1.4 2012/07/07 00:08:52 cvs Exp $
 *
 */
public class SupportFilesHandler extends AIGServlet {
  private final String mhtTemplate =
          "From: \n"
          + "Subject: \n"
          + "Date: \n"
          + "MIME-Version: 1.0\n"
          + "Content-Type: text/html;charset=\"utf-8\"\n"
          + "Content-Transfer-Encoding: quoted-printable\n"
          + "X-MimeOLE: \n"
          + "\n"
          + "=EF=BB=BF<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n"
          + "<HTML><HEAD>\n"
          + "<META http-equiv=3DRefresh content=3D0;url=3D{1}>\n"
          + "</HEAD>\n"
          + "</HTML>";
  private String supportName;

  public SupportFilesHandler() {
    super();
  }

  public SupportFilesHandler(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
    supportName = getParameter("name");
  }

  /**
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return TBXServlet @todo Implement this amgen.ri.aig.AIGServlet method
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new SupportFilesHandler(req, resp);
  }

  /**
   *
   * @return String @todo Implement this amgen.ri.aig.AIGServlet method
   */
  protected String getServletMimeType() {
    return (ExtString.hasLength(supportName) ? "message/rfc822" : "text/json");
  }

  /**
   *
   * @throws Exception @todo Implement this amgen.ri.aig.AIGServlet method
   */
  protected void performRequest() throws Exception {
    try {
      String supportFilesParam = ConfigurationParameterSource.getConfigParameter("support_files");
      JSONArray supportFiles = new JSONArray(supportFilesParam);
      if (ExtString.hasLength(supportName)) {
        for (int i = 0; i < supportFiles.length(); i++) {
          JSONObject supportFile = supportFiles.getJSONObject(i);
          if (ExtString.equals(supportFile.getString("name"), supportName)) {
            response.addHeader("Content-disposition", "attachment; filename=" + supportFile.getString("name").replaceAll("\\s+", "_") + ".mht");
            response.getWriter().println(ExtString.applyTemplate(mhtTemplate, new String[]{supportFile.getString("url")}));
            return;
          }
        }
      } else {
        JSONObject supportFilesObj = new JSONObject();
        supportFilesObj.put("SupportFiles", supportFiles);
        supportFilesObj.write(response.getWriter());
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
