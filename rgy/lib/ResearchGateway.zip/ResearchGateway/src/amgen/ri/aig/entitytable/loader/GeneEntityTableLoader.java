package amgen.ri.aig.entitytable.loader;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.tree.TreeNode;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.entitytable.*;
import amgen.ri.util.ExtString;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Custom EntityTable loader for Person entities
 *
 * @version $Id: GeneEntityTableLoader.java,v 1.7 2015/08/05 19:51:28 jemcdowe Exp $
 */
public class GeneEntityTableLoader extends GenericEntityTableLoader {
  public GeneEntityTableLoader(AIGBase requestor) {
    this(requestor, null);
  }

  public GeneEntityTableLoader(AIGBase requestor, String resultNodeKey) {
    super(requestor, EntityListCategory.AMGEN_GENES, resultNodeKey);
  }

  /**
   * Overrides the createEntityTableFromResultNode to create the EtityTable from
   * a Result Node
   *
   * @param resultNodeKey String
   * @return EntityTable
   * @throws AIGException
   */
  @Override
  public EntityTable createEntityTableFromResultNode(String resultNodeKey) throws AIGException {
    Pattern nameSpecies = Pattern.compile("([\\w]+( \\(INACTIVE\\)){0,1})\\s+\\[(.+)\\]");

    //Create the table
    EntityTable entityTable = new EntityTable(getEntityTableType());
    entityTable.setServiceResultCacheItem(getRequestor().getServiceResultCacheItem(resultNodeKey));
    entityTable.setTableName(getTableName());

    //Create the entity ColumnGroup
    ColumnGroup entityColumnGroup = new ColumnGroup("Gene");
    entityTable.addColumnGroup(entityColumnGroup);
    entityColumnGroup.setIsEntityIDDataIndex(true);
    entityColumnGroup.addColumn(new Column("Symbol"));
    entityColumnGroup.addColumn(new Column("Name"));
    entityColumnGroup.addColumn(new Column("Species"));

    for (TreeNode childResultNode : getChildResultNodes()) {
      String symbolSpecies = childResultNode.getText();
      symbolSpecies = symbolSpecies.replaceAll("\\s+", " ");
      String symbol = null;
      String species = null;

      Matcher m = nameSpecies.matcher(symbolSpecies);
      if (m.matches()) {
        symbol = m.group(1);
        species = m.group(3);
      }
      String name = childResultNode.getDescription();
      name = name.replaceAll("\\s+", " ");
      String serviceData = childResultNode.getServiceData();

      if (ExtString.hasTrimmedLength(serviceData) && ExtString.hasTrimmedLength(symbol) && ExtString.hasTrimmedLength(species) && entityTable.getDataRow(serviceData) == null) {
        DataRow newDataRow = entityTable.addDataRow(new DataRow(serviceData));
        if (newDataRow != null) {
          newDataRow.addDataCell(new DataCell(symbol));
          newDataRow.addDataCell(!ExtString.hasTrimmedLength(name) ? new DataCell("") : new DataCell(name));
          newDataRow.addDataCell(new DataCell(species));
        }
      }
    }
    return entityTable;
  }
}
