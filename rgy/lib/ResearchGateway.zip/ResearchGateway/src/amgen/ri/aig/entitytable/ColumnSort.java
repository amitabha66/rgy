package amgen.ri.aig.entitytable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.comparators.ComparatorChain;

import amgen.ri.util.ExtArray;

public class ColumnSort implements Serializable {
    static final long serialVersionUID = 3908852274194145184L;

    private Map<String, ColumnComparator> columnComparatorMap;
    private List<ColumnComparator> columnComparators;
    private int[] sort;

    public ColumnSort() {
        columnComparators = new ArrayList<ColumnComparator>();
        columnComparatorMap = new HashMap<String, ColumnComparator>();
    }

    public void clearSort() {
        columnComparators.clear();
        columnComparatorMap.clear();
        sort = null;
    }

    public void addColumnComparators(String columnDataIndex, boolean caseSensitive, boolean isReversed) {
        if (columnComparatorMap.containsKey(columnDataIndex)) {
            columnComparatorMap.get(columnDataIndex).setIsReversed(isReversed);
        } else {
            ColumnComparator comparator = new ColumnComparator(columnDataIndex, caseSensitive, isReversed);
            columnComparators.add(comparator);
            columnComparatorMap.put(columnDataIndex, comparator);
        }
    }

    /**
     * Returns whether the sort contains this column by its data index
     *
     * @param columnDataIndex String
     * @return boolean
     */
    public boolean containColumnAsComparator(String columnDataIndex) {
        return (columnComparatorMap.containsKey(columnDataIndex));
    }


    public List<ColumnComparator> getColumnComparators() {
        return columnComparators;
    }

    /**
     * Creates a default sort- just a monotonic range from 0- # rows
     *
     * @param entityTable EntityTable
     */
    public void createDefaultSort(EntityTable entityTable) {
        sort = new int[entityTable.getDataRows().size()];
        for (int i = 0; i < sort.length; i++) {
            sort[i] = i;
        }
    }

    /**
     * Returns the current sort or null if no sort
     *
     * @return int[]
     */
    public int[] getSort() {
        return sort;
    }

    /**
     * Sets the position of a row to be at the top or the bottom of the sort
     *
     * @param entityTable EntityTable
     * @param rowIndex int
     * @param toTop boolean
     */
    public void setRowPosition(EntityTable entityTable, int rowIndex, boolean toTop) {
        if (sort == null) {
            createDefaultSort(entityTable);
        }
        int[] newSort = new int[sort.length];
        int pos = 0;
        if (toTop) {
            newSort[0] = rowIndex;
            pos++;
        } else {
            newSort[sort.length - 1] = rowIndex;
        }

        for (int i = 0; i < sort.length; i++) {
            if (rowIndex != sort[i]) {
                newSort[pos++] = sort[i];
            }
        }
        sort = newSort;
    }

    private Comparator makeComparatorChain(EntityTable entityTable) {
        ComparatorChain chain = new ComparatorChain();
        for (ColumnComparator columnComparator : columnComparators) {
            //Debug.print(columnComparator.getColumnIndex()+" "+columnComparator.isReversed());
            columnComparator.startSort(entityTable);
            chain.addComparator(columnComparator, columnComparator.isReversed());
        }
        return chain;
    }

    private void performSort(EntityTable entityTable) {
        sort = ExtArray.quicksort(entityTable.getDataRows(), makeComparatorChain(entityTable));
    }

    /**
     * Checks whether a re-sort is needed based in the column indexes provided
     * and directions.
     * 1. If columnDataIndexes is null, no re-sort needed.
     * 2. If columnComparators.size() == columnDataIndexes.length, this checks the columnComparators in order
     * to see if it matches the columnDataIndexes element and order. If not a match, re-sort
     * 3. If columnComparators.size() != columnDataIndexes.length, re-sort
     *
     * @param entityTable EntityTable
     * @param columnDataIndexes String[]
     * @param directions String[]
     */
    public void checkSort(EntityTable entityTable, String[] columnDataIndexes, String[] directions, boolean caseSensitive) {
        if (columnDataIndexes == null) {
            return;
        }
        if (columnComparators.size() == columnDataIndexes.length) {
            boolean needsResort = false;
            for (int i = 0; i < columnDataIndexes.length; i++) {
                ColumnComparator comparator = columnComparators.get(i);
                boolean isReversed = directions[i].toLowerCase().startsWith("desc");
                if (!comparator.equals(columnDataIndexes[i], caseSensitive, isReversed)) {
                    needsResort = true;
                    break;
                }
            }
            if (!needsResort) {
                return;
            }
        }
        clearSort();
        for (int i = 0; i < columnDataIndexes.length; i++) {
            String columnDataIndex = columnDataIndexes[i];
            boolean isReversed = (directions != null && i < directions.length ? directions[i].toLowerCase().startsWith("desc") : false);
            addColumnComparators(columnDataIndex, caseSensitive, isReversed);
        }
        performSort(entityTable);
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        for (ColumnComparator cc : columnComparators) {
            sb.append(cc + "\n");
        }
        return sb.toString();
    }

}
