package amgen.ri.aig.projectview.model;

import java.util.ArrayList;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.asf.sa.uddi.ClassificationSchemeNames;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.ServiceParameterException;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.ldap.AmgenEnterpriseEntry;
import amgen.ri.util.Debug;
import amgen.ri.xml.ExtXMLElement;

/**
 * Project View Summary documents class
 * @author jemcdowe
 *
 */
public class ProjectViewSummaryDocuments {
	private Document pdDocumentsDoc;

	public ProjectViewSummaryDocuments() {
		
	}

	public ProjectViewSummaryDocuments(AIGBase aigBase, int projectID) throws AIGException, ServiceParameterException {
		ServiceDetails pvpdDocumentService = aigBase.getLooselyCoupledServiceDetails("PROJECTVIEW_PVPDDOCUMENTS");
		if (pvpdDocumentService != null) {
			aigBase.setServiceParameters(pvpdDocumentService, null);
			pvpdDocumentService.setParameterValue(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME, ServiceDataCategory
					.revertTo(ServiceDataCategory.PROJECT), projectID + "");
			pvpdDocumentService.setParameterValue("category", "PV,PD");
			pdDocumentsDoc = aigBase.executeService2JDocument(pvpdDocumentService, false);
		}
	}

	public JSONObject getDocumentsJSON() throws JSONException {
		JSONObject jDocs = new JSONObject();

		if (pdDocumentsDoc == null) {
			return jDocs;
		}
		List<Element> pvDocEls = ExtXMLElement.getXPathElements(pdDocumentsDoc, "//Document[Category/@id=6]");
		for (Element docEl : pvDocEls) {
			jDocs.append("docs", getDocumentJSON(docEl));
		}

		List<Element> pdDocEls = ExtXMLElement.getXPathElements(pdDocumentsDoc, "//Document[Category/@id=7]");
		for (Element docEl : pdDocEls) {
			jDocs.append("docs", getDocumentJSON(docEl));
		}
		return jDocs;
	}

	private JSONObject getDocumentJSON(Element docEl) throws JSONException {
		JSONObject jDoc = new JSONObject();
		Element doctypeEl = docEl.getChild("DocumentType");
		int id = ExtXMLElement.getChildNumber(docEl, "DocumentId").intValue();
		String name = docEl.getChildText("Name");
		String desc = doctypeEl.getChildText("Description");
		String type = doctypeEl.getChildText("MimeType");
		String category = docEl.getChildText("Category");
		int categoryID = (int)ExtXMLElement.findNumericValueInElement(docEl.getChild("Category"), "id");
		String createdBy = docEl.getChildText("CreatedBy");
		AmgenEnterpriseEntry createdByEntry= AIGBase.getAmgenEnterpriseEntryFromUID(createdBy);
		String created = docEl.getChildText("Created");
		String modifiedBy = docEl.getChildText("ModifiedBy");
		AmgenEnterpriseEntry modifiedByEntry= AIGBase.getAmgenEnterpriseEntryFromUID(modifiedBy);
		String modified = docEl.getChildText("Modified");

		jDoc.put("id", id);
		jDoc.put("name", name);
		jDoc.put("desc", desc);
		jDoc.put("mimetype", type);
		jDoc.put("category", category);
		jDoc.put("categoryID", categoryID);
		jDoc.put("createdBy", createdBy);
		jDoc.put("createdByName", (createdByEntry== null ? createdBy : createdByEntry.getLedgerName()));
		jDoc.put("created", created);
		jDoc.put("modifiedBy", modifiedBy);
		jDoc.put("modifiedByName", (modifiedByEntry== null ? modifiedBy : modifiedByEntry.getLedgerName()));
		jDoc.put("modified", modified);
		return jDoc;
	}
	
	
}
