package amgen.ri.aig.entity.rgdh;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.aig.AIGServlet;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.ldap.ActiveDirectoryLookup;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.util.Debug;

/**
 * @version $Id: DHPersonQuery.java,v 1.6 2014/04/09 22:56:25 jemcdowe Exp $
 *
 */
public class DHPersonQuery extends AIGServlet {
    public static final int MAX_RESULTS = 200;

    public DHPersonQuery() {
        super();
    }

    public DHPersonQuery(HttpServletRequest req, HttpServletResponse resp) {
        super(req, resp);
    }

    public DHPersonQuery(AIGServlet aigServlet) {
        super(aigServlet);
    }

    /**
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return TBXServlet
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new DHPersonQuery(req, resp);
    }

    /**
     *
     * @return String
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected String getServletMimeType() {
        return "text/json";
    }

    /**
     *
     * @throws Exception
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected void performRequest() throws Exception {
        if (doesParameterExist("query", true) || doesParameterExist("username", true)) {
            performLookupUsers();
        } else if (doesParameterExist("group_username", true)) {
            performLookupMembers();

        }
    }

    protected void performLookupMembers() throws Exception {
        PersonRecordIF groupEntry = new ActiveDirectoryLookup().lookup(getParameter("group_username"));
        JSONObject members = new JSONObject();
        for (PersonRecordIF entry : groupEntry.getSortedMembers()) {
            try {
                members.append("members", getNameJSON(entry, false));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        members.write(response.getWriter());
    }

    protected void performLookupUsers() throws Exception {
        List<PersonRecordIF> entries = new ArrayList<PersonRecordIF>();
        if (doesParameterExist("query", true)) {
            boolean includeGroups= !doesParameterEqual("includeGroups", "N");
            entries.addAll(new ActiveDirectoryLookup().searchBy(getParameter("query"), includeGroups));
        }
        if (doesParameterExist("username", true)) {
            entries.addAll(new ActiveDirectoryLookup().lookup(getParameter("username").split(",")));
        }
        getNamesJSON(entries, doesParameterExist("extended_information", true)).write(response.getWriter());
    }

    protected static JSONObject getNamesJSON(List<PersonRecordIF> entries, boolean extendedInformation) {
        JSONObject names = new JSONObject();
        if (entries != null) {
            for (PersonRecordIF entry : entries) {
                try {
                    names.append("names", getNameJSON(entry, extendedInformation));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
        return names;
    }

    protected static JSONObject getNameJSON(PersonRecordIF entry, boolean extendedInformation) {
        JSONObject name = new JSONObject();
        if (entry != null) {
            try {
                name.putOpt("username", entry.getUsername());
                name.putOpt("name", entry.getDisplayName());
                name.putOpt("title", entry.getTitle());
                name.putOpt("costcenter", entry.getCostCenter());
                name.putOpt("location", entry.getLocation());
                name.putOpt("bldg", entry.getBuilding());
                name.putOpt("phone", entry.getPhone());
                name.putOpt("employee_id", entry.getEmployeeID());
                name.putOpt("obj_class", entry.getObjectClass());
                if (extendedInformation) {
                    if (entry.getManager() != null) {
                        name.putOpt("manager", entry.getManager().getDisplayName());
                        name.putOpt("manager_username", entry.getManager().getUsername());
                    }
                    for (PersonRecordIF report : entry.getSortedDirectReports()) {
                        name.append("reports", getNameJSON(report, false));
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return name;
    }

    public static JSONObject getPeopleInformation(String logins) {
        List<PersonRecordIF> entries = null;
        try {
            entries = new ActiveDirectoryLookup().lookup(logins.split(","));
        } catch (Exception ex) {
        }
        return getNamesJSON(entries, false);
    }

}
