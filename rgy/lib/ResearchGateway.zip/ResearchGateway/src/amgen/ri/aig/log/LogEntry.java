/*
 *   LogEntry
 *   RDBData wrapper class for RG_LOG entries
 *   $Revision: 1.2 $
 *   Created: Jeffrey McDowell, 30 Jul 2009
 *   Modified: $Author: jemcdowe $
 *   $Log
 *
 */
package amgen.ri.aig.log;


import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.List;

import amgen.ri.rdb.CompareTerm;
import amgen.ri.rdb.OraSequenceField;
import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.rdb.SQLManagerIF;
import amgen.ri.rdb.Saveable;
import amgen.ri.util.ExtString;

/**
 *   RDBData wrapper class for RG_LOG entries
 *   @version $Revision: 1.2 $
 *   @author Jeffrey McDowell
 *   @author $Author: jemcdowe $
 */
public class LogEntry extends RdbData implements Saveable {
    protected OraSequenceField request_id;
    protected String session_id;
    protected String request_user;
    protected String host;
    protected String remote_host;
    protected String request_type;
    protected String service_key;
    protected Timestamp request_date;
    protected long elapsed_millis;
    protected long service_invoke_millis;
    protected long service_transform_millis;

    protected String error_string;
    protected String request_string;

    /**
     * Default Constructor
     */
    public LogEntry() {
        super();
    }

    /**
     * RdbData Constructor
     */
    public LogEntry(String request_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.request_id = new OraSequenceField(request_id);
    }

    /**
     * Constructor which sets the class variables for a normal request
     */
    public LogEntry(String session_id, String request_user, String host, String remote_host,
                    LogRequestType request_type, SQLManagerIF sqlManager, String connectionPool) {
        super(sqlManager, null, connectionPool);
        this.request_id = new OraSequenceField("RG.RG_LOG_SEQ", this);
        this.session_id = session_id;
        this.request_user = request_user;
        this.host = host;
        this.remote_host = remote_host;
        this.request_type = request_type + "";
        this.request_date = new Timestamp(System.currentTimeMillis());
        this.request_id.toString();
    }

    /**
     * Constructor which sets the class variables for a session start request
     */
    public LogEntry(String session_id, SQLManagerIF sqlManager, String connectionPool) {
        this(session_id, null, null, null, LogRequestType.SESSION, sqlManager, connectionPool);
    }

    /**
     * Constructor which copies the class variables from a source to a new Object
     *
     * @param source LogEntry
     * @param sqlManager SQLManagerIF
     * @param connectionPool String
     */
    public LogEntry(LogEntry source) {
        super(source.getSQLManager(), null, source.getConnectionPool());
        this.request_id = new OraSequenceField("RG.RG_LOG_SEQ", this);
        this.session_id = source.session_id;
        this.request_user = source.request_user;
        this.host = source.host;
        this.remote_host = source.remote_host;
        this.request_type = source.request_type;
        this.service_key = source.service_key;
        this.request_date = source.request_date;
        this.elapsed_millis = source.elapsed_millis;
        this.service_invoke_millis = source.service_invoke_millis;
        this.service_transform_millis = source.service_transform_millis;
        this.error_string = source.error_string;
        this.request_string = source.request_string;
    }

    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return request_id + "";
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }

    /** This method returns the name of the table. */
    protected String getTableName() {
        return "RG.RG_LOG";
    }

    /** Returns the SQL for INSERTing the object in the table */
    public String getInsertSQL() {
        return null;
    }

    /** Returns the SQL for UPDATing the object in the table */
    public String getUpdateSQL() {
        return null;
    }

    /** Get value for session_id */
    public String getSessionID() {
        return (String) get("session_id");
    }

    /** Get value for request_user */
    public String getRequestUser() {
        return (String) get("request_user");
    }

    /** Get value for host */
    public String getHost() {
        return (String) get("host");
    }

    /** Get value for remote_host */
    public String getRemoteHost() {
        return (String) get("remote_host");
    }

    /** Get value for request_type */
    public String getRequestType() {
        return (String) get("request_type");
    }

    /** Get value for service_key */
    public String getServiceKey() {
        return (String) get("service_key");
    }

    /** Get value for request_date */
    public Timestamp getRequestDate() {
        return (Timestamp) get("request_date");
    }

    /** Get value for elapsed_millis */
    public long getElapsedMillis() {
        return getAsNumber("elapsed_millis").longValue();
    }

    public long getServiceInvokeMillis() {
        return getAsNumber("service_invoke_millis").longValue();
    }

    public long getServiceTransformMillis() {
        return getAsNumber("service_transform_millis").longValue();
    }

    /** Get value for error_string */
    public String getErrorString() {
        return (String) get("error_string");
    }

    /** Get value for request_string */
    public String getRequestString() {
        return (String) get("request_string");
    }

    /** Set value for request_user */
    public void setRequestUser(String request_user) {
        set("request_user", request_user);
    }

    /** Set value for host */
    public void setHost(String host) {
        set("host", host);
    }

    public void setServiceInvokeMillis(long service_invoke_millis) {
        set("service_invoke_millis", new Long(service_invoke_millis));
    }

    public void setServiceTransformMillis(long service_transform_millis) {
        set("service_transform_millis", new Long(service_transform_millis));
    }

    /** Set value for remote_host */
    public void setRemoteHost(String remote_host) {
        set("remote_host", remote_host);
    }

    /** Set value for request_type */
    public void setRequestType(String request_type) {
        set("request_type", request_type);
    }

    /** Set value for request_string */
    public void setRequestString(String request_string) {
        set("request_string", ExtString.truncate(request_string, 3990, false));
    }

    /** Set value for service_key */
    public void setServiceKey(String service_key) {
        set("service_key", service_key);
    }

    /** Set value for elapsed_millis */
    public void setElapsedMillis() {
        if (request_date != null) {
            long elapsedTime = System.currentTimeMillis() - request_date.getTime();
            set("elapsed_millis", new Long(elapsedTime));
        }
    }

    /** Set value for error_string */
    public void setErrorString(String errorString) {
        set("error_string", ExtString.truncate(error_string, 4000, false));
    }

    /**
     * Returns the LogEntry for the session given any LogEntry for the session
     *
     * @param logEntry LogEntry
     * @return LogEntry
     */
    public static LogEntry getSessionLogEntry(LogEntry logEntry) {
        if (logEntry == null || !logEntry.setData()) {
            return null;
        }
        List<LogEntry> sessionLogEntry = new RdbDataArray(LogEntry.class,
                new CompareTerm[] {
            new CompareTerm("session_id", logEntry.getSessionID()),
                    new CompareTerm("request_type", LogRequestType.SESSION + "")
        }, logEntry.getSQLManager(),
                null, logEntry.getConnectionPool());
        return (sessionLogEntry.size() == 0 ? null : sessionLogEntry.get(0));
    }

    /**
     * Updates the session's LogEntry with data not available until the first
     * request from this LogEntry and returns it. It has not been committed yet!
     * Null no session LogEntry was found.
     *
     * @param logEntry LogEntry
     * @return LogEntry
     */
    public LogEntry updateSessionLogEntry() {
        LogEntry sessionLogEntry = getSessionLogEntry(this);
        if (sessionLogEntry == null || !sessionLogEntry.setData()) {
            return null;
        }
        sessionLogEntry.setRequestUser(getRequestUser());
        sessionLogEntry.setHost(getHost());
        sessionLogEntry.setRemoteHost(getRemoteHost());
        sessionLogEntry.setElapsedMillis();
        return sessionLogEntry;
    }


}
