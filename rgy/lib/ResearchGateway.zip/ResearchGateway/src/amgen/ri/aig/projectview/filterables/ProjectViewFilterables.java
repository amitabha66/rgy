package amgen.ri.aig.projectview.filterables;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jdom.Element;
import org.jdom.Namespace;

import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.entitylist.PagingEntityList;
import amgen.ri.aig.projectview.model.ProjectViewAssay;
import amgen.ri.aig.projectview.model.ProjectViewAssayList;
import amgen.ri.aig.projectview.model.ProjectViewAssayResult;
import amgen.ri.aig.projectview.model.ProjectViewAvailableView;
import amgen.ri.aig.projectview.model.ProjectViewModel;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;

/**
 * Encpsulates all filterables for the Project View Model
 */
public class ProjectViewFilterables implements Serializable {
    private static final String VQT_AQI_SQL =
            "SELECT Q.AQI_ID QUERYABLE_ID, Q.NAME, Q.UNITS, Q.DATA_TYPE, Q.GROUP_NAME,  "+
            "Q.SORTBY_AQIID RETRIEVABLE_ID "+
            "FROM PV_VQT_ABSTRACT_QUERY_ITEM Q WHERE Q.QUERY_ITEM_TYPE_CODE='Q'";

    private static final String VQT_AQI_PARAMS_SQL =
            "SELECT PARAMETER_KEY, PARAMETER_NAME FROM PV_VQT_AQI_PARAMETERS WHERE AQI_ID=?";

    private AIGServlet requestor;
    private ProjectViewFilterable assayVQTFilterable = null;
    private ProjectViewFilterable assayResultDateVQTFilterable = null;
    private ProjectViewFilterable listVQTFilterable = null;

    private Map<String, ProjectViewFilterableIF> filterablesByQueryableID;
    private Map<String, List<ProjectViewFilterableIF>> filterablesByCategory;
    private JSONArray filterSetJSON;

    private String sortField;

    /**
     * Creates a new ProjectViewFilterables from the model. This includes
     * looking up filterables from the AIG db
     *
     * @param requestor AIGServlet
     * @param model ProjectViewModel
     * @throws SQLException
     */
    public ProjectViewFilterables(AIGServlet requestor, PagingEntityList staticFilterSourceCompoundList, ProjectViewModel projViewModel) throws SQLException {
        this.requestor = requestor;
        this.filterablesByQueryableID = new LinkedHashMap<String, ProjectViewFilterableIF>();
        ResultSet rset = new OraSQLManager().executeQuery(VQT_AQI_SQL, JDBCNamesType.RG_JDBC+"");
        while (rset.next()) {
            String dataType = rset.getString("DATA_TYPE");
            if (ExtString.equals(dataType, "assay")) {
                assayVQTFilterable = new ProjectViewFilterable(
                        rset.getInt("QUERYABLE_ID") + "",
                        rset.getInt("QUERYABLE_ID") + "",
                        rset.getInt("RETRIEVABLE_ID") + "",
                        rset.getString("NAME"),
                        "Assay",
                        rset.getString("UNITS"),
                        rset.getString("DATA_TYPE"),
                        rset.getString("GROUP_NAME"));
            } else if (ExtString.equals(dataType, "list")) {
                listVQTFilterable = new ListQueryable(
                        rset.getInt("QUERYABLE_ID") + "",
                        rset.getInt("QUERYABLE_ID") + "",
                        rset.getInt("RETRIEVABLE_ID") + "",
                        rset.getString("NAME"),
                        rset.getString("UNITS"),
                        rset.getString("GROUP_NAME"));
            } else if (ExtString.equals(dataType, "assaydate")) {
                assayResultDateVQTFilterable= new ProjectViewFilterable(
                        rset.getInt("QUERYABLE_ID") + "",
                        rset.getInt("QUERYABLE_ID") + "",
                        rset.getInt("RETRIEVABLE_ID") + "",
                        rset.getString("NAME"),
                        "Assay",
                        rset.getString("UNITS"),
                        rset.getString("DATA_TYPE"),
                        rset.getString("GROUP_NAME"));
            } else if (ExtString.equals(dataType, "date")) {
                this.filterablesByQueryableID.put(rset.getString("QUERYABLE_ID"), new DateFilterable(
                        rset.getInt("QUERYABLE_ID") + "",
                        rset.getInt("QUERYABLE_ID") + "",
                        rset.getInt("RETRIEVABLE_ID") + "",
                        rset.getString("NAME"),
                        "Compound Properties",
                        rset.getString("UNITS"),
                        rset.getString("GROUP_NAME")));
            } else if (ExtString.equals(dataType, "structure")) {
                this.filterablesByQueryableID.put(rset.getString("QUERYABLE_ID"),
                                                  new StructureFilterable(
                        rset.getInt("QUERYABLE_ID") + "",
                        rset.getInt("QUERYABLE_ID") + "",
                        rset.getInt("RETRIEVABLE_ID") + "",
                        rset.getString("NAME"),
                        rset.getString("UNITS"),
                        rset.getString("GROUP_NAME")));
            } else {
                this.filterablesByQueryableID.put(rset.getString("QUERYABLE_ID"),
                                                  new ProjectViewFilterable(
                        rset.getInt("QUERYABLE_ID") + "",
                        rset.getInt("QUERYABLE_ID") + "",
                        rset.getInt("RETRIEVABLE_ID") + "",
                        rset.getString("NAME"),
                        "Compound Properties",
                        rset.getString("UNITS"),
                        rset.getString("DATA_TYPE"),
                        rset.getString("GROUP_NAME")));
            }
        }
        OraSQLManager.closeResources(rset);
        if (assayVQTFilterable != null) {
            Map<String, String> vqtParameters = new HashMap<String, String>();
            rset = new OraSQLManager().executeQuery(VQT_AQI_PARAMS_SQL, assayVQTFilterable.getQueryable_id(), JDBCNamesType.RG_JDBC+"");
            while (rset.next()) {
                vqtParameters.put(rset.getString("PARAMETER_KEY"), rset.getString("PARAMETER_NAME"));
            }
            OraSQLManager.closeResources(rset);
            assayVQTFilterable.setVQTParameters(vqtParameters);

            ProjectViewAvailableView pjAvailView = projViewModel.getPageProjectViewAvailableView();

            Map<String, ProjectViewAssayList> assayLists = projViewModel.getAssayLists(true);
            for (String listID : assayLists.keySet()) {
                ProjectViewAssayList assayList = assayLists.get(listID);
                if (!assayList.isInvivoPKAuthList()) {
                    for (ProjectViewAssay assay : assayList.getAssays()) {
                        for (ProjectViewAssayResult result : assay.getAssayResults()) {
                            String assayCode = assay.getAssayCode() + ":" + result.getResultTypeID();
                            String unitsName = result.getResultType();
                            String filterableDisplay= assay.getAssayCode() + " " + result.getResultType();
                            if (ExtString.hasLength(assay.getAssayName())) {
                                filterableDisplay = assay.getAssayName()+ ": "+filterableDisplay;
                            }
                            this.filterablesByQueryableID.put(assayCode, new AssayFilterable(
                                    assayCode,
                                    assayVQTFilterable.getQueryable_id(),
                                    assayVQTFilterable.getRetrievable_id(),
                                    filterableDisplay,
                                    assayList.getName(),
                                    unitsName,
                                    "Assay Results",
                                    assayResultDateVQTFilterable,
                                    assay,
                                    result));
                        }
                    }
                }
            }
        }
        if (listVQTFilterable != null && staticFilterSourceCompoundList != null) {
            Map<String, String> vqtParameters = new HashMap<String, String>();
            rset = new OraSQLManager().executeQuery(VQT_AQI_PARAMS_SQL, listVQTFilterable.getQueryable_id(), JDBCNamesType.RG_JDBC+"");
            while (rset.next()) {
                vqtParameters.put(rset.getString("PARAMETER_KEY"), rset.getString("PARAMETER_NAME"));
            }
            OraSQLManager.closeResources(rset);
            listVQTFilterable.setVQTParameters(vqtParameters);
            listVQTFilterable.setValue(staticFilterSourceCompoundList.getList_id() + "");
        }

        filterablesByCategory = new LinkedHashMap<String, List<ProjectViewFilterableIF>>();
        for (String filterable_id : filterablesByQueryableID.keySet()) {
            ProjectViewFilterable filterable = (ProjectViewFilterable) filterablesByQueryableID.get(filterable_id);
            Map<String, String> vqtParameters = new HashMap<String, String>();
            if (filterable.getQueryable_id()== assayVQTFilterable.getQueryable_id()) {
                for(String vqtParameterName : assayVQTFilterable.getVQTParameters().keySet()) {
                    vqtParameters.put(vqtParameterName, assayVQTFilterable.getVQTParameters().get(vqtParameterName));
                }
            } else if (filterable.getQueryable_id()== listVQTFilterable.getQueryable_id()) {
                for(String vqtParameterName : listVQTFilterable.getVQTParameters().keySet()) {
                    vqtParameters.put(vqtParameterName, listVQTFilterable.getVQTParameters().get(vqtParameterName));
                }
            } else {
                rset = new OraSQLManager().executeQuery(VQT_AQI_PARAMS_SQL, filterable.getQueryable_id(), JDBCNamesType.RG_JDBC+"");
                while (rset.next()) {
                    vqtParameters.put(rset.getString("PARAMETER_KEY"), rset.getString("PARAMETER_NAME"));
                }
                OraSQLManager.closeResources(rset);
            }
            filterable.setVQTParameters(vqtParameters);
            String category = filterable.getCategory();
            if (!filterablesByCategory.containsKey(category)) {
                filterablesByCategory.put(category, new ArrayList<ProjectViewFilterableIF>());
            }
            filterablesByCategory.get(category).add(filterable);
        }
    }

    public ProjectViewFilterableIF getProjectViewFilterable(String id) {
        return filterablesByQueryableID.get(id);
    }

    public Set<String> getProjectViewFilterableNames() {
        return filterablesByQueryableID.keySet();
    }

    /**
     * Get Filterables as a JSONObject.
     * If either the filterableID or filterableName is present, only filterables
     * matching these are returned. Otherwise, all are returned.
     *
     * @return JSONObject
     * @param filterableID String
     * @param filterableName String
     */
    public JSONObject getFilterablesJSON(String filterableID, String filterableName, String filterableCategory) {
        JSONObject filterablesJSON = new JSONObject();
        try {
            for (String filterable_id : filterablesByQueryableID.keySet()) {
                if (filterableID == null || filterableID.equals(filterable_id)) {
                    ProjectViewFilterableIF filterable = filterablesByQueryableID.get(filterable_id);
                    if (filterableName == null || filterableName.equals(filterable.getName())) {
                        if (filterableCategory == null || filterableCategory.equals(filterable.getCategory())) {
                            filterablesJSON.append("Filterables", filterable.createFilterableJSON());
                        }
                    }
                }
            }
        } catch (JSONException e) {}
        return filterablesJSON;
    }

    /**
     * Get Filterables as a JSONObject.
     * If either the filterableID or filterableName is present, only filterables
     * matching these are returned. Otherwise, all are returned.
     *
     * @return JSONObject
     * @param filterableID String
     * @param filterableName String
     */
    public JSONArray getFilterablesJSON(String filterableCategory) {
        JSONArray filterablesJSON = new JSONArray();
        try {
            for (ProjectViewFilterableIF filterable : filterablesByCategory.get(filterableCategory)) {
                JSONObject jFilterableNode= filterable.createFilterableJSON();
                jFilterableNode.put("text", filterable.getName());
                jFilterableNode.put("leaf", true);
                filterablesJSON.put(jFilterableNode);
            }
        } catch (JSONException e) {}
        return filterablesJSON;
    }

    /**
     * Get Filterables as a JSONObject.
     * If either the filterableID or filterableName is present, only filterables
     * matching these are returned. Otherwise, all are returned.
     *
     * @return JSONObject
     * @param filterableID String
     * @param filterableName String
     */
    public JSONArray getFilterableCategoriesJSON() {
        JSONArray jFilterCategories = new JSONArray();
        try {
            for (String category : filterablesByCategory.keySet()) {
                JSONObject jCategory = new JSONObject();
                jFilterCategories.put(jCategory);
                jCategory.put("id", category);
                jCategory.put("text", category);
                jCategory.put("isLeaf", false);
            }
        } catch (JSONException e) {}
        return jFilterCategories;
    }

    /**
     * Returns the complete VQT query element using the set filter values
     *
     * @return Element
     */
    public Element getVQTQueryEl() {
        Namespace ns = Namespace.getNamespace("http://Amgen.Research.RG.VennQuerySchemas");
        Element queryEl = new Element("query", ns);
        ExtXMLElement.addAttribute(queryEl, "id", "0");
        ExtXMLElement.addAttribute(queryEl, "entityType", "COMPOUND");
        Element lastQueryableEl = queryEl;
        int queryablesCount = 1;
        Element listQueryableEl = listVQTFilterable.getVQTQueryableEl("set" + (queryablesCount++), ns);
        if (listQueryableEl != null) {
            Element queryablesEl = ExtXMLElement.addElement(lastQueryableEl, "queryables", ns);
            queryablesEl.addContent(listQueryableEl);
            lastQueryableEl = listQueryableEl;
        }
        for (String filterable_id : filterablesByQueryableID.keySet()) {
            ProjectViewFilterableIF filterable = filterablesByQueryableID.get(filterable_id);
            Element queryableEl = filterable.getVQTQueryableEl("set" + (queryablesCount++), ns);
            if (queryableEl != null) {
                Element queryablesEl = ExtXMLElement.addElement(lastQueryableEl, "queryables", ns);
                queryablesEl.addContent(queryableEl);
                lastQueryableEl = queryableEl;
            }
        }
        StringBuffer sortFieldBuffer = new StringBuffer();
        Element retrievablesEl = ExtXMLElement.addElement(queryEl, "retrievables", ns);
        int retrievablesCount = 1;
        for (String filterable_id : filterablesByQueryableID.keySet()) {
            ProjectViewFilterableIF filterable = filterablesByQueryableID.get(filterable_id);
            Element retrievableEl = filterable.getVQTRetrievableEl(ns);
            if (retrievableEl != null) {
                retrievablesEl.addContent(retrievableEl);
                if (ExtString.equalsIgnoreCase(filterable.getSort(), "descending") || ExtString.equalsIgnoreCase(filterable.getSort(), "ascending")) {
                    if (sortFieldBuffer.length() > 0) {
                        sortFieldBuffer.append(",");
                    }
                    sortFieldBuffer.append(retrievablesCount + ":" +
                                           (ExtString.equalsIgnoreCase(filterable.getSort(), "descending") ? "desc" : "asc"));
                }
                retrievablesCount++;
            }
        }
        sortField = sortFieldBuffer.toString();
        return queryEl;
    }

    public String getSortField() {
        return sortField;
    }

    public JSONArray getFilterSetJSON() {
        return filterSetJSON;
    }


    /**
     * Updates the value, operator, sort of the Filterables. This first performs a reset on the
     * filterables. The provided filterablesJSON is returned, or if null, one is created
     *
     * @param filterables JSONArray
     */
    public void updateFilterables(JSONArray filterablesJSON) {
        filterSetJSON = new JSONArray();
        if (filterablesJSON == null) {
            filterablesJSON = new JSONArray();
        }
        resetFilterables();
        for (int i = 0; i < filterablesJSON.length(); i++) {
            JSONObject filterableJSON = filterablesJSON.optJSONObject(i);
            ProjectViewFilterableIF filterable = filterablesByQueryableID.get(filterableJSON.optString("id", "--"));
            if (filterable != null) {
                filterable.updateFilterable(filterableJSON);
                filterSetJSON.put(filterableJSON);
            }
        }
    }

    /**
     * Updates the value, operator, sort of a single Filterables. This first performs a reset on the
     * filterables. The provided filterablesJSON is returned, or if null, one is created
     *
     * @param filterables JSONArray
     */
    public boolean updateFilterable(JSONObject filterableJSON) {
        filterSetJSON = new JSONArray();
        resetFilterables();
        ProjectViewFilterableIF filterable = filterablesByQueryableID.get(filterableJSON.optString("id", "--"));
        if (filterable != null) {
            filterable.updateFilterable(filterableJSON);
            filterSetJSON.put(filterableJSON);
            return true;
        }
        return false;
    }

    /**
     * Resets all the filterables to no filter and no sort
     */
    public void resetFilterables() {
        for (ProjectViewFilterableIF filterable : filterablesByQueryableID.values()) {
            filterable.resetFilterable();
        }
    }

    /**
     * Returns all the Filterables
     *
     * @return Collection
     */
    public Collection<ProjectViewFilterableIF> getFilterables() {
        return filterablesByQueryableID.values();
    }

    /**
     * Returns the Filterables for the given category
     *
     * @param category String
     * @return Collection
     */
    public Collection<ProjectViewFilterableIF> getFilterables(String category) {
        return filterablesByCategory.get(category);
    }
}
