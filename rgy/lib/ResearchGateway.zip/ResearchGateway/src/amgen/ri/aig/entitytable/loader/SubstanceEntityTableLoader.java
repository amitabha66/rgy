package amgen.ri.aig.entitytable.loader;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.category.schema2.EntityListCategory;

/**
 * Custom EntityTable loader for Substance entities
 * @version $Id: SubstanceEntityTableLoader.java,v 1.2 2011/06/21 17:28:57 cvs Exp $
 */
public class SubstanceEntityTableLoader extends StructureEntityTableLoader {
    public SubstanceEntityTableLoader(AIGBase requestor) {
        this(requestor, null);
    }

    public SubstanceEntityTableLoader(AIGBase requestor, String resultNodeKey) {
        super(requestor, EntityListCategory.SUBSTANCES, resultNodeKey);
    }
}
