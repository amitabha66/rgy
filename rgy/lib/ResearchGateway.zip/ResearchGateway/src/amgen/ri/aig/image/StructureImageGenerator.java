package amgen.ri.aig.image;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import java.util.HashMap;
import java.util.Map;

import amgen.ri.aig.preferences.PreferenceIF;
import amgen.ri.aig.preferences.PreferenceManager;
import amgen.ri.aig.preferences.PreferenceableIF;
import amgen.ri.util.ExtString;
import com.symyx.draw.ImageGenerator;
import com.symyx.draw.JDrawPreferences;
import java.awt.Color;
import java.awt.image.BufferedImage;

public class StructureImageGenerator implements PreferenceableIF {
  //Preference settings
  private Map<String, String> preferences;

  public StructureImageGenerator(AIGBase requestor) {
    this.preferences = new HashMap<String, String>();
    try {
      new PreferenceManager(requestor.getSessionLogin(), this).setPreferences();
    } catch (AIGException ex) {
    }
  }

  public BufferedImage createImageFromMolFile(String molFile, int width, int height) {
    ImageGenerator g = new ImageGenerator();
    g.setMolString(molFile);

    JDrawPreferences p = g.preferences();
    //Set defaults
    p.setStereoGroupColorDisplay(JDrawPreferences.STEREODISPLAY_LABEL_ONLY);
    p.setBackgroundColor(Color.WHITE);
    p.setForegroundColor(Color.BLACK);
    p.setStereoAbsColor(getColor("800000"));
    p.setStereoAndColor(getColor("993366"));
    p.setStereoOrColor(getColor("339966"));
    p.setColorAtomsByType(true);
    p.setBondLabelSize(0.2);
    p.setDefaultBondLength(10);
    p.setLabelHeight(0.4);
    p.setDisplayChiralStereoLabels(JDrawPreferences.STEREOLABEL_ON);
    p.setHydrogenDisplayMode(JDrawPreferences.HYDROGEN_HETERO);
    p.setPolAtomDisplayMode(JDrawPreferences.POL_STYLE_BEAD);
    p.setAbsStereoLabelText("");
    p.setAndStereoLabelText("");
    p.setOrStereoLabelText("");
    p.setMixedStereoLabelText("");


    if (preferences.containsKey("stereoGroupColorDisplay")) {
      if (preferences.get("stereoGroupColorDisplay").equals("BOND_ONLY")) {
        p.setStereoGroupColorDisplay(JDrawPreferences.STEREODISPLAY_BOND_ONLY);
      } else if (preferences.get("stereoGroupColorDisplay").equals("LABEL_BOND")) {
        p.setStereoGroupColorDisplay(JDrawPreferences.STEREODISPLAY_LABEL_BOND);
      } else if (preferences.get("stereoGroupColorDisplay").equals("LABEL_ONLY")) {
        p.setStereoGroupColorDisplay(JDrawPreferences.STEREODISPLAY_LABEL_ONLY);
      } else if (preferences.get("stereoGroupColorDisplay").equals("OFF")) {
        p.setStereoGroupColorDisplay(JDrawPreferences.STEREODISPLAY_OFF);
      }
    }

    if (preferences.containsKey("backgroundColor")) {
      Color color = getColor(preferences.get("backgroundColor"));
      if (color != null) {
        p.setBackgroundColor(color);
      }
    }
    if (preferences.containsKey("foregroundColor")) {
      Color color = getColor(preferences.get("foregroundColor"));
      if (color != null) {
        p.setForegroundColor(color);
      }
    }
    if (preferences.containsKey("stereoAbsColor")) {
      Color color = getColor(preferences.get("stereoAbsColor"));
      if (color != null) {
        p.setStereoAbsColor(color);
      }
    }
    if (preferences.containsKey("stereoAndColor")) {
      Color color = getColor(preferences.get("stereoAndColor"));
      if (color != null) {
        p.setStereoAndColor(color);
      }
    }
    if (preferences.containsKey("stereoOrColor")) {
      Color color = getColor(preferences.get("stereoOrColor"));
      if (color != null) {
        p.setStereoOrColor(color);
      }
    }
    if (preferences.containsKey("colorAtomsByType")) {
      String option = preferences.get("colorAtomsByType").toUpperCase();
      boolean b = (option.startsWith("T") || option.startsWith("Y") || option.startsWith("1"));
      p.setColorAtomsByType(b);
    }
    if (preferences.containsKey("bondLabelSize")) {
      double d = ExtString.toDouble(preferences.get("bondLabelSize"));
      if (!Double.isNaN(d)) {
        p.setBondLabelSize(d);
      }
    }
    if (preferences.containsKey("defaultBondLength")) {
      double d = ExtString.toDouble(preferences.get("defaultBondLength"));
      if (!Double.isNaN(d)) {
        p.setDefaultBondLength(d);
      }
    }
    if (preferences.containsKey("labelHeight")) {
      double d = ExtString.toDouble(preferences.get("labelHeight"));
      if (!Double.isNaN(d)) {
        p.setLabelHeight(d);
      }
    }

    if (preferences.containsKey("displayChiralStereoLabels")) {
      if (preferences.get("displayChiralStereoLabels").equals("CLASSIC")) {
        p.setDisplayChiralStereoLabels(JDrawPreferences.STEREOLABEL_CLASSIC);
      } else if (preferences.get("displayChiralStereoLabels").equals("IUPAC")) {
        p.setDisplayChiralStereoLabels(JDrawPreferences.STEREOLABEL_IUPAC);
      } else if (preferences.get("displayChiralStereoLabels").equals("ON")) {
        p.setDisplayChiralStereoLabels(JDrawPreferences.STEREOLABEL_ON);
      } else if (preferences.get("displayChiralStereoLabels").equals("OFF")) {
        p.setDisplayChiralStereoLabels(JDrawPreferences.STEREOLABEL_OFF);
      }
    }


    if (preferences.containsKey("hydrogenDisplayMode")) {
      if (preferences.get("hydrogenDisplayMode").equals("ALL")) {
        p.setHydrogenDisplayMode(JDrawPreferences.HYDROGEN_ALL);
      } else if (preferences.get("hydrogenDisplayMode").equals("HETERO")) {
        p.setHydrogenDisplayMode(JDrawPreferences.HYDROGEN_HETERO);
      } else if (preferences.get("hydrogenDisplayMode").equals("OFF")) {
        p.setHydrogenDisplayMode(JDrawPreferences.HYDROGEN_OFF);
      } else if (preferences.get("hydrogenDisplayMode").equals("TERMINAL")) {
        p.setHydrogenDisplayMode(JDrawPreferences.HYDROGEN_TERMINAL);
      } else if (preferences.get("hydrogenDisplayMode").equals("TERMINAL_AND_HETERO")) {
        p.setHydrogenDisplayMode(JDrawPreferences.HYDROGEN_TERMINAL_AND_HETERO);
      }
    }

    if (preferences.containsKey("polAtomDisplayMode")) {
      if (preferences.get("polAtomDisplayMode").equals("BEAD")) {
        p.setPolAtomDisplayMode(JDrawPreferences.POL_STYLE_BEAD);
      } else if (preferences.get("polAtomDisplayMode").equals("TEXT")) {
        p.setPolAtomDisplayMode(JDrawPreferences.POL_STYLE_TEXT);
      }
    }
    BufferedImage myImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
    g.paint(myImage);
    return myImage;
  }

  private Color getColor(String hex) {
    try {
      if (!hex.startsWith("#")) {
        hex = "#" + hex;
      }
      return Color.decode(hex);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  public String getPreferenceGroup() {
    return "Chemical Structures";
  }

  public void setPreference(PreferenceIF preference) {
    if (preference.getPreferenceName().equals("Stereo Group Color Display")) {
      if (!preference.isDefault()) {
        preferences.put("stereoGroupColorDisplay", preference.getPreferenceValue().toString().toUpperCase().replace(' ', '_'));
      }
    } else if (preference.getPreferenceName().equals("Background Color")) {
      if (!preference.isDefault()) {
        preferences.put("backgroundColor", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Bond Label Size")) {
      if (!preference.isDefault()) {
        preferences.put("bondLabelSize", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Color Atoms By Type")) {
      if (!preference.isDefault()) {
        preferences.put("colorAtomsByType", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Default BondLength")) {
      if (!preference.isDefault()) {
        preferences.put("defaultBondLength", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Display Chiral Stereo Labels")) {
      if (!preference.isDefault()) {
        preferences.put("displayChiralStereoLabels", preference.getPreferenceValue().toString().toUpperCase().replace(' ', '_'));
      }
    } else if (preference.getPreferenceName().equals("Foreground Color")) {
      if (!preference.isDefault()) {
        preferences.put("foregroundColor", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Hydrogen Display Mode")) {
      if (!preference.isDefault()) {
        preferences.put("hydrogenDisplayMode", preference.getPreferenceValue().toString().toUpperCase().replace(' ', '_'));
      }
    } else if (preference.getPreferenceName().equals("Label Height")) {
      if (!preference.isDefault()) {
        preferences.put("labelHeight", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Pol Atom Display Mode")) {
      if (!preference.isDefault()) {
        preferences.put("polAtomDisplayMode", preference.getPreferenceValue().toString().toUpperCase().replace(' ', '_'));
      }
    } else if (preference.getPreferenceName().equals("Stereo Abs Color")) {
      if (!preference.isDefault()) {
        preferences.put("stereoAbsColor", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Stereo And Color")) {
      if (!preference.isDefault()) {
        preferences.put("stereoAndColor", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Stereo Or Color")) {
      if (!preference.isDefault()) {
        preferences.put("stereoOrColor", (String) preference.getPreferenceValue());
      }
    }

  }
}
