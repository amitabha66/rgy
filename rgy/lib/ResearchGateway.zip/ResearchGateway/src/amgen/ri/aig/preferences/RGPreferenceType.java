
/*
 *   UserPreferenceType
 *   RDBData wrapper class for UserPreferenceGroup
 *   $Revision: 1.2 $
 *   Created: Jeffrey McDowell, 25 Oct 2010
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.preferences;


import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.SQLManagerIF;
import amgen.ri.util.ExtString;

/**
 *   RDBData wrapper class for RGPreferenceType. These are the basic data types. For those with defined lists
 *   the possible options are in the preference_options String delimited by '|' characters.
 *   @version $Revision: 1.2 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class RGPreferenceType extends RdbData {
    protected String rg_preference_type;
    protected String preference_options;
    protected String ext_field_config;

    /**
     * Default Constructor
     */
    public RGPreferenceType() {
        super();
    }
    /**
     * RdbData Constructor
     */
    public RGPreferenceType(String rg_preference_type, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.rg_preference_type= rg_preference_type;
    }

    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return rg_preference_type;
    }
    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }
    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }
    /** This method returns the name of the table. */
    protected String getTableName() {
        return "RG_PREFERENCE_TYPE";
    }
    /** Get value for user_preference_type */
    public String getPreference_type() {
        return (String)get("rg_preference_type", false);
    }
    /** Get value for user_preference_type */
    public String getExtFieldConfig() {
        return (String)get("ext_field_config");
    }
    /** Get value for preference_options */
    public List<String> getPreferenceOptionList() {
        String options=(String)get("preference_options");
        if (!ExtString.hasLength(options)) {
            return new ArrayList<String>();
        }
        return Arrays.asList(options.split("\\|"));
    }
    /** Get value for preference_options */
    public double[] getNumericPreferenceOptionBounds() {
        String options=(String)get("preference_options");
        if (ExtString.hasLength(options) && options.matches("\\[[-\\d]+,[-\\d]+\\]")) {
            String[] fields = options.replaceFirst("^[\\[(]+", "").replaceFirst("[\\])]+$", "").split(",");
            if (fields.length == 2) {
                return new double[] {ExtString.toDouble(fields[0]), ExtString.toDouble(fields[1])};
            }
        }
        return null;
    }


}
