package amgen.ri.aig.sm.structure;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import amgen.ri.util.ExtString;

/**
 * <p>@version $Id: ChemMolInput.java,v 1.1 2012/10/25 23:11:35 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class ChemMolInput {
    private ChemMolSource source;
    private String key;
    private String[] input;
    private ChemMolIDType type;
    private File outputFile;

    public ChemMolInput(ChemMolSource source, ChemMolIDType type) {
        this.key = java.util.UUID.randomUUID() + "";
        this.source = source;
        this.type = type;
        this.input = new String[] {key};
    }

    public ChemMolInput(ChemMolSource source, String input, ChemMolIDType type) {
        this(source, new String[] {input}, type);
    }

    public ChemMolInput(ChemMolSource source, String[] input, ChemMolIDType type) {
        this.key = java.util.UUID.randomUUID() + "";
        this.source = source;
        this.input = input;
        this.type = type;
    }

    public String getKey() {
        return key;
    }

    public String[] getInput() {
        return input;
    }

    public ChemMolIDType getType() {
        return type;
    }

    public ChemMolSource getSource() {
        return source;
    }

    public File getMolFile(File tempDir) {
        if (outputFile == null) {
            String extension = "mol";
            if (source.equals(ChemMolSource.ACD)) {
                extension = "sdf";
            } else if (source.equals(ChemMolSource.ACDSC)) {
                extension = "sdf";
            } else if (source.equals(ChemMolSource.CMC)) {
                extension = "sdf";
            } else if (source.equals(ChemMolSource.SMILES)) {
                extension = "sdf";
            }
            outputFile = new File(tempDir, UUID.randomUUID() + "." + extension);
        }
        return outputFile;
    }

    public String getMolFileStr() {
        try {
            if (outputFile != null) {
                return ExtString.readToString(getMolFile());
            }
        } catch (IOException e) {}
        return null;
    }

    public File getMolFile() {
        if (outputFile != null) {
            return outputFile;
        }
        return null;
    }

    public void setMolFile(File molFile) {
        this.outputFile = molFile;
    }

    public void setSource(ChemMolSource source) {
        this.source = source;
    }

    public String toString() {
        String s = source + "\n";
        s += key + "\n";
        s += ExtString.join(input, ',') + "\n";
        s += type + "\n";
        s += outputFile;
        return s;
    }

    public static ChemMolInput getChemMolInput(String db, String rootNumber, String lot, String component_id, String cdbregno,
                                               String id, String substanceID, String mdlnum, String smiles,
                                               String mol, String image_id, String sessionUser) {
        ChemMolSource source = (db == null ? ChemMolSource.ACRF : ChemMolSource.fromString(db));
        String inString = ExtString.findFirstNotNull(new String[] {rootNumber, cdbregno, id, mdlnum, substanceID});
        ChemMolInput input = new ChemMolInput(source, inString, ChemMolIDType.ID);

        if (ExtString.hasLength(component_id)) {
            input = new ChemMolInput(ChemMolSource.ACRF_COMPONENT, new String[] {component_id, sessionUser}, ChemMolIDType.ID);
        } else if (ExtString.hasLength(smiles)) {
            input = new ChemMolInput(ChemMolSource.SMILES, smiles, ChemMolIDType.SMILES);
        } else if (ExtString.hasLength(image_id)) {
            input = new ChemMolInput(ChemMolSource.IMAGE, image_id, ChemMolIDType.IMAGE);
        } else if (ExtString.hasLength(mol)) {
            input = new ChemMolInput(ChemMolSource.MOL, ChemMolIDType.MOL);
        } else {
            if (source.equals(ChemMolSource.ACRF)) {
                if (rootNumber != null && lot != null) {
                    input = new ChemMolInput(ChemMolSource.ACRF, new String[] {rootNumber, lot}, ChemMolIDType.AMGEN_NAME);
                } else if (inString.indexOf('#') > 0) {
                    input = new ChemMolInput(ChemMolSource.ACRF, inString.split("#", 2), ChemMolIDType.AMGEN_NAME);
                } else if (rootNumber != null) {
                    input = new ChemMolInput(ChemMolSource.ACRF, inString, ChemMolIDType.ROOT_NUMBER);
                } else if (cdbregno != null) {
                    input = new ChemMolInput(ChemMolSource.ACRF, inString, ChemMolIDType.CDBREGNO);
                } else if (substanceID != null) {
                    input = new ChemMolInput(ChemMolSource.ACRF, inString, ChemMolIDType.SUBSTANCE_ID);
                }
            } else if (source.equals(ChemMolSource.ACRF_COMPONENT)) {
                if (cdbregno != null) {
                    input = new ChemMolInput(ChemMolSource.ACRF_COMPONENT, new String[] {inString, sessionUser}, ChemMolIDType.CDBREGNO);
                } else {
                    input = new ChemMolInput(ChemMolSource.ACRF_COMPONENT, new String[] {inString, sessionUser}, ChemMolIDType.ID);
                }
            }
        }
        return input;
    }

    public static ChemMolInput getChemMolInput(ChemMolSource source, String inString, ChemMolIDType idType) {
        switch (source) {
            case UNKNOWN:
                throw new IllegalArgumentException("Unknown ChemMolSource");
            case ACRF:
                if (inString.indexOf('#') > 0) {
                    return new ChemMolInput(ChemMolSource.ACRF, inString.split("#", 2), ChemMolIDType.AMGEN_NAME);
                }
                //Fall through
            default:
                return new ChemMolInput(source, inString, idType);
        }
    }


}
