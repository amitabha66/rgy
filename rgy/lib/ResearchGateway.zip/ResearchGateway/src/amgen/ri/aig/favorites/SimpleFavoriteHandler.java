/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.favorites;

import amgen.ri.aig.items.ItemsManager;
import amgen.ri.aig.record.ItemRecord;
import amgen.ri.aig.store.StoreRequestHandler;
import amgen.ri.json.JSONObject;
import amgen.ri.util.Debug;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SimpleFavoriteHandler extends StoreRequestHandler {
  public SimpleFavoriteHandler() {
  }

  public SimpleFavoriteHandler(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  @Override
  public JSONObject generateJSONResponse() throws Exception {
    JSONObject jFolderItems = new JSONObject();
    FavoriteManager favoriteManager = new FavoriteManager(this);
    ItemsManager itemsManager = new ItemsManager(this);
    if (doesParameterExist("favoriteID")) {
      Map<Integer, ItemRecord> sharedFavorites = favoriteManager.getSharedFavoritesForUserAsFavoriteIDMap();
      String[] favoriteIDs = getParameter("favoriteID").split(",");
      boolean isUserFavoriteOwner = false;
      for (String favoriteID : favoriteIDs) {
        try {
          int favID = new Integer(favoriteID);
          Favorite favorite = favoriteManager.getFavorite(favoriteID.trim());
          boolean isOwner = (favorite.getCreated_by().equals(getSessionLogin().getUsername()));
          ItemRecord itemRecord = null;
          if (isOwner) {
            itemRecord = itemsManager.getItemRecordForItemKey(favorite.getFavoriteID(), FavoriteFolderItem.ItemType.FAVORITE);
            isUserFavoriteOwner = true;
          } else {
            itemRecord= sharedFavorites.get(favID);           
          }
          if (itemRecord != null) {
            jFolderItems.append("folderItems", itemRecord);
          }
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
      if (!jFolderItems.has("folderItems") || jFolderItems.getJSONArray("folderItems").length() == 0) {
        if (favoriteIDs.length == 1 && !isUserFavoriteOwner) {
          throw new IllegalArgumentException("Sorry, unable to load shared favorite. You may not have access or you may need to wait for access to be updated.");
        } else {
          throw new IllegalArgumentException("Sorry, unable to load favorite.");
        }
      }
    }
    if (!jFolderItems.has("folderItems") || jFolderItems.getJSONArray("folderItems").length() == 0) {
      throw new IllegalArgumentException("Sorry, unable to locate favorite.");
    }    
    return jFolderItems;
  }
}
