package amgen.ri.aig.scripts;


import java.lang.reflect.Field;
import java.sql.Timestamp;

import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.rdb.ClobData;
import amgen.ri.rdb.OraSequenceField;
import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.SQLManagerIF;
import amgen.ri.rdb.Saveable;

/**
 *   RDBData wrapper class for RGScript entries
 *   @version $Revision: 1.2 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class RGScript extends RdbData implements Saveable {
    protected OraSequenceField script_id;
    protected String entity_type;
    protected String group_name;
    protected String method;
    private String label;
    protected String description;
    protected ClobData code;
    protected String src_url;
    protected String java_class_name;
    protected String parameters;
    protected ClobData help;
    protected String created_by;
    protected Timestamp created;

    /**
     * Default Constructor
     */
    public RGScript() {
        super();
    }

    /**
     * RdbData Constructor
     */
    public RGScript(String script_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.script_id = new OraSequenceField(script_id);
    }

    /**
     * Constructor which sets the class variables for a normal request
     */
    public RGScript(String session_id, EntityListCategory entity_type, String group_name, String method, String label, String description, String code,
                    String src_url, String parameters, String help, String created_by, Timestamp created, SQLManagerIF sqlManager, String connectionPool) {
        super(sqlManager, null, connectionPool);
        this.script_id = new OraSequenceField("rg_script_seq", this);
        this.entity_type = entity_type.toString();
        this.group_name = group_name;
        this.method = method;
        this.label = label;
        this.description = description;
        this.code = ClobData.valueOf(code, "code");
        this.src_url = src_url;
        this.parameters = parameters;
        this.help = ClobData.valueOf(help, "help");
        this.created_by = created_by;
        this.created = new Timestamp(System.currentTimeMillis());
    }


    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return script_id + "";
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }

    /** This method returns the name of the table. */
    protected String getTableName() {
        return "RG_SCRIPTS";
    }

    /** Returns the SQL for INSERTing the object in the table */
    public String getInsertSQL() {
        return null;
    }

    /** Returns the SQL for UPDATing the object in the table */
    public String getUpdateSQL() {
        return null;
    }

    public EntityListCategory getEntity_type() {
        return EntityListCategory.fromString(getAsString("entity_type"));
    }

    public String getGroup_name() {
        return getAsString("group_name");
    }

    public String getMethod() {
        return getAsString("method");
    }

    public String getDescription() {
        return getAsString("description");
    }

    public String getSrc_url() {
        return getAsString("src_url");
    }

    public String getParameters() {
        return getAsString("parameters");
    }

    public String getCreated_by() {
        return getAsString("created_by");
    }

    public String getCreated() {
        return getAsString("created");
    }

    public String getHelp() {
        return getAsString("help");
    }

    public String getCode() {
        return getAsString("code");
    }

    public String getJava_class_name() {
        return getAsString("java_class_name");
    }

    public String getLabel() {
        return getAsString("label");
    }


}
