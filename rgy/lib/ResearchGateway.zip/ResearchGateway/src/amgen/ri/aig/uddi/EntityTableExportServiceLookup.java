package amgen.ri.aig.uddi;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.service.ServiceCacheResponse;
import amgen.ri.aig.cache.item.EntityTableCacheItem;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.asf.sa.uddi.*;
import amgen.ri.xml.ExtXMLElement;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.soap.SOAPException;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;

/**
 *
 * Handles drill down service lookups for the Entity Table
 * <p>
 * @version $Id: EntityTableExportServiceLookup.java,v 1.9 2014/02/10 06:26:12
 * jemcdowe Exp $</p>
 *
 */
public class EntityTableExportServiceLookup extends AbstractServiceLookup {

  private EntityTable entityTable;
  EntityListCategory tableType;

  public EntityTableExportServiceLookup() {
    super();
  }

  public EntityTableExportServiceLookup(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
    String entityTableKey = getParameter("entityTableKey");
    EntityTableCacheItem entityTableCacheItem = ServiceCache.getServiceCache(request).getEntityTableResult(entityTableKey);
    entityTable = entityTableCacheItem.getEntityTable();
    tableType = entityTable.getEntityCategory();
  }

  /**
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return TBXServlet
   * @todo Implement this amgen.ri.aig.AIGServlet method
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new EntityTableExportServiceLookup(req, resp);
  }

  /**
   *
   * @throws Exception
   * @todo Implement this amgen.ri.aig.AIGServlet method
   */
  protected void performRequest() throws Exception {
    Element servicesElement = new Element("Services");
    List<TModelDetails> exportTypeTModels = getExportTypeTModels();
    if (exportTypeTModels.size() > 0) {
      Map<String, ClassificationSchemeQuery> classificationSchemeQueries = new LinkedHashMap<String, ClassificationSchemeQuery>();
      ServiceDataCategory serviceDataCategory = getEntityClassManager().convertEntityListCategoryToServiceDataCategory(tableType);
      classificationSchemeQueries.put("s2", new ClassificationSchemeQuery(ClassificationSchemeQuery.OR_ALL_KEYS));
      classificationSchemeQueries.get("s2").addKeyValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, ServiceDataCategory.revertTo(serviceDataCategory));
      Map<String, ServiceDetails> services = new LinkedHashMap<String, ServiceDetails>();
      for (String classificationSchemeQueryKey : classificationSchemeQueries.keySet()) {
        ServiceQuery serviceQuery= new ServiceQuery(classificationSchemeQueries.get(classificationSchemeQueryKey));
        serviceQuery.addResultTypes(exportTypeTModels);
        ServiceCacheResponse sortedSearchServices = findAndSortServices(serviceQuery);
        for (ServiceDetails searchService : sortedSearchServices) {
          String serviceKey = searchService.getKey();
          if (!services.containsKey(serviceKey) && isValidService(searchService, classificationSchemeQueries.get(classificationSchemeQueryKey))) {
            services.put(serviceKey, searchService);
            try {
              if (searchService.containsUserInAllowedUsers(getSessionLogin().getRemoteUser(), true)) {
                ServiceAttributes serviceAttributes = new ServiceAttributes(searchService, getEntityClassManager());
                Element searchServiceElement = searchService.getAsElement();
                ExtXMLElement.setChildElementValue(searchServiceElement, "Name", serviceAttributes.getName(ServiceNamingContext.RG_RESOURCE));
                ExtXMLElement.setChildElementValue(searchServiceElement, "Description", serviceAttributes.getDescription(ServiceNamingContext.RG_RESOURCE));
                ExtXMLElement.setChildElementValue(searchServiceElement, "IconClass", serviceAttributes.getIconClass(ServiceNamingContext.RG_RESOURCE));
                servicesElement.addContent(searchServiceElement);
              }
            } catch (Exception e) {
              e.printStackTrace();
            }
          }
        }
      }
    }
    ExtXMLElement.write(servicesElement, response.getWriter());
  }

  protected List<TModelDetails> getExportTypeTModels() throws IOException, SOAPException, JDOMException {
    UDDIQuery uddiQuery = ServiceCache.getServiceCache(this).getUDDIQuery();
    ClassificationSchemeQuery query = new ClassificationSchemeQuery();
    query.addKeyValue("Research Gateway Categorization Scheme", "RG Table Export");
    return uddiQuery.findTModels(query);
  }

  protected boolean isValidService(ServiceDetails searchService, ClassificationSchemeQuery query) {
    try {
      boolean valid = true;
      List<ServiceParameter> parametersNotReady = searchService.getParametersNotReady();
      for (ServiceParameter parameter : parametersNotReady) {
        if (!parameter.isCategorizedAs(TModelCommonNameFactory.RESEARCH_GATEWAY_SERVICEINPUT_CATEGORIZATION_SCHEME, "Entity Table XML")) {
          valid = false;
        }
      }
      List<ServiceParameter> entityTableXMLParameters = searchService.getParameters(TModelCommonNameFactory.RESEARCH_GATEWAY_SERVICEINPUT_CATEGORIZATION_SCHEME, "Entity Table XML");
      if (entityTableXMLParameters.size() == 0) {
        valid = false;
      }
      return valid;
    } catch (Exception e) {
      return false;
    }
  }

  public EntityTable getEntityTable() {
    return entityTable;
  }

  @Override
  public Document getServicesDocument() throws JDOMException, AIGException {
    throw new UnsupportedOperationException("Not supported yet.");
  }

}
