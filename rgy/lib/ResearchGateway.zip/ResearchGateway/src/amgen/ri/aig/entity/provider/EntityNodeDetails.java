package amgen.ri.aig.entity.provider;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import javax.naming.directory.Attribute;

import org.jdom.Document;
import org.jdom.Element;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.cache.tree.EntityLineage;
import amgen.ri.aig.cache.tree.NodeType;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.service.ServiceCacheResponse;
import amgen.ri.aig.cache.tree.TreeNode;
import amgen.ri.aig.cache.tree.TreeNodeCache;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.sm.structure.ChemMolIDType;
import amgen.ri.aig.sm.structure.ChemMolInput;
import amgen.ri.aig.sm.structure.ChemMolSource;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.sv.OILServiceParameterInterceptor;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.aig.uddi.ServiceQuery;
import amgen.ri.asf.sa.uddi.ClassificationSchemeNames;
import amgen.ri.asf.sa.uddi.ClassificationSchemeQuery;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.ServiceInvocationDetails;
import amgen.ri.json.JSONObject;
import amgen.ri.ldap.AmgenLDAPAuthProvider;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;

public class EntityNodeDetails implements EntityDetailsResponseIF {
  static final SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.ENHANCED_DATE_PATTERN);
  private AIGServlet requestor;

  /**
   * Default constructor
   */
  public EntityNodeDetails(AIGServlet requestor) {
    super();
    this.requestor = requestor;
  }

  public AIGServlet getRequestor() {
    return requestor;
  }

  public JSONObject getResponseJSON() throws AIGException {
    throw new AIGException("Response type not implemented", Reason.NOT_IMPLEMENTED);
  }

  public Document getResponseDocument() throws AIGException {
    Document entityDetailsDoc = null;
    String entityNodeUUID = requestor.getParameter("uuid");
    TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(requestor.getHttpServletRequest());
    ServiceCache serviceCache = ServiceCache.getServiceCache(requestor.getHttpServletRequest());

    Element entityTreeNodeEl = tnCache.getTreeNode(entityNodeUUID);
    if (entityTreeNodeEl == null) {
      return null;
    }
    ServiceDataCategory dataType = ServiceDataCategory.getServiceDataCategory(entityTreeNodeEl);
    try {
      TreeNode entityTreeNode = new TreeNode(entityTreeNodeEl);
      TreeNode sourceServiceResultNode = tnCache.getServiceResultParentTreeNode(entityTreeNode);
      ServiceResultCacheItem sourceResult = serviceCache.getServiceResult(sourceServiceResultNode.getKey());
      ServiceAttributes serviceAttributes;
      OILServiceParameterInterceptor oilInterceptor;

      Element entityDetailsEl = null;
      Element nodePropertiesEl;
      Element nodePropertyEl;
      List<EntityLineage> entityLineage = tnCache.getEntityLineage(entityNodeUUID);
      EntityLineage nodeEntityLineage = null;

      if (entityLineage.size() > 0) {
        nodeEntityLineage = entityLineage.get(0);
        try {
          switch (NodeType.getNodeType(entityTreeNodeEl)) {
            case ENTITYNODE:
              ClassificationSchemeQuery query = new ClassificationSchemeQuery();
              query.addKeyValue(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME, ServiceDataCategory.revertTo(dataType));
              ServiceQuery serviceQuery= new ServiceQuery(query, TModelCommonNameFactory.ENTITYPROPERTYDEFINITION_tMODELNAME);
              ServiceCacheResponse services = serviceCache.getServices(serviceQuery);
              if (services != null && services.size() > 0) {
                requestor.setServiceParameters(services.get(0), entityLineage);
                entityDetailsEl = services.get(0).executeService2JDocument(TModelCommonNameFactory.ENTITYPROPERTYDEFINITION_tMODELNAME, requestor.getStandardTransformParameters()).
                        detachRootElement();
                requestor.addRequestLogServiceInvocationDetails(services.get(0));
              }
              break;
            case RESULTNODE:
              int childCount = tnCache.getChildTreeNodeKeys(entityNodeUUID).size();
              nodePropertiesEl = new Element("Properties");
              entityDetailsEl = nodePropertiesEl;

              nodePropertyEl = ExtXMLElement.addElement(nodePropertiesEl, "Property");
              ExtXMLElement.addAttribute(nodePropertyEl, "name", "Name");
              ExtXMLElement.addAttribute(nodePropertyEl, "value", entityTreeNodeEl.getAttributeValue("TEXT") + " (Query Results)");

              nodePropertyEl = ExtXMLElement.addElement(nodePropertiesEl, "Property");
              ExtXMLElement.addAttribute(nodePropertyEl, "name", "Number of Results");
              ExtXMLElement.addAttribute(nodePropertyEl, "value", childCount + "");
              ExtXMLElement.addAttribute(nodePropertyEl, "type", "integer");

              //getAddServiceRunDetails(entityDetailsEl);

              break;
            case SERVICENODE:
              childCount = tnCache.getChildTreeNodeKeys(entityNodeUUID).size();
              nodePropertiesEl = new Element("Properties");
              entityDetailsEl = nodePropertiesEl;

              nodePropertyEl = ExtXMLElement.addElement(nodePropertiesEl, "Property");
              ExtXMLElement.addAttribute(nodePropertyEl, "name", "Name");
              ExtXMLElement.addAttribute(nodePropertyEl, "value", entityTreeNodeEl.getAttributeValue("TEXT") + " (Service Results)");

              nodePropertyEl = ExtXMLElement.addElement(nodePropertiesEl, "Property");
              ExtXMLElement.addAttribute(nodePropertyEl, "name", "Number of Results");
              ExtXMLElement.addAttribute(nodePropertyEl, "value", childCount + "");
              ExtXMLElement.addAttribute(nodePropertyEl, "type", "integer");
              break;
          }
        } catch (Exception e) {
          e.printStackTrace();
          entityDetailsEl = null;
        }
      }
      if (entityDetailsEl == null) {
        entityDetailsEl = getNodeDetailsElement(entityTreeNodeEl);
      }
      entityDetailsDoc = new Document(entityDetailsEl);
      List<Element> propertyEls = ExtXMLElement.getXPathElements(entityDetailsDoc, "//Property");
      for (int i = 0; i < propertyEls.size(); i++) {
        Element propertyEl = propertyEls.get(i);
        /*
         * THIS IS TO SUPPORT THE DATE RETURNED BY AIM SERVICE WHICH IS
         * FORMATTED dd-MM-y
         */
        if (ExtString.equalsIgnoreCase(propertyEl.getAttributeValue("type"), "date") && dataType.equals(ServiceDataCategory.ASSAY_IDENTIFIER)) {
          propertyEl.setAttribute("format", "d-n-y");
        }
        propertyEl.setAttribute("order", i + "");

        if ((dataType.equals(ServiceDataCategory.AMGEN_ROOT_ID) || dataType.equals(ServiceDataCategory.AMGEN_COMPOUND_ID)
                || dataType.equals(ServiceDataCategory.AMGEN_NAME)) && ExtString.equals(propertyEl.getAttributeValue("name"), "Structure")) {
          propertyEl.setAttribute("type", "structure");
        }
      }
      Element propertiesEl = ExtXMLElement.getXPathElement(entityDetailsDoc, "//Properties[1]");
      if (propertiesEl != null && sourceResult != null && sourceResult.getServiceDetails() != null) {
        ServiceInvocationDetails invocationDetails = sourceResult.getServiceDetails().getServiceInvocationDetails();
        if (invocationDetails != null) {
          String startTime = dateFormat.format(invocationDetails.getStartTime());
          String endTime = dateFormat.format(invocationDetails.getEndTime());
          double innvocationTime = invocationDetails.getInnvocationTimeMillis();
          String elapsed = ExtString.getElapsedTimeString(innvocationTime / 1000);
          Element nodeProperty = ExtXMLElement.addElement(propertiesEl, "Property");
          ExtXMLElement.addAttribute(nodeProperty, "name", "Start");
          ExtXMLElement.addAttribute(nodeProperty, "value", startTime);
          ExtXMLElement.addAttribute(nodeProperty, "category", "Result Details");

          nodeProperty = ExtXMLElement.addElement(propertiesEl, "Property");
          ExtXMLElement.addAttribute(nodeProperty, "name", "End");
          ExtXMLElement.addAttribute(nodeProperty, "value", endTime);
          ExtXMLElement.addAttribute(nodeProperty, "category", "Result Details");

          nodeProperty = ExtXMLElement.addElement(propertiesEl, "Property");
          ExtXMLElement.addAttribute(nodeProperty, "name", "Elapsed");
          ExtXMLElement.addAttribute(nodeProperty, "value", elapsed);
          ExtXMLElement.addAttribute(nodeProperty, "category", "Result Details");
        }
      }
      return entityDetailsDoc;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  /**
   * Returns a node properties element for the given node
   *
   * @param entityTreeNode Element
   * @return Element
   */
  private Element getNodeDetailsElement(Element entityTreeNode) {
    Element nodeProperties = new Element("Properties");
    Element nodeProperty = ExtXMLElement.addElement(nodeProperties, "Property");
    ExtXMLElement.addAttribute(nodeProperty, "name", "Name");
    ExtXMLElement.addAttribute(nodeProperty, "value", entityTreeNode.getAttributeValue("TEXT"));
    ExtXMLElement.addAttribute(nodeProperty, "category", "Node Properties");

    nodeProperty = ExtXMLElement.addElement(nodeProperties, "Property");
    ExtXMLElement.addAttribute(nodeProperty, "name", "Type");
    ExtXMLElement.addAttribute(nodeProperty, "value", entityTreeNode.getAttributeValue("SERVICE_DATA_TYPE_CATEGORY"));
    ExtXMLElement.addAttribute(nodeProperty, "category", "Node Properties");

    if (NodeType.fromString(entityTreeNode.getAttributeValue("NODE_TYPE")).equals(NodeType.ENTITYNODE) && entityTreeNode.getAttributeValue("SERVICE_DATA_TYPE_CATEGORY") != null) {
      if (entityTreeNode.getAttributeValue("SERVICE_DATA_TYPE_CATEGORY").equals("EntrezGene Identifier")) {
      } else if (entityTreeNode.getAttributeValue("SERVICE_DATA_TYPE_CATEGORY").equals("Amgen Root ID")) {
        nodeProperty = ExtXMLElement.addElement(nodeProperties, "Property");
        ExtXMLElement.addAttribute(nodeProperty, "name", "Description");
        ExtXMLElement.addAttribute(nodeProperty, "value", entityTreeNode.getAttributeValue("TITLE"));
        ExtXMLElement.addAttribute(nodeProperty, "category", "Node Properties");

        String serviceData = (entityTreeNode.getAttributeValue("SERVICE_DATA") == null ? entityTreeNode.getAttributeValue("TEXT") : entityTreeNode.getAttributeValue("SERVICE_DATA"));

        nodeProperty = ExtXMLElement.addElement(nodeProperties, "Property");
        ExtXMLElement.addAttribute(nodeProperty, "name", "Structure");
        ExtXMLElement.addAttribute(nodeProperty, "value", entityTreeNode.getAttributeValue("SERVICE_DATA_TYPE_CATEGORY"));
        ChemMolInput chemMolInput = new ChemMolInput(ChemMolSource.ACRF, serviceData, ChemMolIDType.ROOT_NUMBER);
        ExtXMLElement.addAttribute(nodeProperty, "imageURL", requestor.getStructureImageURL(chemMolInput, "150", null));
        ExtXMLElement.addAttribute(nodeProperty, "category", "Node Properties");
      } else if (entityTreeNode.getAttributeValue("SERVICE_DATA_TYPE_CATEGORY").equals("Project")) {
      } else if (entityTreeNode.getAttributeValue("SERVICE_DATA_TYPE_CATEGORY").equals("Assay Identifier")) {
      } else if (entityTreeNode.getAttributeValue("SERVICE_DATA_TYPE_CATEGORY").equals("Amgen Login")) {
        /*
         * String loginID= entityLineage.getAttributeValue("SERVICE_DATA");
         * if (loginID!= null) {
         * nodeProperty = addElement(nodeProperties, "Property");
         * addAttribute(nodeProperty, "Name", "Picture");
         * addAttribute(nodeProperty, "Value",
         * entityLineage.getAttributeValue("SERVICE_DATA_TYPE_CATEGORY"));
         * addAttribute(nodeProperty, "ImageURL", getStaffImageURL(loginID,
         * null) + "");
         * }
         */
      }
    }
    return nodeProperties;
  }

  private void addStaffProperty(Element propertiesEl, Map<String, Attribute> attributes, String attrName, String propName, String linkURL) {
    String attrValue = "-";
    try {
      attrValue = attributes.get(attrName).get() + "";
      if (attrValue == null) {
        attrValue = "-";
      }
    } catch (Exception e) {
    }
    Element nodeProperty = ExtXMLElement.addElement(propertiesEl, "Property");
    ExtXMLElement.addAttribute(nodeProperty, "name", propName);
    ExtXMLElement.addAttribute(nodeProperty, "value", attrValue);
    ExtXMLElement.addAttribute(nodeProperty, "category", "Staff Details");
    if (linkURL != null) {
      ExtXMLElement.addAttribute(nodeProperty, "linkURL", linkURL);
    }
  }

  /**
   * Returns the mimetype of the servlet
   */
  protected String getServletMimeType() {
    return "text/xml";
  }
}
