package amgen.ri.aig.entitylist;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.asf.sa.uddi.ServiceDetails;

public interface EntityListSourceServiceIF {
    /**
     * Returns the ServiceDetails for the source service
     *
     * @param serviceCache ServiceCache
     * @return ServiceDetails
     * @throws AIGException
     */
    public ServiceDetails getServiceDetails(ServiceCache serviceCache) throws AIGException;

    /** Get value for service_key */
    public String getServiceKey();
}
