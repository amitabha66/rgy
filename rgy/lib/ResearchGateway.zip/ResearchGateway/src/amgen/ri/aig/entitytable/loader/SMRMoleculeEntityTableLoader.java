package amgen.ri.aig.entitytable.loader;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.tree.TreeNode;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.entitytable.Column;
import amgen.ri.aig.entitytable.ColumnGroup;
import amgen.ri.aig.entitytable.DataCell;
import amgen.ri.aig.entitytable.DataRow;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;
import amgen.ri.aig.util.Utilities;
import amgen.ri.util.ExtString;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Custom EntityTable loader for SMR Molecule entities
 * @version $Id: SMRMoleculeEntityTableLoader.java,v 1.4 2014/07/08 15:51:47 jemcdowe Exp $
 */
public class SMRMoleculeEntityTableLoader extends StructureEntityTableLoader {
  public SMRMoleculeEntityTableLoader(AIGBase requestor) {
    this(requestor, null);
  }

  public SMRMoleculeEntityTableLoader(AIGBase requestor, String resultNodeKey) {
    super(requestor, EntityListCategory.SMR_MOLECULES, resultNodeKey);
  }

  public EntityTable createEntityTableFromResultNode(String resultNodeKey) throws AIGException {
    EntityTable entityTable = buildEntityTableFromResultNode(resultNodeKey);
    Set<String> sources = new LinkedHashSet<String>();

    //Check the rows for SOURCE attributes
    for (TreeNode childResultNode : getChildResultNodes()) {
      String sourceAttr = childResultNode.getNodeAttribute("SOURCE");
      if (sourceAttr != null) {
        sources.add(sourceAttr);
      }
    }
    if (sources.size() > 0) {
      //Add any source columns
      ColumnGroup sourceColumnGroup = new ColumnGroup("Source");
      entityTable.addColumnGroup(sourceColumnGroup);
      for (String source : sources) {
        Column sourceColumn = new Column(source);
        sourceColumnGroup.addColumn(sourceColumn);
      }
    }
    //Add the rows
    for (TreeNode childResultNode : getChildResultNodes()) {
      String compoundID = childResultNode.getText();
      String serviceData = childResultNode.getServiceData();
      DataRow dataRow = addEntityRowToEntityTable(entityTable, serviceData, compoundID);
      for (String source : sources) {
        String sourceAttr = childResultNode.getNodeAttribute("SOURCE");
        String sourceID = childResultNode.getNodeAttribute("SOURCE_VALUE");
        if (ExtString.equals(source, sourceAttr) && sourceID != null) {
          dataRow.addDataCell(new DataCell(sourceID));
        } else {
          dataRow.addDataCell(new DataCell(""));
        }
      }
    }
    return entityTable;
  }
}
