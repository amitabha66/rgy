package amgen.ri.aig.cache.mgr;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.CacheManager;
import amgen.ri.aig.cache.CacheManagerFactory;
import amgen.ri.aig.cache.CacheManagerIF;
import amgen.ri.aig.cache.CacheType;
import amgen.ri.aig.cache.offline.CacheBuilderExe;
import amgen.ri.aig.cache.offline.CacheBuilderTask;
import amgen.ri.aig.cache.ora.OracleCacheManager;
import amgen.ri.aig.cache.service.ServiceCacheDisable;
import amgen.ri.json.JSONObject;
import amgen.ri.rg.config.ConfigurationParameterInstanceType;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import java.io.File;
import java.io.IOException;
import java.io.ObjectStreamException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import javax.servlet.Servlet;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.soap.SOAPException;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.jdom.JDOMException;

/**
 * Servlet endpoint to manage the global cache
 *
 * @version $id$
 */
@WebServlet(name = "GlobalCacheManager", urlPatterns = {"/cachemgr.go", "/cachemgr"})
public class GlobalCacheManager extends AIGServlet {

  enum Request {

    STATUS, REFRESH, REFRESH_SERVICE, GET_NOCACHE_SERVICES, SET_NOCACHE_SERVICES, GET_NOCACHING, SET_NOCACHING, UNKNOWN;

    public static Request fromString(String s) {
      if (s == null) {
        return STATUS;
      }
      try {
        return Request.valueOf(s.toUpperCase());
      } catch (Exception e) {
        return STATUS;
      }
    }
  }

  public GlobalCacheManager() {
    super();
  }

  public GlobalCacheManager(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  /**
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return TBXServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new GlobalCacheManager(req, resp);
  }

  /**
   *
   * @return String
   */
  protected String getServletMimeType() {
    return "text/json";
  }

  /**
   *
   * @throws Exception
   */
  protected void performRequest() throws Exception {
    setNoCache();
    OracleCacheManager cacheMgr = (OracleCacheManager) CacheManagerFactory.getOracleCacheManagerInstance(getSessionLogin().getRemoteUser());
    ServiceCacheDisable serviceCacheDisable = (ServiceCacheDisable) getSessionAttribute("ServiceCacheDisable", new ServiceCacheDisable());
    JSONObject jResponse = new JSONObject();

    switch (Request.fromString(getParameter("req"))) {
      case STATUS:
        JSONObject json = new JSONObject();
        json.put("properties", cacheMgr.getStatus().getJSONArray("properties"));
        response.getWriter().println(json);
        break;
      case REFRESH:
        try {
          exec(CacheBuilderExe.class);
        } catch (Exception e) {
          e.printStackTrace();
        }
        break;
      case REFRESH_SERVICE:
        refreshService(getParameter("keys"));
        break;
      case GET_NOCACHE_SERVICES:
        jResponse.put("keys", serviceCacheDisable);
        response.getWriter().println(jResponse);
        break;
      case SET_NOCACHE_SERVICES:
        serviceCacheDisable.clear();
        serviceCacheDisable.addAll(getParameter("keys"));
        break;
      case GET_NOCACHING:
        jResponse.put("caching_disabled", serviceCacheDisable.isDisableAllCaching());
        response.getWriter().println(jResponse);
        break;
      case SET_NOCACHING:
        serviceCacheDisable.setDisableAllCaching(ExtString.isAnyEqualIgnoreCase(getParameter("caching_disabled", "no"), "yes", "true"));
        jResponse.put("caching_disabled", serviceCacheDisable.isDisableAllCaching());
        response.getWriter().println(jResponse);
        break;
    }
  }

  public static int exec(Class klass) throws IOException,
          InterruptedException,
          URISyntaxException,
          MalformedURLException,
          JDOMException,
          SOAPException {
    String javaHome = System.getProperty("java.home");
    String javaBin = javaHome
            + File.separator + "bin"
            + File.separator + "java";

    String globalUpdateJar = ConfigurationParameterSource.getConfigParameter("GLOBAL_CACHE_UPDATE_JAR");
    ProcessBuilder builder = new ProcessBuilder(javaBin, "-jar", globalUpdateJar);
    Process process = builder.start();
    process.waitFor();
    //IOUtils.copy(process.getInputStream(), System.out);
    //IOUtils.copy(process.getErrorStream(), System.err);

    //String stdout = IOUtils.toString(process.getInputStream());
    //String stderr = IOUtils.toString(process.getErrorStream());
    int exitVal = process.exitValue();

    //System.out.println(stdout);
    //System.out.println(stderr);
    // new CacheBuilderTask().run();
    return exitVal;
  }

  private void refreshService(String serviceKeys) throws AIGException {
    if (StringUtils.isNotBlank(serviceKeys)) {
      Collection<String> serviceKeyList = new HashSet<String>(Arrays.asList(serviceKeys.split("[\\s,;]+")));
      CacheManagerIF cacheMgr = CacheManagerFactory.getOracleCacheManagerInstance(getSessionLogin().getRemoteUser());
      cacheMgr.remove(CacheType.SERVICE, serviceKeyList);

      cacheMgr = CacheManagerFactory.getCacheManagerInstance(getHttpSession());
      cacheMgr.remove(CacheType.SERVICE, serviceKeyList);
    }
  }
}
