package amgen.ri.aig.entitytable.subtable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import amgen.ri.aig.entitytable.Column;
import amgen.ri.aig.entitytable.DataCell;
import amgen.ri.aig.entitytable.EntityTableCellFormatterIF;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtArray;

/**
 * A data cells which contains a subtable. The subtable is a List of SubDataRow
 * objects
 * @version $Id: SubtableDataCell.java,v 1.1 2011/06/17 20:41:26 cvs Exp $
 */
public class SubtableDataCell extends DataCell implements Iterable<SubDataRow> {
    static final long serialVersionUID = 7600402792509447559L;
    private final int MAX_ROWS = 1000;
    private List<SubDataRow> subDataRows; //List of DataRows in the subtable
    private Map<String, SubDataRow> subDataRowMap; //Map of Row ID:DataRows in the subtable

    public SubtableDataCell() {
        super(null);
        subDataRows = new ArrayList<SubDataRow>();
        subDataRowMap = new HashMap<String, SubDataRow>();
    }

    public SubtableDataCell(List<DataCell> subDataCells) {
        this();
        for (DataCell subDataCell : subDataCells) {
            SubDataRow subDataRow = addDataRow(new SubDataRow("1"));
            subDataRow.addDataCell(subDataCell);
        }
    }

    /**
     * Adds a DataRow to the subtable table. Returns null if table reached the
     * MAX_ROWS
     *
     * @param subDataCell DataCell
     * @return SubDataRow
     */
    public SubDataRow addDataRow(DataCell subDataCell) {
        SubDataRow subDataRow = addDataRow(new SubDataRow());
        if (subDataRow == null) {
            return subDataRow;
        }
        subDataRow.addDataCell(subDataCell);
        return subDataRow;
    }

    /**
     * Adds a DataRow to the subtable table. Returns null if table reached the MAX_ROWS
     *
     * @param dataRow SubDataRow
     * @return SubDataRow
     */
    public SubDataRow addDataRow(SubDataRow dataRow) {
        if (subDataRows.size() >= MAX_ROWS) {
            return null;
        }
        subDataRows.add(dataRow);
        subDataRowMap.put(dataRow.getRowID(), dataRow);
        return dataRow;
    }

    /**
     * Returns the values of the cell which is used to sort the rows. Generally
     * this returns getValue(), but may be different for subclasses.
     *
     * @return Object
     * @param reversedSort boolean
     */
    public Object getSortValue(boolean reversedSort) {
        if (subDataRows.size() == 0) {
            return null;
        }
        SubDataRow row;
        if (reversedSort) {
            row = (SubDataRow) ExtArray.max(subDataRows, new SubtableColumnComparator());
        } else {
            row = (SubDataRow) ExtArray.min(subDataRows, new SubtableColumnComparator());
        }
        return row.getDataCell(0).getSortValue(reversedSort);
    }

    public Iterator<SubDataRow> iterator() {
        return subDataRows.iterator();
    }

    public List<SubDataRow> getRows() {
        return subDataRows;
    }

    public Object getJSONValue(EntityTableCellFormatterIF formatter, Column column) throws JSONException {
        JSONObject cellJSON = new JSONObject();

        for (SubDataRow row : subDataRows) {
            DataCell cell = row.getDataCell(0);
            cellJSON.append("values", cell.getJSONValue(formatter, column));
        }
        return cellJSON;

    }


}
