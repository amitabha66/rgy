/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amgen.ri.aig.cache.ora;

import amgen.ri.asf.sa.uddi.ServiceDetails;
import java.io.IOException;
import java.io.Serializable;
import javax.xml.soap.SOAPException;
import org.jdom.Document;
import org.jdom.JDOMException;

/**
 *
 * @author jemcdowe
 */
public class OfflineServiceDetails extends ServiceDetails implements Serializable {

        public OfflineServiceDetails(String serviceKey) {          
            super(serviceKey);
        }

        @Override
        protected Document setDataV2() throws JDOMException, SOAPException, IOException {
            return null;
        }

        @Override
        protected Document setDataV3() throws JDOMException, SOAPException, IOException {
            return null;
        }

        @Override
        public boolean isValid() {
            return false;
        }

        @Override
        public boolean isActive(int notUsed) {
            return false;
        }

    }

