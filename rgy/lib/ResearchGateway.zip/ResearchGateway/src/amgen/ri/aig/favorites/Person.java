
/*
 *   Person
 *   RDBData wrapper class for ACCESS_CONTROL
 *   $Revision: 1.2 $
 *   Created: Jeffrey McDowell, 15 Apr 2011
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.favorites;


import java.lang.reflect.Field;
import java.util.List;

import amgen.ri.rdb.CompareTerm;
import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.rdb.SQLManagerIF;

/**
 *   RDBData wrapper class for ACCESS_CONTROL
 *   @version $Revision: 1.2 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class Person extends RdbData {
    protected int person_id;
    protected String last;
    protected String first;
    protected String middlename;
    protected String amgen_login;
    protected String department;
    protected int amgen_staff_id;
    protected String familiar_name;
    protected int job_status;
    protected int emp_type;
    protected String location;
    protected String company_code;
    protected String company_code_desc;
    protected String costcenter_name;
    protected String costcenter_number;
    protected String employment_status;
    protected String employment_status_desc;
    protected String emp_group;
    protected String emp_group_desc;
    protected String emp_subgroup;
    protected String emp_subgroup_desc;
    protected String location_name;
    protected String mgnt_center;
    protected String mgnt_center_desc;
    protected int org_unit_lead_id;
    protected String org_unit_name;
    protected int org_unit_number;

    /**
     * Default Constructor
     */
    public Person() {
        super();
    }
    /**
     * RdbData Constructor
     */
    public Person(String person_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.person_id= Integer.parseInt(person_id);
    }

    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return person_id+"";
    }
    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }
    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }
    /** This method returns the name of the table. */
    protected String getTableName() {
        return "LOCAL_PERSON";
    }
    /**
     * Returns the primary key fields for the RdbData class which are used to
     * generate the SQL statement(s). If this returns null (the Default), the first field of the class is assumed.
     * The getIdentifier() method must return, in CSV, the matching number of elements as this array if generated SQL is used.
     */
    public String[] getPrimaryKeyFields() {
        return new String[] {"person_id"};
    }
    /** Get value for person_id */
    public int getPerson_id() {
        return getAsNumber("person_id", false).intValue();
    }
    /** Get value for last */
    public String getLast() {
        return (String)get("last");
    }
    /** Get value for first */
    public String getFirst() {
        return (String)get("first");
    }
    /** Get value for middlename */
    public String getMiddlename() {
        return (String)get("middlename");
    }
    /** Get value for amgen_login */
    public String getAmgen_login() {
        return (String)get("amgen_login");
    }
    /** Get value for department */
    public String getDepartment() {
        return (String)get("department");
    }
    /** Get value for amgen_staff_id */
    public int getAmgen_staff_id() {
        return getAsNumber("amgen_staff_id").intValue();
    }
    /** Get value for familiar_name */
    public String getFamiliar_name() {
        return (String)get("familiar_name");
    }
    /** Get value for job_status */
    public int getJob_status() {
        return getAsNumber("job_status").intValue();
    }
    /** Get value for emp_type */
    public int getEmp_type() {
        return getAsNumber("emp_type").intValue();
    }
    /** Get value for location */
    public String getLocation() {
        return (String)get("location");
    }
    /** Get value for company_code */
    public String getCompany_code() {
        return (String)get("company_code");
    }
    /** Get value for company_code_desc */
    public String getCompany_code_desc() {
        return (String)get("company_code_desc");
    }
    /** Get value for costcenter_name */
    public String getCostcenter_name() {
        return (String)get("costcenter_name");
    }
    /** Get value for costcenter_number */
    public String getCostcenter_number() {
        return (String)get("costcenter_number");
    }
    /** Get value for employment_status */
    public String getEmployment_status() {
        return (String)get("employment_status");
    }
    /** Get value for employment_status_desc */
    public String getEmployment_status_desc() {
        return (String)get("employment_status_desc");
    }
    /** Get value for emp_group */
    public String getEmp_group() {
        return (String)get("emp_group");
    }
    /** Get value for emp_group_desc */
    public String getEmp_group_desc() {
        return (String)get("emp_group_desc");
    }
    /** Get value for emp_subgroup */
    public String getEmp_subgroup() {
        return (String)get("emp_subgroup");
    }
    /** Get value for emp_subgroup_desc */
    public String getEmp_subgroup_desc() {
        return (String)get("emp_subgroup_desc");
    }
    /** Get value for location_name */
    public String getLocation_name() {
        return (String)get("location_name");
    }
    /** Get value for mgnt_center */
    public String getMgnt_center() {
        return (String)get("mgnt_center");
    }
    /** Get value for mgnt_center_desc */
    public String getMgnt_center_desc() {
        return (String)get("mgnt_center_desc");
    }
    /** Get value for org_unit_lead_id */
    public int getOrg_unit_lead_id() {
        return getAsNumber("org_unit_lead_id").intValue();
    }
    /** Get value for org_unit_name */
    public String getOrg_unit_name() {
        return (String)get("org_unit_name");
    }
    /** Get value for org_unit_number */
    public int getOrg_unit_number() {
        return getAsNumber("org_unit_number").intValue();
    }

    public static Person getPersonForAmgenLogin(String amgenLogin, SQLManagerIF sqlManager, String connectionPool) {
        List<Person> persons= new RdbDataArray(Person.class, new CompareTerm("amgen_login", amgenLogin), sqlManager, null, connectionPool);
        return (persons.size()> 0? persons.get(0) : null);
    }

}
