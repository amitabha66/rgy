package amgen.ri.aig.cache.mgr;

import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.CacheManager;
import amgen.ri.aig.cache.CacheManagerFactory;
import amgen.ri.aig.cache.CacheManagerIF;
import amgen.ri.aig.cache.CacheType;
import amgen.ri.json.JSONObject;
import amgen.ri.rg.config.ConfigurationParameterInstanceType;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.util.Debug;
import java.io.ObjectStreamException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet endpoint to manage the global cache
 *
 * @version $id$
 */
@WebServlet(name = "ManageGlobalCache", urlPatterns = {"/managecache.go", "/managecache"})
public class ManageGlobalCache extends AIGServlet {
  enum ManageGlobalCacheType {
    STATS, DELETEALL, DELETEBYENTITY, DELETEEXPIRED, UNKNOWN;

    public static ManageGlobalCacheType fromString(String s) {
      if (s == null) {
        return UNKNOWN;
      }
      try {
        return ManageGlobalCacheType.valueOf(s.toUpperCase());
      } catch (Exception e) {
        return UNKNOWN;
      }
    }

    /**
     * This is necessary to permit Serializable.
     * A Serialized object containing an enum class variable is not
     * de-Serialized properly.
     * This forces de-Serialized enum to be re-created as this enum through the
     * String
     *
     * @return Object
     * @throws ObjectStreamException
     */
    public Object readResolve() throws ObjectStreamException {
      return ManageGlobalCacheType.fromString(this.toString());
    }
  }

  public ManageGlobalCache() {
    super();
  }

  public ManageGlobalCache(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  /**
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return TBXServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new ManageGlobalCache(req, resp);
  }

  /**
   *
   * @return String
   */
  protected String getServletMimeType() {
    switch (ManageGlobalCacheType.fromString(getParameter("req"))) {
      case STATS:
        return "text/json";
      default:
        return "text/xml";
    }
  }

  /**
   *
   * @throws Exception
   */
  protected void performRequest() throws Exception {
    setNoCache();
    int deleteCount = 0;
    CacheManagerIF cacheMgr= CacheManagerFactory.getOracleCacheManagerInstance(getSessionLogin().getRemoteUser());
    switch (ManageGlobalCacheType.fromString(getParameter("req"))) {
      case STATS:
        JSONObject json = new JSONObject();
        json.put("statistics", cacheMgr.getStats());
        response.getWriter().println(json);
        return;
      case DELETEALL:
        deleteCount = cacheMgr.clear();
        Debug.print("Global Service Cache Cleared");        
        break;
      case DELETEBYENTITY:
        deleteCount = cacheMgr.clear(CacheType.fromString(getParameter("type")));
        break;
    }
    response.getWriter().write("<RESPONSE><DELETED_ITEMS>" + deleteCount + "</DELETED_ITEMS></RESPONSE>");
  }
}
