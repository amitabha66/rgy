
/*
 *   Person
 *   RDBData wrapper class for RDH Person
 *   $Revision: 1.3 $
 *   Created: Jeffrey McDowell, 15 Mar 2012
 *   Modified: $Author: jemcdowe $
 *   $Log
 *
 */
package amgen.ri.aig.rdh;

import amgen.ri.ldap.ActiveDirectoryLookup;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.json.JSONObject;
import java.lang.reflect.Field;
import amgen.ri.rdb.*;

/**
 * RDBData wrapper class for RDH Person
 *
 * @version $Revision: 1.3 $
 * @author Jeffrey McDowell
 * @author $Author: jemcdowe $
 */
public class Person extends RdbData {
  protected int person_id;
  protected String first_name;
  protected String middle_name;
  protected String last_name;
  protected String familiar_name;
  protected int supervisor_person_id;
  protected int amgen_staff_id;
  protected String amgen_login;
  protected String email;
  private PersonRecordIF personRecord;

  /**
   * Default Constructor
   */
  public Person() {
    super();
  }

  /**
   * RdbData Constructor
   */
  public Person(String person_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
    this.person_id = Integer.parseInt(person_id);
  }

  /**
   * A required method which returns the primary key(s) of the table/RdbData
   * class.
   */
  @Override
  public String getIdentifier() {
    return person_id + "";
  }

  @Override
  public String getTableName() {
    return "SHRDAT.PERSON_MV";
  }

  /**
   * This method is required EXACTLY as written to allow the RdbData
   * architecture access to the class variables.
   */
  @Override
  protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
    field.set(this, value);
  }

  /**
   * This method is required EXACTLY as written to allow the RdbData
   * architecture access to the class variables.
   */
  @Override
  protected Object getFieldValue(Field field) throws IllegalAccessException {
    return field.get(this);
  }

  /**
   * Get value for person_id
   */
  public int getPerson_id() {
    return getAsNumber("person_id", false).intValue();
  }

  /**
   * Get value for first_name
   */
  public String getFirst_name() {
    return (String) get("first_name");
  }

  /**
   * Get value for middle_name
   */
  public String getMiddle_name() {
    return (String) get("middle_name");
  }

  /**
   * Get value for last_name
   */
  public String getLast_name() {
    return (String) get("last_name");
  }

  /**
   * Get value for familiar_name
   */
  public String getFamiliar_name() {
    return (String) get("familiar_name");
  }

  /**
   * Get value for supervisor_person_id
   */
  public int getSupervisor_person_id() {
    return getAsNumber("supervisor_person_id").intValue();
  }

  /**
   * Get value for amgen_staff_id
   */
  public int getAmgen_staff_id() {
    return getAsNumber("amgen_staff_id").intValue();
  }

  /**
   * Get value for amgen_login
   */
  public String getAmgen_login() {
    return (String) get("amgen_login");
  }

  /**
   * Get value for email
   */
  public String getEmail() {
    return (String) get("email");
  }

  public PersonRecordIF getPerson() {
    if (personRecord == null) {
      try {
        personRecord = new ActiveDirectoryLookup().lookup(getAmgen_login());
      } catch (Exception ex) {
        ex.printStackTrace();
      }
    }
    return personRecord;
  }

  public JSONObject getSimplePersonRecord() {
    JSONObject name = new JSONObject();
    try {
      name.putOpt("username", getAmgen_login());
      name.putOpt("name", getLast_name() + ", " + getFamiliar_name());
      name.putOpt("employee_id", getAmgen_staff_id());
    } catch (Exception e) {
      e.printStackTrace();
    }
    return name;
  }
}
