/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.item.GlobalCacheItem;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import java.util.Collection;
import java.util.List;
import javax.servlet.http.HttpSession;

/**
 *
 * @author jemcdowe
 */
public interface CacheManagerIF {

  /**
   * Removes the all cached objects from the cache
   */
  int clear();

  /**
   * Removes the all cached objects of a given type from the global cache
   */
  int clear(CacheType cacheType);

  /**
   * Returns whether the Cache contains the given key in the group and hierarchy
   *
   * @param cacheType CacheType
   * @param key String
   * @return boolean
   */
  boolean contains(CacheType cacheType, String key);

  /**
   * Returns whether the Cache contains the given key in the group and hierarchy and is of type cls
   *
   * @param cacheType CacheType
   * @param cls
   * @param key String
   * @return boolean
   */
  boolean contains(CacheType cacheType, String key, Class cls);

  /**
   * Gets a cached object from the Cache or null if the key does not exist in
   * the group and hierarchy
   *
   * @param session HttpSession
   * @param cacheType CacheType
   * @param key String
   * @return Object
   */
  Object get(CacheType cacheType, String key);


  /**
   * Returns the statistics of the Cache
   *
   * @return JCS
   */
  String getStats();


  /**
   * Puts an object into the Cache in the proper group and hierarchy
   *
   * @param cacheType CacheType
   * @param key String
   * @param obj Object
   * @return Object
   * @throws AIGException
   */
  Object put(CacheType cacheType, String key, Object obj) throws AIGException;
  
  /**
   * Puts a GlobalCacheItem into the Cache in the proper group and hierarchy
   *
   */
  Object put(CacheType cacheType, GlobalCacheItem globalCacheItem) throws AIGException;
  
  /**
   * Removes the session cache from the Cache removing all cached objects
   *
   * @param session HttpSession
   */
  void removeSessionCache(HttpSession session);


  /**
   * Removes a set of keys from the cache
   *
   * @param session HttpSession
   * @param cacheType CacheType
   * @param strings String[]
   * @return int
   */
  void remove(CacheType cacheType, Collection<String> keys);

  /**
   * Removes an object from the Cache. Does nothing if the object does not exist
   * in the group and hierarchy
   *
   * @param session HttpSession
   * @param cacheType CacheType
   * @param key String
   */
  void remove(CacheType cacheType, String key);

  /**
   * Gets a sorted List of services for the given keys
   * @param keys
   * @param nameContext
   * @return
   */
  List<ServiceDetails> getAllSortedServices(Collection<String> keys, ServiceNamingContext nameContext, boolean removeOfflineServices);


}
