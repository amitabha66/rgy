/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.store;

import amgen.ri.json.JSONObject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;

import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;

/**
 *
 * @author jemcdowe
 */
import amgen.ri.aig.entitylist.EntityList;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.CompareTerm;
import amgen.ri.rdb.NullCompareTerm;
import amgen.ri.rdb.RdbDataArray;
import java.util.List;
public class ListsStoreRequestHandler extends StoreRequestHandler {
  public ListsStoreRequestHandler(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  public ListsStoreRequestHandler() {
  }

  @Override
  public JSONObject generateJSONResponse() throws Exception {
    String listID = getParameter("list_id");
    String listCategory = getParameter("list_category");
    JSONObject jEntityLists = new JSONObject();
    if (listID != null) {
      EntityList entityList = new EntityList(listID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
      if (entityList.setData()) {
        jEntityLists.append("lists", entityList.getAsJSON(true, request));
      }
    } else if (listCategory != null) {
      CompareTerm userTerm = new CompareTerm("created_by", getSessionLogin().getRemoteUser());
      CompareTerm categoryTerm = new CompareTerm("list_category", listCategory.toUpperCase());
      CompareTerm typeTerm = new NullCompareTerm("list_type", true);

      List<EntityList> lists = new RdbDataArray(EntityList.class, new CompareTerm[]{
                userTerm, categoryTerm, typeTerm
              }, new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
      for (EntityList entityList : lists) {
        jEntityLists.append("lists", entityList.getAsJSON(false, request));
      }
    } else {
      CompareTerm userTerm = new CompareTerm("created_by", getSessionLogin().getRemoteUser());
      CompareTerm typeTerm = new NullCompareTerm("list_type", true);

      List<EntityList> lists = new RdbDataArray(EntityList.class, new CompareTerm[]{
                userTerm, typeTerm
              }, "list_category", true, new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
      for (EntityList entityList : lists) {
        jEntityLists.append("lists", entityList.getAsJSON(false, request));
      }
    }
    return jEntityLists;
  }


  @Override
  public Document generateXMLResponse() throws Exception {
    String listID = getParameter("list_id");
    String listCategory = getParameter("list_category");
    Element entityListsEl = new Element("EntityLists");
    if (listID != null) {
      EntityList entityList = new EntityList(listID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
      if (entityList.setData()) {
        entityListsEl.addContent(entityList.getAsElement(true, request));
      }
    } else if (listCategory != null) {
      CompareTerm userTerm = new CompareTerm("created_by", getSessionLogin().getRemoteUser());
      CompareTerm categoryTerm = new CompareTerm("list_category", listCategory.toUpperCase());
      CompareTerm typeTerm = new NullCompareTerm("list_type", true);

      List<EntityList> lists = new RdbDataArray(EntityList.class, new CompareTerm[]{
                userTerm, categoryTerm, typeTerm
              }, new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
      for (EntityList list : lists) {
        entityListsEl.addContent(list.getAsElement(request));
      }
    } else {
      CompareTerm userTerm = new CompareTerm("created_by", getSessionLogin().getRemoteUser());
      CompareTerm typeTerm = new NullCompareTerm("list_type", true);

      List<EntityList> lists = new RdbDataArray(EntityList.class, new CompareTerm[]{
                userTerm, typeTerm
              }, new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
      for (EntityList list : lists) {
        entityListsEl.addContent(list.getAsElement(request));
      }
    }
    return new Document(entityListsEl);
  }
}
