/*
 *   EntityListSourceService
 *   RDBData wrapper class for ENTITY_LIST_SOURCE_SERVICE
 *   $Revision: 1.3 $
 *   Created: Jeffrey McDowell, 10 Apr 2009
 *   Modified: $Author: jemcdowe $
 *   $Log
 *
 */
package amgen.ri.aig.entitylist;


import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Field;

import org.jdom.Element;
import org.jdom.input.SAXBuilder;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.rdb.ClobData;
import amgen.ri.rdb.LobSaveable;
import amgen.ri.rdb.OraSequenceField;
import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.Removeable;
import amgen.ri.rdb.SQLManagerIF;

/**
 *   RDBData wrapper class for ENTITY_LIST_SOURCE_SERVICE
 *   @version $Revision: 1.3 $
 *   @author Jeffrey McDowell
 *   @author $Author: jemcdowe $
 */
public class EntityListSourceService extends RdbData implements LobSaveable, Removeable, EntityListSourceServiceIF {
    protected OraSequenceField entity_list_source_service_id;
    protected int list_id;
    protected String service_key;
    protected ClobData parameters;

    /**
     * Default Constructor
     */
    public EntityListSourceService() {
        super();
    }

    /**
     * RdbData Constructor
     */
    public EntityListSourceService(String entity_list_source_service_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.entity_list_source_service_id = new OraSequenceField(entity_list_source_service_id);
    }

    /**
     * Constructor which sets the class variables
     */
    public EntityListSourceService(int list_id, ServiceDetails serviceDetails, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.entity_list_source_service_id = new OraSequenceField("entity_list_seq", this);
        this.list_id = list_id;
        try {
            this.parameters = ClobData.valueOf(serviceDetails.getParametersAsXML(), "parameters");
            this.service_key = serviceDetails.getKey();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return entity_list_source_service_id + "";
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }

    /** This method returns the name of the table. */
    protected String getTableName() {
        return "ENTITY_LIST_SOURCE_SERVICE";
    }

    /** Returns the SQL for INSERTing the object in the table */
    public String getInsertSQL() {
        return null;
    }

    /** Returns the SQL for UPDATing the object in the table */
    public String getUpdateSQL() {
        return null;
    }

    /** Returns the SQL for DELTEing the object/row in the table */
    public String getDeleteSQL() {
        return null;
    }

    /** Returns the SQL statement which selects for the LOB */
    public String getSelectLobSQL(String fieldName) {
        return null;
    }

    /** Returns a reader which will stream the Clob data */
    public Reader getClobReader(String fieldName) {
        if (fieldName.equals("parameters")) {
            return parameters.getClobReader();
        }
        return null;
    }

    /** Returns an inputstream which will stream the Blob data */
    public InputStream getBlobStream(String fieldName) {
        return null;
    }

    /** Get value for list_id */
    public int getList_id() {
        return getAsNumber("list_id").intValue();
    }

    /** Get value for service_key */
    public String getServiceKey() {
        return (String) get("service_key");
    }

    /** Get value for parameters */
    public ClobData getParameters() {
        return (ClobData) get("parameters");
    }

    /** Get value for parameters */
    public Element getParametersElement() {
        ClobData parameters = (ClobData) get("parameters");
        Element parametersEl = null;
        if (parameters != null) {
            try {
                Reader parametersReader = parameters.getClobReader();
                try {
                    parametersEl = new SAXBuilder().build(parametersReader).getRootElement();
                } catch (Exception ex) {
                }
                parametersReader.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return parametersEl;
    }

    /**
     * Returns the ServiceDetails for the source service
     *
     * @param serviceCache ServiceCache
     * @return ServiceDetails
     * @throws AIGException
     */
    public ServiceDetails getServiceDetails(ServiceCache serviceCache) throws AIGException {
        ServiceDetails serviceDetails = serviceCache.getService(getServiceKey());
        if (serviceDetails == null) {
            throw new AIGException("No service available for list", Reason.UNABLE_TO_SET_SERVICE);
        }
        if (getParameters() == null) {
            throw new AIGException("No service available for list", Reason.UNABLE_TO_SET_SERVICE);
        }
        serviceDetails.setParameterValues(getParametersElement());
        return serviceDetails;
    }
}
