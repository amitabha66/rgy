package amgen.ri.aig.projectview.model;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jdom.Element;

import amgen.ri.xml.ExtXMLElement;

/**
 * Holds an Available View for the project view
 */
public class ProjectViewAvailableView extends ProjectViewList {

    private Map<String, ProjectViewAssayList> assayLists;
    private Map<String, ProjectViewCompoundList> compoundLists;
    private boolean hasInvivoPK; //Whether the view has invivo PK data defined
    private String spotfireURL; //A URL to a Spotfire project document

    private boolean hasInvivoPKAuthList;


    protected ProjectViewAvailableView(Element availableViewElement) {
        super(availableViewElement.getAttributeValue("view_list_id"), availableViewElement.getAttributeValue("name"));
        hasInvivoPK= false;
        isDefault(Boolean.valueOf(availableViewElement.getAttributeValue("default")));
        hasInvivoPK= (ExtXMLElement.getXPathElements(availableViewElement, "./AssayType[@showEmpty='true']").size()> 0);
        spotfireURL= availableViewElement.getAttributeValue("project_spotfire");
        assayLists = new LinkedHashMap<String, ProjectViewAssayList>();
        List<Element> assayListEls = availableViewElement.getChildren("AssayType");
        for (Element assayListEl : assayListEls) {
            ProjectViewAssayList projectViewAssayList = new ProjectViewAssayList(assayListEl);
            assayLists.put(projectViewAssayList.getId(), projectViewAssayList);
            if (projectViewAssayList.isInvivoPKAuthList()) {
                hasInvivoPK= true;
            }
        }
        compoundLists = new LinkedHashMap<String, ProjectViewCompoundList>();
        List<Element> compoundListEls = ExtXMLElement.getXPathElements(availableViewElement, "CompoundLists/CompoundList");
        for (Element compoundListEl : compoundListEls) {
            ProjectViewCompoundList compoundList = new ProjectViewCompoundList(compoundListEl);
            compoundLists.put(compoundList.getId(), compoundList);
        }
    }

    public Set<String> getAssayListIDs() {
        return assayLists.keySet();
    }

    public Map<String, ProjectViewAssayList> getAssayLists() {
        return assayLists;
    }

    public Map<String, ProjectViewAssayList> getAssayLists(boolean notInInvivoPKAuthList) {
        if (!notInInvivoPKAuthList) {
            return getAssayLists();
        }
        Map<String, ProjectViewAssayList> assayListsNotInInvivoPKAuthList = new LinkedHashMap<String, ProjectViewAssayList>();

        for (String listID : getAssayLists().keySet()) {
            ProjectViewAssayList pvAssayList = getAssayLists().get(listID);
            if (!pvAssayList.isInvivoPKAuthList()) {
                assayListsNotInInvivoPKAuthList.put(listID, pvAssayList);
            }
        }
        return assayListsNotInInvivoPKAuthList;
    }

    public ProjectViewAssayList getAssayList(String assayListID) {
        return assayLists.get(assayListID);
    }

    public Set getCompoundListIDs() {
        return compoundLists.keySet();
    }

    public Map<String, ProjectViewCompoundList> getCompoundLists() {
        return compoundLists;
    }

    public ProjectViewCompoundList getCompoundList(String compoundListID) {
        return compoundLists.get(compoundListID);
    }

    /**
     * Returns either the default compound list or if none defined, returns the
     * first
     *
     * @return ProjectViewCompoundList
     */
    public ProjectViewCompoundList getDefaultCompoundList() {
        for (String compoundListID : compoundLists.keySet()) {
            ProjectViewCompoundList compoundList = compoundLists.get(compoundListID);
            if (compoundList.isDefault()) {
                return compoundList;
            }
        }
        if (compoundLists.size() > 0) {
            return compoundLists.get(compoundLists.keySet().iterator().next());
        }
        return null;
    }

    public boolean isHasInvivoPKAuthList() {
        return hasInvivoPKAuthList;
    }

    public String getSpotfireURL() {
        return spotfireURL;
    }

    public boolean hasInvivoPK() {
        return hasInvivoPK;
    }
}
