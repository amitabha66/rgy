package amgen.ri.aig.entitytable.loader;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.tree.TreeNodeCache;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.entitytable.loader.bioreg.BioregEntityLoader;
import amgen.ri.aig.entitytable.loader.lmr.LMREntityTableLoader;
import amgen.ri.aig.entitytable.proxy.EntityTableProxy;
import org.jdom.Element;

/**
 * Factory for instantiating a EntityTable loader
 *
 * @version $Id: EntityLoaderFactory.java,v 1.13 2015/12/18 01:01:29 jemcdowe Exp $
 */
public class EntityLoaderFactory {

  /**
   * EntityLoaderFactory- Not used
   */
  public EntityLoaderFactory() {
    super();
  }

  /**
   * Gets a EntityTableLoaderIF for getting a loader for a ResultNode
   *
   * @param requestor AIGBase
   * @param resultNodeKey String
   * @return EntityTableLoaderIF
   * @throws AIGException
   */
  public static EntityTableLoaderIF getEntityTableLoader(AIGBase requestor, String resultNodeKey) throws AIGException {
    TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(requestor.getHttpServletRequest());
    Element parentTreeNode = tnCache.getTreeNode(resultNodeKey);
    if (parentTreeNode == null) {
      throw new AIGException("No results to create a table", AIGException.Reason.NO_RESULTS);
    }
    EntityListCategory tableCategory = requestor.getEntityClassManager().convertServiceDataCategoryToEntityListCategory(ServiceDataCategory.getServiceDataCategory(parentTreeNode));
    return getEntityTableLoader(requestor, tableCategory, resultNodeKey);   
  }

  /**
   * Gets a EntityTableLoaderIF for getting a loader for a ResultNode
   *
   * @param requestor AIGBase
   * @param resultNodeKey String
   * @return EntityTableLoaderIF
   * @throws AIGException
   */
  public static EntityTableLoaderIF getEntityTableLoader(AIGBase requestor, EntityListCategory tableCategory) throws AIGException {
    return getEntityTableLoader(requestor, tableCategory, null);   
  }

  private static EntityTableLoaderIF getEntityTableLoader(AIGBase requestor, EntityListCategory tableCategory, String resultNodeKey) throws AIGException {
    switch (tableCategory) {
      case COMPOUNDS:
        return new CompoundEntityTableLoader(requestor, resultNodeKey);
      case SUBSTANCES:
        return new SubstanceEntityTableLoader(requestor, resultNodeKey);
      case PEOPLE:
        return new PersonEntityTableLoader(requestor, resultNodeKey);
      case SMR_MOLECULES:
        return new SMRMoleculeEntityTableLoader(requestor, resultNodeKey);
      case AMGEN_GENES:
        return new GeneEntityTableLoader(requestor, resultNodeKey);
      case LMR_PROTEIN_LOTS:
      case LMR_EXPRESSION_SYSTEMS:
      case LMR_CONSTRUCTS:
      case LMR_HARVESTS:
      case LMR_RECOMBINANT_SEQUENCES:
      case LMR_REQUESTS:
      case LMR_SEQUENCE_SETS:
        return new LMREntityTableLoader(requestor, tableCategory, resultNodeKey);
      case CELL_CULTURE_RUNS:
        return new CellCultureRunsTableLoader(requestor, resultNodeKey);
      case MODIFIED_LARGE_MOLECULES:
      case LARGE_MOLECULES:
        return new BioregEntityLoader(requestor, tableCategory, resultNodeKey);
      case GENOMIC_PROFILING_DATASETS:
        return new GenomicProfilingDataSetsLoader(requestor, resultNodeKey);
      case NOTEBOOKS:
      case DATES:
      case PROJECTS:
      case ASSAYS:
      case LOGICAL_ASSAYS:
      case ASSAY_TYPES:
      case LOGICAL_ASSAY_TYPES:
      case PLATES:
      case EXPERIMENTS:
      case STUDIES:
      case WATSON_STUDIES:
      case GALILEO_STUDIES:
      case ARRAY_SERVER_PROJECTS:
      default:
        return new GenericEntityTableLoader(requestor, tableCategory);
    }
  }

  /**
   * Gets a EntityTableLoaderIF for getting a loader for a EntityTableProxy
   *
   * @param requestor AIGBase
   * @param entityTableProxy EntityTableProxy
   * @return EntityTableLoaderIF
   */
  public static EntityTableLoaderIF getEntityTableLoader(AIGBase requestor, EntityTableProxy entityTableProxy) {
    return new EntityTableProxyLoader(requestor, entityTableProxy);
  }
}
