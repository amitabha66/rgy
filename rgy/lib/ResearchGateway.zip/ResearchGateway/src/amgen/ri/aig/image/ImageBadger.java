/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.image;

import amgen.ri.util.Debug;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.Point;
import java.awt.Transparency;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URISyntaxException;
import java.net.URL;
import javax.imageio.ImageIO;
import sun.awt.image.BufferedImageGraphicsConfig;

/**
 *
 * @author jemcdowe
 */
public class ImageBadger {
  public enum BadgeLocation {
    UPPER_RIGHT, UPPER_LEFT, LOWER_RIGHT, LOWER_LEFT, MIDDLE_RIGHT, MIDDLE_LEFT, MIDDLE, UPPER_MIDDLE, LOWER_MIDDLE;
    
    public static BadgeLocation fromString(String s) {
      try {
        return valueOf(s.toUpperCase());
      } catch(Exception e) {
        return UPPER_LEFT;
      }
    }
  };
  private InputStream baseImageStream;
  private InputStream badgeImageStream;

  public ImageBadger(File baseImageFile, File badgeImageFile) throws IOException {
    this(baseImageFile.toURI().toURL().openStream(), badgeImageFile.toURI().toURL().openStream());
  }

  public ImageBadger(URL baseImageURL, URL badgeImageURL) throws IOException {
    this(baseImageURL.openStream(), badgeImageURL.openStream());
  }

  public ImageBadger(InputStream baseImageStream, InputStream badgeImageStream) {
    this.baseImageStream = baseImageStream;
    this.badgeImageStream = badgeImageStream;
  }

  public void badge(BadgeLocation badgeLocation, OutputStream badgedImageStream) throws IOException {
    BufferedImage baseImg = ImageIO.read(baseImageStream);
    BufferedImage iconImg = ImageIO.read(badgeImageStream);

    Dimension baseDim = new Dimension(baseImg.getWidth(), baseImg.getHeight());
    Dimension iconDim = new Dimension(iconImg.getWidth(), iconImg.getHeight());

    Dimension canvasDim = new Dimension();

    Point basePos = new Point();
    Point iconPos = new Point();

    switch (badgeLocation) {
      case UPPER_RIGHT:
        basePos.setLocation(0, 0);
        iconPos.setLocation(baseDim.getWidth() - 0.5 * iconDim.getWidth(), 1);
        canvasDim.setSize(baseDim.getWidth() + 0.5 * iconDim.getWidth(), baseDim.getHeight());
        break;
      case UPPER_LEFT:
        basePos.setLocation(0.5 * iconDim.getWidth(), 0);
        iconPos.setLocation(0, 1);
        canvasDim.setSize(baseDim.getWidth() + 0.5 * iconDim.getWidth(), baseDim.getHeight());
        break;
      case LOWER_RIGHT:
        basePos.setLocation(0, 0);
        iconPos.setLocation(baseDim.getWidth() - 0.5 * iconDim.getWidth(), baseDim.getHeight() - (iconDim.getHeight() + 1));
        canvasDim.setSize(baseDim.getWidth() + 0.5 * iconDim.getWidth(), baseDim.getHeight());
        break;
      case LOWER_LEFT:
        basePos.setLocation(0.5 * iconDim.getWidth(), 0);
        iconPos.setLocation(0, baseDim.getHeight() - (iconDim.getHeight() + 1));
        canvasDim.setSize(baseDim.getWidth() + 0.5 * iconDim.getWidth(), baseDim.getHeight());
        break;
      case MIDDLE_LEFT:
        basePos.setLocation(0.5 * iconDim.getWidth(), 0);
        iconPos.setLocation(0, 0.5 * (baseDim.getHeight() - iconDim.getHeight()));
        canvasDim.setSize(baseDim.getWidth() + 0.5 * iconDim.getWidth(), baseDim.getHeight());
        break;
      case MIDDLE_RIGHT:
        basePos.setLocation(0, 0);
        iconPos.setLocation(baseDim.getWidth() - 0.5 * iconDim.getWidth(), 0.5 * (baseDim.getHeight() - iconDim.getHeight()));
        canvasDim.setSize(baseDim.getWidth() + 0.5 * iconDim.getWidth(), baseDim.getHeight());
        break;
      case MIDDLE:
        basePos.setLocation(0, 0);
        iconPos.setLocation(0.5 * (baseDim.getWidth() - iconDim.getWidth()), 0.5 * (baseDim.getHeight() - iconDim.getHeight()));
        canvasDim.setSize(baseDim.getWidth(), baseDim.getHeight());
        break;
      case UPPER_MIDDLE:
        basePos.setLocation(0, 0.5 * iconDim.getHeight());
        iconPos.setLocation(0.5 * (baseDim.getWidth() - iconDim.getWidth()), 0);
        canvasDim.setSize(baseDim.getWidth(), baseDim.getHeight() + 0.5 * iconDim.getHeight());
        break;
      case LOWER_MIDDLE:
        basePos.setLocation(0, 0);
        iconPos.setLocation(0.5 * (baseDim.getWidth() - iconDim.getWidth()), baseDim.getHeight() - 0.5 * iconDim.getHeight());
        canvasDim.setSize(baseDim.getWidth(), baseDim.getHeight() + 0.5 * iconDim.getHeight());
        break;
    }

    GraphicsConfiguration gc = BufferedImageGraphicsConfig.getConfig(baseImg);
    BufferedImage scaledImage = gc.createCompatibleImage((int) Math.ceil(canvasDim.getWidth()), (int) Math.ceil(canvasDim.getHeight()), Transparency.TRANSLUCENT);
    Graphics2D g2 = scaledImage.createGraphics();
    g2.drawImage(baseImg, (int) Math.ceil(basePos.getX()), (int) Math.ceil(basePos.getY()), baseImg.getWidth(), baseImg.getHeight(), null);
    g2.drawImage(iconImg, (int) Math.ceil(iconPos.getX()), (int) Math.ceil(iconPos.getY()), iconImg.getWidth(), iconImg.getHeight(), null);
    g2.dispose();
    ImageIO.write(scaledImage, "png", badgedImageStream);
  }


public void overlay(OutputStream out) throws IOException {
    /*
    GraphicsConfiguration gc = BufferedImageGraphicsConfig.getConfig(baseImg);
    BufferedImage scaledImage = gc.createCompatibleImage((int) Math.ceil(canvasDim.getWidth()), (int) Math.ceil(canvasDim.getHeight()), Transparency.TRANSLUCENT);
    Graphics2D g2 = scaledImage.createGraphics();
    g2.drawImage(baseImg, (int) Math.ceil(basePos.getX()), (int) Math.ceil(basePos.getY()), baseImg.getWidth(), baseImg.getHeight(), null);
    g2.drawImage(iconImg, (int) Math.ceil(iconPos.getX()), (int) Math.ceil(iconPos.getY()), iconImg.getWidth(), iconImg.getHeight(), null);
    g2.dispose();
    ImageIO.write(scaledImage, "png", badgedImageStream);
     */
  }
  
  

  public static void main(String[] args) throws Exception {
    File base = new File("C:/Development/JProjects2/ResearchGateway/WebContent/img/default_entitylist.gif");
    File badge = new File("C:/Development/JProjects2/ResearchGateway/WebContent/img/compound.gif");
    for (BadgeLocation loc : BadgeLocation.values()) {
      File out = new File("C:/temp/badged_"+loc+".png");
      new ImageBadger(base, badge).badge(loc, new FileOutputStream(out));
    }
  }
  
}
