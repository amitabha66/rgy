package amgen.ri.aig.category.schema2;

import java.io.ObjectStreamException;
import java.util.ArrayList;
import java.util.List;
import org.jdom.Element;

/**
 * Node type enumeration
 */
public enum ServiceDataCategory {
  //ACRF
  AMGEN_ROOT_ID,
  AMGEN_COMPOUND_ID,
  AMGEN_NAME,
  AMGEN_IDENTIFIER,
  AMGEN_SUBSTANCE_ID,
  //SMR Compounds
  SMR_STRUCTURE_ID,
  SMR_MOLECULE_ID,
  SMR_COMPONENT_ID,
  //Structure
  MOL,
  //LMR
  AMGEN_LM_ROOT_ID,
  AMGEN_LM_SUBSTANCE_ID,
  LMR_PROTEIN_LOT_ID,
  LMR_EXPR_SYSTEM_ID,
  LMR_CONSTRUCT_ID,
  LMR_SEQUENCE_ID,
  LMR_SEQUENCE_SET_ID,
  LMR_HARVEST_ID,
  LMR_REQUEST_ID,
  //ASSAY Identifiers
  ASSAY_IDENTIFIER,
  LOGICAL_ASSAY_IDENTIFIER,
  ASSAY_TYPE,
  LOGICAL_ASSAY_TYPE,
  SCREENER_CURVE,
  ADW_CURVE,
  //Other Experimental Results
  AMES_MUTAGENIC_RESULT,
  //Experiment,Plate Identifiers
  EXPERIMENT_IDENTIFIER,
  PLATE_IDENTIFIER,
  MOSAIC_BARCODE,
  //PK,ADME
  STUDY_IDENTIFIER,
  WATSON_STUDY_IDENTIFIER,
  GALILEO_STUDY_IDENTIFIER,
  WATSON_PK_STUDY_IDENTIFIER,
  WATSON_TK_STUDY_IDENTIFIER,
  WATSON_PD_STUDY_IDENTIFIER,
  
  STUDY_LOG_STUDY_IDENTIFIER,
  
  //Project
  PROJECT,
  DATA_ANALYSIS,
  //Target
  AMGEN_DRUG_TARGET_IDENTIFIER,
  //People, Site, Security
  AMGEN_LOGIN,
  AMGEN_SESSION_LOGIN_FASF_ENCRYPTED,
  AMGEN_SESSION_LOGIN,
  SESSION_IDENTIFIER,
  AMGEN_SITE,
  //Document, Folder
  DOCUMENT,
  DOCUMENT_QUERY,
  FOLDER,
  //Genes, Nuc Seqs, Proteins
  AMGEN_GENE_IDENTIFIER,
  ENTREZGENE_IDENTIFIER,
  GENE_TEXT_QUERY,
  SECRETED_PROTEIN_IDENTIFIER,
  SQUID_NUCLEOTIDE_SEQUENCE_IDENTIFIER,
  SQUID_PROTEIN_SEQUENCE_IDENTIFIER,
  PROTEIN_ACCESSION_NUMBER,
  NUCLEOTIDE_ACCESSION_NUMBER,
  PATHWAY_IDENTIFIER,
  RNAI_IDENTIFIER,
  //OMICs experiment identifiers
  OMICS_PROJECT_IDENTIFIER,
  OMICS_DATASET_IDENTIFIER,
  OMICS_SAMPLESET_IDENTIFIER,
  OMICS_SAMPLE_IDENTIFIER,
  //RNAi experiment identifiers
  RNAI_EXPERIMENT_IDENTIFIER,
  //Notebooks
  NOTEBOOK_IDENTIFIER,
  //Dates
  DATE,
  DATE_RANGE,
  //Cell Culture
  CONSTRUCT_IDENTIFIER,
  CONSTRUCT_LOT_IDENTIFIER,
  CONSTRUCT_STUDY_IDENTIFIER,
  CELL_CULTURE_RUN_IDENTIFIER,
  //CAST
  CAST_EXPERIMENT_IDENTIFIER,
  //RG Specific
  RG_TABLECELL_DETAILS,
  //Array Server
  ARRAY_SERVER_PROJECT_IDENTIFIER,
  //Tivo Dataset identifier
  GENOMIC_PROFILING_DATASET_IDENTIFIER,
  //PSilo Structures
  PSILO_IDENTIFIER,
  PROTEIN_SEQUENCE_IDENTITY_IDENTIFIER,
  //XMR Types
  BIOREG_LOT_NAME,
  BIOREG_NAME,
  //Other
  UNKNOWN;
  static final long serialVersionUID = -1236177977570606307L;

  /**
   * Returns the ServiceDataCategory by converting a String- this includes
   * converting to upper case and replacing space with underscores
   *
   * @param s String
   * @return ServiceDataCategory
   */
  public static ServiceDataCategory fromString(String s) {
    if (s == null) {
      return UNKNOWN;
    }
    try {
      return ServiceDataCategory.valueOf(s.toUpperCase().replace(' ', '_'));
    } catch (Exception e) {
      return UNKNOWN;
    }
  }

  /**
   * Returns the ServiceDataCategory by converting a String- this includes
   * converting to upper case and replacing space with underscores
   *
   * @param s String
   * @return ServiceDataCategory
   */
  public static List<ServiceDataCategory> fromString(List<String> s) {
    List<ServiceDataCategory> categories = new ArrayList<ServiceDataCategory>();
    if (s == null) {
      return categories;
    }
    for (String category : s) {
      categories.add(fromString(category));
    }
    return categories;
  }

  /**
   * Returns whether the ServiceDataCategory and the String match when the
   * String is converted to a ServiceDataCategory enum. If either are null, this
   * returns false
   *
   * @param category ServiceDataCategory
   * @param s String
   * @return ServiceDataCategory
   */
  public static boolean matches(ServiceDataCategory category, String s) {
    if (category == null || s == null) {
      return false;
    }
    ServiceDataCategory category2 = ServiceDataCategory.fromString(s);
    return category.equals(category2);
  }

  /**
   * Returns the category as defined in the "Service Input Categorization
   * Scheme" from this ServiceDataCategory
   *
   * @return String
   */
  public String revertTo() {
    return revertTo(this);
  }

  /**
   * Returns the category as defined in the "Service Input Categorization
   * Scheme" from the ServiceDataCategory. This method ensures proper formating
   * when used in a UDDI query
   *
   * @param serviceDataCategory String
   * @return String
   */
  public static String revertTo(String serviceDataCategory) {
    return revertTo(fromString(serviceDataCategory));
  }

  /**
   * Returns the category as defined in the "Service Input Categorization
   * Scheme" from the ServiceDataCategory
   *
   * @param s String
   * @return String
   */
  public static String revertTo(ServiceDataCategory serviceDataCategory) {
    switch (serviceDataCategory) {
      case UNKNOWN:
        return serviceDataCategory.toString();
    }
    String[] words = serviceDataCategory.toString().split("_");
    StringBuffer sb = new StringBuffer();
    for (String word : words) {
      if (word.length() > 1) {
        if (word.equalsIgnoreCase("cast")) {
          word = word.toUpperCase();
        } else if (word.equalsIgnoreCase("id")) {
          word = word.toUpperCase();
        } else if (word.equalsIgnoreCase("rnai")) {
          word = word.toUpperCase();
        } else {
          word = Character.toUpperCase(word.charAt(0)) + word.substring(1).toLowerCase();
        }
      } else if (word.length() > 0) {
        word = word.toUpperCase();
      }
      sb.append((sb.length() > 0 ? " " : "") + word);
    }
    return sb.toString();
  }

  /**
   * Returns the list of categories as defined in the "Service Input
   * Categorization Scheme" from the ServiceDataCategory
   *
   * @param s List<ServiceDataCategory>
   * @return List<String>
   */
  public static List<String> revertTo(List<ServiceDataCategory> serviceDataCategories) {
    List<String> serviceDataCategoryNames = new ArrayList<String>();
    for (ServiceDataCategory serviceDataCategory : serviceDataCategories) {
      serviceDataCategoryNames.add(revertTo(serviceDataCategory));
    }

    return serviceDataCategoryNames;
  }

  /**
   * Returns whether the TreeNode is of the type provided
   *
   * @param treeNode Element
   * @param nodeType NodeType
   * @return boolean
   */
  public static boolean isServiceDataCategory(Element treeNode, ServiceDataCategory nodeType) {
    return getServiceDataCategory(treeNode).equals(nodeType);
  }

  /**
   * Returns the ServiceDataCategory defined in the TreeNode or UNKNOWN if there
   * is none defined
   *
   * @param treeNode Element
   * @return NodeType
   */
  public static ServiceDataCategory getServiceDataCategory(Element treeNode) {
    if (treeNode == null) {
      return ServiceDataCategory.UNKNOWN;
    }
    return (treeNode.getAttributeValue("SERVICE_DATA_TYPE_CATEGORY") != null ? ServiceDataCategory.fromString(treeNode.getAttributeValue("SERVICE_DATA_TYPE_CATEGORY")) : UNKNOWN);

  }

  /**
   * This is necessary to permit Serializable. A Serialized object containing an
   * enum class variable is not de-Serialized properly. This forces
   * de-Serialized enum to be re-created as this enum through the String
   *
   * @return Object
   * @throws ObjectStreamException
   */
  public Object readResolve() throws ObjectStreamException {
    return ServiceDataCategory.fromString(this.toString());
  }
}
