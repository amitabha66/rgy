package amgen.ri.aig.preferences;

/**
 * <p>@version $Id: PreferenceIF.java,v 1.3 2012/01/03 21:53:09 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public interface PreferenceIF {
    /**
     * Returns the Preference name
     * @return String
     */
    public String getPreferenceName();

    /**
     * Returns the Preference Value
     * @return Object
     */
    public Object getPreferenceValue();

    /**
     * Returns the Preference Value
     * @return Object
     */
    public boolean getPreferenceBooleanValue();
    
    /**
     * Is the current value the default value
     * @return 
     */
    public boolean isDefault();

  String getPreferenceData();

}
