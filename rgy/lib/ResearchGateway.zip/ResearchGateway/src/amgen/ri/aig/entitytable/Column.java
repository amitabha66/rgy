package amgen.ri.aig.entitytable;

import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.entitytable.category.schema2.ColumnType;
import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.Map;
import java.util.UUID;
import org.jdom.Element;

/**
 * 
 * @author not attributable
 * @version 1.0
 */
public class Column implements Serializable {
	static final long serialVersionUID = 3758208190253715282L;

	public static final int DEFAULT_WIDTH = 100;

	private String header;
	private EntityTableDataType columnDataType;
	private String dataIndex;
	private String defaultImageURL;
	private String linkoutTemplateURL;
	private boolean imageResizable;
	private ColumnType columnMetaType;
	private Map<String, Object> attributes;
	private int width = DEFAULT_WIDTH;
	private boolean hidden;

	private String drillDownServiceKey = null;
	private ServiceDataCategory serviceDataCategoryV2;
	private String serviceData;
	private Integer resultCount;
	private ColumnFormat columnFormat;

	private JSONObject calculatedColumnConfig; // Javascript source for a
	// calculated column
	transient private JSONObject sourceConfig;

	private String sourceType;

	/*
	 * Deprecated class variables. These are here only for serializablility of
	 * older classes
	 */
	private String type;
	private String formatSpecifier;
	private amgen.ri.aig.entitytable.ColumnType columnType; // Type of column- This is a hold-over enum using v1.2 serialization!!!
	private amgen.ri.aig.entitytable.EntityTableDataType dataType;// Data type of column- This is a hold-over enum using v1.2 serialization!!!
	private amgen.ri.aig.category.ServiceDataCategory serviceDataCategory;// ServiceDataCategory type of column- This is a hold-over enum using v1.2 serialization!!!


	public Column(String header) {
		this(header, null, null, DEFAULT_WIDTH);
	}

	public Column(String header, int width) {
		this(header, null, null, width);
	}

	public Column(String header, EntityTableDataType dataType) {
		this(header, dataType, null, DEFAULT_WIDTH);
	}

	public Column(String header, EntityTableDataType dataType, ColumnType columnType) {
		this(header, dataType, columnType, DEFAULT_WIDTH);
	}

	public Column(Column source) {
		this(source.header, source.columnDataType, source.width);
		this.serviceDataCategoryV2 = source.serviceDataCategoryV2;
		this.serviceData = source.serviceData;
		this.drillDownServiceKey = source.drillDownServiceKey;
		this.hidden = source.hidden;
		this.columnFormat = source.columnFormat;
	}

	public void update(Column source) {
		if (source != null) {
			this.header = source.header;
			this.columnDataType = source.columnDataType;
			this.dataIndex = source.dataIndex;
			this.defaultImageURL = source.defaultImageURL;
			this.imageResizable = source.imageResizable;
			this.columnMetaType = source.columnMetaType;
			this.attributes = source.attributes;
			this.width = source.width;
			this.hidden = source.hidden;
			this.drillDownServiceKey = source.drillDownServiceKey;
			this.serviceDataCategoryV2 = source.serviceDataCategoryV2;
			this.serviceData = source.serviceData;
			this.resultCount = source.resultCount;
			this.columnFormat = source.columnFormat;
		}
	}

	public Column(Element columnEl, int width) {
		this(columnEl.getAttributeValue("header"), EntityTableDataType.fromString(columnEl.getAttributeValue("type")), width);
		serviceDataCategoryV2 = serviceDataCategoryV2.fromString(columnEl.getAttributeValue("SERVICE_DATA_TYPE_CATEGORY"));
		serviceData = columnEl.getAttributeValue("SERVICE_DATA");
		drillDownServiceKey = columnEl.getAttributeValue("RELATED_SERVICE_KEY");
		linkoutTemplateURL = columnEl.getAttributeValue("linkoutTemplate");
	}

	public Column(String header, EntityTableDataType dataType, int width) {
		this(header, dataType, ColumnType.GENERAL, width);
	}

	public Column(String header, EntityTableDataType dataType, ColumnType columnType, int width) {
		this.header = header;
		this.hidden = false;
		this.columnFormat = null;
		this.dataIndex = UUID.randomUUID().toString();
		this.columnDataType = (dataType == null ? EntityTableDataType.TEXT : dataType);
		this.columnMetaType = (columnType == null ? ColumnType.GENERAL : columnType);
		this.sourceType = (sourceType == null ? "unknown" : sourceType.toLowerCase());
		this.width = width;
		serviceDataCategoryV2 = ServiceDataCategory.UNKNOWN;
	}

	public void addAttribute(String attrName, String attrValue) {
		attributes.put(attrName, attrValue);
	}

	public String getDataIndex() {
		return dataIndex;
	}

	/**
	 * Gets the EntityTableDataType for the column
	 * 
	 * @return EntityTableDataType
	 */
	public EntityTableDataType getDataType() {
		return columnDataType;
	}

	/**
	 * Sets the EntityTableDataType for the column
	 * 
	 * @param dataType EntityTableDataType
	 */
	public void setDataType(EntityTableDataType dataType) {
		this.columnDataType = dataType;
	}

	public String getHeaderText() {
		return header;
	}

	/**
	 * Sets the text of the column header
	 * 
	 * @param header String
	 */
	public void setHeaderText(String header) {
		if (header != null) {
			this.header = header;
			if (calculatedColumnConfig != null) {
				try {
					calculatedColumnConfig.put("header", header);
				} catch (JSONException ex) {
				}
			}
		}
	}

	public int getWidth() {
		return width;
	}

	public String getDrillDownServiceKey() {
		return drillDownServiceKey;
	}

	public ServiceDataCategory getServiceDataCategory() {
		return serviceDataCategoryV2;
	}

	public String getServiceData() {
		return serviceData;
	}

	public void setDrillDownServiceKey(String drillDownServiceKey) {
		this.drillDownServiceKey = drillDownServiceKey;
	}

	public void setServiceDataCategory(ServiceDataCategory serviceDataCategory) {
		this.serviceDataCategoryV2 = serviceDataCategory;
	}

	public void setServiceData(String serviceData) {
		this.serviceData = serviceData;
	}

	public void setSourceConfig(JSONObject sourceConfig) {
		this.sourceConfig = sourceConfig;
	}

	public JSONObject getSourceConfig(JSONObject sourceConfig) {
		return sourceConfig;
	}

	public void setResultCount(int resultCount) {
		this.resultCount = resultCount;
	}

	public int getResultCount() {
		return resultCount;
	}

	/**
	 * getJSON
	 * 
	 * @return boolean
	 */
	public JSONObject getJSON() throws JSONException {
		JSONObject columnJSON = new JSONObject();
		columnJSON.put("header", header);
		if (header != null && header.length() > 15) {
			columnJSON.put("tooltip", header);
		}
		columnJSON.put("dataIndex", dataIndex);
		columnJSON.put("width", width);
		columnJSON.put("hidden", hidden);
		if (columnFormat != null) {
			columnJSON.put("format", columnFormat.getJSON());
		}
		if (linkoutTemplateURL != null) {
			columnJSON.put("linkout_template", linkoutTemplateURL);
		}
		columnJSON.put("type", columnDataType.toString().toLowerCase());
		columnJSON.put("columnType", columnMetaType.toString().toLowerCase());
		if (sourceConfig != null) {
			columnJSON.put("source", sourceConfig);
		}
		if (resultCount != null && resultCount >= 0) {
			columnJSON.put("resultCount", resultCount.intValue());
		}
		switch (columnMetaType) {
		case CALCULATED:
			columnJSON.put("can_refresh", true);
			break;
		case EDITABLE:
			columnJSON.put("editable", true);
			break;
		case GENERAL:
		default:
			columnJSON.put("editable", false);
			columnJSON.addIfNotNull("drillDownServiceKey", getDrillDownServiceKey());
		}
		return columnJSON;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public void setCalculatedColumnConfig(JSONObject calculatedColumnConfig) {
		this.calculatedColumnConfig = calculatedColumnConfig;
	}

	public void setHidden(boolean hidden) {
		this.hidden = hidden;
	}

	public void setColumnFormat(ColumnFormat formatSpecifier) {
		this.columnFormat = formatSpecifier;
	}

	public void setDefaultImageURL(String defaultImageURL) {
		this.defaultImageURL = defaultImageURL;
	}

	public void setImageResizable(boolean imageResizable) {
		this.imageResizable = imageResizable;
	}

	public void setLinkoutTemplateURL(String linkoutTemplateURL) {
		this.linkoutTemplateURL = linkoutTemplateURL;
	}

	public ColumnType getColumnType() {
		return columnMetaType;
	}

	public JSONObject getCalculatedColumnConfig() {
		return calculatedColumnConfig;
	}

	public boolean isHidden() {
		return hidden;
	}

	public ColumnFormat getColumnFormat() {
		return columnFormat;
	}

	public String getDefaultImageURL() {
		return defaultImageURL;
	}

	public boolean getImageResizable() {
		return imageResizable;
	}

	public String getLinkoutTemplateURL() {
		return linkoutTemplateURL;
	}

	public boolean equals(Object obj) {
		if (obj instanceof Column) {
			return ((Column) obj).dataIndex.equals(dataIndex);
		}
		return false;
	}

	/**
	 * Overrides to the Serialization. Most are due to changes which require
	 * some evolution or transients requiring initialization
	 * 
	 * @return Object
	 * @throws ObjectStreamException
	 */
	public Object readResolve() throws ObjectStreamException {
		init();
		return this;
	}

	/**
	 * Method called by readResolve for initializing any transient class
	 * variables or evolving any class variable changes
	 */
	private void init() {
		if (columnDataType == null && type != null) {
			columnDataType = EntityTableDataType.fromString(type);
		}
		if (sourceType != null && sourceType.equals("compound")) {
			columnDataType = EntityTableDataType.STRUCTURE;
		}
		if (columnDataType == null && dataType != null) {
			columnDataType = EntityTableDataType.fromString(dataType.toString());
		}

		if (columnType != null && columnMetaType == null) {
			columnMetaType = ColumnType.fromString(columnType.toString());
		}
		if (columnMetaType == null) {
			columnMetaType = ColumnType.GENERAL;
		}
		if (resultCount == null) {
			resultCount = -1;
		}
	}

}
