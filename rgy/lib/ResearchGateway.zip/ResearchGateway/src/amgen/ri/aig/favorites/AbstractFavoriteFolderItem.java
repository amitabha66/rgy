package amgen.ri.aig.favorites;

import java.lang.reflect.Field;
import java.sql.ResultSet;

import amgen.ri.aig.sql.RGSQLProvider;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.Removeable;
import amgen.ri.rdb.SQLManagerIF;
import amgen.ri.rdb.Saveable;

/**
 * <p>@version $Id: AbstractFavoriteFolderItem.java,v 1.4 2012/03/30 22:40:29 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public abstract class AbstractFavoriteFolderItem extends RdbData implements Saveable, Removeable, FavoriteFolderItemIF {
    public AbstractFavoriteFolderItem() {
        super();
    }

    /**
     * RdbData Constructor
     */
    public AbstractFavoriteFolderItem(SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
    }


    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }

    /** Returns the SQL for INSERTing the object in the table */
    public String getInsertSQL() {
        return null;
    }

    /** Returns the SQL for UPDATing the object in the table */
    public String getUpdateSQL() {
        return null;
    }

    /** Returns the SQL for DELTEing the object/row in the table */
    public String getDeleteSQL() {
        return null;
    }

    /** Returns the child level of this FavoriteFolderItemIF in the given parent folder
     * 0  - This FavoriteFolderItemIF is not in the parentFolder hierarchy
     * 1  - This FavoriteFolderItemIF is the same object as parentFolder
     * 2  - This FavoriteFolderItemIF is an immediate child of parentFolder
     * >3 - This FavoriteFolderItemIF is a deeper child in the parentFolder hierarchy
     */
    public int getChildLevelOf(FavoriteFolder parentFolder) {
        RGSQLProvider sqlProvider = new RGSQLProvider();
        OraSQLManager sqlManager = (OraSQLManager) getSQLManager();

        ResultSet rset = null;
        try {
            rset = sqlManager.executeQuery(sqlProvider.getSQLQuery("child_folder_item_hierarchy_level"),
              new String[] {
                "folder_id:" + getIdentifier(),
                "parent_folder_id:" + parentFolder.getFolderID()
              }, getConnectionPool());
            if (rset.next()) {
                return rset.getInt("HIERARCHY_LEVEL");
            }
        } catch(Exception e) {
        } finally {
            OraSQLManager.closeResources(rset);
        }
        return 0;
    }

}
