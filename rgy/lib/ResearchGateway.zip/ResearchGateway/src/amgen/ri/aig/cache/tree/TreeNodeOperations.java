package amgen.ri.aig.cache.tree;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.AIGResponseMessage;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.item.EntityTableCacheItem;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.entitylist.EntityIF;
import amgen.ri.aig.entitylist.EntityList;
import amgen.ri.aig.entitylist.EntityListMemberIF;
import amgen.ri.aig.entitylist.GenericEntityListMember;
import amgen.ri.aig.entitytable.*;
import amgen.ri.aig.entitytable.loader.EntityLoaderFactory;
import amgen.ri.aig.entitytable.loader.EntityTableLoaderIF;
import amgen.ri.aig.sv.EntityListLoader;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtObject;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.XMLOutputter;

/**
 * @version $Id: TreeNodeOperations.java,v 1.1 2014/07/08 15:51:47 jemcdowe Exp $
 */
@WebServlet(name = "TreeNodeOperation", urlPatterns = {"/treenodeoperation.go", "/treenodeoperation", "/treenodeoperations.go", "/treenodeoperations"})
public class TreeNodeOperations extends AIGServlet {
  private enum TreeNodeOperation {
    DELETENODE,
    SAVELIST,
    UPDATELIST,
    REFRESHLIST,
    ADDTOLIST,
    DELETELIST,
    COPYLIST,
    UNION,
    INTERSECTION,
    DIFFERENCE,
    XOR,
    CREATESUBRESULT,
    CREATESUBTABLE,
    UNKNOWN;

    public static TreeNodeOperation getValue(String s) {
      if (s == null) {
        return UNKNOWN;
      }
      return TreeNodeOperation.valueOf(s.toUpperCase());
    }

    public static TreeNodeOperation getValue(AIGServlet servlet) {
      return TreeNodeOperation.getValue(servlet.getParameter("op"));
    }
  };

  public TreeNodeOperations() {
    super();
  }

  public TreeNodeOperations(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  /**
   * Creates this AIG Servlet object
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return AIGServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new TreeNodeOperations(req, resp);
  }

  /**
   * Handles the servlet request
   *
   * @throws ServletException
   * @throws IOException
   */
  public void performRequest() throws ServletException, IOException {
    response.setContentType(getServletMimeType());
    try {
      String listID = getParameter("list_id");
      String treenodeUUID1 = getParameter("uuid1");
      String treenodeUUID2 = getParameter("uuid2");
      List<String> UUIDs = getParameters("uuids", ",");
      switch (TreeNodeOperation.getValue(this)) {
        case CREATESUBTABLE:
          try {
          EntityTableCacheItem entityTableCacheItem = ServiceCache.getServiceCache(request).getEntityTableResult(getParameter("entityTableKey"));
          if (entityTableCacheItem != null && entityTableCacheItem.getEntityTable() != null) {
            List<String> includeEntityIDs= getJSONObjectParameter("include_entity_ids").getJSONArray("entity_ids").asList();
            createSubtable(entityTableCacheItem.getEntityTable(), includeEntityIDs, getParameter("name"));
          }
          } catch(Exception e) {
            e.printStackTrace();
            throw new AIGException(Reason.UNKNOWN, e);
          }
          break;
        case DELETENODE:
          TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(request);
          tnCache.removeTreeNode(getParameter("uuid"));
          break;
        case SAVELIST:
          saveTreeNodeList();
          break;
        case UPDATELIST:
          updateList();
          break;
        case REFRESHLIST:
          refreshList();
          break;
        case ADDTOLIST:
          addToTreeNodeList();
          break;
        case DELETELIST:
          if (listID != null) {
            EntityList entityList = new EntityList(listID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
            if (entityList.setData()) {
              entityList.performDelete();
            }
          }
          break;
        case COPYLIST:
          if (listID != null) {
            EntityList entityList = EntityList.createCopy(listID, getSessionLogin().getRemoteUser());
            if (!entityList.isEmpty()) {
              if (entityList.performCommitAll(getSessionLogin().getRemoteUser()) == 0) {
                entityList = null;
              }
            }
            Element newEntityListsEl = new Element("EntityLists");
            if (entityList != null) {
              newEntityListsEl.addContent(entityList.getAsElement(request));
            }
            new XMLOutputter().output(newEntityListsEl, response.getWriter());
          }
          break;
        case UNION:
        case INTERSECTION:
        case DIFFERENCE:
        case XOR:
          if (ExtString.hasTrimmedLength(listID) && ExtString.hasTrimmedLength(treenodeUUID2)) {
            createResultByCombiningListTreeNode(treenodeUUID2, listID);
          } else if (ExtString.hasTrimmedLength(treenodeUUID1) && ExtString.hasTrimmedLength(treenodeUUID2)) {
            createResultByCombining(treenodeUUID1, treenodeUUID2);
          } else {
            performListOperation();
          }
          break;
        case CREATESUBRESULT:
          if (treenodeUUID1 != null && ExtArray.hasLength(UUIDs)) {
            createResultBySubResult(treenodeUUID1, UUIDs);
          }
          break;
        default:
          break;
      }
    } catch (AIGException e) {
      AIGResponseMessage.writeErrorElement("TreeNodeOperation", "Operation Failed", e.getMessage(), response);
      log("TreeNodeOps", e);
      throw new ServletException(e);
    }
  }

  /**
   * Saves a TreeNodeList as an EntityList
   *
   * @throws IOException
   */
  private void saveTreeNodeList() throws IOException, AIGException {
    TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(request);
    ServiceCache serviceCache = ServiceCache.getServiceCache(request);
    String treeNodeUUID = getParameter("uuid");
    String entityListName = getParameter("name");
    String entityListDescription = getParameter("description");
    Element saveNode = tnCache.getTreeNode(treeNodeUUID);
    ServiceDetails serviceDetails = null;
    if (serviceCache.getServiceResult(treeNodeUUID) != null) {
      serviceDetails = serviceCache.getServiceResult(treeNodeUUID).getServiceDetails();
    }
    EntityList entityList = null;
    if (saveNode != null && (NodeType.isNodeType(saveNode, NodeType.RESULTNODE) || NodeType.isNodeType(saveNode, NodeType.SERVICENODE))) {
      List<String> childUUIDs = tnCache.getChildTreeNodeKeys(treeNodeUUID);
      if (childUUIDs.size() > 0) {
        Element firstChildNode = tnCache.getTreeNode(childUUIDs.get(0));
        ServiceDataCategory listDataCategory = ServiceDataCategory.getServiceDataCategory(firstChildNode);
        if (!listDataCategory.equals(ServiceDataCategory.UNKNOWN)) {
          entityList = new EntityList(entityListName, entityListDescription, listDataCategory, getSessionLogin().getRemoteUser(), serviceDetails, new OraSQLManager(),
                  JDBCNamesType.RG_JDBC + "");
          for (String childUUID : childUUIDs) {
            Element childNode = tnCache.getTreeNode(childUUID);
            if (childNode != null && childNode.getAttributeValue("SERVICE_DATA") != null && ServiceDataCategory.isServiceDataCategory(childNode, listDataCategory)) {
              String label = childNode.getAttributeValue("TEXT");
              entityList.addListMember(label, childNode.getAttributeValue("SERVICE_DATA"), ServiceDataCategory.getServiceDataCategory(childNode));
            }
          }
          if (!entityList.isEmpty()) {
            if (entityList.performCommitAll(getSessionLogin().getRemoteUser()) == 0) {
              entityList = null;
            }
          }
        }
      }
    }
    Element entityListsEl = new Element("EntityLists");
    if (entityList != null) {
      entityListsEl.addContent(entityList.getAsElement(request));
    }
    ExtXMLElement.write(entityListsEl, response.getWriter());
  }

  /**
   * Updates the an EntityList
   *
   * @throws IOException
   */
  private void updateList() throws IOException, AIGException {
    if (doesParameterExist("list_id", true) && doesParameterExist("name", true)
            && doesParameterExist("description", false) && doesParameterExist("members", true)) {
      String listID = getParameter("list_id");
      String entityListName = getParameter("name");
      String entityListDescription = getParameter("description");
      String[] entityListMemberIDs = getParameter("members").split("\\r\\n+|\\n+|\\t+|;+");
      EntityList entityList = new EntityList(listID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
      if (entityList.setData()) {
        List<EntityListMemberIF> entityListMembers = GenericEntityListMember.createEntityListMembers(entityListMemberIDs, entityList.getEntityCategory());
        entityList.setName(entityListName);
        entityList.setDescription(entityListDescription);
        entityList.setListMembers(entityListMembers);
      }
      if (!entityList.isEmpty()) {
        if (entityList.performCommitAll(getSessionLogin().getRemoteUser()) == 0) {
          entityList = null;
        }
      }
      Element entityListsEl = new Element("EntityLists");
      if (entityList != null) {
        entityListsEl.addContent(entityList.getAsElement(request));
      }
      ExtXMLElement.write(entityListsEl, response.getWriter());
    }
  }

  private void refreshList() {
    try {
      if (doesParameterExist("list_id", true)) {
        String listID = getParameter("list_id");
        EntityList entityList = new EntityList(listID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
        if (entityList.setData()) {
          entityList.updateListFromSourceService(this);
        }
        AIGResponseMessage.writeSuccessElement("EntityList", "Refresh List", "List Refreshed", response);
      }
    } catch (Exception ex) {
      AIGResponseMessage.writeErrorElement("EntityList", "List Refresh Error", "Unable to refresh list: " + ex.getMessage(), response);
      ex.printStackTrace();
    }
  }

  /**
   * Adds entries to an EntityList
   *
   * @throws IOException
   */
  private void addToTreeNodeList() throws IOException, AIGException {
    TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(request);
    String listID = getParameter("list_id");
    List<String> treeNodeUUIDs = getParameters("uuid", ",");

    if (listID != null) {
      EntityList entityList = new EntityList(listID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
      if (entityList.setData()) {
        for (String treeNodeUUID : treeNodeUUIDs) {
          Element treeNode = tnCache.getTreeNode(treeNodeUUID);
          switch (NodeType.getNodeType(treeNode)) {
            case RESULTNODE:
            case SERVICENODE:
              List<String> childUUIDs = tnCache.getChildTreeNodeKeys(treeNode);
              for (String childUUID : childUUIDs) {
                Element childTreeNode = tnCache.getTreeNode(childUUID);
                if (NodeType.getNodeType(childTreeNode).equals(NodeType.ENTITYNODE)) {
                  ServiceDataCategory category = ServiceDataCategory.getServiceDataCategory(childTreeNode);
                  entityList.addListMember(treeNode.getAttributeValue("TEXT"), childTreeNode.getAttributeValue("SERVICE_DATA"), category);
                }
              }
              break;
            case ENTITYNODE:
              ServiceDataCategory category = ServiceDataCategory.getServiceDataCategory(treeNode);
              entityList.addListMember(treeNode.getAttributeValue("TEXT"), treeNode.getAttributeValue("SERVICE_DATA"), category);
              break;
          }
        }
        entityList.performCommitAll(getSessionLogin().getRemoteUser());
        new XMLOutputter().output(entityList.getAsElement(request), response.getWriter());
      }
    }
  }

  private void performListOperation() throws IOException, AIGException {
    List<String> listIDs = getParameters("list_id[0-9]+");
    List<String> treeNodeUUIDs = getParameters("uuid[0-9]*");
    String entityListName = getParameter("name");
    String entityListDescription = getParameter("description");

    if (listIDs.size() == 0 || !doesParameterExist("name", true)) {
      return;
    }
    if (!doesParameterExist("description", true)) {
      entityListDescription = "";
    }
    TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(request);

    try {
      List<List<String>> memberLists = new ArrayList<List<String>>();
      EntityListCategory listCategory = null;
      EntityListCategory category;
      for (String treeNodeUUID : treeNodeUUIDs) {
        Element treeNode = tnCache.getTreeNode(treeNodeUUID);
        if (treeNode != null) {
          List<String> currentMembers = new ArrayList<String>();
          memberLists.add(currentMembers);

          switch (NodeType.getNodeType(treeNode)) {
            case RESULTNODE:
            case SERVICENODE:
              List<String> childUUIDs = tnCache.getChildTreeNodeKeys(treeNode);
              for (String childUUID : childUUIDs) {
                Element childTreeNode = tnCache.getTreeNode(childUUID);
                if (NodeType.getNodeType(childTreeNode).equals(NodeType.ENTITYNODE)) {
                  category = getEntityClassManager().convertServiceDataCategoryToEntityListCategory(ServiceDataCategory.getServiceDataCategory(childTreeNode));
                  if (listCategory == null) {
                    listCategory = category;
                  }
                  if (listCategory.equals(category)) {
                    currentMembers.add(childTreeNode.getAttributeValue("SERVICE_DATA"));
                  }
                }
              }
              break;
            case ENTITYNODE:
              category = getEntityClassManager().convertServiceDataCategoryToEntityListCategory(ServiceDataCategory.getServiceDataCategory(treeNode));
              if (listCategory == null) {
                listCategory = category;
              }
              if (listCategory.equals(category)) {
                currentMembers.add(treeNode.getAttributeValue("SERVICE_DATA"));
              }

              break;
          }
        }
      }
      for (String listID : listIDs) {
        if (ExtString.hasTrimmedLength(listID) && ExtString.isAInteger(listID)) {
          EntityList entityList = new EntityList(listID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
          if (entityList.setData()) {
            if (listCategory == null) {
              listCategory = entityList.getEntityCategory();
            }
            if (listCategory.equals(entityList.getEntityCategory())) {
              List<String> currentMembers = new ArrayList<String>(entityList.getListMemberIds());
              memberLists.add(currentMembers);
            }
          }
        }
      }
      if (memberLists.size() > 0) {
        Set<String> resultSet = new HashSet<String>(memberLists.get(0));
        Set<String> xorDiffSet = new HashSet<String>(memberLists.get(0));
        for (int i = 1; i < memberLists.size(); i++) {
          Set<String> nextSet = new HashSet<String>(memberLists.get(i));
          switch (TreeNodeOperation.getValue(this)) {
            case UNION:
              resultSet.addAll(nextSet);
              break;
            case INTERSECTION:
              resultSet.retainAll(nextSet);
              break;
            case DIFFERENCE:
              resultSet.removeAll(nextSet);
              break;
            case XOR:
              resultSet.addAll(nextSet);
              xorDiffSet.retainAll(nextSet);
              break;
          }
        }
        if (TreeNodeOperation.getValue(this).equals(TreeNodeOperation.XOR)) {
          resultSet.removeAll(xorDiffSet);
        }
        JSONObject results = new JSONObject();
        results.put("results", resultSet.size());
        if (resultSet.size() > 0) {
          EntityList newEntityList = new EntityList(entityListName, entityListDescription, listCategory, getSessionLogin().getRemoteUser(), new OraSQLManager(), JDBCNamesType.RG_JDBC + "");
          newEntityList.setListMembers(resultSet);
          if (!newEntityList.isEmpty()) {
            if (newEntityList.performCommitAll(getSessionLogin().getRemoteUser()) == 0) {
              newEntityList = null;
            } else {
              results.put("list_name", entityListName);
            }
          }
          Element entityListsEl = new Element("EntityLists");
          if (newEntityList != null) {
            entityListsEl.addContent(newEntityList.getAsElement(request));
          }
        }
        results.write(response.getWriter());
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Returns the mimetype of the servlet
   */
  protected String getServletMimeType() {
    return "text/xml";
  }

  private void createResultBySubResult(String parentUUID, List<String> memberUUIDs) throws AIGException, IOException {
    //Grab the TreeNodeCache
    TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(request);
    //Pull the TreeNodes and child uuids out of cache
    Element parentTreeNode = tnCache.getTreeNode(parentUUID);
    NodeType parentNodeType = NodeType.getNodeType(parentTreeNode);
    List<String> childUUIDs = tnCache.getChildTreeNodeKeys(parentUUID);

    if ((parentNodeType.equals(NodeType.RESULTNODE) || parentNodeType.equals(NodeType.SERVICENODE)) && ExtArray.hasLength(childUUIDs)) {
      TreeNode firstChildNode = new TreeNode(tnCache.getTreeNode(childUUIDs.get(0)));
      ServiceDataCategory resultServiceDataCategory = firstChildNode.getServiceDataCategory();
      if (resultServiceDataCategory.equals(ServiceDataCategory.UNKNOWN)) {
        throw new AIGException("Unknown data type", Reason.UNABLE_TO_RETRIEVE_ENTRY);
      }
      //Setup resultset1
      List<EntityLineageWrapper> rset1 = new ArrayList<EntityLineageWrapper>();
      if (childUUIDs.size() > 0) {
        for (String childUUID : childUUIDs) {
          Element childNode = tnCache.getTreeNode(childUUID);
          if (childNode != null && childNode.getAttributeValue("SERVICE_DATA") != null && ServiceDataCategory.isServiceDataCategory(childNode, resultServiceDataCategory)) {
            rset1.add(new EntityLineageWrapper(childNode));
          }
        }
      }
      if (rset1.size() == 0) {
        throw new AIGException("No source data found", Reason.UNABLE_TO_RETRIEVE_ENTRY);
      }
      //Setup resultset2
      List<EntityLineageWrapper> rset2 = new ArrayList<EntityLineageWrapper>();
      if (childUUIDs.size() > 0) {
        for (String memberUUID : memberUUIDs) {
          Element memberNode = tnCache.getTreeNode(memberUUID);
          if (memberNode != null && memberNode.getAttributeValue("SERVICE_DATA") != null && ServiceDataCategory.isServiceDataCategory(memberNode, resultServiceDataCategory)) {
            rset2.add(new EntityLineageWrapper(memberNode));
          }
        }
      }
      if (rset2.size() == 0) {
        throw new AIGException("No source data found", Reason.UNABLE_TO_RETRIEVE_ENTRY);
      }
      createCombinedResult(rset1, null, rset2, null, resultServiceDataCategory, TreeNodeOperation.INTERSECTION);

    } else {
      throw new AIGException("No source data found", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }
  }

  /**
   * createResultByCombining
   *
   * @param treenodeUUID1 String
   * @param treenodeUUID2 String
   */
  private void createResultByCombining(String sourceUUID1, String targetUUID2) throws AIGException, IOException {
    //Grab the TreeNodeCache
    TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(request);
    //Pull the TreeNodes and child uuids out of cache
    Element sourceTreeNode = tnCache.getTreeNode(sourceUUID1);
    NodeType sourceNodeType = NodeType.getNodeType(sourceTreeNode);
    List<String> sourceChild1UUIDs = tnCache.getChildTreeNodeKeys(sourceUUID1);

    Element targetTreeNode = tnCache.getTreeNode(targetUUID2);
    NodeType targetNodeType = NodeType.getNodeType(targetTreeNode);
    List<String> targetChild1UUIDs = tnCache.getChildTreeNodeKeys(targetUUID2);

    //Find the target ServiceDataCategory. Throw exception if not found
    ServiceDataCategory resultServiceDataCategory = ServiceDataCategory.UNKNOWN;

    if (sourceNodeType.equals(NodeType.ENTITYNODE)) {
      resultServiceDataCategory = ServiceDataCategory.getServiceDataCategory(sourceTreeNode);
    } else if (sourceChild1UUIDs.size() > 0) {
      Element firstChildNode = tnCache.getTreeNode(sourceChild1UUIDs.get(0));
      resultServiceDataCategory = ServiceDataCategory.getServiceDataCategory(firstChildNode);
    }
    if (resultServiceDataCategory.equals(ServiceDataCategory.UNKNOWN)) {
      throw new AIGException("Unknown data type", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }
    //Setup resultset1
    List<EntityLineageWrapper> rset1 = new ArrayList<EntityLineageWrapper>();
    if (sourceNodeType.equals(NodeType.ENTITYNODE)) {
      rset1.add(new EntityLineageWrapper(sourceTreeNode));
    } else {
      if (sourceChild1UUIDs.size() > 0) {
        for (String childUUID : sourceChild1UUIDs) {
          Element childNode = tnCache.getTreeNode(childUUID);
          if (childNode != null && childNode.getAttributeValue("SERVICE_DATA") != null && ServiceDataCategory.isServiceDataCategory(childNode, resultServiceDataCategory)) {
            rset1.add(new EntityLineageWrapper(childNode));
          }
        }
      }
    }
    if (rset1.size() == 0) {
      throw new AIGException("No source data found", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }
    //Setup resultset2
    List<EntityLineageWrapper> rset2 = new ArrayList<EntityLineageWrapper>();
    if (targetChild1UUIDs.size() > 0) {
      for (String childUUID : targetChild1UUIDs) {
        Element childNode = tnCache.getTreeNode(childUUID);
        if (childNode != null && childNode.getAttributeValue("SERVICE_DATA") != null && ServiceDataCategory.isServiceDataCategory(childNode, resultServiceDataCategory)) {
          rset2.add(new EntityLineageWrapper(childNode));
        }
      }
    }
    if (rset2.size() == 0) {
      throw new AIGException("No target data found", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }
    createCombinedResult(rset1, sourceUUID1, rset2, targetUUID2, resultServiceDataCategory, TreeNodeOperation.getValue(this));
  }

  /**
   * createResultByCombining
   *
   * @param treenodeUUID1 String
   * @param treenodeUUID2 String
   */
  private void createResultByCombiningListTreeNode(String sourceUUID1, String list_id) throws AIGException, IOException {
    //Grab the TreeNodeCache
    TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(request);
    //Pull the TreeNodes and child uuids out of cache
    Element sourceTreeNode = tnCache.getTreeNode(sourceUUID1);
    NodeType sourceNodeType = NodeType.getNodeType(sourceTreeNode);
    List<String> sourceChild1UUIDs = tnCache.getChildTreeNodeKeys(sourceUUID1);

    EntityList entityList = new EntityList(list_id, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
    if (!entityList.setData()) {
      throw new AIGException("Invalid list", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }
    //Find the target ServiceDataCategory. Throw exception if not found
    ServiceDataCategory resultServiceDataCategory = ServiceDataCategory.UNKNOWN;

    if (sourceNodeType.equals(NodeType.ENTITYNODE)) {
      resultServiceDataCategory = ServiceDataCategory.getServiceDataCategory(sourceTreeNode);
    } else if (sourceChild1UUIDs.size() > 0) {
      Element firstChildNode = tnCache.getTreeNode(sourceChild1UUIDs.get(0));
      resultServiceDataCategory = ServiceDataCategory.getServiceDataCategory(firstChildNode);
    }
    if (resultServiceDataCategory.equals(ServiceDataCategory.UNKNOWN)) {
      throw new AIGException("Unknown data type", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }
    //Setup resultset1
    List<EntityLineageWrapper> rset1 = new ArrayList<EntityLineageWrapper>();
    if (sourceNodeType.equals(NodeType.ENTITYNODE)) {
      rset1.add(new EntityLineageWrapper(sourceTreeNode));
    } else {
      if (sourceChild1UUIDs.size() > 0) {
        for (String childUUID : sourceChild1UUIDs) {
          Element childNode = tnCache.getTreeNode(childUUID);
          if (childNode != null && childNode.getAttributeValue("SERVICE_DATA") != null && ServiceDataCategory.isServiceDataCategory(childNode, resultServiceDataCategory)) {
            rset1.add(new EntityLineageWrapper(childNode));
          }
        }
      }
    }
    if (rset1.isEmpty()) {
      throw new AIGException("No source data found", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }
    //Setup resultset2
    List<EntityLineageWrapper> rset2 = new ArrayList<EntityLineageWrapper>();
    if (entityList.getEntityCategory().equals(getEntityClassManager().convertServiceDataCategoryToEntityListCategory(resultServiceDataCategory))) {
      List<EntityListMemberIF> listMembers = entityList.getListMembers();
      if (!listMembers.isEmpty()) {
        for (EntityListMemberIF entity : listMembers) {
          rset2.add(new EntityLineageWrapper((EntityIF) entity));
        }
      }
    }
    createCombinedResult(rset1, sourceUUID1, rset2, list_id, resultServiceDataCategory, TreeNodeOperation.getValue(this));
  }

  private void createCombinedResult(List<EntityLineageWrapper> rset1, String sourceID1, List<EntityLineageWrapper> rset2, String sourceID2, ServiceDataCategory resultServiceDataCategory, TreeNodeOperation operation) throws
          AIGException, IOException {
    //Grab the TreeNodeCache
    TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(request);
    String combinedNodeName = getParameter("name");
    String combinedNodeDescription = getParameter("description");
    if (rset2.isEmpty()) {
      throw new AIGException("No target data found", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }
    //Setup result buffers and perform operation. Final result will be in resultSet
    Set<EntityLineageWrapper> resultSet = new HashSet<EntityLineageWrapper>(rset1);
    Set<EntityLineageWrapper> xorDiffSet = new HashSet<EntityLineageWrapper>(rset1);

    switch (operation) {
      case UNION:
        resultSet.addAll(rset2);
        break;
      case INTERSECTION:
        resultSet.retainAll(rset2);
        break;
      case DIFFERENCE:
        resultSet.removeAll(rset2);
        break;
      case XOR:
        resultSet.addAll(rset2);
        xorDiffSet.retainAll(rset2);
        resultSet.removeAll(xorDiffSet);
        break;
    }

    Element combinedResultNode = new Element("TREENODE");
    ExtXMLElement.addAttribute(combinedResultNode, "TEXT", combinedNodeName);
    ExtXMLElement.addAttribute(combinedResultNode, "TITLE", combinedNodeDescription);

    for (EntityLineageWrapper entityItemWrapper : resultSet) {
      EntityIF entityItem = entityItemWrapper.getEntity();
      String label = entityItem.getLabel();
      String desc = entityItem.getDescription();
      String serviceData = entityItem.getDataValue();

      Element combinedEntityNode = ExtXMLElement.addElement(combinedResultNode, "TREENODE");
      ExtXMLElement.addAttribute(combinedEntityNode, "TEXT", label);
      ExtXMLElement.addAttribute(combinedEntityNode, "TITLE", desc);
      ExtXMLElement.addAttribute(combinedEntityNode, "SERVICE_DATA", serviceData);
      ExtXMLElement.addAttribute(combinedEntityNode, "SERVICE_DATA_TYPE_CATEGORY", ServiceDataCategory.revertTo(resultServiceDataCategory));
    }

    Element resultNode = processTreeNodes(combinedResultNode, null, NodeType.RESULTNODE, resultServiceDataCategory, null, null);
    if (sourceID1 != null) {
      createCombinedTable(new TreeNode(resultNode), sourceID1, sourceID2);
    }
    TreeNodeCache.getTreeNodeCache(request).addTreeNode(resultNode);
    ExtXMLElement.write(resultNode, response.getWriter());
  }

  private void createSubtable(EntityTable entityTable, List<String> includeEntityIDs, String resultNodeName) throws AIGException, IOException {
    try {
      if (entityTable == null || includeEntityIDs.isEmpty()) {
        return;
      }
      final Set<String> entityIDs = new HashSet<String>(includeEntityIDs);
      EntityTable filteredEntityTable = new EntityTable(entityTable.getEntityCategory());
      List<ColumnGroup> columnGroupsAdded = new ArrayList<ColumnGroup>();
      for (int i = 0; i < entityTable.getColumnGroups().size(); i++) {
        ColumnGroup columnGroup = (ColumnGroup) ExtObject.copy(entityTable.getColumnGroups().get(i));
        filteredEntityTable.addColumnGroup(columnGroup);
        columnGroupsAdded.add(columnGroup);
      }
      for (DataRow sourceRow : entityTable.getDataRows()) {
        if (entityIDs.contains(sourceRow.getEntityID())) {
          DataRow filteredRow = (DataRow) ExtObject.copy(sourceRow);
          filteredEntityTable.addDataRow(filteredRow);
        }
      }

      filteredEntityTable.getEntityTableJSON(true);
      EntityTableCacheItem entityTableCacheItem = ServiceCache.getServiceCache(request).saveEntityTableResult(new EntityTableCacheItem(this, filteredEntityTable));
      
      EntityListLoader entityListLoader = new EntityListLoader(request);
      Document searchResultDoc = entityListLoader.loadAsResultNode(filteredEntityTable, null);
      Element resultEl = searchResultDoc.getRootElement();
      TreeNode resultNode = new TreeNode(resultEl);
      resultNode.setNodeAttribute("TABLE_KEY", entityTableCacheItem.getKey());
      resultNode.setText(resultNodeName);
      TreeNodeCache.getTreeNodeCache(request).addTreeNode(resultEl);
      ExtXMLElement.write(resultEl, response.getWriter());     
    } catch (Exception ex) {
      Logger.getLogger(TreeNodeOperations.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

  private void createCombinedTable(TreeNode resultNode, String sourceID1, String sourceID2) {
    try {
      EntityTable entityTable1 = null;
      EntityTable entityTable2 = null;
      TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(request);

      TreeNode sourceNode1 = new TreeNode(tnCache.getTreeNode(sourceID1));
      if (sourceNode1.isValid()) {
        EntityTableCacheItem entityTableCacheItem = ServiceCache.getServiceCache(request).getEntityTableResult(sourceNode1.getNodeAttribute("TABLE_KEY"));
        if (entityTableCacheItem != null) {
          entityTable1 = entityTableCacheItem.getEntityTable();
        }
      }
      TreeNode sourceNode2 = new TreeNode(tnCache.getTreeNode(sourceID2));
      if (sourceNode2.isValid()) {
        EntityTableCacheItem entityTableCacheItem = ServiceCache.getServiceCache(request).getEntityTableResult(sourceNode2.getNodeAttribute("TABLE_KEY"));
        if (entityTableCacheItem != null) {
          entityTable2 = entityTableCacheItem.getEntityTable();
        }
      }

      if (entityTable1 == null && entityTable2 == null) {
        return;
      }

      EntityTableLoaderIF entityTableLoader = EntityLoaderFactory.getEntityTableLoader(this, resultNode.getKey());
      EntityTable entityTable = entityTableLoader.createEntityTable();

      List<ColumnGroup> columnGroupsAdded = new ArrayList<ColumnGroup>();
      if (entityTable1 != null) {
        for (int i = 1; i < entityTable1.getColumnGroups().size(); i++) {
          ColumnGroup columnGroup = (ColumnGroup) ExtObject.copy(entityTable1.getColumnGroups().get(i));
          entityTable.addColumnGroup(columnGroup);
          columnGroupsAdded.add(columnGroup);
        }
      }
      if (entityTable2 != null) {
        for (int i = 1; i < entityTable2.getColumnGroups().size(); i++) {
          ColumnGroup columnGroup = (ColumnGroup) ExtObject.copy(entityTable2.getColumnGroups().get(i));
          entityTable.addColumnGroup(columnGroup);
          columnGroupsAdded.add(columnGroup);
        }
      }
      for (String entityID : entityTable.getEntityIDs()) {
        DataRow row = entityTable.getDataRow(entityID);
        for (ColumnGroup columnGroup : columnGroupsAdded) {
          for (Column column : columnGroup.getColumns()) {
            row.addDataCell(new DataCell(""));
          }
        }
      }

      for (String entityID : entityTable.getEntityIDs()) {
        DataRow targetRow = entityTable.getDataRow(entityID);
        if (entityTable1 != null) {
          DataRow sourceRow = entityTable1.getDataRow(entityID);
          if (sourceRow != null) {
            for (int i = 1; i < entityTable1.getColumnGroups().size(); i++) {
              ColumnGroup columnGroup = entityTable1.getColumnGroups().get(i);
              for (Column column : columnGroup.getColumns()) {
                int sourceColumnIndex = entityTable1.getColumnIndex(column.getDataIndex());
                int targetColumnIndex = entityTable.getColumnIndex(column.getDataIndex());
                DataCell clonedDataCell = (DataCell) ExtObject.copy(sourceRow.getDataCell(sourceColumnIndex));
                targetRow.setDataCell(clonedDataCell, targetColumnIndex);
              }
            }
          }
        }
        if (entityTable2 != null) {
          DataRow sourceRow = entityTable2.getDataRow(entityID);
          if (sourceRow != null) {
            for (int i = 1; i < entityTable2.getColumnGroups().size(); i++) {
              ColumnGroup columnGroup = entityTable2.getColumnGroups().get(i);
              for (Column column : columnGroup.getColumns()) {
                int sourceColumnIndex = entityTable2.getColumnIndex(column.getDataIndex());
                int targetColumnIndex = entityTable.getColumnIndex(column.getDataIndex());
                DataCell clonedDataCell = (DataCell) ExtObject.copy(sourceRow.getDataCell(sourceColumnIndex));
                targetRow.setDataCell(clonedDataCell, targetColumnIndex);
              }
            }
          }
        }

      }

      entityTable.getEntityTableJSON(true);
      EntityTableCacheItem entityTableCacheItem = ServiceCache.getServiceCache(request).saveEntityTableResult(new EntityTableCacheItem(this, entityTable));
      resultNode.setNodeAttribute("TABLE_KEY", entityTableCacheItem.getKey());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}

class EntityLineageWrapper {
  private EntityIF entity;

  EntityLineageWrapper(EntityLineage entityLineage) {
    this.entity = entityLineage;
  }

  EntityLineageWrapper(Element treeNode) {
    this.entity = EntityLineage.getEntityLineageForTreeNode(treeNode);
  }

  EntityLineageWrapper(EntityIF entity) {
    this.entity = entity;
  }

  public boolean equals(Object obj) {
    if (obj instanceof EntityLineageWrapper) {
      EntityLineageWrapper entityLineageWrapper1 = this;
      EntityLineageWrapper entityLineageWrapper2 = (EntityLineageWrapper) obj;
      String compareVal1 = entityLineageWrapper1.entity.getDataValue();
      String compareVal2 = entityLineageWrapper2.entity.getDataValue();
      return (compareVal1.equals(compareVal2));
    }
    return false;
  }

  public int hashCode() {
    return entity.getDataValue().hashCode();
  }

  public EntityIF getEntity() {
    return entity;
  }

  public String toString() {
    return entity.getDataValue();
  }
}
