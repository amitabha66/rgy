/*
 *   Favorite_Keys
 *   RDBData wrapper class for ABSTRACT_QUERY_ITEM
 *   $Revision: 1.2 $
 *   Created: Jeffrey McDowell, 12 Jun 2009
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.favorites;


import java.lang.reflect.Field;

import amgen.ri.json.JSONObject;
import amgen.ri.rdb.OraSequenceField;
import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.Removeable;
import amgen.ri.rdb.SQLManagerIF;
import amgen.ri.rdb.Saveable;

/**
 *   RDBData wrapper class for ABSTRACT_QUERY_ITEM
 *   @version $Revision: 1.2 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class FavoriteKey extends RdbData implements Saveable, Removeable {
    protected OraSequenceField favorite_key_id;
    protected int favorite_id;
    protected String favorite_key;

    /**
     * Default Constructor
     */
    public FavoriteKey() {
        super();
    }

    /**
     * RdbData Constructor
     */
    public FavoriteKey(String favorite_key_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.favorite_key_id = new OraSequenceField(favorite_key_id);

    }

    /**
     * Constructor which sets the class variables
     */
    public FavoriteKey(int favorite_id, String favorite_key, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.favorite_key_id = new OraSequenceField("FAVORITES_SEQ", this);
        this.favorite_id = favorite_id;
        this.favorite_key = favorite_key;
        setNewEntity();
    }

    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return favorite_key_id + "";
    }

    /** This method returns the name of the table. */
    protected String getTableName() {
        return "FAVORITE_KEYS";
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }

    /** Returns the SQL for INSERTing the object in the table */
    public String getInsertSQL() {
        return null;
    }

    /** Returns the SQL for UPDATing the object in the table */
    public String getUpdateSQL() {
        return null;
    }

    /** Returns the SQL for DELTEing the object/row in the table */
    public String getDeleteSQL() {
        return null;
    }

    /** Get value for favorite_id */
    public int getFavorite_id() {
        return getAsNumber("favorite_id").intValue();
    }

    /** Get value for favorite_key */
    public String getFavorite_key() {
        return (String) get("favorite_key");
    }

    /**
     * Returns the key as a JSONObject. If the key is an encoded JSON object, it gets decoded.
     * Otherwise, the key is in a JSON object as {key: key}
     * If the key is null, this returns null
     */
    public JSONObject getFavoriteKeyAsJSON() {
        if (get("favorite_key")!= null) {
            try {
                return new JSONObject((String) get("favorite_key"));
            } catch (Exception e) {}
            try {
                JSONObject jObj = new JSONObject();
                jObj.put("key", (String)get("favorite_key"));
                return jObj;
            } catch (Exception e) {}
        }
        return null;
    }
}
