/*
 *   Favorite
 *   RDBData wrapper class for favorite
 *   $Revision: 1.13 $
 *   Created: Jeffrey McDowell, 10 Jun 2009
 *   Modified: $Author: jemcdowe $
 *   $Log
 *
 */
package amgen.ri.aig.favorites;

import amgen.ri.aig.AIGBase;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.entity.rgdh.DHProjectInfo;
import amgen.ri.aig.entitylist.EntityList;
import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.aig.sobj.ObjectType;
import amgen.ri.aig.sobj.SavedObject;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.OraSequenceField;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.rdb.Removeable;
import amgen.ri.rdb.SQLManagerIF;
import amgen.ri.rdb.Saveable;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtArray;
import amgen.ri.util.HashCodeGenerator;

/**
 * RDBData wrapper class for favorite
 * 
 * @version $Revision: 1.13 $
 * @author Jeffrey McDowell
 * @author $Author: jemcdowe $
 */
public class Favorite extends AbstractFavorite implements Saveable, Removeable, FavoriteIF {
	protected OraSequenceField favorite_id;
	protected String name;
	protected String description;
	protected ObjectType object_type_id;
	protected String category;
	protected FavoriteKey[] favorite_keys;
	protected SharedFavorite[] shared_favorites;
	protected String created_by;
	protected Timestamp created;
	private int fHashCode;

	/**
	 * Default Constructor
	 */
	public Favorite() {
		super();
	}

	/**
	 * RdbData Constructor
	 */
	public Favorite(String favorite_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
		super(sqlManager, logonusername, connectionPool);
		this.favorite_id = new OraSequenceField(favorite_id);
	}

	/**
	 * Constructor which sets the class variables
	 */
	public Favorite(String name, String description, ObjectType type, EntityListCategory category, List<String> favoriteKeys, SQLManagerIF sqlManager,
			String created_by, String connectionPool) {
		this(name, description, category, type, sqlManager, created_by, connectionPool);
		setFavoriteKeys(favoriteKeys);
	}

	/**
	 * Constructor which sets the class variables
	 */
	public Favorite(String name, String description, ObjectType.Type type, EntityListCategory category, List<String> favoriteKeys, SQLManagerIF sqlManager,
			String created_by, String connectionPool) {    
		this(name, description, category, ObjectType.getObjectType(type+"", connectionPool), sqlManager, created_by, connectionPool);
		setFavoriteKeys(favoriteKeys);
	}

	/**
	 * Constructor which sets the class variables
	 */
	public Favorite(String name, String description, EntityListCategory category, ObjectType type, String favoriteKey, SQLManagerIF sqlManager,
			String created_by, String connectionPool) {
		this(name, description, category, type, sqlManager, created_by, connectionPool);
		if (favoriteKey == null || favoriteKey.trim().length() == 0) {
			throw new IllegalArgumentException("Favorite key(s) cannot be empty");
		}
		this.favorite_keys = new FavoriteKey[1];
		this.favorite_keys[0] = new FavoriteKey(this.favorite_id.intValue(), favoriteKey.trim(), getSQLManager(), getLogonUsername(), getConnectionPool());
	}

	/**
	 * Constructor which sets the class variables
	 */
	private Favorite(String name, String description, EntityListCategory category, ObjectType type, SQLManagerIF sqlManager, String created_by,
			String connectionPool) {
		super(sqlManager, created_by, connectionPool);
		this.favorite_id = new OraSequenceField("FAVORITES_SEQ", this);
		setName(name);
		setDescription(description);
		this.category = category.toString();
		if (type == null) {
			throw new IllegalArgumentException("Unknown favorite type");
		}

		this.object_type_id = type;
		this.created_by = created_by;
		this.created = new Timestamp(System.currentTimeMillis());
		setNewEntity();
	}

	/** A required method which returns the primary key(s) of the table/RdbData class. */
	public String getIdentifier() {
		return favorite_id + "";
	}
  
  public int getFavoriteID() {
    return favorite_id.intValue();
  }

	/** This method returns the name of the table. */
	protected String getTableName() {
		return "FAVORITES";
	}

	/**
	 * Returns whether this Favorite is valid an should be included in any lists of Favorites
	 * 
	 * @return boolean
	 */
	public boolean isValid(AIGBase requestor) {
		return (setData() && super.isValid(requestor));
	}

	/**
	 * Performs a delete of the item verifying sufficient privledge
	 * 
	 * @param sessionUser String
	 * @return int
	 */
	public int performDelete(String sessionUser) {
		if (!getCreated_by().equals(sessionUser)) {
			throw new IllegalArgumentException("Insufficient privledge to delete item");
		}
		return performDelete();
	}

	/**
	 * Performs a deep- delete on the Favorite including all FavoriteKeys returning the number of deleted rows.
	 */
	public int performDelete() {
		int deleteCount = 0;
		FavoriteKey[] keys = getFavoriteKeys();
		if (keys != null) {
			if (getObjectType().isA(ObjectType.SERVICE)) {
				SavedObject sObj = new SavedObject(keys[0].getFavorite_key(), getSQLManager(), getLogonUsername(), getConnectionPool());
				deleteCount += sObj.performDelete();
			}
			for (FavoriteKey key : keys) {
				deleteCount += key.performDelete();
			}
		}
		SharedFavorite[] shares = getShares();
		if (shares != null) {
			for (SharedFavorite share : shares) {
				deleteCount += share.performDelete();
			}
		}
		int localDeleteCount = super.performDelete();
		if (localDeleteCount == 0) {
			return 0;
		}
		return localDeleteCount + deleteCount;
	}

	/**
	 * Performs a commit on this object saving to the database the current values of the fields and performs a commit on all the FavoriteKey objects
	 */
	public int performCommitAll() {
		int updateCount = performCommit();
		FavoriteKey[] keys = getFavoriteKeys();
		if (keys != null) {
			for (FavoriteKey key : keys) {
				updateCount += key.performCommit();
			}
		}
		return updateCount;
	}

	/** Get value for name */
	public String getName() {
		return (String) get("name");
	}

	/** Set value for name */
	public void setName(String name) {
		if (name == null || name.trim().length() == 0) {
			throw new IllegalArgumentException("Favorite name cannot be empty");
		}
		this.name = name;
	}

	/** Get value for description */
	public String getDescription() {
		return (String) get("description");
	}

	/** Set value for description */
	public void setDescription(String description) {
		this.description = (description == null || description.trim().length() == 0 ? "" : description);
	}

	/** Get value for category */
	public void setCategory(EntityListCategory category) {
		if (category.equals(EntityListCategory.UNKNOWN)) {
			throw new IllegalArgumentException("Category can not be UNKNOWN");
		}
		this.category = category.toString();
	}

	/** Get value for type_id */
  @Override
	public ObjectType getObjectType() {
		return (ObjectType) get("object_type_id");
	}

	/** Get value for favorite_key */
	public FavoriteKey[] getFavoriteKeys() {
		return (FavoriteKey[]) get("favorite_keys");
	}

	/** Get value for shared_favorites */
	public SharedFavorite[] getShares() {
		return (SharedFavorite[]) get("shared_favorites");
	}

	/** Get value for a  SharedFavorite for the given user*/
	public SharedFavorite getShare(String sharedWithUser) {
    SharedFavorite[] shares= getShares();
    if (shares!= null) {
      for(SharedFavorite share : shares) {
        if (sharedWithUser.equals(share.getShared_with())) {
          return share;
        }
      }
    }
		return null;
	}


	/** Set values for favorite_keys */
	public void setFavoriteKeys(List<String> favoriteKeys) {
		if (favoriteKeys == null || favoriteKeys.size() == 0) {
			throw new IllegalArgumentException("Favorite key(s) cannot be empty");
		}
		this.favorite_keys = new FavoriteKey[favoriteKeys.size()];
		for (int i = 0; i < favoriteKeys.size(); i++) {
			String favoriteKey = favoriteKeys.get(i);
			if (favoriteKey == null || favoriteKey.trim().length() == 0) {
				throw new IllegalArgumentException("Favorite key(s) cannot be empty");
			}
			this.favorite_keys[i] = new FavoriteKey(this.favorite_id.intValue(), favoriteKey.trim(), getSQLManager(), getLogonUsername(), getConnectionPool());
		}
	}

	public Date getCreatedDate() {
		return (Timestamp) get("created");
	}

	public String getCreated_by() {
		return (String) get("created_by");
	}

	public EntityListCategory getCategory() {
		return EntityListCategory.fromString((String) get("category"));
	}

	/**
	 * Returns the Favorite's basic information as a JSON object
	 * 
	 * @param sessionLogin AIGSessionLogin
	 * @return JSONObject
	 */
	public JSONObject toJSON(AIGSessionLogin sessionLogin) {
		FavoriteFolder favoriteRootFolder = FavoriteFolder.getRootFolder(JDBCNamesType.RG_JDBC+"");

		JSONObject jObj = new JSONObject();
		try {
			jObj.put("modified_by", getCreated_by());
			jObj.put("created", sessionLogin.convertToUserTimeZone("MM/dd/yyyy hh:mm:ss a", getCreatedDate()));
			jObj.put("folder_id", favoriteRootFolder.getFolderID());
			if (this instanceof Favorite) {
				jObj.put("type", FavoriteFolderItem.ItemType.FAVORITE);
			} else {
				jObj.put("type", FavoriteFolderItem.ItemType.SHARED_FAVORITE);
			}
			jObj.put("subtype", getObjectType().getType().toString());

			FavoriteFolderItem favFolderItem = getFavoriteFolderItem();
			if (favFolderItem != null && favFolderItem.setData()) {
				jObj.put("folder_item_id", favFolderItem.getIdentifier());
				jObj.put("folder_id", favFolderItem.getFolder().getFolderID());
			}
			SharedFavorite[] shares = getShares();
			if (ExtArray.hasLength(shares)) {
				for (SharedFavorite share : shares) {
					jObj.append("shared_with", share.toJSON(sessionLogin));
				}
			}
		} catch (Exception e) {
		}
		return jObj;
	}

	public int hashCode() {
		if (fHashCode == 0) {
			int result = HashCodeGenerator.SEED;
			result = HashCodeGenerator.hash(result, this.getIdentifier());
			fHashCode = result;
		}
		return fHashCode;
	}

	public boolean equals(Object obj) {
		if (obj instanceof Favorite) {
			return (((Favorite) obj).getIdentifier() == this.getIdentifier());
		}
		return false;
	}

	/**
	 * Finds all Favorites for a given key for the created_by owner. Convenience method which calls getFavorite(String[] favoriteKeys, String createdBy, String
	 * connectionPool)
	 * 
	 * @param favoriteKey String[]
	 * @param createdBy String
	 * @param connectionPool String
	 * @return List
	 */
	public static List<Favorite> getFavorite(String favoriteKey, int type, String createdBy, String connectionPool) {
		return getFavorite(new String[] {
			favoriteKey
		}, type, createdBy, connectionPool);
	}

	/**
	 * Finds all Favorites for a given key list for the created_by owner
	 * 
	 * @param favoriteKeys String[]
	 * @param createdBy String
	 * @param connectionPool String
	 * @return List
	 */
	public static List<Favorite> getFavorite(String[] favoriteKeys, int type, String createdBy, String connectionPool) {
		if (favoriteKeys == null || favoriteKeys.length == 0) {
			return new ArrayList<Favorite>();
		}
		String sql = "SELECT FAVORITES.FAVORITE_ID FROM FAVORITES, FAVORITE_KEYS WHERE "
				+ "FAVORITES.FAVORITE_ID= FAVORITE_KEYS.FAVORITE_ID AND FAVORITES.CREATED_BY=? " + "AND FAVORITES.OBJECT_TYPE_ID=? ";
		StringBuffer favoriteKeyCompareTerms = new StringBuffer();
		for (String favoriteKey : favoriteKeys) {
			favoriteKeyCompareTerms.append(" AND FAVORITE_KEYS.favorite_key=? ");
		}
		sql += favoriteKeyCompareTerms;
		ArrayList<String> tokens = new ArrayList<String>();
		tokens.add(createdBy);
		tokens.add(type + "");
		tokens.addAll(Arrays.asList(favoriteKeys));

		return new RdbDataArray(Favorite.class, sql, (String[]) tokens.toArray(new String[0]), new OraSQLManager(), null, connectionPool);

	}

	/** Returns the contained Favorite- if Favorite object, return this; if SharedFavorite, getFavorite() */
	public Favorite getFavorite() {
		return this;
	}

	/**
	 * Returns the Object associated with this Favorite. This can vary depending on the ObjectType ENTITYTABLE, SERVICE- SavedObject LIST- EntityList
	 * PROJECTVIEW- DHProjectInfo including viewID= view ID as a transient data field
	 */
	public Object getFavoriteObject() {
		try {
			if (getFavoriteKeys()== null || getFavoriteKeys().length==0) {
				return null;
			}			
			JSONObject jFavKey = getFavoriteKeys()[0].getFavoriteKeyAsJSON();
			switch (getObjectType().getType()) {
				case ENTITYTABLE:
				case SERVICE:
					return new SavedObject(jFavKey.getString("key"), getSQLManager(), getLogonUsername(), getConnectionPool());
				case LIST:
					return new EntityList(jFavKey.getString("key"), getSQLManager(), getLogonUsername(), getConnectionPool());
				case PROJECTVIEW:
					String viewID = jFavKey.getString("viewID");
					String project = jFavKey.getString("project");
					DHProjectInfo projectInfo = DHProjectInfo.getProjectInfo(project);
					projectInfo.setTransientData("viewID", viewID);
					return projectInfo;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
