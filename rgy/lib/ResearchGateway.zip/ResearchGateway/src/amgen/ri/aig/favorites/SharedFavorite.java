package amgen.ri.aig.favorites;

import amgen.ri.aig.AIGBase;
import java.sql.Timestamp;
import java.util.Date;

import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.aig.sobj.ObjectType;
import amgen.ri.json.JSONObject;
import amgen.ri.rdb.OraSequenceField;
import amgen.ri.rdb.Removeable;
import amgen.ri.rdb.SQLManagerIF;
import amgen.ri.rdb.Saveable;
import amgen.ri.util.ExtString;
import amgen.ri.util.HashCodeGenerator;

/**
 * RDBData wrapper class for SharedObject
 *
 * @version $Revision: 1.10 $
 * @author Jeffrey McDowell
 * @author $Author: jemcdowe $
 */
public class SharedFavorite extends AbstractFavorite implements Saveable, Removeable, FavoriteIF {
  protected OraSequenceField shared_favorite_id;
  protected Favorite favorite_id;
  protected String shared_with;
  protected String is_group;
  protected Timestamp shared_date;
  private int fHashCode;

  /**
   * Default Constructor
   */
  public SharedFavorite() {
    super();
  }

  /**
   * RdbData Constructor
   */
  public SharedFavorite(String shared_favorite_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
    this.shared_favorite_id = new OraSequenceField(shared_favorite_id);
  }

  /**
   * Constructor which sets the class variables
   */
  public SharedFavorite(Favorite favorite, String shared_with, boolean is_group, SQLManagerIF sqlManager, String created_by, String connectionPool) {
    super(sqlManager, created_by, connectionPool);
    this.shared_favorite_id = new OraSequenceField("FAVORITES_SEQ", this);
    this.favorite_id = favorite;
    this.shared_with = shared_with;
    this.is_group = (is_group ? "Y" : "N");
    this.shared_date = new Timestamp(System.currentTimeMillis());
  }

  /**
   * Constructor which sets the class variables
   */
  public SharedFavorite(Favorite favorite, PersonRecordIF personRecord, SQLManagerIF sqlManager, String created_by, String connectionPool) {
    super(sqlManager, created_by, connectionPool);
    this.shared_favorite_id = new OraSequenceField("FAVORITES_SEQ", this);
    this.favorite_id = favorite;
    this.shared_with = personRecord.getUsername();
    this.is_group = (personRecord.isGroup() ? "Y" : "N");
    this.shared_date = new Timestamp(System.currentTimeMillis());
  }

  /**
   * A required method which returns the primary key(s) of the table/RdbData
   * class.
   */
  public String getIdentifier() {
    return shared_favorite_id + "";
  }

  /**
   * This method returns the name of the table.
   */
  protected String getTableName() {
    return "FAVORITES_SHARED";
  }

  public int getSharedFavoriteID() {
    return shared_favorite_id.intValue();
  }
  /**
   * Get value for name
   */
  public String getShared_with() {
    return (String) get("shared_with");
  }

  /**
   * Whether this is a group
   */
  public boolean isGroup() {
    return ExtString.equals((String) get("is_group"), "Y");
  }

  /**
   * Set value for name
   */
  public void setShared_with(String shared_with) {
    if (shared_with == null || shared_with.trim().length() == 0) {
      throw new IllegalArgumentException("Shared wit cannot be empty");
    }
    this.shared_with = shared_with;
  }

  public Favorite getFavorite() {
    return (Favorite) get("favorite_id");
  }

  public Date getSharedDate() {
    return (Timestamp) get("shared_date");
  }

  public int hashCode() {
    if (fHashCode == 0) {
      int result = HashCodeGenerator.SEED;
      result = HashCodeGenerator.hash(result, this.getIdentifier());
      fHashCode = result;
    }
    return fHashCode;
  }

  public boolean equals(Object obj) {
    if (obj instanceof SharedFavorite) {
      return (((SharedFavorite) obj).getIdentifier() == this.getIdentifier());
    }
    return false;
  }

  public Date getCreatedDate() {
    return getFavorite().getCreatedDate();
  }

  public String getCreated_by() {
    return getFavorite().getCreated_by();
  }

  public String getDescription() {
    return getFavorite().getDescription();
  }

  public String getName() {
    return getFavorite().getName();
  }

  /**
   * Performs a delete of the item verifying sufficient privledge
   *
   * @param sessionUser String
   * @return int
   */
  public int performDelete(String sessionUser) {
    if (!getCreated_by().equals(sessionUser) && !getShared_with().equals(sessionUser)) {
      throw new IllegalArgumentException("Insufficient privledge to delete item");
    }
    return performDelete();
  }

  public int compareTo(Object o) {
    return 0;
  }

  @Override
  public ObjectType getObjectType() {
    try {
      return getFavorite().getObjectType();
    } catch (Exception e) {
    }
    return null;
  }

  /**
   * Returns whether this Favorite is valid an should be included in any lists
   * of Favorites
   *
   * @return boolean
   */
  public boolean isValid(AIGBase requestor) {
    return (setData() && getFavorite() != null && getFavorite().setData() && super.isValid(requestor));
  }

  /**
   * Returns the Favorite's basic information as a JSON object
   *
   * @param sessionLogin AIGSessionLogin
   * @return JSONObject
   */
  public JSONObject toJSON(AIGSessionLogin sessionLogin) {
    FavoriteFolder favoriteRootFolder = FavoriteFolder.getRootFolder(JDBCNamesType.RG_JDBC+"");

    JSONObject jObj = new JSONObject();
    try {
      jObj.put("modified_by", getCreated_by());
      jObj.put("created", sessionLogin.convertToUserTimeZone("MM/dd/yyyy hh:mm:ss a", getCreatedDate()));
      jObj.put("type", FavoriteFolderItem.ItemType.SHARED_FAVORITE);
      jObj.put("folder_id", favoriteRootFolder.getFolderID());
      jObj.put("subtype", getFavorite().getObjectType().getType().toString());

      FavoriteFolderItem favFolderItem = getFavoriteFolderItem();
      if (favFolderItem != null && favFolderItem.setData()) {
        jObj.put("folder_item_id", favFolderItem.getIdentifier());
        jObj.put("folder_id", favFolderItem.getFolder().getFolderID());
      }
    } catch (Exception e) {
    }
    return jObj;
  }

  @Override
  public Object getFavoriteObject() {
    Favorite favorite= getFavorite();
    if (favorite!= null) {
      return favorite.getFavoriteObject();
    }
    return null;
  }

  public FavoriteKey[] getFavoriteKeys() {
    return getFavorite().getFavoriteKeys();
  }

}
