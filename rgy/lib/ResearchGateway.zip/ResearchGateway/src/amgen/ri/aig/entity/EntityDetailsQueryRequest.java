package amgen.ri.aig.entity;

import java.io.ObjectStreamException;

/**
 * @version $Id: EntityDetailsQueryRequest.java,v 1.1 2011/06/17 20:41:26 cvs Exp $
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public enum EntityDetailsQueryRequest {
    NODE_DETAILS, ENTITY_DETAILS, ENTITY_QUERY, UNKNOWN;

    /**
     * This is necessary to permit Serializable.
     * A Serialized object containing an enum class variable is not de-Serialized properly.
     * This forces de-Serialized enum to be re-created as this enum through the String
     * @return Object
     * @throws ObjectStreamException
     */
    public Object readResolve() throws ObjectStreamException {
        return EntityDetailsQueryRequest.valueOf(this.toString());
    }

}
