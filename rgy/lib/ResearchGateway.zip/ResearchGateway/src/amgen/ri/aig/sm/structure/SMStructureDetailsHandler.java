package amgen.ri.aig.sm.structure;

import amgen.ri.aig.AIGException;
import amgen.ri.json.JSONException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.entity.provider.CompoundEntityDetails;
import amgen.ri.aig.preferences.PreferenceIF;
import amgen.ri.aig.preferences.PreferenceManager;
import amgen.ri.aig.preferences.PreferenceableIF;
import amgen.ri.chem.ExtMolecule;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.json.JSONObject;
import amgen.ri.security.FASFEncrypter;
import amgen.ri.util.ExtFile;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import com.symyx.draw.Renderer;
import java.text.DecimalFormat;
import java.util.HashSet;
import java.util.Set;
import org.jdom.Document;
import org.openscience.cdk.exception.CDKException;

public class SMStructureDetailsHandler extends AIGServlet implements PreferenceableIF {
  private String smscURL;
  private DecimalFormat twoDigitDecimalformat = new DecimalFormat("#.00");
  //Preference settings
  private Map<String, String> preferences;


  public SMStructureDetailsHandler() {
    super();
  }

  public SMStructureDetailsHandler(HttpServletRequest request, HttpServletResponse response) {
    super(request, response);
    String smscBaseURL = ConfigurationParameterSource.getConfigParameter("SMSC_BASE_URL");
    smscURL = smscBaseURL + "/smsc.go";
    try {
      new PreferenceManager(getSessionLogin(), this).setPreferences();
    } catch (AIGException ex) {
    }

  }

  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new SMStructureDetailsHandler(req, resp);
  }

  /**
   * Returns the mimetype of the servlet
   */
  protected String getServletMimeType() {
    return "text/json";
  }

  protected void performRequest() throws ServletException, IOException {
    if (doesParameterExist("id", true)) {
      try {
        String molFile = getMolFile(getParameter("db", "acrf"), getParameter("id"));
        JSONObject jSMSCResponse = new JSONObject();
        jSMSCResponse.put("title", "Structure Properties for " + getParameter("id"));

        if (!ExtString.hasLength(molFile)) {
          jSMSCResponse.write(response.getWriter());
          return;
        }
        jSMSCResponse.put("id", getParameter("id"));
        jSMSCResponse.put("db", getParameter("db", "acrf"));

        JSONObject jPreferences = new JSONObject();
        jSMSCResponse.put("preferences", jPreferences);

        for (String preference : getPreferences().keySet()) {
          jPreferences.put(preference, getPreferences().get(preference));
        }

        addStructureDetailJObject(molFile, jSMSCResponse);

        if (getParameter("db", "acrf").equalsIgnoreCase("acrf")) {
          CompoundEntityDetails compoundEntityDetails = new CompoundEntityDetails(this, getParameter("id"), null, false);
          Document doc = compoundEntityDetails.getResponseDocument();

          Set<String> componentIDs = new HashSet<String>(ExtXMLElement.getXPathValues(doc, "//Identifier[@type='component']/@value"));

          for (String componentID : componentIDs) {
            String componentMolFile = getMolFile("ACRFCOMPONENT", componentID);
            if (ExtString.hasLength(componentMolFile)) {
              JSONObject jComp = new JSONObject();
              jComp.put("id", componentID);
              jComp.put("db", "acrf components");
              jSMSCResponse.append("components", addStructureDetailJObject(componentMolFile, jComp));
            }
          }
        }
        jSMSCResponse.write(response.getWriter());
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

  }

  private String getMolFile(String db, String id) {
    try {
      Map<String, String> params = new HashMap<String, String>();
      params.put("db", db);
      params.put("format", "json");
      params.put("id", id);
      params.put("FASF_IDENTITY", new FASFEncrypter().encrypt(getSessionLogin().getRemoteUser()));
      String smscResponse = ExtFile.postURL(smscURL, params);
      JSONObject jSMSCResponse = new JSONObject(smscResponse);
      String molFile = jSMSCResponse.optString("mol");
      return molFile.replaceFirst("[ \\t\\x0B\\f\\r]*\\n", id + '\n');
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  private JSONObject addStructureDetailJObject(String molFile, JSONObject jObj) throws JSONException, CDKException {
    ExtMolecule molecule = new ExtMolecule(molFile);
    if (molecule.getMolecule() != null) {
      jObj.put("mol", molFile);
      jObj.put("smi", molecule.getSMILES());
      Renderer renderer = new Renderer();
      renderer.setMolString(molFile);
      jObj.put("chime_string", renderer.getChimeString());

      JSONObject jContent;

      jContent = new JSONObject();
      jObj.append("contents", jContent);
      jContent.put("name", "MOL");
      jContent.put("value", molFile);

      jContent = new JSONObject();
      jObj.append("contents", jContent);
      jContent.put("name", "SMILES");
      jContent.put("value", molecule.getSMILES());

      jContent = new JSONObject();
      jObj.append("contents", jContent);
      jContent.put("name", "Formula");
      jContent.put("value", molecule.getHillString());

      jContent = new JSONObject();
      jObj.append("contents", jContent);
      jContent.put("name", "Natural Exact Mass (g/mol)");
      jContent.put("value", twoDigitDecimalformat.format(molecule.getNaturalExactMass()));

      jContent = new JSONObject();
      jObj.append("contents", jContent);
      jContent.put("name", "Major Isotope Mass (g/mol)");
      jContent.put("value", twoDigitDecimalformat.format(molecule.getMajorIsotopeMass()));

      jContent = new JSONObject();
      jObj.append("contents", jContent);
      jContent.put("name", "Total Mass Number (g/mol)");
      jContent.put("value", twoDigitDecimalformat.format(molecule.getTotalMassNumber()));

      jContent = new JSONObject();
      jObj.append("contents", jContent);
      jContent.put("name", "Aromatic (Hückel 4n+2 pi-electrons rule)");
      jContent.put("value", (molecule.isAromatic() ? "Yes" : "No"));

      jContent = new JSONObject();
      jObj.append("contents", jContent);
      jContent.put("name", "Atom Count");
      jContent.put("value", molecule.getAtomCount());

      jContent = new JSONObject();
      jObj.append("contents", jContent);
      jContent.put("name", "Heavy Atom Count");
      jContent.put("value", molecule.getHeavyAtomCount());
    }
    return jObj;
  }

  public String getPreferenceGroup() {
    return "Chemical Structures";
  }

  public void setPreference(PreferenceIF preference) {
    if (preference.getPreferenceName().equals("Stereo Group Color Display")) {
      if (!preference.isDefault()) {
        getPreferences().put("stereoGroupColorDisplay", preference.getPreferenceValue().toString().toUpperCase().replace(' ', '_'));
      }
    } else if (preference.getPreferenceName().equals("Background Color")) {
      if (!preference.isDefault()) {
        getPreferences().put("backgroundColor", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Bond Label Size")) {
      if (!preference.isDefault()) {
        getPreferences().put("bondLabelSize", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Color Atoms By Type")) {
      if (!preference.isDefault()) {
        getPreferences().put("colorAtomsByType", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Default BondLength")) {
      if (!preference.isDefault()) {
        getPreferences().put("defaultBondLength", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Display Chiral Stereo Labels")) {
      if (!preference.isDefault()) {
        getPreferences().put("displayChiralStereoLabels", preference.getPreferenceValue().toString().toUpperCase().replace(' ', '_'));
      }
    } else if (preference.getPreferenceName().equals("Foreground Color")) {
      if (!preference.isDefault()) {
        getPreferences().put("foregroundColor", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Hydrogen Display Mode")) {
      if (!preference.isDefault()) {
        getPreferences().put("hydrogenDisplayMode", preference.getPreferenceValue().toString().toUpperCase().replace(' ', '_'));
      }
    } else if (preference.getPreferenceName().equals("Label Height")) {
      if (!preference.isDefault()) {
        getPreferences().put("labelHeight", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Pol Atom Display Mode")) {
      if (!preference.isDefault()) {
        getPreferences().put("polAtomDisplayMode", preference.getPreferenceValue().toString().toUpperCase().replace(' ', '_'));
      }
    } else if (preference.getPreferenceName().equals("Stereo Abs Color")) {
      if (!preference.isDefault()) {
        getPreferences().put("stereoAbsColor", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Stereo And Color")) {
      if (!preference.isDefault()) {
        getPreferences().put("stereoAndColor", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Stereo Or Color")) {
      if (!preference.isDefault()) {
        getPreferences().put("stereoOrColor", (String) preference.getPreferenceValue());
      }
    }
  }

  /**
   * @return the preferences
   */
  public Map<String, String> getPreferences() {
    return (preferences== null ?  preferences= new HashMap<String, String>() : preferences);
  }

}
