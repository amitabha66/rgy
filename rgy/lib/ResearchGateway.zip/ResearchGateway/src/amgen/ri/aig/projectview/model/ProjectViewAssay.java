package amgen.ri.aig.projectview.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.jdom.Element;

import amgen.ri.util.ExtArray;

/**
 * Holds an assay definition for the project view
 */
public class ProjectViewAssay implements Serializable {
    private String displayName;
    private String assayClass;
    private String assayName;
    private String assayID;
    private String assayCode;
    private List<ProjectViewAssayResult> assayResults;


    public ProjectViewAssay(Element assayEl) {
        super();
        this.displayName = assayEl.getAttributeValue("display_name");
        this.assayClass = assayEl.getAttributeValue("assay_class");
        this.assayName = assayEl.getAttributeValue("assay_name");
        this.assayID = assayEl.getAttributeValue("assay_id");
        this.assayCode = assayEl.getAttributeValue("assay_code");
        this.assayResults = new ArrayList<ProjectViewAssayResult>();
        List<Element> propertyEls = assayEl.getChildren("Property");

        for (Element propertyEl : propertyEls) {
            assayResults.add(new ProjectViewAssayResult(propertyEl));
        }

        this.assayResults = ExtArray.sort(this.assayResults, new Comparator() {
            public int compare(Object obj1, Object obj2) {
                ProjectViewAssayResult r1 = (ProjectViewAssayResult) obj1;
                ProjectViewAssayResult r2 = (ProjectViewAssayResult) obj2;
                int pid1 = r1.getPid();
                int pid2 = r2.getPid();
                return (pid1 < pid2 ? -1 : (pid1 == pid2 ? 0 : 1));
            }
        });

    }

    /**
     * Returns the displayed name for the assay
     *
     * @return String
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Returns the assay class
     *
     * @return String
     */
    public String getAssayClass() {
        return assayClass;
    }

    /**
     * Returns the name of the name as defined in the catelog
     *
     * @return String
     */
    public String getAssayName() {
        return assayName;
    }

    /**
     * Returns the assay ID
     *
     * @return String
     */
    public String getAssayID() {
        return assayID;
    }

    /**
     * Returns the assay code
     *
     * @return String
     */
    public String getAssayCode() {
        return assayCode;
    }

    public List<ProjectViewAssayResult> getAssayResults() {
        return assayResults;
    }

}
