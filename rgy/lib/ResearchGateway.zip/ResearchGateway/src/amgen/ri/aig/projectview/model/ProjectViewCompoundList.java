package amgen.ri.aig.projectview.model;

import java.io.IOException;

import org.jdom.Element;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.entitylist.EntityList;
import amgen.ri.aig.entitylist.PagingEntityList;

/**
 * Contains a compound list used in the project view
 */
public class ProjectViewCompoundList extends ProjectViewList {
    private String listType;
    private int listMemberCount;


    protected ProjectViewCompoundList(String id, String name, String listType, boolean isDefault) {
        this(id, name, isDefault);
        this.listType = listType;
    }

    protected ProjectViewCompoundList(String id, String name, String listType, boolean isDefault, int listMemberCount) {
        this(id, name, isDefault);
        this.listType = listType;
        this.listMemberCount = listMemberCount;
    }

    protected ProjectViewCompoundList(EntityList entityList) {
        this(entityList.getIdentifier(), entityList.getListName(), false);
        listType = entityList.getListType();
    }

    protected ProjectViewCompoundList(Element listElement) {
        this(listElement.getAttributeValue("list_id"),
             listElement.getAttributeValue("name"),
             Boolean.valueOf(listElement.getAttributeValue("default")).booleanValue());
    }

    protected ProjectViewCompoundList(String id, String name, boolean isDefault) {
        super(id, name);
        listType = "VIEW_DATA_TEMPLATE";
        listMemberCount = -1;
        isDefault(isDefault);
    }

    public PagingEntityList getPagedCompoundList(AIGServlet requestor) throws IOException, AIGException {
        return ProjectViewModel.getPagedCompoundList(requestor, getId());
    }

    public String getListType() {
        return listType;
    }

    /**
     * Returns the number of members in the provided List
     */
    public int getListMemberCount() {
        return (listMemberCount < 0 ? super.getListMemberCount() : listMemberCount);
    }

}
