/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.service;

import amgen.ri.aig.cache.item.GlobalCacheItem;
import amgen.ri.aig.cache.ora.OfflineServiceDetails;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import java.io.Serializable;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author jemcdowe
 */
public class ServiceKeyCacheResponse implements Iterable<String>, Serializable {

  static final long serialVersionUID = -8047291451273405684L;

  private Set<String> serviceKeys;
  private Map<String, ServiceDetails> services;

  public ServiceKeyCacheResponse() {
    serviceKeys = new LinkedHashSet<String>();
    services = new HashMap<String, ServiceDetails>();
  }

  public ServiceKeyCacheResponse(Collection<String> serviceKeys) {
    this();
    this.serviceKeys.addAll(serviceKeys);
  }

  public Set<String> getServiceKeys() {
    return serviceKeys;
  }

  public void addServiceKey(String serviceKey) {
    if (!serviceKeys.contains(serviceKey)) {
      serviceKeys.add(serviceKey);
    }
  }

  public void addServiceKeys(Collection<String> serviceKeys) {
    this.serviceKeys.addAll(serviceKeys);
  }

  public void removeServiceKey(String serviceKey) {
    this.serviceKeys.remove(serviceKey);
    this.services.remove(serviceKey);
  }

  public void addServiceDetails(Collection<ServiceDetails> serviceDetails) {
    if (serviceDetails != null) {
      for(ServiceDetails service : serviceDetails) {
        addServiceDetails(service);
      }
    }
  }

  public void addServiceDetails(ServiceDetails serviceDetails) {
    if (serviceDetails != null) {
      if (serviceDetails instanceof OfflineServiceDetails) {
        removeServiceKey(serviceDetails.getKey());
      } else {
        addServiceKey(serviceDetails.getKey());
        services.put(serviceDetails.getKey(), serviceDetails);
      }
    }
  }

  public void addServiceDetailsFromGlobalCacheItems(Collection<GlobalCacheItem> serviceCacheItems) {
    for (GlobalCacheItem service : serviceCacheItems) {
      if (service.getCacheObject() instanceof ServiceDetails) {
        addServiceDetails((ServiceDetails) service.getCacheObject());
      }
    }
  }

  public ServiceDetails getServiceDetails(String serviceKey) {
    return services.get(serviceKey);
  }

  public boolean hasServiceDetails(String serviceKey) {
    return services.containsKey(serviceKey);
  }

  public Iterator<String> iterator() {
    return serviceKeys.iterator();
  }

  public boolean isEmpty() {
    return serviceKeys.isEmpty();
  }

  public int size() {
    return serviceKeys.size();
  }

  void update(ServiceKeyCacheResponse serviceKeyCacheResponse) {
    this.serviceKeys.addAll(serviceKeyCacheResponse.serviceKeys);
    this.services.putAll(serviceKeyCacheResponse.services);
  }

}
