/*
 *   DocumentType
 *   RDBData wrapper class for DOCUMENTTYPES
 *   $Revision: 1.1 $
 *   Created: Jeffrey McDowell, 27 Apr 2009
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.documents;


import java.lang.reflect.Field;

import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.SQLManagerIF;

/**
 *   RDBData wrapper class for DOCUMENTTYPES
 *   @version $Revision: 1.1 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class DocumentType extends RdbData {
    protected int type_id;
    protected String extension;
    protected String mimetype;
    protected String importable;
    protected String commonname;

    /**
     * Default Constructor
     */
    public DocumentType() {
        super();
    }

    /**
     * RdbData Constructor
     */
    public DocumentType(String type_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.type_id = Integer.parseInt(type_id);
    }

    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return type_id + "";
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }

    /** This method returns the name of the table. */
    protected String getTableName() {
        return "DOCUMENTTYPES";
    }

    /**
     * Returns the primary key fields for the RdbData class which are used to
     * generate the SQL statement(s). If this returns null (the Default), the first field of the class is assumed.
     * The getIdentifier() method must return, in CSV, the matching number of elements as this array if generated SQL is used.
     */
    public String[] getPrimaryKeyFields() {
        return new String[] {"type_id"};
    }

    /** Get value for type_id */
    public int getType_id() {
        return getAsNumber("type_id", false).intValue();
    }

    /** Get value for extension */
    public String getExtension() {
        return (String) get("extension");
    }

    /** Get value for mimetype */
    public String getMimetype() {
        return (String) get("mimetype");
    }

    /** Get value for importable */
    public String getImportable() {
        return (String) get("importable");
    }

    /** Get value for commonname */
    public String getCommonname() {
        return (String) get("commonname");
    }

}
