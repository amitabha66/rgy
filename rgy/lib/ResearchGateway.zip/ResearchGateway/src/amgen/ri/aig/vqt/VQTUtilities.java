package amgen.ri.aig.vqt;

import org.jdom.Document;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.service.ServiceCacheResponse;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.uddi.ServiceQuery;
import amgen.ri.asf.sa.uddi.ClassificationSchemeQuery;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.json.JSONArray;
import amgen.ri.util.ExtString;
import com.google.common.collect.Iterables;
import java.net.SocketTimeoutException;

/**
 * @version $Id: VQTUtilities.java,v 1.9 2014/07/08 15:51:48 jemcdowe Exp $
 */
public class VQTUtilities {
  private AIGBase requestor;
  private ServiceDetails vqtServiceDetails;

  public VQTUtilities(AIGBase requestor) {
    this.requestor = requestor;
    try {
      ClassificationSchemeQuery query = new ClassificationSchemeQuery();
      query.addKeyValue(TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME, "VQTENGINE");
      ServiceCacheResponse serviceResults= requestor.getServiceCache().getServices(new ServiceQuery(query));
      if (serviceResults.isEmpty()) {
        throw new AIGException("Unable to load VQT Engine", AIGException.Reason.UNKNOWN);
      }
      vqtServiceDetails = Iterables.getFirst(serviceResults, null);
      requestor.setServiceParameters(vqtServiceDetails, null);
    } catch (AIGException ex) {
    }
  }

  public ServiceDetails getVQTServiceDetails() {
    return vqtServiceDetails;
  }

  public int executeQuery(String queryRequest, String target) throws AIGException {
    int queryRunID = -1;
    target = (ExtString.hasLength(target) ? target : "RG");
    vqtServiceDetails.setParameterValue("QueryRequest", queryRequest);
    vqtServiceDetails.setParameterValue("op", "SEARCH");
    vqtServiceDetails.setParameterValue("target", target);
    if (vqtServiceDetails.isServiceReady()) {
      try {
        Object vqtResult = vqtServiceDetails.executeService();
        requestor.addRequestLogServiceInvocationDetails(vqtServiceDetails);
        if (vqtResult != null) {
          if (vqtResult instanceof Number) {
            queryRunID = ((Number) vqtResult).intValue();
          } else if (vqtResult instanceof String) {
            queryRunID = Integer.valueOf(new String((byte[]) vqtResult)).intValue();
          } else if (vqtResult instanceof byte[]) {
            queryRunID = Integer.valueOf(new String((byte[]) vqtResult)).intValue();
          }
        }
      } catch (SocketTimeoutException se) {
        throw new AIGException("Your query exceeded the time allowed. Please refine and narrow query.", AIGException.Reason.TIMEOUT, se);
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return queryRunID;
  }

  public Document getSavedQueries(EntityListCategory entityType) {
    vqtServiceDetails.setParameterValue("QueryRequest", entityType.toString());
    vqtServiceDetails.setParameterValue("op", "SAVED_QUERIES");
    if (vqtServiceDetails.isServiceReady()) {
      try {
        Document savedQueries = vqtServiceDetails.executeService2JDocument();
        requestor.addRequestLogServiceInvocationDetails(vqtServiceDetails);
        return savedQueries;
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return null;
  }

  public Document executeEntityIDQuery(int queryID) {
    int queryRunID = -1;
    vqtServiceDetails.setParameterValue("QueryRequest", queryID + "");
    vqtServiceDetails.setParameterValue("op", "ENTITY_IDS");
    if (vqtServiceDetails.isServiceReady()) {
      try {
        Document entityIDs = vqtServiceDetails.executeService2JDocument();
        requestor.addRequestLogServiceInvocationDetails(vqtServiceDetails);
        return entityIDs;
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return null;
  }

  public int getEntityCountResultCount(String queryRequest) {
    int resultCount = -1;
    vqtServiceDetails.setParameterValue("QueryRequest", queryRequest);
    vqtServiceDetails.setParameterValue("op", "ENTITY_COUNT");

    if (vqtServiceDetails.isServiceReady()) {
      try {
        Object vqtResult = vqtServiceDetails.executeService();
        requestor.addRequestLogServiceInvocationDetails(vqtServiceDetails);
        if (vqtResult != null) {
          if (vqtResult instanceof Number) {
            resultCount = ((Number) vqtResult).intValue();
          } else if (vqtResult instanceof byte[]) {
            resultCount = Integer.valueOf(new String((byte[]) vqtResult)).intValue();
          }
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return resultCount;
  }

  public JSONArray getFolderItems(String node) {
    vqtServiceDetails.setParameterValue("QueryRequest", "folderitems");
    vqtServiceDetails.setParameterValue("node", node);
    vqtServiceDetails.setParameterValue("op", "FOLDERITEMS");

    if (vqtServiceDetails.isServiceReady()) {
      try {
        String vqtResult = vqtServiceDetails.executeService2String();
        requestor.addRequestLogServiceInvocationDetails(vqtServiceDetails);

        if (vqtResult != null) {
          return new JSONArray(vqtResult);
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return null;
  }
}
