package amgen.ri.aig.proxy;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.aig.AIGServlet;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtNet;
import amgen.ri.util.ExtString;
import amgen.ri.util.ExtURL;
import amgen.ri.xml.ExtXMLElement;
import java.io.FileWriter;
import org.apache.commons.collections.EnumerationUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.message.BasicHeader;
import org.jdom.Document;

/**
 * Simple proxy which forwards the all params to the URL in the param 'src' as POST. Response is sent via a pass-through
 * to the servlet OutputStream. Nothing is set for the content type. If you need to set a content type, use XMLDataProxy
 * or subclass.
 *
 * <p>
 *
 * @version $Id: DataProxy.java,v 1.16 2015/11/13 23:48:57 jemcdowe Exp $ </p>
 *
 */
public class DataProxy extends AIGServlet {

  private final String[] PROXIED_HEADERS = {
    "Accept", "Accept-Charset", "Accept-Encoding", "Accept-Language", "Content-Type", "Date", "Expect", "From", "Pragma", "Warning",};

  public DataProxy() {
  }

  /**
   * Standard constructor which creates a new AIGServlet
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   */
  public DataProxy(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  /**
   * Returns the getAIGServlet implementation class for the request
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return AIGServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new DataProxy(req, resp);
  }

  /**
   * Returns the mimetype of the servlet used to setContentType
   *
   * @return String
   */
  protected String getServletMimeType() {
    if (doesParameterExist("contentType", true)) {
      return getParameter("contentType");
    } else {
      return "";
    }
  }

  /**
   * Handles the servlet request
   *
   * @throws Exception
   */
  protected void performRequest() throws Exception {
    if (!doesParameterExist("src", true)) {
      return;
    }
    URL srcURL = new URL(getParameter("src"));
    Map<String, String> parameters = new HashMap<String, String>();

    for (String paramName : getParameterNames()) {
      if (!paramName.equals("src") && !paramName.equals("contentType")) {
        parameters.put(paramName, getParameter(paramName));
      }
    }
    response.setCharacterEncoding("UTF-8");
    writeResponse(srcURL, parameters, response.getOutputStream());
  }

  /**
   * Handles the proxy request
   *
   * @param srcURL Source URL object
   * @param parameters HTTP decoded parameters
   * @param out OutputStream to send the response
   * @throws Exception
   */
  protected void writeResponse(URL srcURL, Map<String, String> parameters, OutputStream out) throws Exception {
    try {
      ExtNet httpClient = getHttpClient();
      for (String headerName : (List<String>) EnumerationUtils.toList(request.getHeaderNames())) {
        if (ExtString.inIgnoreCase(headerName, PROXIED_HEADERS)) {
          httpClient.addHeader(new BasicHeader(headerName, request.getHeader(headerName)));
        }
      }

      if (StringUtils.isNotEmpty(srcURL.getQuery())) {
        Map<String, String[]> queryStringMap = ExtURL.parseUrlQueryString(srcURL.getQuery());
        if (parameters == null) {
          parameters = new HashMap<String, String>();
        }
        for (String paramName : queryStringMap.keySet()) {
          String[] paramValues = queryStringMap.get(paramName);
          if (ExtArray.hasLength(paramValues)) {
            parameters.put(paramName, paramValues[0]);
          }
        }
        srcURL = new URL(srcURL.getProtocol(), srcURL.getHost(), srcURL.getPort(), srcURL.getPath());
      }

      StringBuffer requestParameters = new StringBuffer();
      if (parameters != null) {
        for (String paramName : parameters.keySet()) {
          if (requestParameters.length() > 0) {
            requestParameters.append("&");
          }
          requestParameters.append(URLEncoder.encode(paramName, "UTF-8") + "=" + URLEncoder.encode(parameters.get(paramName), "UTF-8"));
        }
      }

      switch (getMethodType()) {
        case GET:
          URL getURL = new URL(srcURL + (requestParameters.length() > 0 ? "?" + requestParameters : ""));
          httpClient.writeHttp2Stream(getURL, out);
          break;
        case POST:
          httpClient.writeHttp2StreamViaPost(srcURL, parameters, out);
          break;
        case UNKNOWN:
          throw new IOException("Unknown request method");
      }
    } catch (Exception e) {
      e.printStackTrace();
      System.err.println("Message: " + e + " URL: " + srcURL);
    }
  }

}
