/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.store;

import amgen.ri.aig.items.ItemsHandler;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.favorites.SimpleFavoriteHandler;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONObject;
import amgen.ri.xml.ExtXMLElement;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;

/**
 *
 * @author jemcdowe
 */
public class StoreRequestHandler extends AIGServlet implements StoreRequestHandlerIF {
  public enum StoreRequestType {
    LISTS, SERVICES, RGAPPS, PEOPLE, FAVORITES, ITEMS, UNKNOWN;

    public static StoreRequestType fromString(String s) {
      try {
        return StoreRequestType.valueOf(s.toUpperCase());
      } catch (Exception e) {
        return UNKNOWN;
      }
    }
  };
  protected StoreRequestType requestType;
  protected ResponseFormatType responseType;

  public StoreRequestHandler() {
  }

  public StoreRequestHandler(AIGServlet aigServlet) {
    super(aigServlet);
    this.responseType = ResponseFormatType.fromString(aigServlet.getParameter("responseFormat"));
    this.requestType = StoreRequestType.fromString(aigServlet.getParameter("request"));
  }

  public StoreRequestHandler(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
    this.responseType = ResponseFormatType.fromString(getParameter("responseFormat"));
    this.requestType = StoreRequestType.fromString(getParameter("request"));
  }

  @Override
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    switch (StoreRequestType.fromString(req.getParameter("request"))) {
      case LISTS:
        return new ListsStoreRequestHandler(req, resp);
      case SERVICES:
        return new ServiceQueryHandler(req, resp).getAIGServlet(req, resp);
      case RGAPPS:
        return new RGLoftHandler(req, resp);
      case PEOPLE:
        return new SimplePersonQueryHandler(req, resp);
      case FAVORITES:
        return new SimpleFavoriteHandler(req, resp);
      case ITEMS:
        return new ItemsHandler(req, resp);
    }
    try {
      resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Unknown request");
    } catch (IOException ex) {
    }
    throw new IllegalArgumentException("Invalid request");
  }

  @Override
  protected void performRequest() throws Exception {
    try {
      switch (responseType) {
        case JSON:
          JSONObject json = generateJSONResponse();          
          json.write(response.getWriter());
          return;
        case JSONARRAY:
          JSONArray jArray = generateJSONArrayResponse();          
          jArray.write(response.getWriter());
          return;          
        case XML:
          Document doc = generateXMLResponse();
          ExtXMLElement.write(doc, response.getWriter());
          return;
        case RAW:
          writeRawResponse();
          return;
      }
    } catch (IllegalArgumentException e) {
      sendErrorHttpResponseHeader(e);
    }
  }

  @Override
  protected String getServletMimeType() {
    switch (responseType) {
      case RAW:
        return "application/octet-stream";
      case XML:
        return "text/xml";
      case JSON:
      default:
        return "text/plain";
    }
  }

  @Override
  public JSONObject generateJSONResponse() throws Exception {
    throw new UnsupportedOperationException("Should not get here.");
  }

  public JSONArray generateJSONArrayResponse() throws Exception {
    throw new UnsupportedOperationException("Should not get here.");
  }

  @Override
  public Document generateXMLResponse() throws Exception {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  @Override
  public void writeRawResponse() throws Exception {
    throw new UnsupportedOperationException("Not supported yet.");
  }
}
