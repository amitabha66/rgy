package amgen.ri.aig.event;

import amgen.ri.json.ExtJSON;
import amgen.ri.servlet.FASFParameterEncoderIF;
import amgen.ri.util.ExtBase64;

/**
 * Implementation of the FASFParameterEncoderIF to BASE64 encode JSON parameters
 * @version $Id: FASFParameterEncoder.java,v 1.2 2011/06/21 17:28:58 cvs Exp $
 */
public class FASFParameterEncoder implements FASFParameterEncoderIF {
    public FASFParameterEncoder() {
    }

    /**
     * For a given parameter, return the encoded value.
     *
     * @param name String
     * @param value String
     * @return String
     * @todo Implement this amgen.ri.servlet.FASFParameterEncoderIF method
     */
    public String encodeParameter(String name, String value) {
        if (ExtJSON.isJSON(value)) {
            return ExtBase64.encodeToString(value.getBytes(), false);
        }
        return value;
    }
}
