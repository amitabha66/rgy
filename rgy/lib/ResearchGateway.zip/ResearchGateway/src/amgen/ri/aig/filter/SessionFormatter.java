package amgen.ri.aig.filter;

import java.io.Serializable;
import java.text.DecimalFormat;

/**
 * @version $Id: SessionFormatter.java,v 1.2 2012/01/18 06:26:17 cvs Exp $
 *
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class SessionFormatter implements Serializable {
    private DecimalFormat integerFormat = new DecimalFormat("0");
    private DecimalFormat fourDecimalFixedFormat = new DecimalFormat("0.####");
    private DecimalFormat fourDecimalScientficFormat = new DecimalFormat("0.####E0");

    public SessionFormatter() {
        super();
    }

    public String format(Object value, String source) {
        if (value == null) {
            return value + "";
        }
        if (value instanceof Integer) {
            return formatInteger((Integer) value, source);
        }
        if (value instanceof Number) {
            return formatDouble(((Number) value).doubleValue(), source);
        }
        return value + "";
    }

    public String formatInteger(int value, String source) {
        return integerFormat.format(value);
    }

    public String formatDouble(double value, String source) {
        if (value < 0.0001 && value != 0) {
            return fourDecimalScientficFormat.format(value);
        } else {
            return fourDecimalFixedFormat.format(value);
        }
    }

    public String formatInteger(Number value, String source) {
        return integerFormat.format(value);
    }

    public String formatDouble(Number value, String source) {
        return fourDecimalFixedFormat.format(value);
    }


}
