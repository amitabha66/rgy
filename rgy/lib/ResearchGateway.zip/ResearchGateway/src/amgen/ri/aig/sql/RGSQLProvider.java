package amgen.ri.aig.sql;

import java.io.File;

import javax.servlet.ServletContext;

import amgen.ri.sql.GenericSQLProvider;

/**
 * <p>@version $Id: RGSQLProvider.java,v 1.7 2013/07/09 18:32:09 jemcdowe Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class RGSQLProvider extends GenericSQLProvider {
  public static String CONFIG_FILENAME = "rg.sql.xml";

  public RGSQLProvider() {
    super(RGSQLProvider.class, CONFIG_FILENAME);
  }

  public String getSQL(String name) {
    return (getSQLQuery(name) == null ? null : getSQLQuery(name).getSql());

  }
}
