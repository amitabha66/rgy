/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.uddi;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.asf.sa.uddi.BindingDetails;
import amgen.ri.asf.sa.uddi.CategoryKeyValue;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtArray;
import amgen.ri.xml.ExtXMLElement;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;

public class RecentServiceLookup extends AbstractServiceLookup implements ServiceLookupIF {
  private int MAX_RECENT_SERVICES= 5;
  public enum ServiceLookupType {
    QUERYSERVICES;

    public static ServiceLookupType fromString(String s) {
      try {
        return ServiceLookupType.valueOf(s.toUpperCase());
      } catch (Exception e) {
        return QUERYSERVICES;
      }
    }
  };
  private ServiceLookupType serviceLookupType;

  /**
   * Default constructor
   */
  public RecentServiceLookup() {
    super();
  }

  public RecentServiceLookup(AIGServlet aigServlet) {
    super(aigServlet);
    serviceLookupType = ServiceLookupType.fromString(getParameter("serviceType"));
  }

  /**
   * Main constructor- used only by the getAIGServlet method
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   */
  private RecentServiceLookup(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
    serviceLookupType = ServiceLookupType.fromString(getParameter("serviceType"));
  }

  /**
   * Creates this AIG Servlet object
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return AIGServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new RecentServiceLookup(req, resp);
  }

  /**
   * Returns the mimetype of the servlet
   */
  @Override
  protected String getServletMimeType() {
    return "text/xml";
  }

  /**
   * Actual work entry stub
   *
   * @throws ServletException
   * @throws IOException
   */
  @Override
  protected void performRequest() throws ServletException, IOException {
    try {
      ExtXMLElement.write(getServicesDocument(), response.getWriter());
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  @Override
  public Document getServicesDocument() throws JDOMException, AIGException {
    Document servicesDocument = new Document(new Element("Services"));
    try {
      Map<String, ServiceDetails> searchServices = getRecentServiceDetails();
      for (String serviceKey : searchServices.keySet()) {
        if (servicesDocument.getRootElement().getContentSize() < MAX_RECENT_SERVICES) {
          ServiceDetails service = searchServices.get(serviceKey);
          String[] resultTypes = null;
          switch (serviceLookupType) {
            case QUERYSERVICES:
            default:
              resultTypes = new String[]{TModelCommonNameFactory.QUERYTREENODESDEFINITION_tMODELNAME,
                TModelCommonNameFactory.QUERYRGRAWENTITYTABLEDEFINITION_TMODELNAME};
              break;
          }
          boolean serviceHasValidResultType = false;
          for (String resultType : resultTypes) {
            if (ExtArray.hasLength(service.getBindingByTModelName(resultType))) {
              serviceHasValidResultType = true;
              break;
            }
          }

          if (serviceHasValidResultType) {
            if (service.containsUserInAllowedUsers(getSessionLogin().getRemoteUser(), true)) {
              ServiceAttributes serviceAttributes = new ServiceAttributes(service, getEntityClassManager());
              Element searchServiceElement = getServiceElement(service);
              if (searchServiceElement != null) {
                boolean showResources = true;
                BindingDetails rawTableBinding = service.getResultTypeBinding(TModelCommonNameFactory.QUERYRGRAWENTITYTABLEDEFINITION_TMODELNAME);
                if (rawTableBinding != null || serviceAttributes.getEntityListCategory().size() > 1) {
                  showResources = false;
                }
                servicesDocument.getRootElement().addContent(searchServiceElement);
                ExtXMLElement.addTextElement(searchServiceElement, "ID", UUID.randomUUID() + "");
                Element nameElement = searchServiceElement.getChild("Name");
                nameElement.setText(serviceAttributes.getName(ServiceNamingContext.RG_QUERY));
                Element descElement = searchServiceElement.getChild("Description");
                descElement.setText(serviceAttributes.getDescription(ServiceNamingContext.RG_QUERY));
                ExtXMLElement.addElement(searchServiceElement, "EditableParams", serviceAttributes.countEditableParameters(null) + "");
                ExtXMLElement.addElement(searchServiceElement, "IconCls", serviceAttributes.getIconClass(ServiceNamingContext.RG_LOFT));
                CategoryKeyValue orgCatValue = serviceAttributes.getOrganizationCategoryKeyValue();
                ExtXMLElement.addTextElement(searchServiceElement, "Category", (orgCatValue == null ? "Other" : orgCatValue.getKeyName()));
                ExtXMLElement.addTextElement(searchServiceElement, "CategoryTag", serviceAttributes.getFirstEntityListCategoryLabel());
                ExtXMLElement.addTextElement(searchServiceElement, "EntityCategory", serviceAttributes.getFirstEntityListCategory() + "");
                ExtXMLElement.addTextElement(searchServiceElement, "ShowResources", showResources + "");
              }
            }
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return servicesDocument;
  }

  @Override
  public JSONObject getServiceRecords() throws JDOMException, AIGException {
    return getServiceRecords(getServicesDocument());
  }
}
