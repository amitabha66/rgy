package amgen.ri.aig.convert;

import java.io.File;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;

import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtString;

/**
 * @version $id$
 *
 */
public class JSONTable2ExcelHandler extends AIGServlet {
    public JSONTable2ExcelHandler() {
        super();
    }

    public JSONTable2ExcelHandler(HttpServletRequest req, HttpServletResponse resp) {
        super(req, resp);
    }

    public JSONTable2ExcelHandler(AIGServlet aigServlet) {
        super(aigServlet);
    }

    /**
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return TBXServlet
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new JSONTable2ExcelHandler(req, resp);
    }

    /**
     *
     * @return String
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected String getServletMimeType() {
        return "application/vnd.ms-excel";
    }

    /**
     *
     * @throws Exception
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected void performRequest() throws Exception {
        try {
            JSONObject tableJSON = getJSONObjectParameter("table");
            String filename = tableJSON.optString("title", "rg") + ".xls";
            response.addHeader("Content-disposition",
                               "attachment; filename=" + filename.replaceAll("\\s+", "_"));
            HSSFWorkbook wb = createExcel(tableJSON);
            wb.write(response.getOutputStream());
            response.getOutputStream().flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public HSSFWorkbook createExcel(JSONObject table) throws JSONException {
        AIGSessionLogin sessionLogin = AIGSessionLogin.getAIGSessionLogin(request);
        File workDir = sessionLogin.createWorkDir();
        HSSFWorkbook wb = new HSSFWorkbook();

        HSSFCellStyle columnHeaderXLStyle = wb.createCellStyle();
        HSSFFont columnHeaderXLFont = wb.createFont();
        columnHeaderXLFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        columnHeaderXLStyle.setFont(columnHeaderXLFont);

        HSSFCellStyle subdataXLStyle = wb.createCellStyle();
        subdataXLStyle.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
        HSSFFont subdataXLFont = wb.createFont();
        subdataXLFont.setColor(new HSSFColor.GREY_50_PERCENT().getIndex());
        subdataXLStyle.setFont(subdataXLFont);

        HSSFSheet sheet = wb.createSheet(ExtString.truncate(ExtString.getSafeFileName(table.optString("title", "Sheet 1")), 30, false));
        int rowCounter = 0;
        //Create the ColumnGroup headers
        HSSFRow columnGroupHeaderXLRow = sheet.createRow(rowCounter);
        short cellCounter = 0;
        JSONArray columns = table.getJSONArray("columns");
        HSSFRow columnHeaderXLRow = sheet.createRow(rowCounter++);
        for (int i = 0; i < columns.length(); i++) {
            JSONObject column = columns.getJSONObject(i);
            String header = column.getString("header");
            String type = column.getString("type");
            HSSFCell columnGroupXLCell = columnHeaderXLRow.createCell(cellCounter++);
            columnGroupXLCell.setCellStyle(columnHeaderXLStyle);
            columnGroupXLCell.setCellValue(StringEscapeUtils.unescapeXml(header));
        }
        JSONArray rows = table.getJSONArray("rows");

        for (int i = 0; i < rows.length(); i++) {
            JSONArray row = rows.getJSONArray(i);
            HSSFRow xlRow = sheet.createRow(rowCounter++);
            xlRow.setHeightInPoints((float) 12.75);
            cellCounter = 0;
            for (int j = 0; j < row.length(); j++) {
                HSSFCell xlDataCell = xlRow.createCell(cellCounter++);
                Object cell = row.get(j);
                String value;
                if (cell instanceof JSONObject) {
                    JSONObject cellObj = row.getJSONObject(j);
                    value = cellObj.optString("value", "");
                    String type = cellObj.optString("celltype", "");
                    if (ExtString.equalsIgnoreCase(type, "subdata")) {
                        xlDataCell.setCellStyle(subdataXLStyle);
                    }
                } else {
                    value = ExtString.toString(cell, "");
                }
                if (ExtString.isANumber(value)) {
                    xlDataCell.setCellValue(ExtString.toDouble(value));
                } else {
                    xlDataCell.setCellValue(StringEscapeUtils.unescapeXml(value.replaceAll("\\s+", " ")));
                }
            }
        }
        return wb;
    }
}
