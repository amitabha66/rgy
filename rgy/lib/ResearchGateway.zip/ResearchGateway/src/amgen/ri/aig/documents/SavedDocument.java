/*
 *   Documents
 *   RDBData wrapper class for Documents
 *   $Revision: 1.2 $
 *   Created: Jeffrey McDowell, 27 Apr 2009
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.documents;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import amgen.ri.rdb.BlobData;
import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.rdb.SQLManagerIF;
import amgen.ri.servlet.SessionLogin;

/**
 *   RDBData wrapper class for Documents
 *   @version $Revision: 1.2 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class SavedDocument extends RdbData {
  protected int document_id;
  protected DocumentType type_id;
  protected String name;
  protected String description;
  protected int folder_id;
  protected int document_size_kb;
  protected Timestamp created;
  protected String created_by;
  protected Timestamp modified;
  protected String modified_by;
  protected BlobData file_obj;
  protected DocumentTag[] tags;

  /**
   * Default Constructor
   */
  public SavedDocument() {
    super();
  }

  /**
   * RdbData Constructor
   */
  public SavedDocument(String document_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
    this.document_id = Integer.parseInt(document_id);
  }

  /** A required method which returns the primary key(s) of the table/RdbData class. */
  public String getIdentifier() {
    return document_id + "";
  }

  /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
  protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
    field.set(this, value);
  }

  /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
  protected Object getFieldValue(Field field) throws IllegalAccessException {
    return field.get(this);
  }

  /**
   * Returns the table name used when generating the SQL command. If this returns null, the Class name
   * is assumed to be the table name. Not used if generateSQL() is false or
   * getSQL() is not null. Default implementation returns null.
   */
  public String getTableName() {
    return "DOCUMENTS";
  }

  public static List<SavedDocument> findDocuments(String tagType, String tagValue, SQLManagerIF sqlManager, SessionLogin sessionLogin, String connectionMgr) throws Exception {
    if (tagValue == null) {
      return new ArrayList<SavedDocument>();
    }
    String findDocumentsSQL =
            "SELECT D.DOCUMENT_ID FROM DOCUMENTS D, DOCUMENTTAGS DT WHERE D.TYPE_ID>0 AND (D.IS_PUBLIC='Y' OR D.CREATED_BY=?) AND "
            + "D.DOCUMENT_ID= DT.DOCUMENT_ID AND DT.TAG_TYPE=? AND CONTAINS(TAG_VALUE, ?)>0";

    return new RdbDataArray(SavedDocument.class, findDocumentsSQL,
            new String[]{
              sessionLogin.getRemoteUser(),
              tagType,
              tagValue
            }, sqlManager, null, connectionMgr);
  }

  public String getName() {
    return (String) get("name");
  }

  public String getDescription() {
    return (String) get("description");
  }

  public DocumentType getType() {
    return (DocumentType) get("type_id");
  }

  public Timestamp getCreated() {
    return (Timestamp) get("created");
  }

  public String getCreatedBy() {
    return (String) get("created_by");
  }

  public BlobData getFileContents() {
    return (BlobData) get("file_obj");
  }

  public String getImage() {
    String imageFile;
    if (getType().getMimetype().equals("application/msaccess")) {
      imageFile = "access.gif";
    } else if (getType().getMimetype().equals("application/vnd.ms-excel")) {
      imageFile = "excel.gif";
    } else if (getType().getMimetype().equals("application/vnd.ms-powerpoint")) {
      imageFile = "powerpoint.gif";
    } else if (getType().getMimetype().equals("application/msproject")) {
      imageFile = "project.gif";
    } else if (getType().getMimetype().equals("application/msword")) {
      imageFile = "word.gif";
    } else if (getType().getMimetype().equals("application/mswrite")) {
      imageFile = "write.gif";
    } else if (getType().getMimetype().equals("application/msoutlook")) {
      imageFile = "outlook.gif";
    } else if (getType().getMimetype().equals("application/visio")) {
      imageFile = "visio.gif";
    } else if (getType().getMimetype().equals("application/pdf")) {
      imageFile = "pdf.gif";
    } else if (getType().getMimetype().equals("application/rft")) {
      imageFile = "rft.gif";
    } else if (getType().getMimetype().equals("image/bmp")) {
      imageFile = "bitmap.gif";
    } else if (getType().getMimetype().equals("image/gif")) {
      imageFile = "gif.gif";
    } else if (getType().getMimetype().equals("image/jpeg")) {
      imageFile = "jpeg.gif";
    } else if (getType().getMimetype().equals("image/png")) {
      imageFile = "png.gif";
    } else if (getType().getMimetype().equals("image/tiff")) {
      imageFile = "tiff.gif";
    } else if (getType().getMimetype().equals("text/html")) {
      imageFile = "html.gif";
    } else if (getType().getMimetype().equals("text/plain")) {
      imageFile = "text.gif";
    } else if (getType().getMimetype().equals("text/csv")) {
      imageFile = "csv.gif";
    } else {
      imageFile = "document.gif";
    }
    return "/aig/img/document_icons/" + imageFile;
  }
}
