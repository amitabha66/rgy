package amgen.ri.aig.preferences;

/**
 * <p>@version $Id: RGPreference.java,v 1.7 2013/07/09 18:32:09 jemcdowe Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.CompareTerm;
import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.rdb.SQLManagerIF;
import amgen.ri.util.ExtString;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

/**
 *   RDBData wrapper class for RGPreference. These are the available preferences used by RG
 *   @version $Revision: 1.7 $
 *   @author Jeffrey McDowell
 *   @author $Author: jemcdowe $
 */
public class RGPreference extends RdbData implements PreferenceIF {
  protected int rg_preference_id;
  protected String preference_name;
  protected String preference_default_value;
  protected String preference_options;
  protected String preference_description;
  protected RGPreferenceGroup rg_preference_group_id;
  protected RGPreferenceType rg_preference_type;
  private UserPreference userPreference;

  /**
   * Default Constructor
   */
  public RGPreference() {
    super();
  }

  /**
   * RdbData Constructor
   */
  public RGPreference(String id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
    this.rg_preference_id = new Integer(id);
  }

  /** A required method which returns the primary key(s) of the table/RdbData class. */
  public String getIdentifier() {
    return rg_preference_id + "";
  }

  /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
  protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
    field.set(this, value);
  }

  /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
  protected Object getFieldValue(Field field) throws IllegalAccessException {
    return field.get(this);
  }

  /** This method returns the name of the table. */
  protected String getTableName() {
    return "RG_PREFERENCES";
  }

  /** Get value for preference_name */
  public String getPreference_name() {
    return (String) get("preference_name");
  }

  /** Get value for preference_description */
  public String getPreference_description() {
    return (String) get("preference_description");
  }

  public SpecialUserPreferences getPreferenceTypeCategory() {
    return SpecialUserPreferences.fromString(getPreference_name());
  }

  /** Get value for preference_value */
  public String getPreferenceDefaultValue() {
    return (String) get("preference_default_value");
  }

  /** Get value for rg_preference_group_id */
  public RGPreferenceGroup getRGPreferenceGroup() {
    return (RGPreferenceGroup) get("rg_preference_group_id");
  }

  /** Get value for rg_preference_group_id */
  public RGPreferenceType getRGPreferenceType() {
    return (RGPreferenceType) get("rg_preference_type");
  }

  /**
   * Returns the UserPreference for this RGPreference or null if a UserPreference is not set for this RGPreference
   *
   * @return UserPreferences
   */
  public UserPreference getUserPreference() {
    if (userPreference == null) {
      String userPreferencesSQL = "SELECT UP.USER_PREFERENCE_ID FROM USER_PREFERENCES UP, RG_PREFERENCES RGP WHERE "
              + "UP.RG_PREFERENCE_ID= RGP.RG_PREFERENCE_ID AND RGP.RG_PREFERENCE_ID=? AND UP.USERNAME=?";
      List<UserPreference> userPreferences = new RdbDataArray(UserPreference.class, userPreferencesSQL, new String[]{
                getIdentifier(), getLogonUsername()
              }, getSQLManager(), getLogonUsername(), getConnectionPool());
      if (userPreferences.size() > 0) {
        userPreference = userPreferences.get(0);
      }
    }
    return userPreference;
  }

  /**
   * Updates a UserPreference for this RGPreference by either returning its UserPreference instance with the
   * updated value or creating a new UserPreference with the updated value
   *
   * @return UserPreferences
   */
  public UserPreference updateUserPreference(String updatedPreferenceValue) {
    UserPreference userPreference = getUserPreference();
    if (userPreference == null || !userPreference.setData()) {
      userPreference = new UserPreference(this, updatedPreferenceValue, null, getSQLManager(), getLogonUsername(), getConnectionPool());
    } else {
      userPreference.setAllData();
      userPreference.setPreferenceValue(updatedPreferenceValue);
    }
    return userPreference;
  }

  /*
   * PreferenceIF Implementations
   */
  /**
   * Returns the Preference name
   * @return String
   */
  public String getPreferenceName() {
    return getPreference_name();
  }

  /**
   * Returns the Preference Value- returns either the
   * UserPreference value OR the default value if no UserPreference is set
   * @return Object
   */
  public Object getPreferenceValue() {
    UserPreference userPreference = getUserPreference();
    Object value = (userPreference == null ? null : userPreference.getPreferenceValue());
    return (value == null ? getPreferenceDefaultValue() : value);
  }
  
  /**
   * Return the Preference Data as a String
   * @return 
   */
  public String getPreferenceData() {
    UserPreference userPreference = getUserPreference();
    return (userPreference== null ? null : userPreference.getPreferenceData());
  }
  
  /**
   * Tests whether the preference value is not null and equals Yes or True (case-insensitive)
   * Returns false otherwise.
   * @return 
   */
  public boolean getPreferenceBooleanValue() {
    Object value= getPreferenceValue();
    if (value== null) {
      return false;
    }
    return (ExtString.anyIsEqualIgnoreCase(new String[] {"Yes", "True"}, value.toString()));
  }

  /** Returns the options of the preference as a List. This checks the RGPreference then return the RGPreferenceType
   * options
   */
  public List<String> getPreferenceOptionList() {
    String options = (String) get("preference_options");
    if (ExtString.hasLength(options)) {
      return Arrays.asList(options.split("\\|"));
    }
    return getRGPreferenceType().getPreferenceOptionList();
  }

  /** Returns the numeric bounds of the preference as a 2-field double array. If either is not defined, a NaN is returned in the field. This checks the RGPreference then return the RGPreferenceType
   * options
   */
  public double[] getNumericPreferenceOptionBounds() {
    String options = (String) get("preference_options");
    if (ExtString.hasLength(options) && options.matches("\\[[-\\d]+,[-\\d]+\\]")) {
      String[] fields = options.replaceFirst("^[\\[(]+", "").replaceFirst("[\\])]+$", "").split(",");
      if (fields.length == 2) {
        return new double[]{ExtString.toDouble(fields[0]), ExtString.toDouble(fields[1])};
      }
    }
    return getRGPreferenceType().getNumericPreferenceOptionBounds();
  }

  public String toString() {
    return getPreferenceName() + "= " + getPreferenceValue() + " [" + getPreferenceDefaultValue() + "]";
  }

  /**
   * valueOf
   *
   * @param specialUserPreferences SpecialUserPreferences
   * @return Object
   */
  public static RGPreference valueOf(SpecialUserPreferences specialUserPreference) {
    List<RGPreference> rgPreferences = new RdbDataArray(RGPreference.class, new CompareTerm[]{
              new CompareTerm("PREFERENCE_NAME", specialUserPreference.toString())
            }, null, new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
    return (rgPreferences.size() > 0 ? rgPreferences.get(0) : null);
  }

  /**
   * Is the current value the default value
   * @return 
   */
  public boolean isDefault() {
    Object value = getPreferenceValue();
    Object defaultValue = getPreferenceDefaultValue();
    if (value == null || defaultValue == null) {
      return false;
    }
    return (value.equals(defaultValue));
  }
}
