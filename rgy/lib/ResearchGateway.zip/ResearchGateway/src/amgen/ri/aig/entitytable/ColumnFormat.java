package amgen.ri.aig.entitytable;

import amgen.ri.aig.AIGException;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtDate;
import amgen.ri.util.ExtString;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Defines a format object for a Column which is used by the EntityTableCellFormatter
 * @version $Id: ColumnFormat.java,v 1.4 2014/05/19 22:42:01 jemcdowe Exp $
 */
public class ColumnFormat implements Serializable {
    static final long serialVersionUID = 1020060613531161556L;

    /**
     * enum to defined the format type
     */
    public enum FormatType {
        NUMBER, DATE, CURRENCY, GENERAL;

        static final long serialVersionUID = -3931295240812299272L;

        public static String revertString(FormatType type) {
            try {
                return ExtString.toTitleCase(type.toString());
            } catch (Exception e) {
                return "General";
            }
        }

        /**
         * This is necessary to permit Serializable.
         * A Serialized object containing an enum class variable is not de-Serialized properly.
         * This forces de-Serialized enum to be re-created as this enum through the String
         * @return Object
         * @throws ObjectStreamException
         */
        public Object readResolve() throws ObjectStreamException {
            return FormatType.valueOf(this.toString());
        }
    }


    /**
     * enum to defined the format type
     */
    public enum NotationType {
        STANDARD, SCIENTIFIC, ENGINEERING, PERCENTAGE, CUSTOM;

        static final long serialVersionUID = -6788518071064260473L;

        public static NotationType fromString(String s) {
            try {
                return NotationType.valueOf(s.toUpperCase());
            } catch (Exception e) {
                return STANDARD;
            }
        }

        public static String revertString(NotationType type) {
            try {
                return ExtString.toTitleCase(type.toString());
            } catch (Exception e) {
                return "Custom";
            }
        }

        /**
         * This is necessary to permit Serializable.
         * A Serialized object containing an enum class variable is not de-Serialized properly.
         * This forces de-Serialized enum to be re-created as this enum through the String
         * @return Object
         * @throws ObjectStreamException
         */
        public Object readResolve() throws ObjectStreamException {
            return NotationType.valueOf(this.toString());
        }
    }


    private FormatType formatType;
    private NotationType notation;
    private String formatMask;
    private JSONObject jFormat;
    private transient Format formatter;

    /**
     * Creates a ColumnFormat for a JSONObject
     * Uses the attributes type and format. Format is not required for all types.
     *
     * @param jFormatType JSONObject
     * @throws AIGException
     * @throws JSONException
     */
    public ColumnFormat(JSONObject jFormat) throws JSONException {
        this.formatType = FormatType.valueOf(jFormat.getString("type").toUpperCase());
        JSONObject jSpecifier = jFormat.optJSONObject("format");
        this.notation = NotationType.fromString(jSpecifier.optString("notation"));
        switch (formatType) {
            case DATE:
                this.formatMask = new PredefinedColumnFormats().getDateFormat(jSpecifier.optString("specifier"));
                if (this.formatMask == null) {
                    this.formatMask = jFormat.optString("specifier");
                }
                new SimpleDateFormat(formatMask);
                break;
            case NUMBER:
                if (ExtString.hasTrimmedLength(jSpecifier.optString("custom"))) {
                    this.formatMask = jSpecifier.optString("custom");
                } else {
                    this.formatMask = new PredefinedColumnFormats().buildDecimalFormat(jSpecifier.optInt("decimals"), notation);
                }
                new DecimalFormat(formatMask);
                break;
            case CURRENCY:
                this.formatMask = jSpecifier.optString("specifier");
                Locale locale = findLocale();
                if (locale == null) {
                    throw new IllegalArgumentException("Invalid locale");
                }
                break;
            default:
                break;
        }

        this.jFormat = jFormat;
    }

    /**
     * Creates a new ColumnFormat for the given type and format mask
     *
     * @param formatType FormatType
     * @param formatMask String
     * @throws AIGException
     */
    public ColumnFormat(FormatType formatType, NotationType notation, int decimals, String dateFormatKey) throws AIGException {
        this.formatType = formatType;
        this.notation = notation;
        this.formatMask = formatMask;
        this.jFormat = new JSONObject();
        JSONObject jSpecifier = new JSONObject();
        try {
            this.jFormat.putOpt("format", jSpecifier);
            switch (formatType) {
                case DATE:
                    this.formatMask = new PredefinedColumnFormats().getDateFormat(dateFormatKey);
                    if (this.formatMask == null) {
                        throw new IllegalArgumentException("Unknown data format. " + dateFormatKey);
                    }
                    new SimpleDateFormat(formatMask);
                    this.jFormat = new JSONObject();
                    this.jFormat.put("type", "Date");
                    jSpecifier.put("specifier", dateFormatKey);
                    break;
                case NUMBER:
                    this.formatMask = new PredefinedColumnFormats().buildDecimalFormat(decimals, notation);
                    if (this.formatMask == null) {
                        this.formatMask = formatMask;
                    }
                    new DecimalFormat(formatMask);
                    this.jFormat.put("type", FormatType.revertString(this.formatType));
                    jSpecifier.putOpt("notation", NotationType.revertString(this.notation));
                    jSpecifier.putOpt("decimals", decimals);
                    jSpecifier.putOpt("custom", "");
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            throw new AIGException("Unable to create format", AIGException.Reason.INVALID_REQUEST, e);
        }
    }

    /**
     * Creates a new ColumnFormat for the given type and format mask
     *
     * @param formatType FormatType
     * @param formatMask String
     * @throws AIGException
     */
    public ColumnFormat(FormatType formatType, NotationType notation, int decimals) throws AIGException {
        this(formatType, notation, decimals, null);
    }


    /**
     * Returns the FormatType
     *
     * @return FormatType
     */
    public FormatType getFormatType() {
        return formatType;
    }


    /**
     * Returns the java Format object. This is a transient object and therefore
     * may be initially null. For certain formats, there may be no Format object
     * so null is returned.
     *
     * @return Format
     */
    private Format getFormat() {
        if (formatter == null) {
            switch (formatType) {
                case DATE:
                    formatter = new SimpleDateFormat(formatMask);
                    break;
                case NUMBER:
                    formatter = new DecimalFormat(formatMask);
                    break;
                case CURRENCY:
                    formatter = NumberFormat.getCurrencyInstance(findLocale());
                    break;
                default:
                    break;
            }
        }
        return formatter;
    }

    private Locale findLocale() {
        for (Locale locale : Locale.getAvailableLocales()) {
            if (ExtString.equalsIgnoreCase(locale.getDisplayCountry(), formatMask)) {
                return locale;
            }
        }
        return null;

    }

    /**
     * Properly formats the given object
     *
     * @param value Object
     * @return String
     */
    public String getFormatterValue(Object value) {
        if (value == null) {
            return null;
        }
        Format format = getFormat();
        if (format == null) {
            return value.toString();
        }
        if (format instanceof NumberFormat) {
            if (value instanceof Number) {
                return format.format(value);
            } else if (ExtString.isANumber(value + "")) {
                return format.format(ExtString.toDouble(value + ""));
            } else {
                value.toString();
            }
        } else if (format instanceof SimpleDateFormat) {
            if (value instanceof Date) {
                return format.format(value);
            } else {
                Date d = ExtDate.toDate(value + "");
                if (d != null) {
                    return format.format(d);
                } else {
                    value.toString();
                }
            }
        }
        return value.toString();
    }

    /**
     * Returns the ColumnFormat as a JSONObject
     *
     * @return JSONObject
     */
    public JSONObject getJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put("type", formatType.toString());
            if (formatMask != null) {
                json.put("mask", formatMask);
            }
            if (jFormat != null) {
                json.put("format", jFormat.get("format"));
            }
        } catch (Exception e) {}
        return json;
    }

    /**
     * Returns the ColumnFormat as a readable String
     *
     * @return String
     */
    public String toString() {
        return (formatType + (formatMask == null ? "" : ":" + formatMask));
    }

    public NotationType getNotation() {
        return notation;
    }


}
