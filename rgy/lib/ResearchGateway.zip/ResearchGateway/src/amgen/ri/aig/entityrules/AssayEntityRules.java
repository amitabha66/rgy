package amgen.ri.aig.entityrules;

import amgen.ri.aig.cache.tree.TreeNode;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.entitylist.EntityListMemberIF;
import amgen.ri.util.ExtString;

/**
 * Class used to enforce business rules when processing nodes or
 * EntityListMembers for an EntityType
 *
 * @version $id$
 */
public class AssayEntityRules extends AbstractEntityRules {
    public AssayEntityRules() {
        super(EntityListCategory.ASSAYS);
    }

    /**
     * applyEntityRules
     *
     * @param node TreeNode
     * @return TreeNode
     */
    public TreeNode applyEntityRules(TreeNode node) {
        basicProcessing(node);
        String id = node.getServiceData();
        if (!ExtString.hasLength(id)) {
            return null;
        }
        if (ASSAYCODE_PATTERN.matcher(id).matches()) {
            node.setServiceData(id.substring(2));
        }
        if (!NUMBER_PATTERN.matcher(id).matches()) {
            return null;
        }
        String text = node.getText();
        if (NUMBER_PATTERN.matcher(text).matches()) {
            node.setText("AA" + text);
        }
        return node;
    }

    /**
     * applyEntityRules
     *
     * @param member EntityListMemberIF
     * @return EntityListMemberIF
     */
    public EntityListMemberIF applyEntityRules(EntityListMemberIF member, ServiceDataCategory memberServiceDataCategory) {
        return member;
    }

}
