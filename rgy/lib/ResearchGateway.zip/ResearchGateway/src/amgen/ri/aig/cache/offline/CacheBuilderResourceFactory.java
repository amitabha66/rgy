/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amgen.ri.aig.cache.offline;

import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.rg.resource.ResourceFactory;

/**
 *
 * @author jemcdowe
 */
public class CacheBuilderResourceFactory extends ResourceFactory {

  public CacheBuilderResourceFactory() {
  }

  public CacheBuilderResourceFactory(EntityClassManager entityClassManager) {
    super(entityClassManager);
  }
  
}
