package amgen.ri.aig.preferences;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.css.CSSImageRetriever;
import amgen.ri.aig.documents.SavedDocument;
import amgen.ri.aig.sql.RGSQLProvider;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.CompareTerm;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.sql.SQLQuery;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtImage;
import amgen.ri.util.ExtString;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import javax.imageio.ImageIO;

/**
 * @version $Id: UserPreferencesHandler.java,v 1.12 2013/04/18 23:04:26 jemcdowe Exp $
 */
public class UserPreferencesHandler extends AIGServlet {
  private RGSQLProvider rgSQLProvider;

  public UserPreferencesHandler() {
    super();
  }

  public UserPreferencesHandler(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
    rgSQLProvider = new RGSQLProvider();
  }

  /**
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return TBXServlet @todo Implement this amgen.ri.aig.AIGServlet method
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new UserPreferencesHandler(req, resp);
  }

  /**
   *
   * @return String @todo Implement this amgen.ri.aig.AIGServlet method
   */
  protected String getServletMimeType() {
    switch (UserPreferencesHandlerRequest.fromRequest(this)) {
      case GET_IMG_THUMB:
        return "image/png";
      default:
        return "text/json";
    }
  }

  /**
   *
   * @throws Exception @todo Implement this amgen.ri.aig.AIGServlet method
   */
  protected void performRequest() throws Exception {
    double groupID = getParameterNumber("id").doubleValue();
    switch (UserPreferencesHandlerRequest.fromRequest(this)) {
      case GROUP_PREFS:
        if (!Double.isNaN(groupID)) {
          Map<Integer, RGPreference> rgPreferences = getRGPreferences((int) groupID);
          JSONObject jGroupParams = new JSONObject();
          for (Integer prefID : rgPreferences.keySet()) {
            RGPreference preference = rgPreferences.get(prefID);
            boolean preferenceValid = true;
            JSONObject jGroupParam = new JSONObject();

            jGroupParam.put("id", new Integer(preference.getIdentifier()).intValue());
            jGroupParam.put("name", preference.getPreference_name());
            jGroupParam.put("desc", preference.getPreference_description());
            jGroupParam.put("group_id", preference.getRGPreferenceGroup().getIdentifier());
            jGroupParam.put("group_name", preference.getRGPreferenceGroup().getPreference_group());
            jGroupParam.put("type", preference.getRGPreferenceType().getPreference_type());
            jGroupParam.put("extfield_config", preference.getRGPreferenceType().getExtFieldConfig());
            List<String> options = preference.getPreferenceOptionList();
            double[] numericBounds = preference.getNumericPreferenceOptionBounds();
            if (numericBounds != null && (!Double.isNaN(numericBounds[0]) || !Double.isNaN(numericBounds[1]))) {
              JSONObject jNumericBounds = new JSONObject();
              jGroupParam.put("options", jNumericBounds);
              if (!Double.isNaN(numericBounds[0])) {
                jNumericBounds.put("minValue", numericBounds[0]);
              }
              if (!Double.isNaN(numericBounds[1])) {
                jNumericBounds.put("maxValue", numericBounds[1]);
              }
            } else if (ExtArray.hasLength(options)) {
              jGroupParam.put("options", options);
            }
            if (preference.getRGPreferenceType().getPreference_type().equalsIgnoreCase("BACKGROUNDIMAGE")) {
              Map<String, Integer> imageDocuments = getUserImageDocuments();

              options = ExtArray.sort(new ArrayList<String>(imageDocuments.keySet()));
              options.add(0, "None");
              List<String> globalBKImageSelectors = ExtArray.sort(new ArrayList(CSSImageRetriever.getInstance().getSelectors("RG.BKImages.css")));
              options.addAll(1, globalBKImageSelectors);

              if (ExtArray.hasLength(options)) {
                jGroupParam.put("options", options);

                String prefValue = (String) preference.getPreferenceValue();
                if (ExtString.isAInteger(prefValue)) {
                  int documentID = (int) ExtString.toDouble((String) preference.getPreferenceValue(), -1);
                  String currentDoc = null;
                  for (String docName : imageDocuments.keySet()) {
                    int docID = imageDocuments.get(docName);
                    if (docID == documentID) {
                      currentDoc = docName;
                    }
                  }
                  if (currentDoc != null) {
                    jGroupParam.put("value", currentDoc);
                  }
                } else {
                  if (options.contains(prefValue)) {
                    jGroupParam.put("value", prefValue);
                  }
                }
              } else {
                preferenceValid = false;
              }
            } else {
              jGroupParam.put("value", preference.getPreferenceValue());
            }

            if (preferenceValid) {
              jGroupParams.append("preferences", jGroupParam);
            }

          }
          jGroupParams.write(response.getWriter());
        }
        break;
      case GROUP_NODES:
        writePreferenceGroupNodes();
        break;
      case SAVE:
        Map<Integer, RGPreference> rgPreferenceMap = getRGPreferences(-1);
        JSONArray jPrefs = getJSONArrayParameter("preferences");
        int updatedPreferences = 0;
        for (int i = 0; i < jPrefs.length(); i++) {
          JSONObject jPref = jPrefs.getJSONObject(i);
          String value = jPref.getString("value");
          if (ExtString.hasTrimmedLength(value)) {
            RGPreference rgPreference = rgPreferenceMap.get(jPref.getInt("preference_id"));
            if (rgPreference.getRGPreferenceType().getPreference_type().equalsIgnoreCase("BACKGROUNDIMAGE")) {
              Set<String> globalBKImageSelectors = CSSImageRetriever.getInstance().getSelectors("RG.BKImages.css");
              if (globalBKImageSelectors.contains(value)) {
                //value= value; Just leave value alone!!!
              } else {
                Map<String, Integer> imageDocuments = getUserImageDocuments();
                Integer selectedDoc = imageDocuments.get(value);
                if (selectedDoc == null) {
                  UserPreference userPreference = rgPreference.getUserPreference();
                  if (userPreference != null) {
                    userPreference.performDelete();
                  }
                  value = null;
                } else {
                  value = selectedDoc.toString();
                }
              }
            }
            if (value != null) {
              UserPreference userPreference = rgPreference.updateUserPreference(value);
              if (userPreference.performCommit() > 0) {
                updatedPreferences++;
              }
            }
          }
        }
        JSONObject jResults = new JSONObject();
        jResults.put("updates", updatedPreferences);
        jResults.write(response.getWriter());
        break;
      case RESET_GROUP:
        int deletedPreferences = 0;
        if (!Double.isNaN(groupID)) {
          Map<Integer, RGPreference> rgPreferences = getRGPreferences((int) groupID);
          for (Integer prefID : rgPreferences.keySet()) {
            RGPreference preference = rgPreferences.get(prefID);
            UserPreference userPreference = preference.getUserPreference();
            if (userPreference != null) {
              if (userPreference.performDelete() > 0) {
                deletedPreferences++;
              }
            }
          }
        }
        JSONObject jDeleteResults = new JSONObject();
        jDeleteResults.put("updates", deletedPreferences);
        jDeleteResults.write(response.getWriter());
        break;
      case GET_IMG_THUMB:
        BufferedImage img = null;
        Set<String> globalBKImageSelectors = CSSImageRetriever.getInstance().getSelectors("RG.BKImages.css");
        if (globalBKImageSelectors.contains(getParameter("name"))) {
          img = CSSImageRetriever.getInstance().getImageForRule(getParameter("name"));
        } else {
          Map<String, Integer> imageDocuments = getUserImageDocuments();
          Integer documentID = imageDocuments.get(getParameter("name"));
          if (documentID != null) {
            SavedDocument document = new SavedDocument(documentID + "", new OraSQLManager(), null, JDBCNamesType.RGDOCS_JDBC+"");
            if (document.setData()) {
              try {
                img = ImageIO.read(document.getFileContents().getBlobStream());
              } catch (Exception e) {
                e.printStackTrace();
              }
            }
          }
        }
        if (img != null) {
          try {
            BufferedImage scaledImg = ExtImage.resize(img, 24, 24);
            ImageIO.write(scaledImg, "PNG", response.getOutputStream());
          } catch (Exception e) {
            e.printStackTrace();
          }
        }
        break;

    }
  }

  /**
   * Returns RGPreferences as a Map of pref_id:RGPreference RGPreferences in the
   * Map are either- group_id>0 RGPreferences in the given group group_id<=0 All
   * RGPreferences
   *
   *
   *

   *
   * @param groupID int
   * @return Map
   * @throws AIGException
   */
  protected Map<Integer, RGPreference> getRGPreferences(int groupID) throws AIGException {
    Map<Integer, RGPreference> rgPreferenceMap = new LinkedHashMap<Integer, RGPreference>();
    List<RGPreference> rgPreferences = null;
    if (groupID > 0) {
      CompareTerm[] groupIDTerm = null;
      groupIDTerm = new CompareTerm[]{new CompareTerm("RG_PREFERENCE_GROUP_ID", groupID)};
      rgPreferences = new RdbDataArray(RGPreference.class, groupIDTerm, "preference_name", true, new OraSQLManager(), getSessionLogin().getRemoteUser(),
              JDBCNamesType.RG_JDBC+"");
    } else {
      rgPreferences = new RdbDataArray(RGPreference.class, new OraSQLManager(), getSessionLogin().getRemoteUser(), JDBCNamesType.RG_JDBC+"");
    }
    for (RGPreference rgPreference : rgPreferences) {
      rgPreferenceMap.put(new Integer(rgPreference.getIdentifier()), rgPreference);
    }
    return rgPreferenceMap;
  }

  protected void writePreferenceGroupNodes() throws SQLException, JSONException, IOException, AIGException {
    JSONArray jPrefGroupNodes = new JSONArray();
    SQLQuery rgPreferenceGroupsSQL = rgSQLProvider.getSQLQuery("rg_preference_groups");

    ResultSet rset = null;
    try {
      rset = new OraSQLManager().executeQuery(rgPreferenceGroupsSQL, JDBCNamesType.RG_JDBC+"");
      while (rset.next()) {
        int prefGroupID = rset.getInt("PREFERENCE_GROUP_ID");
        String prefGroupName = rset.getString("PREFERENCE_GROUP");
        JSONObject jPrefGroupNode = new JSONObject();
        jPrefGroupNodes.put(jPrefGroupNode);
        jPrefGroupNode.put("id", prefGroupID);
        jPrefGroupNode.put("text", prefGroupName);
        jPrefGroupNode.put("leaf", true);
      }
      jPrefGroupNodes.write(response.getWriter());
    } finally {
      OraSQLManager.closeResources(rset);
    }
  }

  protected Map<String, Integer> getUserImageDocuments() throws SQLException, JSONException, IOException, AIGException {
    Map<String, Integer> imageDocuments = new HashMap<String, Integer>();
    SQLQuery getUserImageDocumentsSQL = rgSQLProvider.getSQLQuery("get_image_documents_for_user");

    ResultSet rset = null;
    try {
      rset = new OraSQLManager().executeQuery(getUserImageDocumentsSQL, new String[]{"amgen_login:" + getSessionLogin().getRemoteUser()}, JDBCNamesType.RGDOCS_JDBC+"");
      while (rset.next()) {
        int documentID = rset.getInt("DOCUMENT_ID");
        String documentName = rset.getString("NAME");
        imageDocuments.put(documentName, documentID);
      }
      return imageDocuments;
    } finally {
      OraSQLManager.closeResources(rset);
    }
  }

  protected String getDocumentName(int documentID) throws SQLException, JSONException, IOException, AIGException {
    SQLQuery getDocumentNameSQL = rgSQLProvider.getSQLQuery("get_document_name");
    ResultSet rset = null;
    try {
      rset = new OraSQLManager().executeQuery(getDocumentNameSQL, new String[]{"document_id:" + documentID}, JDBCNamesType.RGDOCS_JDBC+"");
      while (rset.next()) {
        return rset.getString("NAME");
      }
      return null;
    } finally {
      OraSQLManager.closeResources(rset);
    }
  }

  enum UserPreferencesHandlerRequest {
    GROUP_NODES, GROUP_PREFS, SAVE, RESET_GROUP, GET_IMG_THUMB;

    public static UserPreferencesHandlerRequest fromRequest(AIGBase servlet) {
      if (servlet.doesParameterEqual("op", "save")) {
        return SAVE;
      }
      if (servlet.doesParameterEqual("op", "img_thumb")) {
        return GET_IMG_THUMB;
      }
      if (servlet.doesParameterEqual("op", "reset")) {
        return RESET_GROUP;
      }
      if (servlet.doesParameterExist("id", true)) {
        return GROUP_PREFS;
      }
      return GROUP_NODES;
    }
  }
}
