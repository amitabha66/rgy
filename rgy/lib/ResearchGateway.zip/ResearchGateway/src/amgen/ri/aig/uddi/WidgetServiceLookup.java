/**
 *
 * @author jemcdowe
 */
package amgen.ri.aig.uddi;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.service.ServiceCacheResponse;
import amgen.ri.aig.cache.service.ServiceKeyCacheResponse;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.asf.sa.uddi.*;
import amgen.ri.json.JSONObject;
import amgen.ri.xml.ExtXMLElement;
import java.io.IOException;
import java.util.*;
import java.util.UUID;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;

public class WidgetServiceLookup extends AbstractServiceLookup implements ServiceLookupIF, QueryServiceIF {
  /**
   * Default constructor
   */
  public WidgetServiceLookup() {
    super();
  }

  public WidgetServiceLookup(AIGServlet aigServlet) {
    super(aigServlet);
  }

  /**
   * Main constructor- used only by the getAIGServlet method
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   */
  public WidgetServiceLookup(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  /**
   * Returns the getAIGServlet implementation class for the request
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return TBXServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new WidgetServiceLookup(req, resp);
  }

  /**
   * Actual work entry stub
   *
   * @throws ServletException
   * @throws IOException
   */
  @Override
  protected void performRequest() throws ServletException, IOException, AIGException {
    try {
      ExtXMLElement.write(getServicesDocument(), response.getWriter());
    } catch (JDOMException ex) {
      ex.printStackTrace();
    }
  }

  @Override
  public Document getServicesDocument() throws JDOMException, AIGException {
    Document servicesDocument = new Document(new Element("Services"));
    ServiceQuery serviceQuery= getServiceQuery();
    ServiceCacheResponse sortedSearchServices = findAndSortServices(serviceQuery);
    for (ServiceDetails service : sortedSearchServices) {
      try {
        if (service.containsUserInAllowedUsers(getSessionLogin().getRemoteUser(), true)) {
          ServiceAttributes serviceAttributes = new ServiceAttributes(service, getEntityClassManager());
          Element searchServiceElement = getServiceElement(service);
          if (searchServiceElement != null) {                        
            servicesDocument.getRootElement().addContent(searchServiceElement);
            ExtXMLElement.addTextElement(searchServiceElement, "ID", UUID.randomUUID() + "");
            Element nameElement = searchServiceElement.getChild("Name");
            nameElement.setText(serviceAttributes.getName(ServiceNamingContext.RG_QUERY));
            Element descElement = searchServiceElement.getChild("Description");
            descElement.setText(serviceAttributes.getDescription(ServiceNamingContext.RG_QUERY));
            ExtXMLElement.addElement(searchServiceElement, "IconCls", serviceAttributes.getIconClass(ServiceNamingContext.RG_LOFT));
          }
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return servicesDocument;
  }

  @Override
  public JSONObject getServiceRecords() throws JDOMException, AIGException {
    return getServiceRecords(getServicesDocument());
  }
  
  /**
   * Performs the UDDI search for the request, sorts the results, and returns
   * them as a List
   *
   * @param classificationSchemeQuery ClassificationSchemeQuery
   * @param resultName String
   * @throws ServletException
   * @throws IOException
   * @throws AIGException
   * @return List
   */
  @Override
  protected ServiceCacheResponse findAndSortServices(ServiceQuery serviceQuery) throws AIGException {
    ServiceCache serviceCache= ServiceCache.getServiceCache(request);
    ServiceKeyCacheResponse widgetServiceKeysWithHTMLAccessPoint = serviceCache.getServiceKeys(serviceQuery);
    
    Set<ServiceDetails> searchServices = new HashSet<ServiceDetails>();
    for (String serviceKey : widgetServiceKeysWithHTMLAccessPoint) {
      ServiceDetails service= serviceCache.getService(serviceKey, true, false);
      if (isValidService(service, serviceQuery)) {
        searchServices.add(service);
      }
    }
    return new ServiceCacheResponse(searchServices);
  }  

  public ServiceQuery getServiceQuery() {
    ClassificationSchemeQuery classificationSchemeQuery = new ClassificationSchemeQuery(ClassificationSchemeQuery.OR_ALL_KEYS);
    classificationSchemeQuery.addKeyValue("Research Gateway Categorization Scheme", "RG Service Application");
    return new ServiceQuery(classificationSchemeQuery, CommonNames.HTMLDEFINITION_tMODELNAME);    
  }

  public Collection<ServiceQuery> getCacheServiceQueries() {
    return Arrays.asList(getServiceQuery());
  }
}
