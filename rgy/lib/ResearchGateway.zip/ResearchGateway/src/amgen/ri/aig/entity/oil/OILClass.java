package amgen.ri.aig.entity.oil;

public enum OILClass {
  IDENTITY, ROBE, SAMPLE, UNKNOWN;

  public String getClassChar() {
    switch (this) {
      case IDENTITY:
        return "i";
      case ROBE:
        return "r";
      case SAMPLE:
        return "s";
      default:
        throw new IllegalArgumentException("Unknown UIR type");
    }
  }

  public static OILClass fromString(String s) {
    if (s != null) {
      s = s.toUpperCase();
      if (s.startsWith("I")) {
        return IDENTITY;
      } else if (s.startsWith("R")) {
        return ROBE;
      } else if (s.startsWith("S")) {
        return SAMPLE;
      }
    }
    return UNKNOWN;
  }
}