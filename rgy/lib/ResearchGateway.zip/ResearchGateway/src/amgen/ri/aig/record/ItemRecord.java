/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.record;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.favorites.Favorite;
import amgen.ri.aig.favorites.FavoriteIF;
import amgen.ri.aig.favorites.SharedFavorite;
import amgen.ri.aig.sobj.ObjectType;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jemcdowe
 */
public class ItemRecord extends AbstractRecord {

  public enum ItemType {
    ITEM, SHARED_ITEM, FOLDER, UNKNOWN;

    public static ItemType fromString(String s) {
      try {
        return ItemType.valueOf(s.toUpperCase().replaceAll("\\s", "_"));
      } catch (Exception e) {
        return UNKNOWN;
      }
    }
  } 

  public ItemRecord() {
    super("-1");
    try {
      put("id", -1);
    } catch (JSONException ex) {
    }
  }

  public ItemRecord(JSONObject source) throws JSONException {
    super(source, "id");
    setIconCls();
  }

  public ItemRecord(AbstractRecord record) throws JSONException {
    super(record);
    setIconCls();
  }

  private void setIconCls() {
    switch (getItemType()) {
      case ITEM:
      case SHARED_ITEM:
        switch (getItemSubType()) {
          case LIST:
            add("iconCls", "list-fav");
            break;
          case ENTITYTABLE:
            add("iconCls", "table-fav");
            break;
          case PROJECTVIEW:
            add("iconCls", "view-fav");
            break;
          case SERVICE:
            add("iconCls", "service-fav");
            break;
        }
        break;
      case FOLDER:
        break;
    }
  }

  public boolean exists() {
    return (getId() > -1);
  }

  public boolean isCanDelete() {
    return getBoolean("can_delete");
  }

  public String getCategory() {
    return getString("category");
  }

  public String getCategoryLabel() {
    return getString("category_label");
  }

  public Date getCreated() {
    return getDate("created");
  }

  public String getCreatedBy() {
    return getString("created_by");
  }

  public String getCreatedByName() {
    return getString("created_by_name");
  }

  public int getId() {
    return getNumber("id").intValue();
  }

  public boolean isIs_owner() {
    return getBoolean("is_owner");
  }

  public boolean isLeaf() {
    return getBoolean("leaf");
  }

  public String getName() {
    return getString("name");
  }

  public String getDescription() {
    return getString("description");
  }
  public int getParentID() {
    return getNumber("parent_id").intValue();
  }

  public String getSharedWith() {
    return getString("shared_with");
  }

  public boolean isStarred() {
    return getBoolean("starred");
  }

  public String getSubtype() {
    return getString("subtype");
  }

  public ObjectType.Type getItemSubType() {
    return ObjectType.Type.fromString(getSubtype());
  }

  public String getText() {
    return getString("text");
  }

  /**
   * Returns the type of the Item
   *
   * @return
   */
  public String getType() {
    return getString("type");
  }

  /**
   * Returns the type of the Item as an ItemType enum
   *
   * @return
   */
  public ItemType getItemType() {
    return ItemType.fromString(getType());
  }

  /**
   * Returns whether this a "Saved" type- i.e. ITEM or SHARED_ITEM
   *
   * @return
   */
  public boolean isSavedItemType() {
    return (getItemType().equals(ItemType.ITEM) || getItemType().equals(ItemType.SHARED_ITEM));
  }

  /**
   * Returns the saved item key (id). 0 if it is a Folder.
   *
   * @return
   */
  public int getItemKey() {
    return getNumber("item_key").intValue();
  }

  public FavoriteIF getItem(AIGBase requestor) {
    FavoriteIF item = null;
    try {
      if (exists() && isSavedItemType()) {
        switch (getItemType()) {
          case ITEM:
            item = new Favorite(getItemKey() + "", new OraSQLManager(), requestor.getSessionLogin().getRemoteUser(), JDBCNamesType.RG_JDBC + "");
            break;
          case SHARED_ITEM:
            item = new SharedFavorite(getItemKey() + "", new OraSQLManager(), requestor.getSessionLogin().getRemoteUser(), JDBCNamesType.RG_JDBC + "");
            break;
          case FOLDER:
            break;
          case UNKNOWN:
            throw new IllegalArgumentException("Unknown item type");
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return item;
  }
}
