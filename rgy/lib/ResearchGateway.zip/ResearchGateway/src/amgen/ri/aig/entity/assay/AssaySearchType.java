package amgen.ri.aig.entity.assay;

import java.io.ObjectStreamException;

/**
 * @version $Id: AssaySearchType.java,v 1.1 2013/07/09 18:32:09 jemcdowe Exp $
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public enum AssaySearchType {
    ALIAS_ID, ALIAS, ASSAY_ID, PARENT_ASSAY_ID, CHILD_ASSAY_ID, ALL;

    public static AssaySearchType fromString(String s) {
        if (s == null) {
            return ALL;
        }
        try {
            return AssaySearchType.valueOf(s.toUpperCase());
        } catch (Exception e) {
            return ALL;
        }
    }

    /**
     * This is necessary to permit Serializable.
     * A Serialized object containing an enum class variable is not de-Serialized properly.
     * This forces de-Serialized enum to be re-created as this enum through the String
     * @return Object
     * @throws ObjectStreamException
     */
    public Object readResolve() throws ObjectStreamException {
        return AssaySearchType.fromString(this.toString());
    }

}
