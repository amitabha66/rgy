package amgen.ri.aig.image;

import amgen.ri.aig.preferences.PreferenceIF;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.aig.sm.structure.ChemMolSource;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.aig.preferences.PreferenceManager;
import amgen.ri.aig.preferences.PreferenceableIF;
import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.asf.sa.uddi.ClassificationSchemeNames;
import amgen.ri.json.JSONObject;
import amgen.ri.security.FASFEncrypter;
import amgen.ri.util.ExtFile;
import amgen.ri.util.ExtString;
import java.io.Reader;
import org.apache.catalina.connector.ClientAbortException;
import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class ChemImageHandler extends HttpServlet implements PreferenceableIF {
  String serviceInputCategorizationScheme = ClassificationSchemeNames.getName(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME);
  private HttpServletResponse response;
  private HttpServletRequest request;
  private AIGSessionLogin sessionLogin;
  //Preference settings
  private Map<String, String> preferences;

  public ChemImageHandler() {
    super();
  }

  public ChemImageHandler(HttpServletRequest request, HttpServletResponse response) {
    super();
    this.preferences = new HashMap<String, String>();
    this.request = request;
    this.response = response;
    try {
      sessionLogin = (AIGSessionLogin) AIGSessionLogin.getSessionLogin(request);
    } catch (ServletException ex) {
    }
    new PreferenceManager(sessionLogin, this).setPreferences();
  }

  /**
   * doGet entry stub which calls doPost
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @throws ServletException
   * @throws IOException
   */
  protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    doPost(req, resp);
  }

  /**
   * doPost entry stub which calls the getHandler method and the performRequest
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @throws ServletException
   * @throws IOException
   */
  protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    try {
      ChemImageHandler handler = new ChemImageHandler(req, resp);
      handler.performRequest();
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  protected void performRequest() throws ServletException, IOException {
    String db = request.getParameter("db");
    String rootNumber = request.getParameter("rootnumber");
    String lot = request.getParameter("lot");
    String component_id = request.getParameter("component_id");
    String cdbregno = request.getParameter("cdbregno");
    String id = request.getParameter("id");
    String substanceID = request.getParameter("substanceid");
    String mdlnum = request.getParameter("mdlnum");
    String smiles = request.getParameter("smi");
    String mol = request.getParameter("mol");
    String imageID = request.getParameter("image_id");

    String format = request.getParameter("format");
    String width = request.getParameter("width");
    String height = request.getParameter("height");

    String smscURL = getSMSCURL(request, db, rootNumber, lot, component_id, cdbregno, id,
            substanceID, mdlnum, smiles, mol, imageID, format,
            width, height, null);

    if (ExtString.equals(format, "json") && ExtString.hasLength(id)) {
      try {
        smscURL = getSMSCURL(request, "acrf", id, "json", null, null, sessionLogin.getRemoteUser());
        String smscResponse = ExtFile.postURL(smscURL, null);
        JSONObject smscResponseJS = new JSONObject(smscResponse);
        if (smscResponseJS.has("mol")) {
          String molStr = smscResponseJS.getString("mol");
          molStr = molStr.replaceFirst("[ \\t\\x0B\\f\\r]*\\n", id + '\n');
          smscResponseJS.put("mol", molStr);
        }
        smscResponseJS.put("title", "Structure Details for " + id);
        smscResponseJS.write(response.getWriter());
        return;
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    try {
      //if (!StringUtils.equals(db, "acrf") || !processACRFRequest()) {
        response.sendRedirect(smscURL);
      //}
    } catch (ClientAbortException e) {
    }
  }

  boolean processACRFRequest() {
    int id = ExtString.toInteger(request.getParameter("id"), -1);
    int root = ExtString.toInteger(request.getParameter("rootnumber"), -1);
    int lot = ExtString.toInteger(request.getParameter("lot"), -1);
    int componentID = ExtString.toInteger(request.getParameter("component_id"), -1);

    int width = ExtString.toInteger(request.getParameter("width"), 200);
    int height = ExtString.toInteger(request.getParameter("height"), 200);

    ChemImageDao chemimage = new ChemImageDao(root, lot, componentID, componentID, sessionLogin.getUsername(), width, height);

    SqlSession sqlSession = null;

    try {
      if (root > -1 && lot > -1) {
        sqlSession = getRGDHSqlSession();
        sqlSession.getMapper(ChemImageMapper.class).getChemImageData4RootLot(chemimage);
      } else if (root > -1) {
        sqlSession = getRGDHSqlSession();
        sqlSession.getMapper(ChemImageMapper.class).getChemImageData4Root(chemimage);
      } else if (id > -1) {
        sqlSession = getRGDHSqlSession();
        chemimage.setRoot(id);
        sqlSession.getMapper(ChemImageMapper.class).getChemImageData4Root(chemimage);
      } else if (componentID > -1) {
        sqlSession = getRGDHSqlSession();
        sqlSession.getMapper(ChemImageMapper.class).getChemImageData4Component(chemimage);
      }

      if (chemimage.getResults() != null) {
        response.getOutputStream().write(chemimage.getResults());
        return true;
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      close(sqlSession);
    }

    return false;
  }

  /**
   * Function to create connection with database and to read the xml files used
   * for mapping.
   */
  public SqlSessionFactory getSqlSessionFactory(String factoryID) {
    SqlSessionFactory sqlSessionFactory = null;
    try {
      String resource = "rg.mybatis.config.xml";
      Reader reader = Resources.getResourceAsReader(resource);
      sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader, factoryID);
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
    return sqlSessionFactory;
  }

  public SqlSession getRGDHSqlSession() {
    return getSqlSessionFactory("rgsmscl").openSession();
  }

  public void close(SqlSession sqlSession) {
    if (sqlSession != null) {
      try {
        sqlSession.close();
      } catch (Exception e) {
      }
    }
  }

  public String getSMSCURL(HttpServletRequest req, String db, String id, String format,
          String width, String height, String includeLogin) {
    return getSMSCURL(req, db, null, null, null, null, id,
            null, null, null, null,
            null, format, width, height, includeLogin);
  }

  public String getSMSCURL(HttpServletRequest req, String db, String rootNumber,
          String lot, String component_id,
          String cdbregno, String id,
          String substanceID, String mdlnum,
          String smiles, String mol,
          String imageID, String format,
          String width, String height, String includeLogin) {
    Double widthD = ExtString.toDouble(width);
    int widthVal = (Double.isNaN(widthD) ? 200 : widthD.intValue());
    Double heightD = ExtString.toDouble(height);
    int heightVal = (Double.isNaN(heightD) ? widthVal : heightD.intValue());

    ChemMolSource source = (db == null ? ChemMolSource.ACRF : ChemMolSource.fromString(db));
    if (source.equals(ChemMolSource.ACRF) & component_id != null) {
      source = ChemMolSource.ACRF_COMPONENT;
    }

    String smscBaseURL = ConfigurationParameterSource.getConfigParameter("SMSC_BASE_URL");
    String smscURL = smscBaseURL + "/smsc.go";

    Map<String, String> params = new HashMap<String, String>();

    if (ExtString.hasLength(id)) {
      params.put("id", id);
    }
    params.put("width", widthVal + "");
    params.put("height", heightVal + "");
    if (format != null) {
      params.put("format", format);
    }
    if (includeLogin != null) {
      try {
        params.put("FASF_IDENTITY", new FASFEncrypter().encrypt(includeLogin));
      } catch (Exception ex) {
      }
    }
    switch (source) {
      case ACRF:
      case ACRF_COMPOUNDR:
      case ACRF_LARGEST_COMPONENT:
        params.put("db", "acrf");
        if (ExtString.hasLength(rootNumber)) {
          params.put("id", rootNumber);
          if (ExtString.hasLength(lot)) {
            params.put("id", rootNumber + "#" + lot);
          }
        }
        break;
      case ACRF_COMPONENT:
        params.put("db", "acrfcomponent");
        if (ExtString.hasLength(component_id)) {
          params.put("id", component_id);
        }
        break;
      case COMBICHEM_LIBRARY:
        params.put("db", "cc");
        if (ExtString.hasLength(rootNumber)) {
          params.put("id", rootNumber);
          if (ExtString.hasLength(lot)) {
            params.put("id", rootNumber + "#" + lot);
          }
        }
        break;
      case MDLTOX:
        params.put("db", "mdltox");
        if (ExtString.hasLength(mdlnum)) {
          params.put("id", mdlnum);
        }
        break;
      case MDDR:
        params.put("db", "mddr");
        if (ExtString.hasLength(cdbregno)) {
          params.put("id", cdbregno);
        }
        break;
      case GVK:
        params.put("db", "gvk");
        break;
      case ACD:
        params.put("db", "acd");
        if (ExtString.hasLength(cdbregno)) {
          params.put("id", cdbregno);
        }
        break;
      case ACDSC:
        params.put("db", "acdsc");
        if (ExtString.hasLength(cdbregno)) {
          params.put("id", cdbregno);
        }
        break;
      case CMC:
        params.put("db", "cmc");
        if (ExtString.hasLength(cdbregno)) {
          params.put("id", cdbregno);
        }
        break;
      default:
        throw new IllegalArgumentException("Unknown type " + source);
    }
    params.putAll(preferences);
    return ExtString.toURI(smscURL, params);
  }

  public String getPreferenceGroup() {
    return "Chemical Structures";
  }

  public void setPreference(PreferenceIF preference) {
    if (preference.getPreferenceName().equals("Stereo Group Color Display")) {
      if (!preference.isDefault()) {
        preferences.put("stereoGroupColorDisplay", preference.getPreferenceValue().toString().toUpperCase().replace(' ', '_'));
      }
    } else if (preference.getPreferenceName().equals("Background Color")) {
      if (!preference.isDefault()) {
        preferences.put("backgroundColor", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Bond Label Size")) {
      if (!preference.isDefault()) {
        preferences.put("bondLabelSize", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Color Atoms By Type")) {
      if (!preference.isDefault()) {
        preferences.put("colorAtomsByType", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Default BondLength")) {
      if (!preference.isDefault()) {
        preferences.put("defaultBondLength", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Display Chiral Stereo Labels")) {
      if (!preference.isDefault()) {
        preferences.put("displayChiralStereoLabels", preference.getPreferenceValue().toString().toUpperCase().replace(' ', '_'));
      }
    } else if (preference.getPreferenceName().equals("Foreground Color")) {
      if (!preference.isDefault()) {
        preferences.put("foregroundColor", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Hydrogen Display Mode")) {
      if (!preference.isDefault()) {
        preferences.put("hydrogenDisplayMode", preference.getPreferenceValue().toString().toUpperCase().replace(' ', '_'));
      }
    } else if (preference.getPreferenceName().equals("Label Height")) {
      if (!preference.isDefault()) {
        preferences.put("labelHeight", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Pol Atom Display Mode")) {
      if (!preference.isDefault()) {
        preferences.put("polAtomDisplayMode", preference.getPreferenceValue().toString().toUpperCase().replace(' ', '_'));
      }
    } else if (preference.getPreferenceName().equals("Stereo Abs Color")) {
      if (!preference.isDefault()) {
        preferences.put("stereoAbsColor", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Stereo And Color")) {
      if (!preference.isDefault()) {
        preferences.put("stereoAndColor", (String) preference.getPreferenceValue());
      }
    } else if (preference.getPreferenceName().equals("Stereo Or Color")) {
      if (!preference.isDefault()) {
        preferences.put("stereoOrColor", (String) preference.getPreferenceValue());
      }
    }

  }
}
