package amgen.ri.aig.uddi;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.item.EntityTableCacheItem;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.asf.sa.uddi.BindingDetails;
import amgen.ri.asf.sa.uddi.ClassificationSchemeNames;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.io.IOException;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.rpc.ServiceException;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;

public class ServiceLookup extends AbstractServiceLookup implements ServiceLookupIF {

  /**
   * Default constructor
   */
  public ServiceLookup() {
    super();
  }

  public ServiceLookup(AIGServlet aigServlet) {
    super(aigServlet);
  }

  /**
   * Main constructor- used only by the getAIGServlet method
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   */
  private ServiceLookup(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  /**
   * Creates this AIG Servlet object
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return AIGServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new ServiceLookup(req, resp);
  }

  /**
   * Returns the mimetype of the servlet
   */
  protected String getServletMimeType() {
    return "text/xml";
  }

  /**
   * Actual work entry stub
   *
   * @throws ServletException
   * @throws IOException
   */
  @Override
  protected void performRequest() throws ServletException, IOException {
    try {
      String serviceKey = getParameter("serviceKey");
      String resultKey = getParameter("resultKey");
      String folderItemID = getParameter("folderItemID");
      String coreServiceKeyValue = getParameter("coreServiceKeyValue");
      boolean disableParameterCache = doesParameterExist("disableParameterCache");
      if (doesParameterEqual("binding", "sdXML")) {
        Document sdXMLDoc;
        if (ServiceCache.getServiceCache(request).containsServiceDetailsForResult(resultKey)) {
          ServiceResultCacheItem resultCacheItem = ServiceCache.getServiceCache(request).getServiceResult(resultKey);
          ServiceDetails serviceDetails = resultCacheItem.getServiceDetails();
          setSecurityServiceParameters(serviceDetails);
          sdXMLDoc = processSDXML(serviceDetails, true);
        } else if (ExtString.hasLength(folderItemID)) {
          ServiceDetails serviceDetails = getServiceDetailsFromFavoriteFolderItem(new Integer(folderItemID), !disableParameterCache);
          setSecurityServiceParameters(serviceDetails);
          sdXMLDoc = processSDXML(serviceDetails, true);
        } else {
          ServiceDetails serviceDetails = ServiceCache.getServiceCache(request).getService(serviceKey);
          if (!disableParameterCache && serviceDetails.isParametersSaveable()) {
            setRecentParameters(serviceDetails);
          }
          setSecurityServiceParameters(serviceDetails);
          sdXMLDoc = processSDXML(serviceDetails, true);
          if (doesParameterExist("coreServiceKeyValue", true)) {
            Element serviceEl = ExtXMLElement.getXPathElement(sdXMLDoc, "//Service[1]");
            if (serviceEl != null) {
              Document recentParametersDoc = getRecentParameters(serviceDetails);
              Element recentCoreServiceParametersEl = ExtXMLElement.getXPathElement(recentParametersDoc, "//Service[1]/CoreServiceParameterSet");
              if (recentCoreServiceParametersEl != null) {
                serviceEl.addContent((Element) recentCoreServiceParametersEl.clone());
              }
            }
          }
        }
        ExtXMLElement.write(sdXMLDoc, response.getWriter());
      } else if (ExtString.hasLength(folderItemID)) {
        Document serviceDoc = getServiceDocumentFromFavoriteFolderItem(new Integer(folderItemID), false);
        ExtXMLElement.addTextElement(serviceDoc.getRootElement(), "FolderItemID", folderItemID);
        ExtXMLElement.write(serviceDoc, response.getWriter());
      } else if (ExtString.hasLength(coreServiceKeyValue)) {
        ServiceDetails serviceDetails = ServiceCache.getServiceCache(request).getCoreServiceByKeyValue(coreServiceKeyValue);
        if (serviceDetails != null) {
          setSecurityServiceParameters(serviceDetails);
          Document serviceDoc = new Document(serviceDetails.getAsElement());
          ExtXMLElement.addTextElement(serviceDoc.getRootElement(), "SDBinding", serviceDetails.getSDURL() + "");
          ExtXMLElement.write(serviceDoc, response.getWriter());
        }
      } else {
        ServiceDetails serviceDetails = ServiceCache.getServiceCache(request).getService(serviceKey);
        setSecurityServiceParameters(serviceDetails);
        Document serviceDoc = new Document(serviceDetails.getAsElement());
        ExtXMLElement.addTextElement(serviceDoc.getRootElement(), "SDBinding", serviceDetails.getSDURL() + "");
        ExtXMLElement.write(serviceDoc, response.getWriter());
      }
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  @Override
  public Document getServicesDocument() throws JDOMException, AIGException {
    String serviceKey = getParameter("serviceKey");
    String resultKey = getParameter("resultKey");
    String coreServiceKeyValue = getParameter("coreServiceKeyValue");
    ServiceCache serviceCache = ServiceCache.getServiceCache(request);
    ServiceDetails service = null;
    if (ExtString.hasLength(resultKey) && serviceCache.containsServiceDetailsForResult(resultKey)) {
      ServiceResultCacheItem resultCacheItem = serviceCache.getServiceResult(resultKey);
      service = resultCacheItem.getServiceDetails();
      if (!serviceCache.verifyServiceActive(service)) {
        throw new AIGException(String.format("Service (%s) is offline", service.getKey()), AIGException.Reason.SERVICE_OFFLINE);
      }
    } else if (doesParameterExist("folderItemID")) {
      try {
        Document savedServiceDocument = getSavedServiceDocument(getParameterNumber("folderItemID").intValue());
        serviceKey = ExtXMLElement.getXPathValue(savedServiceDocument, "//ServiceKey");
        serviceCache.verifyServiceActive(serviceKey);
        service = serviceCache.getService(serviceKey);
      } catch (Exception e) {
        e.printStackTrace();
      }
    } else if (ExtString.hasLength(coreServiceKeyValue)) {
      service = serviceCache.getCoreServiceByKeyValue(coreServiceKeyValue);
      serviceCache.verifyServiceActive(service);
    } else {
      serviceCache.verifyServiceActive(serviceKey);
      service = serviceCache.getService(serviceKey);
    }
    Document servicesDocument = new Document(new Element("Services"));
    try {
      if (service.containsUserInAllowedUsers(getSessionLogin().getRemoteUser(), true)) {
        ServiceAttributes serviceAttributes = new ServiceAttributes(service, getEntityClassManager());
        Element searchServiceElement = getServiceElement(service);
        if (searchServiceElement != null) {
          boolean showResources = true;
          BindingDetails rawTableBinding = service.getResultTypeBinding(TModelCommonNameFactory.QUERYRGRAWENTITYTABLEDEFINITION_TMODELNAME);
          if (rawTableBinding != null || serviceAttributes.getEntityListCategory().size() > 1) {
            showResources = false;
          }

          servicesDocument.getRootElement().addContent(searchServiceElement);
          ExtXMLElement.addTextElement(searchServiceElement, "ID", UUID.randomUUID() + "");
          Element nameElement = searchServiceElement.getChild("Name");
          nameElement.setText(serviceAttributes.getName(ServiceNamingContext.RG_QUERY));
          Element descElement = searchServiceElement.getChild("Description");
          descElement.setText(serviceAttributes.getDescription(ServiceNamingContext.RG_QUERY));
          ExtXMLElement.addElement(searchServiceElement, "EditableParams", serviceAttributes.countEditableParameters(null) + "");
          ExtXMLElement.addElement(searchServiceElement, "IconCls", serviceAttributes.getIconClass(ServiceNamingContext.RG_LOFT));
          ExtXMLElement.addElement(searchServiceElement, "IsVQT", serviceAttributes.isServiceVQTEngine() + "");
          ExtXMLElement.addElement(searchServiceElement, "IsWidget", serviceAttributes.isWidget() + "");

          if (serviceAttributes.isWidget()) {
            ExtXMLElement.addElement(searchServiceElement, "WidgetURL", serviceAttributes.getWidgetURL() + "");
            List<String> widgetProperties = serviceAttributes.getWidgetProperties();
            Element widgetPropertiesEl = ExtXMLElement.addElement(searchServiceElement, "WidgetProperties");
            for (String widgetProperty : widgetProperties) {
              ExtXMLElement.addElement(widgetPropertiesEl, "WidgetProperty", widgetProperty);
            }
          }

          ExtXMLElement.addElement(searchServiceElement, "IsParametersSaveable", serviceAttributes.isServiceParametersSaveable() + "");
          ExtXMLElement.addTextElement(searchServiceElement, "CategoryTag", serviceAttributes.getFirstEntityListCategoryLabel());
          ExtXMLElement.addTextElement(searchServiceElement, "EntityCategory", serviceAttributes.getFirstEntityListCategory() + "");
          ExtXMLElement.addElement(searchServiceElement, "IsDefaultView", serviceAttributes.isEntityDefaultView() + "");
          ExtXMLElement.addTextElement(searchServiceElement, "ShowResources", showResources + "");

          if (doesParameterExist("folderItemID")) {
            ExtXMLElement.addTextElement(searchServiceElement, "FolderItemID", getParameter("folderItemID"));
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return servicesDocument;
  }

  @Override
  public JSONObject getServiceRecords() throws JDOMException, AIGException {
    return getServiceRecords(getServicesDocument());
  }

  /**
   * processSDXML
   *
   * @param document Document
   * @return Document
   */
  private Document processSDXML(ServiceDetails serviceDetails, boolean includeParameterValues) throws ServiceException, JDOMException, IOException {
    if (doesParameterExist("entityTableKey")) {
      String entityTableKey = getParameter("entityTableKey");
      EntityTableCacheItem entityTableCacheItem = ServiceCache.getServiceCache(request).getEntityTableResult(entityTableKey);
      if (entityTableCacheItem != null) {
        EntityListCategory tableListCategory = entityTableCacheItem.getEntityTable().getEntityCategory();
        List<ServiceDataCategory> serviceDataCategories = new ArrayList<ServiceDataCategory>(getEntityClassManager().convertEntityListCategoryToServiceDataCategories(tableListCategory));
        List<String> serviceDataCategoryNames = ServiceDataCategory.revertTo(serviceDataCategories);
        Map<ClassificationSchemeNames, List<String>> disableParamMap = new HashMap<ClassificationSchemeNames, List<String>>();
        disableParamMap.put(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME, serviceDataCategoryNames);
        return serviceDetails.getSDXMLDocument(disableParamMap, includeParameterValues);
      }
    }
    return serviceDetails.getSDXMLDocument(includeParameterValues);
  }
}
