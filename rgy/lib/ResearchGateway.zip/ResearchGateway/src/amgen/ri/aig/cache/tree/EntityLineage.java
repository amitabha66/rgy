package amgen.ri.aig.cache.tree;

import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.entitylist.EntityIF;
import java.util.ArrayList;
import java.util.List;
import org.jdom.Element;

/**
 *
 * @version $id$
 */
public class EntityLineage implements EntityIF {
  private String text;

  private String description;
  private EntityListCategory dataCategory;
  private ServiceDataCategory serviceDataCategory;
  private String dataValue;
  private String entityUUID;
  private int distance;


  public EntityLineage(String text, String description, ServiceDataCategory serviceDataCategory, EntityListCategory dataCategory, String dataValue, String entityUUID) {
    this.text = text;
    this.description = description;
    this.entityUUID = entityUUID;
    setDataValue(dataValue);
    this.serviceDataCategory = serviceDataCategory;
  }

  public String getLabel() {
    return text;
  }

  public void setLabel(String text) {
    this.text = text;
  }
  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }
  
  public void setDataValue(String dataValue) {
    this.dataValue = dataValue;
  }

  public String getDataValue() {
    return dataValue;
  }

  public String getEntityUUID() {
    return entityUUID;
  }

  public ServiceDataCategory getServiceDataCategory() {
    return serviceDataCategory;
  }

  public EntityListCategory getEntityCategory() {
    return dataCategory;
  }

  /**
   * Get the value of distance- this is an optional value indicating the distance from a starting point
   *
   * @return the value of distance
   */
  public int getDistance() {
    return distance;
  }

  /**
   * Set the value of distance- this is an optional value indicating the distance from a starting point
   *
   * @param distance new value of distance
   */
  public void setDistance(int distance) {
    this.distance = distance;
  }

  public String toString() {
    return getEntityCategory() + " (" + getServiceDataCategory() + "=" + getDataValue()+")";
  }

  /**
   * Returns a list of lineage TREENODE elements as an EntityLineage List
   *
   * @param lineageElements List
   * @return List
   */
  public static List<EntityLineage> getEntityLineageFromTreeNodes(List<Element> lineageElements) {
    List<EntityLineage> lineage = new ArrayList<EntityLineage>();
    try {
      for (Element lineageElement : lineageElements) {
        EntityLineage entityLineage= getEntityLineageForTreeNode(lineageElement);       
        if (entityLineage != null) {
          lineage.add(entityLineage);
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return lineage;
  }

  /**
   * Returns a lineage object for a TREENODE element
   *
   * @param treeNodeElement List
   * @return List
   * @fixme EntityClassManager
   */
  public static EntityLineage getEntityLineageForTreeNode(Element treeNodeElement) {
    String treeNodeText = treeNodeElement.getAttributeValue("TEXT");
    String treeNodeDesc = treeNodeElement.getAttributeValue("TITLE");
    String entityUUID = treeNodeElement.getAttributeValue("UUID");
    ServiceDataCategory serviceDataCategory= ServiceDataCategory.fromString(treeNodeElement.getAttributeValue("SERVICE_DATA_TYPE_CATEGORY"));
    EntityListCategory dataCategory= new EntityClassManager().convertServiceDataCategoryToEntityListCategory(serviceDataCategory);
    String treeNodeServiceData = treeNodeElement.getAttributeValue("SERVICE_DATA");  
    
    if (treeNodeServiceData == null || treeNodeServiceData.length() == 0) {
      treeNodeServiceData = treeNodeText;
    }
    if (!serviceDataCategory.equals(ServiceDataCategory.UNKNOWN) && !dataCategory.equals(EntityListCategory.UNKNOWN)) {
      return new EntityLineage(treeNodeText, treeNodeDesc, serviceDataCategory, dataCategory, treeNodeServiceData, entityUUID);
    }
    return null;
  }
}
