package amgen.ri.aig.quick;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.aig.AIGServlet;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONObject;

public class QuickLaunchEngine extends AIGServlet {
    static Map<String, List<QuickLaunchItem>> quickLaunchItemsMap = new HashMap();


    static {
        List<QuickLaunchItem> stuffArray = new ArrayList();
        quickLaunchItemsMap.put("Stuff", stuffArray);
        stuffArray.add(new QuickLaunchItem("My Projects", "project_icon.gif", "GO"));
        stuffArray.add(new QuickLaunchItem("My Projects", "project_icon.gif", "GO"));
        stuffArray.add(new QuickLaunchItem("My Projects", "project_icon.gif", "GO"));
        stuffArray.add(new QuickLaunchItem("My Projects", "project_icon.gif", "GO"));
        stuffArray.add(new QuickLaunchItem("My Projects", "project_icon.gif", "GO"));
        stuffArray.add(new QuickLaunchItem("My Projects", "project_icon.gif", "GO"));
        stuffArray.add(new QuickLaunchItem("My Projects", "project_icon.gif", "GO"));
        stuffArray.add(new QuickLaunchItem("My Projects", "project_icon.gif", "GO"));
        stuffArray.add(new QuickLaunchItem("My Projects", "project_icon.gif", "GO"));
        stuffArray.add(new QuickLaunchItem("My Projects", "project_icon.gif", "GO"));
        stuffArray.add(new QuickLaunchItem("My Projects", "project_icon.gif", "GO"));
        stuffArray.add(new QuickLaunchItem("My Projects", "project_icon.gif", "GO"));
        stuffArray.add(new QuickLaunchItem("My Projects", "project_icon.gif", "GO"));
        stuffArray.add(new QuickLaunchItem("My Projects", "project_icon.gif", "GO"));
        stuffArray.add(new QuickLaunchItem("My Projects", "project_icon.gif", "GO"));

        List<QuickLaunchItem> actionsArray = new ArrayList();
        quickLaunchItemsMap.put("Actions", actionsArray);
        actionsArray.add(new QuickLaunchItem("Launch", "launch_icon.gif", "GO"));
        actionsArray.add(new QuickLaunchItem("Launch", "launch_icon.gif", "GO"));
        actionsArray.add(new QuickLaunchItem("Launch", "launch_icon.gif", "GO"));

    }

    public QuickLaunchEngine() {
        super();
    }

    public QuickLaunchEngine(HttpServletRequest req, HttpServletResponse resp) {
        super(req, resp);
    }

    /**
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return TBXServlet
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new QuickLaunchEngine(req, resp);
    }

    /**
     *
     * @return String
     */
    protected String getServletMimeType() {
        return "";
    }

    /**
     *
     * @throws Exception
     */
    protected void performRequest() throws Exception {
        QuickLaunchRequest quickRequest = QuickLaunchRequest.fromString(getParameter("quick"));

        switch (quickRequest) {
            case LIST:
                JSONArray stuffArray = new JSONArray();
                for (QuickLaunchItem quickLaunchItem : quickLaunchItemsMap.get("Stuff")) {
                    stuffArray.put(new JSONObject(quickLaunchItem, new String[] {"name", "icon", "action"}));
                }
                JSONArray actionsArray = new JSONArray();
                for (QuickLaunchItem quickLaunchItem : quickLaunchItemsMap.get("Actions")) {
                    actionsArray.put(new JSONObject(quickLaunchItem, new String[] {"name", "icon", "action"}));
                }
                JSONObject quickLaunchItemsJSON = new JSONObject();
                quickLaunchItemsJSON.put("Stuff", stuffArray);
                quickLaunchItemsJSON.put("Actions", actionsArray);
                quickLaunchItemsJSON.write(response.getWriter());
        }
    }
}
