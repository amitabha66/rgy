package amgen.ri.aig.projectview.filterables;

import java.util.Map;

import org.jdom.Element;
import org.jdom.Namespace;

import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;

/**
 * Encapsulates a filterables include the VQT ids, name, units, type, group.
 * Also holds the set value, operator and sort
 */
public class ListQueryable extends ProjectViewFilterable {

    /**
     * Creates a normal ProjectViewFilterable
     *
     * @param queryable_id String
     * @param retrievable_id String
     * @param name String
     * @param units String
     * @param type String
     * @param group String
     */
    public ListQueryable(String filterable_id, String queryable_id, String retrievable_id, String name, String units, String group) {
        super(filterable_id, queryable_id, retrievable_id, name, "Lists", units, "list", group);
    }

    public Element getVQTQueryableEl(String uid, Namespace ns) {
        if (!ExtString.hasLength(getValue())) {
            return null;
        }
        Element queryableEl = new Element("queryable", ns);
        ExtXMLElement.addAttribute(queryableEl, "uid", uid);
        ExtXMLElement.addAttribute(queryableEl, "id", getQueryable_id());
        ExtXMLElement.addAttribute(queryableEl, "name", getName());
        ExtXMLElement.addTextElement(queryableEl, "description", getName() + " " + getValue(), ns);
        Element parametersEl = ExtXMLElement.addElement(queryableEl, "parameters", ns);
        //Single Parameter
        Map<String, String> vqtParameters = getVQTParameters();
        if (vqtParameters.size() > 0) {
            Element parameterEl = ExtXMLElement.addElement(parametersEl, "parameter", ns);
            ExtXMLElement.addTextElement(parameterEl, "name", vqtParameters.keySet().iterator().next(), ns);
            ExtXMLElement.addTextElement(parameterEl, "value", getValue(), ns);
        }
        return queryableEl;
    }

}
