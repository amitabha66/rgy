package amgen.ri.aig.entity;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jdom.Document;
import org.jdom.output.Format;

import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.entity.provider.AbstractEntityDetails;
import amgen.ri.aig.entity.provider.EntityDetailsResponseIF;
import amgen.ri.aig.entity.provider.EntityNodeDetails;
import amgen.ri.aig.entity.provider.EntityQuery;
import amgen.ri.util.Debug;
import amgen.ri.xml.ExtXMLElement;

/**
 * Handler for Entity Properties and basic queries for AIG components like the
 * AssaySelector
 *
 * @version $Id: EntityDetailsQueryHandler.java,v 1.3 2012/03/08 06:32:12 cvs Exp $
 */
public class EntityDetailsQueryHandler extends AIGServlet {
    private EntityDetailsQueryRequest entityDetailsRequest;
    private boolean isJSONOputput;
    /**
     * Default constructor
     */
    public EntityDetailsQueryHandler() {
        super();
    }

    /**
     * Main constructor- used only by the getAIGServlet method
     *
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    private EntityDetailsQueryHandler(HttpServletRequest request, HttpServletResponse response) {
        super(request, response);
        entityDetailsRequest = EntityDetailsQueryRequest.UNKNOWN;
        if (doesParameterExist("uuid", true)) {
            entityDetailsRequest = EntityDetailsQueryRequest.NODE_DETAILS;
        } else if (doesParameterExist("type", true) && doesParameterExist("query", true)) {
            entityDetailsRequest = EntityDetailsQueryRequest.ENTITY_QUERY;
        } else if (doesParameterExist("type", true) && doesParameterExist("id", true)) {
            entityDetailsRequest = EntityDetailsQueryRequest.ENTITY_DETAILS;
        }
        isJSONOputput = doesParameterEqual("format", "json");
    }

    /**
     * Creates this AIG Servlet object
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return AIGServlet
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new EntityDetailsQueryHandler(req, resp);
    }

    /**
     * Instantiates the response provider and calls the appropriate response
     *
     * @throws ServletException
     * @throws IOException
     */
    public void performRequest() throws ServletException, IOException {
        EntityDetailsResponseIF entityDetailsResponse = null;
        switch (entityDetailsRequest) {
            case NODE_DETAILS:
                entityDetailsResponse = new EntityNodeDetails(this);
                break;
            case ENTITY_DETAILS:
                entityDetailsResponse = AbstractEntityDetails.getEntityDetails(this);
                break;
            case ENTITY_QUERY:
                entityDetailsResponse = new EntityQuery(this);
                break;
        }

        if (entityDetailsResponse == null) {
            return;
        }
        try {
            if (isJSONOputput) {
                entityDetailsResponse.getResponseJSON().write(response.getWriter());
            } else {
                Document entityDetailsDoc = entityDetailsResponse.getResponseDocument();
                if (entityDetailsDoc != null) {
                    Format f = Format.getCompactFormat();
                    f.setEncoding("US-ASCII");
                    ExtXMLElement.write(entityDetailsDoc, response.getWriter(), f);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Returns the mimetype of the servlet
     */
    protected String getServletMimeType() {
        if (isJSONOputput) {
            return "text/json";
        } else {
            return "text/xml";
        }
    }


}
