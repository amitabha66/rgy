package amgen.ri.aig.projectview.filterables;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.jdom.Element;
import org.jdom.Namespace;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtDate;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;

/**
 * Abstract base class for encapsulates a filterables include the VQT ids, name, units, type, group.
 * Also holds the set value, operator and sort
 */
public abstract class AbstractFilterable implements ProjectViewFilterableIF {
    protected SimpleDateFormat vqtDateFormat= new SimpleDateFormat("dd MMM yyyy");

    private String filterable_id;

    private String queryable_id;
    private String retrievable_id;
    private Map<String, String> vqtParameters;

    private String name;
    private String category;
    private String units;
    private String type;
    private String group;

    private String value;
    private String operator;
    private String sort;
    private Map<String, String> filterableParameters;


    /**
     * Creates a normal ProjectViewFilterable
     *
     * @param queryable_id String
     * @param retrievable_id String
     * @param name String
     * @param units String
     * @param type String
     * @param group String
     */
    public AbstractFilterable(String filterable_id, String queryable_id, String retrievable_id, String name, String category, String units, String type, String group) {
        this.filterable_id = filterable_id;
        this.queryable_id = queryable_id;
        this.retrievable_id = retrievable_id;
        this.name = name;
        this.category = category;
        this.units = units;
        this.type = type;
        this.group = group;
        this.filterableParameters = new HashMap<String, String>();
        Map<String, String> vqtParameterNames = new HashMap<String, String>();
    }

    /**
     * getQueryable_id
     *
     * @return String
     */
    public String getQueryable_id() {
        return queryable_id;
    }

    /**
     * getRetrievable_id
     *
     * @return String
     */
    public String getRetrievable_id() {
        return retrievable_id;
    }

    /**
     * getName
     *
     * @return String
     */
    public String getName() {
        return name;
    }

    /**
     * getUnits
     *
     * @return String
     */
    public String getUnits() {
        return units;
    }

    /**
     * getType
     *
     * @return String
     */
    public String getType() {
        return type;
    }

    /**
     * getGroup
     *
     * @return String
     */
    public String getGroup() {
        return group;
    }

    /**
     * getValue
     *
     * @return String
     */
    public String getValue() {
        return value;
    }

    /**
     * getOperator
     *
     * @return String
     */
    public String getOperator() {
        return getOperator(false);
    }

    /**
     * getOperator
     *
     * @param singleChar boolean
     * @return String
     */
    public String getOperator(boolean singleChar) {
        if (operator == null) {
            return null;
        }
        if (singleChar) {
            if (operator.equals("exists")) {
                return "exists";
            }
            if (operator.equals("is greater than")) {
                return ">";
            }
            if (operator.equals("after")) {
                return ">";
            }
            if (operator.equals("is less than")) {
                return "<";
            }
            if (operator.equals("before")) {
                return "<";
            }
            if (operator.equals("equals")) {
                return "=";
            }
            if (operator.equals("on")) {
                return "=";
            }
        }
        return operator;
    }

    /**
     * Returns a Date String formatted to that used by VQT or null if the input String
     * can not be parsed intoa Date object using ExtDate.toDate
     *
     * @param date String
     * @return String
     */
    public String getVQTFormattedDate(String date) {
        Date d= ExtDate.toDate(date);
        if (d!= null) {
            return vqtDateFormat.format(d);
        }
        return null;
    }

    public String getFilterable_id() {
        return filterable_id;
    }


    public void setValue(String value) {
        if (value == null || ExtString.equals(value, "null")) {
            this.value = null;
        } else {
            this.value = value;
        }
    }

    public void setOperator(String operator) {
        if (operator == null || ExtString.equals(operator, "null")) {
            this.operator = null;
        } else {
            this.operator = operator;
        }
    }

    public void setSort(String sort) {
        if (sort == null || ExtString.equals(sort, "null")) {
            this.sort = null;
        } else {
            this.sort = sort;
        }
    }

    public void setVQTParameters(Map<String, String> vqtParameters) {
        this.vqtParameters = vqtParameters;
    }

    public Map<String, String> getVQTParameters() {
        return vqtParameters;
    }

    public Map<String, String> getFilterableParameters() {
        return filterableParameters;
    }
    public String getFilterableParameter(String parameter) {
        return filterableParameters.get(parameter);
    }
    public boolean doesFilterableParameterExist(String parameter) {
        return ExtString.hasLength(filterableParameters.get(parameter));
    }

    /*
     *
     * ProjectViewFilterableIF Implementations
     *
     */

    abstract public Element getVQTQueryableEl(String uid, Namespace ns);

    public Element getVQTRetrievableEl(Namespace ns) {
        if (getVQTQueryableEl("", ns) == null && !ExtString.equalsIgnoreCase(getSort(), "ascending") && !ExtString.equalsIgnoreCase(getSort(), "descending")) {
            return null;
        }
        if (ExtString.equals(getRetrievable_id(), "0")) {
            return null;
        }
        Element retrievableEl = new Element("retrievable", ns);
        ExtXMLElement.addAttribute(retrievableEl, "id", getRetrievable_id());
        ExtXMLElement.addAttribute(retrievableEl, "name", getName());
        ExtXMLElement.addTextElement(retrievableEl, "description", getName() + (getUnits() != null ? " " + getUnits() : ""), ns);
        return retrievableEl;
    }

    public void resetFilterable() {
        setOperator(null);
        setSort(null);
        setValue(null);
    }

    public void updateFilterable(JSONObject jFilterable) {
        setOperator(jFilterable.optString("operator", "null"));
        setSort(jFilterable.optString("sort", "null"));
        setValue(jFilterable.optString("value", "null"));
        if (jFilterable.has("parameters")) {
            try {
                JSONObject filterParams = jFilterable.getJSONObject("parameters");
                Iterator<String> keys = filterParams.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    filterableParameters.put(key, filterParams.getString(key));
                }
            } catch (Exception e) {}
        }
    }


    public JSONObject createFilterableJSON() {
        JSONObject assayFilterable = new JSONObject();
        try {
            assayFilterable.put("id", getFilterable_id());
            assayFilterable.addIfNotNull("name", getName());
            assayFilterable.addIfNotNull("units", getUnits());
            assayFilterable.addIfNotNull("type", getType());
            assayFilterable.addIfNotNull("group", getGroup());

            assayFilterable.addIfNotNull("operator", getOperator());
            assayFilterable.addIfNotNull("sort", getSort());
            assayFilterable.addIfNotNull("value", getValue());

            assayFilterable.put("sortable", !getRetrievable_id().equals("0"));
        } catch (JSONException ex) {
        }
        return assayFilterable;

    }

    public String getSort() {
        return sort;
    }

    public String getCategory() {
        return category;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("queryable_id" + " = " + getQueryable_id());
        sb.append("\n");
        sb.append("retrievable_id" + " = " + getRetrievable_id());
        sb.append("\n");
        sb.append("name" + " = " + name);
        sb.append("\n");
        sb.append("units" + " = " + units);
        sb.append("\n");
        sb.append("type" + " = " + type);
        sb.append("\n");
        sb.append("group" + " = " + group);
        sb.append("\n");
        sb.append("value" + " = " + value);
        sb.append("\n");
        sb.append("operator" + " = " + operator);
        sb.append("\n");
        sb.append("sort" + " = " + sort);
        return sb.toString();
    }

}
