package amgen.ri.aig.view;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.xml.ExtXMLElement;

public class EntityServiceHTMLView extends EntityServiceView {
    public EntityServiceHTMLView(AIGServlet aigServlet) {
        super(aigServlet);
    }

    /**
     * renderServiceResult
     *
     * @param resultItem ServiceResultCacheItem
     * @param outWriter Writer
     * @param outStream OutputStream
     * @throws IOException
     */
    public void renderServiceResult(Object resultObj, ServiceResultCacheItem parentResultItem, ServiceDetails serviceDetails, HttpServletRequest request, HttpServletResponse response) throws
            IOException {
        String[] scriptContainerElNames = {"Head", "Body"};
        Document htmlDocument = (Document) resultObj;
        Element scriptContainerEl = null;
        for (String scriptContainerElName : scriptContainerElNames) {
            scriptContainerEl = ExtXMLElement.getXPathElement(htmlDocument, "//" + scriptContainerElName);
            if (scriptContainerEl != null) {
                break;
            }
            scriptContainerEl = ExtXMLElement.getXPathElement(htmlDocument, "//" + scriptContainerElName.toLowerCase());
            if (scriptContainerEl != null) {
                break;
            }
            scriptContainerEl = ExtXMLElement.getXPathElement(htmlDocument, "//" + scriptContainerElName.toUpperCase());
            if (scriptContainerEl != null) {
                break;
            }
        }
        if (scriptContainerEl != null) {
            ExtXMLElement.addElement(scriptContainerEl, "SCRIPT", "document.domain='amgen.com'");
        }

        Format format = Format.getCompactFormat();
        format.setOmitDeclaration(true);
        format.setExpandEmptyElements(true);

        XMLOutputter outputtter = new XMLOutputter(format);
        outputtter.output((Document) resultObj, response.getWriter());
    }

    /**
     * Returns the mimetype for the view
     *
     * @return String
     */
    public String getViewMimetype() {
        return "text/html";
    }

}
