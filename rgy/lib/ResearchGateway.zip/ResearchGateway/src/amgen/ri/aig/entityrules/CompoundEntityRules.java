package amgen.ri.aig.entityrules;

import amgen.ri.aig.cache.tree.TreeNode;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.entitylist.EntityListMemberIF;
import amgen.ri.aig.entitylist.GenericEntityListMember;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtString;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * Class used to enforce business rules when processing nodes or
 * EntityListMembers for an EntityType
 *
 * @version $id$
 */
public class CompoundEntityRules extends AbstractEntityRules {
  public CompoundEntityRules(EntityListCategory entityType) {
    super(entityType);
    if (!entityType.equals(EntityListCategory.SUBSTANCES) && !entityType.equals(EntityListCategory.COMPOUNDS) && !entityType.equals(EntityListCategory.SMR_MOLECULES) && !entityType.equals(EntityListCategory.SMR_STRUCTURES)) {
      throw new IllegalArgumentException("Invalid type for rules");
    }
  }

  /**
   * applyEntityRules
   *
   * @param node TreeNode
   * @return TreeNode @todo Implement this
   * amgen.ri.aig.entityrules.EntityRulesIF method
   */
  public TreeNode applyEntityRules(TreeNode node) {
    basicProcessing(node);
    switch (getEntityType()) {
      case SUBSTANCES:
        return applyEntityRules4SubstanceNode(node);
      case COMPOUNDS:
      case SMR_STRUCTURES:
      case SMR_MOLECULES:
        return applyEntityRules4CompoundNode(node);
    }
    return null;
  }

  /**
   * applyEntityRules
   *
   * @param member EntityListMemberIF
   * @return EntityListMemberIF
   */
  public EntityListMemberIF applyEntityRules(EntityListMemberIF member, ServiceDataCategory memberServiceDataCategory) {
    if (member == null || !ExtString.hasTrimmedLength(member.getMember())) {
      return null;
    }
    switch (getEntityType()) {
      case COMPOUNDS:
      case SMR_STRUCTURES:
      case SMR_MOLECULES:
        String id = applyIntegerIDRules(member.getMember());
        if (id == null) {
          return null;
        }
        return new GenericEntityListMember(member.getLabel(), id, null, getEntityClassManager().convertServiceDataCategoryToEntityListCategory(memberServiceDataCategory));
      case SUBSTANCES:
        return applyEntityRules4Substance(member, memberServiceDataCategory);
    }
    return member;
  }

  /**
   * Apply EntityRule to a list of IDs and return a Map of Original
   * ID:Translated ID
   *
   * @param ids List
   * @param memberServiceDataCategory ServiceDataCategory
   * @return Map
   */
  public Map<String, String> applyEntityRules(Collection<String> ids, ServiceDataCategory memberServiceDataCategory) {
    if (getEntityType().equals(EntityListCategory.SUBSTANCES) && memberServiceDataCategory.equals(ServiceDataCategory.AMGEN_SUBSTANCE_ID)) {
      try {
        return getAmgenNameForSubstanceID(new ArrayList(ids));
      } catch (SQLException ex) {
      }
    }
    return super.applyEntityRules(ids, memberServiceDataCategory);
  }

  private TreeNode applyEntityRules4CompoundNode(TreeNode node) {
    String id = applyIntegerIDRules(node.getText());
    if (id == null) {
      return null;
    }
    node.setText(id);
    node.setServiceData(id);
    return node;
  }

  private TreeNode applyEntityRules4StructureNode(TreeNode node) {
    String id = applyIntegerIDRules(node.getText());
    if (id == null) {
      return null;
    }
    node.setText(id);
    node.setServiceData(id);
    return node;
  }

  private TreeNode applyEntityRules4SubstanceNode(TreeNode node) {
    ServiceDataCategory nodeServiceDataCategory = node.getServiceDataCategory();
    String id = null;
    try {
      switch (nodeServiceDataCategory) {
        case AMGEN_SUBSTANCE_ID:
          id = applySubstanceIDRules(getAmgenNameForSubstanceID(node.getServiceData()));
          break;
        case AMGEN_NAME:
        default:
          id = applySubstanceIDRules(node.getText());
          break;
      }
    } catch (Exception e) {
      id = null;
    }
    if (id == null) {
      return null;
    }
    node.setText(id);
    node.setServiceData(id);
    node.setServiceDataCategory(ServiceDataCategory.AMGEN_NAME);
    return node;
  }

  private EntityListMemberIF applyEntityRules4Substance(EntityListMemberIF member, ServiceDataCategory memberServiceDataCategory) {
    String id = member.getMember();
    if (memberServiceDataCategory.equals(ServiceDataCategory.AMGEN_SUBSTANCE_ID)) {
      try {
        id = getAmgenNameForSubstanceID(member.getMember());
      } catch (Exception e) {
        return null;
      }
    }
    id = applySubstanceIDRules(id);
    if (id == null) {
      return null;
    }
    return new GenericEntityListMember(member.getLabel(), id, null, getEntityClassManager().convertServiceDataCategoryToEntityListCategory(memberServiceDataCategory));
  }

  /**
   * getAmgenNameForSubstanceID
   *
   * @param string String
   * @return any
   */
  private String getAmgenNameForSubstanceID(String substanceID) throws SQLException {
    return getAmgenNameForSubstanceID(Arrays.asList(new String[]{substanceID})).get(substanceID);
  }

  /**
   * getAmgenNameForSubstanceID
   *
   * @param string String
   * @return any
   */
  private Map<String, String> getAmgenNameForSubstanceID(List<String> substanceIDs) throws SQLException {
    Map<String, String> substance2AmgenNameMap = new HashMap<String, String>();
    String sql = "SELECT SUBSTANCE_ID, ROOT_NUMBER, LOT_NUMBER FROM RGDH.SM_SUBSTANCE WHERE SUBSTANCE_ID IN ";
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RGDH_JDBC+"");
      int numSQLs = ExtArray.getPages(substanceIDs, 1000);
      for (int i = 0; i < numSQLs; i++) {
        List<String> substanceIDSubList = ExtArray.getPage(substanceIDs, i, 1000);
        String compSQL = sql + "(" + ExtString.repeat("?", substanceIDSubList.size(), ",") + ")";
        PreparedStatement stmt = conn.prepareStatement(compSQL);
        for (int j = 1; j <= substanceIDSubList.size(); j++) {
          stmt.setString(numSQLs, substanceIDSubList.get(j));
        }
        ResultSet rset = stmt.executeQuery();
        while (rset.next()) {
          String substanceID = rset.getString("SUBSTANCE_ID");
          int rootNumber = rset.getInt("ROOT_NUMBER");
          int lotNumber = rset.getInt("LOT_NUMBER");
          substance2AmgenNameMap.put(substanceID, rootNumber + "#" + lotNumber);
        }
        stmt.close();
      }
      return substance2AmgenNameMap;
    } finally {
      OraSQLManager.closeResources(conn);
    }
  }

  private String applySubstanceIDRules(String id) {
    if (!ExtString.hasLength(id)) {
      return null;
    }
    if (id.indexOf('#') < 0) {
      id = id + "#1";
    }
    String[] rootLot = id.split("#", 2);
    if (rootLot.length != 2) {
      return null;
    }
    String root = rootLot[0];
    String lot = rootLot[1];

    if (ExtString.isAInteger(root) && ExtString.isAInteger(lot)) {
      id = ExtString.toInteger(root) + "#" + ExtString.toInteger(lot);
    }
    return id;
  }

  private String applyIntegerIDRules(String id) {
    if (id.indexOf('#') > 0) {
      id = id.substring(0, id.indexOf('#'));
    }
    if (ExtString.isAInteger(id)) {
      return ExtString.toInteger(id) + "";
    } else {
      return null;
    }
  }
}
