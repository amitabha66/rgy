package amgen.ri.aig.jmx;

import java.lang.management.ManagementFactory;

import javax.management.InstanceAlreadyExistsException;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanRegistrationException;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.NotCompliantMBeanException;
import javax.management.ObjectName;

import amgen.ri.util.Debug;

/**
 * <p>@version $Id: RGMBeanAgent.java,v 1.2 2011/06/21 17:28:57 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class RGMBeanAgent {

    public static void registerRGMBean() throws NullPointerException, MalformedObjectNameException, NotCompliantMBeanException, MBeanRegistrationException, InstanceAlreadyExistsException {
        Debug.print("Registering RG MBean");
        MBeanServer server = ManagementFactory.getPlatformMBeanServer();
        RGAppManager tBean = new RGAppManager();
        ObjectName tBeanName = new ObjectName("ResearchGatewayAgent:type=ResearchGatewayAppMgr");
        server.registerMBean(tBean, tBeanName);
    }
    public static void unregisterRGMBean() throws NullPointerException, MalformedObjectNameException, NotCompliantMBeanException, MBeanRegistrationException, InstanceAlreadyExistsException,
            InstanceNotFoundException {
        Debug.print("Unregistering RG MBean");
        MBeanServer server = ManagementFactory.getPlatformMBeanServer();
        ObjectName tBeanName = new ObjectName("ResearchGatewayAgent:type=ResearchGatewayAppMgr");
        server.unregisterMBean(tBeanName);
    }

}
