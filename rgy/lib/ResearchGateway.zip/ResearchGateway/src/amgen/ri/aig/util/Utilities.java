package amgen.ri.aig.util;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.entity.rgdh.SMCompound;
import amgen.ri.oracle.OraSQLManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Set of utilities used by AIG
 */
public class Utilities {

  public static final double RT = 0.5925; //Energy value (kcal/mol @ 298.15K)

  /**
   * Empty constructor
   */
  private Utilities() {
  }

  /**
   * Pulls the Amgen staff ID for a user's Amgen login from the PERSON table
   *
   * @param login String
   * @return String
   * @throws SQLException
   */
  public static String getStaffIDFromLogin(String login) throws SQLException {
    String staffID = null;
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RGDH_JDBC + "");
      PreparedStatement stmt = conn.prepareStatement("SELECT AMGEN_STAFF_ID FROM RGDH.PERSON WHERE AMGEN_LOGIN=?");
      stmt.setString(1, login);
      ResultSet rset = stmt.executeQuery();
      if (rset.next()) {
        staffID = rset.getString(1);
      }
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return staffID;
  }

  /**
   * Calculates the number of heavy (non-H) atoms in a formula of the form "<element><count> <element><count>..."
   *
   * @param formula String
   * @return int
   */
  public static int countHeavyAtoms(String formula) {
    int heavyAtomCount = 0;
    try {
      if (formula == null) {
        return -1;
      }
      Pattern elementPattern = Pattern.compile("([A-Z]{1}[a-z]{0,1})([0-9]{0,})\\s{0,}");
      Matcher elementMatcher = elementPattern.matcher(formula);
      while (elementMatcher.find()) {
        if (elementMatcher.groupCount() == 2) {
          String element = elementMatcher.group(1);
          int count = (elementMatcher.group(2).length() == 0 ? 1 : Integer.valueOf(elementMatcher.group(2)));
          if (!element.equals("H")) {
            heavyAtomCount += count;
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return heavyAtomCount;
  }

  /**
   * Calculates the binding efficiency for an IC50 value
   *
   * @param resultType String
   * @param value IC50 value in uM
   * @param formula String
   * @param heavyAtoms int
   * @return double
   */
  public static double calculateBindingEfficiency(String resultType, double value, SMCompound smCompound) {
    if (resultType == null || Double.isNaN(value) || Double.isInfinite(value) || value == 0) {
      return Double.NaN;
    }
    if (!resultType.startsWith("IC50") && !resultType.startsWith("EC50")) {
      return Double.NaN;
    }
    double heavyAtomCount = smCompound.getHeavyAtomCount();
    if (heavyAtomCount <= 0) {
      return Double.NaN;
    }
    return -RT * Math.log(value * 0.000001) / heavyAtomCount;
  }

  /**
   * Calculates the Lipophilic Efficiency (lipE) for an IC50 value
   *
   * @param resultType String
   * @param value IC50 value in uM
   * @param formula String
   * @param heavyAtoms int
   * @return double
   */
  public static double calculateLipophilicEfficiency(String resultType, double value, SMCompound smCompound) {
    if (resultType == null || Double.isNaN(value) || Double.isInfinite(value) || value == 0) {
      return Double.NaN;
    }
    if (!resultType.startsWith("IC50") && !resultType.startsWith("EC50")) {
      return Double.NaN;
    }
    if (smCompound == null || !smCompound.setData()) {
      return Double.NaN;
    }
    double cLogP = smCompound.getClogp();
    if (Double.isNaN(cLogP) || Double.isInfinite(cLogP)) {
      return Double.NaN;
    }
    return -Math.log10(value * 0.000001) - cLogP;
  }

  /**
   * Converts points <-> pixels based on 10pt Arial font.
   *
   * @param input double
   * @param isPixels double
   * @return double
   */
  public static double points2Pixels(double input, boolean isPixels) {
    //The Conversion for points/pixels assuming Arial 10pt as the default font
    double pts3pixConversion = 12.75 / 17;

    if (isPixels) { //Convert pixels -> points
      return input * pts3pixConversion;
    } else { //Convert points -> pixels
      return input / pts3pixConversion;
    }
  }

  public static Map<String, Long> dateDifference(Date start, Date end) {
    Map<String, Long> diffMap = new HashMap<String, Long>();
    Calendar calendar1 = Calendar.getInstance();
    Calendar calendar2 = Calendar.getInstance();
    calendar1.setTime(start);
    calendar2.setTime(end);
    long milliseconds1 = calendar1.getTimeInMillis();
    long milliseconds2 = calendar2.getTimeInMillis();
    long diff = milliseconds2 - milliseconds1;
    diffMap.put("MILLIS", diff);
    long diffSeconds = diff / 1000;
    diffMap.put("SECONDS", diffSeconds);
    long diffMinutes = diff / (60 * 1000);
    diffMap.put("MINUTES", diffMinutes);
    long diffHours = diff / (60 * 60 * 1000);
    diffMap.put("HOURS", diffHours);
    long diffDays = diff / (24 * 60 * 60 * 1000);
    diffMap.put("DAYS", diffDays);
    return diffMap;
  }
}
