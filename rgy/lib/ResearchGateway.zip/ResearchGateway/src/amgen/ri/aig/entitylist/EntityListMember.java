/*
 *   EntityListMember
 *   RDBData wrapper class for EntityListMember
 *   $Revision: 1.5 $
 *   Created: Jeffrey McDowell, 28 Jul 2008
 *   Modified: $Author: jemcdowe $
 *   $Log
 *
 */
package amgen.ri.aig.entitylist;

import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.Map;

import org.jdom.Element;

import amgen.ri.rdb.OraSequenceField;
import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.Removeable;
import amgen.ri.rdb.SQLManagerIF;
import amgen.ri.rdb.Saveable;
import java.util.List;
import org.jdom.Attribute;

/**
 *   RDBData wrapper class for EntityListMember
 *   @version $Revision: 1.5 $
 *   @author Jeffrey McDowell
 *   @author $Author: jemcdowe $
 */
public class EntityListMember extends RdbData implements Saveable, Removeable, EntityListMemberIF, EntityIF, Serializable {
  protected OraSequenceField entity_list_member_id;
  protected int list_id;
  protected String member;
  protected EntityListMemberAttribute[] memberAttributes;
  private EntityListCategory dataCategory;


  /**
   * Default Constructor
   */
  public EntityListMember() {
    super();
  }

  /**
   * RdbData Constructor
   */
  public EntityListMember(String entity_list_member_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
    this.entity_list_member_id = new OraSequenceField(entity_list_member_id);
  }

  /**
   * Constructor which sets the class variables
   */
  public EntityListMember(int list_id, String member, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
    this.entity_list_member_id = new OraSequenceField("entity_list_seq", this);
    this.list_id = list_id;
    this.member = member.trim();
  }

  /** A required method which returns the primary key(s) of the table/RdbData class. */
  public String getIdentifier() {
    return entity_list_member_id + "";
  }

  /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
  protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
    field.set(this, value);
  }

  /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
  protected Object getFieldValue(Field field) throws IllegalAccessException {
    return field.get(this);
  }

  /** This method returns the name of the table. */
  protected String getTableName() {
    return "ENTITY_LIST_MEMBERS";
  }

  /** Returns the SQL for INSERTing the object in the table */
  public String getInsertSQL() {
    return null;
  }

  /** Returns the SQL for UPDATing the object in the table */
  public String getUpdateSQL() {
    return null;
  }

  /** Returns the SQL for DELTEing the object/row in the table */
  public String getDeleteSQL() {
    return null;
  }

  /** Get value for list_id */
  public int getList_id() {
    return getAsNumber("list_id").intValue();
  }
  

  /** Get value for member */
  public String getMember() {
    return (String) get("member");
  }

  /** Get label for member */
  public String getLabel() {
    return getMember();
  }

  /**
   * Returns whether this member has a default view when loaded into the
   * entity tree
   */
  public String getDefaultViewServiceKey() {
    return null;
  }

  /**
   * Returns any parameters used to create a default result when loaded into the
   * entity tree
   *
   * @return Map
   */
  public Map<String, Object> getDefaultViewServiceParameters() {
    return null;
  }

  /**
   * Returns the attributes of the member
   */
  public EntityListMemberAttribute[] getMemberAttributes() {
    EntityListMemberAttribute[] attr = (EntityListMemberAttribute[]) get("memberAttributes");
    return (attr == null ? new EntityListMemberAttribute[0] : attr);
  }

  /**
   * Returns the list member as an XML element optionally including the attributes as
   *   <EntityListMember member='member'>
   *     <Attribute attribute_type='attribute_type' attribute_value='attribute_value'/>
   *   </EntityListMember>
   *
   * @return Element
   * @param includeMembers boolean
   */
  public Element getAsElement(boolean includeAttributes) {
    Element memberEl = new Element("EntityListMember");
    if (getMember() == null || getMember().length() == 0) {
      return null;
    }
    memberEl.setAttribute("member", getMember());
    if (includeAttributes) {
      for (EntityListMemberAttribute attr : getMemberAttributes()) {
        memberEl.addContent(attr.getAsElement());
      }
    }
    return memberEl;
  }
  /**
   * Returns the list member as a JSON object in the format
   * {
   *  member: <member>,
   *  attributes: [
   *   {
   *    attribute: <value>
   *   }
   *  ]
   * }
   * @param includeAttributes
   * @return
   * @throws JSONException 
   */
  public JSONObject getAsJSON(boolean includeAttributes) throws JSONException {
    JSONObject jObject = new JSONObject();
    Element memberEl = getAsElement(includeAttributes);
    List<Attribute> attrs = memberEl.getAttributes();
    for (Attribute attr : attrs) {
      jObject.put(attr.getName(), attr.getValue());
    }
    if (includeAttributes) {
      List<Element> memberAttributesEls = memberEl.getChildren("Attribute");
      for (Element memberAttributesEl : memberAttributesEls) {
        JSONObject jAttrObject = new JSONObject();
        jObject.append("attributes", jAttrObject);
        attrs = memberAttributesEl.getAttributes();
        for (Attribute attr : attrs) {
          jAttrObject.put(attr.getName(), attr.getValue());
        }
      }
    }
    return jObject;
  }

  /**
   * Performs a commit on this object saving to the database the current values of the fields
   * and performs a commit on all the EntityListMemberAttribute objects
   */
  public int performCommitAll() {
    int updateCount = performCommit(true);
    if (getMemberAttributes() != null) {
      for (EntityListMemberAttribute attr : getMemberAttributes()) {
        attr.setData();
        updateCount += attr.performCommit();
      }
    }
    return updateCount;
  }

  
  public EntityListCategory getDataCategory() {
    return dataCategory;
  }

  public void setDataCategory(EntityListCategory dataCategory) {
    this.dataCategory = dataCategory;
  }
  
  /*
   * EntityIF implementations
   */
  @Override
  public String getDataValue() {
    return getMember();
  }

  @Override
  public String getDescription() {
    return null;
  }

  @Override
  public EntityListCategory getEntityCategory() {
    return dataCategory;
  }
  
}
