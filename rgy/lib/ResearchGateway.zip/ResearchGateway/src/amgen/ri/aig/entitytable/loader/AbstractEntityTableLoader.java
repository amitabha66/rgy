package amgen.ri.aig.entitytable.loader;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.cache.tree.NodeType;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.tree.TreeNode;
import amgen.ri.aig.cache.tree.TreeNodeCache;
import amgen.ri.aig.cache.item.AbstractCacheItem.ResultRelationshipType;
import amgen.ri.aig.cache.item.CacheItemIF;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.rg.resource.ResourceFactory;
import amgen.ri.util.ExtString;
import java.util.ArrayList;
import java.util.List;
import org.jdom.Element;

/**
 * Abstract class for EntityTable loaders which are used to create new
 * EntityTable models
 *
 * @version $Id: AbstractEntityTableLoader.java,v 1.2 2011/06/21 17:28:57 cvs
 * Exp $
 */
public abstract class AbstractEntityTableLoader extends ResourceFactory implements EntityTableLoaderIF {
  private AIGBase requestor;
  private EntityListCategory entityTableType;
  private String tableName;
  private String resultNodeKey;

  /**
   * AbstractEntityTableLoader
   *
   * @param requestor AIGBase
   * @param entityTableType EntityListCategory
   */
  public AbstractEntityTableLoader(AIGBase requestor, EntityListCategory entityTableType) {
    this(requestor, entityTableType, null);
  }

  /**
   * AbstractEntityTableLoader
   *
   * @param requestor AIGBase
   * @param entityTableType EntityListCategory
   * @param resultNodeKey String
   */
  public AbstractEntityTableLoader(AIGBase requestor, EntityListCategory entityTableType, String resultNodeKey) {
    super();
    this.requestor = requestor;
    this.entityTableType = entityTableType;
    this.resultNodeKey = resultNodeKey;
    super.setEntityClassManager(requestor.getEntityClassManager());
  }

  /**
   * Returns the AIGBase requestor
   *
   * @return AIGBase
   */
  public AIGBase getRequestor() {
    return requestor;
  }

  /**
   * Returns the entity type of the table as an EntityTableType object
   *
   * @return EntityListCategory
   */
  public EntityListCategory getEntityTableType() {
    return entityTableType;
  }

  /**
   * Returns the ResultNodeKey used by Loaders which load from a result node
   *
   * @return String
   */
  public String getResultNodeKey() {
    return resultNodeKey;
  }

  /**
   * Returns the name to be used by the new table. It is either the set name or
   * created by the EntityTableType
   *
   * @return String
   */
  public String getTableName() {
    if (tableName!= null) {
      return tableName;
    }
    return EntityListCategory.revertTo(entityTableType);
  }

  /**
   * Sets the name to be used by the new table.
   */
  public void setTableName(String tableName) {
    this.tableName = tableName;
  }

  /**
   * Returns the child ResultNodes for the parent result node
   *
   * @return List
   * @throws AIGException
   */
  public List<TreeNode> getChildResultNodes() throws AIGException {
    TreeNodeCache treeNodeCache = getRequestor().getTreeNodeCache();
    Element parentTreeNode = treeNodeCache.getTreeNode(resultNodeKey);
    if (parentTreeNode == null) {
      throw new AIGException("Unable to create entity table. No treenode found.", Reason.CACHE_ERROR);
    }
    if (!NodeType.isNodeType(parentTreeNode, NodeType.RESULTNODE) && !NodeType.isNodeType(parentTreeNode, NodeType.SERVICENODE)) {
      throw new AIGException("Unable to create entity table. Invalid treenode.", Reason.CACHE_ERROR);
    }
    if (!NodeType.isNodeType(parentTreeNode, NodeType.RESULTNODE) && !NodeType.isNodeType(parentTreeNode, NodeType.SERVICENODE)) {
      throw new AIGException("Unable to create entity table. No results for treenode.", Reason.CACHE_ERROR);
    }
    List<String> childResultKeys = treeNodeCache.getChildTreeNodeKeys(resultNodeKey);
    List<TreeNode> childResultNodes = new ArrayList<TreeNode>();
    for (String childResultKey : childResultKeys) {
      childResultNodes.add(new TreeNode(treeNodeCache.getTreeNode(childResultKey)));
    }
    return childResultNodes;
  }

  /**
   * Returns the ServiceResultCacheItem for the resultNodeKey
   *
   * @return
   * @throws AIGException
   */
  public ServiceResultCacheItem getServiceResultCacheItem() throws AIGException {
    ServiceCache serviceCache = getRequestor().getServiceCache();
    return serviceCache.getServiceResult(resultNodeKey);
  }

  /**
   * Returns a related service result saved in the cache for the resultNodeKey
   * and a ResultRelationshipType.
   *
   * @param relationship
   * @return
   * @throws AIGException
   */
  public CacheItemIF getRelatedServiceResult(ResultRelationshipType relationship) throws AIGException {
    ServiceCache serviceCache = getRequestor().getServiceCache();
    return serviceCache.getRelatedServiceResult(resultNodeKey, relationship);
  }

  /**
   * createEntityTable implementation. Generally call the appropriate loader
   * method
   *
   * @return EntityTable
   * @throws AIGException
   */
  public final EntityTable createEntityTable() throws AIGException {
    EntityTable entityTable = createEntityTableModel();
    if (entityTable != null) {
      entityTable.getEntityTableJSON(true);
    }
    return entityTable;
  }

  /**
   * Creates the EntityTable model. May be overridden by subclass
   *
   * @return EntityTable
   * @throws AIGException
   */
  protected EntityTable createEntityTableModel() throws AIGException {
    EntityTable entityTable = null;
    if (ExtString.hasLength(getResultNodeKey())) {
      entityTable = createEntityTableFromResultNode(getResultNodeKey());
    }
    return entityTable;
  }

  /**
   * Users to create an EntityTable from a ResultNode. This must be overridden.
   * Default implementation throws an Exception
   *
   * @param resultNodeKey String
   * @return EntityTable
   * @throws AIGException
   */
  public EntityTable createEntityTableFromResultNode(String resultNodeKey) throws AIGException {
    throw new AIGException("Unknown error with table loader", Reason.NOT_IMPLEMENTED);
  }

}
