package amgen.ri.aig.event;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.jcs.JCS;
import org.apache.log4j.Logger;

import amgen.ri.aig.log.RGSessionLogger;
import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.servlet.SessionLogin;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;

public class SessionListener implements HttpSessionListener {
  public Logger rgLogger;

  public SessionListener() {
    try {
      rgLogger = Logger.getLogger("rg");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Notification that a session was created.
   *
   * @param se the notification event
   */
  public void sessionCreated(HttpSessionEvent se) {
    if (se.getSession().getServletContext().getInitParameter("redirect") != null) {
      //don't bother doing anything- forced redirect
      return;
    }
    String sessionIdleMinutes = se.getSession().getServletContext().getInitParameter("amgen.ri.aig.event.SessionPinger.SessionIdleMinutes");
    int sessionIdleSecs = (ExtString.isANumber(sessionIdleMinutes) ? (int) (ExtString.toDouble(sessionIdleMinutes) * 60) : 3600);

    se.getSession().setMaxInactiveInterval(sessionIdleSecs);
    SessionLogin login = SessionLogin.getSessionLogin(se.getSession());
    se.getSession().setAttribute("amgen.ri.aig.log.RGSessionLogger.jdbc", ConfigurationParameterSource.getConfigParameter("LOG_JDBC"));
    new RGSessionLogger().insertSessionStartLog(se.getSession());
    Debug.print("Session Started- <" + se.getSession().getId() + "> " + (login != null ? login.getUserLedgerDisplayName() + " (" + login.getRemoteMachineIP() + ")" : "User Unknown"), true, false);
    writeToLogger("Session Started- <" + se.getSession().getId() + "> " + (login != null ? login.getUserLedgerDisplayName() + " (" + login.getRemoteMachineIP() + ")" : "User Unknown"));
  
  }

  /**
   * Notification that a session is about to be invalidated.
   *
   * @param se the notification event
   */
  public void sessionDestroyed(HttpSessionEvent se) {
    if (se.getSession().getServletContext().getInitParameter("redirect") != null) {
      //don't bother doing anything- forced redirect
      return;
    }
    SessionLogin login = SessionLogin.getSessionLogin(se.getSession());
    new RGSessionLogger().updateSessionEndLog(se.getSession());

    Debug.print("Session Ended- <" + se.getSession().getId() + "> " + (login != null ? login.getUserLedgerDisplayName() + " (" + login.getRemoteMachineIP() + ")" : "User Unknown"), true, false);
    writeToLogger("Session Ended- <" + se.getSession().getId() + "> " + (login != null ? login.getUserLedgerDisplayName() + " (" + login.getRemoteMachineIP() + ")" : "User Unknown"));
    JCS aigCache = null;
    try {
      aigCache = JCS.getInstance("aigCache");
      aigCache.invalidateGroup(se.getSession().getId());
    } catch (Exception ex) {
      ex.printStackTrace();
    }
    if (login != null && login instanceof AIGSessionLogin) {
      try {
        ((AIGSessionLogin) login).sessionDestroyed();
      } catch (Exception e) {
      }
    }
  }

  public void writeToLogger(String msg) {
    try {
      rgLogger.info(msg);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
