package amgen.ri.aig.preferences;


/**
 * Preferences with these names are system preferences (RGPreferenceGroup with rg_preference_group_id=0 are system preferences)
 * @version $Id: SpecialUserPreferences.java,v 1.2 2015/05/28 17:24:16 jemcdowe Exp $
 */
public enum SpecialUserPreferences {
    RECENT_SERVICES, SHOW_CACHE, NORMAL;

    /**
     * Returns the UserPreferenceType by converting a String- this includes
     * converting to upper case and replacing space with underscores
     *
     * @param s String
     * @return ServiceDataCategory
     */
    public static SpecialUserPreferences fromString(String s) {
        if (s == null) {
            return NORMAL;
        }
        try {
            return SpecialUserPreferences.valueOf(s.toUpperCase().replace(' ', '_'));
        } catch (Exception e) {
            return NORMAL;
        }
    }

}
