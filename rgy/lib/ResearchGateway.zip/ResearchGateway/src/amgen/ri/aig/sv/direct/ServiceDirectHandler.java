package amgen.ri.aig.sv.direct;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.aig.cache.item.ServiceResultRawCacheItem;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.export.ExportUtils;
import amgen.ri.aig.sv.EntityServiceInvoker;
import amgen.ri.asf.sa.uddi.BindingDetails;
import amgen.ri.asf.sa.uddi.Categorization;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.ServiceParameter;
import amgen.ri.asf.sa.uddi.TModelInstanceDetails;
import amgen.ri.util.ExtString;

/**
 * <p>@version $Id: ServiceDirectHandler.java,v 1.7 2014/07/08 15:51:49 jemcdowe Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class ServiceDirectHandler extends AIGServlet {
    public ServiceDirectHandler() {
        super();
    }

    public ServiceDirectHandler(HttpServletRequest req, HttpServletResponse resp) {
        super(req, resp);
    }


    /**
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return TBXServlet
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new ServiceDirectHandler(req, resp);
    }

    /**
     *
     * @return String
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected String getServletMimeType() {
        return "text/plain";
    }

    /**
     *
     * @throws Exception
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected void performRequest() throws Exception {
        String exportName = getParameter("name", "output");
        String resultBindingType = getParameter("resultType");
    	ExportUtils exportUtils= new ExportUtils();
        EntityServiceInvoker invoker = new EntityServiceInvoker(this);
        ServiceDetails service = getServiceDetails(getParameter("serviceKey"));
        if (service == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Unknown service requested");
            return;
        }
        BindingDetails defaultResultBinding = service.getDefaultResultTypeBinding();
        if (defaultResultBinding == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "No result type found");
            return;
        }
        List<TModelInstanceDetails> instances = defaultResultBinding.getTModelInstancesWithCategorization(TModelCommonNameFactory.RESEARCH_GATEWAY_DOCUMENT_TYPES_SCHEME);

        if (instances.size() == 0) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "No document instance specified for result");
            return;
        }
        Categorization resultDocumentType = TModelCommonNameFactory.getInstance().getCategorizationByName(instances.get(0).getTModelDetails(), TModelCommonNameFactory.RESEARCH_GATEWAY_DOCUMENT_TYPES_SCHEME);
        
        
        if (resultDocumentType == null || !resultDocumentType.hasKeyValues()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "No document type specified for result");
            return;
        }
        response.setContentType(exportUtils.getMimetype(resultDocumentType));
        response.addHeader("Content-disposition", "attachment; filename=" + exportName.trim().replaceAll("\\s+", "_") + "." + exportUtils.getExtension(resultDocumentType));

        Map<String, String> serviceParams = new HashMap<String, String>();
        serviceParams.putAll(getParameters(new String[] {"name", "serviceKey", "serviceParams", "resultKey"}));

        String resultKey = invoker.invokeServiceAndCache(serviceParams, true, true);
        ServiceCache cache = ServiceCache.getServiceCache(this);
        ServiceResultCacheItem result = cache.getServiceResult(resultKey);
        if (result instanceof ServiceResultRawCacheItem) {
            byte[] results = ((ServiceResultRawCacheItem) result).getResultBytes();
            response.getOutputStream().write(results);
        } else {
            if (ExtString.hasLength(resultBindingType)) {
                BindingDetails resultBinding = service.getResultTypeBinding(resultBindingType);
                if (resultBinding!= null) {
                    result.transformResult(this, resultBinding, new ArrayList<ServiceParameter>(), null, response.getWriter());
                    return;
                }
            }
            String results = result.getCacheString();
            response.getWriter().print(results);
        }
    }
}
