package amgen.ri.aig.sv;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.tree.NodeType;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.tree.TreeNodeCache;
import amgen.ri.aig.cache.item.EntityTableCacheItem;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.aig.category.schema2.AggregatedViewType;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.entity.rgdh.DHProjectInfo;
import amgen.ri.aig.entitylist.EntityList;
import amgen.ri.aig.entitylist.EntityListIF;
import amgen.ri.aig.entitylist.EntityListMemberIF;
import amgen.ri.aig.entitylist.GenericEntityList;
import amgen.ri.aig.entitylist.GenericEntityListMember;
import amgen.ri.aig.entitytable.DataRow;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.aig.entitytable.loader.EntityLoaderFactory;
import amgen.ri.aig.entitytable.proxy.EntityTableProxy;
import amgen.ri.aig.favorites.FavoriteIF;
import amgen.ri.aig.items.ItemsManager;
import amgen.ri.aig.listener.RecentServiceUpdater;
import amgen.ri.aig.projectview.model.ProjectViewModel;
import amgen.ri.aig.record.ItemRecord;
import amgen.ri.aig.sobj.SavedObject;
import amgen.ri.aig.uddi.EntityResourcesLookup;
import amgen.ri.aig.viz.VisualizationResults;
import amgen.ri.aig.viz.VizUtils;
import amgen.ri.aig.vqt.VQTResultLoader3;
import amgen.ri.aig.vqt.VQTUtilities;
import amgen.ri.asf.sa.uddi.*;
import amgen.ri.html.GenericHTMLElement;
import amgen.ri.html.HTMLElement;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.CompareTerm;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.SocketException;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.wsdl.WSDLException;
import javax.xml.rpc.ServiceException;
import javax.xml.transform.TransformerException;
import org.apache.commons.lang.StringUtils;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.xpath.XPath;

/**
 * Handler for query requests. Query requests include loading treenodes and results from query services, loading lists,
 * loading saved view.
 */
public class ExecuteQueryService extends AIGServlet {

    //If maintains a Document of default services IF needed to be added to the TREENODES response
  // And the EntityListCategory of the service. 
  //If set, these get added to the response
  private Document defaultServicesDoc;
  private EntityListCategory serviceEntityListCategory;

  /**
   * Default constructor
   */
  public ExecuteQueryService() {
    super();
  }

  /**
   * Main constructor- used only by the getAIGServlet method
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   */
  private ExecuteQueryService(HttpServletRequest request, HttpServletResponse response) {
    super(request, response);
  }

  /**
   * Creates this AIG Servlet object
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return AIGServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new ExecuteQueryService(req, resp);
  }

  /**
   * Performs the query request- either from the input from a form or a list
   *
   * @throws ServletException
   * @throws IOException
   */
  protected void performRequest() throws ServletException, IOException {
    try {
      ServiceDetails serviceDetails = null;
      Map<String, String> inServiceParameterValues;
      ServiceAttributes serviceAttributes;
      EntityListCategory quickCategory;
      switch (ExecuteQueryRequest.getValue(this)) {
        case RUN_QUICKSEARCH:
          if (isParameterEmpty("query")) {
            throw new AIGException("Invalid request- no quick search service", Reason.ENTITY_MISMATCH);
          }
          serviceDetails = ServiceCache.getServiceCache(request).getService(getParameter("serviceKey"));
          serviceAttributes = new ServiceAttributes(serviceDetails, getEntityClassManager());

          List<ServiceParameter> serviceParameters = serviceDetails.getParameters(TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME, "Entity Quick Search");
          for (ServiceParameter serviceParameter : serviceParameters) {
            serviceParameter.setValue(getParameter("query"));
          }
          if (serviceParameters.isEmpty()) {
            throw new AIGException("Invalid service- not a quick search service", Reason.ENTITY_MISMATCH);
          }
          quickCategory = serviceAttributes.getFirstEntityListCategory();

          if (!quickCategory.equals(EntityListCategory.UNKNOWN)) {
            EntityResourcesLookup searchDialogEntityResourcesLookup = new EntityResourcesLookup(this);
            searchDialogEntityResourcesLookup.setSearchCategory(quickCategory);
            this.defaultServicesDoc = searchDialogEntityResourcesLookup.getServicesDocument("//Service[IsDefaultView='true']");
            this.serviceEntityListCategory = quickCategory;
          }

                //
        //Falls through here!!
        //  
        case RUN_QUERYSERVICE:
          if (serviceDetails == null) {
            serviceDetails = ServiceCache.getServiceCache(request).getService(getParameter("serviceKey"));

            serviceAttributes = new ServiceAttributes(serviceDetails, getEntityClassManager());
            EntityListCategory serviceEntityListCategory = serviceAttributes.getFirstEntityListCategory();
            if (!serviceEntityListCategory.equals(EntityListCategory.UNKNOWN)) {
              EntityResourcesLookup searchDialogEntityResourcesLookup = new EntityResourcesLookup(this);
              searchDialogEntityResourcesLookup.setSearchCategory(serviceEntityListCategory);
              this.defaultServicesDoc = searchDialogEntityResourcesLookup.getServicesDocument("//Service[IsDefaultView='true']");
              this.serviceEntityListCategory = serviceEntityListCategory;
            }
          }
          inServiceParameterValues = new HashMap<String, String>();
          if (doesParameterExist("service_params", true)) {
            try {
              JSONObject jsonServiceParameters = getJSONObjectParameter("service_params");
              inServiceParameterValues = jsonServiceParameters.toMap();
            } catch (Exception e) {
              e.printStackTrace();
            }
          }
          for (String parameterName : serviceDetails.getParameterNames()) {
            ServiceParameter serviceParameter = serviceDetails.getParameter(parameterName);
            String parameterValue = getParameter(parameterName);
            if (parameterValue == null && (inServiceParameterValues != null && inServiceParameterValues.containsKey(parameterName))) {
              parameterValue = inServiceParameterValues.get(parameterName);
            } else if (parameterValue == null && inServiceParameterValues != null) {
              for (String inParameterKey : inServiceParameterValues.keySet()) {
                if (serviceParameter.isCategorizedAs(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME, inParameterKey)) {
                  parameterValue = inServiceParameterValues.get(inParameterKey);
                }
              }
            }
            ServiceParameterType serviceParameterType = serviceParameter.getParameterType();
            if (serviceParameterType.equals(ServiceParameterType.BOOLEAN)) {
              if (parameterValue == null) {
                if (!ExtString.equals(serviceParameter.getParameterValueSource(), "default")) {
                  serviceDetails.setParameterValue(parameterName, "false");
                }
              } else if (parameterValue.equalsIgnoreCase("false")) {
                serviceDetails.setParameterValue(parameterName, "false");
              } else if (parameterValue.equalsIgnoreCase("true")) {
                serviceDetails.setParameterValue(parameterName, "true");
              } else {
                serviceDetails.setParameterValue(parameterName, "true");
              }
            } else if (ExtString.hasLength(parameterValue) && !ExtString.equalsIgnoreCase(parameterValue, "undefined")
                    && !parameterValue.equals("Please select a value")) {
              if (serviceParameter.isAcceptsList()) {
                String[] splitValues = parameterValue.split(";");
                for (String splitValue : splitValues) {
                  if (ExtString.hasTrimmedLength(splitValue)) {
                    serviceParameter.addValue(splitValue.trim());
                  }
                }
                serviceParameter.setParameterValueSource("list");
              } else {
                serviceDetails.setParameterValue(parameterName, parameterValue);
                if (parameterName.equals("contactLoginName")) {
                }
              }
            }
          }
          executeService(serviceDetails, true, null);
          break;
        case RUN_STRUCTURESEARCH:
          serviceDetails = getLooselyCoupledServiceDetails("QUICK_SEARCH_SSS");
          serviceAttributes = new ServiceAttributes(serviceDetails, getEntityClassManager());
          inServiceParameterValues = new HashMap<String, String>();
          if (doesParameterExist("service_params", true)) {
            try {
              inServiceParameterValues = new JSONObject(getParameter("service_params")).toMap();
            } catch (Exception e) {
            }
          }
          for (String parameterName : serviceDetails.getParameterNames()) {
            ServiceParameter serviceParameter = serviceDetails.getParameter(parameterName);
            String parameterValue = getParameter(parameterName);
            if (parameterValue == null && (inServiceParameterValues != null && inServiceParameterValues.containsKey(parameterName))) {
              parameterValue = inServiceParameterValues.get(parameterName);
            }
            ServiceParameterType serviceParameterType = serviceParameter.getParameterType();
            if (serviceParameterType.equals(serviceParameterType.BOOLEAN)) {
              if (parameterValue == null) {
                serviceDetails.setParameterValue(parameterName, "false");
              } else if (parameterValue.equalsIgnoreCase("false")) {
                serviceDetails.setParameterValue(parameterName, "false");
              } else if (parameterValue.equalsIgnoreCase("true")) {
                serviceDetails.setParameterValue(parameterName, "true");
              } else {
                serviceDetails.setParameterValue(parameterName, "true");
              }
            } else if (ExtString.hasLength(parameterValue) && !ExtString.equalsIgnoreCase(parameterValue, "undefined")
                    && !parameterValue.equals("Please select a value")) {
              if (serviceParameter.isAcceptsList()) {
                String[] splitValues = parameterValue.split(";");
                for (String splitValue : splitValues) {
                  if (ExtString.hasTrimmedLength(splitValue)) {
                    serviceParameter.addValue(splitValue.trim());
                  }
                }
                serviceParameter.setParameterValueSource("list");
              } else {
                serviceDetails.setParameterValue(parameterName, parameterValue);
              }
            }
          }
          try {
            Map<String, String> coreParameterSetMap = new HashMap<String, String>();
            String searchType = inServiceParameterValues.get("search_type");
            if (searchType != null && searchType.equalsIgnoreCase("similarity") && ExtString.isANumber(inServiceParameterValues.get("percent"))) {
              serviceDetails.setParameterValue("searchType", "MOLSIM");
              serviceDetails.setParameterValue("searchStringMOLSIM", inServiceParameterValues.get("mol"));
              serviceDetails.setParameterValue("similarityPerc", inServiceParameterValues.get("percent"));

              coreParameterSetMap.put("searchType", "MOLSIM");
              coreParameterSetMap.put("mol", inServiceParameterValues.get("mol"));
              coreParameterSetMap.put("percent", inServiceParameterValues.get("percent"));

            } else {
              serviceDetails.setParameterValue("searchType", "MOLSUB");
              serviceDetails.setParameterValue("searchStringMOLSUB", inServiceParameterValues.get("mol"));

              coreParameterSetMap.put("searchType", "MOLSUB");
              coreParameterSetMap.put("mol", inServiceParameterValues.get("mol"));
            }

            quickCategory = serviceAttributes.getFirstEntityListCategory();

            if (!quickCategory.equals(EntityListCategory.UNKNOWN)) {
              EntityResourcesLookup searchDialogEntityResourcesLookup = new EntityResourcesLookup(this);
              searchDialogEntityResourcesLookup.setSearchCategory(quickCategory);
              this.defaultServicesDoc = searchDialogEntityResourcesLookup.getServicesDocument("//Service[IsDefaultView='true']");
              this.serviceEntityListCategory = quickCategory;
            }

            executeService(serviceDetails, false, coreParameterSetMap);
          } catch (Exception e) {
            e.printStackTrace();
          }
          break;
        case RUN_SAVEDSERVICE:
          loadService(getParameter("saved_service_id"));
          break;
        case LOAD_LIST:
          EntityList entityList = new EntityList(getParameter("list_id"), new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
          if (!((EntityList) entityList).setData()) {
            throw new AIGException("Unable to load EntityList", Reason.UNABLE_TO_RETRIEVE_ENTRY);
          }
          loadEntityList(entityList, null, null, true);
          break;
        case LOAD_TABLE:
          loadEntityTable(getParameter("table_id"));
          break;
        case LOAD_LIST_FROM_PROJECTVIEW:
          ServiceResultCacheItem projectViewResult = getServiceResultCacheItem(getParameter("pv_resultKey"));
          if (projectViewResult == null) {
            throw new AIGException("Unable to load ProjectView", Reason.UNABLE_TO_RETRIEVE_ENTRY);
          }
          ProjectViewModel projViewModel = (ProjectViewModel) projectViewResult.getProperty("PROJECTVIEWDETAILS");
          entityList = new EntityList(projViewModel.getCompoundListID() + "", new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
          if (projViewModel.getCompoundList().getOrderByField() == null) {
            entityList.setOrderByField("entity_list_member_id", projViewModel.getCompoundList().isOrderByAscending());
          } else {
            entityList.setOrderByField(projViewModel.getCompoundList().getOrderByField(), projViewModel.getCompoundList().isOrderByAscending());
          }
          if (!((EntityList) entityList).setData()) {
            throw new AIGException("Unable to load EntityList", Reason.UNABLE_TO_RETRIEVE_ENTRY);
          }
          loadEntityList(entityList, null, null, true);
          break;
        case RUN_VQT:
          executeVisualQuery(getParameter("QueryRequest"), getParameter("target"));
          break;
        case RUN_VQT_COUNT:
          executeVisualQueryResultCount();
          break;
        case VQT_FOLDERITEMS:
          executeVisualQueryFolderRequest();
          break;
        case LOAD_VIEW:
          AggregatedViewType aggregatedViewType = AggregatedViewType.fromString(getParameter("view_type"));
          switch (aggregatedViewType) {
            case PROJECT_VIEW:
              loadProjectView(getParameter("project"));
              break;
            case ENTITY_TABLE:
              loadProjectViewAsTableView();
              break;
            default:
              break;
          }
          break;
        case QUICKLOAD_VIEW:
          JSONObject params = getJSONObjectParameter("service_params");
          if (params != null && params.has("quickload_view_id")) {
            String quickloadViewID = params.optString("quickload_view_id");
            loadEntityTable(quickloadViewID);
          } else if (params != null && params.has("query_run_id")) {
            String queryRunID = params.getString("query_run_id").replaceFirst("VQT:", "");
            if (ExtString.isANumber(queryRunID)) {
              loadVisualQueryResult((int) ExtString.toDouble(queryRunID), null);
            }
          } else if (doesParameterExist("query_run_id", true)) {
            loadVisualQueryResult(getParameterNumber("query_run_id").intValue(), null);
          }
          break;
        case LOAD_FAVORITE_FOLDERITEM:
          loadFavoriteFolderItem(getParameterNumber("favorite_folderitem_id").intValue());
          break;
        case UNKNOWN:
      }
    } catch (Exception ex) {
      ex.printStackTrace();
      if (ex instanceof AIGException) {
        if (((AIGException) ex).getReason().equals(Reason.TIMEOUT)) {
          response.addHeader("RG_REQUESTTIMEOUT", "true");
        }
      }
      response.addHeader("RG_ERROR", ex.getMessage());
      response.sendError(555, ex.getMessage());
    }
  }

  /**
   * Loads the target of a FavoriteFolderItem provided as an ID
   *
   * @param favoriteFolderItemID
   * @throws AIGException
   */
  private void loadFavoriteFolderItem(int favoriteFolderItemID) throws AIGException {
    ItemsManager itemsMgr = new ItemsManager(this);
    ItemRecord itemRecord = itemsMgr.getItemRecord(favoriteFolderItemID);
    FavoriteIF favorite = itemRecord.getItem(this);
    if (favorite == null) {
      throw new AIGException("Unable to load item (" + favoriteFolderItemID + ")", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }
    switch (itemRecord.getItemSubType()) {
      case ENTITYTABLE:
        try {
          SavedObject savedObject = (SavedObject) favorite.getFavoriteObject();
          if (!savedObject.setData()) {
            throw new AIGException("Unable to load EntityTable", Reason.UNABLE_TO_RETRIEVE_ENTRY);
          }
          EntityTable entityTable = (EntityTable) savedObject.getSavedObject();
          entityTable.setTableName(savedObject.getName());
          entityTable.setDescription(savedObject.getDescription());
          entityTable.setSavedObject(savedObject);
          ServiceCache.getServiceCache(request).saveEntityTableResult(new EntityTableCacheItem(this, entityTable));
          loadEntityList(entityTable, null, null, true);
        } catch (Exception e) {
          e.printStackTrace();
          throw new AIGException("Unable to load saved table", Reason.UNABLE_TO_RETRIEVE_ENTRY);
        }
        break;
      case LIST:
        EntityList entityList = (EntityList) favorite.getFavoriteObject();
        if (!((EntityList) entityList).setData()) {
          throw new AIGException("Unable to load saved list", Reason.UNABLE_TO_RETRIEVE_ENTRY);
        }
        try {
          loadEntityList(entityList, null, null, true);
        } catch (Exception e) {
          e.printStackTrace();
          throw new AIGException("Unable to load saved list", Reason.UNABLE_TO_RETRIEVE_ENTRY);
        }
        break;
      case PROJECTVIEW:
        try {
          DHProjectInfo projectInfo = (DHProjectInfo) favorite.getFavoriteObject();
          if (!projectInfo.setData()) {
            throw new AIGException("Unable to load project view", Reason.UNABLE_TO_RETRIEVE_ENTRY);
          }
          ServiceCache serviceCache = ServiceCache.getServiceCache(this);
          ServiceDetails projectViewServiceDetails = getLooselyCoupledServiceDetails("PROJECTVIEW_DETAILS");
          GenericEntityListMember projectListMember = new GenericEntityListMember(projectInfo.getName(), projectInfo.getIdentifier(), projectInfo.getName(), EntityListCategory.PROJECTS);
          projectListMember.setDefaultResultViewParameters("view_id", projectInfo.getTransientData("viewID"));
          projectListMember.setDefaultViewServiceKey(projectViewServiceDetails.getKey());
          GenericEntityList projectList = new GenericEntityList("Projects", "Project list", EntityListCategory.PROJECTS, projectListMember);
          loadEntityList(projectList, null, null, true);
        } catch (Exception e) {
          e.printStackTrace();
          throw new AIGException("Unable to load project view", Reason.UNABLE_TO_RETRIEVE_ENTRY);
        }
        break;
      case SERVICE:
        try {
          SavedObject savedServiceObject = (SavedObject) favorite.getFavoriteObject();
          if (!savedServiceObject.setData()) {
            throw new AIGException("Unable to load saved service", Reason.UNABLE_TO_RETRIEVE_ENTRY);
          }
          ServiceDetails savedServiceDetails = (ServiceDetails) savedServiceObject.getSavedObject();
          ServiceDetails serviceDetails = ServiceCache.getServiceCache(request).getService(savedServiceDetails.getKey());
          //If the ServiceDetails are null, can not load service
          if (serviceDetails == null) {
            throw new AIGException("Unable to load saved service. Possibly the service is not available.", Reason.UNABLE_TO_RETRIEVE_ENTRY);
          }
          //If it is VQT, run as executeVisualQuery
          ServiceDetails vqtServiceDetails = new VQTUtilities(this).getVQTServiceDetails();

          if (vqtServiceDetails != null && vqtServiceDetails.getKey().equals(serviceDetails.getKey())) {
            ServiceParameter queryRequestParameter = serviceDetails.getParameter("QueryRequest");
            if (queryRequestParameter != null && queryRequestParameter.getValue() != null) {
              ServiceParameter targetParameter = serviceDetails.getParameter("target");
              String vqtTarget = "RG";
              if (targetParameter != null && targetParameter.getValue() != null) {
                vqtTarget = targetParameter.getValue().toString();
              }
              executeVisualQuery(queryRequestParameter.getValue().toString(), vqtTarget);
            }
          } else {
            serviceDetails.copyParameters(savedServiceDetails);
            executeService(serviceDetails, false, null);
          }
        } catch (Exception e) {
          e.printStackTrace();
          throw new AIGException("Unable to load saved service", Reason.UNABLE_TO_RETRIEVE_ENTRY);
        }
        break;
    }
  }

  /**
   * Loads a Project View
   *
   * @throws ServiceParameterException
   * @throws TransformerException
   * @throws JDOMException
   * @throws WSDLException
   * @throws IOException
   * @throws ServiceException
   * @throws AIGException
   */
  private void loadProjectView(String projectId) throws AIGException {
    try {
      String projectName = projectId;
      DHProjectInfo project = null;
      if (ExtString.isANumber(projectName)) {
        project = new DHProjectInfo(projectName, new OraSQLManager(), null, JDBCNamesType.RGDH_JDBC + "");
      } else {
        List<DHProjectInfo> projectInfos = new RdbDataArray(DHProjectInfo.class, new CompareTerm("name", projectName), new OraSQLManager(), null,
                JDBCNamesType.RGDH_JDBC + "");
        project = (projectInfos.size() > 0 ? projectInfos.get(0) : null);
      }
      if (project != null && project.setData()) {
        projectName = project.getName();
        projectId = project.getIdentifier();
      }

      String nodeName = (doesParameterExist("view_name", true) ? getParameter("view_name") + " [View:" + projectName + "]" : projectName);

      ServiceCache serviceCache = ServiceCache.getServiceCache(this);
      ServiceDetails projectViewServiceDetails = getLooselyCoupledServiceDetails("PROJECTVIEW_DETAILS");
      GenericEntityListMember projectListMember = new GenericEntityListMember(nodeName, projectId, nodeName, EntityListCategory.PROJECTS);
      projectListMember.setDefaultResultViewParameters("view_id", getParameter("view_id"));
      projectListMember.setDefaultViewServiceKey(projectViewServiceDetails.getKey());
      GenericEntityList projectList = new GenericEntityList("Projects", "Project list", EntityListCategory.PROJECTS, projectListMember);
      loadEntityList(projectList, null, null, true);
    } catch (Exception e) {
      e.printStackTrace();
      throw new AIGException("Unable to load project view", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }
  }

  private void loadEntityTable(String tableID) throws AIGException {
    try {
      tableID = tableID.replaceFirst("RG(:)?", "");
      SavedObject savedObject = new SavedObject(tableID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
      if (!savedObject.setData()) {
        throw new AIGException("Unable to load EntityTable", Reason.UNABLE_TO_RETRIEVE_ENTRY);
      }     
      EntityTable entityTable= (EntityTable) savedObject.getSavedObject();
      entityTable.setSavedObject(savedObject);
      loadEntityTable(entityTable);     
    } catch (Exception e) {
      e.printStackTrace();
      throw new AIGException("Unable to load table", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }
  }

  private void loadEntityTable(EntityTable entityTable) throws AIGException {
    try {      
      entityTable.setTableName(entityTable.getTableName(true));
      entityTable.setDescription(entityTable.getDescription());
      ServiceCache.getServiceCache(request).saveEntityTableResult(new EntityTableCacheItem(this, entityTable));
      loadEntityList(entityTable, null, null, true);
    } catch (Exception e) {
      e.printStackTrace();
      throw new AIGException("Unable to load table", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }
  }

  private void loadService(String serviceID) throws AIGException {
    try {
      SavedObject savedServiceObject = new SavedObject(serviceID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
      if (!savedServiceObject.setData()) {
        throw new AIGException("Unable to load saved service", Reason.UNABLE_TO_RETRIEVE_ENTRY);
      }
      ServiceDetails serviceDetails = (ServiceDetails) savedServiceObject.getSavedObject();
      ServiceDetails vqtServiceDetails = new VQTUtilities(this).getVQTServiceDetails();

      if (vqtServiceDetails != null && vqtServiceDetails.getKey().equals(serviceDetails.getKey())) {
        ServiceParameter queryRequestParameter = serviceDetails.getParameter("QueryRequest");
        if (queryRequestParameter != null && queryRequestParameter.getValue() != null) {
          ServiceParameter targetParameter = serviceDetails.getParameter("target");
          String vqtTarget = "RG";
          if (targetParameter != null && targetParameter.getValue() != null) {
            vqtTarget = targetParameter.getValue().toString();
          }
          executeVisualQuery(queryRequestParameter.getValue().toString(), vqtTarget);
        }
      } else {
        executeService(serviceDetails, false, null);
      }
    } catch (Exception e) {
      e.printStackTrace();
      throw new AIGException("Unable to load project view", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }
  }

  /**
   * Loads a ProjectView as a TableView
   *
   * @throws ServiceParameterException
   * @throws TransformerException
   * @throws JDOMException
   * @throws WSDLException
   * @throws IOException
   * @throws ServiceException
   * @throws AIGException
   * @throws JSONException
   */
  private void loadProjectViewAsTableView() throws ServiceParameterException, TransformerException, JDOMException, WSDLException, IOException,
          ServiceException, AIGException, JSONException, ClassNotFoundException {
    ServiceCache serviceCache = ServiceCache.getServiceCache(this);
    ServiceDetails assayResultsServiceDetails = getLooselyCoupledServiceDetails("PROJECTVIEW2TABLE");
    assayResultsServiceDetails.setParameterValue("viewId", getParameter("view_id"));
    assayResultsServiceDetails.setParameterValue("returnType", "SOBJECT");
    Map<String, ?> serviceParameters = new JSONObject(getParameter("view_params")).toMap();
    Object obj = executeService(assayResultsServiceDetails, serviceParameters, true);

    byte[] entityTableBytes = (byte[]) obj;
    ByteArrayInputStream is = new ByteArrayInputStream(entityTableBytes);

    ObjectInputStream oip = new ObjectInputStream(is);
    Object object = oip.readObject();
    oip.close();
    is.close();
    EntityTableProxy entityTableProxy = (EntityTableProxy) object;
    EntityTable entityTable = EntityLoaderFactory.getEntityTableLoader(this, entityTableProxy).createEntityTable();
    ServiceCache.getServiceCache(request).saveEntityTableResult(new EntityTableCacheItem(this, entityTable));
    loadEntityList(entityTable, null, null, true);
  }

  private void executeVisualQueryResultCount() throws JSONException, IOException {
    VQTUtilities vqtUtilities = new VQTUtilities(this);
    JSONObject responseObj = new JSONObject();
    JSONObject countObj = new JSONObject();
    countObj.put("count", vqtUtilities.getEntityCountResultCount(getParameter("QueryRequest")));
    responseObj.append("results", countObj);
    response.getWriter().println(responseObj);
  }

  private void executeVisualQueryFolderRequest() throws JSONException, IOException {
    VQTUtilities vqtUtilities = new VQTUtilities(this);
    JSONArray folderItems = vqtUtilities.getFolderItems(getParameter("node"));
    if (folderItems != null) {
      response.getWriter().println(folderItems);
    }
  }

  /**
   * Executes a visual query (VQT) request and loads it into the treenode cache and writes the TREENODE xml result to
   * the response Debug.print(true);
   *
   * @throws AIGException
   * @return ServiceDetails
   */
  private void executeVisualQuery(String queryRequest, String target) throws AIGException, ServiceParameterException, TransformerException, JDOMException,
          WSDLException, ServiceException, IOException, JSONException {
    VQTUtilities vqtUtilities = new VQTUtilities(this);
    int queryRunID = vqtUtilities.executeQuery(queryRequest, target);
    loadVisualQueryResult(queryRunID, target);
  }

  /**
   * Loads a visual query (VQT) request and loads it into the treenode cache and writes the TREENODE xml result to the
   * response Debug.print(true);
   *
   * @throws AIGException
   * @return ServiceDetails
   */
  private void loadVisualQueryResult(int queryRunID, String target) throws AIGException, ServiceParameterException, TransformerException, JDOMException,
          WSDLException, ServiceException, IOException, JSONException, RemoteException {
    VQTUtilities vqtUtilities = new VQTUtilities(this);
    if (queryRunID < 0) {
      return;
    }
    try {
      // VQTResultLoader2 loader = new VQTResultLoader2(this, queryRunID);
      VQTResultLoader3 loader = new VQTResultLoader3(this, queryRunID, target);
      if (ExtString.equalsIgnoreCase(target, "spotfire")) {
        String exportName = "vqt";
        int entityTableResultCacheID = loader.createEntityTable2ResultCache();
        if (entityTableResultCacheID >= 0) {
          ServiceDetails sfService = getLooselyCoupledServiceDetails("ENTITYTABLERESULTCACHE2SPOTFIRE");
          sfService.addParameterValue("xmlId", entityTableResultCacheID + "");
          String stdfFile = sfService.executeService2String();

          response.setContentType("application/vnd.spotfire.stdf");
          response.addHeader("Content-disposition", "attachment; filename=" + exportName.replaceAll("\\s+", "_") + ".stdf");
          response.getWriter().print(stdfFile);
          response.getWriter().flush();
        } else {
          throw new AIGException("Failed to create result", Reason.UNKNOWN);
        }
      } else {
        EntityTable entityTable = loader.createEntityTable();
        EntityTableCacheItem entityTableCacheItem = new EntityTableCacheItem(this, entityTable);
        ServiceCache.getServiceCache(request).saveEntityTableResult(entityTableCacheItem);
        Element searchDataNode = new Element("SEARCHDATA");
        ExtXMLElement.addAttribute(searchDataNode, "query_run_id", queryRunID + "");
        ExtXMLElement.addAttribute(searchDataNode, "result_entity_count", entityTable.getEntityIDs().size() + "");
        Document treeNodesDoc = loadEntityList(entityTable, searchDataNode, vqtUtilities.getVQTServiceDetails(), false);
        treeNodesDoc.getRootElement().setAttribute("DEFAULTVIEW_EXISTS", "T");

        List<VisualizationResults> vizResults = loader.getVisualizations();
        JSONArray jVizConfigs = new JSONArray();
        JSONObject jVizConfig = new JSONObject();
        jVizConfigs.put(jVizConfig);
        int id = 0;
        for (VisualizationResults vizResult : vizResults) {
          jVizConfig.put("name", vizResult.getVisualizationName());
          if (vizResult.isByEntity()) {
            for (EntityListMemberIF entity : entityTable.getListMembers()) {
              JSONObject jVizConfig2 = new JSONObject();
              jVizConfig.append("urls", jVizConfig2);
              jVizConfig2.put("name", entity.getLabel());
              jVizConfig2.put("wpURL", VizUtils.generateSpotfireWebplayerURL(vizResult, entity));
              jVizConfig2.put("dxpURL", VizUtils.generateSpotfireDXPURL(vizResult, entity));
              jVizConfig2.put("desc", entity.getDescription());
              jVizConfig2.put("id", id++);
            }
          } else {
            JSONObject jVizConfig2 = new JSONObject();
            jVizConfig.append("urls", jVizConfig2);
            jVizConfig2.put("name", vizResult.getVisualizationName());
            jVizConfig2.put("wpURL", VizUtils.generateSpotfireWebplayerURL(vizResult, null));
            jVizConfig2.put("dxpURL", VizUtils.generateSpotfireDXPURL(vizResult, null));
            jVizConfig2.put("desc", vizResult.getVisualizationName());
            jVizConfig2.put("id", id++);
          }
        }

        if (jVizConfigs.length() > 0) {
          treeNodesDoc.getRootElement().setAttribute("viz", jVizConfigs.toString());
        }
        setServiceResultCacheItem(treeNodesDoc.getRootElement().getAttributeValue("UUID"), vqtUtilities.getVQTServiceDetails(),
                TModelCommonNameFactory.TREENODESXMLDEFINITION_tMODELNAME, treeNodesDoc);
        ExtXMLElement.write(treeNodesDoc, response.getWriter());
      }
    } catch (SQLException ex1) {
      if (ex1.getErrorCode() == 31) {
        throw new AIGException("Your search exceeded the time allowed. You may need to refine your search.", Reason.TIMEOUT);
      }
      ex1.printStackTrace();
    } catch (Exception ex2) {
      ex2.printStackTrace();
    }
  }

  /**
   * Executes a service and loads it into the treenode cache and writes the TREENODE xml result to the response
   *
   * @param serviceDetails ServiceDetails
   * @throws AIGException
   * @throws ServiceException
   */
  private void executeService(ServiceDetails serviceDetails, boolean includeDefaultViewServiceKey, Map<String, String> coreParameterSetMap) throws AIGException, ServiceException {
    if (serviceDetails == null) {
      return;
    }
    if (!ServiceCache.getServiceCache(this).verifyServiceActive(serviceDetails)) {
      throw new AIGException("Service Offline", Reason.SERVICE_OFFLINE);
    }
    ServiceAttributes serviceAttributes = new ServiceAttributes(serviceDetails, getEntityClassManager());
    TModelDetails defaultResultTModelDetails = serviceAttributes.getDefaultResultType();

    setServiceParameters(serviceDetails, null);
    if (serviceDetails.isServiceReady()) {
      String resultBinding = null;
      String treeNodesBinding = null;
      if (serviceDetails.getBindingByTModelName(TModelCommonNameFactory.QUERYRGRAWENTITYTABLEDEFINITION_TMODELNAME).size() > 0) {
        resultBinding = TModelCommonNameFactory.QUERYRGRAWENTITYTABLEDEFINITION_TMODELNAME;
      }
      if (serviceDetails.getBindingByTModelName(TModelCommonNameFactory.ENTITYTABLERAWDEFINITION_tMODELNAME).size() > 0) {
        resultBinding = TModelCommonNameFactory.QUERYRGRAWENTITYTABLEDEFINITION_TMODELNAME;
      }
      if (serviceDetails.getBindingByTModelName(TModelCommonNameFactory.QUERYENTITYTABLEDEFINITION_tMODELNAME).size() > 0) {
        resultBinding = TModelCommonNameFactory.QUERYENTITYTABLEDEFINITION_tMODELNAME;
      }

      if (serviceDetails.getResultTypeBinding(TModelCommonNameFactory.QUERYTREENODESDEFINITION_tMODELNAME) != null) {
        treeNodesBinding = TModelCommonNameFactory.QUERYTREENODESDEFINITION_tMODELNAME;
      } else if (serviceDetails.getResultTypeBinding(TModelCommonNameFactory.QUERYENTITYTABLEDEFINITION_tMODELNAME) != null) {
        treeNodesBinding = TModelCommonNameFactory.QUERYENTITYTABLEDEFINITION_tMODELNAME;
      } else if (serviceDetails.getResultTypeBinding(TModelCommonNameFactory.TREENODESXMLDEFINITION_tMODELNAME) != null) {
        treeNodesBinding = TModelCommonNameFactory.TREENODESXMLDEFINITION_tMODELNAME;
      }

      serviceDetails.addListener(new RecentServiceUpdater(this, coreParameterSetMap));

      if (resultBinding != null) { // Check there is an alternative result
        // binding
        if (ExtString.isAnyEqualIgnoreCase(resultBinding, TModelCommonNameFactory.QUERYRGRAWENTITYTABLEDEFINITION_TMODELNAME,
                TModelCommonNameFactory.QUERYENTITYTABLEDEFINITION_tMODELNAME)) {
          // Grab either the results as a byte array or String
          byte[] resultBytes = null;
          String resultString = null;
          try {
            Object resultObj = serviceDetails.executeService();
            if (resultObj == null) {
              return;
            }
            if (resultObj instanceof byte[]) {
              resultBytes = (byte[]) resultObj;
            } else if (resultObj instanceof String) {
              resultString = (String) resultObj;
            }
          } catch (SocketException se) {
            throw new AIGException("Your search exceeded the time allowed. You may need to refine your search.", Reason.TIMEOUT);
          } catch (Exception e) {
            e.printStackTrace();
            return;
          }
          // If byte array, check if it is an entity table
          if (ExtString.equalsIgnoreCase(resultBinding, TModelCommonNameFactory.QUERYRGRAWENTITYTABLEDEFINITION_TMODELNAME) && resultBytes != null) {
            try {
              EntityTableProxy entityTableProxy = null;
              ByteArrayInputStream is = new ByteArrayInputStream(resultBytes);
              ObjectInputStream oip = new ObjectInputStream(is);
              Object object = oip.readObject();
              oip.close();
              is.close();
              entityTableProxy = (EntityTableProxy) object;

              EntityTable entityTable = EntityLoaderFactory.getEntityTableLoader(this, entityTableProxy).createEntityTable();
              EntityTableCacheItem entityTableCacheItem = new EntityTableCacheItem(this, entityTable);
              ServiceCache.getServiceCache(request).saveEntityTableResult(entityTableCacheItem);
              Element searchDataNode = new Element("SEARCHDATA");
              ExtXMLElement.addAttribute(searchDataNode, "result_entity_count", entityTable.getEntityIDs().size() + "");
              Document treeNodesDoc = loadEntityList(entityTable, searchDataNode, serviceDetails, true);
              treeNodesDoc.getRootElement().setAttribute("DEFAULTVIEW_EXISTS", "T");
              setServiceResultCacheItem(treeNodesDoc.getRootElement().getAttributeValue("UUID"), serviceDetails,
                      TModelCommonNameFactory.TREENODESXMLDEFINITION_tMODELNAME, treeNodesDoc);
              addRequestLogServiceInvocationDetails(serviceDetails);
              return;
            } catch (Exception e) {
              e.printStackTrace();
            }
          } else if (ExtString.equalsIgnoreCase(resultBinding, TModelCommonNameFactory.QUERYENTITYTABLEDEFINITION_tMODELNAME)) {
            try {
              resultString = (resultString != null ? resultString : new String(resultBytes));
              Document resultDoc = ExtXMLElement.buildDocument(resultString);
              Document queryTableDoc = serviceDetails.performResultTransform(TModelCommonNameFactory.QUERYENTITYTABLEDEFINITION_tMODELNAME, resultDoc);
              EntityListCategory tableCategory= EntityListCategory.fromString(ExtXMLElement.getXPathValue(queryTableDoc, "/EntityTable/@category"));
              String entityTableName= ExtXMLElement.getXPathValue(queryTableDoc, "/EntityTable/@name");
              EntityTable entityTable= new EntityTable(tableCategory);
              entityTable.setTableName((entityTableName== null ? tableCategory.revertToString() : entityTableName));
              for(Element rowEl : ExtXMLElement.getXPathElements(queryTableDoc, "/EntityTable//Row")) {
                String entityID= ExtXMLElement.getAttribute(rowEl, "entity_id");
                String entityLabel= ExtXMLElement.getAttribute(rowEl, "entity_label");
                String entityDescription= ExtXMLElement.getAttribute(rowEl, "entity_description");
                
                DataRow row= new DataRow(entityID, entityLabel);
                row.setEntityDescription(entityDescription);
                entityTable.addDataRow(row);                
              }
              entityTable.addServiceResult(queryTableDoc);             
              
              addRequestLogServiceInvocationDetails(serviceDetails);
              loadEntityTable(entityTable);
              return;
            } catch (Exception ex) {
              Logger.getLogger(ExecuteQueryService.class.getName()).log(Level.SEVERE, null, ex);
            }
          }

          // Entity table failed, If treenode binding, try loading
          if (treeNodesBinding != null) {
            try {
              resultString = (resultString != null ? resultString : new String(resultBytes));
              Document resultDoc = ExtXMLElement.buildDocument(resultString);
              Document treeNodesDoc = serviceDetails.performResultTransform(treeNodesBinding, resultDoc);
              addRequestLogServiceInvocationDetails(serviceDetails);
              loadServiceResult(treeNodesDoc, resultDoc, defaultResultTModelDetails, serviceDetails, includeDefaultViewServiceKey);
            } catch (Exception e) {
              e.printStackTrace();
            }
          }
        }
      } else if (treeNodesBinding != null) {
        try {
          Document[] treeNodesDoc = serviceDetails.executeService2JDocumentWithNative(treeNodesBinding);
          Document treeNodesResultDoc = null;
          Document resultDoc = null;
          switch (treeNodesDoc.length) {
            case 0:
              return;
            case 1:
              treeNodesResultDoc = treeNodesDoc[0];
              break;
            case 2:
              resultDoc = treeNodesDoc[0];
              treeNodesResultDoc = treeNodesDoc[1];
              break;
          }
          addRequestLogServiceInvocationDetails(serviceDetails);
          loadServiceResult(treeNodesResultDoc, resultDoc, defaultResultTModelDetails, serviceDetails, includeDefaultViewServiceKey);
        } catch (SocketException se) {
          throw new AIGException("Your search exceeded the time allowed. You may need to refine your search.", Reason.TIMEOUT);
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
    }
  }

  /**
   * Executes a service and loads it into the treenode cache and writes the TREENODE xml result to the response
   *
   * @param serviceDetails ServiceDetails
   * @throws AIGException
   * @throws ServiceException
   */
  private void loadServiceResult(Document treeNodesDoc, Document rawResult, TModelDetails defaultResultTModelDetails, ServiceDetails serviceDetails, boolean includeDefaultViewServiceKey) throws AIGException,
          ServiceException, JSONException, IOException {
    Element searchResultNode = processQueryNodes(treeNodesDoc, rawResult, defaultResultTModelDetails, serviceDetails, includeDefaultViewServiceKey);
    if (isIsMultiPartRequest()) {
      JSONObject ajaxResponse = new JSONObject();
      ajaxResponse.put("xml", ExtXMLElement.toString(searchResultNode));
      ajaxResponse.put("text", "");
      HTMLElement htmlEl = new GenericHTMLElement("html");
      HTMLElement headEl = htmlEl.addMemberElement("head");
      headEl.addMemberElement("script").appendContent("document.domain='amgen.com'");
      HTMLElement bodyEl = htmlEl.addMemberElement("body");
      bodyEl.addMemberElement("script").appendContent("var ajaxResponse= " + ajaxResponse);
      response.getWriter().println(htmlEl);
    } else {
      if (searchResultNode != null && defaultServicesDoc != null && defaultServicesDoc.getRootElement() != null) {
        searchResultNode.addContent((Element) defaultServicesDoc.getRootElement().clone());
      }
      ExtXMLElement.write(searchResultNode, response.getWriter());
    }
  }

  /**
   * Executes a service and loads it into the treenode cache and writes the TREENODE xml result to the response
   *
   * @param serviceDetails ServiceDetails
   * @throws AIGException
   * @throws ServiceException
   */
  private Element processQueryNodes(Document treeNodesDoc, Document rawResult, TModelDetails defaultResultTModelDetails, ServiceDetails serviceDetails, boolean includeDefaultViewServiceKey) throws AIGException,
          ServiceException {
    if (treeNodesDoc != null) {
      try {
        XPath queryResultEntityTreeNodesXPath = XPath.newInstance("//TREENODE[@SERVICE_DATA_TYPE_CATEGORY]");
        List<Element> queryResultEntityTreeNodes = queryResultEntityTreeNodesXPath.selectNodes(treeNodesDoc.getRootElement());
        if (queryResultEntityTreeNodes.size() > 0) {
          if (includeDefaultViewServiceKey) {
            ClassificationSchemeQuery defaultViewQuery = new ClassificationSchemeQuery();
            defaultViewQuery.addKeyValue(TModelCommonNameFactory.RESEARCH_GATEWAY_CATEGORIZATION_SCHEME, "Entity Default View");
            List<String> defaultHTMLViewServiceKeys = serviceDetails.getRelatedServiceKeys(defaultViewQuery, null, null,
                    TModelCommonNameFactory.HTMLDEFINITION_tMODELNAME, true);
            List<String> defaultProjectViewServiceKeys = serviceDetails.getRelatedServiceKeys(defaultViewQuery, null, null,
                    TModelCommonNameFactory.PROJECTVIEWDEFINITION_tMODELNAME, true);
            List<String> defaultViewServiceKeys = new ArrayList<String>(); //defaultHTMLViewServiceKeys);
            defaultViewServiceKeys.addAll(defaultProjectViewServiceKeys);

            if (defaultViewServiceKeys.size() > 0) {
              ServiceDetails relatedServiceDetails = getServiceDetails(defaultViewServiceKeys.get(0));
              ServiceAttributes serviceAttributes = new ServiceAttributes(relatedServiceDetails, getEntityClassManager());

              treeNodesDoc.getRootElement().setAttribute("DEFAULT_VIEW_NAME", serviceAttributes.getName(ServiceNamingContext.RG_RESOURCE));
              treeNodesDoc.getRootElement().setAttribute("DEFAULT_VIEW_KEY", defaultViewServiceKeys.get(0));
            }
          }
          ServiceDataCategory serviceDataCategory = ServiceDataCategory.getServiceDataCategory(queryResultEntityTreeNodes.get(0));
          Element searchResultNode = processTreeNodes(treeNodesDoc.getRootElement(), null, NodeType.RESULTNODE, serviceDataCategory, null, null);
                    // Commented out because already cached by processTreeNodes
          // TreeNodeCache.getTreeNodeCache(request).addTreeNode(searchResultNode);
          String rawServiceResultCacheItemKey = null;
          if (rawResult != null && defaultResultTModelDetails != null) {
            ServiceResultCacheItem rawServiceResultCacheItem = setServiceResultCacheItem(null, serviceDetails, defaultResultTModelDetails.getName(), rawResult);
            rawServiceResultCacheItemKey = rawServiceResultCacheItem.getKey();
          }
          ServiceResultCacheItem tnServiceResultCacheItem = setServiceResultCacheItem(searchResultNode.getAttributeValue("UUID"), serviceDetails, TModelCommonNameFactory.TREENODESXMLDEFINITION_tMODELNAME,
                  treeNodesDoc);
          if (rawServiceResultCacheItemKey != null) {
            tnServiceResultCacheItem.addRelatedResultKey(ServiceResultCacheItem.ResultRelationshipType.RAW, rawServiceResultCacheItemKey);
          }
          if (serviceDetails != null) {
            ServiceAttributes serviceAttributes = new ServiceAttributes(serviceDetails, getEntityClassManager());
            ExtXMLElement.addAttribute(searchResultNode, "SERVICE_KEY", serviceDetails.getKey());
            ExtXMLElement.addAttribute(searchResultNode, "SERVICE_NAME", serviceAttributes.getName(ServiceNamingContext.RG_QUERY));
            ExtXMLElement.addAttribute(searchResultNode, "SERVICE_ICON", serviceAttributes.getIconClass(ServiceNamingContext.RG_LOFT));
          }
          if (doesParameterExist("rg.resultnodename", true)) {
            searchResultNode = TreeNodeCache.getTreeNodeCache(request).renameTreeNode(searchResultNode, getParameter("rg.resultnodename"));
          }
          return searchResultNode;
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return null;
  }

  /**
   * Loads an EntityListIF object into the treenode cache and writes the TREENODE xml result to the response
   *
   * @param entityList EntityListIF
   * @throws AIGException
   * @throws ServiceException
   * @throws IOException
   * @throws WSDLException
   * @throws JDOMException
   * @throws TransformerException
   * @throws ServiceParameterException
   */
  private Document loadEntityList(EntityListIF entityList, Element searchDataNode, ServiceDetails serviceDetails, boolean writeNodes) throws AIGException,
          ServiceException, IOException, WSDLException, JDOMException, TransformerException, ServiceParameterException, JSONException {
    EntityListLoader entityListLoader = new EntityListLoader(request);
    Document searchResultDoc = entityListLoader.loadAsResultNode(entityList, serviceDetails);

    if (entityList instanceof EntityTable) {
      searchResultDoc.getRootElement().setAttribute("DEFAULTVIEW_EXISTS", "T");
    }
    if (searchDataNode != null) {
      searchResultDoc.getRootElement().addContent(searchDataNode);
      if (serviceDetails != null) {
        ServiceAttributes serviceAttributes = new ServiceAttributes(serviceDetails, getEntityClassManager());
        List<Element> resultEls = ExtXMLElement.getXPathElements(searchResultDoc, "//TREENODE[@NODE_TYPE='RESULTNODE']");
        for (Element resultEl : resultEls) {
          ExtXMLElement.addAttribute(resultEl, "SERVICE_NAME", serviceAttributes.getName(ServiceNamingContext.RG_QUERY));
          ExtXMLElement.addAttribute(resultEl, "SERVICE_ICON", serviceAttributes.getIconClass(ServiceNamingContext.RG_LOFT));
        }
      }
    }
    if (writeNodes) {
      if (isIsMultiPartRequest()) {
        JSONObject ajaxResponse = new JSONObject();
        ajaxResponse.put("xml", ExtXMLElement.toString(searchResultDoc));
        ajaxResponse.put("text", "");
        HTMLElement htmlEl = new GenericHTMLElement("html");
        HTMLElement headEl = htmlEl.addMemberElement("head");
        headEl.addMemberElement("script").appendContent("document.domain='amgen.com'");
        HTMLElement bodyEl = htmlEl.addMemberElement("body");
        bodyEl.addMemberElement("script").appendContent("var ajaxResponse= " + ajaxResponse);

        response.getWriter().println(htmlEl);
      } else {
        ExtXMLElement.write(searchResultDoc, response.getWriter());
      }
    }
    return searchResultDoc;
  }

  /**
   * Returns the mimetype of the servlet
   */
  protected String getServletMimeType() {
    return (isIsMultiPartRequest() ? "text/html" : "text/xml");
  }
}
