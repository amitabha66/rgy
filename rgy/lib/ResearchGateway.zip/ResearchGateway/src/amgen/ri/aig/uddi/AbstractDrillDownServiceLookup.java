package amgen.ri.aig.uddi;

import amgen.ri.aig.AIGException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jdom.Element;

import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.service.ServiceCacheResponse;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.asf.sa.uddi.ClassificationSchemeDetails;
import amgen.ri.asf.sa.uddi.ClassificationSchemeNames;
import amgen.ri.asf.sa.uddi.ClassificationSchemeQuery;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.ServiceParameter;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import org.jdom.Document;
import org.jdom.JDOMException;

/**
 * <p>
 * @version $Id: AbstractDrillDownServiceLookup.java,v 1.2 2011/06/21 17:28:58
 * cvs Exp $ Abstract class for the drill down service lookup
 */
public abstract class AbstractDrillDownServiceLookup extends AbstractServiceLookup {

  private String defaultServiceKey;
  private Map<String, ClassificationSchemeQuery> classificationSchemeQueries;

  public AbstractDrillDownServiceLookup() {
    super();
  }

  public AbstractDrillDownServiceLookup(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  protected void setCategories(Map<String, ClassificationSchemeQuery> classificationSchemeQueries, String defaultServiceKey) {
    this.classificationSchemeQueries = classificationSchemeQueries;
    this.defaultServiceKey = defaultServiceKey;
  }

  /**
   *
   * @throws Exception @todo Implement this amgen.ri.aig.AIGServlet method
   */
  protected void performRequest() throws Exception {
    Map<String, ServiceDetails> services = new LinkedHashMap<String, ServiceDetails>();
    Element servicesElement = new Element("Services");
    Element defaultServiceEl = null;
    for (String classificationSchemeQueryKey : classificationSchemeQueries.keySet()) {
      ServiceQuery serviceQuery = new ServiceQuery(classificationSchemeQueries.get(classificationSchemeQueryKey), TModelCommonNameFactory.RGDDHTMLDEFINITION_tMODELNAME);
      ServiceCacheResponse sortedSearchServices = findAndSortServices(serviceQuery);
      for (ServiceDetails searchService : sortedSearchServices) {
        String serviceKey = searchService.getKey();
        if (!services.containsKey(serviceKey) && isValidService(searchService, classificationSchemeQueries.get(classificationSchemeQueryKey))) {
          services.put(serviceKey, searchService);
          try {
            ServiceAttributes serviceAttributes = new ServiceAttributes(searchService, getEntityClassManager());
            if (searchService.containsUserInAllowedUsers(getSessionLogin().getRemoteUser(), true)) {
              Element searchServiceElement = searchService.getAsElement();
              ExtXMLElement.setChildElementValue(searchServiceElement, "Name", serviceAttributes.getName(ServiceNamingContext.RG_RESOURCE));
              ExtXMLElement.setChildElementValue(searchServiceElement, "Description", serviceAttributes.getDescription(ServiceNamingContext.RG_RESOURCE));
              servicesElement.addContent(searchServiceElement);
              if (ExtString.equals(serviceKey, defaultServiceKey)) {
                ExtXMLElement.addTextElement(searchServiceElement, "Default", "true");
                defaultServiceEl = searchServiceElement;
              } else {
                ExtXMLElement.addTextElement(searchServiceElement, "Default", "false");
              }
              ExtXMLElement.addTextElement(searchServiceElement, "ddCategory", classificationSchemeQueryKey);
            }
          } catch (Exception e) {
            e.printStackTrace();
          }
        }
      }
    }
    if (ExtString.hasLength(defaultServiceKey) && defaultServiceEl == null) {
      ServiceDetails ddServiceDetails = ServiceCache.getServiceCache(this).getService(defaultServiceKey);
      ServiceAttributes serviceAttributes = new ServiceAttributes(ddServiceDetails, getEntityClassManager());
      defaultServiceEl = ddServiceDetails.getAsElement();
      ExtXMLElement.setChildElementValue(defaultServiceEl, "Name", serviceAttributes.getName(ServiceNamingContext.RG_RESOURCE));
      ExtXMLElement.setChildElementValue(defaultServiceEl, "Description", serviceAttributes.getDescription(ServiceNamingContext.RG_RESOURCE));
      ExtXMLElement.addTextElement(defaultServiceEl, "Default", "true");
      servicesElement.addContent(0, defaultServiceEl);
    }
    if (defaultServiceEl != null) {
      defaultServiceEl.detach();
      servicesElement.addContent(0, defaultServiceEl);
    }
    ExtXMLElement.write(servicesElement, response.getWriter());
  }

  /**
   * isServiceValid
   *
   * @param searchService ServiceDetails
   * @return boolean
   */
  protected boolean isValidService(ServiceDetails searchService, ClassificationSchemeQuery query) {
    try {
      List<ServiceParameter> parameters = searchService.getParametersNotReady();
      ClassificationSchemeDetails serviceInputClassDetails = getClassificationSchemeDetailsByName(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME);
      if (parameters.size() == 0) {
        return true;
      }
      for (ServiceParameter parameter : parameters) {
        boolean parameterValid = false;
        List<String> keyValues = parameter.getCategoryKeyValue(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME);
        for (String keyValue : keyValues) {
          for (String queryKeyValue
                  : query.getClassificationSchemeValues(ClassificationSchemeNames.getName(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME))) {
            if (serviceInputClassDetails.isa(keyValue, queryKeyValue)) {
              parameterValid = true;
            }
          }
        }
        if (!parameterValid) {
          return false;
        }
      }
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  @Override
  public Document getServicesDocument() throws JDOMException, AIGException {
    throw new UnsupportedOperationException("Not supported yet.");
  }

}
