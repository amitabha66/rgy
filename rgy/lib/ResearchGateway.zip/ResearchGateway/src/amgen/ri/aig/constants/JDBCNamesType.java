package amgen.ri.aig.constants;

/**
 * Maintains the JDBC connection pool names
 * @author jemcdowe
 */
public enum JDBCNamesType {
  RG_JDBC,
  RGDOCS_JDBC,
  RGDH_JDBC,
  VQT_JDBC,
  RGSMSCL_JDBC
}
