package amgen.ri.aig.entitylist;

import java.io.Serializable;
import java.util.List;

import amgen.ri.aig.category.schema2.EntityListCategory;

/**
 * @version $Id: EntityListIF.java,v 1.3 2012/04/17 15:10:26 cvs Exp $
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public interface EntityListIF extends Serializable {
    /**
     * Get name for the list
     *
     * @return String
     */
    public String getListName();

    /**
     * Get description for the list
     *
     * @return String
     */
    public String getListDescription();

    /**
     * Get value for list_category
     *
     * @return EntityListCategory
     */
    public EntityListCategory getEntityCategory();

    /**
     * Returns the members of the list members IDs
     *
     * @param delimiter String
     * @return String
     */
    public String getListMemberIds(String delimiter);

    /**
     * Returns the members of the list members IDs
     * @return List
     */
    public List<String> getListMemberIds();

    /**
     * Returns the members of the list in the provided List
     *
     * @param memberList List
     * @return List
     */
    public List<EntityListMemberIF> getListMembers(List<EntityListMemberIF> memberList);

    /**
     * Returns the members of the list in the provided List
     *
     * @param memberList List
     * @return List
     */
    public List<EntityListMemberIF> getListMembers();

    /**
     * Returns the number of members in the provided List
     */
    public int getListMemberCount();


    /**
     * Returns whether this list contains a member with this id
     *
     * @param memberID String
     * @return boolean
     */
    public boolean containsMember(EntityListMemberIF memberID);

    /**
     * Returns the service source of the list, if available
     *
     * @return EntityListSourceServiceIF
     */
    public EntityListSourceServiceIF getSourceService();

}
