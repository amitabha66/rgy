package amgen.ri.aig.entitytable;

import java.io.Serializable;
import java.util.Comparator;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import amgen.ri.aig.util.AssaySummaryFormat;
import amgen.ri.util.ExtDate;
import amgen.ri.util.ExtString;

public class ColumnComparator implements Comparator, Serializable {
  static final long serialVersionUID = -1604350296174350043L;
  public static final Pattern ROOTLOT_PATTERN = Pattern.compile("(\\d+)#(\\d+)");

  private String columnDataIndex;
  private boolean caseSensitive = false;
  private boolean isReversed = false;
  private transient int columnIndex = -1;
  private transient Column column;

  /**
   * Creates a ColumnComparator for the given column
   *
   * @param columnDataIndex int
   * @param caseSensitive boolean
   */
  public ColumnComparator(String columnDataIndex, boolean caseSensitive) {
    this.columnDataIndex = columnDataIndex;
    this.caseSensitive = caseSensitive;
  }

  /**
   * Creates a ColumnComparator for the given column
   *
   * @param columnDataIndex int
   * @param caseSensitive boolean
   * @param isReversed boolean
   */
  public ColumnComparator(String columnDataIndex, boolean caseSensitive, boolean isReversed) {
    this(columnDataIndex, caseSensitive);
    setIsReversed(isReversed);
  }

  /**
   * Updates the sort column index and whether it is numeric. Should be called
   * before a new sort
   */
  public void startSort(EntityTable entityTable) {
    this.columnIndex = entityTable.getColumnIndex(columnDataIndex);
    this.column = entityTable.getColumn(columnIndex);
  }

  /**
   * Create a comparable value for the given cell value
   *
   * @param value Object
   * @return Object
   */
  private Object getCompareValue(Object cellValue) {
    //If null, return null
    if (cellValue == null) {
      return null;
    }
    //If a Number, return the Number
    if (cellValue instanceof Number) {
      return ((Number) cellValue).doubleValue();
    }
    //If a Date, return the Date
    if (cellValue instanceof Date) {
      return (Date) cellValue;
    }
    String stringValue = cellValue + "";

    //Check if it matches root#lot. If so, return as root.lot
    Matcher rootLotMatcher = ROOTLOT_PATTERN.matcher(stringValue);
    if (rootLotMatcher.find()) {
      try {
        return new Double(rootLotMatcher.group(1) + "." + rootLotMatcher.group(2));
      } catch (Exception e) {
      }
    }
    //check if it is a Date
    Date date = ExtDate.toDate(stringValue);
    if (date != null) {
      return new Double(date.getTime());
    }
    //check if it matches the AssaySummaryFormat
    double numericVal = AssaySummaryFormat.valueOf(stringValue);
    if (!Double.isNaN(numericVal)) {
      return numericVal;
    }

    //check if it is a Number
    double val = ExtString.toDouble(stringValue);
    if (!Double.isNaN(val)) {
      return new Double(val);
    }
    //give up, return String    	
    return stringValue;
  }

  /**
   * Does the comparison depending on the column type- String or number
   *
   * @param o1 Object
   * @param o2 Object
   * @return int
   */
  public int compare(Object o1, Object o2) {
    if (columnIndex < 0) {
      throw new IllegalStateException("ColumnComparator not initiated");
    }
    DataRow row1 = ((DataRow) o1);
    DataRow row2 = ((DataRow) o2);
    Object sortValue1 = row1.getDataCellSortValue(columnIndex, isReversed());
    Object sortValue2 = row2.getDataCellSortValue(columnIndex, isReversed());

    if (sortValue1 == null || sortValue2 == null) {
      int ret = (isReversed() ? -1 : 1) * (sortValue1 == null && sortValue2 == null ? 0 : (sortValue1 == null ? 1 : -1));
      return ret;
    }
    if (sortValue1.equals("-") && sortValue2.equals("-")) {
      return 0;
    } else if (sortValue1.equals("-")) {
      return 1;
    } else if (sortValue2.equals("-")) {
      return -1;
    }
    Object compareValue1 = getCompareValue(sortValue1);
    Object compareValue2 = getCompareValue(sortValue2);

    if (compareValue1 instanceof Double && compareValue2 instanceof Double) {
      return Double.compare((Double) compareValue1, (Double) compareValue2);
    }
    String compareString1 = (caseSensitive ? compareValue1.toString() : compareValue1.toString().toLowerCase());
    String compareString2 = (caseSensitive ? compareValue2.toString() : compareValue2.toString().toLowerCase());

    return compareString1.compareTo(compareString2);
  }

  /**
   * Sets if the column sort is case sensitive for a text sort
   *
   * @param caseSensitive boolean
   */
  public String getColumnIndex() {
    return columnDataIndex;
  }

  /**
   * Sets if the column sort is reversed
   *
   * @param isReversed boolean
   */
  public void setIsReversed(boolean isReversed) {
    this.isReversed = isReversed;
  }

  /**
   * Sets if the column sort is case sensitive for a text sort
   *
   * @param caseSensitive boolean
   */
  public void setCaseSensitive(boolean caseSensitive) {
    this.caseSensitive = caseSensitive;
  }

  /**
   * Returns if the column sort is case sensitive for a text sort
   *
   *
   * @return boolean
   */
  public boolean isCaseSensitive() {
    return caseSensitive;
  }

  /**
   * Returns whether the sort is reversed
   *
   * @return boolean
   */
  public boolean isReversed() {
    return isReversed;
  }

  /**
   * Returns whether the given parameters match those in the Comparator
   *
   * @param columnDataIndex String
   * @param isReversed boolean
   * @param caseSensitive boolean
   * @return boolean
   */
  public boolean equals(String columnDataIndex, boolean caseSensitive, boolean isReversed) {
    return (this.columnDataIndex.equals(columnDataIndex) && this.isReversed == isReversed && this.caseSensitive == caseSensitive);
  }

  public String toString() {
    return this.columnDataIndex + " " + this.isReversed + " " + this.caseSensitive;
  }

}
