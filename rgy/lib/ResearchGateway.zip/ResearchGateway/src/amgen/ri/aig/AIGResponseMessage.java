package amgen.ri.aig;

import java.io.IOException;
import java.io.Writer;

import javax.servlet.http.HttpServletResponse;

import org.jdom.Element;

import amgen.ri.html.HTMLElement;
import amgen.ri.json.JSONObject;
import amgen.ri.xml.ExtXMLElement;

/**
 * @version $Id: AIGResponseMessage.java,v 1.2 2011/06/21 17:28:58 cvs Exp $
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class AIGResponseMessage {
    private String component;
    private String title;
    private String message;
    private JSONObject jDetails;

    /**
     * AIGResponseMessage
     *
     * @param component String
     * @param title String
     * @param message String
     */
    public AIGResponseMessage(String component, String title, String message) {
        this.component = component;
        this.title = title;
        this.message = message;
    }

    /**
     * AIGResponseMessage
     *
     * @param component String
     * @param title String
     * @param message String
     */
    public AIGResponseMessage(String component, String message) {
        this.component = component;
        this.message = message;
    }

    public void setDetails(JSONObject jObj) {
        jDetails= jObj;
    }

    /**
     * Creates an error message Element
     *
     * @return Element
     */
    public Element getErrorElement() {
        Element componentEl = new Element("AIGError");
        ExtXMLElement.addAttribute(componentEl, "component", component);
        if (title != null) {
            ExtXMLElement.addTextElement(componentEl, "Title", title);
        }
        ExtXMLElement.addTextElement(componentEl, "ErrorText", message);
        if (jDetails!= null) {
            ExtXMLElement.addTextElement(componentEl, "Details", jDetails.toString());
        }
        return componentEl;
    }

    /**
     * Writes an error message to the Writer
     *
     * @param component String
     * @param title String
     * @param message String
     * @param writer Writer
     */
    public static void writeErrorElement(String component, String title, String message, Writer writer) {
        AIGResponseMessage aigErrorMessage = new AIGResponseMessage(component, title, message);
        try {
            ExtXMLElement.write(aigErrorMessage.getErrorElement(), writer);
        } catch (IOException ex) {
        }
    }

    /**
     * Creates an error message as an HTMLElement
     *
     * @param component String
     * @param title String
     * @param message String
     * @return HTMLElement
     */
    public static HTMLElement getHTMLErrorElement(String component, String title, String message) {
        AIGResponseMessage aigErrorMessage = new AIGResponseMessage(component, title, message);
        return AIGServlet.createErrorTable("error.gif", title, message);
    }

    /**
     * Writes an error message to the HttpServletResponse Writer
     *
     * @param component String
     * @param title String
     * @param message String
     * @param response HttpServletResponse
     */
    public static void writeErrorElement(String component, String title, String message, HttpServletResponse response) {
        try {
            writeErrorElement(component, title, message, response.getWriter());
        } catch (IOException ex) {
        }
    }

    /**
     * Creates an Success message Element
     *
     * @return Element
     */
    public Element getSuccessElement() {
        Element componentEl = new Element("AIGSuccess");
        ExtXMLElement.addAttribute(componentEl, "component", component);
        if (title != null) {
            ExtXMLElement.addTextElement(componentEl, "Title", title);
        }
        ExtXMLElement.addTextElement(componentEl, "SuccessText", message);
        if (jDetails!= null) {
            ExtXMLElement.addTextElement(componentEl, "Details", jDetails.toString());
        }
        return componentEl;
    }

    /**
     * Writes an Success message to the Writer
     *
     * @param component String
     * @param title String
     * @param message String
     * @param writer Writer
     */
    public static void writeSuccessElement(String component, String title, String message, Writer writer) {
        AIGResponseMessage aigErrorMessage = new AIGResponseMessage(component, title, message);
        try {
            ExtXMLElement.write(aigErrorMessage.getSuccessElement(), writer);
        } catch (IOException ex) {
        }
    }

    /**
     * Writes an Success message to the HttpServletResponse Writer
     *
     * @param component String
     * @param title String
     * @param message String
     * @param response HttpServletResponse
     */
    public static void writeSuccessElement(String component, String title, String message, HttpServletResponse response) {
        try {
            writeSuccessElement(component, title, message, response.getWriter());
        } catch (IOException ex) {
        }
    }


}
