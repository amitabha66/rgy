/*
 *   SavedObject
 *   RDBData wrapper class for SavedObject
 *   $Revision: 1.3 $
 *   Created: Jeffrey McDowell, 22 Apr 2009
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.sobj;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Reader;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.List;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.favorites.Favorite;
import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.BlobData;
import amgen.ri.rdb.CompareTerm;
import amgen.ri.rdb.LobSaveable;
import amgen.ri.rdb.OraSequenceField;
import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.rdb.Removeable;
import amgen.ri.rdb.SQLManagerIF;

import com.sun.xml.messaging.saaj.util.ByteOutputStream;
import java.util.concurrent.ExecutionException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 *   RDBData wrapper class for SavedObject
 *   @version $Revision: 1.3 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class SavedObject extends RdbData implements LobSaveable, Removeable {
  protected OraSequenceField saved_object_id;
  protected ObjectType object_type_id;
  protected String name;
  protected String description;
  protected String category;
  protected Timestamp created;
  protected String created_by;
  protected Timestamp modified;
  protected String modified_by;
  protected BlobData obj;

  /**
   * Default Constructor
   */
  public SavedObject() {
    super();
  }

  /**
   * RdbData Constructor
   */
  public SavedObject(String saved_object_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
    this.saved_object_id = new OraSequenceField(saved_object_id);
  }

  /**
   * Constructor which saves a serializable object
   *
   * @param name String
   * @param description String
   * @param created_by String
   * @param saveObj Serializable
   * @param sqlManager SQLManagerIF
   * @param logonusername String
   * @param connectionPool String
   * @throws IOException
   * @throws AIGException
   */
  public SavedObject(String name, String description, EntityListCategory category, String created_by, SaveableIF savebleObj, SQLManagerIF sqlManager, String logonusername, String connectionPool) throws
          IOException, AIGException {
    super(sqlManager, logonusername, connectionPool);
    this.saved_object_id = new OraSequenceField("entity_list_seq", this);
    setName(name);
    this.description = description;
    this.category = category.toString();
    this.created = new Timestamp(System.currentTimeMillis());
    this.created_by = created_by;
    this.modified = new Timestamp(System.currentTimeMillis());
    this.modified_by = created_by;

    this.object_type_id = new ObjectType(savebleObj.getObjectType() + "", sqlManager, logonusername, connectionPool);
    if (object_type_id == null || !object_type_id.setData()) {
      throw new AIGException("Not a valid object type", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }

    /*
    ByteOutputStream out = new ByteOutputStream();
    ObjectOutputStream objOut = new ObjectOutputStream(out);
    objOut.writeObject(saveObj);
    objOut.close();
     */
    this.obj = new BlobData(savebleObj.getObjectBytes());
  }

  /**
   * Constructor which saves a String
   *
   * @param name String
   * @param description String
   * @param created_by String
   * @param type int
   * @param saveObj String
   * @param sqlManager SQLManagerIF
   * @param logonusername String
   * @param connectionPool String
   * @throws IOException
   * @throws AIGException
   */
  public SavedObject(String name, String description, EntityListCategory category, String created_by, int type, String saveObj, SQLManagerIF sqlManager, String logonusername, String connectionPool) throws
          IOException,
          AIGException {
    super(sqlManager, logonusername, connectionPool);
    this.saved_object_id = new OraSequenceField("entity_list_seq", this);
    setName(name);
    this.description = description;
    this.category = category.toString();
    this.created = new Timestamp(System.currentTimeMillis());
    this.created_by = created_by;
    this.modified = new Timestamp(System.currentTimeMillis());
    this.modified_by = created_by;
    this.object_type_id = new ObjectType(type + "", sqlManager, logonusername, connectionPool);

    if (this.object_type_id == null || !this.object_type_id.setData()) {
      throw new AIGException("Not a valid object type", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }
    this.obj = new BlobData(saveObj);
  }

  /** A required method which returns the primary key(s) of the table/RdbData class. */
  public String getIdentifier() {
    return saved_object_id + "";
  }

  /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
  protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
    field.set(this, value);
  }

  /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
  protected Object getFieldValue(Field field) throws IllegalAccessException {
    return field.get(this);
  }

  /** This method returns the name of the table. */
  protected String getTableName() {
    return "SAVED_OBJECTS";
  }

  /**
   * Returns any Favorites for this SavedObject
   *
   * @return List
   */
  public List<Favorite> getFavorites() {
    return Favorite.getFavorite(getIdentifier(), ObjectType.ENTITYTABLE, getCreated_by(), getConnectionPool());
  }

  public int performDelete() {
    if (isA(ObjectType.ENTITYTABLE)) {
      //Delete any Favorites
      List<Favorite> favorites = getFavorites();
      for (Favorite favorite : favorites) {
        favorite.performDelete();
      }
    }
    return super.performDelete();
  }

  /**
   * Returns whether this ObjectType matches the given type id. Use the ObjectType
   * class statics for comparisons.
   *
   * @param type int
   * @return boolean
   */
  private boolean isA(int type) {
    return getObject_type().isA(type);
  }

  /** Returns the SQL for INSERTing the object in the table */
  public String getInsertSQL() {
    return null;
  }

  /** Returns the SQL for UPDATing the object in the table */
  public String getUpdateSQL() {
    return null;
  }

  /** Returns the SQL for DELTEing the object/row in the table */
  public String getDeleteSQL() {
    return null;
  }

  /** Returns the SQL statement which selects for the LOB */
  public String getSelectLobSQL(String fieldName) {
    return null;
  }

  /** Returns a reader which will stream the Clob data */
  public Reader getClobReader(String fieldName) {
    return null;
  }

  /** Returns an inputstream which will stream the Blob data */
  public InputStream getBlobStream(String fieldName) {
    if (fieldName.equals("obj")) {
      return obj.getBlobStream();
    }
    return null;
  }

  /** Get value for object_type_id */
  public ObjectType getObject_type() {
    return (ObjectType) get("object_type_id");
  }

  /** Set value for object_type_id */
  public void setObject_type_id(ObjectType object_type) {
    set("object_type_id", object_type);
  }

  /** Get value for name */
  public String getName() {
    return (String) get("name");
  }

  /** Set value for name */
  public void setName(String name) {
    if (name == null || name.trim().length() == 0) {
      throw new IllegalArgumentException("Favorite name cannot be empty");
    }
    this.name = name;
  }

  /** Get value for description */
  public String getDescription() {
    return (String) get("description");
  }

  /** Get value for category */
  public void setCategory(EntityListCategory category) {
    if (category.equals(EntityListCategory.UNKNOWN)) {
      throw new IllegalArgumentException("Category can not be UNKNOWN");
    }
    this.category = category.toString();
  }

  /** Set value for description */
  public void setDescription(String description) {
    set("description", description);
  }

  /** Get value for created */
  public Timestamp getCreated() {
    return (Timestamp) get("created");
  }

  /** Get value for created_by */
  public String getCreated_by() {
    return (String) get("created_by");
  }

  /** Get value for modified */
  public Timestamp getModified() {
    return (Timestamp) get("modified");
  }

  /** Get value for modified_by */
  public String getModified_by() {
    return (String) get("modified_by");
  }

  /** Get value for modified_by */
  public void updateModification(AIGSessionLogin sessionLogin) {
    this.modified = new Timestamp(System.currentTimeMillis());
    this.modified_by = sessionLogin.getRemoteUser();
  }

  public EntityListCategory getCategory() {
    return EntityListCategory.fromString((String) get("category"));
  }

  /** Set value for obj. Also resets the modification date and user */
  public void setSavedObject(Serializable saveObject, AIGSessionLogin sessionLogin) throws IOException {
    ByteOutputStream out = new ByteOutputStream();
    ObjectOutputStream objOut = new ObjectOutputStream(new GZIPOutputStream(out));
    objOut.writeObject(saveObject);
    objOut.close();
    set("obj", new BlobData(out.getBytes()));
    updateModification(sessionLogin);
  }

  /**
   * Get the saved serializable Object
   *
   * @throws IOException
   * @throws ClassNotFoundException
   * @return Object
   */
  public Object getSavedObject() throws IOException, ClassNotFoundException {
    BlobData savedObj = (BlobData) get("obj");
    ObjectInputStream objIn = null;
    Object obj = null;
    try {
      try {
        objIn = new ObjectInputStream(new GZIPInputStream(savedObj.getBlobStream()));
        obj = objIn.readObject();
      } catch (Exception e1) {
        objIn = new ObjectInputStream(savedObj.getBlobStream());
        obj = objIn.readObject();
      }
    } finally {
      try {
        objIn.close();
      } catch (Exception e2) {
      }
    }
    return obj;
  }

  /**
   * Get the saved serializable Object
   *
   * @throws IOException
   * @throws ClassNotFoundException
   * @return Object
   */
  public String getSavedString() {
    BlobData savedObj = (BlobData) get("obj");
    return savedObj.toString();
  }

  public static List<SavedObject> getSavedObjects(int type, String createdBy, String connectionPool) {
    return new RdbDataArray(SavedObject.class, new CompareTerm[]{
              new CompareTerm("OBJECT_TYPE_ID", type + ""),
              new CompareTerm("CREATED_BY", createdBy)
            }, new OraSQLManager(), null, connectionPool);

  }
}
