/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.uddi;

import amgen.ri.aig.AIGException;
import amgen.ri.json.JSONObject;
import org.jdom.Document;
import org.jdom.JDOMException;

/**
 *
 * @author jemcdowe
 */
public interface ServiceLookupIF {
  JSONObject getServiceRecords() throws JDOMException, AIGException;  
  Document getServicesDocument() throws JDOMException, AIGException;  
}
