package amgen.ri.aig.entitytable;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.aig.cache.item.ServiceResultRawCacheItem;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.entity.oil.BasicEntityOILConverter;
import amgen.ri.aig.entity.oil.EntityOILConverterIF;
import amgen.ri.aig.entity.oil.UIR;
import amgen.ri.aig.entitylist.EntityListIF;
import amgen.ri.aig.entitylist.EntityListMemberIF;
import amgen.ri.aig.entitylist.EntityListSourceServiceIF;
import amgen.ri.aig.entitylist.GenericEntityListMember;
import amgen.ri.aig.entitytable.category.schema2.ColumnType;
import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;
import amgen.ri.aig.entitytable.proxy.EntityTableProxy;
import amgen.ri.aig.entitytable.subtable.SubtableDataCell;
import amgen.ri.aig.preferences.PreferenceIF;
import amgen.ri.aig.preferences.PreferenceableIF;
import amgen.ri.aig.scripts.CalculationScriptsIF;
import amgen.ri.aig.scripts.CalculationType;
import amgen.ri.aig.scripts.ColumnCalculator;
import amgen.ri.aig.sm.structure.SMStructureDocumentReader;
import amgen.ri.aig.sobj.ObjectType;
import amgen.ri.aig.sobj.SaveObjectException;
import amgen.ri.aig.sobj.SaveableIF;
import amgen.ri.aig.sobj.SavedObject;
import amgen.ri.aig.util.Utilities;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.chem.ExtMolecule;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtObject;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import com.google.common.collect.LinkedListMultimap;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URL;
import java.util.*;
import java.util.zip.GZIPInputStream;
import javax.imageio.ImageIO;
import org.jdom.Document;
import org.jdom.Element;

/**
 * Model for the EntityTable
 *
 * @version $Id: EntityTable.java,v 1.22 2015/08/05 19:51:28 jemcdowe Exp $
 */
public class EntityTable implements Serializable, EntityListIF, PreferenceableIF, SaveableIF {
  static final long serialVersionUID = -1604350296174350043L;
  private final int MAX_ROWS = 10000;
  private String tableKey; //Used to hold the tableCacheID
  private String tableName; //Holds a name for the table
  private String tableDescription; //Holds a description for the table
  private List<ColumnGroup> columnGroups; //List of ColumnGroups in the table
  private List<DataRow> dataRows; //List of DataRows in the table
  private Map<String, DataRow> dataRowMap; //Map of Entity ID:DataRows in the table
  private int pageSize = 25; //Paging size (rows)
  private int rowHeightPixels = -1; //Defines the row height in pixels. Used only to define image heights
  private EntityListCategory tableCategory; //Type of table
  private ColumnSort columnSort; //Current sort of the DataRows
  private ColumnFilter columnFilter; //Current filter of DataRows
  private ServiceResultCacheItem serviceResultCacheItem; //Holds the original service result
  private transient SavedObject savedObject;
  private transient Map<String, String> exportOptions;
  private transient JSONObject entityTableJSON; //Current table as a JSON string
  private transient EntityTableCellFormatterIF currentFormatter;
  private transient byte[] structureDocument;
  //Maintains some basic display information
  private JSONObject tableConfig;
  //basic display information for columns and column groups
  private JSONObject columnsConfig;
  /*
   * Legacy fields needed for serialization evolution
   */
  private StructureDataCell i_do_nothing;
  private amgen.ri.aig.category.EntityListCategory entityTableType; //Type of table- This is a hold-over enum using v1.2 serialization!!!

  public EntityTable() {
    columnGroups = new ArrayList<ColumnGroup>();
    dataRows = new ArrayList<DataRow>();
    dataRowMap = new HashMap<String, DataRow>();
    columnSort = new ColumnSort();
    tableConfig = new JSONObject();
    tableName = "Entity Table";
    this.rowHeightPixels = (int) Utilities.points2Pixels(150, false);
  }

  /**
   * Creates a new EntityTable of the given type
   *
   * @param requestor AIGBase
   * @param entityTableType EntityListCategory
   */
  public EntityTable(EntityListCategory tableCategory) {
    this();
    this.tableCategory = tableCategory;
  }

  /**
   * Sets the EntityTable Column Groups
   *
   * @param columnGroups List
   */
  public void setColumnGroups(List<ColumnGroup> columnGroups) {
    this.columnGroups = columnGroups;
  }

  /**
   * Sets the DataRows for the Table
   *
   * @param dataRows List
   */
  public void setDataRows(List<DataRow> dataRows) {
    this.dataRows = dataRows;
    this.dataRowMap = new HashMap<String, DataRow>();
    for (DataRow row : dataRows) {
      this.dataRowMap.put(row.getEntityID(), row);
    }
  }

  /**
   * Returns the image for a cell for an Image Column. This may be 1. The cell's
   * image, properly scaled if requested 2. If no cell image, the default column
   * image 3. If no cell or default column image, the default "No Image
   * Available"
   *
   * @param dataIndex Column's dataIndex
   * @param cell DataCell
   * @param requestor AIGBase
   * @return BufferedImage
   */
  public BufferedImage getCellImage(String dataIndex, DataCell cell, boolean scaledImage, AIGBase requestor) {
    return getCellImage(getColumnByDataIndex(dataIndex), cell, scaledImage, requestor);
  }

  /**
   * Returns the image for a cell for an Image Column. This may be 1. The cell's
   * image, properly scaled if requested 2. If no cell image, the default column
   * image 3. If no cell or default column image, the default "No Image
   * Available"
   *
   * @param column Column
   * @param cell DataCell
   * @param requestor AIGBase
   * @return BufferedImage
   */
  public BufferedImage getCellImage(Column column, DataCell cell, boolean scaledImage, AIGBase requestor) {
    if (column == null) {
      return null;
    }
    BufferedImage img = null;
    if (scaledImage) {
      img = cell.getScaledImage(column);
    } else {
      img = cell.getImage();
    }
    if (img == null && ExtString.hasLength(column.getDefaultImageURL())) {
      try {
        img = ImageIO.read(new URL(column.getDefaultImageURL()));
      } catch (Exception e) {
        img = null;
      }
    }
    if (img == null) {
      try {
        img = requestor.getDefaultNoImage();
      } catch (Exception e) {
      }
    }
    return img;
  }

  /**
   * Reorders the column according to the provided data index List
   *
   * @param dataIndexes List
   */
  public void updateColumnGroupOrder(List<String> dataIndexes) {
    if (dataIndexes.size() != columnGroups.size()) {
      return;
    }
    List<ColumnGroup> updatedColumngroupList = new ArrayList<ColumnGroup>();
    for (String dataIndex : dataIndexes) {
      ColumnGroup updatedColumnGroup = null;
      for (ColumnGroup columnGroup : columnGroups) {
        if (columnGroup.getDataIndex().equals(dataIndex)) {
          updatedColumnGroup = columnGroup;
          break;
        }
      }
      if (updatedColumnGroup == null) {
        throw new IllegalArgumentException("Unable to find Column Group " + dataIndex);
      }
      updatedColumngroupList.add(updatedColumnGroup);
    }
    this.columnGroups = updatedColumngroupList;
  }

  /**
   * getCurrentFormatter
   *
   * @return EntityTableCellFormatter
   */
  public EntityTableCellFormatterIF getCurrentFormatter() {
    if (this.currentFormatter == null) {
      currentFormatter = new DefaultEntityTableCellFormatter();
    }
    return currentFormatter;
  }

  /**
   * Sets the current EntityTableCellFormatterIF
   */
  public void setCurrentFormatter(EntityTableCellFormatterIF formatter) {
    this.currentFormatter = formatter;
  }

  /**
   * Creates a column group based on a service result
   *
   * @param requestor AIGServlet
   * @param serviceResultCacheItem ServiceResultCacheItem
   * @return boolean
   */
  public boolean addServiceResult(AIGServlet requestor, ServiceResultCacheItem serviceResultCacheItem) {
    if (serviceResultCacheItem == null) {
      return false;
    }
    if (serviceResultCacheItem instanceof ServiceResultRawCacheItem) {
      return addServiceResultFromProxyModelResult(requestor, (ServiceResultRawCacheItem) serviceResultCacheItem);
    }
    Document entityTableColumnResultDoc = null;
    try {
      entityTableColumnResultDoc = serviceResultCacheItem.transformResult(requestor, TModelCommonNameFactory.ENTITYTABLEDEFINITION_tMODELNAME, null, true);
    } catch (Exception ex) {
      ex.printStackTrace();
    }

    if (entityTableColumnResultDoc == null || ExtXMLElement.getXPathElements(entityTableColumnResultDoc, "/EntityTable/ColumnGroup[count(Column)>0]").size() == 0) {
      return false;
    }
    Element entityTableEl = entityTableColumnResultDoc.getRootElement();
    List<Column> newColumns = new ArrayList<Column>();
    List<Element> columnGroupEls = ExtXMLElement.getXPathElements(entityTableColumnResultDoc, "/EntityTable/ColumnGroup[count(Column)>0]");
    for (Element columnGroupEl : columnGroupEls) {
      ColumnGroup columnGroup = new ColumnGroup(columnGroupEl, 100);
      newColumns.addAll(columnGroup.getColumns());
      columnGroups.add(columnGroup);
    }
    if (newColumns.size() > 0) {
      for (DataRow dataRow : dataRows) {
        String entityID = dataRow.getEntityID();
        List<Element> dataCellEls = ExtXMLElement.getXPathElements(entityTableEl, "/EntityTable/Row[@entity_id='" + entityID + "'][1]/child::*[name()='Cell' or name()='TableCell']");
        if (dataCellEls.size() == newColumns.size()) {
          for (Element dataCellEl : dataCellEls) {
            if (dataCellEl.getName().equals("Cell")) {
              String text = dataCellEl.getText();
              String imageURL = dataCellEl.getAttributeValue("image_url");
              String linkoutTokens = dataCellEl.getAttributeValue("linkoutTokens");
              String[] tokens = null;
              if (ExtString.hasLength(linkoutTokens)) {
                tokens = linkoutTokens.split(",");
              }
              DataCell dataCell = dataRow.addDataCell(new DataCell(text, imageURL, 0, 0));
              if (ExtArray.hasLength(tokens)) {
                dataCell.setLinkoutTokens(tokens);
              }
            } else if (dataCellEl.getName().equals("TableCell")) {
              List<Element> subtableRowEls = dataCellEl.getChildren("Row");
              List<DataCell> subCells = new ArrayList<DataCell>();
              for (Element subtableRowEl : subtableRowEls) {
                Element subtableCellEl = subtableRowEl.getChild("Cell");
                if (subtableCellEl != null) {
                  String text = subtableCellEl.getText();
                  subCells.add(new DataCell(text));
                }
              }
              dataRow.addDataCell(new SubtableDataCell(subCells));
            }
          }
        } else {
          for (int i = 0; i < newColumns.size(); i++) {
            dataRow.addDataCell(new DataCell(""));
          }
        }
      }
    }
    getEntityTableJSON(true);
    return true;
  }
  

  /**
   * Creates a column group based on a service result
   *
   * @param requestor AIGServlet
   * @param serviceResultCacheItem ServiceResultCacheItem
   * @return boolean
   */
  public boolean addServiceResult(Document entityTableColumnResultDoc) {    
    if (entityTableColumnResultDoc == null || ExtXMLElement.getXPathElements(entityTableColumnResultDoc, "/EntityTable/ColumnGroup[count(Column)>0]").size() == 0) {
      return false;
    }
    Element entityTableEl = entityTableColumnResultDoc.getRootElement();
    List<Column> newColumns = new ArrayList<Column>();
    List<Element> columnGroupEls = ExtXMLElement.getXPathElements(entityTableColumnResultDoc, "/EntityTable/ColumnGroup[count(Column)>0]");
    for (Element columnGroupEl : columnGroupEls) {
      ColumnGroup columnGroup = new ColumnGroup(columnGroupEl, 100);
      newColumns.addAll(columnGroup.getColumns());
      columnGroups.add(columnGroup);
    }
    if (newColumns.size() > 0) {
      for (DataRow dataRow : dataRows) {
        String entityID = dataRow.getEntityID();
        List<Element> dataCellEls = ExtXMLElement.getXPathElements(entityTableEl, "/EntityTable/Row[@entity_id='" + entityID + "'][1]/child::*[name()='Cell' or name()='TableCell']");
        if (dataCellEls.size() == newColumns.size()) {
          for (Element dataCellEl : dataCellEls) {
            if (dataCellEl.getName().equals("Cell")) {
              String text = dataCellEl.getText();
              String imageURL = dataCellEl.getAttributeValue("image_url");
              String linkoutTokens = dataCellEl.getAttributeValue("linkoutTokens");
              String[] tokens = null;
              if (ExtString.hasLength(linkoutTokens)) {
                tokens = linkoutTokens.split(",");
              }
              DataCell dataCell = dataRow.addDataCell(new DataCell(text, imageURL, 0, 0));
              if (ExtArray.hasLength(tokens)) {
                dataCell.setLinkoutTokens(tokens);
              }
            } else if (dataCellEl.getName().equals("TableCell")) {
              List<Element> subtableRowEls = dataCellEl.getChildren("Row");
              List<DataCell> subCells = new ArrayList<DataCell>();
              for (Element subtableRowEl : subtableRowEls) {
                Element subtableCellEl = subtableRowEl.getChild("Cell");
                if (subtableCellEl != null) {
                  String text = subtableCellEl.getText();
                  subCells.add(new DataCell(text));
                }
              }
              dataRow.addDataCell(new SubtableDataCell(subCells));
            }
          }
        } else {
          for (int i = 0; i < newColumns.size(); i++) {
            dataRow.addDataCell(new DataCell(""));
          }
        }
      }
    }
    getEntityTableJSON(true);
    return true;
  }  

  /**
   * Creates a column group based on a service result
   *
   * @param requestor AIGServlet
   * @param serviceResultCacheItem ServiceResultCacheItem
   * @return boolean
   */
  public boolean addStructureDetails(AIGServlet requestor) {
    Document structureDoc = null;
    try {
      structureDoc = getStructureDocument(requestor);
    } catch (IOException ex) {
    }
    if (structureDoc == null) {
      return false;
    }
    ColumnGroup columnGroup = new ColumnGroup("Structure Properties");
    columnGroups.add(columnGroup);
    columnGroup.addColumn(new Column("SMILES"));
    columnGroup.addColumn(new Column("CHIME"));
    columnGroup.addColumn(new Column("Formula"));
    columnGroup.addColumn(new Column("Natural Exact Mass (g/mol)", EntityTableDataType.DOUBLE));
    columnGroup.addColumn(new Column("Major Isotope Mass (g/mol)", EntityTableDataType.DOUBLE));
    columnGroup.addColumn(new Column("Total Mass Number (g/mol)", EntityTableDataType.DOUBLE));
    columnGroup.addColumn(new Column("Aromatic (Hückel 4n+2 pi-electrons rule)"));
    columnGroup.addColumn(new Column("Atom Count", EntityTableDataType.INTEGER));
    columnGroup.addColumn(new Column("Heavy Atom Count", EntityTableDataType.INTEGER));

    for (DataRow dataRow : dataRows) {
      String entityID = dataRow.getEntityID();
      String structureXPath = "//Structure[ID=%s][count(Access)=0 or Access/@code != '0']/MOL";

      if (ExtString.isAInteger(entityID)) {
        structureXPath = String.format(structureXPath, new Object[]{ExtString.toInteger(entityID)});
      } else if (ExtString.isANumber(entityID)) {
        structureXPath = String.format(structureXPath, new Object[]{entityID});
      } else {
        structureXPath = String.format(structureXPath, new Object[]{"'" + entityID + "'"});
      }
      String molFile = ExtXMLElement.getXPathValue(structureDoc, structureXPath);
      if (molFile != null) {
        ExtMolecule molecule = new ExtMolecule(molFile);
        dataRow.addDataCell(new DataCell(molecule.getSMILES()));
        dataRow.addDataCell(new DataCell(molecule.getChimeString()));
        dataRow.addDataCell(new DataCell(molecule.getHillString()));
        dataRow.addDataCell(new DataCell(molecule.getNaturalExactMass()));
        dataRow.addDataCell(new DataCell(molecule.getMajorIsotopeMass()));
        dataRow.addDataCell(new DataCell(molecule.getTotalMassNumber()));
        dataRow.addDataCell(new DataCell((molecule.isAromatic() ? "Yes" : "No")));
        dataRow.addDataCell(new DataCell(molecule.getAtomCount()));
        dataRow.addDataCell(new DataCell(molecule.getHeavyAtomCount()));
      } else {
        dataRow.addDataCell(new DataCell(""));
        dataRow.addDataCell(new DataCell(""));
        dataRow.addDataCell(new DataCell(""));
        dataRow.addDataCell(new DataCell(""));
        dataRow.addDataCell(new DataCell(""));
        dataRow.addDataCell(new DataCell(""));
        dataRow.addDataCell(new DataCell(""));
        dataRow.addDataCell(new DataCell(""));
        dataRow.addDataCell(new DataCell(""));
      }
    }
    getEntityTableJSON(true);
    return true;
  }

  /**
   * Creates a column group based on a service result which is an
   * EntityTableProxy serialized Object
   *
   * @param requestor AIGServlet
   * @param serviceResultCacheItem ServiceResultCacheItem
   * @return boolean
   */
  public boolean addServiceResultFromProxyModelResult(AIGServlet requestor, ServiceResultRawCacheItem serviceResultCacheItem) {
    if (serviceResultCacheItem == null) {
      return false;
    }
    EntityOILConverterIF oilConverter= new BasicEntityOILConverter();
    EntityClassManager entityClassManager= requestor.getEntityClassManager();
    
    EntityTableProxy entityTableProxy = null;
    try {
      Object obj = serviceResultCacheItem.getAsObject();
      entityTableProxy = (EntityTableProxy) obj;
    } catch (Exception ex) {
      //ex.printStackTrace();
      return false;
    }
    int newColumnCount = 0;
    List<ColumnGroup> resultColumnGroups = entityTableProxy.getColumnGroups();
    for (ColumnGroup resultColumnGroup : resultColumnGroups) {
      if (resultColumnGroup.getColumnCount() > 0) {
        columnGroups.add(resultColumnGroup);
        newColumnCount += resultColumnGroup.getColumnCount();
      }
    }
    if (newColumnCount > 0) {
      LinkedListMultimap<String, DataRow> uirDataRowMap= oilConverter.generateUIRDataRowMap(entityClassManager.getEntityClass(getEntityCategory()), entityTableProxy.getDataRows());     
      
      for (DataRow dataRow : dataRows) {
        String entityID = dataRow.getEntityID();
        
        List<DataRow> resultDataRows = uirDataRowMap.get(entityID);
        if (!resultDataRows.isEmpty() && resultDataRows.get(0).getDataCells().size() == newColumnCount) {
          int added = dataRow.addDataCells(resultDataRows.get(0).getDataCells());
        } else {
          for (int i = 0; i < newColumnCount; i++) {
            dataRow.addDataCell(new DataCell(""));
          }
        }
      }
    }
    getEntityTableJSON(true);
    return true;
  }

  /**
   * Creates a editable columns
   *
   * @param header String
   * @param dataType EntityTableDataType
   */
  public void addEditableColumns(String header, EntityTableDataType dataType) {
    Column column = new Column(header, dataType, ColumnType.EDITABLE);

    for (DataRow dataRow : dataRows) {
      String entityID = dataRow.getEntityID();
      dataRow.addDataCell(new DataCell("", dataType));
    }
    ColumnGroup columnGroup = new ColumnGroup(column.getHeaderText());
    columnGroup.addColumn(column);
    columnGroups.add(columnGroup);
    getEntityTableJSON(true);

  }

  /**
   * Tests a potential calculated Column to find errors before creating. Returns
   * a best guess on the data type for the column
   *
   * @param calcConfig JSONObject
   * @param availableScriptMethods CalculationScriptsIF
   * @throws Exception
   * @return EntityTableDataType
   */
  public EntityTableDataType evaluateCalculatedColumn(JSONObject calcConfig, CalculationScriptsIF availableScriptMethods) throws Exception {
    CalculationType calculationType = CalculationType.fromString(calcConfig.optString("calculationType", "unknown"));
    String jsSource = null;
    switch (calculationType) {
      case FUNCTION:
        jsSource = calcConfig.getString("functionCalculation");
        break;
      case EXPRESSION:
        jsSource = calcConfig.getString("expressionCalculation");
        break;
      case ADVANCED:
        jsSource = calcConfig.getString("advFunction");
        break;
    }
    ColumnCalculator columnCalculator = new ColumnCalculator(this, availableScriptMethods, jsSource, calculationType);
    return columnCalculator.testScript(this);
  }

  /**
   * Creates a calculated Column
   *
   * @param newColumnHeader String
   * @param calcConfig JSONObject
   */
  public void addCalculatedColumn(String columnGroupHeader, String columnGroupDataIndex, String header, JSONObject calcConfig, JSONObject calcColumnFormat,
          CalculationScriptsIF availableScriptMethods) throws Exception {
    EntityTableDataType calcColumnDataType = evaluateCalculatedColumn(calcConfig, availableScriptMethods);
    CalculationType calculationType = CalculationType.fromString(calcConfig.optString("calculationType", "unknown"));
    String jsSource = null;
    switch (calculationType) {
      case FUNCTION:
        jsSource = calcConfig.getString("functionCalculation");
        break;
      case EXPRESSION:
        jsSource = calcConfig.getString("expressionCalculation");
        break;
      case ADVANCED:
        jsSource = calcConfig.getString("advFunction");
        break;
    }
    ColumnCalculator columnCalculator = new ColumnCalculator(this, availableScriptMethods, jsSource, calculationType);

    ColumnGroup columnGroup = null;
    if (!ExtString.equals(columnGroupHeader, "[default]")) {
      columnGroup = getColumnGroup(columnGroupDataIndex);
    }
    Column column = new Column(header.trim(), EntityTableDataType.TEXT, ColumnType.CALCULATED);
    column.setCalculatedColumnConfig(calcConfig);
    if (calcColumnFormat != null) {
      column.setColumnFormat(new ColumnFormat(calcColumnFormat));
    }
    if (columnGroup != null) {
      columnGroup.addColumn(column);
    } else if (ExtString.hasTrimmedLength(columnGroupHeader) && !ExtString.equals(columnGroupHeader, "[default]")) {
      columnGroup = new ColumnGroup(columnGroupHeader.trim());
      columnGroup.addColumn(column);
      columnGroups.add(columnGroup);
    } else if (ExtString.hasTrimmedLength(header)) {
      columnGroup = new ColumnGroup(header.trim());
      columnGroup.addColumn(column);
      columnGroups.add(columnGroup);
    } else {
      throw new IllegalArgumentException("No column header provided");
    }
    columnCalculator.calculateNew(this, this.getColumnIndex(column.getDataIndex()), calcColumnDataType);
    getEntityTableJSON(true);
  }

  /**
   * Recalculates Column
   *
   * @param newColumnHeader String
   * @param calcConfig JSONObject
   */
  public void reCalculateColumn(String columnDataIndex, JSONObject calcConfig, JSONObject columnFormat, CalculationScriptsIF availableScriptMethods) throws Exception {
    Column column = getColumnByDataIndex(columnDataIndex);
    int columnIndex = getColumnIndex(columnDataIndex);
    if (column == null || !column.getColumnType().equals(ColumnType.CALCULATED) || columnIndex < 0) {
      throw new IllegalArgumentException("Invalid column specified");
    }
    if (calcConfig == null) {
      calcConfig = column.getCalculatedColumnConfig();
    }
    if (calcConfig == null) {
      throw new IllegalArgumentException("Invalid column specified. No calculation specified.");
    }
    if (columnFormat != null) {
      column.setColumnFormat(new ColumnFormat(columnFormat));
    }

    EntityTableDataType calcColumnDataType = evaluateCalculatedColumn(calcConfig, availableScriptMethods);

    CalculationType calculationType = CalculationType.fromString(calcConfig.optString("calculationType", "unknown"));
    String jsSource = null;
    switch (calculationType) {
      case FUNCTION:
        jsSource = calcConfig.getString("functionCalculation");
        break;
      case EXPRESSION:
        jsSource = calcConfig.getString("expressionCalculation");
        break;
      case ADVANCED:
        jsSource = calcConfig.getString("advFunction");
        break;
    }
    ColumnCalculator columnCalculator = new ColumnCalculator(this, availableScriptMethods, jsSource, calculationType);
    columnCalculator.reCalculate(this, columnDataIndex, calcColumnDataType);
    column.setHeaderText(calcConfig.optString("header", column.getHeaderText()));
    column.setCalculatedColumnConfig(calcConfig);
    getEntityTableJSON(true);
  }

  /**
   * Creates column groups based in VQT service results
   *
   * @param columnHeaders Map
   * @return boolean
   */
  public boolean addVQTServiceResultColumns(Map<Integer, Column> vqtColumns) {
    List<Column> newColumns = new ArrayList<Column>();
    for (Integer order : vqtColumns.keySet()) {
      Column column = new Column(vqtColumns.get(order));
      ColumnGroup columnGroup = new ColumnGroup(column.getHeaderText());
      newColumns.add(column);
      columnGroup.addColumn(column);
      columnGroups.add(columnGroup);
    }
    getEntityTableJSON(true);
    return (newColumns.size() > 0);
  }

  /**
   * Adds the data to the VQT service result rows
   *
   * @param columnHeaders Map
   * @param columnData Map
   */
  public void addVQTServiceResult(Map<Integer, Column> columnHeaders, Map<String, Map<Integer, String>> columnData) {
    if (columnHeaders.size() > 0) {
      for (DataRow dataRow : dataRows) {
        String entityID = dataRow.getEntityID();
        Map<Integer, String> columnValues = columnData.get(entityID);
        if (columnValues != null) {
          for (Integer order : columnHeaders.keySet()) {
            String value = columnValues.get(order);
            if (!ExtString.hasTrimmedLength(value)) {
              dataRow.addDataCell(new DataCell(""));
            } else {
              dataRow.addDataCell(new DataCell(value));
            }
          }
        }
      }
    }
  }

  /**
   * Returns all ColumnGroups
   *
   * @return List
   */
  public List<ColumnGroup> getColumnGroups() {
    return columnGroups;
  }

  /**
   * Finds the column group using a data index- This can be the index for the
   * ColumnGroup or for an index for a child column
   *
   * @param dataIndex String
   * @return ColumnGroup
   */
  public ColumnGroup getColumnGroup(String dataIndex) {
    if (dataIndex == null) {
      return null;
    }

    for (ColumnGroup columnGroup : getColumnGroups()) {
      if (columnGroup.getDataIndex().equals(dataIndex)) {
        return columnGroup;
      }
      for (Column column : columnGroup.getColumns()) {
        if (column.getDataIndex().equals(dataIndex)) {
          return columnGroup;
        }
      }
    }
    return null;
  }

  /**
   * Finds the column group for a given column
   *
   * @param column Column
   * @return ColumnGroup
   */
  public ColumnGroup getColumnGroup(Column column) {
    return getColumnGroup(column.getDataIndex());
  }

  public int getColumnCount() {
    int count = 0;
    for (ColumnGroup columnGroup : getColumnGroups()) {
      count += columnGroup.getColumnCount();
    }
    return count;
  }

  public List<DataRow> getDataRows() {
    return dataRows;
  }

  public DataRow getDataRow(String entityID) {
    return dataRowMap.get(entityID);
  }

  public int getDataRowIndex(DataRow dataRow) {
    for (int i = 0; i < dataRows.size(); i++) {
      if (dataRows.get(i).getEntityID().equals(dataRow.getEntityID())) {
        return i;
      }
    }
    return -1;
  }

  /**
   * Returns the current column sort
   *
   * @return ColumnSort
   */
  public ColumnSort getColumnSort() {
    return columnSort;
  }

  /**
   * Returns the current row height in pixels
   *
   * @return int
   */
  public int getRowHeightPixels() {
    return rowHeightPixels;
  }

  /**
   * Returns the TableKey used to store this in the session cache
   *
   * @return String
   */
  public String getTableKey() {
    return tableKey;
  }

  public String getDescription() {
    return tableDescription;
  }

  /**
   * Returns the current row height in pixels
   *
   * @return int
   */
  public int getRowHeightPoints() {
    return (int) Math.ceil(Utilities.points2Pixels(rowHeightPixels, true));
  }

  public String getTableName(boolean removeProbleChars) {
    if (!removeProbleChars) {
      return tableName;
    }
    String name = tableName;
    String invalidChars = "!@#$%&()+~`\"':;,.|/\\[]?*";
    for (int i = 0; i < invalidChars.length(); i++) {
      name = name.replace(invalidChars.charAt(i), '_');
    }
    return name;
  }

  public void addColumnGroup(ColumnGroup columnGroup) {
    columnGroups.add(columnGroup);
  }

  /**
   * Adds a DataRow to the table. Returns null if table reached the MAX_ROWS
   *
   * @param dataRow DataRow
   * @return DataRow
   */
  public DataRow addDataRow(DataRow dataRow) {
    if (dataRows.size() >= MAX_ROWS || dataRowMap.containsKey(dataRow.getEntityID())) {
      return null;
    }
    dataRows.add(dataRow);
    dataRowMap.put(dataRow.getEntityID(), dataRow);
    return dataRow;
  }

  public List<String> getEntityIDs() {
    List<String> entityIds = new ArrayList<String>(dataRows.size());
    for (DataRow dataRow : dataRows) {
      entityIds.add(dataRow.getEntityID());
    }
    return entityIds;
  }

  /**
   * Returns a column by its data index
   *
   * @param dataIndex int
   * @return Column
   */
  public Column getColumnByDataIndex(String dataIndex) {
    int columnIndex = getColumnIndex(dataIndex);
    if (columnIndex > -1) {
      return getColumn(columnIndex);
    }
    return null;
  }

  /**
   * Returns the column index of a column by its data index
   *
   * @param dataIndex String
   * @return int
   */
  public int getColumnIndex(String dataIndex) {
    int index = -1;
    for (ColumnGroup columnGroup : columnGroups) {
      for (Column column : columnGroup.getColumns()) {
        index++;
        if (column.getDataIndex().equals(dataIndex)) {
          return index;
        }
      }
    }
    return -1;
  }

  /**
   * Returns the column index of a column
   *
   * @param column Column
   * @return int
   */
  public int getColumnIndex(Column column) {
    return getColumnIndex(column.getDataIndex());
  }

  /**
   * Returns the column groups index of a ColumnGroup or -1 if not found
   *
   * @param columnGroup ColumnGroup
   * @return int
   */
  public int getColumnGroupIndex(ColumnGroup columnGroup) {
    int index = -1;
    for (ColumnGroup cGroup : columnGroups) {
      index++;
      if (cGroup.equals(columnGroup)) {
        return index;
      }
    }
    return -1;
  }

  /**
   * Returns a column by its index
   *
   * @param columnIndex int
   * @return Column
   */
  public Column getColumn(int columnIndex) {
    int index = -1;
    for (ColumnGroup columnGroup : columnGroups) {
      for (Column column : columnGroup.getColumns()) {
        index++;
        if (index == columnIndex) {
          return column;
        }
      }
    }
    return null;
  }

  /**
   * Returns a column by its index
   *
   * @param columnIndex int
   * @return Column
   */
  public List<Column> getColumns() {
    List<Column> columns = new ArrayList<Column>();
    for (ColumnGroup columnGroup : columnGroups) {
      for (Column column : columnGroup.getColumns()) {
        columns.add(column);
      }
    }
    return columns;
  }

  /**
   * Deletes a column by its data index. If the column is the only member of a
   * column group, it calls deleteColumnGroup(). Also, removes the sort if there
   * is a dependency on the column.
   *
   * No column from the first ColumnGroup can be removed.
   *
   * @param columnDataIndex String
   * @return boolean
   */
  public boolean deleteColumn(String columnDataIndex) {
    //Not allowed to delete the entity column group
    Column column = getColumnByDataIndex(columnDataIndex);
    ColumnGroup columnGroup = getColumnGroup(column);
    if (getColumnGroupIndex(columnGroup) == 0) {
      return false;
    }

    DeleteColumnGroup deleteColumnGroup = DeleteColumnGroup.createDeleteColumnGroupByDataIndex(this, columnDataIndex);
    if (deleteColumnGroup == null) {
      return false;
    }
    if (deleteColumnGroup.columnGroup.getColumnCount() == 1) {
      return deleteColumnGroup(columnDataIndex);
    }
    if (deleteColumnGroup.columnIsSortColumn) {
      columnSort.clearSort();
    }
    deleteColumnGroup.columnGroup.deleteColumn(deleteColumnGroup.column);
    deleteCells(deleteColumnGroup.columnPosition, 1);
    return true;
  }

  /**
   * Deletes a column group given a column member's data index. Also, removes
   * the sort if there is a dependency on a member column
   *
   * No column from the first ColumnGroup can be removed.
   *
   * @param columnDataIndex String
   * @return boolean
   */
  public boolean deleteColumnGroup(String memberColumnDataIndex) {
    //Not allowed to delete the entity column group
    ColumnGroup columnGroup = getColumnGroup(memberColumnDataIndex);
    if (getColumnGroupIndex(columnGroup) == 0) {
      return false;
    }

    DeleteColumnGroup deleteColumnGroup = DeleteColumnGroup.createDeleteColumnGroupByDataIndex(this, memberColumnDataIndex);
    if (deleteColumnGroup == null) {
      return false;
    }
    if (deleteColumnGroup.columnGroupContainsSortColumn) {
      columnSort.clearSort();
    }
    columnGroups.remove(deleteColumnGroup.columnGroup);
    deleteCells(deleteColumnGroup.columnGroupPosition, deleteColumnGroup.columnGroup.getColumnCount());
    return true;
  }

  /**
   * Delete data cells in the table from [deleteCellStart, deleteCellStart +
   * deleteCellCount)
   *
   * @param deleteCellStart int
   * @param deleteCellCount int
   */
  private void deleteCells(int deleteCellStart, int deleteCellCount) {
    for (DataRow row : dataRows) {
      for (int i = 0; i < deleteCellCount; i++) {
        row.deleteColumn(deleteCellStart);
      }
    }
  }

  public JSONObject getEntityTableJSON(boolean reset) {
    try {
      if (reset || entityTableJSON == null) {
        boolean hasStructures = false;
        for (ColumnGroup columnGroup : this.columnGroups) {
          for (Column column : columnGroup.getColumns()) {
            JSONObject columnConfigJSON = new JSONObject();
            column.setSourceConfig(columnConfigJSON);
            switch (column.getDataType()) {
              case STRUCTURE:
                JSONObject structureSourceJSON = null;
                switch (getEntityCategory()) {
                  case COMPOUNDS:
                  case SUBSTANCES:
                    structureSourceJSON = new JSONObject();
                    structureSourceJSON.put("imgsource_id", "acrf");
                    hasStructures = true;
                    break;
                  case SMR_MOLECULES:
                    structureSourceJSON = new JSONObject();
                    structureSourceJSON.put("imgsource_id", "smr_molecule");
                    hasStructures = true;
                    break;
                  case SMR_STRUCTURES:
                    structureSourceJSON = new JSONObject();
                    structureSourceJSON.put("imgsource_id", "smr_structure");
                    hasStructures = true;
                    break;
                }
                if (structureSourceJSON != null) {
                  if (rowHeightPixels != -1) {
                    column.setWidth(rowHeightPixels);
                  }
                  columnConfigJSON.put("structure", structureSourceJSON);
                }
                break;
              case PERSON:
                JSONObject personSourceJSON = null;
                personSourceJSON = new JSONObject();
                personSourceJSON.put("imgsource_id", "directory");
                columnConfigJSON.put("person", personSourceJSON);
                if (rowHeightPixels != -1) {
                  column.setWidth(rowHeightPixels);
                }
                break;
            }
          }
        }

        int total = 0;
        entityTableJSON = new JSONObject();
        entityTableJSON.put("root", "values");
        if (getSavedObject() != null) {
          entityTableJSON.put("savedTableID", getSavedObject().getIdentifier());
          entityTableJSON.put("savedTableCreatedBy", getSavedObject().getCreated_by());
        }
        entityTableJSON.put("totalProperty", "total");
        entityTableJSON.put("pageSize", pageSize);
        entityTableJSON.put("entityType", getEntityCategory());
        entityTableJSON.put("hasStructures", hasStructures);

        entityTableJSON.put("rowHeight", this.getRowHeightPoints());
        entityTableJSON.put("tableConfig", this.getTableConfig());

        JSONArray fieldJArr = new JSONArray();
        entityTableJSON.put("fields", fieldJArr);
        //JSONArray columnsJArr = new JSONArray();
        //entityTableJSON.put("columns", columnsJArr);
        JSONArray headersJArr = new JSONArray();
        JSONArray headerJArr = new JSONArray();
        headersJArr.put(headerJArr);
        entityTableJSON.put("headers", headersJArr);

        JSONArray jColumnGroups = new JSONArray();
        entityTableJSON.put("columngroups", jColumnGroups);

        JSONArray entityIDDataIndexesJArr = new JSONArray();
        entityTableJSON.put("entityIDDataIndexes", entityIDDataIndexesJArr);

        int columnGroupCounter = 0;
        for (ColumnGroup columnGroup : columnGroups) {
          boolean isEntityColumnGroup = (getColumnGroupIndex(columnGroup) == 0);
          JSONObject jColumnGroup = columnGroup.getJSON();
          int columnGroupOrder = getColumnGroupConfig(columnGroup, "index", columnGroupCounter++).intValue();
          columnGroupCounter = columnGroupOrder + 1;
          jColumnGroup.put("index", columnGroupOrder);
          headerJArr.put(jColumnGroup);
          jColumnGroups.put(jColumnGroup);
          int columnCounter = 0;
          for (Column column : columnGroup.getColumns()) {
            if (columnGroup.isEntityIDDataIndex()) {
              entityIDDataIndexesJArr.put(column.getDataIndex());
            }
            fieldJArr.put(column.getDataIndex());
            JSONObject jColumn = column.getJSON();
            jColumn.put("hierarchy", columnGroup.getHeaderText() + ": " + column.getHeaderText());
            jColumn.put("can_delete", !isEntityColumnGroup);
            int columnOrder = getColumnConfig(column, "index", columnCounter++).intValue();
            columnCounter = columnOrder + 1;
            jColumn.put("index", columnOrder);
            //columnsJArr.put(jColumn);
            jColumnGroup.append("columns", jColumn);
          }
        }
      }
    } catch (JSONException e) {
      e.printStackTrace();
    }

    return entityTableJSON;
  }

  /**
   * Returns the table config. The table config is additional parameters beyond
   * the standard configuration like columns row height, ...
   *
   * @return Collection
   */
  public JSONObject getTableConfig() {
    return (tableConfig == null ? tableConfig = new JSONObject() : tableConfig);
  }

  public JSONObject getColumnsConfig() {
    return columnsConfig;
  }

  /**
   * Gets a column group config JSON Object for the given column group index
   *
   * @param columnGroupIndex
   * @return
   */
  public JSONObject getColumnConfig(int columnGroupIndex) {
    try {
      JSONObject cc = getColumnsConfig();
      if (cc == null) {
        return null;
      }
      if (!cc.has("column_groups")) {
        return null;
      }
      if (columnGroupIndex < 0 || columnGroupIndex >= cc.getJSONArray("column_groups").length()) {
        return null;
      }
      return cc.getJSONArray("column_groups").getJSONObject(columnGroupIndex);
    } catch (Exception ex) {
    }
    return null;
  }

  /**
   * Gets a column group config JSON Object
   */
  public JSONObject getColumnGroupConfig(ColumnGroup columnGroup) {
    try {
      JSONObject cc = getColumnsConfig();
      if (cc == null) {
        return null;
      }
      if (!cc.has("column_groups")) {
        return null;
      }
      Column firstColumn = columnGroup.getColumn(0);
      List<JSONObject> jColumnGroupConfigs = cc.getJSONArray("column_groups").asList();
      for (JSONObject jColumnGroupConfig : jColumnGroupConfigs) {
        if (jColumnGroupConfig.has("column_configs")) {
          List<JSONObject> jColumnConfigs = jColumnGroupConfig.getJSONArray("column_configs").asList();
          for (JSONObject jColumnConfig : jColumnConfigs) {
            String dataIndex = jColumnConfig.getString("dataIndex");
            if (dataIndex.equalsIgnoreCase(firstColumn.getDataIndex())) {
              return jColumnGroupConfig;
            }
          }
        }
      }
    } catch (Exception ex) {
    }
    return null;
  }

  /**
   * Gets a column group config JSON Object
   *
   * @return
   */
  public String getColumnGroupConfig(ColumnGroup columnGroup, String key, String defaultValue) {
    try {
      JSONObject jColumnGroupConfig = getColumnGroupConfig(columnGroup);
      if (jColumnGroupConfig != null) {
        return jColumnGroupConfig.optString(key, defaultValue);
      }
    } catch (Exception ex) {
    }
    return defaultValue;
  }

  /**
   * Gets a column group config JSON Object by a member column's data index
   *
   * @param columnDataIndex
   * @return
   */
  public Number getColumnGroupConfig(ColumnGroup columnGroup, String key, double defaultValue) {
    try {
      JSONObject jColumnGroupConfig = getColumnGroupConfig(columnGroup);
      if (jColumnGroupConfig != null) {
        return jColumnGroupConfig.optDouble(key, defaultValue);
      }
    } catch (Exception ex) {
    }
    return defaultValue;
  }

  /**
   * Gets a column config JSON Object for the given data index
   *
   * @param columnDataIndex
   * @return
   */
  public JSONObject getColumnConfig(Column column) {
    try {
      JSONObject cc = getColumnsConfig();
      if (cc == null) {
        return null;
      }
      if (!cc.has("column_groups")) {
        return null;
      }
      List<JSONObject> jColumnGroupConfigs = cc.getJSONArray("column_groups").asList();
      for (JSONObject jColumnGroupConfig : jColumnGroupConfigs) {
        if (jColumnGroupConfig.has("column_configs")) {
          List<JSONObject> jColumnConfigs = jColumnGroupConfig.getJSONArray("column_configs").asList();
          for (JSONObject jColumnConfig : jColumnConfigs) {
            String dataIndex = jColumnConfig.getString("dataIndex");
            if (dataIndex.equalsIgnoreCase(column.getDataIndex())) {
              return jColumnConfig;
            }
          }
        }
      }
    } catch (Exception ex) {
    }
    return null;
  }

  /**
   * Gets an attribute value for the given column identified by its data index
   * for the attributes key.
   * If not available, this returns the default value
   *
   * @param columnDataIndex
   * @param key
   * @param defaultValue
   * @return
   */
  public String getColumnConfig(Column column, String key, String defaultValue) {
    try {
      JSONObject cc = getColumnConfig(column);
      if (cc == null) {
        return defaultValue;
      }
      return cc.optString(key, defaultValue);
    } catch (Exception ex) {
    }
    return defaultValue;
  }

  /**
   * Gets a numeric attribute value for the given column identified by its data
   * index for the attributes key
   * If not available or the attribute if non-numeric, this returns the default
   * value
   *
   * @param columnDataIndex
   * @param key
   * @param defaultValue
   * @return
   */
  public Number getColumnConfig(Column column, String key, double defaultValue) {
    try {
      JSONObject cc = getColumnConfig(column);
      if (cc == null) {
        return defaultValue;
      }
      return cc.optDouble(key, defaultValue);
    } catch (Exception ex) {
    }
    return defaultValue;
  }

  public JSONObject writeTableValuesJSON(Number start, Number pageSize, String sortColumnDataIndexes, String sortDirection, boolean caseSensitive, EntityTableCellFormatterIF defaultFormatter,
          Writer writer) throws IOException {
    JSONObject valuesJSON = getTableValuesJSON(start, pageSize, sortColumnDataIndexes, sortDirection, caseSensitive, defaultFormatter);
    if (valuesJSON != null) {
      try {
        valuesJSON.write(writer);
      } catch (JSONException ex) {
        ex.printStackTrace();
      }
      writer.flush();
    }
    return valuesJSON;
  }

  /**
   * Returns a page of table values, optionally setting the current sort and
   * pageSize
   *
   * @param start Number
   * @param pageSize Number
   * @param sortColumnDataIndexes String
   * @param sortDirection String
   * @param caseSensitive boolean
   * @return JSONObject
   */
  public JSONObject getTableValuesJSON(Number start, Number pageSize, String sortColumnDataIndexes, String sortDirection, boolean caseSensitive) {
    return getTableValuesJSON(start, pageSize, sortColumnDataIndexes, sortDirection, caseSensitive, null);
  }

  /**
   * Returns a page of table values, optionally setting the current sort and
   * pageSize
   *
   * @param start Number
   * @param pageSize Number
   * @param sortColumnDataIndexes String
   * @param sortDirection String
   * @param caseSensitive boolean
   * @param defaultFormatter EntityTableCellFormatterIF
   * @return JSONObject
   */
  public JSONObject getTableValuesJSON(Number start, Number pageSize, String sortColumnDataIndexes, String sortDirection, boolean caseSensitive, EntityTableCellFormatterIF defaultFormatter) {
    if (defaultFormatter == null) {
      defaultFormatter = new DefaultEntityTableCellFormatter();
    }
    if (this.currentFormatter == null) {
      currentFormatter = defaultFormatter;
    }
    List<Column> columns = getColumns();
    JSONObject valuesJSON = new JSONObject();
    try {
      String[] sortColumnDataIndices = (sortColumnDataIndexes == null ? null : sortColumnDataIndexes.split("\t"));
      String[] sortDirections = (sortDirection == null ? null : sortDirection.split("\t"));

      columnSort.checkSort(this, sortColumnDataIndices, sortDirections, caseSensitive);

      //Reset the PageSize if called
      if (pageSize != null && !Double.isNaN(pageSize.doubleValue()) && pageSize.doubleValue() > -1) {
        this.pageSize = pageSize.intValue();
      }

      JSONArray jFields = entityTableJSON.getJSONArray("fields");
      JSONArray jValues = new JSONArray();
      valuesJSON.put("values", jValues);
      valuesJSON.put("total", dataRows.size());

      int[] sort = columnSort.getSort();
      int rowStart = (start == null || Double.isNaN(start.doubleValue()) ? 0 : start.intValue());

      int rowIndex = rowStart;
      int rowCount = 0;

      do {
        int indx = (sort == null ? rowIndex : sort[rowIndex]);
        DataRow dataRow = dataRows.get(indx);
        if (columnFilter == null || columnFilter.match(this, dataRow)) {
          JSONObject jRowValues = dataRow.getJSON(jFields, currentFormatter, columns);
          jRowValues.put("entity_id", dataRow.getEntityID());
          jValues.put(jRowValues);
          rowCount++;
        }
        rowIndex++;
      } while (rowCount < this.pageSize && rowIndex < dataRows.size());
    } catch (JSONException e) {
      e.printStackTrace();
    }
    return valuesJSON;
  }

  /**
   * Returns a page of table values, optionally setting the current sort and
   * pageSize
   *
   * @param start Number
   * @param pageSize Number
   * @param sortColumnDataIndexes String
   * @param sortDirection String
   * @param caseSensitive boolean
   * @param defaultFormatter EntityTableCellFormatterIF
   * @return JSONObject
   */
  public JSONObject getColumnValuesJSON(EntityTableCellFormatterIF defaultFormatter, Column column) {
    if (defaultFormatter == null) {
      defaultFormatter = new DefaultEntityTableCellFormatter();
    }
    if (this.currentFormatter == null) {
      currentFormatter = defaultFormatter;
    }
    JSONObject valuesJSON = new JSONObject();
    try {
      JSONArray valuesJArr = new JSONArray();
      valuesJSON.put("values", valuesJArr);
      valuesJSON.put("total", dataRows.size());

      int[] sort = columnSort.getSort();
      int rowStart = 0;

      int rowIndex = rowStart;
      int rowCount = 0;

      do {
        int indx = (sort == null ? rowIndex : sort[rowIndex]);
        DataRow dataRow = dataRows.get(indx);

        if (columnFilter == null || columnFilter.match(this, dataRow)) {
          JSONObject jRowValues = new JSONObject();
          jRowValues.put("id", dataRow.getEntityID());
          jRowValues.put("label", (dataRow.getEntityLabel() == null ? dataRow.getEntityID() : dataRow.getEntityLabel()));
          jRowValues.put("value", dataRow.getDataCell(getColumnIndex(column)).getValue(currentFormatter, column));
          valuesJArr.put(jRowValues);
          rowCount++;
        }
        rowIndex++;
      } while (rowIndex < dataRows.size());
    } catch (JSONException e) {
      e.printStackTrace();
    }
    return valuesJSON;
  }

  /**
   * Returns all the DataRows in the EntityTable sorted and filtered using the
   * current filters and sorts
   *
   * @return List
   */
  public List<DataRow> getSortedAndFilteredDataRows() {
    List<Column> columns = getColumns();
    List<DataRow> sortedRows = new ArrayList<DataRow>();
    int[] sort = columnSort.getSort();
    int rowStart = 0;
    int rowIndex = rowStart;
    do {
      int indx = (sort == null ? rowIndex : sort[rowIndex]);
      DataRow dataRow = dataRows.get(indx);
      if (columnFilter == null || columnFilter.match(this, dataRow)) {
        sortedRows.add(dataRow);
      }
      rowIndex++;
    } while (rowIndex < dataRows.size());
    return sortedRows;
  }

  /**
   * Creates an XML Document from this model optionally including the DataRows
   * and DataCells
   *
   * @param includeData boolean
   * @return Document
   */
  public Document createDocument(boolean includeData) {
    Document entityTableDoc = new Document();
    Element entityTableEl = new Element("EntityTable");
    entityTableDoc.addContent(entityTableEl);
    ExtXMLElement.addAttribute(entityTableEl, "name", getTableName(true));
    ExtXMLElement.addAttribute(entityTableEl, "category", getEntityCategory().toString());
    for (ColumnGroup columnGroup : columnGroups) {
      Element columnGroupEl = ExtXMLElement.addElement(entityTableEl, "ColumnGroup");
      ExtXMLElement.addAttribute(columnGroupEl, "header", columnGroup.getHeaderText());
      for (Column column : columnGroup.getColumns()) {
        Element columnEl = ExtXMLElement.addElement(columnGroupEl, "Column");
        ExtXMLElement.addAttribute(columnEl, "header", column.getHeaderText());
        ExtXMLElement.addAttribute(columnEl, "type", (column.getDataType() == null ? EntityTableDataType.TEXT : column.getDataType()).toString());
        ExtXMLElement.addAttribute(columnEl, "format", (column.getColumnFormat() == null ? null : column.getColumnFormat().getJSON().toString()));
        ExtXMLElement.addAttribute(columnEl, "linkoutTemplate", column.getLinkoutTemplateURL());
        ExtXMLElement.addAttribute(columnEl, "SERVICE_DATA_TYPE_CATEGORY", (column.getServiceDataCategory() == null ? null : column.getServiceDataCategory() + ""));
        ExtXMLElement.addAttribute(columnEl, "SERVICE_DATA", column.getServiceData());
        ExtXMLElement.addAttribute(columnEl, "RELATED_SERVICE_KEY", column.getDrillDownServiceKey());
      }
    }
    if (includeData) {
      for (DataRow row : getDataRows()) {
        Element rowEl = ExtXMLElement.addElement(entityTableEl, "Row");
        ExtXMLElement.addAttribute(rowEl, "entity_id", row.getEntityID());
        ExtXMLElement.addTextElement(rowEl, "Description", row.getEntityDescription());

        for (DataCell cell : row.getDataCells()) {
          if (cell instanceof SubtableDataCell) {
            SubtableDataCell subtableDataCell = (SubtableDataCell) cell;
            Element cellEl = ExtXMLElement.addElement(rowEl, "TableCell");
            for (DataRow stRow : subtableDataCell.getRows()) {
              Element stRowEl = ExtXMLElement.addElement(cellEl, "Row");
              ExtXMLElement.addTextElement(stRowEl, "Description", stRow.getEntityDescription());
              for (DataCell stCell : stRow.getDataCells()) {
                ExtXMLElement.addElement(stRowEl, "Cell", stCell.getValue());
              }
            }
            ExtXMLElement.addAttribute(rowEl, "entity_id", row.getEntityID());
          } else {
            Element cellEl = ExtXMLElement.addElement(rowEl, "Cell", cell.getValue());
            ExtXMLElement.addAttribute(cellEl, "image_url", cell.getImageURL());
            if (cell.getLinkoutTokens() != null && cell.getLinkoutTokens().length > 0) {
              ExtXMLElement.addAttribute(cellEl, "linkoutTokens", ExtString.join(cell.getLinkoutTokens(), ','));
            }
          }
        }
      }
    }
    return entityTableDoc;

  }

  /**
   * Returns option set for the export
   *
   * @return Map
   */
  public Map<String, String> getExportOptions() {
    if (exportOptions == null) {
      exportOptions = new HashMap<String, String>();
    }
    return exportOptions;
  }

  public SavedObject getSavedObject() {
    return savedObject;
  }

  /**
   * Returns the DataRow given the index using the current sort
   *
   * @param rowIndex int
   * @return DataRow
   */
  public DataRow getSortedDataRow(int rowIndex) {
    try {
      int[] sort = columnSort.getSort();
      int sortedIndex = (sort == null ? rowIndex : sort[rowIndex]);
      return dataRows.get(sortedIndex);
    } catch (Exception e) {
    }
    return null;
  }

  /**
   * Returns the entity ID for the row index using the current sort
   *
   * @param rowIndex int
   * @return String
   */
  public String getEntityID(int rowIndex) {
    DataRow row = getSortedDataRow(rowIndex);
    if (row != null) {
      return row.getEntityID();
    }
    return null;
  }

  /**
   * setTableName
   *
   * @param tableName String
   */
  public void setTableName(String tableName) {
    this.tableName = tableName;
  }

  /**
   * Sets the row height in pixels. Note this only used to set picture heights.
   * Text-only rows are unaffected
   *
   * @param rowHeightPixels int
   */
  public void setRowHeightPixels(int rowHeightPixels) {
    if (this.rowHeightPixels == rowHeightPixels) {
      return;
    }
    this.rowHeightPixels = rowHeightPixels;
    for (DataRow row : dataRows) {
      int columnIndex = 0;
      for (DataCell cell : row.getDataCells()) {
        Column column = getColumn(columnIndex);
        if (cell.getImageURL() != null && rowHeightPixels > 0) {
          double height = cell.getImageHeight();
          double width = cell.getImageWidth();
          double ratio = (height == 0 || width == 0 ? 1 : width / height);
          cell.setImageHeight(this.rowHeightPixels);
          cell.setImageWidth((int) Math.round(((double) cell.getImageHeight() * ratio)));
          column.setWidth(cell.getImageWidth());
        }
        columnIndex++;
      }
    }
  }

  /**
   * setTableKey
   *
   * @param tableID String
   */
  public void setTableKey(String tableID) {
    this.tableKey = tableID;
  }

  /**
   * setDescription
   *
   * @param tableDescription String
   */
  public void setDescription(String tableDescription) {
    this.tableDescription = tableDescription;
  }

  /**
   * Set the row height using points as input. This does a conversion using
   * Arial 10pt as the point definition. If the input is NaN, the row height is
   * removed
   *
   * @param rowHeightPoints Number
   */
  public void setRowHeightPoints(Number rowHeightPoints) {
    if (Double.isNaN(rowHeightPoints.doubleValue()) || rowHeightPoints.doubleValue() == 0) {
      setRowHeightPixels(-1);
    } else {
      setRowHeightPixels((int) Math.ceil(Utilities.points2Pixels(rowHeightPoints.doubleValue(), false)));
    }
  }

  public void saveTable(OutputStream out) throws IOException {
    ObjectOutputStream objOut = new ObjectOutputStream(out);
    objOut.writeObject(this);
    objOut.close();
  }


  /*
   **********************************
   * EntityListIF Implementations *********************************
   */
  /**
   * Get name for the list
   *
   * @return String
   */
  public String getListName() {
    return getTableName(true);
  }

  /**
   * Get description for the list
   *
   * @return String
   */
  public String getListDescription() {
    return getDescription();
  }

  /**
   * Returns the members of the list
   *
   * @param delimiter String
   * @return String
   */
  public String getListMemberIds(String delimiter) {
    return GenericEntityListMember.concatenateMemberIDs(getListMembers(), delimiter);
  }

  /**
   * Returns the members of the list members IDs
   *
   * @return List
   */
  public List<String> getListMemberIds() {
    return GenericEntityListMember.getListMemberIds(getListMembers());
  }

  /**
   * Get value for list_category
   *
   * @return EntityListCategory
   */
  public EntityListCategory getEntityCategory() {
    return tableCategory;
  }

  /**
   * Returns the members of the list in the provided List
   *
   * @param memberList List
   * @return List
   */
  public List<EntityListMemberIF> getListMembers(List<EntityListMemberIF> memberList) {
    if (memberList == null) {
      memberList = new ArrayList<EntityListMemberIF>(dataRows.size());
    }
    switch (getEntityCategory()) {
      case PEOPLE:
      case PROJECTS:
        for (DataRow row : getDataRows()) {
          String label = row.getEntityID();
          if (row.getDataCells().size() > 0) {
            label = row.getDataCells().get(0).getValue();
          }
          memberList.add(new GenericEntityListMember(label, row.getEntityID(), row.getEntityDescription(), getEntityCategory()));
        }
        break;
      case AMGEN_GENES:
        for (DataRow row : getDataRows()) {
          DataCell symDataCell = row.getDataCell(0);
          DataCell nameDataCell = row.getDataCell(1);
          DataCell speciesDataCell = row.getDataCell(2);
          if (symDataCell != null && nameDataCell != null && speciesDataCell != null) {
            String species = (ExtString.hasLength(speciesDataCell.getValue()) ? " [" + speciesDataCell.getValue() + "]" : "");
            memberList.add(new GenericEntityListMember(symDataCell.getValue() + species, row.getEntityID(), nameDataCell.getValue(), getEntityCategory()));
          }
        }
        break;
      case OMICS_DATASETS:
        for (DataRow row : getDataRows()) {
          DataCell dataSetNameDataCell = row.getDataCell(0);
          memberList.add(new GenericEntityListMember(dataSetNameDataCell.getValue(), row.getEntityID(), row.getEntityDescription(), getEntityCategory()));          
        }
        break;        
      default:
        for (DataRow row : getDataRows()) {
          String label = row.getEntityID();
          if (row.getEntityLabel() != null) {
            label = row.getEntityLabel();
          } else if (row.getEntityLabelColNum() != null) {
            DataCell cell = row.getDataCell(row.getEntityLabelColNum());
            if (cell != null) {
              label = cell.getValue();
            }
          }
          memberList.add(new GenericEntityListMember(label, row.getEntityID(), row.getEntityDescription(), getEntityCategory()));
        }
        break;
    }
    return memberList;
  }

  /**
   * Returns the members of the list in a List
   *
   * @return List
   */
  public List<EntityListMemberIF> getListMembers() {
    return getListMembers(new ArrayList<EntityListMemberIF>());
  }

  /**
   * Returns the number of members in the provided List
   */
  public int getListMemberCount() {
    return getListMembers().size();
  }

  /**
   * Returns whether this list contains a member with this id
   *
   * @param memberID String
   * @return boolean
   */
  public boolean containsMember(EntityListMemberIF member) {
    if (member == null) {
      return false;
    }
    return dataRowMap.containsKey(member.getMember());
  }

  /**
   * Compares this EntityTable with another checking whether the list categories
   * and entity ids are the same.
   *
   * @param table EntityTable
   * @return boolean
   */
  public boolean compareTableMembers(EntityTable table) {
    if (!getEntityCategory().equals(table.getEntityCategory())) {
      return false;
    }
    if (table.dataRowMap.size() != this.dataRowMap.size()) {
      return false;
    }
    for (String memberID : table.dataRowMap.keySet()) {
      if (!dataRowMap.containsKey(memberID)) {
        return false;
      }
    }
    return true;
  }

  /**
   * Returns the service source of the list, if available
   *
   * @return EntityListSourceServiceIF
   */
  public EntityListSourceServiceIF getSourceService() {
    if (serviceResultCacheItem == null || serviceResultCacheItem.getServiceDetails() == null) {
      return null;
    }
    return new EntityListSourceServiceIF() {
      public String getServiceKey() {
        return serviceResultCacheItem.getServiceDetails().getKey();
      }

      public ServiceDetails getServiceDetails(ServiceCache serviceCache) {
        return serviceResultCacheItem.getServiceDetails();
      }
    };
  }

  public void setServiceResultCacheItem(ServiceResultCacheItem serviceResultCacheItem) {
    this.serviceResultCacheItem = serviceResultCacheItem;
  }

  public EntityTableProxy getAsProxy() {
    EntityTableProxy proxy = new EntityTableProxy(tableCategory);
    proxy.setColumnGroups(getColumnGroups());
    proxy.setDataRows(getDataRows());
    return proxy;
  }

  public byte[] getAsProxyBytes() throws IOException {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    ObjectOutputStream oop = new ObjectOutputStream(out);
    oop.writeObject(getAsProxy());
    oop.flush();
    oop.close();
    return out.toByteArray();
  }

  public Document getStructureDocument(AIGBase requestor) throws IOException {
    switch (getEntityCategory()) {
      default:
        throw new IOException("Only valid for Compound and Substance tables");
      case COMPOUNDS:
      case SUBSTANCES:
        if (structureDocument == null) {
          structureDocument = new SMStructureDocumentReader(requestor).getSerializedStructureDocumentFromEntityTable(this);
        }
        break;
    }
    try {
      InputStream is = new GZIPInputStream(new ByteArrayInputStream(structureDocument));
      ObjectInputStream oip = new ObjectInputStream(is);
      return (Document) oip.readObject();
    } catch (Exception e) {
    }
    return null;
  }

  public String toString() {
    StringBuffer sb = new StringBuffer();
    sb.append("Type: " + tableCategory + "\n");
    sb.append("ColumnGroups: " + columnGroups.size() + "\n");
    sb.append("Columns: " + getColumnCount() + "\n");
    sb.append("Rows: " + getDataRows().size() + "\n");

    return sb.toString();

  }

  /**
   * Overrides to the Serialization. Most are due to changes which require some
   * evolution or transients requiring initialization
   *
   * @return Object
   * @throws ObjectStreamException
   */
  public Object readResolve() throws ObjectStreamException {
    init();
    return this;
  }

  /**
   * Method called by readResolve for initializing any transient class variables
   * or evolving any class variable changes
   */
  private void init() {
    if (tableCategory == null && entityTableType != null) {
      tableCategory = EntityListCategory.fromString(entityTableType.toString());
    }
  }

  /**
   * setTableConfig
   *
   * @param tableConfigParam JSONObject
   */
  public void setTableConfig(JSONObject tableConfig) {
    this.tableConfig = tableConfig;
  }

  /**
   * setColumnsConfig
   *
   * @param columnsConfig JSONObject
   */
  public void setColumnsConfig(JSONObject columnsConfig) {
    if (columnsConfig != null) {
      this.columnsConfig = columnsConfig;
    }
  }

  public void setSavedObject(SavedObject savedObject) {
    this.savedObject = savedObject;
  }

  /**
   * Prepares any data needed in the EntityTable prior to saving. Returns true
   * if ready for saving, false otherwise
   *
   * @return boolean
   */
  public void prepareForSave() throws AIGException {
    boolean valid = true;
    for (DataRow row : getDataRows()) {
      if (!row.prepareForSave()) {
        valid = false;
      }
    }
    if (!valid) {
      throw new AIGException("Invalid table", AIGException.Reason.DATABASE_ERROR);
    }
  }

  /*
   * PreferenceableIF Implementations
   */
  /**
   * Returns the PreferenceGroup for this PreferenceableIF object
   *
   * @return String
   */
  public String getPreferenceGroup() {
    return "Table View";
  }

  /**
   * Sets a Preference in this PreferenceableIF object
   *
   * @param preference PreferenceIF
   */
  public void setPreference(PreferenceIF preference) {
    try {
      if (ExtString.alphaNumericsEqual(preference.getPreferenceName(), "Assay Result Format")) {
        getCurrentFormatter().setShowAssaySummary(ExtString.equalsIgnoreCase(preference.getPreferenceValue() + "", "VNT"));
      } else if (ExtString.alphaNumericsEqual(preference.getPreferenceName(), "Excel Export: Assay Result Format")) {
        getExportOptions().put("Assay Result Format", preference.getPreferenceValue() + "");
      } else if (ExtString.alphaNumericsEqual(preference.getPreferenceName(), "Excel Export: Include Chemical Structures")) {
        getExportOptions().put("Include Chemical Structures", preference.getPreferenceValue() + "");
      } else if (ExtString.alphaNumericsEqual(preference.getPreferenceName(), "Open Default Views")) {
        getTableConfig().put("enableDDLoading", ExtString.equalsIgnoreCase(preference.getPreferenceValue() + "", "Yes"));
      } else if (ExtString.alphaNumericsEqual(preference.getPreferenceName(), "Row Height")) {
        setRowHeightPoints(new Double(preference.getPreferenceValue() + ""));
      } else if (ExtString.alphaNumericsEqual(preference.getPreferenceName(), "Page Size")) {
        pageSize = new Integer(preference.getPreferenceValue() + "");
      }
      getEntityTableJSON(true);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Returns the ObjectType of the Saveable object
   *
   * @return ObjectType
   */
  public int getObjectType() {
    return ObjectType.ENTITYTABLE;
  }

  /**
   * Returns the Saveable object as a byte array
   *
   * @return byte[]
   */
  public byte[] getObjectBytes() throws SaveObjectException {
    try {
      return ExtObject.serializeObject(this);
    } catch (Exception e) {
      throw new SaveObjectException("Unable to serialize table", AIGException.Reason.REQUEST_ERROR, e);
    }
  }

  /**
   * moveRowTop
   *
   * @param row DataRow
   */
  public void moveRowTop(DataRow row) {
    int rowIndex = getDataRowIndex(row);
    if (rowIndex < 0) {
      return;
    }
    columnSort.setRowPosition(this, rowIndex, true);
  }

  /**
   * moveRowTop
   *
   * @param row DataRow
   */
  public void moveRowBottom(DataRow row) {
    int rowIndex = getDataRowIndex(row);
    columnSort.setRowPosition(this, rowIndex, false);
  }
}

class RowNumbererColumn extends Column {
  RowNumbererColumn() {
    super("");
  }
}

/**
 * Hold information related to deleting a column or group. This includes the
 * column's data index (used to find the delete column or group) column group
 * column column position- 0-index position in the table of the column column
 * group position- 0-index position of the first column of the group in the
 * table whether the column group contains a sort-by column whether the column
 * is a sort-by column
 *
 * The DeleteColumnGroup is created by a static so everything gets set correctly
 * from the table
 *
 */
class DeleteColumnGroup {
  public String columnDataIndex;
  public ColumnGroup columnGroup;
  public Column column;
  public int columnPosition;
  public int columnGroupPosition;
  public boolean columnGroupContainsSortColumn;
  public boolean columnIsSortColumn;

  /**
   * Private constructor used by the createDeleteColumnGroupByDataIndex method
   *
   * @param columnGroup ColumnGroup
   * @param column Column
   * @param columnPosition int
   */
  private DeleteColumnGroup(ColumnGroup columnGroup, Column column, int columnPosition) {
    this.columnGroup = columnGroup;
    this.column = column;
    this.columnPosition = columnPosition;
  }

  /**
   * Private method for setting the column group start used by the
   * createDeleteColumnGroupByDataIndex method
   *
   * @param entityTable EntityTable
   */
  private void setColumnGroupStart(EntityTable entityTable) {
    int startColumnGroupPosition = -1;
    if (this.columnGroup != null) {
      for (ColumnGroup columnGroup : entityTable.getColumnGroups()) {
        for (Column column : columnGroup.getColumns()) {
          startColumnGroupPosition++;
          if (columnGroup == this.columnGroup) {
            this.columnGroupPosition = startColumnGroupPosition;
            return;
          }
        }
      }
    }
  }

  /**
   * Used to debug
   *
   * @return String
   */
  public String toString() {
    StringBuffer sb = new StringBuffer("DeleteColumnGroup>>");
    sb.append("columnDataIndex" + "= " + columnDataIndex + "\n");
    sb.append("columnGroup" + "= " + columnGroup.getHeaderText() + "\n");
    sb.append("column" + "= " + column.getHeaderText() + "\n");
    sb.append("columnPosition" + "= " + columnPosition + "\n");
    sb.append("columnGroupPosition" + "= " + columnGroupPosition + "\n");
    sb.append("columnGroupContainsSortColumn" + "= " + columnGroupContainsSortColumn + "\n");
    sb.append("columnIsSortColumn" + "= " + columnIsSortColumn + "\n");
    sb.append("<<DeleteColumnGroup\n");

    return sb.toString();
  }

  /**
   * Creates a DeleteColumnGroup using a column data index to find th columns,
   * groups, positions, and sort dependencies in the table
   *
   * @param entityTable EntityTable
   * @param columnDataIndex String
   * @return DeleteColumnGroup
   */
  static DeleteColumnGroup createDeleteColumnGroupByDataIndex(EntityTable entityTable, String columnDataIndex) {
    int columnGroupIndex = -1;
    int position = -1;
    for (ColumnGroup columnGroup : entityTable.getColumnGroups()) {
      columnGroupIndex++;
      for (Column column : columnGroup.getColumns()) {
        position++;
        //Found the member column for the column group
        if (column.getDataIndex().equals(columnDataIndex)) {
          //Set the DeleteColumnGroup
          DeleteColumnGroup deleteColumnGroup = new DeleteColumnGroup(columnGroup, column, position);
          //Set the data index
          deleteColumnGroup.columnDataIndex = columnDataIndex;
          //Set whether the group contains the sort column
          deleteColumnGroup.columnGroupContainsSortColumn = false;
          for (Column memberColumn : columnGroup.getColumns()) {
            if (entityTable.getColumnSort().containColumnAsComparator(memberColumn.getDataIndex())) {
              deleteColumnGroup.columnGroupContainsSortColumn = true;
              break;
            }
          }
          deleteColumnGroup.columnIsSortColumn = entityTable.getColumnSort().containColumnAsComparator(column.getDataIndex());
          //Set the column start
          deleteColumnGroup.setColumnGroupStart(entityTable);
          return deleteColumnGroup;
        }
      }
    }
    return null;
  }
}
