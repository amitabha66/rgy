package amgen.ri.aig.entitytable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Defines a service parameter bound to a DataCell which is used to define a
 * value to a drill-down service.
 * Parameters can be bound by parameter name, but the recommended method is to
 * provide a UDDI-published classification scheme keyValue which will be used to
 * dynamically bind to parameter and value at runtime.
 *
 * @version $Id: CellServiceParameter.java,v 1.1 2011/06/17 20:41:19 cvs Exp $
 */
public class CellServiceParameter implements Serializable {
    static final long serialVersionUID = -3338317991221608980L;
    private String parameterName;
    private Object parameterValue;
    private Map<String, List<String>> parameterCategorizations;

    /**
     * Creates a CellServiceParameter with parameter name and value. This is not
     * the recommended method for parameter binding.
     *
     * @param parameterName String
     * @param parameterValue Object
     */
    public CellServiceParameter(String parameterName, Object parameterValue) {
        this.parameterName = parameterName;
        this.parameterValue = parameterValue;
        this.parameterCategorizations = new HashMap<String, List<String>>();
    }

    /**
     * Creates a CellServiceParameter with its registered classification scheme
     * name and key value.
     *
     * @param classificationScheme String
     * @param keyValue String
     * @param parameterValue Object
     */
    public CellServiceParameter(String classificationScheme, String keyValue, Object parameterValue) {
        this(null, parameterValue);
        this.parameterCategorizations.put(classificationScheme, new ArrayList<String>());
        this.parameterCategorizations.get(classificationScheme).add(keyValue);
    }

    /**
     * Sets the parameter value
     *
     * @param parameterValue Object
     */
    public void setParameterValue(Object parameterValue) {
        this.parameterValue = parameterValue;
    }

    /**
     * Sets the parameter name to bind the value- this is not recommended. This
     * is usually null.
     *
     * @param parameterName String
     */
    public void setParameterName(String parameterName) {
        this.parameterName = parameterName;
    }

    /**
     * Returns the parameter value
     *
     * @return Object
     */
    public Object getParameterValue() {
        return parameterValue;
    }

    /**
     * Returns the parameter name- generally null as the parameter value is
     * usually bound by classification scheme.
     *
     * @return String
     */
    public String getParameterName() {
        return parameterName;
    }

    /**
     * Adds a classification scheme keyValue to the classification scheme
     * keyValues
     *
     * @param classificationScheme String
     * @param keyValue String
     */
    public void addClassificationSchemeKeyValue(String classificationScheme, String keyValue) {
        if (!parameterCategorizations.containsKey(classificationScheme)) {
            this.parameterCategorizations.put(classificationScheme, new ArrayList<String>());
        }
        this.parameterCategorizations.get(classificationScheme).add(keyValue);
    }

    /**
     * Returns all categorization scheme keyValues for a classification scheme
     *
     * @param classificationScheme String
     * @return List
     */
    public List<String> getParameterCategorizations(String classificationScheme) {
        return parameterCategorizations.get(classificationScheme);
    }

    /**
     * Returns all classification scheme names
     *
     * @return Set
     */
    public Set<String> getParameterClassificationSchemeNames() {
        return parameterCategorizations.keySet();
    }
}
