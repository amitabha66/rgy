package amgen.ri.aig.favorites;

import amgen.ri.aig.AIGBase;
import amgen.ri.json.JSONObject;
import amgen.ri.security.IdentityIF;
import java.util.Date;

/**
 * <p>@version $Id: FavoriteFolderItemIF.java,v 1.4 2012/06/04 23:02:04 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public interface FavoriteFolderItemIF {
    public String getDescription();

    public String getName();

    public Date getCreated();

    public String getOwnedBy();

    public String getCreatedBy();

    public boolean isValid(AIGBase requestor);

    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier();

    /** Gets the created_by as a AmgenEnterpriseEntry */
    public Person getCreatedByPerson();

    /** Set value for parent_folder_id */
    public void setParentFolder(FavoriteFolder parentFolder);
    /** Returns the child level of this FavoriteFolderItemIF in the given parent folder
     * 0  - This FavoriteFolderItemIF is not in the parentFolder hierarchy
     * 1  - This FavoriteFolderItemIF is the same object as parentFolder
     * 2  - This FavoriteFolderItemIF is an immediate child of parentFolder
     * >3 - This FavoriteFolderItemIF is a deeper child in the parentFolder hierarchy
     */
    public int getChildLevelOf(FavoriteFolder parentFolder);

    public boolean setData();
    public int performCommit();

  JSONObject asJSON(IdentityIF identity);
}
