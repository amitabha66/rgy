package amgen.ri.aig.sobj;

import amgen.ri.aig.AIGException;

/**
 * <p>@version $Id: SaveObjectException.java,v 1.2 2011/06/21 17:28:58 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class SaveObjectException extends AIGException {
    public SaveObjectException(String message, Reason reason) {
        super(message, reason);
    }

    public SaveObjectException(Reason reason, Throwable cause) {
        super(reason, cause);
    }

    public SaveObjectException(String message, Reason reason, Throwable cause) {
        super(message, reason, cause);
    }
}
