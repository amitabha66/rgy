package amgen.ri.aig.scripts;

import org.jdom.Document;

import amgen.ri.json.JSONObject;

public interface CalculationMethodsIF {
    /**
     * Returns a JSOObject which displays the available methods. The format to the JSONObject is
     * {
     *   methods: [{
     *     method_name: "internal name of the method",
     *     method_label: "Label to display for the method",
     *     method_description: "Description for the method",
     *     method_help: "Help text for the method",
     *     method_parmeter_list: "Parameter list for the method",
     *     method_group: "Method group"
     *   },...]
     * }
     *
     * @return JSONObject
     */
    public JSONObject getMethodsAsJSON();

    public Document getMethodDocument();

}
