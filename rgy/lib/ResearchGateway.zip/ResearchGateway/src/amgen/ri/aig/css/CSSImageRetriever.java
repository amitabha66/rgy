/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.css;

import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.jawr.FileSetManager;
import amgen.ri.util.ExtString;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.net.URL;
import java.util.List;

import org.w3c.css.sac.InputSource;
import org.w3c.dom.css.CSSRule;
import org.w3c.dom.css.CSSRuleList;
import org.w3c.dom.css.CSSStyleDeclaration;
import org.w3c.dom.css.CSSStyleRule;
import org.w3c.dom.css.CSSStyleSheet;
import com.steadystate.css.dom.CSSStyleRuleImpl;
import com.steadystate.css.parser.CSSOMParser;
import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import javax.servlet.ServletContext;

/**
 *
 * @author jemcdowe
 */
public class CSSImageRetriever {
  private static CSSImageRetriever instance;
  private Map<String, URL> cssIconMap;
  private Map<String, Set<String>> cssSelectorMap;
  /**
   * Regular expression to find the URI of images in
   * <code>background-image</code> CSS properties.
   */
  private static final Pattern backgroundImagePattern = Pattern.compile(
          "background-image\\s*:(.)*url\\((\\s)*([\"\']*)([^\"\'\\)]+)([\"\']*)(\\s)*\\)",
          Pattern.CASE_INSENSITIVE);
  /**
   * Regular expression to find the URI of images in
   * <code>background</code> CSS properties.
   */
  private static final Pattern backgroundPattern = Pattern.compile(
          "background\\s*:(.)*url\\((\\s)*([\"\']*)([^\"\']+)([\"\'\\)]*)(\\s)*\\)",
          Pattern.CASE_INSENSITIVE);

  private CSSImageRetriever(ServletContext context) throws IOException {
    File cssDir = new File(context.getRealPath("css"));
    File[] cssFiles = cssDir.listFiles(new FilenameFilter() {
      public boolean accept(File dir, String name) {
        return name.endsWith(".css");
      }
    });
    loadBackgroundImagesFromCSS(context, cssFiles);
    FileSetManager fm= new FileSetManager();
    addBackgroundImagesFromCSS(context, fm.getStyles(context, "ixcss"));
  }

  public CSSImageRetriever(File[] cssFiles) throws IOException {
    loadBackgroundImagesFromCSS(null, cssFiles);
  }

  public static CSSImageRetriever init(ServletContext context) throws IOException {
    if (instance == null) {
      instance = new CSSImageRetriever(context);
    }
    return instance;
  }

  public static CSSImageRetriever getInstance() {
    if (instance == null) {
      throw new IllegalArgumentException("CSSImageRetriever Not Initialized");
    }
    return instance;
  }

  public Set<String> getSelectors(String cssFile) {
    return (cssSelectorMap.containsKey(cssFile) ? cssSelectorMap.get(cssFile) : new HashSet<String>());
  }
   // @fixme EntityClassManager

  public URL getBackgroundImageForType(EntityListCategory category) {
    String pluralRule = new EntityClassManager().getEntityClass(category).getPluralStyle();
    return getBackgroundImageforRule(pluralRule);
  }

  public URL getBackgroundImageforRule(String cssRule) {
    return cssIconMap.get(cssRule);
  }

  public BufferedImage getImageForRule(String cssRule) {
    try {
      return ImageIO.read(getBackgroundImageforRule(cssRule));
    } catch (Exception e) {
    }
    return null;
  }

  private void loadBackgroundImagesFromCSS(ServletContext context, File[] cssFiles) throws IOException {
    cssIconMap = new HashMap<String, URL>();
    cssSelectorMap = new HashMap<String, Set<String>>();
    for (File cssFile : cssFiles) {
      InputSource source = new InputSource(new InputStreamReader(new FileInputStream(cssFile)));
      CSSOMParser parser = new CSSOMParser();
      CSSStyleSheet stylesheet = parser.parseStyleSheet(source, null, null);
      CSSRuleList ruleList = stylesheet.getCssRules();

      for (int i = 0; i < ruleList.getLength(); i++) {
        CSSRule rule = ruleList.item(i);
        if (rule instanceof CSSStyleRule) {
          CSSStyleRuleImpl styleRule = (CSSStyleRuleImpl) rule;
          for (int j = 0; j < styleRule.getSelectors().getLength(); j++) {
            String selector = styleRule.getSelectors().item(j).toString().replaceFirst("^\\*\\.", "");
            if (ExtString.hasLength(selector)) {
              CSSStyleDeclaration styleDeclaration = styleRule.getStyle();
              String imgFileName = null;

              Matcher matcher = backgroundPattern.matcher(styleDeclaration.getCssText());
              if (matcher.lookingAt()) {
                imgFileName = matcher.group(4);
              }
              matcher = backgroundImagePattern.matcher(styleDeclaration.getCssText());
              if (matcher.lookingAt()) {
                imgFileName = matcher.group(4);
              }
              if (imgFileName != null) {
                URL url = getResourceURL(context, imgFileName, cssFile.toURI().toURL());
                if (url != null) {
                  cssIconMap.put(selector, url);
                  if (!cssSelectorMap.containsKey(cssFile.getName())) {
                    cssSelectorMap.put(cssFile.getName(), new LinkedHashSet<String>());
                  }
                  cssSelectorMap.get(cssFile.getName()).add(selector);
                }
              }
            }
          }
        }
      }
    }
  }
  

  private void addBackgroundImagesFromCSS(ServletContext context, List<URL> cssFiles) throws IOException {    
    for (URL cssFile : cssFiles) {
      InputSource source = new InputSource(new InputStreamReader(cssFile.openStream()));
      CSSOMParser parser = new CSSOMParser();
      CSSStyleSheet stylesheet = parser.parseStyleSheet(source, null, null);
      CSSRuleList ruleList = stylesheet.getCssRules();

      for (int i = 0; i < ruleList.getLength(); i++) {
        CSSRule rule = ruleList.item(i);
        if (rule instanceof CSSStyleRule) {
          CSSStyleRuleImpl styleRule = (CSSStyleRuleImpl) rule;
          for (int j = 0; j < styleRule.getSelectors().getLength(); j++) {
            String selector = styleRule.getSelectors().item(j).toString().replaceFirst("^\\*\\.", "");
            if (ExtString.hasLength(selector)) {
              CSSStyleDeclaration styleDeclaration = styleRule.getStyle();
              String imgFileName = null;

              Matcher matcher = backgroundPattern.matcher(styleDeclaration.getCssText());
              if (matcher.lookingAt()) {
                imgFileName = matcher.group(4);
              }
              matcher = backgroundImagePattern.matcher(styleDeclaration.getCssText());
              if (matcher.lookingAt()) {
                imgFileName = matcher.group(4);
              }
              if (imgFileName != null) {
                URL url = getResourceURL(context, imgFileName, cssFile);
                if (url != null) {
                  cssIconMap.put(selector, url);
                  if (!cssSelectorMap.containsKey(cssFile.getFile())) {
                    cssSelectorMap.put(cssFile.getFile(), new LinkedHashSet<String>());
                  }
                  cssSelectorMap.get(cssFile.getFile()).add(selector);
                }
              }
            }
          }
        }
      }
    }
  }  

  /**
   * Returns the URL to a resource. 
   * This checks if it is 
   * 1. An HTTP resource,
   * 2. A local resource which has the context path prepended already
   * 3. A local resource without the context path prepended
   * 4. A local resource with a relative path- which is optionally relative to the parentFile
   * 
   * @param resourceFileName
   * @param parentFile
   * @return
   * @throws IOException 
   */
  private URL getResourceURL(ServletContext context, String resourceFileName, URL parentFile) throws IOException {
    if (resourceFileName != null) {
      if (resourceFileName.startsWith("http")) { //An http resource
        return new URL(resourceFileName);
      } else if (resourceFileName.startsWith("/aig/")) { //A local resource with the context path included (remove first)
        resourceFileName = resourceFileName.replaceFirst("/aig/", "");
        File resourceFile = new File(context.getRealPath(resourceFileName));
        return resourceFile.toURI().toURL();
      } else if (resourceFileName.startsWith("/")) { //A local resource with a full path- create the real path
        File resourceFile = new File(context.getRealPath(resourceFileName));
        return resourceFile.toURI().toURL();
      } else { // A local resource with path relative to the CSS
        if (parentFile == null) {
          File resourceFile = new File(context.getRealPath(resourceFileName));
          return resourceFile.toURI().toURL();
        } else {
          URL url = new URL(parentFile.getProtocol(), parentFile.getHost(), parentFile.getPort(),
                  new File(parentFile.getPath()).getParentFile() + "/" + resourceFileName);
          return url;
        }
      }
    }
    return null;
  }
}
