package amgen.ri.aig.uddi;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.tree.NodeType;
import amgen.ri.aig.cache.service.ServiceCacheResponse;
import amgen.ri.aig.cache.tree.TreeNodeCache;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.asf.sa.uddi.ClassificationSchemeQuery;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.io.IOException;
import java.util.List;
import java.util.UUID;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.output.XMLOutputter;

/**
 * Performs a lookup in the UDDI or cache for the service nodes for a data type
 */
public class EntityNodeServiceLookup extends AbstractServiceLookup {

  /**
   * Default constructor
   */
  public EntityNodeServiceLookup() {
    super();
  }

  /**
   * Main constructor- used only by the getAIGServlet method
   *
   * @param request HttpServletRequest
   * @param response HttpServletResponse
   */
  public EntityNodeServiceLookup(HttpServletRequest request, HttpServletResponse response) {
    super(request, response);
  }

  /**
   * Creates this AIG Servlet object
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return AIGServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new EntityNodeServiceLookup(req, resp);
  }

  /**
   * Perform request stub
   *
   * @throws ServletException
   * @throws IOException
   */
  public void performRequest() throws ServletException, IOException, AIGException {
    String entityType = getParameter("datatype");
    String entityServiceData = getParameter("data");
    String entityNodeUUID = getParameter("uuid");
    Element entityTreeNodes = getTreeNodeServices(entityType, entityServiceData, entityNodeUUID);
    new XMLOutputter().output(entityTreeNodes, response.getWriter());
  }

  /**
   * Performs the lookup in the UDDI or cache and creates the TREENODES elements
   * for the view
   *
   * @param entityType String
   * @param entityServiceData String
   * @param parentNodeUUID String
   * @return Element
   */
  public Element getTreeNodeServices(String entityType, String entityServiceData, String entityNodeUUID) throws AIGException {
    Element entityTreeNodes = new Element("TREENODES");
    TreeNodeCache treeNodeCache = TreeNodeCache.getTreeNodeCache(request);

    try {
      String parentServiceKey = treeNodeCache.getEntityNodeParentServiceKey(entityNodeUUID);
      ClassificationSchemeQuery classificationSchemeQuery = new ClassificationSchemeQuery();
      classificationSchemeQuery.addFindQualifier(ClassificationSchemeQuery.SORT_BY_NAME_ASC);
      classificationSchemeQuery.addKeyValue(TModelCommonNameFactory.SERVICE_INPUT_CATEGORIZATION_SCHEME, ServiceDataCategory.revertTo(entityType));
      ServiceQuery serviceQuery = new ServiceQuery(classificationSchemeQuery, TModelCommonNameFactory.TREENODESXMLDEFINITION_tMODELNAME);
      ServiceCacheResponse entityServices = findAndSortServices(serviceQuery);

      for (ServiceDetails entityService : entityServices) {
        if (entityService.containsUserInAllowedUsers(getSessionLogin().getRemoteUser(), true)) {
          ServiceAttributes serviceAttributes = new ServiceAttributes(entityService, getEntityClassManager());
          if (parentServiceKey == null || !entityService.getKey().equals(parentServiceKey) || serviceAttributes.allowRecursion()) {
            String nodeUUID = UUID.randomUUID() + "";
            Element entityServiceTreeNode = new Element("TREENODE");
            entityServiceTreeNode.setAttribute("IMAGE", "service");
            ExtXMLElement.addAttribute(entityServiceTreeNode, "TEXT", serviceAttributes.getName(ServiceNamingContext.RG_NODE));
            ExtXMLElement.addAttribute(entityServiceTreeNode, "TITLE", serviceAttributes.getDescription(ServiceNamingContext.RG_NODE));
            entityServiceTreeNode.setAttribute("EXPANDED", "false");
            entityServiceTreeNode.setAttribute("SERVICEKEY", entityService.getKey());
            entityServiceTreeNode.setAttribute("NODE_TYPE", NodeType.SERVICENODE + "");
            entityServiceTreeNode.setAttribute("UUID", nodeUUID);
            entityServiceTreeNode.setAttribute("PARENTUUID", entityNodeUUID);
            StringBuffer treeNodeSrc = new StringBuffer(request.getContextPath() + "/executeentitynodeservice.go?key=" + entityService.getKey() + "&data="
                    + ExtString.escape(entityServiceData) + "&datatype="
                    + entityType + "&uuid=" + nodeUUID);
            entityServiceTreeNode.setAttribute("TREENODESRC", treeNodeSrc.toString());
            entityTreeNodes.addContent(entityServiceTreeNode);
            treeNodeCache.addTreeNode(entityServiceTreeNode);
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return entityTreeNodes;
  }

  /**
   * Returns the mimetype of the servlet
   */
  protected String getServletMimeType() {
    return "text/xml";
  }

  @Override
  public Document getServicesDocument() throws JDOMException, AIGException {
    throw new UnsupportedOperationException("Not supported yet.");
  }
}
