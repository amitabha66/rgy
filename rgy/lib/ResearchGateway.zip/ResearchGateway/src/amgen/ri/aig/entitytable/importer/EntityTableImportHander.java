package amgen.ri.aig.entitytable.importer;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.item.EntityTableCacheItem;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;
import amgen.ri.aig.entitytable.loader.EntityLoaderFactory;
import amgen.ri.aig.entitytable.loader.EntityTableLoaderIF;
import amgen.ri.aig.sv.EntityListLoader;
import amgen.ri.excel.ExcelUtils;
import amgen.ri.excel.GroupHeader;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtString;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.poi.POIXMLProperties;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jdom.Document;

/**
 * <p>@version $Id: EntityTableImportHander.java,v 1.7 2014/07/08 15:51:48 jemcdowe Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class EntityTableImportHander extends AIGServlet {

    private enum EntityTableImportHanderRequest {
        PROCESS_DATA_FILE, IMPORT_DATA_FILE, IMPORT_TYPES, UNKNOWN
    }


    private EntityTableImportHanderRequest entityTableImportHanderRequest;
    private EntityListCategory importEntityType;
    private ServiceDataCategory importServiceDataCategory;


    public EntityTableImportHander() {
        super();
    }

    public EntityTableImportHander(HttpServletRequest req, HttpServletResponse resp) {
        super(req, resp);
        try {
            entityTableImportHanderRequest = EntityTableImportHanderRequest.valueOf(getParameter("op"));
        } catch (Exception e) {
            entityTableImportHanderRequest = EntityTableImportHanderRequest.UNKNOWN;
        }
        importEntityType = EntityListCategory.fromString(getParameter("type"));
        importServiceDataCategory = getEntityClassManager().convertEntityListCategoryToServiceDataCategory(importEntityType);
    }

    /**
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return TBXServlet
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new EntityTableImportHander(req, resp);
    }

    /**
     *
     * @return String
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected String getServletMimeType() {
        return (isIsMultiPartRequest() ? "text/html" : "text/json");
    }

    /**
     *
     * @throws Exception
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected void performRequest() throws Exception {
        try {
            switch (entityTableImportHanderRequest) {
                case PROCESS_DATA_FILE:
                    processDataFile();
                    break;
                case IMPORT_DATA_FILE:
                    importDataFile();
                    break;
                case IMPORT_TYPES:
                    getImportTypes();
                default:
            }
        } catch (Exception e) {
            e.printStackTrace();
            sendExceptionResponse(e);
        }
    }

    /**
     * getImportTypes
     */
    private void getImportTypes() throws JSONException, IOException {
        JSONObject jImportTypes = new JSONObject();

        JSONObject jImportType = new JSONObject();
        jImportType.put("import_type", "Compounds");
        jImportTypes.append("importTypes", jImportType);

        jImportType = new JSONObject();
        jImportType.put("import_type", "Substances");
        jImportTypes.append("importTypes", jImportType);

        jImportType = new JSONObject();
        jImportType.put("import_type", "Assays");
        jImportTypes.append("importTypes", jImportType);

        jImportType = new JSONObject();
        jImportType.put("import_type", "People");
        jImportTypes.append("importTypes", jImportType);

        writeResponse(null, jImportTypes);
    }

    private EntityListCategory getTypeFromWorkbookType(Workbook wb) {
        if (wb == null) {
            return EntityListCategory.UNKNOWN;
        }
        try {
            String category = null;
            if (wb instanceof XSSFWorkbook) {
                POIXMLProperties xlProperties = ((XSSFWorkbook) wb).getProperties();
                POIXMLProperties.CoreProperties xlCoreProperties = xlProperties.getCoreProperties();
                category = xlCoreProperties.getCategory();
            } else if (wb instanceof HSSFWorkbook) {
                category = ((HSSFWorkbook) wb).getDocumentSummaryInformation().getCategory();
            }
            if (category != null && category.startsWith("RGTableExport:")) {
                String[] categoryFlds = category.split(":");
                if (categoryFlds.length == 2) {
                    return EntityListCategory.fromString(categoryFlds[1]);
                }
            }
        } catch (Exception e) {
        }
        return EntityListCategory.UNKNOWN;
    }


    /**
     * processDataFile
     */
    private void processDataFile() throws JSONException, IOException, AIGException {
        Workbook wb = getWorkbookFromRequest("import_data_file");
        EntityListCategory importRGTableType = getTypeFromWorkbookType(wb);
        if (!importRGTableType.equals(EntityListCategory.UNKNOWN)) {
            throw new AIGException("Research Gateway does not yet import exported tables.", Reason.INVALID_REQUEST);
        }

        JSONObject jColumns = new JSONObject();
        JSONArray jTypes = new JSONArray();

        JSONArray jType = new JSONArray();
        jType.put("Text");
        jTypes.put(jType);

        jType = new JSONArray();
        jType.put("Double");
        jTypes.put(jType);

        jType = new JSONArray();
        jType.put("Integer");
        jTypes.put(jType);

        jType = new JSONArray();
        jType.put("Date");
        jTypes.put(jType);

        jType = new JSONArray();
        jType.put("Do Not Import");
        jTypes.put(jType);

        jType = new JSONArray();
        jTypes.put(jType);

        if (!importRGTableType.equals(EntityListCategory.UNKNOWN)) {
            importServiceDataCategory = getEntityClassManager().convertEntityListCategoryToServiceDataCategory(importRGTableType);
        } else {
            switch (importServiceDataCategory) {
                case AMGEN_ROOT_ID:
                case AMGEN_NAME:
                case AMGEN_LOGIN:
                case ASSAY_IDENTIFIER:
                    jType.put(ServiceDataCategory.revertTo(importServiceDataCategory));
                    break;
                default:
                    throw new AIGException("Type is not importable", Reason.INVALID_REQUEST);
            }
        }
        jColumns.put("import_table_type", (importRGTableType.equals(EntityListCategory.UNKNOWN) ? importEntityType : EntityListCategory.revertTo(importRGTableType)));
        jColumns.put("import_service_data_type", ServiceDataCategory.revertTo(importServiceDataCategory));

        if (wb != null) {
            Sheet sheet = wb.getSheetAt(0);
            List<String> columnNames;
            Row firstDataRow;
            List<Integer> rowTypes;

            //Not an RG import Worksheet
            if (importRGTableType.equals(EntityListCategory.UNKNOWN)) {
                firstDataRow = sheet.getRow(1);
                columnNames = ExcelUtils.getColumnHeaders(sheet);
            } else {
                List<GroupHeader> groupedHeaders = ExcelUtils.getGroupedColumnHeaders(sheet);
                firstDataRow = sheet.getRow(2);
                columnNames = new ArrayList<String>();
                for (GroupHeader groupedHeader : groupedHeaders) {
                    for (GroupHeader child : groupedHeader.getChildren()) {
                        columnNames.add(groupedHeader.getHeader() + "/" + child.getHeader());
                    }
                }
            }
            rowTypes = ExcelUtils.getRowCellTypes(firstDataRow);
            for (int i = 0; i < columnNames.size(); i++) {
                String columnName = columnNames.get(i);
                String expData = ExcelUtils.getCellStringValue(firstDataRow, i);
                JSONObject jColumn = new JSONObject();
                jColumn.put("name", columnName);
                jColumns.append("columns", jColumn);
                jColumn.put("types", jTypes);
                if (i == 0) {
                    jColumn.put("type", ServiceDataCategory.revertTo(importServiceDataCategory));
                } else if (!ExtString.hasLength(expData)) {
                    jColumn.put("type", "Do Not Import");
                } else {
                    int colType = -1;
                    if (firstDataRow != null) {
                        colType = rowTypes.get(i);
                    }
                    switch (colType) {
                        case Cell.CELL_TYPE_NUMERIC:
                            Cell cell = firstDataRow.getCell(i);
                            String type = "Double";
                            try {
                                if (cell.getCellStyle().getDataFormatString().equals("0")) {
                                    type = "Integer";
                                }
                            } catch (Exception e) {}
                            jColumn.put("type", type);
                            break;
                        default:
                            jColumn.put("type", "Text");
                            break;
                    }
                }
            }
        }
        writeResponse(null, jColumns);
    }

    /**
     * processDataFile
     */
    private void importDataFile() throws AIGException {
        try {
            Map<Integer, EntityTableDataType> columnTypes = new HashMap<Integer, EntityTableDataType>();
            int serviceDataCategoryColNum = -1;
            JSONArray colTypeMap = getJSONArrayParameter("typeMap");
            if (colTypeMap != null) {
                for (int i = 0; i < colTypeMap.length(); i++) {
                    String type = colTypeMap.optString(i, "Text");
                    if (ServiceDataCategory.fromString(type).equals(importServiceDataCategory)) {
                        serviceDataCategoryColNum = i;
                    } else if (ExtString.equals(type, "Do Not Import")) {
                        columnTypes.put(i, EntityTableDataType.UNSPECIFIED);
                    } else {
                        EntityTableDataType dataType = EntityTableDataType.fromString(type);
                        switch (dataType) {
                            case DOUBLE:
                                columnTypes.put(i, EntityTableDataType.DOUBLE);
                                break;
                            case INTEGER:
                                columnTypes.put(i, EntityTableDataType.INTEGER);
                                break;
                            case DATE:
                                columnTypes.put(i, EntityTableDataType.DATE);
                                break;
                            default:
                                columnTypes.put(i, EntityTableDataType.TEXT);
                                break;
                        }
                    }
                }
            }
            if (serviceDataCategoryColNum < 0) {
                throw new Exception("No " + ServiceDataCategory.revertTo(importServiceDataCategory) + " column defined.");
            }
            Workbook importWB = getWorkbookFromRequest("import_data_file");
            EntityTableLoaderIF tableLoader = EntityLoaderFactory.getEntityTableLoader(this, importEntityType);
            EntityTable entityTable = tableLoader.createEntityTableFromWorkbook(importWB, serviceDataCategoryColNum, columnTypes);
            ServiceCache.getServiceCache(request).saveEntityTableResult(new EntityTableCacheItem(this, entityTable));

            EntityListLoader entityListLoader = new EntityListLoader(request);
            Document searchResultDoc = entityListLoader.loadAsResultNode(entityTable, null);
            searchResultDoc.getRootElement().setAttribute("DEFAULTVIEW_EXISTS", "T");

            writeResponse(searchResultDoc, null);
        } catch (AIGException ex1) {
            ex1.printStackTrace();
            throw ex1;
        } catch (Exception ex2) {
            ex2.printStackTrace();
            throw new AIGException("Unable to load EntityTable", Reason.INVALID_REQUEST);
        }
    }
}
