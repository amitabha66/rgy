package amgen.ri.aig.entitytable;


/**
 * <p>@version $Id: EntityTableCellFormatterIF.java,v 1.1 2011/06/17 20:41:19 cvs Exp $</p>
 */
public interface EntityTableCellFormatterIF {
    public String format(Column column, Object value, String source);

    public void toggleShowAssaySummary();

    public boolean isShowAssaySummary();

    public void setShowAssaySummary(boolean showAssaySummary);
}
