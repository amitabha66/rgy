package amgen.ri.aig.projectview.filterables;

import org.jdom.Element;
import org.jdom.Namespace;

import amgen.ri.aig.projectview.model.ProjectViewAssay;
import amgen.ri.aig.projectview.model.ProjectViewAssayResult;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;

/**
 * Encapsulates a filterables include the VQT ids, name, units, type, group.
 * Also holds the set value, operator and sort
 */
public class AssayFilterable extends ProjectViewFilterable {
    private ProjectViewAssay assay;
    private ProjectViewFilterable assayResultDateFilterable;
    private ProjectViewAssayResult assayResults;

    /**
     * Creates an assay ProjectViewFilterable
     *
     * @param queryable_id String
     * @param retrievable_id String
     * @param name String
     * @param units String
     * @param type String
     * @param group String
     * @param assay ProjectViewAssay
     * @param assayResults ProjectViewAssayResult
     */
    public AssayFilterable(String filterable_id, String queryable_id, String retrievable_id, String name, String category, String units, String group, ProjectViewFilterable assayResultDateFilterable,
                           ProjectViewAssay assay,
                           ProjectViewAssayResult assayResults) {
        super(filterable_id, queryable_id, retrievable_id, name, category, units, "assay", group);
        this.assay = assay;
        this.assayResultDateFilterable = assayResultDateFilterable;
        this.assayResults = assayResults;
    }


    public ProjectViewAssay getAssay() {
        return assay;
    }

    public ProjectViewAssayResult getAssayResults() {
        return assayResults;
    }

    public void setAssayResultDateFilterable(ProjectViewFilterable assayResultDateFilterable) {
        this.assayResultDateFilterable = assayResultDateFilterable;
    }

    public Element getVQTQueryableEl(String uid, Namespace ns) {
        if (!ExtString.hasLength(getOperator())) {
            return null;
        }
        if (getOperator().startsWith("No filter")) {
            return null;
        }
        if (ExtString.in(getOperator(), new String[] {"exists", "is greater than", "is less than", "equals"})) {
            return getVQTAssayResultQueryableEl(uid, ns);
        } else if (ExtString.in(getOperator(), new String[] {"on", "after", "before", "between",
                                "this week", "last week", "this month", "last month",
                                "this year", "last year", "the last 7 days", "the last 30 days"})) {
            return getVQTAssayResultDateQueryableEl(uid, ns);
        }
        throw new IllegalArgumentException("Unknown query operator " + getOperator());
    }

    /**
     * getOperator
     *
     * @param singleChar boolean
     * @return String
     */
    public String getQueryOperator() {
        String operator = getOperator();
        if (operator == null) {
            return null;
        }
        if (ExtString.in(operator, new String[] {"exists", "is greater than", "is less than", "equals", "after", "before", "on", "between"})) {
            return getOperator(true);
        }
        if (operator.equals("this week")) {
            return "thisWeek";
        }
        if (operator.equals("last week")) {
            return "lastWeek";
        }
        if (operator.equals("this month")) {
            return "thisMonth";
        }
        if (operator.equals("last month")) {
            return "lastMonth";
        }
        if (operator.equals("this year")) {
            return "thisYear";
        }
        if (operator.equals("last year")) {
            return "lastYear";
        }
        if (operator.equals("the last 7 days")) {
            return "last7Days";
        }
        if (operator.equals("the last 30 days")) {
            return "last30Days";
        }

        return operator;
    }

    public Element getVQTAssayResultQueryableEl(String uid, Namespace ns) {
        if (!ExtString.equals(getOperator(), "exists") && !ExtString.hasLength(getValue())) {
            return null;
        }
        Element queryableEl = new Element("queryable", ns);
        ExtXMLElement.addAttribute(queryableEl, "uid", uid);
        ExtXMLElement.addAttribute(queryableEl, "id", getQueryable_id());
        ExtXMLElement.addAttribute(queryableEl, "name", "Assay Result");
        ExtXMLElement.addTextElement(queryableEl, "description", "average " + assay.getAssayCode() + " " + assayResults.getResultType() + " " + getOperator() + " " + getValue(), ns);
        Element parametersEl = ExtXMLElement.addElement(queryableEl, "parameters", ns);
        //Parameter- result type
        Element parameterEl = ExtXMLElement.addElement(parametersEl, "parameter", ns);
        ExtXMLElement.addTextElement(parameterEl, "name", "result_type", ns);
        ExtXMLElement.addTextElement(parameterEl, "value", assayResults.getResultType(), ns);
        //Parameter- match_type
        parameterEl = ExtXMLElement.addElement(parametersEl, "parameter", ns);
        ExtXMLElement.addTextElement(parameterEl, "name", "match_type", ns);
        if (ExtString.equals(getOperator(true), "exists")) {
            ExtXMLElement.addTextElement(parameterEl, "value", "any", ns);
        } else {
            ExtXMLElement.addTextElement(parameterEl, "value", "average", ns);
        }
        //Parameter- include_nonnumerics
        parameterEl = ExtXMLElement.addElement(parametersEl, "parameter", ns);
        ExtXMLElement.addTextElement(parameterEl, "name", "include_nonnumerics", ns);
        ExtXMLElement.addTextElement(parameterEl, "value", "1", ns);
        //Parameter- assay_code
        parameterEl = ExtXMLElement.addElement(parametersEl, "parameter", ns);
        ExtXMLElement.addTextElement(parameterEl, "name", "assay_code", ns);
        ExtXMLElement.addTextElement(parameterEl, "value", assay.getAssayCode(), ns);
        //Parameter- value
        parameterEl = ExtXMLElement.addElement(parametersEl, "parameter", ns);
        ExtXMLElement.addTextElement(parameterEl, "name", "value", ns);
        ExtXMLElement.addTextElement(parameterEl, "operator", getQueryOperator(), ns);
        if (!getOperator().equals("exists")) {
            ExtXMLElement.addTextElement(parameterEl, "value", getValue(), ns);
        }
        return queryableEl;
    }

    public Element getVQTAssayResultDateQueryableEl(String uid, Namespace ns) {
        if (assayResultDateFilterable== null) {
            return null;
        }
        Element parameterEl;
        Element queryableEl = new Element("queryable", ns);
        ExtXMLElement.addAttribute(queryableEl, "uid", uid);
        ExtXMLElement.addAttribute(queryableEl, "id", assayResultDateFilterable.getQueryable_id());
        ExtXMLElement.addAttribute(queryableEl, "name", "Assay Result Date");
        ExtXMLElement.addTextElement(queryableEl, "description", "average " + assay.getAssayCode() + " " + assayResults.getResultType() + " assayed " + getOperator(), ns);
        //Parameters
        Element parametersEl = ExtXMLElement.addElement(queryableEl, "parameters", ns);
        //Parameter- assay_code
        parameterEl = ExtXMLElement.addElement(parametersEl, "parameter", ns);
        ExtXMLElement.addTextElement(parameterEl, "name", "assay_code", ns);
        ExtXMLElement.addTextElement(parameterEl, "value", assay.getAssayCode(), ns);
        //Parameter- result type
        parameterEl = ExtXMLElement.addElement(parametersEl, "parameter", ns);
        ExtXMLElement.addTextElement(parameterEl, "name", "result_type", ns);
        ExtXMLElement.addTextElement(parameterEl, "value", assayResults.getResultType(), ns);
        //Parameter- date_assayed
        parameterEl = ExtXMLElement.addElement(parametersEl, "parameter", ns);
        ExtXMLElement.addTextElement(parameterEl, "name", "date_assayed", ns);
        ExtXMLElement.addTextElement(parameterEl, "operator", getQueryOperator(), ns);

        String startDate= getVQTFormattedDate(getFilterableParameter("start"));
        String endDate= getVQTFormattedDate(getFilterableParameter("end"));

        if (ExtString.equals(getOperator(), "after")) {
            if (startDate!= null) {
                ExtXMLElement.addTextElement(parameterEl, "value", startDate, ns);
            } else {
                return null;
            }
        }
        if (ExtString.equals(getOperator(), "before")) {
            if (endDate!= null) {
                ExtXMLElement.addTextElement(parameterEl, "value", endDate, ns);
            } else {
                return null;
            }
        }
        if (ExtString.equals(getOperator(), "on")) {
            if (startDate!= null) {
                ExtXMLElement.addTextElement(parameterEl, "value", startDate, ns);
            } else {
                return null;
            }
        }
        if (ExtString.equals(getOperator(), "between")) {
            if (startDate!= null && endDate!= null) {
                ExtXMLElement.addTextElement(parameterEl, "value", startDate, ns);
                ExtXMLElement.addTextElement(parameterEl, "value", endDate, ns);
            } else {
                return null;
            }
        }
        return queryableEl;
    }

    public Element getVQTRetrievableEl(Namespace ns) {
        if (getVQTQueryableEl("", ns) == null && !ExtString.equalsIgnoreCase(getSort(), "ascending") && !ExtString.equalsIgnoreCase(getSort(), "descending")) {
            return null;
        }
        if (ExtString.equals(getRetrievable_id(), "0")) {
            return null;
        }
        Element retrievableEl = new Element("retrievable", ns);
        ExtXMLElement.addAttribute(retrievableEl, "id", getRetrievable_id());
        ExtXMLElement.addAttribute(retrievableEl, "name", "Assay Results");
        ExtXMLElement.addTextElement(retrievableEl, "description", assay.getAssayCode() + " " + assayResults.getResultType(), ns);
        Element parametersEl = ExtXMLElement.addElement(retrievableEl, "parameters", ns);
        //Parameter- result type
        Element parameterEl = ExtXMLElement.addElement(parametersEl, "parameter", ns);
        ExtXMLElement.addTextElement(parameterEl, "name", "result_type", ns);
        ExtXMLElement.addTextElement(parameterEl, "value", assayResults.getResultType(), ns);
        //Parameter- assay_code
        parameterEl = ExtXMLElement.addElement(parametersEl, "parameter", ns);
        ExtXMLElement.addTextElement(parameterEl, "name", "assay_code", ns);
        ExtXMLElement.addTextElement(parameterEl, "value", assay.getAssayCode(), ns);

        return retrievableEl;
    }

    public JSONObject createFilterableJSON() {
        JSONObject assayFilterable = super.createFilterableJSON();
        try {
            assayFilterable.put("result_type_id", assayResults.getResultTypeID());
            assayFilterable.put("result_type", assayResults.getResultType());
            assayFilterable.put("assay_code", assay.getAssayCode());
        } catch (JSONException ex) {
        }
        return assayFilterable;

    }

}
