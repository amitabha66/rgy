package amgen.ri.aig.entitytable;

import java.io.ObjectStreamException;

import javax.servlet.http.HttpServletRequest;

/**
 * Defines the types of Entities known to AIG
 */
public enum EntityTableRequest {
    NEW, LIST, DELETE,
            VALUES, COLUMNVALUES, GETCELLIMAGE,
            GETSELECTABLETEXTFORCELL, UPDATEFORMAT,
            ADDCOLUMNBYSERVICE,
            ADDSTRUCTUREDETAILS,
            RESETVIEWCONFIG,
            ADDEDITABLECOLUMN, UPDATEEDITABLECELLVALUE,
            ADDCALCULATEDCOLUMN, EVALUATECALCULATEDCOLUMN, RECALCULATECOLUMN, GETCALCULATEDCOLUMNCONFIG, GETAVAILABLEMETHODS,
            REFRESHCOLUMN, DELETECOLUMN,
            XCOLUMNHEADER,
            EXPORT,
            IMPORT,
            SAVE, SAVEAS,
            MOVEROWTOP,
            MOVEROWBOTTOM,
            DEBUG, UNKNOWN;

    public static EntityTableRequest fromString(String s) {
        if (s == null) {
            return UNKNOWN;
        }
        try {
            return EntityTableRequest.valueOf(s.toUpperCase());
        } catch (Exception e) {
            return UNKNOWN;
        }
    }

    /**
     * valueOf
     *
     * @return EntityTableRequest
     */
    public static EntityTableRequest valueOf(HttpServletRequest request) {
        //EntityTableRequests derived directly from the op parameters
        switch (EntityTableRequest.fromString(request.getParameter("op"))) {
            case LIST:
            case DELETE:
            case DELETECOLUMN:
            case UPDATEFORMAT:
            case UPDATEEDITABLECELLVALUE:
            case ADDEDITABLECOLUMN:
            case GETSELECTABLETEXTFORCELL:
            case GETCELLIMAGE:
            case EXPORT:
            case IMPORT:
            case DEBUG:
                return EntityTableRequest.fromString(request.getParameter("op"));
        }
        //Other EntityTableRequests

        String entityTableKey = request.getParameter("entityTableKey");
        String serviceKey = request.getParameter("serviceKey");
        if (entityTableKey == null) {
            return NEW;
        }
        if (serviceKey != null) {
            return ADDCOLUMNBYSERVICE;
        }
        if (request.getParameter("op") != null) {
            return EntityTableRequest.fromString(request.getParameter("op"));
        }
        return VALUES;
    }

    /**
     * This is necessary to permit Serializable.
     * A Serialized object containing an enum class variable is not de-Serialized properly.
     * This forces de-Serialized enum to be re-created as this enum through the String
     * @return Object
     * @throws ObjectStreamException
     */
    public Object readResolve() throws ObjectStreamException {
        return EntityTableRequest.fromString(this.toString());
    }

}
