/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.record;

import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.loft.AppAttributeType;
import amgen.ri.aig.loft.AppType;
import amgen.ri.aig.sobj.ObjectType;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtString;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Encapsulates an App record
 *
 * @author jemcdowe
 */
public class AppRecord extends AbstractRecord {
  public AppRecord(JSONObject source) throws JSONException {
    super(source, "id");
    setRecordAttributes();
  }

  public AppRecord(AbstractRecord record) throws JSONException {
    super(record);
  }

  public AppRecord(String recordID) {
    super(recordID);
  }

  public int getId() {
    return getNumber("id").intValue();
  }

  /**
   * Get the value of className
   *
   * @return the value of className
   */
  public String getClassName() {
    return getString("className");
  }

  /**
   * Get the value of created
   *
   * @return the value of created
   */
  public Date getCreated() {
    return getDate("created");
  }

  /**
   * Get the value of filterSortCategory
   *
   * @return the value of filterSortCategory
   */
  public String getFilterSortCategory() {
    return getString("filterSortCategory");
  }

  /**
   * Get the value of name
   *
   * @return the value of name
   */
  public String getName() {
    return getString("name");
  }

  /**
   * Get the Owner of the App
   *
   * @return the value of owned_by
   */
  public String getOwnedBy() {
    return getString("owned_by");
  }

  /**
   * Get the value of order
   *
   * @return the value of order
   */
  public int getOrder() {
    return getNumber("order").intValue();
  }

  /**
   * Get the value of quickAppOrder
   *
   * @return the value of quickAppOrder
   */
  public int getQuickAppOrder() {
    return getNumber("quickAppOrder").intValue();
  }

  /**
   * Returns whether this represents a quick app
   *
   * @return
   */
  public boolean isQueryApp() {
    return (getQuickAppOrder() > -1);
  }

  /**
   * Get the value of type
   *
   * @return the value of type
   */
  public AppType getType() {
    return AppType.fromString(getString("type"));
  }

  /**
   * Set the value of type
   *
   * @param type new value of type
   */
  public List<JSONObject> getAttributes() {
    return (List<JSONObject>) getOptArray("attributes").asList();
  }

  public JSONObject getAttribute(AppAttributeType attrName) {
    for (JSONObject attr : getAttributes()) {
      String value = attr.optString(attrName + "", "");
      if (ExtString.hasTrimmedLength(value)) {
        return attr;
      }
    }
    return null;
  }

  public String getAttributeValue(AppAttributeType attrName) {
    JSONObject attr = getAttribute(attrName);
    return (attr == null ? null : attr.optString(attrName + "", ""));
  }

  public void setAttributeValue(AppAttributeType attrName, String value) {
    try {
      JSONObject jAttr = getAttribute(attrName);
      if (jAttr == null) {
        jAttr = new JSONObject();
        this.append("attributes", jAttr);
      }
      jAttr.put(attrName + "", value);
    } catch (JSONException ex) {
      Logger.getLogger(AppRecord.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

  public ObjectType.Type getAppObjectType() {
    JSONObject sourceRecord = optJSONObject("sourceRecord");
    if (sourceRecord != null) {
      return ObjectType.Type.fromString(sourceRecord.optString("subtype"));
    }
    return ObjectType.Type.UNKNOWN;
  }

  private void setRecordAttributes() {
    try {
      switch (getType()) {
        case EXPLORE_TOOL:
          putOpt("filterSortCategory", "TOOL." + "SEARCHES_TOOL");
          break;
        case VQT_TOOL:
          putOpt("filterSortCategory", "TOOL." + "VISUAL_QUERIES_TOOL");
          break;
        case FAVORITES_TOOL:
        case LISTS_TOOL:
        case PROJECT_VIEW_TOOL:
        case PREFERENCES_TOOL:
        case TABLE_IMPORT_TOOL:
        case STRUCTURE_SEARCH_TOOL:
        case DOCUMENTS_TOOL:
          putOpt("filterSortCategory", "TOOL." + getType());
          break;
        case SERVICE:
          EntityListCategory entityCategory = EntityListCategory.fromString(getAttributeValue(AppAttributeType.ENTITY_CATEGORY));
          putOpt("filterSortCategory", "SEARCH." + (entityCategory.equals(EntityListCategory.UNKNOWN) ? "OTHER" : entityCategory));
          break;
        case FAVORITE:
          ObjectType.Type objType = getAppObjectType();
          putOpt("filterSortCategory", "FAVORITE." + (objType.equals(ObjectType.Type.UNKNOWN) ? "OTHER" : objType));
          break;
      }
    } catch (JSONException ex) {
      Logger.getLogger(AppRecord.class.getName()).log(Level.SEVERE, null, ex);
    }
  }
}
