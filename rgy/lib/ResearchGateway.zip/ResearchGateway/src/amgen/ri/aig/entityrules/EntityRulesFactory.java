package amgen.ri.aig.entityrules;

import amgen.ri.aig.category.schema2.EntityListCategory;

/**
 * Factory to return the appropriate business rules object for an EntityType
 *
 * @version $id$
 */
public class EntityRulesFactory {
    private EntityRulesFactory() {
        super();
    }

    public static EntityRulesFactory getInstance() {
        return new EntityRulesFactory();
    }


    public EntityRulesIF getEntityRules(EntityListCategory entityType) {
        switch (entityType) {
            case COMPOUNDS:
            case SUBSTANCES:
            case SMR_STRUCTURES:
            case SMR_MOLECULES:
                return new CompoundEntityRules(entityType);
            case ASSAYS:
                return new AssayEntityRules();
            case DOCUMENTS:
                return new DocumentEntityRules();
            default:
                return new GenericEntityRules(entityType);
        }
    }

}
