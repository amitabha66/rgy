/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.json;

import amgen.ri.aig.cache.json.JSONCacheItemFilterMatcherIF;
import amgen.ri.aig.constants.Constants;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;


/**
 *
 * @author jemcdowe
 */
public class JSONCacheItemFilter {
  private static SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.JSON_DATE_PATTERN);


  enum DataType {
    STRING, DATE, NUMERIC, LIST;

    public static DataType fromString(String s) {
      try {
        return DataType.valueOf(s.toUpperCase());
      } catch (Exception e) {
        return DataType.STRING;
      }
    }
  };
  private String field;
  private DataType dataType;
  private ComparisonType comparisonType;
  private List<Object> values;
  private JSONCacheItemFilterMatcherIF filterMatcher;

  public JSONCacheItemFilter(String field, String dataType, String comparisonType, String value) throws ParseException {
    String[] values = value.split(";");
    setFilter(field, dataType, comparisonType, Arrays.asList(values));
    setFilterMatcher(new DefaultJSONCacheItemFilterMatcher(this));
  }

  public JSONCacheItemFilter(String field, String dataType, String comparisonType, List<Object> values) throws ParseException {
    setFilter(field, dataType, comparisonType, values);
  }

  public void setFilterMatcher(JSONCacheItemFilterMatcherIF filterMatcher) {
    this.filterMatcher= filterMatcher;
  }
  private void setFilter(String field, String dataType, String comparisonType, List<?> values) throws ParseException {
    this.field = field;
    this.dataType = DataType.fromString(dataType);
    this.comparisonType = ComparisonType.fromString(comparisonType);
    this.values = new ArrayList<Object>();

    switch (this.dataType) {
      case LIST:
        for (Object value : values) {
          this.values.add(value.toString().toUpperCase());
        }
        break;
      case DATE:
        for (Object value : values) {
          if (value instanceof Date) {
            this.values.add((Date) value);
          } else {
            this.values.add(dateFormat.parse(value.toString()));
          }
        }
        break;
      case NUMERIC:
        for (Object value : values) {
          if (value instanceof Number) {
            this.values.add(((Number) value).doubleValue());
          } else {
            this.values.add(new Double(value.toString()));
          }
        }
        break;
      case STRING:
      default:
        for (Object value : values) {
          this.values.add(value.toString().toUpperCase());
        }
        break;
    }
  }

  public String getField() {
    return field;
  }

  public List<Object> getValues() {
    return values;
  }

  public void setValues(List<Object> values) {
    this.values = values;
  }
  
  public ComparisonType getComparisonType() {
    return comparisonType;
  }

  public boolean match(Object testValue) {
    if (values.isEmpty() || testValue == null) {
      if (dataType.equals(DataType.LIST)) {
        return false;
      }
      return false;
    }
    switch (dataType) {
      case DATE:
        if (testValue instanceof Date) {
          return filterMatcher.matchDate((Date) testValue);
        } else {
          try {
            return filterMatcher.matchDate(dateFormat.parse(testValue.toString()));
          } catch (ParseException ex) {
            return true;
          }
        }
      case NUMERIC:
        if (testValue instanceof Number) {
          return filterMatcher.matchNumeric(((Number) testValue).doubleValue());
        } else {
          return filterMatcher.matchNumeric(new Double(testValue.toString()));
        }
      case LIST:
        return filterMatcher.matchList(testValue);
      case STRING:
      default:
        return filterMatcher.matchString(testValue.toString().toUpperCase());
    }
  }

  public String toString() {
    return field + " " + dataType + " " + comparisonType + " " + values.get(0);
  }
}