package amgen.ri.aig.scripts;

import java.io.File;
import java.io.FileNotFoundException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;

import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.scripts.jsmin.JSMin;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;


/**
 * <p>@version $Id: AvailableScriptMethods.java,v 1.2 2011/06/21 17:28:58 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class AvailableScriptMethods extends AbstractScripts implements CalculationMethodsIF, CalculationScriptsIF {
    public static final String JSOBJ_NAME = "RGM";
    private Document methodsDocument;

    public AvailableScriptMethods(EntityListCategory entityType, Document globalScriptFileDoc) throws FileNotFoundException {
        super(entityType, null);
        methodsDocument = new Document(new Element("JSObjects"));
        ExtXMLElement.addElement(methodsDocument.getRootElement(), "AvailableMethods");
        Element globalObjectsEl = ExtXMLElement.getXPathElement(globalScriptFileDoc, "/JSObjects/GlobalObjects");
        if (globalObjectsEl != null) {
            methodsDocument.getRootElement().addContent((Element) globalObjectsEl.clone());
        }
    }

    /**
     * Adds the AvailableScripts to the Methods. It must be a unique group name
     * or it is disregarded
     *
     * @param availableScripts AbstractAvailableScripts
     */
    public void addAvailableScripts(AbstractScripts availableScripts) {
        List<Element> availMethodGroupEls = availableScripts.getMethodGroups(getEntityListCategory());
        for (Element availMethodGroupEl : availMethodGroupEls) {
            String groupName = availMethodGroupEl.getChildText("Name");
            Element availableMethodsEl = ExtXMLElement.getXPathElement(methodsDocument, "/JSObjects/AvailableMethods");
            Element localMethodGroupEl = ExtXMLElement.getXPathElement(methodsDocument, "/JSObjects/AvailableMethods/MethodGroup[Name='" + groupName + "']");
            if (localMethodGroupEl == null) {
                String className = availMethodGroupEl.getChildText("ClassName");
                Element newMethodGroupEl = ExtXMLElement.addElement(availableMethodsEl, "MethodGroup");
                newMethodGroupEl.setAttribute("entity_type", getEntityListCategory().toString());
                ExtXMLElement.addTextElement(newMethodGroupEl, "Name", groupName);
                ExtXMLElement.addTextElement(newMethodGroupEl, "ClassName", className);
                List<Element> availMethodEls = ExtXMLElement.getXPathElements(availMethodGroupEl, "./Method");
                for (Element availMethodEl : availMethodEls) {
                    boolean isValid = false;
                    try {
                        if (ExtString.hasLength(className)) {
                            isValid = true;
                        } else {
                            Element codeEl = availMethodEl.getChild("Code");
                            String src = codeEl.getAttributeValue("src");
                            if (ExtString.hasLength(src)) {
                                String sourceCode = null;
                                File srcFile = new File(src);
                                if (!srcFile.exists() && availableScripts.getScriptFileDir() != null) {
                                    srcFile = new File(availableScripts.getScriptFileDir(), src);
                                }
                                if (srcFile.exists()) {
                                    src = srcFile.toURL().toString();
                                }
                                sourceCode = ExtString.readToString(new URL(src));
                                if (ExtString.hasLength(sourceCode)) {
                                    codeEl.setText(sourceCode);
                                }
                            }
                            String minSourceCode = getSourceCode(availMethodEl.getChildText("Name"), codeEl.getText());
                            if (minSourceCode != null && minSourceCode.startsWith("function")) {
                                isValid = true;
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (isValid) {
                        newMethodGroupEl.addContent((Element) availMethodEl.clone());
                    }
                }
            }
        }
    }

    /**
     * Returns the Method XML Document
     *
     * @return Document
     */
    public Document getMethodDocument() {
        return methodsDocument;
    }

    /**
     * Adds all scripts to the given scope
     *
     * @param cx Context
     * @param scope Scriptable
     * @throws InvocationTargetException
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public void addScripts(Context cx, Scriptable scope) throws InvocationTargetException, InstantiationException, IllegalAccessException {
        StringBuffer sourceBuffer = new StringBuffer(getGlobalObjects());
        List<Element> methodGroupEls = getMethodGroups(getEntityListCategory());
        for (Element methodGroupEl : methodGroupEls) {
            String methodGroupName = methodGroupEl.getChildText("Name");
            String methodGroupJSName = getValidJSName(methodGroupName);
            String className = methodGroupEl.getChildText("ClassName");
            if (ExtString.hasLength(className)) {
                Class scriptClass = getScriptMethodsClass(className);
                if (scriptClass != null) {
                    ScriptableObject scriptClassInstance = (ScriptableObject) scriptClass.newInstance();
                    ScriptableObject.defineClass(scope, scriptClass);
                    Scriptable preDefFuncs = cx.newObject(scope, scriptClassInstance.getClassName());
                    scope.put(methodGroupJSName, scope, preDefFuncs);
                }
            } else {
                sourceBuffer.append("var " + methodGroupJSName + "={};");
                List<Element> methodEls = getMethodsForGroup(methodGroupEl);
                for (Element method : methodEls) {
                    String methodName = method.getChildText("Name");
                    String methodJSName = getValidJSName(methodName);
                    Element codeEl = method.getChild("Code");
                    String sourceCode = getSourceCode(methodName, codeEl.getText());
                    if (ExtString.hasTrimmedLength(sourceCode)) {
                        try {
                            if (sourceCode.startsWith("function")) {
                                sourceBuffer.append(methodGroupJSName + "." + methodJSName + "=");
                                sourceBuffer.append(sourceCode);
                                sourceBuffer.append("\n");
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
        cx.evaluateString(scope, sourceBuffer.toString(), "", 1, null);
    }

    /**
     * getSourceCode
     *
     * @param methodName String
     * @param string String
     * @param string1 String
     * @return String
     */
    protected String getSourceCode(String methodName, String sourceCode) {
        if (ExtString.hasLength(sourceCode)) {
            try {
                sourceCode = JSMin.minify(sourceCode);
                if (!validScriptSource(methodName, sourceCode)) {
                    return null;
                }
            } catch (Exception ex2) {
                ex2.printStackTrace();
                return null;
            }
        } else {
            return null;
        }
        return sourceCode;
    }


    /**
     * Returns the GlobalObjects code as a single concatenated script
     *
     * @return String
     */
    private String getGlobalObjects() {
        StringBuffer globalBuffer = new StringBuffer();
        List<Element> globalEls =
                ExtXMLElement.getXPathElements(methodsDocument, "//GlobalObjects/JSObject");
        for (Element globalEl : globalEls) {
            globalBuffer.append(globalEl.getChildText("Code"));
            globalBuffer.append("\n");
        }
        return globalBuffer.toString();
    }

    /**
     * Returns a valid Javascript name for method groups and method names.
     * Currently replaces all non-word characters with underscores.
     *
     * @param s String
     * @return String
     */
    public String getValidJSName(String s) {
        return s.replaceAll("\\s", "_");
    }


}
