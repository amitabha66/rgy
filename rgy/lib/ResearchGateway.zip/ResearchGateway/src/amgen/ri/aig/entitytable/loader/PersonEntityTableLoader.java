package amgen.ri.aig.entitytable.loader;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.tree.TreeNode;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.entitytable.Column;
import amgen.ri.aig.entitytable.ColumnGroup;
import amgen.ri.aig.entitytable.DataCell;
import amgen.ri.aig.entitytable.DataRow;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;
import amgen.ri.aig.preferences.PreferenceManager;
import amgen.ri.excel.ExcelUtils;
import amgen.ri.ldap.AmgenEnterpriseEntry;
import amgen.ri.util.ExtString;

/**
 * Custom EntityTable loader for Person entities
 * @version $Id: PersonEntityTableLoader.java,v 1.6 2014/07/08 15:51:47 jemcdowe Exp $
 */
public class PersonEntityTableLoader extends AbstractEntityTableLoader {
    public PersonEntityTableLoader(AIGBase requestor) {
        this(requestor, null);
    }

    public PersonEntityTableLoader(AIGBase requestor, String resultNodeKey) {
        super(requestor, EntityListCategory.PEOPLE, resultNodeKey);
    }

    /**
     * Overrides the createEntityTableFromResultNode to create the EtityTable
     * from a Result Node
     *
     * @param resultNodeKey String
     * @return EntityTable
     * @throws AIGException
     */
  @Override
    public EntityTable createEntityTableFromResultNode(String resultNodeKey) throws AIGException {
        //Create the table
        EntityTable entityTable = new EntityTable(EntityListCategory.PEOPLE);
        new PreferenceManager(getRequestor(), entityTable).setPreferences();
        entityTable.setServiceResultCacheItem(getRequestor().getServiceResultCacheItem(resultNodeKey));
        entityTable.setTableName(getTableName());

        //Create the entity ColumnGroup
        ColumnGroup peopleColumnGroup = new ColumnGroup("Person");
        entityTable.addColumnGroup(peopleColumnGroup);
        peopleColumnGroup.setIsEntityIDDataIndex(true);
        peopleColumnGroup.addColumn(new Column("Name"));

        for (TreeNode childResultNode : getChildResultNodes()) {
            String name = childResultNode.getText();
            String login = childResultNode.getServiceData();
            DataRow dataRow = entityTable.addDataRow(new DataRow(login));
            if (dataRow != null) {
                dataRow.addDataCell(new DataCell(name));
            }
        }
        return entityTable;
    }


    /**
     * Overrides the createEntityTableFromResultNode to create the EntityTable
     * from a Result Node
     *
     * @param resultNodeKey String
     * @return EntityTable
     * @throws AIGException
     */
    public EntityTable createEntityTableFromWorkbook(Workbook workbook, int serviceDataCategoryColNum, Map<Integer, EntityTableDataType> columnTypes) throws AIGException {
        if (!getEntityTableType().equals(EntityListCategory.PEOPLE)) {
            throw new AIGException("Only valid for people entities", AIGException.Reason.ENTITY_MISMATCH);
        }

        //Create the table
        EntityTable entityTable = new EntityTable(EntityListCategory.PEOPLE);
        new PreferenceManager(getRequestor(), entityTable).setPreferences();
        entityTable.setTableName(getTableName());

        //Create the entity ColumnGroup
        ColumnGroup peopleColumnGroup = new ColumnGroup("Person");
        entityTable.addColumnGroup(peopleColumnGroup);
        peopleColumnGroup.setIsEntityIDDataIndex(true);
        peopleColumnGroup.addColumn(new Column("Name"));

        Sheet importSheet = workbook.getSheetAt(0);
        Row headerRow = importSheet.getRow(0);
        List<Integer> importColumns = new ArrayList<Integer>();

        for (int col = 0; col < headerRow.getPhysicalNumberOfCells(); col++) {
            if (col != serviceDataCategoryColNum) {
                String header = ExcelUtils.getCellStringValue(headerRow, col);
                EntityTableDataType dataType = EntityTableDataType.UNSPECIFIED;
                if (columnTypes != null) {
                    dataType = columnTypes.get(col);
                }
                if (!dataType.equals(EntityTableDataType.UNSPECIFIED)) {
                    ColumnGroup columnGroup = new ColumnGroup(header);
                    entityTable.addColumnGroup(columnGroup);

                    Column column = new Column(header, dataType);
                    columnGroup.addColumn(column);
                    importColumns.add(col);
                }
            }
        }

        for (int row = 1; row < importSheet.getPhysicalNumberOfRows(); row++) {
            Row importRow = importSheet.getRow(row);
            String login = ExcelUtils.getCellStringValue(importRow, serviceDataCategoryColNum);
            AmgenEnterpriseEntry entry = new AmgenEnterpriseEntry(login);
            if (ExtString.hasLength(entry.getUid())) {
                DataRow dataRow = entityTable.addDataRow(new DataRow(login));
                dataRow.addDataCell(new DataCell(entry.getLedgerName()));
                for (int col : importColumns) {
                    EntityTableDataType dataType = EntityTableDataType.UNSPECIFIED;
                    if (columnTypes != null) {
                        dataType = columnTypes.get(col);
                    }
                    String importValue = ExcelUtils.getCellStringValue(importRow, col);
                    dataRow.addDataCell(new DataCell(importValue, dataType));
                }
            }
        }
        return entityTable;
    }

    /**
     * Overrides the createEntityTableFromResultNode to create the EntityTable
     * from a Result Node
     *
     * @param resultNodeKey String
     * @return EntityTable
     * @throws AIGException
     */
    public int addEntitiesToEntityTable(EntityTable entityTable, List<String> logins) throws AIGException {
        int importCount = 0;

        for (String login : logins) {
            ColumnGroup entityColumnGroup = entityTable.getColumnGroups().get(0);
            AmgenEnterpriseEntry amgenEnterpriseEntry = new AmgenEnterpriseEntry(login);
            if (ExtString.hasLength(amgenEnterpriseEntry.getLedgerName())) {
                DataRow newDataRow = addEntityRowToEntityTable(entityTable, login, amgenEnterpriseEntry.getLedgerName());
                if (newDataRow != null) {
                    importCount++;
                    for (int i = entityColumnGroup.getColumnCount(); i < entityTable.getColumnCount(); i++) {
                        newDataRow.addDataCell(new DataCell(""));
                    }
                }
            }
        }
        return importCount;
    }

    /**
     * Creates a new row in the table given the entityID.
     * Entity IDs can not be duplicated, so if thsi entityID already exists in the table, this returns null.
     * If for any other reason it can not be added, it returns null.
     * Otherwise, it returns the new DataRow
     * @param entityTable EntityTable
     * @param entityID String
     * @return DataRow
     */
    public DataRow addEntityRowToEntityTable(EntityTable entityTable, String entityID, String entityLabel) {
        if (ExtString.hasTrimmedLength(entityID) && ExtString.hasTrimmedLength(entityLabel) && entityTable.getDataRow(entityID) == null) {
            DataRow newDataRow = entityTable.addDataRow(new DataRow(entityID));
            if (newDataRow != null) {
                newDataRow.addDataCell(new DataCell(entityLabel));
                return newDataRow;
            }
        }
        return null;
    }

}
