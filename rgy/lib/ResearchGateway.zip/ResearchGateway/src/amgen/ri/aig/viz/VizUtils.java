/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.viz;

import amgen.ri.aig.entitylist.EntityListIF;
import amgen.ri.aig.entitylist.EntityListMemberIF;
import amgen.ri.json.JSONObject;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtURL;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;

/**
 *
 * @author jemcdowe
 */
public class VizUtils {

  public static String generateSpotfireWebplayerURL(VisualizationResults vizResult, EntityListMemberIF entity) {
    String spotfireURL = vizResult.getSpotfireWebPlayerURL();
    List<String> configBlockParams = new ArrayList<String>();
    configBlockParams.add("visualization_id=" + vizResult.getVisualizationID());
    configBlockParams.add("query_run_id=" + vizResult.getQueryRunID());
    configBlockParams.add("query_item_id=" + vizResult.getQueryItemID());
    configBlockParams.add("entity_key=" + (entity== null ? "null" : entity.getMember()));    
    spotfireURL += "&configurationBlock=" + ExtURL.urlEncode(StringUtils.join(configBlockParams, ';') + ";");
    return spotfireURL;
  }

  public static String generateSpotfireDXPURL(VisualizationResults vizResult, EntityListMemberIF entity) {
    String spotfireURL = vizResult.getSpotfireDXPURL();
    List<String> configBlockParams = new ArrayList<String>();
    configBlockParams.add("visualization_id=" + vizResult.getVisualizationID());
    configBlockParams.add("query_run_id=" + vizResult.getQueryRunID());
    configBlockParams.add("query_item_id=" + vizResult.getQueryItemID());
    configBlockParams.add("entity_key=" + (entity== null ? "null" : entity.getMember()));    
    spotfireURL += ":configurationBlock:" + ExtURL.urlEncode(StringUtils.join(configBlockParams, ';') + ";");
    return spotfireURL;
  }

}
