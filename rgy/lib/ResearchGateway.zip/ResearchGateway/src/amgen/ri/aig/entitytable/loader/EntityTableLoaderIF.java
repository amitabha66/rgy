package amgen.ri.aig.entitytable.loader;

import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Workbook;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.entitytable.EntityTable;
import amgen.ri.aig.entitytable.category.schema2.EntityTableDataType;

/**
 * 
 * Used to create a custom table loader for an entity type
 * @version $Id: EntityTableLoaderIF.java,v 1.6 2015/12/18 01:01:29 jemcdowe Exp $</p>
 */
public interface EntityTableLoaderIF {

  /**
   * The entry stub which creates an EntityTable
   *
   * THIS GENERALLY DOES NEED TO BE IMPLEMETED IF THE IMPLEMENTATION CLASS EXTENDS THE AbstractEntityTableLoader.
   *
   *
   *
   * @return
   * @throws AIGException
   */
  public EntityTable createEntityTable() throws AIGException;

  /**
   * Overrides the createEntityTableFromResultNode to create the EntityTable from a Result Node
   *
   * @param workbook
   * @param serviceDataCategoryColNum
   * @param columnTypes
   * @return EntityTable
   * @throws AIGException
   */
  public EntityTable createEntityTableFromWorkbook(Workbook workbook, int serviceDataCategoryColNum, Map<Integer, EntityTableDataType> columnTypes) throws AIGException;

  /**
   * Sets the name to be used by the new table.
   *
   * @param tableName
   */
  public void setTableName(String tableName);

  /**
   * Adds new Entities to an existing EntityTable. Note that entities are only added if they are unique!! returns the
   * number of imports
   *
   * @param entityTable
   * @param entityIDs
   * @return
   * @throws amgen.ri.aig.AIGException
   */
  public int addEntitiesToEntityTable(EntityTable entityTable, List<String> entityIDs) throws AIGException;

  /**
   * Users to create an EntityTable from a ResultNode. This must be overridden. Default implementation throws an
   * Exception
   *
   * @param resultNodeKey String
   * @return EntityTable
   * @throws AIGException
   */
  public EntityTable createEntityTableFromResultNode(String resultNodeKey) throws AIGException;
}
