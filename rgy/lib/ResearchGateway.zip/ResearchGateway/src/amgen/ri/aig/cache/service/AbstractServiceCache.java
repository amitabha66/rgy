/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.service;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.CacheUtils;
import amgen.ri.aig.cache.item.GlobalCacheItem;
import amgen.ri.aig.cache.CacheType;
import amgen.ri.aig.cache.ora.OfflineServiceDetails;
import amgen.ri.aig.cache.ora.OracleCacheManager;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.listener.ServiceLogger;
import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.aig.sv.OILServiceParameterInterceptor;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.aig.uddi.ServiceQuery;
import amgen.ri.asf.sa.security.FASFIdentitySecurityToken;
import amgen.ri.asf.sa.security.SiteMinderSessionSecurityToken;
import amgen.ri.asf.sa.uddi.BindingDetails;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.TModelDetails;
import amgen.ri.rg.resource.ResourceFactory;
import amgen.ri.security.FASFEncrypter;
import amgen.ri.security.FASFIdentity;
import amgen.ri.util.Debug;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.naming.ServiceUnavailableException;
import javax.servlet.http.HttpSession;
import javax.xml.rpc.ServiceException;
import javax.xml.soap.SOAPException;
import org.jdom.JDOMException;

/**
 *
 * @author jemcdowe
 */
public abstract class AbstractServiceCache extends ResourceFactory {

  public static final String SERVICECACHE_SESSIONKEY = "SERVICECACHE_SESSIONKEY";
  private Map<String, Boolean> serviceOffline;

  /**
   * Private constructor use the getServiceCache for singleton access
   *
   * @param session
   * @throws amgen.ri.aig.AIGException
   */
  protected AbstractServiceCache(HttpSession session) throws AIGException {
    super(session);
    serviceOffline = new HashMap<String, Boolean>();
  }

  /**
   * returns the SessionLogin
   *
   * @return
   */
  protected AIGSessionLogin getSessionLogin() {
    return AIGSessionLogin.getAIGSessionLogin(getSession());
  }

  /**
   * @return the serviceOffline
   */
  protected Map<String, Boolean> getServiceOffline() {
    return serviceOffline;
  }

  protected boolean isServiceOffline(String serviceKey) {
    if (getServiceOffline().containsKey(serviceKey)) {
      return getServiceOffline().get(serviceKey);
    }
    return false;
  }

  protected void setServiceOffline(String serviceKey, boolean offline) {
    getServiceOffline().put(serviceKey, offline);
  }

  /**
   * Returns the BindingDetails for the given key- either from cache or by quering the UDDI.
   *
   * @param bindingKey String
   * @return BindingDetails
   * @throws AIGException
   */
  protected BindingDetails getBindingDetailsFromCache(String bindingKey) throws AIGException {
    try {
      if (bindingKey == null) {
        return null;
      }
      if (getLocalCacheMgr().contains(CacheType.BINDING, bindingKey)) {
        BindingDetails binding = (BindingDetails) getLocalCacheMgr().get(CacheType.BINDING, bindingKey);
        return binding;
      }
      BindingDetails binding = new BindingDetails(getUDDIQuery().getUddiDetails(), bindingKey);
      getLocalCacheMgr().put(CacheType.BINDING, bindingKey, binding);
      return binding;
    } catch (AIGException e) {
      throw e;
    } catch (Exception e) {
      throw new AIGException(AIGException.Reason.UNABLE_TO_RETRIEVE_ENTRY, e);
    }
  }

  /**
   * Returns the List of service keys for the given ClassificationSchemeQuery either from cache or from a UDDI query.
   *
   * @param serviceQuery
   * @return
   * @throws amgen.ri.aig.AIGException
   */
  protected ServiceKeyCacheResponse getServiceKeysByQueryFromCache(ServiceQuery serviceQuery) throws AIGException {
    try {
      if (getServiceCacheDisable().isDisableAllCaching()) {
        Debug.print("All Cache Disabled");
        Collection<String> serviceKeys = queryUDDIForServiceKeys(serviceQuery).getServiceKeys();
        return new ServiceKeyCacheResponse(serviceKeys);
      }
      String queryKey = CacheUtils.constructQueryKey(serviceQuery);
      GlobalCacheItem globalCacheItem = (GlobalCacheItem) getGlobalCacheMgr().get(CacheType.SERVICEQUERY, queryKey);
      if (globalCacheItem != null) {
        Debug.print("Using Oracle Global cache for SERVICEQUERY");
        Collection<String> serviceKeys = (List<String>) globalCacheItem.getCacheObject();
        serviceKeys = removeOfflineKeys(serviceKeys);
        ServiceKeyCacheResponse response = new ServiceKeyCacheResponse(serviceKeys);
        List<ServiceDetails> serviceCacheItems = getGlobalCacheMgr().getAllSortedServices(serviceKeys, ServiceNamingContext.RG_QUERY, true);
        response.addServiceDetails(processServices(serviceCacheItems));
        response.addServiceDetails(serviceCacheItems);
        return response;
      }
      Collection<String> serviceKeys = queryUDDIForServiceKeys(serviceQuery).getServiceKeys();
      getGlobalCacheMgr().put(CacheType.SERVICEQUERY, new GlobalCacheItem(queryKey, new ArrayList<String>(serviceKeys)));
      return new ServiceKeyCacheResponse(removeOfflineKeys(serviceKeys));
    } catch (AIGException e) {
      throw e;
    } catch (Exception e) {
      e.printStackTrace();
      throw new AIGException(AIGException.Reason.UNABLE_TO_RETRIEVE_ENTRY, e);
    }
  }

  private Collection<String> removeOfflineKeys(Collection<String> serviceKeys) {
    if (serviceKeys == null) {
      return null;
    }
    List<String> updatedServiceKeys = new ArrayList<String>(serviceKeys);
    updatedServiceKeys.removeAll(((OracleCacheManager) getGlobalCacheMgr()).getOfflineServiceKeys());
    return updatedServiceKeys;
  }

  /**
   * Returns the ServiceDetails for the given key- either from cache or by querying the UDDI.
   *
   * Note: This actually returns a copy of the cached ServiceDetails object to avoid any corruption
   *
   * @param serviceKey String
   * @return ServiceDetails
   */
  protected ServiceDetails getServiceFromCache(String serviceKey, boolean setParameters) throws AIGException {
    if (isServiceOffline(serviceKey)) {
      throw new AIGException(String.format("Service (%s) is offline", serviceKey), AIGException.Reason.SERVICE_OFFLINE);
    }
    try {
      if (serviceKey == null) {
        return null;
      }
      if (getServiceCacheDisable().contains(serviceKey) || getServiceCacheDisable().isDisableAllCaching()) {
        Debug.print("No Cache Service- " + serviceKey);
        ServiceDetails serviceDetails = new ServiceDetails(getUDDIQuery().getUddiDetails(), serviceKey, true, false);
        if (serviceDetails.getStatus(true, SERVICECONNECTION_TIMEOUTMILLIS * 3) != ServiceDetails.STATUS_OK) {
          throw new ServiceUnavailableException("Service [" + serviceKey + "] is either inactive or invalid");
        }
        Debug.print("Poll Success for SERVICE- " + serviceKey);
        ServiceAttributes serviceAttr = new ServiceAttributes(serviceDetails, getEntityClassManager());
        if (setParameters && !serviceAttr.isWidget()) {
          serviceDetails.setParameters();
        }
        return processService(serviceDetails);
      }

      if (getGlobalCacheMgr().contains(CacheType.SERVICE, serviceKey)) {
        Debug.print("Using Oracle Global cache for SERVICE- " + serviceKey);
        GlobalCacheItem globalCacheItem = (GlobalCacheItem) getGlobalCacheMgr().get(CacheType.SERVICE, serviceKey);
        Object cachedService = globalCacheItem.getCacheObject();
        if (cachedService instanceof OfflineServiceDetails) {
          throw new AIGException(String.format("Service (%s) is offline", serviceKey), AIGException.Reason.SERVICE_OFFLINE);
        } else if (cachedService instanceof ServiceDetails) {
          return processService((ServiceDetails) cachedService);
        }
      }
      if (getLocalCacheMgr().contains(CacheType.SERVICE, serviceKey)) {
        Debug.print("Using Local cache for SERVICE- " + serviceKey);
        ServiceDetails serviceDetails = (ServiceDetails) getLocalCacheMgr().get(CacheType.SERVICE, serviceKey);
        return processService(serviceDetails);
      }
      Debug.print("Polling SERVICE- " + serviceKey);
      ServiceDetails serviceDetails = new ServiceDetails(getUDDIQuery().getUddiDetails(), serviceKey, true, false);
      if (serviceDetails.getStatus(true, SERVICECONNECTION_TIMEOUTMILLIS * 3) != ServiceDetails.STATUS_OK) {
        throw new ServiceUnavailableException("Service [" + serviceKey + "] is either inactive or invalid");
      }
      Debug.print("Poll Success for SERVICE- " + serviceKey);
      ServiceAttributes serviceAttr = new ServiceAttributes(serviceDetails, getEntityClassManager());
      if (setParameters && !serviceAttr.isWidget()) {
        serviceDetails.setParameters();
      }
      getLocalCacheMgr().put(CacheType.SERVICE, serviceKey, serviceDetails);
      getGlobalCacheMgr().put(CacheType.SERVICE, new GlobalCacheItem(serviceDetails));
      return processService(serviceDetails);
    } catch (ServiceUnavailableException e) {
      setServiceOffline(serviceKey, true);
      getGlobalCacheMgr().put(CacheType.SERVICE, new GlobalCacheItem(new OfflineServiceDetails(serviceKey)));
      throw new AIGException(e.getMessage(), AIGException.Reason.SERVICE_OFFLINE);
    } catch (ServiceException e) {
      setServiceOffline(serviceKey, true);
      getGlobalCacheMgr().put(CacheType.SERVICE, new GlobalCacheItem(new OfflineServiceDetails(serviceKey)));
      e.printStackTrace();
      throw new AIGException(e.getMessage(), AIGException.Reason.SERVICE_OFFLINE);
    } catch (AIGException e) {
      throw e;
    } catch (Exception e) {
      e.printStackTrace();
      throw new AIGException(AIGException.Reason.UNABLE_TO_RETRIEVE_ENTRY, e);
    }
  }

  /**
   * Returns the TModelDetails for the given key- either from cache or by querying the UDDI.
   *
   * @param tModelKey String
   * @return TModelDetails
   */
  protected TModelDetails getTModelDetailsFromCache(String tModelKey) throws AIGException {
    try {
      if (tModelKey == null) {
        return null;
      }
      if (getLocalCacheMgr().contains(CacheType.TMODEL, tModelKey)) {
        TModelDetails tModel = (TModelDetails) getLocalCacheMgr().get(CacheType.TMODEL, tModelKey);
        return tModel;
      }
      TModelDetails tModel = new TModelDetails(getUDDIQuery().getUddiDetails(), tModelKey);
      getLocalCacheMgr().put(CacheType.TMODEL, tModelKey, tModel);
      return tModel;
    } catch (AIGException e) {
      throw e;
    } catch (Exception e) {
      throw new AIGException(AIGException.Reason.UNABLE_TO_RETRIEVE_ENTRY, e);
    }
  }

  /**
   * This is the ACTUAL UDDI query call :)
   *
   * @param serviceQuery
   * @param inputTypeAcceptsList
   * @param resultType
   * @return
   * @throws JDOMException
   * @throws SOAPException
   * @throws IOException
   */
  protected ServiceKeyCacheResponse queryUDDIForServiceKeys(ServiceQuery serviceQuery) throws JDOMException, SOAPException, IOException {
    Set<String> serviceKeys = new LinkedHashSet<String>();
    List<String> inputTypesWhichAcceptsList = new ArrayList(serviceQuery.getInputTypesWhichAcceptsList());

    if (serviceQuery.getResultTypes().isEmpty()) {
      serviceKeys.addAll(getUDDIQuery().findServiceKeys(serviceQuery.getClassificationSchemeQuery(), inputTypesWhichAcceptsList, null, true));
    } else {
      for (String resultType : serviceQuery.getResultTypes()) {
        serviceKeys.addAll(getUDDIQuery().findServiceKeys(serviceQuery.getClassificationSchemeQuery(), new ArrayList(serviceQuery.getInputTypesWhichAcceptsList()), resultType, true));
      }
    }
    return new ServiceKeyCacheResponse(serviceKeys);
  }

  /**
   * Process a List of ServiceDetails objects
   *
   * @param services
   * @return
   * @throws AIGException
   */
  protected List<ServiceDetails> processServices(List<ServiceDetails> services) throws AIGException {
    List<ServiceDetails> processedServices = new ArrayList<ServiceDetails>(services.size());
    for (ServiceDetails service : services) {
      try {
        processedServices.add(processService(service));
      } catch (Exception e) {
      }
    }
    return processedServices;

  }

  /**
   * Processes the provided ServiceDetails: Creates a copy of the object Resets any parameters Clears and adds listeners
   * Clears and adds security tokens
   *
   * @param service
   * @return
   * @throws amgen.ri.aig.AIGException
   */
  protected ServiceDetails processService(ServiceDetails service) throws AIGException {
    ServiceDetails serviceCopy = (ServiceDetails) service.copy();
    serviceCopy.setParameters(true);
    serviceCopy.clearListeners();
    serviceCopy.clearSecurityTokens();
    serviceCopy.addListener(new OILServiceParameterInterceptor(getEntityClassManager()));
    serviceCopy.addListener(new ServiceLogger(getSession()));

    SiteMinderSessionSecurityToken token = new SiteMinderSessionSecurityToken(AIGSessionLogin.getAIGSessionLogin(getSession()));
    FASFIdentitySecurityToken fasfToken = new FASFIdentitySecurityToken(AIGSessionLogin.getAIGSessionLogin(getSession()));
    FASFIdentity fasfIdentity = null;
    try {
      fasfIdentity = new FASFEncrypter().decryptFASFIdentity(fasfToken.getToken());
    } catch (Exception e) {
    }
    if (fasfIdentity != null) {
      fasfIdentity.setSessionID(getSession().getId());
      fasfIdentity.setSessionStart(getSession().getCreationTime());
      fasfIdentity.setLastAccess(getSession().getLastAccessedTime());
      fasfToken = new FASFIdentitySecurityToken(fasfIdentity);
      fasfToken.setCookieName("RG_IDENTITY");
    }
    serviceCopy.addSecurityToken(token);
    serviceCopy.addSecurityToken(fasfToken);

    return serviceCopy;
  }

  /**
   * @return the serviceCacheDisable
   */
  public ServiceCacheDisable getServiceCacheDisable() {
    ServiceCacheDisable serviceCacheDisable = (ServiceCacheDisable) getSession().getAttribute("ServiceCacheDisable");
    return (serviceCacheDisable == null ? new ServiceCacheDisable() : serviceCacheDisable);
  }

}
