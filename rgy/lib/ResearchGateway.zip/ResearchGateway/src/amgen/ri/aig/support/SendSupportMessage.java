package amgen.ri.aig.support;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.aig.AIGServlet;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.mail.SendMessage;
import amgen.ri.servlet.SessionLogin;

public class SendSupportMessage extends AIGServlet {
    public SendSupportMessage() {
        super();
    }

    /**
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     */
    public SendSupportMessage(HttpServletRequest req, HttpServletResponse resp) {
        super(req, resp);
    }

    /**
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return TBXServlet
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new SendSupportMessage(req, resp);
    }

    /**
     *
     * @return String
     */
    protected String getServletMimeType() {
        return "text/xml";
    }

    /**
     *
     * @throws Exception
     */
    protected void performRequest() throws Exception {
        try {
            if (doesParameterExist("subject", true) && doesParameterExist("message", true)) {
                String emailDomain= ConfigurationParameterSource.getConfigParameter("AMGEN_EMAIL_DOMAIN");
                if (emailDomain== null) {
                    System.err.println("Warning: No email domain defined");
                    return;
                }

                String rgVersion = ConfigurationParameterSource.getConfigParameter("AIG_VERSION");
                String build = ConfigurationParameterSource.getConfigParameter("BUILD");
                String rgBuild = build + " (" + rgVersion.toLowerCase() + ")";

                String subject = "Research Gateway Support Question: " + getParameter("subject");
                String message = "Research Gateway SUPPORT QUESTION<P>" +
                                 "From: " + SessionLogin.getSessionLogin(request).getUserLedgerDisplayName() + "<BR>" +
                                 "Research Gateway Build: " + rgBuild + "<BR>" +
                                 "Research Gateway Session: " + (String) request.getSession(false).getId() + "<BR>" +
                                 "Sent: " + new Date() + "<P>" + getParameter("message");
                String[] addresses = ConfigurationParameterSource.getConfigParameter("SUPPORT_EMAILS").split("[,\\s]+");
                String from = SessionLogin.getSessionLogin(request).getRemoteUser() + "@"+emailDomain;
                SendMessage messenger = new SendMessage(request.getSession(true).getServletContext());
                messenger.sendHTMLMessage(addresses, null, null, from, subject, message);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
