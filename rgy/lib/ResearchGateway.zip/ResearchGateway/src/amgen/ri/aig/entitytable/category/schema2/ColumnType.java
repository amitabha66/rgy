package amgen.ri.aig.entitytable.category.schema2;

import java.io.ObjectStreamException;

/**
 * @version $Id: ColumnType.java,v 1.2 2012/04/26 23:02:58 cvs Exp $
 */
public enum ColumnType {
	EDITABLE, CALCULATED, GENERAL;

	static final long serialVersionUID = 6724450762411450217L;

	public static ColumnType fromString(String s) {
		if (s != null) {
			try {
				s = s.toUpperCase().replaceAll(" ", "_");
				return ColumnType.valueOf(s);
			} catch (Exception e) {
			}
		}
		return GENERAL;
	}

	/**
	 * This is necessary to permit Serializable. A Serialized object containing
	 * an enum class variable is not de-Serialized properly. This forces
	 * de-Serialized enum to be re-created as this enum through the String
	 * 
	 * @return Object
	 * @throws ObjectStreamException
	 */
	public Object readResolve() throws ObjectStreamException {
		return ColumnType.fromString(this.toString());
	}


}
