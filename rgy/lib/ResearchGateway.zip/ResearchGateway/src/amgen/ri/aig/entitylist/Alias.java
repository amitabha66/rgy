/*
 *   Alias
 *   RDBData wrapper class for ALIAS
 *   $Revision: 1.1 $
 *   Created: Jeffrey McDowell, 05 Jun 2009
 *   Modified: $Author: cvs $
 *   $Log
 *
 */
package amgen.ri.aig.entitylist;


import java.lang.reflect.Field;

import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.SQLManagerIF;

/**
 *   RDBData wrapper class for ALIAS
 *   @version $Revision: 1.1 $
 *   @author Jeffrey McDowell
 *   @author $Author: cvs $
 */
public class Alias extends RdbData {
    protected int alias_id;
    protected String target_type;
    protected int target_id;
    protected String alias_name;
    protected String alias_value;
    protected String created_by;
    protected String created;
    protected String alias_type;

    /**
     * Default Constructor
     */
    public Alias() {
        super();
    }

    /**
     * RdbData Constructor
     */
    public Alias(String alias_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.alias_id = Integer.parseInt(alias_id);
    }

    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return alias_id + "";
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }

    /** Get value for alias_id */
    public int getAlias_id() {
        return getAsNumber("alias_id", false).intValue();
    }

    /** Get value for target_type */
    public String getTarget_type() {
        return (String) get("target_type");
    }

    /** Get value for target_id */
    public int getTarget_id() {
        return getAsNumber("target_id").intValue();
    }

    /** Get value for alias_name */
    public String getAlias_name() {
        return (String) get("alias_name");
    }

    /** Get value for alias_value */
    public String getAlias_value() {
        return (String) get("alias_value");
    }

    /** Get value for created_by */
    public String getCreated_by() {
        return (String) get("created_by");
    }

    /** Get value for created */
    public String getCreated() {
        return (String) get("created");
    }

    /** Get value for alias_type */
    public String getAlias_type() {
        return (String) get("alias_type");
    }

}
