package amgen.ri.aig.cache.item;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.io.Writer;
import java.util.List;
import java.util.Map;

import javax.xml.rpc.ServiceException;
import javax.xml.transform.TransformerException;

import org.jdom.Document;
import org.jdom.JDOMException;

import amgen.ri.aig.AIGServlet;
import amgen.ri.asf.sa.uddi.BindingDetails;
import amgen.ri.asf.sa.uddi.ServiceParameter;
import amgen.ri.asf.sa.uddi.TModelDetails;

/**
 * <p>@version $Id: ServiceResultRawCacheItem.java,v 1.2 2011/06/21 17:28:58 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class ServiceResultRawCacheItem extends ServiceResultCacheItem {
    public ServiceResultRawCacheItem() {
        super();
    }

    public ServiceResultRawCacheItem(String resultKey) {
        super(resultKey);
    }

    public void setResults(byte[] resultDocument) {
        setCacheObject(resultDocument);
    }

    public Document getResultAsDocument() {
        throw new IllegalArgumentException("Request not valid for result type");
    }

    /**
     * This assumes the result is a Serialized Object byte array, deserializes
     * it into an Object, and returns it.
     *
     * @return Object
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public Object getAsObject() throws IOException, ClassNotFoundException {
        byte[] resultBytes = (byte[]) getCacheObject();
        ByteArrayInputStream is = new ByteArrayInputStream(resultBytes);
        ObjectInputStream oip = new ObjectInputStream(is);
        Object object = oip.readObject();
        oip.close();
        is.close();
        return object;
    }

    /**
     * Transforms the result into the format specified by the binding tModel
     * type optionally including the default parameters
     *
     * @param requestor AIGServlet
     * @param resultTypeName String
     * @param parameters List
     * @param includeDefaultParams boolean
     * @return Document
     * @throws IOException
     * @throws TransformerException
     * @throws ServiceException
     */
    public Document transformResult(AIGServlet requestor, String resultTypeName, List<ServiceParameter> parameters, boolean includeDefaultParams) throws IOException, TransformerException,
            ServiceException {
        throw new IllegalArgumentException("Request not valid for result type");
    }

    /**
     * Transforms the result into the format specified by the binding tModel type
     *
     * @param resultTypeName String
     * @return Document
     * @throws IOException
     * @throws TransformerException
     * @throws ServiceException
     */
    public Document transformResult(AIGServlet requestor, String resultTypeName, List<ServiceParameter> parameters) throws IOException, TransformerException, ServiceException {
        throw new IllegalArgumentException("Request not valid for result type");
    }

    /**
     * Transforms the result into the format specified by the binding writing to
     * a Writer
     *
     * @param resultBinding BindingDetails
     * @param parameters Map
     * @param writer Writer
     * @throws IOException
     * @throws TransformerException
     * @throws JDOMException
     */
    public void transformResult(AIGServlet requestor, BindingDetails resultBinding, Map<String, String> parameters, Map<String, String> transformerOutputProperties, Writer writer) throws IOException,
            TransformerException, JDOMException {
        throw new IllegalArgumentException("Request not valid for result type");
    }

    /**
     * Transforms the result into the format specified by the tModel writing to
     * a Writer
     *
     * @param tModelDetails TModelDetails
     * @param parameters Map
     * @param writer Writer
     * @throws TransformerException
     * @throws IOException
     * @throws JDOMException
     */
    public void transformResult(AIGServlet requestor, TModelDetails tModelDetails, Map<String, String> parameters, Map<String, String> transformerOutputProperties, Writer writer) throws
            TransformerException, IOException, JDOMException {
        throw new IllegalArgumentException("Request not valid for result type");
    }

    /**
     * Transforms the result into the format specified by the binding
     *
     * @param resultBinding BindingDetails
     * @return Document
     * @throws IOException
     * @throws TransformerException
     */
    public Document transformResult(AIGServlet requestor, BindingDetails resultBinding, List<ServiceParameter> parameters) throws IOException, TransformerException {
        throw new IllegalArgumentException("Request not valid for result type");
    }


    /**
     * Transforms the result into the format specified by the binding writing to
     * a Writer
     *
     * @param resultBinding BindingDetails
     * @param parameters List
     * @param writer Writer
     * @throws IOException
     * @throws TransformerException
     * @throws JDOMException
     */
    public void transformResult(AIGServlet requestor, BindingDetails resultBinding, List<ServiceParameter> parameters, Map<String, String> transformerOutputProperties, Writer writer) throws
            IOException, TransformerException, JDOMException {
        throw new IllegalArgumentException("Request not valid for result type");
    }

    /**
     * Transforms the result into the format specified by the tModel writing to
     * a Writer
     *
     * @param tModelDetails TModelDetails
     * @param parameters List
     * @param writer Writer
     * @throws TransformerException
     * @throws IOException
     * @throws JDOMException
     */
    public void transformResult(AIGServlet requestor, TModelDetails tModelDetails, List<ServiceParameter> parameters, Map<String, String> transformerOutputProperties, Writer writer) throws
            TransformerException, IOException, JDOMException {
        throw new IllegalArgumentException("Request not valid for result type");
    }

    /**
     * Check if a transform is required baded on the ServiceDetails default
     * result type
     *
     * @param targetResultBinding BindingDetails
     * @return boolean
     */
    private boolean requiresTransform(BindingDetails targetResultBinding) {
        throw new IllegalArgumentException("Request not valid for result type");
    }


    public void write(OutputStream out) throws IOException {
        if (getCacheString() != null) {
            out.write(getCacheString().getBytes());
            out.flush();
        }
    }

    public void write(Writer writer) throws IOException {
        if (getCacheString() != null) {
            writer.write(getCacheString());
            writer.flush();
        }
    }

}
