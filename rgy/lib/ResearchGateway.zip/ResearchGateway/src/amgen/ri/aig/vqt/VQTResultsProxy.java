/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.vqt;

import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.entitytable.proxy.EntityTableProxy;
import amgen.ri.aig.viz.VisualizationResultsProxy;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 *
 * @author jemcdowe
 */
public class VQTResultsProxy implements Serializable {
  private EntityTableProxy entityTableProxy;
  private VisualizationResultsProxy visualizationResultsProxy;

  private int queryRunID;
  private String entityTypeCode;
  private EntityListCategory entityTableType;
  private String createdBy;
  private int createdByPersonID;
  private Timestamp dateCreated;
  private Timestamp dateFinished;
  private int errorID;

  public VQTResultsProxy(int queryRunID) {
    this.queryRunID = queryRunID;
  }

  /**
   * @return the entityTableProxy
   */
  public EntityTableProxy getEntityTableProxy() {
    return entityTableProxy;
  }

  /**
   * @param entityTableProxy the entityTableProxy to set
   */
  public void setEntityTableProxy(EntityTableProxy entityTableProxy) {
    this.entityTableProxy = entityTableProxy;
  }

  /**
   * @return the visualizationResultsProxy
   */
  public VisualizationResultsProxy getVisualizationResultsProxy() {
    return visualizationResultsProxy;
  }

  /**
   * @param visualizationResultsProxy the visualizationResultsProxy to set
   */
  public void setVisualizationResultsProxy(VisualizationResultsProxy visualizationResultsProxy) {
    this.visualizationResultsProxy = visualizationResultsProxy;
  }

  /**
   * @return the queryRunID
   */
  public int getQueryRunID() {
    return queryRunID;
  }

  /**
   * @return the entityTypeCode
   */
  public String getEntityTypeCode() {
    return entityTypeCode;
  }

  /**
   * @param entityTypeCode the entityTypeCode to set
   */
  public void setEntityTypeCode(String entityTypeCode) {
    this.entityTypeCode = entityTypeCode;
    this.entityTableType = getEntityListCategoryFromEntityTypeCode(entityTypeCode);
  }

  /**
   * @return the entityTableType
   */
  public EntityListCategory getEntityTableType() {
    return entityTableType;
  }

  /**
   * @param creatorUsername the creatorUsername to set
   */
  public void setCreatedBy(String createdBy, int createdByPersonID) {
    this.createdBy = createdBy;
    this.createdByPersonID = createdByPersonID;
  }

  /**
   * @return the createdBy
   */
  public String getCreatedBy() {
    return createdBy;
  }

  /**
   * @return the createdByPersonID
   */
  public int getCreatedByPersonID() {
    return createdByPersonID;
  }

  /**
   * @return the dateCreated
   */
  public Timestamp getDateCreated() {
    return dateCreated;
  }

  /**
   * @param dateCreated the dateCreated to set
   */
  public void setDateCreated(Timestamp dateCreated) {
    this.dateCreated = dateCreated;
  }

  /**
   * @return the dateFinished
   */
  public Timestamp getDateFinished() {
    return dateFinished;
  }

  /**
   * @param dateFinished the dateFinished to set
   */
  public void setDateFinished(Timestamp dateFinished) {
    this.dateFinished = dateFinished;
  }

  /**
   * @return the errorID
   */
  public int getErrorID() {
    return errorID;
  }

  /**
   * @param errorID the errorID to set
   */
  public void setErrorID(int errorID) {
    this.errorID = errorID;
  }

  /**
   * Converts the VQT entity type code to an RG EntityListCategory enum
   *
   * @param entityTypeCode String
   * @return EntityListCategory
   */
  protected EntityListCategory getEntityListCategoryFromEntityTypeCode(String entityTypeCode) {
    if (entityTypeCode != null) {
      if (entityTypeCode.equals("SM_LOT")) {
        return EntityListCategory.SUBSTANCES;
      }
      if (entityTypeCode.equals("PERSON")) {
        return EntityListCategory.PEOPLE;
      }
      if (entityTypeCode.equals("ASSAY")) {
        return EntityListCategory.ASSAYS;
      }
      if (entityTypeCode.equals("PROJECT")) {
        return EntityListCategory.PROJECTS;
      }
      if (entityTypeCode.equals("COMPOUND")) {
        return EntityListCategory.COMPOUNDS;
      }
      if (entityTypeCode.equals("CCRUN")) {
        return EntityListCategory.CELL_CULTURE_RUNS;
      }
      if (entityTypeCode.equals("SMR_MOLECULE")) {
        return EntityListCategory.SMR_MOLECULES;
      }
      if (entityTypeCode.equals("GENE")) {
        return EntityListCategory.AMGEN_GENES;
      }
      if (entityTypeCode.equals("EXPR_SYS")) {
        return EntityListCategory.LMR_EXPRESSION_SYSTEMS;
      }
      if (entityTypeCode.equals("PROTEIN_LOT")) {
        return EntityListCategory.LMR_PROTEIN_LOTS;
      }
      if (entityTypeCode.equals("LMR_HARVEST")) {
        return EntityListCategory.LMR_HARVESTS;
      }
      if (entityTypeCode.equals("LMR_CONSTR")) {
        return EntityListCategory.LMR_CONSTRUCTS;
      }
      if (entityTypeCode.equals("LMR_SEQSET")) {
        return EntityListCategory.LMR_SEQUENCE_SETS;
      }
      if (entityTypeCode.equals("LMR_SEQUENCE")) {
        return EntityListCategory.LMR_RECOMBINANT_SEQUENCES;
      }
      if (entityTypeCode.equals("LMR_REQUEST")) {
        return EntityListCategory.LMR_REQUESTS;
      }
      if (entityTypeCode.equals("OMICS_DS")) {
        return EntityListCategory.OMICS_DATASETS;
      }
      if (entityTypeCode.equals("LM_ENTITY")) {
        return EntityListCategory.LARGE_MOLECULES;
      } 
      if (entityTypeCode.equals("LM_LOT")) {
        return EntityListCategory.MODIFIED_LARGE_MOLECULES;
      }      
    }
    return EntityListCategory.UNKNOWN;
  }

}
