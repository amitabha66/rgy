package amgen.ri.aig.jmx;

/**
 * <p>
 * @version $Id: RGAppManagerMBean.java,v 1.2 2014/07/08 15:51:49 jemcdowe Exp $</p>
 *
 * <p>
 * </p>
 *
 * <p>
 * </p>
 *
 * <p>
 * </p> not attributable
 */
public interface RGAppManagerMBean {

  public void refreshServiceCache();

  public void deleteCache(String cacheType);

  public String getServiceCacheStats();

}
