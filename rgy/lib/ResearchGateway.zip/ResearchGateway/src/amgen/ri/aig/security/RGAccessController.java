package amgen.ri.aig.security;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletContext;

import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.sql.RGSQLProvider;
import amgen.ri.ldap.AmgenEnterpriseEntry;
import amgen.ri.oracle.OraConnectionManager;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.servlet.SessionLogin;
import amgen.ri.sql.SQLProvider;
import amgen.ri.util.ExtString;

/**
 * @version $Id: RGAccessController.java,v 1.16 2015/03/24 21:14:27 jemcdowe Exp $
 */
public class RGAccessController {

  private Set<String> disallowedUserLogins;
  private Set<String> disallowedOrgUnitNumbers;
  private Set<String> allowedUserLogins;
  private Set<String> allowedOrgUnitNumbers;
  private Set<Integer> allowedCostCenterNumbers;
  private Set<Integer> disallowedCostCenterNumbers;
  private RGAccessStatus defaultAccess;
  private ExtIDType grantedType;
  private ExtIDType deniedType;

  enum ExtIDType {

    ORG_UNIT_NUMBER, COST_CENTER_NUMBER, AMGEN_LOGIN, UNKNOWN;

    public static ExtIDType fromString(String s) {
      try {
        return valueOf(s);
      } catch (Exception e) {
        return UNKNOWN;
      }
    }
  };

  public RGAccessController() {
    super();
    defaultAccess = RGAccessStatus.GRANTED;
    SQLProvider sqlProvider = new RGSQLProvider();
    this.disallowedUserLogins = new HashSet<String>();
    this.disallowedOrgUnitNumbers = new HashSet<String>();
    this.allowedUserLogins = new HashSet<String>();
    this.allowedOrgUnitNumbers = new HashSet<String>();
    this.allowedCostCenterNumbers = new HashSet<Integer>();
    this.disallowedCostCenterNumbers = new HashSet<Integer>();

    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC + "");
      ResultSet rset = OraSQLManager.executeQuery(conn, sqlProvider.getSQLQuery("default_access_control"));
      if (rset.next()) {
        defaultAccess = RGAccessStatus.fromString(rset.getString("ACCESS_TYPE"));
      }
      rset.close();

      rset = OraSQLManager.executeQuery(conn, sqlProvider.getSQLQuery("access_control"));
      while (rset.next()) {
        String accessControlExtid = rset.getString("ACCESS_CONTROL_EXTID");
        ExtIDType extidType = ExtIDType.fromString(rset.getString("EXTID_TYPE"));
        RGAccessStatus accessType = RGAccessStatus.fromString(rset.getString("ACCESS_TYPE"));

        switch (extidType) {
          case ORG_UNIT_NUMBER:
            switch (accessType) {
              case GRANTED:
                allowedOrgUnitNumbers.add(accessControlExtid.toLowerCase());
                break;
              case DENIED:
                disallowedOrgUnitNumbers.add(accessControlExtid.toLowerCase());
                break;
            }
            break;
          case COST_CENTER_NUMBER:
            if (ExtString.isAInteger(accessControlExtid)) {
              switch (accessType) {
                case GRANTED:
                  allowedCostCenterNumbers.add(ExtString.toInteger(accessControlExtid));
                  break;
                case DENIED:
                  disallowedCostCenterNumbers.add(ExtString.toInteger(accessControlExtid));
                  break;
              }
            }
            break;
          case AMGEN_LOGIN:
            switch (accessType) {
              case GRANTED:
                allowedUserLogins.add(accessControlExtid.toLowerCase());
                break;
              case DENIED:
                disallowedUserLogins.add(accessControlExtid.toLowerCase());
                break;
            }
            break;
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);
    }
  }

  public RGAccessStatus processAccessStatus(SessionLogin sessionLogin) {
    return processAccessStatus(sessionLogin.getAmgenEnterpriseEntry());
  }

  public RGAccessStatus processAccessStatus(AmgenEnterpriseEntry amgenEnterpriseEntry) {
    // Start with any disallows
    if (disallowedUserLogins.size() > 0) {
      if (disallowedUserLogins.contains(amgenEnterpriseEntry.getUid().toLowerCase())) {
        deniedType = ExtIDType.AMGEN_LOGIN;
        return RGAccessStatus.DENIED;
      }
    }
    // Allowed users lists
    if (allowedUserLogins.size() > 0) {
      if (allowedUserLogins.contains(amgenEnterpriseEntry.getUid().toLowerCase())) {
        grantedType = ExtIDType.AMGEN_LOGIN;
        return RGAccessStatus.GRANTED;
      }
    }

    //Disallowed Org Units
    if (disallowedOrgUnitNumbers.size() > 0) {
      for (String disallowedOrgUnitNumber : disallowedOrgUnitNumbers) {
        if (amgenEnterpriseEntry.isInOrgUnit(disallowedOrgUnitNumber)) {
          deniedType = ExtIDType.ORG_UNIT_NUMBER;
          return RGAccessStatus.DENIED;
        }
      }
    }
    //Disallowed Cost Centers Units
    if (disallowedCostCenterNumbers.size() > 0) {
      for (int disallowedCostCenterNumber : disallowedCostCenterNumbers) {
        if (amgenEnterpriseEntry.isInCostCenter(disallowedCostCenterNumber)) {
          deniedType = ExtIDType.COST_CENTER_NUMBER;
          return RGAccessStatus.DENIED;
        }
      }
    }

    if (amgenEnterpriseEntry.isEmployeeOnStaff()) {
      //Allow Cost Centers Units
      if (allowedCostCenterNumbers.size() > 0) {
        for (int allowedCostCenterNumber : allowedCostCenterNumbers) {
          if (amgenEnterpriseEntry.isInCostCenter(allowedCostCenterNumber)) {
            grantedType = ExtIDType.COST_CENTER_NUMBER;
            return RGAccessStatus.GRANTED;
          }
        }
      }
      //Allow Org Units
      if (allowedOrgUnitNumbers.size() > 0) {
        for (String allowedOrgUnitNumber : allowedOrgUnitNumbers) {
          if (amgenEnterpriseEntry.isInOrgUnit(allowedOrgUnitNumber)) {
            grantedType = ExtIDType.ORG_UNIT_NUMBER;
            return RGAccessStatus.GRANTED;
          }
        }
      }
    }
    deniedType = ExtIDType.UNKNOWN;

    return (defaultAccess.equals(RGAccessStatus.UNKNOWN) ? RGAccessStatus.DENIED : defaultAccess);
  }

  public static void main(String[] args) throws Exception {
    //OraConnectionManager.addConnectionPool(JDBCNamesType.AIG_JDBC + "", "jdbc:oracle:thin:aigdev/!potB9ytCgPE=@ussf-tdbx-ddb01:1521:SFDSC01T.amgen.com");
    OraConnectionManager.addConnectionPool(JDBCNamesType.RG_JDBC + "", "jdbc:oracle:thin:rg/!EXPY3VRLqYrzPUobV7w0kQ==@uslv-pdbx-ora13.amgen.com:1771:lv0630p.amgen.com");

    testAccess("bsilva");
  }

  private static void testAccess(String username) {
    RGAccessController rgAccessController = new RGAccessController();
    AmgenEnterpriseEntry[] entries = new AmgenEnterpriseEntry[]{
      new AmgenEnterpriseEntry(username),};

    for (AmgenEnterpriseEntry entry : entries) {
      List<AmgenEnterpriseEntry> managerChain = new ArrayList<AmgenEnterpriseEntry>();
      List<String> managerLedgerChain = new ArrayList<String>();
      AmgenEnterpriseEntry manager = entry.getManager();
      while (manager != null) {
        managerChain.add(manager);
        managerLedgerChain.add(manager.getLedgerName());
        if (manager.getManagerUniqueIdentifier().equals(manager.getUniqueIdentifier())) {
          break;
        }
        manager = manager.getManager();
      }

      System.out.printf("%s (%s)- %s\n%s (Granted: %s, Denied: %s)\n%s\n%s\n%s\n%s\n%s\n%s\n\n", new Object[]{
        entry.getLedgerName(),
        entry.getUid(),
        entry.getAmgenLocationCode(),
        rgAccessController.processAccessStatus(entry).toString(),
        rgAccessController.grantedType + "",
        rgAccessController.deniedType + "",
        "SupervisorNameChain: " + ExtString.join(entry.getSupervisorNameChain(), "/"),
        "ManagerLedgerChain: " + ExtString.join(managerLedgerChain, "/"),
        "OrgUnitNameChain: " + ExtString.join(entry.getOrgUnitNameChain(), "/"),
        "OrgUnitNumberChain: " + ExtString.join(entry.getOrgUnitNumberChain(), "/"),
        "CostCenterNameChain: " + ExtString.join(entry.getCostCenterNameChain(), "/"),
        "CostCenterNumberChain: " + ExtString.join(entry.getCostCenterNumberChain(), "/")
      });
    }
  }
}
