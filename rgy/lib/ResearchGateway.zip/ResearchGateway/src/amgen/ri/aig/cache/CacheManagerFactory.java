/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache;

import amgen.ri.aig.cache.ora.OracleCacheManager;
import amgen.ri.aig.AIGException;
import javax.servlet.http.HttpSession;

/**
 *
 * @author jemcdowe
 */
public final class CacheManagerFactory {

  private static final String RG_CACHE_KEY = "rg.cache.session.key";
  //private static CacheManagerIF cacheMgr;

  public CacheManagerFactory() {
  }

  public static CacheManagerIF getCacheManagerInstance(HttpSession session) throws AIGException {
    if (session.getAttribute(RG_CACHE_KEY) == null || !(session.getAttribute(RG_CACHE_KEY) instanceof CacheManagerIF)) {
      session.setAttribute(RG_CACHE_KEY, new CacheManager(session));
    }
    return (CacheManagerIF) session.getAttribute(RG_CACHE_KEY);
  }
  /**
   * Returns a CacheManagerIF for a specific session. USED ONLY FOR ServiceResultCacheRetrieval requests
   * @param sessionID
   * @return
   * @throws AIGException 
   */
  public static CacheManagerIF getCacheManagerInstance(String sessionID) throws AIGException {    
    return new CacheManager(sessionID);
  }  

  public static CacheManagerIF getOracleCacheManagerInstance(String requestUser) throws AIGException {
    return new OracleCacheManager(requestUser);
  }

}
