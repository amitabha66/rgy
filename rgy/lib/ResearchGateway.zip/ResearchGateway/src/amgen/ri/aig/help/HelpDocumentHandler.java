package amgen.ri.aig.help;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jdom.Document;
import org.jdom.Element;

import amgen.ri.aig.AIGServlet;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.json.JSONObject;
import amgen.ri.xml.ExtXMLElement;

/**
 * <p>@version $Id: HelpDocumentHandler.java,v 1.3 2011/10/24 22:53:07 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class HelpDocumentHandler extends AIGServlet {
    public HelpDocumentHandler() {
        super();
    }

    public HelpDocumentHandler(HttpServletRequest req, HttpServletResponse resp) {
        super(req, resp);
    }

    public HelpDocumentHandler(AIGServlet aigServlet) {
        super(aigServlet);
    }

    /**
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return TBXServlet
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new HelpDocumentHandler(req, resp);
    }

    /**
     *
     * @return String
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected String getServletMimeType() {
        return "text/json";
    }

    /**
     *
     * @throws Exception
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected void performRequest() throws Exception {
        String helpTipsFile = ConfigurationParameterSource.getConfigParameter("HELP_TIPS_DOCUMENT");
        helpTipsFile = context.getRealPath(helpTipsFile);
        Document helpTipsDoc = ExtXMLElement.fromFile(helpTipsFile);
        if (helpTipsDoc != null) {
            Element tipEl = ExtXMLElement.getXPathElement(helpTipsDoc, "//HelpTip[@tip_id='" + getParameter("tip_id") + "']");
            if (tipEl != null) {
                JSONObject tipObj = new JSONObject();
                tipObj.put("title", tipEl.getAttributeValue("title"));
                tipObj.put("doc", tipEl.getText());
                tipObj.write(response.getWriter());
            }
        }
    }
}
