package amgen.ri.aig.constants;

import java.util.HashMap;
import java.util.Map;


/**
 * Research Gateway-wide constants
 *
 * @version $Id: Constants.java,v 1.10 2013/04/18 23:04:26 jemcdowe Exp $
 */
public class Constants {    
    public static final String FILE_UPLOAD_DIRECTORY = "FILE_UPLOAD_DIRECTORY";
    public static final String SIMPLE_DATE_PATTERN = "MM/dd/yyyy h:m:s a";
    public static final String ENHANCED_DATE_PATTERN = "EEE, d MMM yyyy HH:m:s";

    public static final String RSS_DATE_PATTERN1 = "EEE, dd MMM yyyy HH:mm:ss z";
    public static final String RSS_DATE_PATTERN2 = "dd MMM yyyy HH:mm:ss z";

    public static final String JSON_DATE_PATTERN = "MM/dd/yyyy hh:mm:ss a";
    
    public static final String DEFAULT_WIDGET_ICON= "ix-v0-48-environment_network";
}
