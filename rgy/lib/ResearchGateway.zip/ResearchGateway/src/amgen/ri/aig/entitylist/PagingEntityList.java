package amgen.ri.aig.entitylist;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.RdbData;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.rdb.SQLManagerIF;

/**
 * An EntityList which allows for paging through the members rather than
 * pulling all into memory
 */
public class PagingEntityList extends RdbData implements Serializable {
    protected int list_id;
    protected String name;
    protected String description;
    protected String list_category;
    protected Timestamp created;
    protected String created_by;
    protected Timestamp modified;
    protected String modified_by;
    protected String list_type;

    private int currentIndex;
    private int listSize;
    private EntityListMemberIF currentEntityListMember;

    private String orderByField;
    private boolean orderByAscending;


    public PagingEntityList() {
        super();
        listSize = 0;
        currentIndex = 0;
    }

    /**
     * RdbData Constructor
     */
    public PagingEntityList(String list_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        super(sqlManager, logonusername, connectionPool);
        this.list_id = Integer.valueOf(list_id);
        listSize = 0;
        currentIndex = 0;
        this.orderByField = null;
        this.orderByAscending = true;
    }

    /**
     * RdbData Constructor
     */
    public PagingEntityList(String list_id, String orderByField, boolean ascending, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
        this(list_id, sqlManager, logonusername, connectionPool);
        this.orderByField = orderByField;
        this.orderByAscending = ascending;
    }


    /** A required method which returns the primary key(s) of the table/RdbData class. */
    public String getIdentifier() {
        return list_id + "";
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
        field.set(this, value);
    }

    /** This method is required EXACTLY as written to allow the RdbData architecture access to the class variables. */
    protected Object getFieldValue(Field field) throws IllegalAccessException {
        return field.get(this);
    }

    /** This method returns the name of the table. */
    protected String getTableName() {
        return "ENTITY_LIST";
    }

    /**
     * Ovverrides the dataSet listener to set the listSize
     * @param success boolean
     */
    protected void dataSet(boolean success) {
        listSize = 0;
        currentIndex = 0;
        if (!success) {
            return;
        }
        try {
            ResultSet rset = getSQLManager().executeQuery("SELECT COUNT(ENTITY_LIST_MEMBER_ID) FROM ENTITY_LIST_MEMBERS WHERE LIST_ID=?",
                    getIdentifier(), getConnectionPool());
            if (rset.next()) {
                listSize = rset.getInt(1);
            }
            OraSQLManager.closeResources(rset);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    /** Get value for list_id */
    public int getList_id() {
        return list_id;
    }

    /** Get value for name */
    public String getName() {
        return (String) get("name");
    }

    /** Get value for description */
    public String getDescription() {
        return (String) get("description");
    }

    /** Get value for list_type */
    public String getListType() {
        return (String) get("list_type");
    }


    /** Gets the number of members */
    public int getMemberCount() {
        return listSize;
    }

    /** Get value for created */
    public Timestamp getCreated() {
        return (Timestamp) get("created");
    }

    /** Get value for created_by */
    public String getCreated_by() {
        return (String) get("created_by");
    }

    /** Get value for modified */
    public Timestamp getModified() {
        return (Timestamp) get("modified");
    }

    /**
     * Finds the index of the given member id.
     * NOTE: This is a zero-based index.
     *
     * @param member String
     * @return int
     */
    public int findIndex(String member) {
        int index = -1;
        try {
            String orderByClause = "";
            if (orderByField != null) {
                orderByClause = " order by " + orderByField + (orderByAscending ? " ASC " : " DESC ");
            }

            String sql =
                    "select rnum from ( select /*+ FIRST_ROWS(n) */ a.*, ROWNUM rnum " +
                    "from (SELECT member FROM ENTITY_LIST_MEMBERS WHERE list_id=? "
                    + orderByClause +
                    ") a) " +
                    "where member=?";
            SQLManagerIF sqlManager = new OraSQLManager();
            ResultSet rset = sqlManager.executeQuery(sql,
                    new String[] {getIdentifier(), member}, getConnectionPool());
            if (rset.next()) {
                index = rset.getInt(1) - 1;
            }
            OraSQLManager.closeResources(rset);
        } catch (Exception e) {}
        return index;
    }

    /**
     * Returns the current index of the stack
     *
     * NOTE: This is a zero-based index.
     * @return int
     */
    public int getCurrentIndex() {
        return currentIndex;
    }

    /**
     * Returns the orderBy field or null if none
     *
     * @return String
     */
    public String getOrderByField() {
        return orderByField;
    }

    /**
     * Whether the order is ascending or descending
     *
     * @return boolean
     */
    public boolean isOrderByAscending() {
        return orderByAscending;
    }

    /**
     * Returns the current EntityListMemberIF member in the stack
     *
     * @return EntityListMemberIF
     */
    public EntityListMemberIF current() {
        setData();
        if (currentEntityListMember != null) {
            return currentEntityListMember;
        }
        return get(currentIndex);
    }

    /**
     * Returns the next EntityListMemberIF member in the stack
     *
     * @return EntityListMemberIF
     */
    public EntityListMemberIF next() {
        return get(currentIndex + 1);
    }

    /**
     * Returns the previous EntityListMemberIF member in the stack
     *
     * @return EntityListMemberIF
     */
    public EntityListMemberIF previous() {
        return get(currentIndex - 1);
    }

    /**
     * Returns the first EntityListMemberIF member in the stack
     *
     * @return EntityListMemberIF
     */
    public EntityListMemberIF first() {
        return get(0);
    }

    /**
     * Returns the last EntityListMemberIF member in the stack
     *
     * @return EntityListMemberIF
     */
    public EntityListMemberIF last() {
        return get(listSize - 1);
    }

    /**
     * Returns a specific EntityListMemberIF member in the stack
     *
     * NOTE: This is a zero-based index.
     * @return EntityListMemberIF
     */
    public EntityListMemberIF get(int index) {
        if (!validIndex(index)) {
            return null;
        }
        String replacementIndex = (index + 1) + "";
        String orderByClause = "";
        if (orderByField != null) {
            orderByClause = " order by " + orderByField + (orderByAscending ? " ASC " : " DESC ");
        }

        String memberIndexSQL =
                "select entity_list_member_id from ( select /*+ FIRST_ROWS(n) */ a.*, ROWNUM rnum " +
                "from (SELECT entity_list_member_id FROM ENTITY_LIST_MEMBERS WHERE list_id=? " +
                orderByClause +
                ") a " +
                "where ROWNUM <=?) where rnum  >= ?";

        List<EntityListMember> array = new RdbDataArray(EntityListMember.class,
                memberIndexSQL, new String[] {
            getIdentifier(), replacementIndex, replacementIndex
        },
                getSQLManager(), null, getConnectionPool());
        currentIndex = index;
        currentEntityListMember = (array.size() > 0 ? array.get(0) : null);
        return currentEntityListMember;
    }

    /**
     * Searches for list members using the given substring and the stem of the
     * member ids. e.g. 1234 will find 111234, 2221234, 1234, 91234,...
     *
     * @param query String
     * @return List
     */
    public List<EntityListMemberIF> searchForMembersByStem(String query) {
        String sql = "SELECT ENTITY_LIST_MEMBER_ID FROM ENTITY_LIST_MEMBERS " +
                     " WHERE LIST_ID=? AND MEMBER LIKE '%" + query + "'";
        return new RdbDataArray(EntityListMember.class,
                                sql, new String[] {
            getIdentifier()
        }, getSQLManager(), null, getConnectionPool());
    }

    /**
     * Returns whether there is a next EntityListMemberIF member in the stack
     *
     * @return boolean
     */
    public boolean hasNext() {
        int index = currentIndex + 1;
        return validIndex(index);
    }

    /**
     * Returns  whether there is a previous EntityListMemberIF member in the stack
     *
     * @return boolean
     */
    public boolean hasPrevious() {
        int index = currentIndex - 1;
        return validIndex(index);
    }

    /**
     * Returns the next index is valid for the stack
     *
     * NOTE: This is a zero-based index.
     * @return boolean
     */
    public boolean validIndex(int index) {
        return (index >= 0 && index < listSize);
    }

}
