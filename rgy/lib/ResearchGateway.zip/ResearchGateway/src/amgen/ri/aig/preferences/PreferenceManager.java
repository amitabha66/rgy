package amgen.ri.aig.preferences;

import java.util.List;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.servlet.SessionLogin;
import java.util.ArrayList;

/**
 * Sets the preferences for a PreferenceableIF object for a given user.
 *
 * @version $Id: PreferenceManager.java,v 1.5 2013/04/18 23:04:26 jemcdowe Exp $
 */
public class PreferenceManager {
  public static String RGPREFERENCE_BY_GROUP_SQL =
          "SELECT RGP.RG_PREFERENCE_ID  "
          + "FROM RG_PREFERENCE_GROUP RGPG, RG_PREFERENCES RGP  "
          + "WHERE RGP.RG_PREFERENCE_GROUP_ID= RGPG.RG_PREFERENCE_GROUP_ID "
          + "AND  RGPG.PREFERENCE_GROUP= ?";
  private SessionLogin sessionLogin;
  private PreferenceableIF preferenceable;
  private Exception lastException;

  /**
   * Creates a new PreferenceManager from an AIGBase servlet
   *
   * @param servlet AIGBase
   * @param preferenceable PreferenceableIF
   */
  public PreferenceManager(AIGBase servlet, PreferenceableIF preferenceable) {
    try {
      this.sessionLogin = servlet.getSessionLogin();
    } catch (Exception ex) {
      ex.printStackTrace();
      lastException = ex;
    }
    this.preferenceable = preferenceable;
  }

  /**
   * Creates a PreferenceManager for a SessionLogin
   *
   * @param sessionLogin SessionLogin
   * @param preferenceable PreferenceableIF
   */
  public PreferenceManager(SessionLogin sessionLogin, PreferenceableIF preferenceable) {
    this.sessionLogin = sessionLogin;
    this.preferenceable = preferenceable;
  }

  /**
   * Returns the PreferenceableIF object
   *
   * @return PreferenceableIF
   */
  public PreferenceableIF getPreferenceable() {
    return preferenceable;
  }

  /**
   * Returns the last Exception captured by the PreferenceManager. null if none.
   *
   * @return Exception
   */
  public Exception getLastException() {
    return lastException;
  }

  /**
   * Sets the Preferences on the PreferenceableIF object
   *
   * @return boolean
   */
  public boolean setPreferences() {
    if (preferenceable == null) {
      return false;
    }
    try {
      List<RGPreference> rgPreferences = getPreferences();

      for (PreferenceIF preference : rgPreferences) {
        preferenceable.setPreference(preference);
      }
    } catch (Exception e) {
      lastException = e;
      e.printStackTrace();
      return false;
    }
    return true;
  }

  /**
   * Returns the Preferences for this PreferenceableIF object
   *
   * @return List<RGPreference>
   */
  public List<RGPreference> getPreferences() {
    if (preferenceable == null) {
      return new ArrayList<RGPreference>();
    }
    try {
      return new RdbDataArray(RGPreference.class, RGPREFERENCE_BY_GROUP_SQL, new String[]{
                preferenceable.getPreferenceGroup()
              }, new OraSQLManager(), sessionLogin.getRemoteUser(), JDBCNamesType.RG_JDBC+"");

    } catch (Exception e) {
      lastException = e;
      e.printStackTrace();
    }
    return new ArrayList<RGPreference>();
  }

  /**
   * Returns the RGPreference for this PreferenceableIF object
   *
   * @return PreferenceIF
   */
  public PreferenceIF getPreference(String name) {
    for (PreferenceIF preference : getPreferences()) {
      if (preference.getPreferenceName().equals(name)) {
        return preference;
      }
    }
    return null;
  }
}
