package amgen.ri.aig;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jdom.Document;

import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.aig.jawr.FileSetManager;
import amgen.ri.aig.preferences.PreferenceManager;
import amgen.ri.aig.preferences.PreferenceableIF;
import amgen.ri.aig.preferences.RGPreference;
import amgen.ri.aig.preferences.UserPreference;
import amgen.ri.aig.security.AIGSessionLogin;
import amgen.ri.html.GenericHTMLElement;
import amgen.ri.html.HTMLElement;
import amgen.ri.html.Image;
import amgen.ri.html.Table;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.servlet.ServletBase;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.lang.reflect.Constructor;

/**
 * Defines a base class for all servlet classes in AIG
 */
public abstract class AIGServlet extends AIGBase {
  public enum ExtJSVersion {
    VERSION_2,
    VERSION_3,
    VERSION_4
  };
  protected HttpServletResponse response;
  protected FileSetManager fileSetManager;

  /**
   * Default constructor
   */
  public AIGServlet() {
    super();
  }

  /**
   * Standard constructor whcih creates a new AIGServlet
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   */
  public AIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    super(req);
    this.response = resp;
    try {
      this.fileSetManager = new FileSetManager(req);
    } catch (FileNotFoundException ex1) {
      ex1.printStackTrace();
    }
    try {
      this.response.setCharacterEncoding("UTF-8");
    } catch (Exception ex) {
    }
    if (this instanceof PreferenceableIF) {
      new PreferenceManager(this, (PreferenceableIF) this).setPreferences();
    }
  }

  /**
   * Standard constructor which creates a new AIGServlet from an existing
   * AIGServlet
   *
   * @param aigServlet HttpServletRequest
   */
  public AIGServlet(AIGServlet aigServlet) {
    this(aigServlet.request, aigServlet.response);
  }

  /**
   * Overrides the POST method- instantiating the AIGServlet class and calling
   * performRequest
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @throws ServletException
   * @throws IOException
   */
  protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    AIGServlet servlet = getAIGServlet(req, resp);
    String servletMimeType = servlet.getServletMimeType();
    if (servletMimeType != null) {
      if (servlet.getServletMimeType().equals("text/html")) {
        servlet.setNoCache();
      }
      servlet.response.setContentType(servlet.getServletMimeType());
    }
    try {
      servlet.performRequest();
    } catch (AIGException e) {
      System.err.println("AIG Exception: " + e.getReason() + " caused by " + e.getCause());
      throw new ServletException(e);
    } catch (Exception e) {
      throw new ServletException(e);
    }
  }

  /**
   * Returns the getAIGServlet implementation class for the request, The default implementation uses reflection to instantiate
   * the current Class
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return TBXServlet
   */
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    try {
      Constructor constructor = getClass().getConstructor(new Class[]{HttpServletRequest.class, HttpServletResponse.class});
      return (AIGServlet) constructor.newInstance(new Object[]{req, resp});
    } catch (Exception ex) {
      ex.printStackTrace();
    }
    return null;
  }

  /**
   * Actual work entry stub
   *
   * @throws ServletException
   * @throws IOException
   */
  protected abstract void performRequest() throws Exception;

  /**
   * Returns the mimetype of the servlet
   */
  protected abstract String getServletMimeType();

  /**
   * Sets all the please do not cache directives
   */
  protected void setNoCache() {
    setNoCache(response);
  }

  /**
   * Sets all the please do not cache directives
   */
  public void setNoCache(HttpServletResponse response) {
    response.setHeader("Pragma", "No-cache");
    response.setHeader("Cache-Control", "no-cache");
    response.setDateHeader("Expires", 0);
  }

  public HttpServletResponse getHttpServletResponse() {
    return response;
  }

  /**
   * Adds an error header to the HTTP response
   *
   * @param e
   */
  public void createErrorHttpResponseHeader(Throwable t) {
    response.addHeader("RG_ERROR", t.getMessage());
  }

  /**
   * Adds an error header to the HTTP response and sends an error to the
   * response
   *
   * @param e
   */
  public void sendErrorHttpResponseHeader(Throwable t) throws IOException {
    response.addHeader("RG_ERROR", t.getMessage());
    response.sendError(HttpServletResponse.SC_BAD_REQUEST, t.getMessage());
  }

  /**
   * Creates the HTML element for an RG view. Thsi includes the HTML and HEAD
   * elements. Includes in the HEAD element are the TITLE element if title is
   * non-null and the ExtJS, Supplementals, and RG CSS imports.
   *
   * @param title String
   * @return HTMLElement
   */
  public HTMLElement createRGHTMLElement(String title, ExtJSVersion extVersion) {
    setNoCache();
    HTMLElement html = new GenericHTMLElement("HTML");
    HTMLElement head = html.addMemberElement("HEAD");
    if (title != null) {
      HTMLElement titleEl = head.addMemberElement("TITLE");
      titleEl.setText(title);
    }
    switch (extVersion) {
      case VERSION_2:
        fileSetManager.appendStyles(head, "extjscss");
        break;
      case VERSION_3:
        fileSetManager.appendStyles(head, "ext3css");
        break;
      case VERSION_4:
        fileSetManager.appendStyles(head, "ext4css");
        break;
    }
    fileSetManager.appendStyles(head, "supplemental_imports_css");
    fileSetManager.appendStyles(head, "rgcss");
    fileSetManager.appendStyles(head, "ixcss");

    return html;
  }

  /**
   * Create an HTML table describing and error
   *
   * @param icon String
   * @param title String
   * @param message String
   * @return HTMLElement
   */
  public static HTMLElement createErrorTable(String icon, String title, String message) {
    HTMLElement errorDiv = new GenericHTMLElement("DIV", "errorTable");
    Table errorTable = (Table) errorDiv.addMemberElement(new Table("errorTable"));
    Table.TableRow row = errorTable.addHeaderRow("errorTable", "errorTable");
    row.setClassName("errorTable");
    Image imageEl = (Image) row.addCell().addMemberElement(new Image("img/" + icon));
    row.addCell("errorTable").setText(title);
    row = errorTable.addRow();
    row.setClassName("errorTable");
    row.addCell();
    row.addCell("errorTable").setText(message);
    return errorDiv;
  }

  /**
   * Handles any exception that's thrown by the request
   *
   * @param ex Exception
   * @throws IOException
   */
  protected void handleException(Exception ex) throws IOException {
    HTMLElement html = new GenericHTMLElement("HTML");
    HTMLElement body = (HTMLElement) html.addMemberElement(new GenericHTMLElement("BODY"));
    HTMLElement script = (HTMLElement) body.addMemberElement(new GenericHTMLElement("SCRIPT"));
    script.setText("document.domain='amgen.com'");
    HTMLElement span = (HTMLElement) body.addMemberElement(new GenericHTMLElement("span"));
    span.setStyle("font:normal 12px tahoma,arial,helvetica,sans-serif");

    Table table = (Table) span.addMemberElement(new Table(null, "5"));
    Table.TableRow row = table.addRow();
    Table.TableCell cell = row.addCell();
    cell.addAttribute("valign", "top");
    String message = "An error occurred running your request";
    if (ex instanceof AIGException) {
      switch (((AIGException) ex).getReason()) {
        case UNABLE_TO_RUN_SERVICE:
          cell.addMemberElement(new Image("img/error.gif"));
          message = "Unable to run the service.";
          if (ex.getMessage() != null) {
            message += "<BR><I>" + ex.getMessage() + "</I>";
          }
          break;
        case NO_RESULTS:
          cell.addMemberElement(new Image("img/info.gif"));
          message = "Service returned no results.";
          break;
      }
    } else {
      cell.addMemberElement(new Image("img/error.gif"));
    }
    cell = row.addCell();
    cell.setStyle("text-align:justify;width:300px");
    cell.setText(message);
    if (getServletMimeType() == null || getServletMimeType().equals("text/html")) {
      response.getWriter().println(html);
    }
  }

  /**
   * Sends an AIG error message- sc=555
   *
   * @param ex Exception
   * @throws IOException
   */
  protected void sendExceptionResponse(Exception ex) {
    try {
      if (isIsMultiPartRequest()) {
        JSONObject jError = new JSONObject();
        JSONObject jStatus = new JSONObject();
        jError.put("status", jStatus);
        jStatus.put("code", 555);
        jStatus.put("msg", ex.getMessage());
        writeResponse(null, jError);
      } else {
        response.sendError(555, ex.getMessage());
      }
    } catch (Exception ex1) {
      ex1.printStackTrace();
    }
  }

  protected void writeResponse(Document xml, JSONObject jObject) throws JSONException, IOException {
    if (isIsMultiPartRequest()) {
      JSONObject ajaxResponse = new JSONObject();
      if (xml != null) {
        ajaxResponse.put("xml", ExtXMLElement.toString(xml));
      }
      if (jObject != null) {
        ajaxResponse.put("text", jObject.toString());
      }
      HTMLElement htmlEl = new GenericHTMLElement("html");
      HTMLElement headEl = htmlEl.addMemberElement("head");
      headEl.addMemberElement("script").appendContent("document.domain='amgen.com'");
      HTMLElement bodyEl = htmlEl.addMemberElement("body");
      bodyEl.addMemberElement("script").appendContent("var ajaxResponse= " + ajaxResponse);
      response.getWriter().println(htmlEl);
    } else {
      if (xml != null) {
        ExtXMLElement.write(xml, response.getWriter());
      } else if (jObject != null) {
        jObject.write(response.getWriter());
      }
    }
  }

  /**
   * Adds the core ExtJs scripts, namespace defintion, and optional custom
   * script definitions to an HTMLElement
   *
   * @param el HTMLElement
   * @param customsScriptContextName String
   * @return HTMLElement
   */
  public HTMLElement addCoreExtJsScripts(HTMLElement el, ExtJSVersion extVersion, String customsScriptContextName) throws AIGException {
    AIGSessionLogin sessionLogin = (AIGSessionLogin) getSessionLogin();
    String rgBuild = context.getInitParameter("BUILD");

    try {
      Pattern pattern = Pattern.compile("(v[0-9]+\\.\\w+)\\s+Build: \\$Date: 2015/03/14 00:41:43 $\\s+\\$Revision: 1.13 $");
      Matcher matcher = pattern.matcher(rgBuild);
      if (matcher.find()) {
        String version = matcher.group(1);
        Date revisionDate = new java.text.SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(matcher.group(2));
        String revision = matcher.group(3);
        SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy");
        rgBuild = "Version: " + version + "<BR>Build: " + revision + " " + format.format(revisionDate);
      }
    } catch (Exception e) {
    }

    try {

      switch (extVersion) {
        case VERSION_2:
          fileSetManager.appendScripts(el, "extjs");
          break;
        case VERSION_3:
          fileSetManager.appendScripts(el, "ext3js");
          break;
        case VERSION_4:
          fileSetManager.appendScripts(el, "ext4js");
          break;
      }

      fileSetManager.appendScripts(el, "rginit");

      HTMLElement initScript = el.addMemberElement("script");
      initScript.addAttribute("type", "text/javascript");
      initScript.appendContent("var AIG_VERSION= '" + ConfigurationParameterSource.getRGVersion() + "';");
      initScript.appendContent("var RG_VERSION= '" + ConfigurationParameterSource.getRGVersion() + "';");
      initScript.appendContent("var RG_BUILD= '" + rgBuild + "';");
      initScript.appendContent("AIG.USER_SESSION_INFO= " + getSessionInfo() + ";");
      initScript.appendContent("var SUPPORT_EMAIL= '" + ConfigurationParameterSource.getConfigParameter("SUPPORT_EMAILS") + "';");

      if (customsScriptContextName != null) {
        fileSetManager.appendScripts(el, customsScriptContextName);
      }
    } catch (Exception ex) {
      ex.printStackTrace();
    }

    // addExtJsScripts(request, el, "core_scripts.ext", aigVersion);
    // if (customsScriptContextName != null) {
    // addExtJsScripts(request, el, "custom_scripts." + customsScriptContextName, aigVersion);
    // }
    return el;
  }

  /**
   * Adds the ExtJs scripts to an HTMLElement, returning the same HTMLElement
   *
   * @param el HTMLElement
   * @param scriptContextName String
   * @return HTMLElement
   */
  public HTMLElement addJsScripts(HTMLElement el, String scriptContextName) throws AIGException {
    try {
      if (scriptContextName != null) {
        fileSetManager.appendScripts(el, scriptContextName);
      }
    } catch (Exception ex) {
      ex.printStackTrace();
    }
    return el;
  }

  protected HTMLElement createNeedsParametersHTML() {
    HTMLElement html = new GenericHTMLElement("HTML");
    HTMLElement body = (HTMLElement) html.addMemberElement(new GenericHTMLElement("BODY"));
    HTMLElement script = (HTMLElement) body.addMemberElement(new GenericHTMLElement("SCRIPT"));
    script.setText("document.domain='amgen.com'");
    HTMLElement span = (HTMLElement) body.addMemberElement(new GenericHTMLElement("span"));
    span.setStyle("font:normal 12px tahoma,arial,helvetica,sans-serif");

    Table table = (Table) span.addMemberElement(new Table(null, "5"));
    Table.TableRow row = table.addRow();
    Table.TableCell cell = row.addCell();
    cell.addAttribute("valign", "top");
    cell.addMemberElement(new Image("img/service_params_needed.gif"));
    cell = row.addCell();
    cell.setStyle("text-align:justify;width:300px");
    cell.setText("Tool requires additional parameters. Please enter required parameters in Settings tab on the right and press <i>Update</i>.");
    return html;
  }

  /**
   * Returns the session login information as a JSON object
   *
   * @return JSONObject
   */
  public JSONObject getSessionInfo() {
    JSONObject sessionInfo = new JSONObject();
    try {
      AIGSessionLogin sessionLogin = (AIGSessionLogin) getSessionLogin();
      sessionInfo.put("LOGIN", sessionLogin.getRemoteUser());
      sessionInfo.put("DISPLAY_NAME", sessionLogin.getUserLedgerDisplayName());
      sessionInfo.put("IP", sessionLogin.getRemoteMachineIP());
      sessionInfo.put("LOCATION", sessionLogin.getUserAmgenLocationCode());
      sessionInfo.put("TIMEZONE", sessionLogin.getUsersTimeZone().getID());
      sessionInfo.put("SESSION_ID", sessionLogin.getSessionID());
    } catch (Exception ex) {
    }
    return sessionInfo;
  }

  /**
   * logServiceResultsDebug
   *
   * @param resultDocument String
   */
  public void logServiceResultsDebug(String resultDocument) {
    System.out.println(resultDocument);
  }

  /**
   * Saves a preference for this object.
   * This object must be an implementation of PreferenceableIF and
   * contain the provided preference identified by its name.
   *
   * @param preferenceName
   * @param preferenceValue
   * @return
   */
  public boolean savePreferences(String preferenceName, String preferenceValue) {
    if (this instanceof PreferenceableIF) {
      PreferenceManager prefManager = new PreferenceManager(this, (PreferenceableIF) this);
      RGPreference rgPreference = (RGPreference) prefManager.getPreference(preferenceName);
      if (rgPreference != null) {
        UserPreference userPreference = rgPreference.updateUserPreference(preferenceValue);
        return (userPreference.performCommit() > 0);
      }
    }
    return false;
  }
}
