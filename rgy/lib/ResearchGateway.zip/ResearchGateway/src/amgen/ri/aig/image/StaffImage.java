package amgen.ri.aig.image;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGServlet;
import amgen.ri.rg.config.ConfigurationParameterSource;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.sql.RGSQLProvider;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.sql.SQLProvider;
import amgen.ri.util.ExtString;

/**
 * <p>@version $Id: StaffImage.java,v 1.4 2013/04/18 23:04:27 jemcdowe Exp $</p>
 */
public class StaffImage extends AIGServlet {
    public StaffImage() {
        super();
    }

    public StaffImage(HttpServletRequest req, HttpServletResponse resp) {
        super(req, resp);
    }

    public StaffImage(AIGServlet aigServlet) {
        super(aigServlet);
    }

    /**
     *
     * @param req HttpServletRequest
     * @param resp HttpServletResponse
     * @return TBXServlet
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
        return new StaffImage(req, resp);
    }

    /**
     *
     * @return String
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected String getServletMimeType() {
        return "text/plain";
    }

    /**
     *
     * @throws Exception
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    protected void performRequest() throws Exception {
        String staffImageURL= getStaffImageURL(this, getParameter("login"), getParameter("personid"), getParameter("staffid"));
        response.sendRedirect(staffImageURL);
    }

    /**
     *
     * @throws Exception
     * @todo Implement this amgen.ri.aig.AIGServlet method
     */
    public String getStaffImageURL(AIGBase requestor, String login, String personID, String staffID) throws SQLException {
        SQLProvider sqlProvider = new RGSQLProvider();
        Connection conn = null;
        try {
            if (ExtString.hasLength(login) && !ExtString.equals(login, "[login]")) {
                conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC+"");
                ResultSet rset = OraSQLManager.executeQuery(conn, sqlProvider.getSQLQuery("people_staffid_from_amgenlogin"), new String[] {"login:" + login});
                if (rset.next()) {
                    staffID = rset.getString(1);
                }
            } else if (ExtString.hasLength(personID) && !ExtString.equals(personID, "[personid]")) {
                conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC+"");
                ResultSet rset = OraSQLManager.executeQuery(conn, sqlProvider.getSQLQuery("people_staffid_from_personid"), new String[] {"personid:" + personID});
                if (rset.next()) {
                    staffID = rset.getString(1);
                }
            }

            String staffImageURL = ConfigurationParameterSource.getConfigParameter("STAFF_IMAGE_URL");
            return staffImageURL.replace("[STAFF_ID]", staffID);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }
}
