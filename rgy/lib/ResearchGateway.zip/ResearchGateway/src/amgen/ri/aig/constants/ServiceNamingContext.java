package amgen.ri.aig.constants;

/**
 *
 * @author jemcdowe
 */
public enum ServiceNamingContext {
  RG_QUERY,
  RG_NODE,
  RG_RESOURCE,
  RG_COLUMN,
  RG_LOFT,
  RG_LAUNCHPAD
}
