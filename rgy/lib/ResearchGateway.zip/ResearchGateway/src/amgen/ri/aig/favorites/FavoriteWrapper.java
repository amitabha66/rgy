package amgen.ri.aig.favorites;

import java.io.Serializable;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.sobj.SaveObjectException;
import amgen.ri.aig.sobj.SaveableIF;
import amgen.ri.util.ExtObject;

/**
 * <p>@version $Id: FavoriteWrapper.java,v 1.1 2012/10/16 20:24:26 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class FavoriteWrapper implements SaveableIF {
    Serializable favoriteObject;
    private int objectType;


    public FavoriteWrapper(Serializable favoriteObject, int objectType) {
        this.favoriteObject = favoriteObject;
        this.objectType = objectType;
    }

    /**
     *
     * @return byte[]
     * @throws SaveObjectException
     */
    public byte[] getObjectBytes() throws SaveObjectException {
        try {
            return ExtObject.serializeObject(favoriteObject);
        } catch (Exception e) {
            throw new SaveObjectException("Unable to serialize table", AIGException.Reason.REQUEST_ERROR, e);
        }
    }

    /**
     *
     * @return int
     */
    public int getObjectType() {
        return objectType;
    }

}
