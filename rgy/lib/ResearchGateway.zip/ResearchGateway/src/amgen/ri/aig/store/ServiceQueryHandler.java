package amgen.ri.aig.store;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.uddi.*;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONObject;
import amgen.ri.xml.ExtXMLElement;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jdom.Document;

/**
 *
 * @author jemcdowe
 */
public class ServiceQueryHandler extends AIGServlet implements StoreRequestHandlerIF {

  public enum ServiceQueryType {

    QUERY, TABLE_SERVICES, SERVICE, RECENT, NODE_RESOURCES, SEARCH_DIALOG_RESOURCES, QUICK_SERVICES, QUICK_SEARCH_SSS, UNKNOWN;
    
    public static ServiceQueryType fromString(String s) {
      try {
        return ServiceQueryType.valueOf(s.toUpperCase());
      } catch (Exception e) {
        return UNKNOWN;
      }
    }
  };
  protected ServiceQueryType requestType;
  protected ResponseFormatType responseType;
  private ServiceLookupIF serviceLookup;
  
  public ServiceQueryHandler() {
  }
  
  public ServiceQueryHandler(AIGServlet aigServlet) {
    super(aigServlet);
    this.responseType = ResponseFormatType.fromString(aigServlet.getParameter("responseFormat"));
    this.requestType = ServiceQueryType.fromString(aigServlet.getParameter("queryType"));
  }
  
  public ServiceQueryHandler(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
    this.responseType = ResponseFormatType.fromString(getParameter("responseFormat"));
    this.requestType = ServiceQueryType.fromString(getParameter("queryType"));
  }
  
  @Override
  protected AIGServlet getAIGServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new ServiceQueryHandler(req, resp);
  }
  
  @Override
  protected void performRequest() throws Exception {
    switch (ServiceQueryType.fromString(getParameter("queryType"))) {
      case QUERY:
        serviceLookup = new QueryServiceLookup(this);
        break;
      case QUICK_SERVICES:
        serviceLookup = new QuickSearchServiceLookup(this);
        break;
      case TABLE_SERVICES:
        serviceLookup = new EntityTableColumnServiceLookup(this);
        break;
      case SERVICE:
        serviceLookup = new ServiceLookup(this);
        break;
      case RECENT:
        serviceLookup = new RecentServiceLookup(this);
        break;
      case NODE_RESOURCES:
        EntityResourcesLookup entityResourcesLookup = new EntityResourcesLookup(this);
        entityResourcesLookup.setNodeUUIDs(getParameter("query"));
        serviceLookup = entityResourcesLookup;
        break;
      case SEARCH_DIALOG_RESOURCES:
        EntityResourcesLookup searchDialogEntityResourcesLookup = new EntityResourcesLookup(this);
        searchDialogEntityResourcesLookup.setSearchCategory(EntityListCategory.fromString(getParameter("category")));
        searchDialogEntityResourcesLookup.setQueryServiceKey(getParameter("queryServiceKey"));
        serviceLookup = searchDialogEntityResourcesLookup;
        break;
      default:
        throw new UnsupportedOperationException("Not supported.");
    }
    try {
      switch (responseType) {
        case JSON:
          JSONObject json = generateJSONResponse();
          json.write(response.getWriter());
          return;
        case XML:
          Document doc = generateXMLResponse();
          ExtXMLElement.write(doc, response.getWriter());
          return;
      }
    } catch (AIGException e) {
      if (e.getReason().equals(AIGException.Reason.SERVICE_OFFLINE)) {
        response.sendError(550, e.getMessage());
      } else {
        throw e;
      }
    }
  }
  
  @Override
  protected String getServletMimeType() {
    switch (responseType) {
      case XML:
        return "text/xml";
      case JSON:
      default:
        return "text/plain";
    }
  }
  
  @Override
  public JSONObject generateJSONResponse() throws Exception {
    if (serviceLookup != null) {
      return serviceLookup.getServiceRecords();
    }
    throw new UnsupportedOperationException("Not supported.");
  }
  
  public JSONArray generateJSONArrayResponse() throws Exception {
    throw new UnsupportedOperationException("Should not get here.");
  }
  
  @Override
  public Document generateXMLResponse() throws Exception {
    if (serviceLookup != null) {
      return serviceLookup.getServicesDocument();
    }
    throw new UnsupportedOperationException("Not supported.");
  }
  
  @Override
  public void writeRawResponse() throws Exception {
    throw new UnsupportedOperationException("Not supported.");
  }
}
