package amgen.ri.aig.scripts.jsmin;

/**
 * <p>@version $Id: UnterminatedCommentException.java,v 1.1 2011/06/17 20:41:25 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class UnterminatedCommentException extends Exception {
    public UnterminatedCommentException() {
        super();
    }

    public UnterminatedCommentException(String message) {
        super(message);
    }

    public UnterminatedCommentException(String message, Throwable cause) {
        super(message, cause);
    }

    public UnterminatedCommentException(Throwable cause) {
        super(cause);
    }
}
