/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.entity;

import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.entity.oil.BasicEntityOILConverter;
import amgen.ri.aig.entity.oil.EntityOILConverterIF;
import amgen.ri.aig.entity.oil.OILClass;
import amgen.ri.aig.entity.oil.UIR;
import amgen.ri.asf.sa.uddi.ClassificationSchemeNames;
import amgen.ri.asf.sa.uddi.ServiceParameter;
import amgen.ri.asf.sa.uddi.ServiceParameterCategory;
import amgen.ri.asf.sa.uddi.ServiceParameterUIRType;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import amgen.ri.util.HashCodeGenerator;
import amgen.ri.xml.ExtXMLElement;
import com.google.common.collect.Iterables;
import java.io.Serializable;
import java.util.*;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import org.jdom.Element;

/**
 *
 * @author jemcdowe
 */
public class EntityClass implements Serializable {

  private EntityListCategory entityCategory;
  private Set<ServiceDataCategory> serviceInputCategories;
  private Map<ServiceDataCategory, Pattern> serviceInputCategory2PatternMap;
  private String label;
  private String singularStyle;
  private String pluralStyle;
  private String loftStyle;
  private OILClass oilClass;
  private String oilCode;
  private int fHashCode;

  public EntityClass(EntityListCategory entityCategory, String defaultSingularStyle, String defaultPluralStyle, String defaultLoftStyle) {
    this.entityCategory = entityCategory;
    this.singularStyle = defaultSingularStyle;
    this.pluralStyle = defaultPluralStyle;
    this.loftStyle = defaultLoftStyle;
    this.serviceInputCategories = new LinkedHashSet<ServiceDataCategory>();
    this.serviceInputCategory2PatternMap = new EnumMap<ServiceDataCategory, Pattern>(ServiceDataCategory.class);
  }

  public EntityClass(EntityListCategory entityCategory, Element typeEl, String defaultSingularStyle, String defaultPluralStyle, String defaultLoftStyle) {
    this(entityCategory, defaultSingularStyle, defaultPluralStyle, defaultLoftStyle);
    this.label = typeEl.getChildText("Label");

    Element styleEl = typeEl.getChild("Style");
    String singularStyleAttr = ExtXMLElement.getAttribute(styleEl, "singular");
    if (ExtString.hasLength(singularStyleAttr)) {
      this.singularStyle = singularStyleAttr;
    }
    String pluralStyleAttr = ExtXMLElement.getAttribute(styleEl, "plural");
    if (ExtString.hasLength(pluralStyleAttr)) {
      this.pluralStyle = pluralStyleAttr;
    }
    String loftStyleAttr = ExtXMLElement.getAttribute(styleEl, "loft");
    if (ExtString.hasLength(loftStyleAttr)) {
      this.loftStyle = loftStyleAttr;
    }

    Element oilEl = typeEl.getChild("Oil");
    OILClass oilClassAttr = OILClass.fromString(ExtXMLElement.getAttribute(oilEl, "class"));
    String oilCodeAttr = ExtXMLElement.getAttribute(oilEl, "code");
    if (!oilClassAttr.equals(OILClass.UNKNOWN)) {
      this.oilClass = oilClassAttr;
      this.oilCode = oilCodeAttr;
    }

    List<Element> serviceInputCategoryEls = typeEl.getChildren("ServiceInputCategory");
    for (Element serviceInputCategoryEl : serviceInputCategoryEls) {
      String serviceInputCategoryName = serviceInputCategoryEl.getAttributeValue("name");
      ServiceDataCategory serviceInputCategory = ServiceDataCategory.fromString(serviceInputCategoryName);
      if (serviceInputCategory.equals(ServiceDataCategory.UNKNOWN)) {
        throw new IllegalArgumentException("Unknown category name " + serviceInputCategoryName);
      }
      serviceInputCategories.add(serviceInputCategory);
      String serviceInputCategoryRegEx = serviceInputCategoryEl.getChildText("RegExPattern");
      if (serviceInputCategoryRegEx != null) {
        try {
          serviceInputCategory2PatternMap.put(serviceInputCategory, Pattern.compile(serviceInputCategoryRegEx.trim()));
        } catch (PatternSyntaxException e) {
          throw new IllegalArgumentException("Warning: Unable to compile ServiceDataCategory regular expression: " + serviceInputCategoryRegEx);
        }
      }
    }
  }

  /**
   * @return the entityCategory
   */
  public EntityListCategory getEntityCategory() {
    return entityCategory;
  }

  /**
   * @return the serviceInputCategories
   */
  public Collection<ServiceDataCategory> getServiceInputCategories() {
    return serviceInputCategories;
  }

  /**
   * Returns the top ServiceDataCategory for the Entity type
   *
   * @return
   */
  public ServiceDataCategory getServiceInputCategory() {
    return Iterables.getFirst(serviceInputCategories, ServiceDataCategory.UNKNOWN);
  }

  /**
   * @return the serviceInputCategory2PatternMap
   */
  public Pattern getServiceInputCategory2PatternMap(ServiceDataCategory serviceDataCategory) {
    return serviceInputCategory2PatternMap.get(serviceDataCategory);
  }

  /**
   * @return the label
   */
  public String getLabel() {
    return label;
  }

  /**
   * @return the singularStyle
   */
  public String getSingularStyle() {
    return singularStyle;
  }

  /**
   * @return the pluralStyle
   */
  public String getPluralStyle() {
    return pluralStyle;
  }

  /**
   * @return the loftStyle
   */
  public String getLoftStyle() {
    return loftStyle;
  }

  /**
   * @return the oilClass
   */
  public OILClass getOilClass() {
    return oilClass;
  }

  /**
   * @return the oilCode
   */
  public String getOilCode() {
    return oilCode;
  }

  /**
   * Returns whether the entity has an OIL classification
   *
   * @param entityClassMgr
   * @param parameter
   * @return
   */
  public boolean hasOilClass(EntityClassManager entityClassMgr, ServiceParameter parameter) {
    ServiceParameterCategory category = getServiceParameterCategory(entityClassMgr, parameter);
    EntityClass parameterEntityClass = entityClassMgr.getEntityClass(category);
    return (ExtString.hasLength(parameterEntityClass.getOilCode()) && parameterEntityClass.getOilClass() != null
            && !parameterEntityClass.getOilClass().equals(OILClass.UNKNOWN));
  }

  /**
   * Returns a DRUID format String for the UIR class. This is x::CODE:%s where x= single-character class designation
   * CODE= OIL code %s= the LUID
   *
   * @return
   */
  public String getDRUIDFormat() {
    return getOilClass().getClassChar() + "::" + getOilCode() + ":%s";
  }

  /**
   * Returns a pattern for matching a DRUID which also captures the LUID. The pattern is x::CODE:(LUID) where x=
   * single-character class designation CODE= OIL code LUID= the LUID in the only capture group. It is named LUID.
   *
   *
   * @return
   */
  public Pattern getDRUIDPattern() {
    try {
      return Pattern.compile(getOilClass().getClassChar() + "::" + Pattern.quote(getOilCode()) + ":([\\p{Graph}]+)");
    } catch (Exception e) {
      // e.printStackTrace();
    }
    return null;
  }

  /**
   * The provided value is a DRUID according to the Druid Pattern provided by getDRUIDPattern()
   *
   * @param val
   * @return
   */
  public boolean isDruid(String val) {
    Pattern druidPattern = getDRUIDPattern();
    return (druidPattern == null ? false : druidPattern.matcher(val).matches());
  }

  public ServiceParameterUIRType getCurrentUIRType(ServiceParameter parameter, ServiceParameterUIRType defaultType) {
    if (parameter != null && !parameter.getRawValues().isEmpty()) {
      return (isDruid(parameter.getRawValues().get(0).toString()) ? ServiceParameterUIRType.DRUID : defaultType);
    }
    return defaultType;
  }

  /**
   * Converts a collection of ServiceParameters to their proper representation- LUID, DRUID, or GUID using the
   * BasicEntityOILConverter converter utility
   *
   */
  public void convertUID(EntityClassManager entityClassManager, ServiceParameter... parameters) {
    convertUID(entityClassManager, new BasicEntityOILConverter(), parameters);
  }

  /**
   * Converts a collection of ServiceParameters to their proper representation- LUID, DRUID, or GUID using the
   * BasicEntityOILConverter converter utility
   */
  public void convertUID(EntityClassManager entityClassManager, List<ServiceParameter> parameters) {
    convertUID(entityClassManager, new BasicEntityOILConverter(), parameters);
  }

  /**
   * Converts a collection of ServiceParameters to their proper representation- LUID, DRUID, or GUID using the provided
   * EntityOILConverter converter utility
   *
   */
  public void convertUID(EntityClassManager entityClassManager, EntityOILConverterIF converter, ServiceParameter... parameters) {
    convertUID(entityClassManager, converter, Arrays.asList(parameters));
  }

  /**
   * Converts a collection of ServiceParameters to their proper representation- LUID, DRUID, or GUID using the provided
   * EntityOILConverter converter utility
   *
   * @param entityClassManager
   */
  public void convertUID(EntityClassManager entityClassManager, EntityOILConverterIF converter, List<ServiceParameter> parameters) {
    Set<String> ids2Convert = new HashSet<String>();
    for (ServiceParameter parameter : parameters) {
      if (hasOilClass(entityClassManager, parameter)) {
        if (parameter.hasValue()) {
          ServiceParameterUIRType currentValueUIRType = getCurrentUIRType(parameter, ServiceParameterUIRType.PREF);

          ServiceParameterCategory parameterCategory = getServiceParameterCategory(entityClassManager, parameter);
          ServiceParameterUIRType requiredUIRType = parameterCategory.getIdType();
          if (!requiredUIRType.equals(ServiceParameterUIRType.NOTSET) && !requiredUIRType.equals(currentValueUIRType)) {
            for (Object val : parameter.getRawValues()) {
              ids2Convert.add(val + "");
            }
          }
        }
      }
    }

    if (!ids2Convert.isEmpty()) {
      Map<String, UIR> uirMap = converter.convert(this, new ArrayList<String>(ids2Convert));
      for (ServiceParameter parameter : parameters) {
        if (parameter.hasValue()) {
          ServiceParameterCategory parameterCategory = getServiceParameterCategory(entityClassManager, parameter);
          ServiceParameterUIRType currentValueUIRType = getCurrentUIRType(parameter, ServiceParameterUIRType.PREF);
          ServiceParameterUIRType requiredUIRType = parameterCategory.getIdType();
          if (!requiredUIRType.equals(ServiceParameterUIRType.NOTSET) && !requiredUIRType.equals(currentValueUIRType)) {
            List rawValues = new ArrayList(parameter.getRawValues());
            parameter.clearValues();
            for (Object val : rawValues) {
              UIR uir = uirMap.get(val + "");
              if (uir != null) {
                switch (requiredUIRType) {
                  case DRUID:
                    parameter.addValue(uir.getUir_druid());
                    break;
                  case LUID:
                    parameter.addValue(uir.getUir_luid());
                    break;
                  case PREF:
                    parameter.addValue(uir.getPreferred_name());
                    break;
                }
              }
            }
          }
        }
      }
    }
  }

  private ServiceParameterCategory getServiceParameterCategory(EntityClassManager entityClassManager, ServiceParameter serviceParameter) {
    List<ServiceParameterCategory> parameterCategories = serviceParameter.getServiceParameterCategories(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME);
    for (ServiceParameterCategory parameterCategory : parameterCategories) {
      if (this.equals(entityClassManager.getEntityClass(parameterCategory))) {
        return parameterCategory;
      }
    }
    return null;
  }

  @Override
  public int hashCode() {
    if (fHashCode == 0) {
      int result = HashCodeGenerator.SEED;
      result = HashCodeGenerator.hash(result, entityCategory);
      fHashCode = result;
    }
    return fHashCode;
  }

  @Override
  public boolean equals(Object obj) {
    if (obj != null && obj instanceof EntityClass) {
      return ((EntityClass) obj).entityCategory.equals(this.entityCategory);
    }
    return false;
  }
}
