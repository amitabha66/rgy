/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.entity.oil;

import amgen.ri.aig.entity.EntityTypeXMLDAO;
import java.util.List;

/**
 *
 * @author jemcdowe
 */
public interface OILMapper {
  public EntityTypeXMLDAO getEntityTypeXML();  
  public List<UIR> getUIRByDruid(List<String> druids, String oilCode);
  public List<UIR> getUIRByLuid(List<String> luids, String oilCode);
  public List<UIR> getUIRByPreferredName(List<String> preferredNames, String oilCode);  
}
