package amgen.ri.aig.listener;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.preferences.SpecialUserPreferences;
import amgen.ri.aig.preferences.UserPreference;
import amgen.ri.asf.sa.uddi.*;
import amgen.ri.json.JSONArray;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.text.SimpleDateFormat;
import java.util.*;
import org.jdom.CDATA;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.filter.Filter;

/**
 * <p>@version $Id: RecentServiceUpdater.java,v 1.2 2011/06/21 17:28:57 cvs Exp
 * $</p>
 */
public class RecentServiceUpdater implements ServiceListenerIF {
  public static final SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.SIMPLE_DATE_PATTERN);
  private AIGBase requestor;
  private Map<String, String> coreServiceParameterSet;

  public RecentServiceUpdater(AIGBase requestor) {
    this.requestor = requestor;
    this.coreServiceParameterSet = new HashMap<String, String>();
  }

  public RecentServiceUpdater(AIGBase requestor, Map<String, String> coreServiceParameterSet) {
    this(requestor);
    if (coreServiceParameterSet != null) {
      this.coreServiceParameterSet.putAll(coreServiceParameterSet);
    }
  }

  /**
   * serviceStarted
   *
   * @param serviceDetails ServiceDetails
   */
  @Override
  public boolean serviceStarted(final ServiceDetails serviceDetails) {
    try {
      UserPreference preference = requestor.getUserPreferences(SpecialUserPreferences.RECENT_SERVICES);
      Document recentServicesDoc = null;
      Document previousServiceDoc = null;
      if (preference != null && preference.getPreferenceDataDocument() != null) {
        recentServicesDoc = preference.getPreferenceDataDocument();
        List removedContent = recentServicesDoc.getRootElement().removeContent(new Filter() {
          @Override
          public boolean matches(Object obj) {
            if (obj instanceof Element) {
              Element el = (Element) obj;
              return ExtString.equals(el.getAttributeValue("serviceKey"), serviceDetails.getKey());
            }
            return false;
          }
        });
        if (!removedContent.isEmpty()) {
          previousServiceDoc = new Document((Element) removedContent.get(0));
        }
      }
      if (recentServicesDoc == null) {
        recentServicesDoc = ExtXMLElement.toDocument("<RecentServices/>");
      }

      Element recentServiceEl = ExtXMLElement.addElement(recentServicesDoc.getRootElement(), "Service");
      recentServiceEl.setAttribute("serviceKey", serviceDetails.getKey());
      recentServiceEl.setAttribute("lastDateCalled", dateFormat.format(new Date()));

      Element parameterSetEl = ExtXMLElement.addElement(recentServiceEl, "ParameterSet");

      //Add the ParameterSet
      Collection<ServiceParameter> serviceParameters = serviceDetails.getParameters();
      for (ServiceParameter serviceParameter : serviceParameters) {
        //
        // Only include parameters and values which match the following:
        // 1. Has a set value (NOT one merely set by defaults)
        // 2. Has a value not set by (a) lineage, (b) session attributes, (c) defaults- which should be handled by (1)
        // 3. NOT categorized as SERVICE_INPUT_CATEGORIZATION_SCHEME="Amgen Session Login"
        //
        if (serviceParameter.hasSetValue()
                && (!ExtString.hasLength(serviceParameter.getParameterValueSource())
                || !ExtString.in(serviceParameter.getParameterValueSource(), new String[]{"lineage", "session", "default"}))
                && !serviceParameter.isCategorizedAs(ClassificationSchemeNames.SERVICE_INPUT_CATEGORIZATION_SCHEME, "Amgen Session Login")) {
          Element parameterEl = ExtXMLElement.addElement(parameterSetEl, "Parameter");
          ExtXMLElement.addElement(parameterEl, "Name", serviceParameter.getParameterName());
          Element valueEl = ExtXMLElement.addElement(parameterEl, "Value");
          valueEl.addContent(new CDATA((new JSONArray(serviceParameter.getRawValues()).toString())));
        }
      }
      String resourceServiceKeys = requestor.getParameter("resourceServiceKeys");
      if (ExtString.hasLength(resourceServiceKeys)) {
        String[] keys = resourceServiceKeys.split(",");
        Element resourceServiceKeySetEl = ExtXMLElement.addElement(recentServiceEl, "ResourceServiceKeySet");
        for (String key : keys) {
          Element resourceServiceEl = ExtXMLElement.addElement(resourceServiceKeySetEl, "Service");
          resourceServiceEl.setAttribute("serviceKey", key.trim());
        }
      }
      if (!coreServiceParameterSet.isEmpty()) {
        Element coreServiceParameterSetEl = ExtXMLElement.addElement(recentServiceEl, "CoreServiceParameterSet");
        for (String paramName : coreServiceParameterSet.keySet()) {
          Element parameterEl = ExtXMLElement.addElement(coreServiceParameterSetEl, "Parameter");
          ExtXMLElement.addElement(parameterEl, "Name", paramName);
          Element valueEl = ExtXMLElement.addElement(parameterEl, "Value");
          valueEl.addContent(new CDATA(coreServiceParameterSet.get(paramName)));
        }
      } else if (previousServiceDoc != null) {
        Element coreServiceParameterSetEl = ExtXMLElement.getXPathElement(previousServiceDoc, "//CoreServiceParameterSet");
        if (coreServiceParameterSetEl != null) {
          recentServiceEl.addContent((Element) coreServiceParameterSetEl.clone());
        }
      }
      requestor.updateUserPreferences(SpecialUserPreferences.RECENT_SERVICES, null, recentServicesDoc);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return true;
  }

  /**
   * transformStarted
   *
   * @param serviceDetails ServiceDetails
   * @return boolean
   */
  public boolean transformStarted(ServiceDetails serviceDetails) {
    return true;
  }

  /**
   * transformEnded
   *
   * @param serviceDetails ServiceDetails
   * @param details ServiceInvocationDetails
   */
  public void transformEnded(ServiceDetails serviceDetails, ServiceInvocationDetails details) {
  }

  /**
   * serviceEnded
   *
   * @param serviceDetails ServiceDetails
   */
  public void serviceEnded(ServiceDetails serviceDetails, ServiceInvocationDetails details) {
  }

  public void serviceFailed(ServiceDetails serviceDetails, ServiceInvocationDetails details) {
  }
}
