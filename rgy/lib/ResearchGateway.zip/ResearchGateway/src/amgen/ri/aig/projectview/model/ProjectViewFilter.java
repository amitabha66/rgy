package amgen.ri.aig.projectview.model;

import java.io.Serializable;

import org.jdom.Element;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.projectview.ProjectViewFilterQuery;
import amgen.ri.aig.projectview.filterables.ProjectViewFilterables;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.xml.ExtXMLElement;


/**
 * @version $Id: ProjectViewFilter.java,v 1.4 2013/04/18 23:04:26 jemcdowe Exp $
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class ProjectViewFilter implements Serializable {
    private String id;
    private String filterSetName;
    private ProjectViewFilterables filterables;
    private ProjectViewFilterQuery pvFilterQuery;


    public ProjectViewFilter(String filterSetName, int filterSourceCompoundListID, ProjectViewFilterables filterables,
                             String sessionUser, String sessionID) throws AIGException {
        try {
            this.filterSetName = filterSetName;
            this.filterables = filterables;
            pvFilterQuery = new ProjectViewFilterQuery(ExtXMLElement.toString(getVQTQueryEl()), 0,
                    filterSourceCompoundListID,
                    sessionUser, sessionID,
                    getSortField(), new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
            if (pvFilterQuery.performCommit() <= 0) {
                throw new AIGException("Unable to save filter", Reason.UNKNOWN);
            }
            id = pvFilterQuery.getIdentifier();
        } catch (Exception e) {
            e.printStackTrace();
            throw new AIGException(Reason.UNABLE_TO_RUN_SERVICE, e);
        }
    }

    public ProjectViewFilterables getFilterables() {
        return filterables;
    }

    public ProjectViewFilterQuery getPvFilterQuery() {
        return pvFilterQuery;
    }

    public Element getVQTQueryEl() {
        return filterables.getVQTQueryEl();
    }

    public String getSortField() {
        return filterables.getSortField();
    }

    public String getId() {
        return id;
    }

    public String getFilterSetName() {
        return filterSetName;
    }

    public String toString() {
        return filterables + "";
    }

    public void setFilterSetName(String filterSetName) {
        this.filterSetName = filterSetName;
    }

}
