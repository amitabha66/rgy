package amgen.ri.aig.scripts;


/**
 * <p>@version $Id: CalculationType.java,v 1.1 2011/06/17 20:41:25 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public enum CalculationType {
    FUNCTION, EXPRESSION, ADVANCED, UNKNOWN;

    public static CalculationType fromString(String s) {
        if (s == null) {
            return UNKNOWN;
        }
        try {
            return CalculationType.valueOf(s.toUpperCase().replace(' ', '_'));
        } catch (Exception e) {
            return UNKNOWN;
        }
    }
}
