/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.cache.service;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 *
 * @author jemcdowe
 */
public final class ServiceCacheDisable implements Set<String> {

  private Set<String> serviceKeys;
  private boolean disableAllCaching;

  public ServiceCacheDisable() {
    this.disableAllCaching= false;
    this.serviceKeys = new HashSet<String>();
  }

  public ServiceCacheDisable(String serviceKeys) {
    this.disableAllCaching= false;
    this.addAll(serviceKeys);
  }

  public void addAll(String serviceKeys) {
    this.serviceKeys = new HashSet<String>(Arrays.asList(serviceKeys.split("[\\s,;]+")));
  }
  /**
   * Get the value of disableAllCaching
   *
   * @return the value of disableAllCaching
   */
  public boolean isDisableAllCaching() {
    return disableAllCaching;
  }

  /**
   * Set the value of disableAllCaching
   *
   * @param disableAllCaching new value of disableAllCaching
   */
  public void setDisableAllCaching(boolean disableAllCaching) {
    this.disableAllCaching = disableAllCaching;
  }

  public int size() {
    return serviceKeys.size();
  }

  public boolean isEmpty() {
    return serviceKeys.isEmpty();
  }

  public boolean contains(Object o) {
    return serviceKeys.contains(o);
  }

  public Iterator<String> iterator() {
    return serviceKeys.iterator();
  }

  public Object[] toArray() {
    return serviceKeys.toArray();
  }

  public <T> T[] toArray(T[] ts) {
    return serviceKeys.toArray(ts);
  }

  public boolean add(String e) {
    return serviceKeys.add(e);
  }

  public boolean remove(Object o) {
    return serviceKeys.remove(o);
  }

  public boolean containsAll(Collection<?> clctn) {
    return serviceKeys.containsAll(clctn);
  }

  public boolean addAll(Collection<? extends String> clctn) {
    return serviceKeys.addAll(clctn);
  }

  public boolean retainAll(Collection<?> clctn) {
    return serviceKeys.retainAll(clctn);
  }

  public boolean removeAll(Collection<?> clctn) {
    return serviceKeys.removeAll(clctn);
  }

  public void clear() {
    serviceKeys.clear();
  }

}
