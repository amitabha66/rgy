package amgen.ri.aig.projectview.model;

import java.io.IOException;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.wsdl.WSDLException;
import javax.xml.rpc.ServiceException;
import javax.xml.transform.TransformerException;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.tree.TreeNodeCache;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.Constants;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.entity.provider.CompoundEntityDetails;
import amgen.ri.aig.entity.rgdh.SMCompound;
import amgen.ri.aig.entitylist.EntityList;
import amgen.ri.aig.entitylist.EntityListIF;
import amgen.ri.aig.entitylist.EntityListMemberIF;
import amgen.ri.aig.entitylist.GenericEntityList;
import amgen.ri.aig.entitylist.GenericEntityListMember;
import amgen.ri.aig.entitylist.PagingEntityList;
import amgen.ri.aig.preferences.PreferenceIF;
import amgen.ri.aig.preferences.PreferenceableIF;
import amgen.ri.aig.projectview.ProjectViewOperation;
import amgen.ri.aig.projectview.filterables.ProjectViewFilterableIF;
import amgen.ri.aig.projectview.filterables.ProjectViewFilterables;
import amgen.ri.aig.sv.EntityServiceInvoker;
import amgen.ri.aig.util.Utilities;
import amgen.ri.aig.vqt.VQTUtilities;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.ServiceParameterException;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.CompareTerm;
import amgen.ri.rdb.InCompareTerm;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.servlet.SessionLogin;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtString;
import amgen.ri.util.Pair;
import amgen.ri.xml.ExtXMLElement;

public class ProjectViewModel implements Serializable, PreferenceableIF {
  public static final int MAX_ASSAYS = 500;
  public static final String COMPOUND_LIST_SOURCE = "ORIGINAL_COMPOUND_LISTID";
  private String resultKey;
  // Basic Project View Information- Available Views, Session ID, Session User
  private Document projectViewDoc;
  private String projectName;
  private int projectId;
  private EntityListCategory entityCategory;
  private Map<String, ProjectViewAvailableView> availableViews;
  private String sessionUser;
  // Current View Info
  private ProjectViewAvailableView view; // This is the current view
  private Map<String, ProjectViewFilter> filters; // Map of filters created during sessions
  private Map<String, EntityListIF> createdCompoundLists; // Map of lists created during session
  private ProjectViewSummaryDocuments pdDocuments; // Contains the current view's PD documents
  private String sessionID;
  private transient Map<String, Document> compoundInfoDocs;
  // Current Page Information
  private Document currentPVPageDoc;
  private String currentViewID;
  private PagingEntityList currentCompoundList;
  private SMCompound smCompound; // Holds an RDB object to the RGDH for the current compound
  private Map<String, String> resultNodeCompoundLists;
  // Current Display Info
  private Map<String, Boolean> columnDisplayed;
  private String viewLayout = "table";
  private int tiledLayoutColumnCount = 3;
  private int fractionalDigits = 4;
  private String numberFormat = "fixed";
  private String aggregation = null;
  private boolean modelValid;

  public ProjectViewModel(Document projectViewDoc, int projectId, String projectName, String resultKey, AIGServlet requestor) throws ServletException,
          AIGException {
    super();
    SessionLogin sessionLogin = SessionLogin.getSessionLogin(requestor.getHttpServletRequest());    
    this.sessionUser = sessionLogin.getRemoteUser();
    this.projectId = projectId;
    this.projectName = projectName;
    this.entityCategory= EntityListCategory.COMPOUNDS;
    this.resultKey = resultKey;
    try {
      this.pdDocuments = new ProjectViewSummaryDocuments(requestor, projectId);
    } catch (Exception e) {
      e.printStackTrace();
      this.pdDocuments = new ProjectViewSummaryDocuments();
    }
    filters = new LinkedHashMap<String, ProjectViewFilter>();
    this.compoundInfoDocs = new HashMap<String, Document>();
    createdCompoundLists = new LinkedHashMap<String, EntityListIF>();

    availableViews = new LinkedHashMap<String, ProjectViewAvailableView>();
    resultNodeCompoundLists = new LinkedHashMap<String, String>();

    columnDisplayed = new HashMap<String, Boolean>();

    if (updateModel(projectViewDoc)) {
      setView(null);
      try {
        setCompoundList(null, false, null, requestor);
      } catch (IOException ex) {
      }
      if (view == null) {
        modelValid = false;
      }
    }
  }

  /**
   * Returns the type of Entity being displayed in the project view
   *
   * @return
   */
  public EntityListCategory getEntityCategory() {
    return entityCategory;
  }

  private boolean updateModel(Document projectViewDoc) {
    modelValid = false;
    if (projectViewDoc != null) {
      this.projectViewDoc = projectViewDoc;
      // ExtXMLElement.printPrettyString(projectViewDoc);
      availableViews.clear();

      List<Element> availableViewEls = ExtXMLElement.getXPathElements(projectViewDoc, "/CompoundResults/AvailableViews/View");
      for (Element availableViewEl : availableViewEls) {
        ProjectViewAvailableView projectViewAvailableView = new ProjectViewAvailableView(availableViewEl);
        availableViews.put(projectViewAvailableView.getId(), projectViewAvailableView);
      }
      sessionID = ExtXMLElement.getXPathValue(projectViewDoc, "/CompoundResults/AvailableViews/@session_id");
      modelValid = true;
    }
    return modelValid;
  }

  /**
   * Main handler in the model for paging compounds. A page event can be a
   * variety of requests: START- return current compound OR go to first compound
   * in list
   * REFRESH- stay on same compound PREVIOUS- go to previous compound in list
   * NEXT- go to next compound in list FIRST- go to first compound in list
   * INDEX- go
   * to a position in compound list COMPOUNDS- search for compounds in list or
   * create a new list FILTER- filter the current list creating a new list
   * X_COMPOUNDLIST- change the compound list and go to the first in the list
   * RESET_COMPOUNDLIST- change the compound list to the default list
   *
   * @param requestor AIGServlet
   * @param pageOperation ProjectViewOperation
   * @return boolean
   * @throws AIGException
   */
  public boolean pageProjectViewModel(AIGServlet requestor, ProjectViewOperation pageOperation) throws AIGException {
    if (!modelValid) {
      return false;
    }
    try {
      SessionLogin sessionLogin = SessionLogin.getSessionLogin(requestor.getHttpServletRequest());
      ServiceResultCacheItem projectViewResult = requestor.getServiceResultCacheItem(resultKey);
      if (projectViewResult == null) {
        return false;
      }
      switch (pageOperation) {
        case START:
          if (currentCompoundList.current() == null) {
            currentCompoundList.first();
          }
          if (currentCompoundList.current() == null) {
            return false;
          }
          break;
        case REFRESH:
          break;
        case PREVIOUS:
          if (currentCompoundList.previous() == null) {
            return false;
          }
          break;
        case NEXT:
          if (currentCompoundList.next() == null) {
            return false;
          }
          break;
        case FIRST:
          if (currentCompoundList.first() == null) {
            return false;
          }
          break;
        case LAST:
          if (currentCompoundList.last() == null) {
            return false;
          }
          break;
        case INDEX:
          if (!Double.isNaN(requestor.getParameterNumber("index").doubleValue())) {
            int index = requestor.getParameterNumber("index").intValue();
            if (currentCompoundList.get(index - 1) == null) {
              return false;
            }
          }
          break;
        case COMPOUNDS:
          if (requestor.doesParameterExist("compounds", true)) {
            List<String> cmpdIDs;
            String[] cmpdRqIDs = requestor.getParameter("compounds").trim().split("[\\s,;]+");
            if (cmpdRqIDs.length == 1 && (cmpdRqIDs[0].length() == 3 || cmpdRqIDs[0].startsWith("*"))) {
              cmpdIDs = searchCompoundListByStem(cmpdRqIDs[0]);
            } else {
              cmpdIDs = Arrays.asList(cmpdRqIDs);
            }

            if (cmpdIDs.size() == 1 && findCompound(cmpdIDs.get(0), requestor)) {
              break;
            } else {
              String newListName = getProjectName() + " List " + (createdCompoundLists.size() + 1);
              int compoundListID = createPVCompoundList(newListName, null, cmpdIDs, requestor);
              if (compoundListID >= 0) {
                if (!setCompoundList(compoundListID + "", false, null, requestor)) {
                  return false;
                }
              } else {
                return false;
              }
              if (currentCompoundList.first() == null) {
                return false;
              }
              break;
            }
          }
          return false;
        case FILTER:
          ProjectViewFilterables filterables = null;
          String filterSetName = "Filter Set";

          // Start: DETERMINE THE LIST TO FILTER OR SORT
          // Look to see if there is a compound_list_id and compound_list_type in the request
          // If so, try to make a PagingEntityList based on the values

          int filterSourceCompoundListID = -1;
          PagingEntityList filterSourceCompoundList;

          if (requestor.doesParameterExist("compound_list_id", true) && requestor.doesParameterExist("compound_list_type", true)) {
            if (requestor.doesParameterEqual("compound_list_type", "RESULTNODE")) {
              filterSourceCompoundListID = createCompoundListFromResultNode(requestor.getParameter("compound_list_id"), requestor);
            } else if (requestor.doesParameterEqual("compound_list_type", "FILTER")) {
              ProjectViewFilter filterQuery = filters.get(requestor.getParameter("compound_list_id"));
              if (filterQuery != null) {
                filterSourceCompoundListID = filterQuery.getPvFilterQuery().getList_id();
              }
            } else {
              filterSourceCompoundListID = requestor.getParameterNumber("compound_list_id", -1).intValue();
            }
          }
          // If the filterSourceCompoundListID has not been set, use the current compound list.
          // If it has, create a PagingEntityList. If something goes wrong, bail (return false)
          if (filterSourceCompoundListID == -1) {
            filterSourceCompoundList = getCompoundList();
          } else {
            filterSourceCompoundList = getPagedCompoundList(requestor, filterSourceCompoundListID + "");
          }
          if (filterSourceCompoundList == null) {
            return false;
          }
          // Done: DETERMINE THE LIST TO FILTER OR SORT

          // Start: CHECK FILTER TYPE AND SET THE filterables OBJECT
          // This depends on where it came from.
          // Either the Filter Dialog, where the request may have many filterables in a JSONArray
          if (requestor.isParameterJSONArray("filterables")) {
            // From the Filter Dialog
            try {
              if (filterSourceCompoundListID > -1) {
                filterables = new ProjectViewFilterables(requestor, filterSourceCompoundList, this);
                filterables.updateFilterables(requestor.getJSONArrayParameter("filterables"));
              }
            } catch (Exception e) {
              e.printStackTrace();
            }
            // A "Quick Sort" where the request will only have the filterable ID in the sort_by and "Ascending or Descending in the sort parameter
          } else if (requestor.doesParameterExist("sort_by", true) && requestor.doesParameterExist("sort", true)) {
            // From the quick-sort (right-click menu)
            filterables = new ProjectViewFilterables(requestor, filterSourceCompoundList, this);
            JSONObject filterableJSON;

            if (requestor.isParameterJSONObject("sort_by")) {
              filterableJSON = requestor.getJSONObjectParameter("sort_by");
            } else {
              ProjectViewFilterableIF filterable = filterables.getProjectViewFilterable(requestor.getParameter("sort_by"));
              if (filterable == null) {
                return false;
              }
              filterableJSON = new JSONObject(filterable.createFilterableJSON().toString());
            }
            filterableJSON.addIfNotNull("sort", requestor.getParameter("sort"));
            filterables.updateFilterable(filterableJSON);
            filterSetName = "Sorted (" + filterableJSON.optString("name") + ", " + filterableJSON.optString("sort") + ")";
            // A "Quick Filter" where the request will only have a single filterable as a JSONObject
          } else if (requestor.isParameterJSONObject("filterable")) {
            // From the quick-filter (right-click menu)
            JSONObject filterable = requestor.getJSONObjectParameter("filterable");
            // filterSourceCompoundListID = getCompoundListID();
            filterables = new ProjectViewFilterables(requestor, filterSourceCompoundList, this);
            filterables.updateFilterable(filterable);
            if (filterable.optString("type", "").equalsIgnoreCase("structure")) {
              if (filterable.optString("operator", "").equalsIgnoreCase("similarity")) {
                filterSetName = "Filtered (Structure- " + filterable.optString("operator") + " at "
                        + filterable.optJSONObject("parameters").optString("similarity") + "%)";
              } else {
                filterSetName = "Filtered (Structure- " + filterable.optString("operator") + ")";
              }
            } else {
              filterSetName = "Filtered (" + filterable.optString("name") + " " + filterable.optString("operator")
                      + (filterable.has("value") ? " " + filterable.optString("value") : "") + ")";
            }
          }
          // Done: CHECK FILTER TYPE AND SET THE filterables OBJECT

          // Start: RUN FILTER TYPE, CREATE FILTERED LIST, AND SET THE UPDATED COMPOUND LIST

          if (filterables != null) {
            ProjectViewFilter filterQuery = new ProjectViewFilter(requestor.getParameter("filter_set_name", filterSetName),
                    filterSourceCompoundListID, filterables, getSessionUser(), getSessionID());
            int filteredCompoundListID = createFilteredList(filterQuery, requestor);
            if (filteredCompoundListID >= 0) {
              if (setCompoundList(filteredCompoundListID, true, filterQuery.getId(), requestor)) {
                break;
              }
            }
          }
          // Done: RUN FILTER TYPE, CREATE FILTERED LIST, AND SET THE UPDATED COMPOUND LIST
          return false;
        case X_COMPOUNDLIST:
          if (requestor.doesParameterExist("compound_list_id", true) && requestor.doesParameterExist("compound_list_type", true)) {
            if (requestor.doesParameterEqual("compound_list_type", "RESULTNODE")) {
              if (setCompoundListToResultNode(requestor.getParameter("compound_list_id"), requestor)) {
                break;
              }
            } else if (requestor.doesParameterEqual("compound_list_type", "VQT")) {
              if (setCompoundListFromVQTSearch(requestor.getParameter("compound_list_id"), requestor)) {
                break;
              }

            } else if (requestor.doesParameterEqual("compound_list_type", "FILTER")) {
              ProjectViewFilter filterQuery = filters.get(requestor.getParameter("compound_list_id"));
              if (filterQuery != null) {
                int filteredCompoundListID = filterQuery.getPvFilterQuery().getList_id();
                if (setCompoundList(filteredCompoundListID, true, filterQuery.getId(), requestor)) {
                  break;
                }
              }
            } else if (setCompoundList(requestor.getParameter("compound_list_id"), false, null, requestor)) {
              break;
            }
          } else {
            return false;
          }
          return false;
        case RESET_COMPOUNDLIST:
          if (setCompoundList(null, false, null, requestor)) {
            break;
          }
          return false;
        default:
          return false;
      }
      boolean ret = updatePageData(requestor);
      return ret;
    } catch (Exception e) {
      e.printStackTrace();
      throw new AIGException("Unable to page next.", AIGException.Reason.UNABLE_TO_RUN_SERVICE, e);
    }
  }

  /**
   * createFilteredList
   *
   * @param filterQuery ProjectViewFilter
   * @return int
   */
  private int createFilteredList(ProjectViewFilter filterQuery, AIGServlet requestor) throws AIGException, IOException, JDOMException, RemoteException,
          ServiceException, WSDLException {
    ServiceDetails filterService = requestor.getLooselyCoupledServiceDetails("PROJECTVIEW_FILTER");
    filterService.setParameterValue("session_user", sessionUser);
    filterService.setParameterValue("query", ExtXMLElement.toString(filterQuery.getVQTQueryEl()));
    filterService.setParameterValue("sort", filterQuery.getSortField());
    filterService.setParameterValue("filter_sort_name", filterQuery.getFilterSetName());
    filterService.setParameterValue("filter_sort_id", filterQuery.getId());

    String results = filterService.executeService2String().trim();
    requestor.addRequestLogServiceInvocationDetails(filterService);
    
    if (!ExtString.isANumber(results)) {
      return -1;
    }
    int listID = new Integer(results);
    EntityList list = new EntityList(listID + "", new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
    if (list.size() == 0) {
      return -1;
    }
    filters.put(filterQuery.getId(), filterQuery);
    return listID;
  }

  public boolean setCurrentPageDoc(ServiceResultCacheItem projectViewResult) {
    if (projectViewResult == null || projectViewResult.getResultAsDocument() == null) {
      return false;
    }
    return setCurrentPageDoc(projectViewResult.getResultAsDocument());
  }

  /**
   * Sets the view from the AvailableViews. If viewID is null, it sets the first
   * default view or if none listed a default, the first view in the list. If
   * viewID is not null, sets the AvailableView with this id or none.
   *
   * @param viewID String
   * @return boolean
   */
  public boolean setView(String viewID) {
    if (availableViews.size() == 0) {
      return false;
    }
    if (viewID == null) {
      for (String availableViewID : availableViews.keySet()) {
        ProjectViewAvailableView availableView = availableViews.get(availableViewID);
        if (availableView.isDefault()) {
          view = availableView;
          currentViewID = view.getId();
          return true;
        }
      }
      view = availableViews.get(availableViews.keySet().iterator().next());
      currentViewID = view.getId();
      return true;
    }
    if (availableViews.containsKey(viewID)) {
      view = availableViews.get(viewID);
      currentViewID = view.getId();
      return true;
    }
    return false;
  }

  public boolean setCompoundList(int compoundListID, boolean filterAndSortList, String filterID, AIGServlet requestor) throws IOException, AIGException {
    if (compoundListID < 0) {
      return false;
    }
    return setCompoundList(compoundListID + "", filterAndSortList, filterID, requestor);
  }

  public boolean setCompoundList(String compoundListID, boolean isAFilteredAndSortedList, String filterID, AIGServlet requestor) throws IOException,
          AIGException {
    PagingEntityList compoundList = null;
    if (isAFilteredAndSortedList) {
      compoundList = new PagingEntityList(compoundListID, "entity_list_member_id", true, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
      if (filterID != null) {
        compoundList.setTransientData(COMPOUND_LIST_SOURCE, filterID);
      }
    } else {
      if (compoundListID == null) {
        if (view == null) {
          return false;
        }
        ProjectViewCompoundList defaultPVCompoundList = view.getDefaultCompoundList();
        if (defaultPVCompoundList != null) {
          compoundList = defaultPVCompoundList.getPagedCompoundList(requestor);
          if (compoundList != null) {
            if (!compoundList.setData()) {
              return false;
            }
            compoundList.set("name", defaultPVCompoundList.getName());
          }
        }
      } else {
        ProjectViewCompoundList pvCompoundList = view.getCompoundList(compoundListID);
        if (pvCompoundList != null) {
          compoundList = pvCompoundList.getPagedCompoundList(requestor);
          if (compoundList != null) {
            if (!compoundList.setData()) {
              return false;
            }
            compoundList.set("name", pvCompoundList.getName());
          }
        } else {
          compoundList = new PagingEntityList(compoundListID, "ENTITY_LIST_MEMBER_ID", true, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
        }
      }
    }
    if (compoundList == null || !compoundList.setData()) {
      return false;
    }
    this.currentCompoundList = compoundList;
    return (this.currentCompoundList.first() != null);
  }

  public boolean setCurrentPageDoc(Document currentPVPageDoc) {
    this.currentPVPageDoc = currentPVPageDoc;
    // modelValid = false;
    if (currentPVPageDoc == null || ExtXMLElement.getXPathElements(currentPVPageDoc, "/CompoundResults/Compound").size() == 0) {
      return false;
    }
    // ExtXMLElement.printPrettyString(currentPVPageDoc);
    currentViewID = ExtXMLElement.getXPathValue(currentPVPageDoc, "/CompoundResults/Compound/@view_list_id");
    // modelValid = true;
    return true;
  }

  /**
   * Gets the user-defined compound lists and load them into the compoundLists
   * and compoundListIDs collections
   *
   * @return Map
   */
  public Map<String, ProjectViewCompoundList> getCompoundLists(AIGServlet requestor) {
    Map<String, ProjectViewCompoundList> compoundLists = new LinkedHashMap<String, ProjectViewCompoundList>();
    for (String filterID : filters.keySet()) {
      ProjectViewFilter filter = filters.get(filterID);
      String filterName = filter.getFilterSetName();
      String displayName = filter.getPvFilterQuery().getDisplay_name();

      ProjectViewCompoundList filterList = new ProjectViewCompoundList(filter.getId(), displayName, "FILTER", false);
      compoundLists.put(filter.getId(), filterList);
    }
    // Update the view's compound lists
    if (getCurrentViewID() != null) {
      CompareTerm listCategoryTerm = new InCompareTerm("list_category", new String[]{
        "COMPOUNDS", "COMPOUNDS-DEFAULT", "COMPOUNDS-SESSION"
      });
      CompareTerm entityListMembersIDTerm = new CompareTerm("entity_list_members_id", getCurrentViewID());

      List<EntityList> lists = new RdbDataArray(EntityList.class, new CompareTerm[]{
        listCategoryTerm, entityListMembersIDTerm
      }, new OraSQLManager(), null, JDBCNamesType.RG_JDBC + "");
      for (EntityList list : lists) {
        if (list.setData()) {
          compoundLists.put(list.getIdentifier(), new ProjectViewCompoundList(list));
        }
      }
    }

    // Update the view's compound lists
    if (getCurrentViewID() != null) {
      for (String listID : createdCompoundLists.keySet()) {
        EntityListIF list = createdCompoundLists.get(listID);
        if (list != null && ExtString.hasLength(list.getListName())) {
          compoundLists.put(listID, new ProjectViewCompoundList(listID, list.getListName(), "SESSION", (listID.equals(getCompoundListIDString()))));
        }

      }
    }

    // Current COMPOUNDS result sets
    try {
      TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(requestor.getHttpServletRequest());
      List<String> resultNodeKeys = tnCache.getRootChildTreeNodeKeys(EntityListCategory.COMPOUNDS);
      Collections.reverse(resultNodeKeys);
      for (String resultNodeKey : resultNodeKeys) {
        Element treeNode = tnCache.getTreeNode(resultNodeKey);
        String treeNodeText = treeNode.getAttributeValue("TEXT");
        List<String> entityChildNodeKeys = tnCache.getChildTreeNodeKeys(resultNodeKey);
        String text = treeNodeText + " [" + entityChildNodeKeys.size() + "]";
        compoundLists.put(resultNodeKey, new ProjectViewCompoundList(resultNodeKey, text, "RESULTNODE", false));
      }
    } catch (Exception e) {
      e.printStackTrace();
    }

    // Current user's private lists
    Map<Integer, GenericEntityList> listMap = EntityList.getBasicEntityListInfo(ServiceDataCategory.AMGEN_ROOT_ID, getSessionUser());
    for (int list_id : listMap.keySet()) {
      GenericEntityList list = listMap.get(list_id);
      compoundLists.put(list_id + "", new ProjectViewCompoundList(list_id + "", list.getListName(), null, false, list.getListMemberCount()));
    }

    return compoundLists;
  }

  /**
   * Returns the current view ID
   *
   * @return String
   */
  public String getCurrentViewID() {
    return currentViewID;
  }

  /**
   * Returns the current view
   *
   * @return ProjectViewAvailableView
   */
  public ProjectViewAvailableView getCurrentView() {
    if (getCurrentViewID() == null) {
      return null;
    }
    return availableViews.get(getCurrentViewID());
  }

  /**
   * Sets the current view id verifying that it is valid. Returns the updated
   * current view id.
   *
   * @param viewID String
   * @return String
   */
  public String setCurrentViewID(String viewID) {
    if (viewID != null && availableViews.containsKey(viewID)) {
      this.currentViewID = viewID;
    }
    return getCurrentViewID();
  }

  public Map<String, ProjectViewAssayList> getAssayLists(boolean notInInvivoPKAuthList) {
    if (getCurrentView() == null) {
      return null;
    }
    return getCurrentView().getAssayLists(notInInvivoPKAuthList);
  }

  public Map<String, ProjectViewAvailableView> getAvailableViews() {
    return availableViews;
  }

  public String getProjectName() {
    return projectName;
  }

  public Set<String> getAvailableViewIDs() {
    return availableViews.keySet();
  }

  public List<String> getAssayListIDs() {
    if (getCurrentView() == null) {
      return new ArrayList<String>();
    }
    return new ArrayList(getCurrentView().getAssayListIDs());
  }

  /**
   * Returns the number of columns used in the tiled/portlet view. 0 if not
   * specified
   *
   * @return int
   */
  public int getTiledLayoutColumnCount() {
    return tiledLayoutColumnCount;
  }

  public int getFractionalDigits() {
    return fractionalDigits;
  }

  public String getNumberFormat() {
    return numberFormat;
  }

  public String getAggregation() {
    return (aggregation == null ? "Mean" : aggregation);
  }

  /**
   * Returns whether the model is valid
   *
   * @return boolean
   */
  public boolean isModelValid() {
    return modelValid;
  }

  public String getResultKey() {
    return resultKey;
  }

  public String getSessionID() {
    return sessionID;
  }

  public String getSessionUser() {
    return sessionUser;
  }

  public int getProjectId() {
    return projectId;
  }

  /**
   * Returns the current view layout
   *
   * @return String
   */
  public String getCurrentViewLayout() {
    return viewLayout;
  }

  public ProjectViewAvailableView getAvailableView(String viewID) {
    return availableViews.get(viewID);
  }

  public ProjectViewAssayList getAssayList(String id) {
    if (getCurrentView() == null) {
      return null;
    }
    return getCurrentView().getAssayList(id);
  }

  public void setFractionalDigits(int fractionalDigits) {
    this.fractionalDigits = fractionalDigits;
  }

  public void setNumberFormat(String numberFormat) {
    this.numberFormat = (numberFormat == null ? "fixed" : numberFormat.toLowerCase());
    ;
  }

  public void setAggregation(String aggregation) {
    this.aggregation = (aggregation == null ? "Mean" : aggregation);
  }

  public void setColumnDisplayed(String column, boolean displayed) {
    columnDisplayed.put(column, displayed);
  }

  public boolean getColumnDisplayed(String column) {
    if (!columnDisplayed.containsKey(column)) {
      return false;
    }
    return columnDisplayed.get(column);
  }

  /**
   * Sets the number of columns used in the tiled/portlet view
   *
   * @param tiledLayoutColumnCount String
   * @return int
   */
  public int setTiledLayoutColumnCount(int tiledLayoutColumnCount) {
    this.tiledLayoutColumnCount = tiledLayoutColumnCount;
    return getTiledLayoutColumnCount();
  }

  public String setCurrentViewLayout(String viewLayout) {
    this.viewLayout = null;
    if (viewLayout != null && (viewLayout.equalsIgnoreCase("table") || viewLayout.equalsIgnoreCase("tiles"))) {
      this.viewLayout = viewLayout.toLowerCase();
    }
    return getCurrentViewLayout();
  }

  public String getDefinitionDocs() {
    StringBuffer sb = new StringBuffer("PV:\n");
    sb.append(ExtXMLElement.toPrettyString(projectViewDoc));
    sb.append("\nPage:\n");
    sb.append(ExtXMLElement.toPrettyString(currentPVPageDoc));
    return sb.toString();
  }

  public Document getProjectViewDocument() {
    return projectViewDoc;
  }

  public Document getProjectViewPageDocument() {
    return currentPVPageDoc;
  }

  /**
   * Returns a ProjectView page Document for a compound. If the compound is the
   * current page, the current page Document is returned. Otherwise, the
   * ProjectView service is invoked and results returned. This does not affect
   * the current display page.
   *
   * @param requestor AIGServlet
   * @param compoundID String
   * @param compoundListID String
   * @return Document
   * @throws ServletException
   * @throws WSDLException
   * @throws JDOMException
   * @throws IOException
   * @throws TransformerException
   * @throws AIGException
   * @throws ServiceException
   */
  public Document getProjectViewPageDocument(AIGServlet requestor, String compoundID) throws ServletException, WSDLException, JDOMException, IOException,
          TransformerException, AIGException, ServiceException {
    if (compoundID.equals(getCompoundID())) {
      return getProjectViewPageDocument();
    }
    ServiceResultCacheItem projectViewResult = requestor.getServiceResultCacheItem(resultKey);
    SessionLogin sessionLogin = SessionLogin.getSessionLogin(requestor.getHttpServletRequest());
    if (projectViewResult == null || sessionLogin == null || projectViewDoc == null) {
      return null;
    }
    Map<String, String> params = new HashMap<String, String>();
    addIfNotNull(params, "compounds", compoundID);
    addIfNotNull(params, "session_id", getSessionID());
    addIfNotNull(params, "view_list_id", getCurrentViewID());
    addIfNotNull(params, "compound_list_id", getCompoundListID());
    addIfNotNull(params, "session_login", sessionLogin.getRemoteUser());
    addIfNotNull(params, "searchType", "");
    EntityServiceInvoker invoker = new EntityServiceInvoker(requestor);
    String resultKey = invoker.invokeServiceAndCache(projectViewResult.getServiceDetails(), null, params, true);
    return requestor.getServiceResultCacheItem(resultKey).getResultAsDocument();
  }

  /**
   * isValidCompoundListID
   *
   * @param string String
   * @return boolean
   */
  public boolean isValidCompoundListID(String listID) {
    String[] validCategories = new String[]{
      "COMPOUNDS", "COMPOUNDS-DEFAULT", "COMPOUNDS-SESSION"
    };
    EntityList list = EntityList.getEntityList(listID);

    if (list != null && list.getEntityCategory() != null && ExtString.in((String) list.get("list_category"), validCategories)) {
      return true;
    }
    return false;
  }

  /**
   * Gets current compound info for the current compound
   *
   * @return Collection
   * @param requestor AIGServlet
   * @param componentID String
   */
  public Document getCurrentCompoundInfo_old(AIGServlet requestor) {
    try {
      EntityListMemberIF currentCompound = getCurrentCompound();
      if (currentCompound != null) {
        return getCompoundInfo(requestor, currentCompound.getMember());
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return new Document();
  }

  /**
   * Gets current compound info for the current compound
   *
   * @return Collection
   * @param requestor AIGServlet
   * @param componentID String
   */
  public Document getCurrentCompoundInfo(AIGServlet requestor) {
    try {
      EntityListMemberIF currentCompound = getCurrentCompound();
      if (currentCompound != null) {
        return getCompoundInfo(requestor, currentCompound.getMember());
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return new Document();
  }

  /**
   * Gets the compound info for a specific compound. Returns either a JSONObject
   * or XML Document
   *
   * @return Collection
   * @param requestor AIGServlet
   * @param compoundID String
   * @param componentID String
   * @param asJSON boolean
   */
  public Document getCompoundInfo(AIGServlet requestor, String compoundID) {
    if (modelValid) {
      try {
        EntityListMemberIF currentCompound = getCurrentCompound();
        if (currentCompound != null) {
          if (!compoundInfoDocs.containsKey(compoundID)) {
            CompoundEntityDetails compoundEntityDetails = new CompoundEntityDetails(requestor, compoundID, null, false);
            compoundInfoDocs.put(compoundID, compoundEntityDetails.getResponseDocument());
          }
          return compoundInfoDocs.get(compoundID);
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return new Document();
  }

  private boolean updatePageData(AIGServlet requestor) throws AIGException {
    if (!modelValid) {
      return false;
    }
    try {
      ServiceResultCacheItem projectViewResult = requestor.getServiceResultCacheItem(resultKey);
      if (projectViewResult != null && hasCurrentCompound()) {
        EntityListMemberIF currentCompoundListMember = currentCompoundList.current();
        ServiceResultCacheItem updatedProjectViewResult = invokeProjectViewService(requestor, currentCompoundListMember.getMember(),
                currentCompoundList.getIdentifier());
        return setCurrentPageDoc(updatedProjectViewResult);
      }
    } catch (Exception e) {
      e.printStackTrace();
      throw new AIGException("Unable to page next.", AIGException.Reason.UNABLE_TO_RUN_SERVICE, e);
    }
    return false;
  }

  /**
   * Invokes the ProjectViewService as part of compound page request
   *
   * @param requestor AIGServlet
   * @param compounds String
   * @param compoundListID String
   * @return ServiceResultCacheItem
   * @throws ServletException
   * @throws WSDLException
   * @throws JDOMException
   * @throws IOException
   * @throws TransformerException
   * @throws AIGException
   * @throws ServiceException
   */
  private ServiceResultCacheItem invokeProjectViewService(AIGServlet requestor, String compounds, String compoundListID) throws ServletException,
          WSDLException, JDOMException, IOException, TransformerException, AIGException, ServiceException {
    ServiceResultCacheItem projectViewResult = requestor.getServiceResultCacheItem(resultKey);
    SessionLogin sessionLogin = SessionLogin.getSessionLogin(requestor.getHttpServletRequest());
    if (projectViewResult == null || sessionLogin == null || projectViewDoc == null) {
      return null;
    }
    Map<String, String> params = new HashMap<String, String>();
    addIfNotNull(params, "compounds", compounds);
    addIfNotNull(params, "session_id", getSessionID());
    addIfNotNull(params, "view_list_id", getCurrentViewID());
    addIfNotNull(params, "compound_list_id", compoundListID);
    addIfNotNull(params, "session_login", sessionLogin.getRemoteUser());
    addIfNotNull(params, "searchType", "");
    addIfNotNull(params, "viewType", "");
    EntityServiceInvoker invoker = new EntityServiceInvoker(requestor);
    invoker.invokeServiceAndCache(projectViewResult.getServiceDetails(), resultKey, params, true);
    return requestor.getServiceResultCacheItem(resultKey);
  }

  public boolean findCompound(String compound, AIGServlet requestor) {
    if (!modelValid) {
      return false;
    }
    int compoundIndex = currentCompoundList.findIndex(compound);
    if (compoundIndex >= 0) {
      currentCompoundList.get(compoundIndex);
      return true;
    }
    for (String listID : view.getCompoundLists().keySet()) {
      if (!listID.equals(currentCompoundList.getList_id())) {
        ProjectViewCompoundList pvCompoundList = view.getCompoundLists().get(listID);
        compoundIndex = currentCompoundList.findIndex(compound);
        if (compoundIndex >= 0) {
          try {
            setCompoundList(pvCompoundList.getId(), false, null, requestor);
            currentCompoundList.get(compoundIndex);
            return true;
          } catch (Exception e) {
          }
        }
      }
    }
    return false;
  }

  /**
   * Searches for list members using the given substring and the stem of the
   * member ids. e.g. 1234 will find 111234, 2221234, 1234, 91234,...
   *
   * @param query String
   * @return List
   */
  public List<String> searchCompoundListByStem(String cmpdSearch) {
    if (!modelValid) {
      return new ArrayList<String>();
    }
    cmpdSearch = cmpdSearch.replaceFirst("[\\*\\%]", "");
    List<EntityListMemberIF> resultMembers = currentCompoundList.searchForMembersByStem(cmpdSearch);
    List<String> compoundList = new ArrayList<String>();
    for (EntityListMemberIF resultMember : resultMembers) {
      compoundList.add(resultMember.getMember());
    }
    return compoundList;
  }

  public PagingEntityList getCompoundList() {
    return currentCompoundList;
  }

  public int getCompoundListID() {
    return (currentCompoundList != null ? currentCompoundList.getList_id() : -1);
  }

  /**
   * Returns the source for the current compound list ID. Thsi may be the same
   * as getCompoundListID() or if this is a dynamic list, it may be different.
   *
   * @return int
   */
  public String getCompoundListSource() {
    if (currentCompoundList == null) {
      return null;
    }
    Object sourceCompoundID = currentCompoundList.getTransientData(COMPOUND_LIST_SOURCE);
    if (sourceCompoundID != null) {
      return sourceCompoundID + "";
    }
    return currentCompoundList.getList_id() + "";
  }

  public String getCompoundID() {
    return (hasCurrentCompound() ? currentCompoundList.current().getMember() : null);
  }

  public String getCompoundListIDString() {
    return (currentCompoundList != null ? currentCompoundList.getIdentifier() : "-1");
  }

  public int getCompoundIndex() {
    return (currentCompoundList != null ? currentCompoundList.getCurrentIndex() : -1);
  }

  public int getCompoundListSize() {
    return (currentCompoundList != null ? currentCompoundList.getMemberCount() : -1);
  }

  public boolean hasPreviousCompound() {
    return (currentCompoundList != null ? currentCompoundList.hasPrevious() : false);
  }

  public boolean hasNextCompound() {
    return (currentCompoundList != null ? currentCompoundList.hasNext() : false);
  }

  public boolean hasCurrentCompound() {
    return (currentCompoundList != null ? (currentCompoundList.current() != null) : false);
  }

  /**
   * Returns the current compound as an EntityListMemberIF
   *
   * @return EntityListMemberIF
   */
  public EntityListMemberIF getCurrentCompound() {
    if (currentCompoundList == null) {
      return null;
    }
    return currentCompoundList.current();
  }

  /**
   * Returns the root number for the current compound
   *
   * @return int
   */
  public int getCurrentCompoundID() {
    EntityListMemberIF currentCompound = getCurrentCompound();
    if (currentCompound == null) {
      return -1;
    }
    return ExtString.toInteger(currentCompound.getMember());
  }

  /**
   * Returns the SMCompound object for the current compound
   *
   * @return SMCompound
   */
  public SMCompound getCurrentSMCompound() {
    int currentCompoundID = getCurrentCompoundID();
    if (currentCompoundID < 0) {
      return null;
    }
    if (smCompound == null || smCompound.getRoot_number() != currentCompoundID) {
      smCompound = new SMCompound(currentCompoundID + "", new OraSQLManager(), null, JDBCNamesType.RGDH_JDBC + "");
    }
    return smCompound;
  }

  /**
   * getCompoundListName
   *
   * @return String
   */
  public String getCompoundListName() {
    return (currentCompoundList != null ? currentCompoundList.getName() : null);
  }

  public String toString() {
    StringBuffer sb = new StringBuffer();
    sb.append(">>>>> ProjectViewUpdater");
    sb.append("\n");

    sb.append("\tCompound: ");
    sb.append(hasCurrentCompound() ? getCompoundID() : "None");
    sb.append("\n");

    sb.append("\tCompound List: ");
    sb.append(getCompoundListID() >= 0 ? getCompoundList().getName() : "None");
    sb.append("\n");

    sb.append("\tView Name: ");
    sb.append(getCurrentViewID() != null ? getCurrentView().getName() : "None");
    sb.append("\n");

    sb.append("\tView: ");
    // sb.append(projectViewDoc != null ? ExtXMLElement.toPrettyString(projectViewDoc) : "None");
    sb.append("\n");

    sb.append("\tPage: ");
    // sb.append(currentPVPageDoc != null ? ExtXMLElement.toPrettyString(currentPVPageDoc) : "None");
    sb.append("\n");

    return sb.toString();
  }

  /**
   * Creates a JSON string for the current project view page page- set of assay
   * lists as defined in the model
   *
   * @return JSONObject
   * @throws JSONException
   * @throws AIGException
   * @param requestor String
   */
  public JSONObject createPageJSON(AIGServlet requestor) throws JSONException, AIGException {
    return createPageJSON(requestor, getProjectViewPageDocument());
  }

  /**
   * Creates a JSON object for the project view
   *
   * @param resultKey String
   * @return JSONObject
   * @throws JSONException
   */
  public JSONObject createViewJSON() throws JSONException {
    JSONObject viewData = new JSONObject();
    viewData.put("isValid", isModelValid());
    addIfNotNull(viewData, "viewLayout", getCurrentViewLayout());
    viewData.put("grouping", true);
    addIfNotValue(viewData, "tiledColumnCount", getTiledLayoutColumnCount(), 0);
    addIfNotNull(viewData, "numberFormat", getNumberFormat());
    addIfNotValue(viewData, "fractionalDigits", getFractionalDigits(), 0);
    addIfNotNull(viewData, "projectName", getProjectName());
    addIfNotNull(viewData, "aggregation", getAggregation());

    addIfNotNull(viewData, "be_column", (getColumnDisplayed("be") ? "display" : "not"));
    addIfNotNull(viewData, "lipe_column", (getColumnDisplayed("lipe") ? "display" : "not"));

    addIfNotNull(viewData, "resultKey", resultKey);
    viewData.put("viewListID", getCurrentViewID());

    ProjectViewAvailableView currentView = getCurrentView();
    if (isModelValid() && currentView != null) {
      viewData.put("viewListName", currentView.getName());
      viewData.put("isDefault", currentView.isDefault() + "");
      viewData.put("viewHasInvivoPK", currentView.hasInvivoPK());
      /*
       * if (ExtString.hasLength(currentView.getSpotfireURL())) { JSONObject projDocumentURL = new JSONObject(); projDocumentURL.put("name",
       * "Project Summary"); projDocumentURL.put("url", currentView.getSpotfireURL()); viewData.append("projectSummaryDocs", projDocumentURL); }
       */
      viewData.put("projectSummaryDocs", pdDocuments.getDocumentsJSON());

    } else {
      viewData.put("viewListName", "None");
      viewData.put("isDefault", "false");
    }
    if (getCurrentView() != null && getCurrentView().getDefaultCompoundList() != null) {
      viewData.put("defaultCompoundListID", getCurrentView().getDefaultCompoundList().getId());
      viewData.put("defaultCompoundListName", getCurrentView().getDefaultCompoundList().getListName());
    }
    List<String> assayListIDs = getAssayListIDs();
    for (String listID : assayListIDs) {
      ProjectViewAssayList assayList = getAssayList(listID);
      if (assayList != null) {
        String listName = assayList.getName();
        if (!assayList.isInvivoPKAuthList()) {
          Map<String, String> viewList = new HashMap();
          viewList.put("list_id", listID + "");
          viewList.put("list_name", listName);
          viewData.append("viewLists", viewList);
        }
      }
    }
    return viewData;
  }

  /**
   * Creates a projectViewAvailableView data model from the current project view
   * page Document
   *
   * @return JSONObject
   * @throws JSONException
   * @throws AIGException
   */
  public ProjectViewAvailableView getPageProjectViewAvailableView() {
    return getPageProjectViewAvailableView(getProjectViewPageDocument());
  }

  /**
   * Creates a projectViewAvailableView data model from a project view page
   * Document
   *
   * @return JSONObject
   * @throws JSONException
   * @throws AIGException
   * @param pvPageDoc Document
   */
  public ProjectViewAvailableView getPageProjectViewAvailableView(Document pvPageDoc) {
    if (pvPageDoc == null) {
      return null;
    }
    Element pageEl = ExtXMLElement.getXPathElement(pvPageDoc, "/CompoundResults/Compound[1]");
    if (pageEl == null) {
      return null;
    }
    return new ProjectViewAvailableView(pageEl);
  }

  /**
   * Creates a JSON string for a project view page page- set of assay lists as
   * defined in the model
   *
   * @return JSONObject
   * @throws JSONException
   * @throws AIGException
   * @param requestor String
   * @param pvPageDoc Document
   */
  public JSONObject createPageJSON(AIGServlet requestor, Document pvPageDoc) throws JSONException, AIGException {
    JSONObject resultJSON = new JSONObject();
    ProjectViewAvailableView projectViewAvailableView = getPageProjectViewAvailableView(pvPageDoc);
    if (!modelValid || view == null || projectViewAvailableView == null) {
      return resultJSON;
    }
    // Handle the invivo PK Data
    Set<String> invivoPKAssayIDSet = new HashSet<String>();
    List<Element> resultContentEls = ExtXMLElement.getXPathElements(pvPageDoc, "/CompoundResults/ResultContent");
    Map<String, ProjectViewInVivoPK> invivoPKData = new LinkedHashMap<String, ProjectViewInVivoPK>();
    for (Element resultContentEl : resultContentEls) {
      String assayID = resultContentEl.getAttributeValue("assay_id");
      Element assayEl = ExtXMLElement.getXPathElement(pvPageDoc, "/CompoundResults/Compound/AssayType/Assay[@assay_id='" + assayID + "']");
      try {
        ProjectViewInVivoPK projectViewInVivoPK = new ProjectViewInVivoPK(resultContentEl, assayEl);
        invivoPKAssayIDSet.add(projectViewInVivoPK.getAssayID());
        invivoPKData.put(projectViewInVivoPK.getId(), projectViewInVivoPK);
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

    // Set the rest of the assays- excluding those that will be displayed in the invivo PK
    Map<String, ProjectViewAssayList> assayLists = projectViewAvailableView.getAssayLists();
    int listCounter = 0;
    for (String listID : assayLists.keySet()) {
      ProjectViewAssayList assayList = assayLists.get(listID);
      if (!assayList.isInvivoPKAuthList()) {
        String listName = assayList.getName();
        List<ProjectViewAssay> assays = assayList.getAssays();
        for (ProjectViewAssay assay : assays) {
          String assayName = assay.getAssayName();
          String displayName = assay.getDisplayName();
          String assayID = assay.getAssayID();
          if (!invivoPKAssayIDSet.contains(assayID)) {
            String assayCode = assay.getAssayCode();
            String assayDisplayName = displayName;
            if (assayDisplayName == null) {
              assayDisplayName = (assayName == null ? assayCode : assayName + " (" + assayCode + ")");
            }
            List<ProjectViewAssayResult> assayResults = assay.getAssayResults();
            for (ProjectViewAssayResult assayResult : assayResults) {
              JSONObject assayDataObj = new JSONObject();
              if (!resultJSON.has("Assay") || resultJSON.getJSONArray("Assay").length() < MAX_ASSAYS) {
                resultJSON.append("Assay", assayDataObj);
                assayDataObj.put("key", UUID.randomUUID().toString());
                assayDataObj.put("list_id", listID);
                assayDataObj.put("list_name", listName);
                assayDataObj.put("list_index", listCounter++);
                // assayDataObj.put("field_display_name", assayDisplayName);
                assayDataObj.put("field_display_name", assayResult.getName());
                assayDataObj.put("assay_code", assayCode);
                assayDataObj.put("result_type_display", assayResult.getResultTypeDisplay());
                assayDataObj.put("result_type_id", assayResult.getResultTypeID());
                assayDataObj.put("result_type", assayResult.getResultType());
                assayDataObj.put("vnt_suffix", assayResult.getVNTSuffix());
                assayDataObj.put("vnt_value", assayResult.getValue());
                assayDataObj.put("only_mods", assayResult.onlyModifiedValues());
                String aggregation = (getAggregation() == null ? "Mean" : getAggregation());
                assayDataObj.put("value", assayResult.getAggregatedValue(aggregation));

                if (assayResult.getValue() == null || assayResult.getValue().length() == 0) {
                  assayDataObj.put("value", "-");
                }
                if (getColumnDisplayed("be")) {
                  double be = Utilities.calculateBindingEfficiency(assayResult.getResultType(), ExtString.toDouble(assayDataObj
                          .getString("value")), getCurrentSMCompound());
                  assayDataObj.put("be", (Double.isNaN(be) ? "-" : be));
                } else {
                  assayDataObj.put("be", "-");
                }
                if (getColumnDisplayed("lipe")) {
                  double lipe = Utilities.calculateLipophilicEfficiency(assayResult.getResultType(), ExtString.toDouble(assayDataObj
                          .getString("value")), getCurrentSMCompound());
                  assayDataObj.put("lipe", (Double.isNaN(lipe) ? "-" : lipe));
                } else {
                  assayDataObj.put("lipe", "-");
                }
              }
            }
          }
        }
      }
    }
    if (!resultJSON.has("Assay")) {
      resultJSON.put("Assay", new JSONArray());
    }
    for (String key : invivoPKData.keySet()) {
      ProjectViewInVivoPK invivoPK = invivoPKData.get(key);
      Map<String, String> attr = invivoPK.getAttributes();
      Set<String> paramNames = invivoPK.getParameterNames();
      JSONObject invivoDataObj = new JSONObject();
      resultJSON.append("InVivo", invivoDataObj);
      addIfNotNull(invivoDataObj, "aacode", invivoPK.getAssayID());
      addIfNotNull(invivoDataObj, "field_display_name", invivoPK.getAssay());

      for (String paramName : paramNames) {
        String rawValue = invivoPK.getParameterValue(paramName);
        if (ExtString.hasLength(rawValue)) {
          addIfNotNull(invivoDataObj, paramName, rawValue);
        } else {
          addIfNotNull(invivoDataObj, paramName, "-");
        }
        ProjectViewAssayResult parameterResult = invivoPK.getParameterResult(paramName);
        if (parameterResult != null) {
          String value = parameterResult.getAggregatedValue("Mean");
          if (ExtString.hasLength(value)) {
            addIfNotNull(invivoDataObj, paramName, value);
          } else {
            addIfNotNull(invivoDataObj, paramName, "-");
          }
        }
      }

      addIfNotNull(invivoDataObj, "species", attr.get("ANIMAL SPECIES"));
      addIfNotNull(invivoDataObj, "dose", attr.get("DOSE"));
      addIfNotNull(invivoDataObj, "route", attr.get("ROUTE OF ADMINISTRATION"));
      addIfNotNull(invivoDataObj, "vehicle", attr.get("VEHICLE"));
      addIfNotNull(invivoDataObj, "gender", attr.get("SEX"));
      addIfNotNull(invivoDataObj, "fedstate", attr.get("FED STATE"));
    }
    if (!resultJSON.has("InVivo")) {
      resultJSON.put("InVivo", new JSONArray());
    }

    String viewTitle = projectName + " > " + view.getName() + " (" + (view.isDefault() ? "default" : "custom") + ")" + " >  " + getCompoundListName()
            + " [" + getCompoundID() + ", " + (getCompoundIndex() + 1) + " of " + getCompoundListSize() + "]";

    resultJSON.put("viewTitle", viewTitle);
    resultJSON.put("compoundListName", getCompoundListName());
    resultJSON.put("compoundListID", getCompoundListID());
    if (getCompoundListSource() != null) {
      resultJSON.put("compoundListSource", getCompoundListSource());
    }
    resultJSON.put("totalCompounds", getCompoundListSize());
    resultJSON.put("compoundIndex", (getCompoundIndex() + 1));
    resultJSON.put("hasPrevious", hasPreviousCompound());
    resultJSON.put("hasNext", hasNextCompound());
    addIfNotNull(resultJSON, "currentCompound", getCompoundID());
    resultJSON.put("resultKey", getResultKey());

    return resultJSON;
  }

  /**
   * Created a JSON string for experiments which use the list_id, assay_id, and
   * result_type
   *
   * @return JSONObject
   * @throws JSONException
   */
  public JSONObject createExperimentJSON(AIGServlet requestor, String listID, String assayID, String resultType) throws JSONException, AIGException {
    JSONObject assayExpJSON = new JSONObject();
    String rootNumber = getCompoundID();
    Element assayTypeEl = ExtXMLElement.getXPathElement(getProjectViewPageDocument(), "/CompoundResults/Compound/AssayType[@id='" + listID + "']");
    if (rootNumber == null || assayTypeEl == null) {
      return assayExpJSON;
    }
    String listName = assayTypeEl.getAttributeValue("name");
    Element propertyEl = ExtXMLElement.getXPathElement(assayTypeEl, "Assay[@assay_code='" + assayID + "']/Property[@type='" + resultType + "']");
    if (propertyEl == null) {
      return assayExpJSON;
    }
    for (Element experimentEl : (Collection<Element>) propertyEl.getChildren("IndResults")) {
      JSONObject assayDataObj = new JSONObject();
      String name = experimentEl.getAttributeValue("name");
      String value = experimentEl.getAttributeValue("value");
      String date = experimentEl.getAttributeValue("date");
      assayDataObj.put("list_id", listID);
      assayDataObj.put("list_name", listName);
      assayDataObj.put("field_display_name", name + " (" + date + ")");
      assayDataObj.put("value", (value == null || value.length() == 0 ? "-" : value));

      if (getColumnDisplayed("be")) {
        double be = Utilities.calculateBindingEfficiency(resultType, ExtString.toDouble(value), getCurrentSMCompound());
        assayDataObj.put("be", (Double.isNaN(be) ? "-" : be));
      } else {
        assayDataObj.put("be", "-");
      }

      if (getColumnDisplayed("lipe")) {
        double lipe = Utilities.calculateBindingEfficiency(resultType, ExtString.toDouble(value), getCurrentSMCompound());
        assayDataObj.put("lipe", (Double.isNaN(lipe) ? "-" : lipe));
      } else {
        assayDataObj.put("lipe", "-");
      }

      assayDataObj.put("result_type", resultType);
      assayDataObj.put("result_type_display", propertyEl.getAttributeValue("type"));
      assayExpJSON.append("Assay", assayDataObj);
    }
    if (!assayExpJSON.has("Assay")) {
      assayExpJSON.put("Assay", new JSONArray());
    }
    return assayExpJSON;
  }

  /**
   * addIfNotNull
   *
   * @param invivoDataObj JSONObject
   * @param string String
   * @param string1 String
   */
  private void addIfNotNull(JSONObject invivoDataObj, String name, String value) {
    if (value != null) {
      try {
        invivoDataObj.put(name, value);
      } catch (JSONException ex) {
      }
    }
  }

  /**
   * addIfNotNull
   *
   * @param invivoDataObj JSONObject
   * @param string String
   * @param string1 String
   */
  private void addIfNotNull(JSONObject invivoDataObj, String name, JSONObject value) {
    if (value != null) {
      try {
        invivoDataObj.put(name, value);
      } catch (JSONException ex) {
      }
    }
  }

  /**
   * addIfNotNull
   *
   * @param map JSONObject
   * @param name String
   * @param value String
   */
  private void addIfNotNull(Map map, String name, Object value) {
    if (value != null) {
      map.put(name, value);
    }
  }

  /**
   * addIfNotValue
   *
   * @param viewData JSONObject
   * @param string String
   * @param i int
   * @param i1 int
   */
  private void addIfNotValue(JSONObject jObj, String name, int value, int testValue) {
    if (value != testValue) {
      try {
        jObj.put(name, value);
      } catch (JSONException ex) {
      }
    }
  }

  /**
   * Creates a compound list from a result node returning the list id. If
   * already created, this just returns the identifier.
   *
   * @param resultNodeKey String
   * @param requestor AIGServlet
   * @return boolean
   */
  public int createCompoundListFromResultNode(String resultNodeKey, AIGServlet requestor) {
    try {
      if (!resultNodeCompoundLists.containsKey(resultNodeKey)) {
        TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(requestor.getHttpServletRequest());
        int listID = tnCache.createCompoundListFromResultNode(resultNodeKey, requestor);
        resultNodeCompoundLists.put(resultNodeKey, listID + "");
      }
      return Integer.valueOf(resultNodeCompoundLists.get(resultNodeKey));
    } catch (Exception e) {
      e.printStackTrace();
    }
    return -1;
  }

  public int createCompoundListFromVQT(String queryID, AIGServlet requestor) {
    double qID = ExtString.toDouble(queryID);
    if (Double.isNaN(qID)) {
      return -1;
    }
    String listName = "VQT Query";
    String listDescription = "";
    if (requestor.doesParameterExist("vqt_name")) {
      listName = requestor.getParameter("vqt_name");
      listDescription = requestor.getParameter("vqt_desc");
    }
    Document entityIDDoc = new VQTUtilities(requestor).executeEntityIDQuery((int) qID);
    if (entityIDDoc != null) {
      List<String> entityIDs = ExtXMLElement.getXPathValues(entityIDDoc, "//Entity");
      if (entityIDs.size() > 0) {
        return createPVCompoundList(listName, listDescription, entityIDs, requestor);
      }
    }
    return -1;
  }

  /**
   * Sets the compound list to a result node
   *
   * @param resultNodeKey String
   * @param requestor AIGServlet
   * @return boolean
   */
  public boolean setCompoundListToResultNode(String resultNodeKey, AIGServlet requestor) {
    int listID = createCompoundListFromResultNode(resultNodeKey, requestor);
    if (listID == -1) {
      return false;
    }
    try {
      return setCompoundList(listID, false, null, requestor);
    } catch (Exception ex) {
      return false;
    }
  }

  public boolean setCompoundListFromVQTSearch(String queryID, AIGServlet requestor) {
    int listID = createCompoundListFromVQT(queryID, requestor);
    if (listID == -1) {
      return false;
    }
    try {
      return setCompoundList(listID, false, null, requestor);
    } catch (Exception ex) {
      return false;
    }
  }

  /**
   * Creates a COMPOUNDS-SESSION type the compound list
   *
   * @param name String
   * @param description String
   * @param members List
   * @param requestor AIGServlet
   * @return boolean
   */
  public int createPVCompoundList(String name, String description, List<String> members, AIGServlet requestor) {
    try {
      if (members == null || members.size() == 0) {
        return -1;
      }
      if (description == null) {
        description = name;
      }
      EntityList resultNodeEntityList = new EntityList(name, description, EntityListCategory.COMPOUNDS, sessionUser, new OraSQLManager(),
              JDBCNamesType.RG_JDBC + "");
      resultNodeEntityList.setList_type("COMPOUNDS-SESSION");
      for (String member : members) {
        if (ExtString.hasLength(member)) {
          resultNodeEntityList.addListMember(new GenericEntityListMember(member, EntityListCategory.COMPOUNDS), ServiceDataCategory.AMGEN_ROOT_ID);
        }
      }
      if (resultNodeEntityList.performCommitAll(sessionUser) == 0) {
        return -1;
      }
      createdCompoundLists.put(resultNodeEntityList.getIdentifier(), resultNodeEntityList);
      return Integer.valueOf(resultNodeEntityList.getIdentifier());
    } catch (Exception e) {
      e.printStackTrace();
    }
    return -1;
  }

  /**
   * getFiltersJSON
   *
   * @return Object
   */
  public JSONObject getFiltersJSON() {
    JSONObject filtersJSON = new JSONObject();
    try {
      for (String filterID : filters.keySet()) {
        ProjectViewFilter filter = filters.get(filterID);
        JSONObject filterJSON = new JSONObject();
        filterJSON.addIfNotNull("id", filter.getId());
        filterJSON.addIfNotNull("name", filter.getFilterSetName());
        filtersJSON.append("Filters", filterJSON);
      }
    } catch (JSONException e) {
    }
    return filtersJSON;
  }

  /**
   * Gets a filter for the current compound list
   *
   * @return ProjectViewFilter
   * @param compoundListID String
   */
  public ProjectViewFilter getFilterByCompoundList() {
    if (currentCompoundList != null) {
      return getFilterByCompoundList(currentCompoundList.getList_id());
    }
    return null;
  }

  /**
   * Gets a filter for a compound list ID
   *
   * @return ProjectViewFilter
   * @param compoundListID String
   */
  public ProjectViewFilter getFilterByCompoundList(int compoundListID) {
    for (String filterID : filters.keySet()) {
      ProjectViewFilter filter = filters.get(filterID);
      if (filter.getPvFilterQuery().getList_id() == compoundListID) {
        return filter;
      }
    }
    return null;
  }

  /**
   * Gets a filter for a the filter ID
   *
   * @return ProjectViewFilter
   * @param filterID String
   */
  public ProjectViewFilter getFilter(String filterID) {
    return filters.get(filterID);
  }

  /**
   * Gets a list which had been created during the session from its ID
   *
   * @return ProjectViewFilter
   * @param listID String
   */
  public EntityListIF getCreatedCompoundList(String listID) {
    return createdCompoundLists.get(listID);
  }

  /**
   * Translates a possible dynamic compound list ID to its actual compound list
   * ID. Dynamic compound list IDs are those whcih are updated by the project
   * view
   * caching system and are based on a general classification such as 'project
   * registered compounds' or 'compounds with data in assay X'. These need the
   * current static list id for use in operations like filtering. For
   * non-dynamic lists, this just returns the given list
   *
   * @param requestor AIGServlet
   * @param compoundID String
   * @return PagingEntityList
   * @throws IOException
   * @throws AIGException
   */
  public static PagingEntityList getPagedCompoundList(AIGServlet requestor, String compoundListID) throws IOException, AIGException {
    try {
      ServiceDetails listLookupService = requestor.getLooselyCoupledServiceDetails("PROJECTVIEW_LISTLOOKUP");
      listLookupService.setParameterValue("available_type", "ActualCompoundListId");
      listLookupService.setParameterValue("comp_list_id", compoundListID);
      listLookupService.setParameterValue("session_user", requestor.getSessionLogin().getRemoteUser());
      String results = listLookupService.executeService2String();

      if (ExtString.hasTrimmedLength(results)) {
        PagingEntityList pagingEntityList = new PagingEntityList(results.trim(), "entity_list_member_id", true, new OraSQLManager(), null,
                JDBCNamesType.RG_JDBC + "");
        pagingEntityList.setTransientData(COMPOUND_LIST_SOURCE, (int) ExtString.toDouble(compoundListID));
        return pagingEntityList;
      }
    } catch (Exception e) {
      throw new AIGException(AIGException.Reason.UNABLE_TO_RUN_SERVICE, e);
    }
    return null;
  }

  /**
   * Returns the PreferenceGroup for this PreferenceableIF object
   *
   * @return String
   */
  public String getPreferenceGroup() {
    return "Project View";
  }

  /**
   * Sets a Preference in this PreferenceableIF object
   *
   * @param preference PreferenceIF
   */
  public void setPreference(PreferenceIF preference) {
    if (ExtString.alphaNumericsEqualIgnoreCase(preference.getPreferenceName(), "View Layout")) {
      if (preference.getPreferenceValue().toString().toLowerCase().startsWith("tab")) {
        setCurrentViewLayout("table");
      } else {
        setCurrentViewLayout("tiles");
      }
    } else if (ExtString.alphaNumericsEqualIgnoreCase(preference.getPreferenceName(), "View Columns")) {
      if (ExtString.isANumber(preference.getPreferenceValue().toString())) {
        setTiledLayoutColumnCount((int) ExtString.toDouble(preference.getPreferenceValue().toString()));
      }
    } else if (ExtString.alphaNumericsEqualIgnoreCase(preference.getPreferenceName(), "Aggregation")) {
      setAggregation(preference.getPreferenceValue().toString());
    } else if (ExtString.alphaNumericsEqualIgnoreCase(preference.getPreferenceName(), "Show Binding Efficiency")) {
      setColumnDisplayed("be", ExtString.equalsIgnoreCase(preference.getPreferenceValue().toString(), "YES"));
    } else if (ExtString.alphaNumericsEqualIgnoreCase(preference.getPreferenceName(), "Show Lipophilic Efficiency (lipE)")) {
      setColumnDisplayed("lipe", ExtString.equalsIgnoreCase(preference.getPreferenceValue().toString(), "YES"));
    } else if (ExtString.alphaNumericsEqualIgnoreCase(preference.getPreferenceName(), "Number Format")) {
      setNumberFormat(preference.getPreferenceValue().toString());
    } else if (ExtString.alphaNumericsEqualIgnoreCase(preference.getPreferenceName(), "Fractional Digits")) {
      if (ExtString.isANumber(preference.getPreferenceValue().toString())) {
        setFractionalDigits((int) ExtString.toDouble(preference.getPreferenceValue().toString()));
      }
    }
  }
}
