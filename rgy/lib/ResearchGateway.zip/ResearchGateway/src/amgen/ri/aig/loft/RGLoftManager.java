/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.aig.loft;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.aig.record.AppRecord;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtString;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.Types;
import java.util.List;
import java.util.Map;
import oracle.jdbc.OracleCallableStatement;

/**
 *
 * @author jemcdowe
 */
public class RGLoftManager extends AbstractLoftManager {
  private AIGServlet requestor;
  //Some common variables- may be null depending on request
  private JSONObject jAddApp;
  private String appID;

  public RGLoftManager(AIGServlet requestor) throws AIGException {
    super(requestor.getSessionLogin());
    this.requestor= requestor;
    jAddApp = requestor.getJSONObjectParameter("app");
    appID = requestor.getParameter("appID");
  }

  public AppRecord addApp() throws Exception {
    AppType type = AppType.fromString(jAddApp.optString("type", "na"));

    Connection conn = null;
    OracleCallableStatement stmt = null;
    try {
      int rgAppID = -1;
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC.toString());
      switch (type) {
        case SERVICE:
          String serviceKey = null;
          if (jAddApp != null && jAddApp.has("serviceKey")) {
            serviceKey = jAddApp.getString("serviceKey");
          } else if (jAddApp != null && jAddApp.has("record")) {
            JSONObject jAppRecord = jAddApp.getJSONObject("record");
            serviceKey = getAttribute(jAppRecord, AppAttributeType.SERVICE_KEY);
          }
          if (!ExtString.hasLength(serviceKey)) {
            throw new IllegalArgumentException("A service app must have a service key");
          }
          ServiceDetails service = ServiceCache.getServiceCache(requestor).getService(serviceKey);
          ServiceAttributes serviceAttr = new ServiceAttributes(service, requestor.getEntityClassManager());
          String iconClass = new ServiceAttributes(service, requestor.getEntityClassManager()).getIconClass(ServiceNamingContext.RG_LOFT);
          if (iconClass == null) {
            iconClass = "ix-v0-48-gears_run";
          }
          String serviceName = serviceAttr.getName(new ServiceNamingContext[]{ServiceNamingContext.RG_LAUNCHPAD, ServiceNamingContext.RG_LOFT, ServiceNamingContext.RG_QUERY});
          String serviceDesc = serviceAttr.getDescription(ServiceNamingContext.RG_QUERY);
          EntityListCategory serviceEntityListCategory = serviceAttr.getFirstEntityListCategory();

          stmt = (OracleCallableStatement) conn.prepareCall("BEGIN ? := RG_LOFT.createServiceLoftApp(?, ?, ?, ?, ?, ?); END;");
          stmt.registerOutParameter(1, Types.INTEGER);
          stmt.setString(2, serviceKey);
          stmt.setString(3, serviceName);
          stmt.setString(4, serviceDesc);
          stmt.setString(5, serviceEntityListCategory + "");
          stmt.setString(6, iconClass);
          stmt.setString(7, getRequestUser());
          stmt.execute();
          rgAppID = stmt.getInt(1);
          break;
        case FAVORITE:
          if (!jAddApp.has("folderItemID")) {
            throw new IllegalArgumentException("A favorite must have a favorite key");
          }
          int folderItemID = jAddApp.getInt("folderItemID");

          stmt = (OracleCallableStatement) conn.prepareCall("BEGIN ? := RG_LOFT.createFavoriteLoftApp(?, ?); END;");
          stmt.registerOutParameter(1, Types.INTEGER);
          stmt.setInt(2, folderItemID);
          stmt.setString(3, getRequestUser());
          stmt.execute();
          rgAppID = stmt.getInt(1);
          break;
        default:
          stmt = (OracleCallableStatement) conn.prepareCall("BEGIN ? := RG_LOFT.createToolLoftApp(?, ?); END;");
          stmt.registerOutParameter(1, Types.INTEGER);
          stmt.setString(2, type.toString());
          stmt.setString(3, getRequestUser());
          stmt.execute();
          rgAppID = stmt.getInt(1);
          break;
      }
      if (rgAppID > -1) {
        List<AppRecord> appRecords= getUserAppRecords(rgAppID);
        if (!appRecords.isEmpty()) {
          return appRecords.get(0);
        }
      }
    } finally {
      OraSQLManager.close(stmt);
      OraSQLManager.close(conn);
    }
    return null;
  }

  public JSONObject removeApp() throws Exception {
    if (ExtString.isAInteger(appID)) {
      Connection conn = null;
      CallableStatement stmt = null;
      try {
        conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC.toString());
        stmt = conn.prepareCall("BEGIN RG_LOFT.deleteLoftApp(?, ?); END;");
        stmt.setInt(1, ExtString.toInteger(appID));
        stmt.setString(2, getRequestUser());
        stmt.execute();
      } finally {
        OraSQLManager.close(stmt);
        OraSQLManager.close(conn);
      }
    }
    return new JSONObject();
  }

  public void updateSort(Map<String, Integer> updatedSort) throws AIGException {
    Connection conn = null;
    OracleCallableStatement stmt = null;
    try {
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC.toString());
      stmt = (OracleCallableStatement) conn.prepareCall("BEGIN RG_LOFT.UPDATELOFTAPPSORT(:rg_app_id, :sort_index, :requested_by); END;");
      
      for (AppRecord app : getUserAppRecords()) {        
        if (updatedSort.containsKey(app.getRecordID())) {
          stmt.setIntAtName("rg_app_id", app.getId());
          stmt.setIntAtName("sort_index", updatedSort.get(app.getRecordID()));
          stmt.setStringAtName("requested_by", getRequestUser());
          stmt.execute();
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.close(stmt);
      OraSQLManager.close(conn);
    }
  }

  public JSONObject createLoftPage(String name, List<String> initialAppIDs) throws AIGException {
    JSONObject jPage = new JSONObject();
    Connection conn = null;
    Statement stmt = null;
    try {
      if (!ExtString.hasLength(name)) {
        throw new AIGException("Invalid page name", AIGException.Reason.UNKNOWN);
      }
      jPage.put("page_id", -1);
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC.toString());

      stmt = conn.prepareCall("BEGIN ? := RG_LOFT.createLoftPage(?, ?); END;");
      CallableStatement cs = (CallableStatement) stmt;
      cs.registerOutParameter(1, Types.INTEGER);
      cs.setString(2, name);
      cs.setString(3, getRequestUser());

      cs.execute();
      int pageID = cs.getInt(1);
      jPage.put("page_id", pageID);
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.close(stmt);
      OraSQLManager.close(conn);
    }
    try {
      int pageID = jPage.optInt("page_id", -1);
      if (ExtArray.hasLength(initialAppIDs) & pageID > 0) {
        for (String initialAppID : initialAppIDs) {
          if (ExtString.isAInteger(initialAppID)) {
            JSONObject jTag = tagAppWithPage(ExtString.toInteger(initialAppID), pageID);
            if (jTag.has("app_id")) {
              jPage.append("app_ids", jTag.getInt("app_id"));
            }
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return jPage;
  }

  public JSONObject renameLoftPage(int pageID, String name) throws AIGException {
    JSONObject jPage = new JSONObject();
    Connection conn = null;
    Statement stmt = null;
    try {
      if (!ExtString.hasLength(name)) {
        throw new AIGException("Invalid page name", AIGException.Reason.UNKNOWN);
      }
      jPage.put("page_id", -1);
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC.toString());

      stmt = conn.prepareCall("BEGIN RG_LOFT.renameLoftPage(?, ?, ?); END;");
      CallableStatement cs = (CallableStatement) stmt;
      cs.setInt(1, pageID);
      cs.setString(2, name);
      cs.setString(3, getRequestUser());
      cs.execute();
      jPage.put("page_id", pageID);
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.close(stmt);
      OraSQLManager.close(conn);
    }
    return jPage;
  }

  public JSONObject removeLoftPage(int pageID) {
    JSONObject jPage = new JSONObject();
    Connection conn = null;
    Statement stmt = null;
    try {
      jPage.put("page_id", -1);
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC.toString());
      stmt = conn.prepareCall("BEGIN RG_LOFT.removeLoftPage(?, ?); END;");
      CallableStatement cs = (CallableStatement) stmt;
      cs.setInt(1, pageID);
      cs.setString(2, getRequestUser());
      cs.execute();
      jPage.put("page_id", pageID);
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.close(stmt);
      OraSQLManager.close(conn);
    }
    return jPage;
  }

  public JSONObject tagAppWithPage(int appID, int pageID) {
    JSONObject jPage = new JSONObject();
    Connection conn = null;
    Statement stmt = null;
    try {
      jPage.put("page_id", -1);
      jPage.put("app_id", -1);
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC.toString());
      stmt = conn.prepareCall("BEGIN RG_LOFT.addPageTagToApp(?, ?, ?); END;");
      CallableStatement cs = (CallableStatement) stmt;
      cs.setInt(1, appID);
      cs.setInt(2, pageID);
      cs.setString(3, getRequestUser());
      cs.execute();
      jPage.put("page_id", pageID);
      jPage.put("app_id", appID);
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.close(stmt);
      OraSQLManager.close(conn);
    }
    return jPage;
  }

  public JSONObject untagAppWithPage(int appID, int pageID) {
    JSONObject jPage = new JSONObject();
    Connection conn = null;
    Statement stmt = null;
    try {
      jPage.put("page_id", -1);
      jPage.put("app_id", -1);
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC.toString());
      stmt = conn.prepareCall("BEGIN RG_LOFT.addPageUnTagToApp(?, ?, ?); END;");
      CallableStatement cs = (CallableStatement) stmt;
      cs.setInt(1, appID);
      cs.setInt(2, pageID);
      cs.setString(3, getRequestUser());
      cs.execute();
      jPage.put("page_id", pageID);
      jPage.put("app_id", appID);
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.close(stmt);
      OraSQLManager.close(conn);
    }
    return jPage;
  }

  public JSONObject setDefaultLoftPage(int pageID, boolean setAsDefault) {
    JSONObject jPage = new JSONObject();
    Connection conn = null;
    Statement stmt = null;
    try {
      jPage.put("page_id", -1);
      conn = new OraSQLManager().getConnection(JDBCNamesType.RG_JDBC.toString());
      stmt = conn.prepareCall("BEGIN RG_LOFT.setPageAsDefault(?, ?, ?); END;");
      CallableStatement cs = (CallableStatement) stmt;
      cs.setInt(1, pageID);
      cs.setInt(2, (setAsDefault ? 1 : 0));
      cs.setString(3, getRequestUser());
      cs.execute();
      jPage.put("page_id", pageID);
      jPage.put("setAsDefault", setAsDefault);
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.close(stmt);
      OraSQLManager.close(conn);
    }
    return jPage;
  }
}
