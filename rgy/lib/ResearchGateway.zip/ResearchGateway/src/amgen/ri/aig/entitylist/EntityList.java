/*
 *   EntityList
 *   RDBData wrapper class for EntityList
 *   $Revision: 1.13 $
 *   Created: Jeffrey McDowell, 28 Jul 2008
 *   Modified: $Author: jemcdowe $
 *   $Log
 *
 */
package amgen.ri.aig.entitylist;

import amgen.ri.aig.AIGBase;
import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.cache.tree.NodeType;
import amgen.ri.aig.cache.service.ServiceCache;
import amgen.ri.aig.cache.tree.TreeNode;
import amgen.ri.aig.cache.tree.TreeNodeCache;
import amgen.ri.aig.category.schema2.EntityListCategory;
import amgen.ri.aig.category.schema2.ServiceDataCategory;
import amgen.ri.aig.constants.JDBCNamesType;
import amgen.ri.aig.constants.TModelCommonNameFactory;
import amgen.ri.aig.entity.EntityClassManager;
import amgen.ri.aig.entityrules.EntityRulesFactory;
import amgen.ri.aig.entityrules.EntityRulesIF;
import amgen.ri.aig.favorites.Favorite;
import amgen.ri.aig.sobj.ObjectType;
import amgen.ri.aig.sv.ServiceAttributes;
import amgen.ri.aig.vqt.VQTResultLoader3;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rdb.*;
import amgen.ri.servlet.SessionLogin;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtDate;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.io.IOException;
import java.lang.reflect.Field;
import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.wsdl.WSDLException;
import javax.xml.rpc.ServiceException;
import javax.xml.soap.SOAPException;
import javax.xml.transform.TransformerException;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;

/**
 * RDBData wrapper class for EntityList
 *
 * @version $Revision: 1.13 $
 * @author Jeffrey McDowell
 * @author $Author: jemcdowe $
 */
public class EntityList extends RdbData implements Saveable, Removeable, EntityListIF, List<EntityListMemberIF> {
  protected OraSequenceField list_id;
  protected String name;
  protected String description;
  protected String list_category;
  protected Timestamp created;
  protected String created_by;
  protected Timestamp modified;
  protected String modified_by;
  protected String list_type;
  protected EntityListMember[] listMembers;
  protected EntityListSourceService[] sourceService;
  private List<EntityListMemberIF> members;
  private String orderByField;
  private boolean orderByAscending;
  private EntityClassManager entityClassManager;

  /**
   * Default Constructor
   */
  public EntityList() {
    super();
  }

  /**
   * RdbData Constructor
   */
  public EntityList(String list_id, SQLManagerIF sqlManager, String logonusername, String connectionPool) {
    super(sqlManager, logonusername, connectionPool);
    this.list_id = new OraSequenceField(list_id);
  }

  /**
   * Constructor which sets the class variables
   */
  public EntityList(String name, String description, ServiceDataCategory serviceDataCategory, String created_by, ServiceDetails serviceDetails, SQLManagerIF sqlManager, String connectionPool) {
    super(sqlManager, null, connectionPool);
    this.list_id = new OraSequenceField("entity_list_seq", this);
    this.name = name;
    this.description = description;
    setListCategory(serviceDataCategory);
    this.created = new Timestamp(System.currentTimeMillis());
    this.created_by = created_by;
    this.modified = new Timestamp(System.currentTimeMillis());
    this.modified_by = created_by;
    if (serviceDetails != null) {
      sourceService = new EntityListSourceService[]{new EntityListSourceService(this.list_id.intValue(), serviceDetails, sqlManager, null, connectionPool)};
    }
  }

  /**
   * Constructor which sets the class variables
   */
  public EntityList(String name, String description, EntityListCategory listCategory, String created_by, SQLManagerIF sqlManager, String connectionPool) {
    super(sqlManager, null, connectionPool);
    this.list_id = new OraSequenceField("entity_list_seq", this);
    this.name = name;
    this.description = description;
    this.list_category = listCategory + "";
    this.created = new Timestamp(System.currentTimeMillis());
    this.created_by = created_by;
    this.modified = new Timestamp(System.currentTimeMillis());
    this.modified_by = created_by;

  }

  /**
   * Create an EntityList from a TreeNode
   *
   * @param name String
   * @param description String
   * @param resultNode Element
   * @param request HttpServletRequest
   * @param sqlManager SQLManagerIF
   * @param connectionPool String
   * @throws AIGException
   * @throws ServletException
   */
  public EntityList(String name, String description, TreeNode resultNode, HttpServletRequest request, SQLManagerIF sqlManager, String connectionPool) throws AIGException, ServletException {
    super(sqlManager, null, connectionPool);
    if (!resultNode.isNodeType(NodeType.RESULTNODE) && resultNode.isNodeType(NodeType.SERVICENODE)) {
      throw new AIGException("Invalid node type", Reason.UNKNOWN_ENTITY_TYPE);
    }
    SessionLogin sessionLogin = SessionLogin.getSessionLogin(request);
    TreeNodeCache tnCache = TreeNodeCache.getTreeNodeCache(request);
    List<String> childUUIDs = tnCache.getChildTreeNodeKeys(resultNode.getNode());
    if (childUUIDs.size() == 0) {
      throw new AIGException("No child nodes", Reason.UNKNOWN_ENTITY_TYPE);
    }
    Element firstChildNode = tnCache.getTreeNode(childUUIDs.get(0));
    ServiceDataCategory listDataCategory = ServiceDataCategory.getServiceDataCategory(firstChildNode);
    if (listDataCategory.equals(ServiceDataCategory.UNKNOWN)) {
      throw new AIGException("Invalid list category", Reason.UNKNOWN_ENTITY_TYPE);
    }
    this.list_id = new OraSequenceField("entity_list_seq", this);
    this.name = name;
    this.description = description;
    setListCategory(listDataCategory);
    this.created = new Timestamp(System.currentTimeMillis());
    this.created_by = sessionLogin.getRemoteUser();
    this.modified = new Timestamp(System.currentTimeMillis());
    this.modified_by = created_by;
    for (String childUUID : childUUIDs) {
      Element childNode = tnCache.getTreeNode(childUUID);
      if (childNode != null) {
        TreeNode childTreeNode = new TreeNode(childNode);
        if (childTreeNode.getServiceData() != null && childTreeNode.isServiceDataCategory(listDataCategory)) {
          String label = childTreeNode.getText();
          addListMember(label, childTreeNode.getServiceData(), childTreeNode.getServiceDataCategory());
        }
      }
    }
  }

  /**
   * Convenience method to return an EntityList for a listID
   *
   * @param listID EntityList
   * @return EntityList
   */
  public static EntityList getEntityList(String listID) {
    if (listID == null) {
      return null;
    }
    return new EntityList(listID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
  }

  /**
   * Create a copy of an existing list
   *
   * @param entityList EntityList
   * @param created_by String
   * @return EntityList
   */
  public static EntityList createCopy(EntityList entityList, String created_by) {
    if (entityList.setData()) {
      EntityList newEntityList = new EntityList(entityList.getName(), entityList.getDescription(), entityList.getEntityCategory(),
              created_by, entityList.getSQLManager(), entityList.getConnectionPool());
      return newEntityList;
    }
    return null;
  }

  /**
   * Create a copy of an existing list retrieved by its list id
   *
   * @param listID EntityList
   * @param created_by String
   * @return EntityList
   */
  public static EntityList createCopy(String listID, String created_by) {
    EntityList entityList = new EntityList(listID, new OraSQLManager(), null, JDBCNamesType.RG_JDBC+"");
    if (entityList.setData()) {
      EntityList newEntityList = new EntityList("Copy of " + entityList.getName(), entityList.getDescription(), entityList.getEntityCategory(),
              created_by, entityList.getSQLManager(), entityList.getConnectionPool());
      for (EntityListMemberIF member : entityList.getListMembers()) {
        newEntityList.addListMember(new GenericEntityListMember(member));
      }
      return newEntityList;
    }
    return null;
  }

  /**
   * Returns basic information about a list (name, description, member count,
   * list category in a GenericEntityList List
   *
   * @param listDataCategory ServiceDataCategory
   * @param created_by String
   * @return List
   */
  public static Map<Integer, GenericEntityList> getBasicEntityListInfo(ServiceDataCategory listDataCategory, String created_by) {
    Map<Integer, GenericEntityList> lists = new LinkedHashMap<Integer, GenericEntityList>();
    try {
      EntityListCategory category = new EntityClassManager().convertServiceDataCategoryToEntityListCategory(listDataCategory);
      ResultSet rset = new OraSQLManager().executeQuery(
              "SELECT EL.LIST_ID LIST_ID, EL.NAME NAME, EL.DESCRIPTION DESCRIPTION, (SELECT COUNT(LIST_ID) FROM "
              + "ENTITY_LIST_MEMBERS EE WHERE EE.LIST_ID= EL.LIST_ID) CNT FROM USER_ENTITY_LISTS EL "
              + "WHERE  EL.CREATED_BY= ? AND LIST_CATEGORY= ? ORDER BY UPPER(EL.NAME)",
              new String[]{created_by, category + ""}, JDBCNamesType.RG_JDBC+"");
      while (rset.next()) {
        int list_id = rset.getInt("list_id");
        String name = rset.getString("NAME");
        String desc = rset.getString("DESCRIPTION");
        int count = rset.getInt("CNT");
        GenericEntityList list = new GenericEntityList(name, desc,
                category, rset.getInt("CNT"));
        lists.put(list_id, list);
      }
      OraSQLManager.closeResources(rset);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return lists;
  }

  /**
   * Sets the list category based on the ServiceDataCategory
   *
   * @param serviceDataCategory ServiceDataCategory
   */
  private void setListCategory(ServiceDataCategory serviceDataCategory) {
    list_category = new EntityClassManager().convertServiceDataCategoryToEntityListCategory(serviceDataCategory).toString();
    if (list_category.equals("UNKNOWN")) {
      throw new IllegalArgumentException("Unknown data category");
    }
  }

  /**
   * Returns whether this EntityList's list category matches the
   * ServiceDataCategory
   *
   * @param serviceDataCategory ServiceDataCategory
   * @return boolean
   */
  public boolean matchesListCategory(ServiceDataCategory serviceDataCategory) {
    if (serviceDataCategory == null || serviceDataCategory.equals(ServiceDataCategory.UNKNOWN)) {
      return false;
    }
    EntityListCategory category = getEntityClassManager().convertServiceDataCategoryToEntityListCategory(serviceDataCategory);
    if (category.equals(EntityListCategory.UNKNOWN)) {
      return false;
    }
    return category.equals(getEntityCategory());
  }

  /**
   * A required method which returns the primary key(s) of the table/RdbData
   * class.
   */
  public String getIdentifier() {
    return list_id + "";
  }

  /**
   * This method is required EXACTLY as written to allow the RdbData
   * architecture access to the class variables.
   */
  protected void setFieldValue(Field field, Object value) throws IllegalAccessException {
    field.set(this, value);
  }

  /**
   * This method is required EXACTLY as written to allow the RdbData
   * architecture access to the class variables.
   */
  protected Object getFieldValue(Field field) throws IllegalAccessException {
    return field.get(this);
  }

  /**
   * This method returns the name of the table.
   */
  protected String getTableName() {
    return "ENTITY_LIST";
  }

  /**
   * Returns the SQL for INSERTing the object in the table
   */
  public String getInsertSQL() {
    return null;
  }

  /**
   * Returns the SQL for UPDATing the object in the table
   */
  public String getUpdateSQL() {
    return null;
  }

  /**
   * Returns the SQL for DELTEing the object/row in the table
   */
  public String getDeleteSQL() {
    return null;
  }

  protected String getArrayIdentifier(String fieldName, ResultSet rset) throws SQLException {
    return rset.getString(1);
  }

  protected String getMemberSQL(String fieldName) {
    if (fieldName.equals("listMembers")) {
      String orderByClause = "";
      if (orderByField != null) {
        orderByClause = " order by " + orderByField + (orderByAscending ? " ASC " : " DESC ");
      }

      return "SELECT ENTITY_LIST_MEMBER_ID, LIST_ID, MEMBER FROM ENTITY_LIST_MEMBERS "
              + " WHERE ENTITY_LIST_MEMBERS.LIST_ID=? AND ROWNUM<=10000 " + orderByClause;
    }
    return super.getMemberSQL(fieldName);
  }

  /**
   * Called when an RdbData array element is set. Default implementation does
   * nothing.
   *
   * @param rdbData new array element
   */
  protected void arrayElementSet(String fieldName, RdbData rdbData, ResultSet arrayRset) {
    if (fieldName.equals("listMembers")) {
      try {
        String entityListMemberID = arrayRset.getString("ENTITY_LIST_MEMBER_ID");
        int listID = arrayRset.getInt("LIST_ID");
        String member = arrayRset.getString("MEMBER");
        rdbData.set("list_id", listID);
        rdbData.set("member", member);
        rdbData.setIsDataSet(true, true);
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
  }

  /**
   * Get value for name
   */
  public String getName() {
    return (String) get("name");
  }

  /**
   * Set value for name
   */
  public void setName(String name) {
    set("name", name);
  }

  /**
   * Get value for description
   */
  public String getDescription() {
    return (String) get("description");
  }

  /**
   * Get value for list_type
   */
  public String getListType() {
    return (String) get("list_type");
  }

  /**
   * Set value for description
   */
  public void setDescription(String description) {
    set("description", description);
  }

  /**
   * Set value for list_category
   */
  public void setList_category(String list_category) {
    set("list_category", list_category);
  }

  /**
   * Set value for list_type
   */
  public void setList_type(String list_type) {
    set("list_type", list_type);
  }

  /**
   * Get value for created
   */
  public Timestamp getCreated() {
    return (Timestamp) get("created");
  }

  /**
   * Get value for created_by
   */
  public String getCreated_by() {
    return (String) get("created_by");
  }

  /**
   * Set value for created_by
   */
  public void setCreated_by(String created_by) {
    set("created_by", created_by);
  }

  /**
   * Get value for modified
   */
  public Timestamp getModified() {
    return (Timestamp) get("modified");
  }

  /**
   * Get value for modified_by
   */
  public String getModified_by() {
    return (String) get("modified_by");
  }

  /**
   * Clears the EntityListMember from the EntityList and delete from the
   * database
   *
   * @return the number of delete commits
   */
  public int clearListMembers() {
    int deleteCount = 0;
    for (EntityListMember member : getEntityListMembers()) {
      deleteCount += member.performDelete();
    }
    listMembers = new EntityListMember[0];
    members= null;
    return deleteCount;

  }

  /**
   * Adds a new list member to the list if the ServiceDataCategory matches the
   * list category
   *
   * @param memberID String
   * @param serviceDataCategory ServiceDataCategory
   * @return EntityListMember
   */
  public EntityListMemberIF addListMember(EntityListMemberIF member, ServiceDataCategory serviceDataCategory) {
    if (!matchesListCategory(serviceDataCategory)) {
      return null;
    }
    return addListMember(member);
  }

  /**
   * addListMember
   *
   * @param label String
   * @param string String
   * @param serviceDataCategory ServiceDataCategory
   */
  public EntityListMemberIF addListMember(String label, String member, ServiceDataCategory serviceDataCategory) {
    return addListMember(new GenericEntityListMember(label, member, null, getEntityCategory()), serviceDataCategory);
  }

  /**
   * addListMember
   *
   * @param label String
   * @param string String
   * @param serviceDataCategory ServiceDataCategory
   */
  public EntityListMemberIF addListMember(String label, String member, String description, ServiceDataCategory serviceDataCategory) {
    return addListMember(new GenericEntityListMember(label, member, description, getEntityCategory()), serviceDataCategory);
  }

  /**
   * Sets the given list of members as the list
   *
   * @param members String
   * @return EntityListMember
   */
  public EntityListMember[] setListMembers(EntityListMemberIF[] members) {
    return setListMembers(Arrays.asList(members));
  }

  /**
   * Sets the given list of members as the list
   *
   * @param members Collection
   * @return EntityListMember
   */
  public EntityListMember[] setListMembers(Collection<String> members) {
    return setListMembers(GenericEntityListMember.createEntityListMembers(members, getEntityCategory()));
  }

  /**
   * Sets the given list of members as the list
   *
   * @param members list
   * @return EntityListMember
   */
  public EntityListMember[] setListMembers(List<EntityListMemberIF> members) {
    if (members != null) {
      for (EntityListMember entityListMember : getEntityListMembers()) {
        entityListMember.performDelete();
      }
      List<EntityListMember> newMembers = new ArrayList<EntityListMember>();
      for (EntityListMemberIF member : members) {
        member = validateNewListMember(member, false);
        if (member != null) {
          EntityListMember newMember = new EntityListMember(list_id.intValue(), member.getMember(), getSQLManager(), getLogonUsername(), getConnectionPool());
          newMembers.add(newMember);
        }
      }
      listMembers = (EntityListMember[]) newMembers.toArray(new EntityListMember[0]);
    }
    members = null;
    return listMembers;
  }

  /**
   * Adds a new list member to the list
   *
   * @param memberID String
   * @param serviceDataCategory ServiceDataCategory
   * @return EntityListMember
   */
  private EntityListMember addListMember(EntityListMemberIF member) {
    member = validateNewListMember(member, true);
    if (member != null) {
      EntityListMember newMember = new EntityListMember(list_id.intValue(), member.getMember(), getSQLManager(), getLogonUsername(), getConnectionPool());
      listMembers = (EntityListMember[]) ExtArray.append(listMembers, newMember);
      members = null;
      return newMember;
    }
    return null;
  }

  private EntityListMemberIF validateNewListMember(String member, boolean verifyUnique) {
    return validateNewListMember(new GenericEntityListMember(member, getEntityCategory()), verifyUnique);
  }

  private EntityListMemberIF validateNewListMember(EntityListMemberIF member, boolean verifyUnique) {
    if (member == null || !ExtString.hasTrimmedLength(member.getMember())) {
      return null;
    }
    EntityRulesIF entityRules = EntityRulesFactory.getInstance().getEntityRules(getEntityCategory());
    member = entityRules.applyEntityRules(member, ServiceDataCategory.UNKNOWN);
    if (member == null) {
      return null;
    }
    if (!verifyUnique) {
      return member;
    }
    return (containsMember(member) ? null : member);
  }

  /**
   * Set value for modified_by
   */
  public void setModified_by(String modified_by) {
    set("modified_by", modified_by);
  }

  /**
   * Performs a commit on this object saving to the database the current values
   * of the fields and performs a commit on all the EntityListMember objects
   */
  public int performCommitAll(String modified_by) {
    this.modified = new Timestamp(System.currentTimeMillis());
    this.modified_by = modified_by;
    int updateCount = performCommit(true);
    for (EntityListMember member : getEntityListMembers()) {
      member.setData();
      updateCount += member.performCommitAll();
    }
    if (getSourceService() != null) {
      for (EntityListSourceService source : sourceService) {
        source.setAllData();
        updateCount += source.performCommit(true);
      }
    }
    return updateCount;
  }

  /**
   * Performs a deep- delete on the EntityList including all members returning
   * the number of deleted rows.
   */
  public int performDelete() {
    int updateCount = clearListMembers();
    if (getSourceService() != null) {
      for (EntityListSourceService source : sourceService) {
        updateCount += source.performDelete();
      }
    }
    //Delete any Favorites
    List<Favorite> favorites = Favorite.getFavorite(getIdentifier(), ObjectType.LIST, getCreated_by(), getConnectionPool());
    for (Favorite favorite : favorites) {
      favorite.performDelete();
    }
    updateCount += super.performDelete();
    return updateCount;
  }

  /**
   * Returns the orderBy field or null if none
   *
   * @return String
   */
  public String getOrderByField() {
    return orderByField;
  }

  /**
   * Whether the order is ascending or descending
   *
   * @return boolean
   */
  public boolean isOrderByAscending() {
    return orderByAscending;
  }

  /**
   * Sets the orderBy field or null if none and whether the order is ascending
   * or descending.
   *
   * @param orderByField String
   * @param orderByAscending boolean
   */
  public void setOrderByField(String orderByField, boolean orderByAscending) {
    this.orderByField = orderByField;
    this.orderByAscending = orderByAscending;
  }

  /**
   * Returns the list as an XML document <EntityList name='name [# members]'
   * description='description' category='category' list_id='listID' />
   *
   * @return Element
   */
  public Element getAsElement(HttpServletRequest request) throws AIGException {
    return getAsElement(false, request);
  }

  /**
   * Returns the list as an JSON Object { name:'name', member_count:
   * 'member_count', description: 'description', category: 'category', list_id:
   * 'listID', members: [] }
   *
   * @return Element
   */
  public JSONObject getAsJSON(boolean includeMembers, HttpServletRequest request) throws AIGException, JSONException {
    JSONObject jObject = new JSONObject();
    Element listEL = getAsElement(includeMembers, request);
    List<Attribute> attrs = listEL.getAttributes();
    for (Attribute attr : attrs) {
      jObject.put(attr.getName(), attr.getValue());
    }
    if (includeMembers) {
      for (EntityListMember member : getEntityListMembers()) {
        jObject.append("members", member.getAsJSON(true));
      }
    }
    return jObject;

  }

  /**
   * Returns the list as an XML document optionally including the members as
   * <EntityList name='name' member_count='member_count'
   * description='description' category='category' list_id='listID'>
   * <EntityListMember member='member'> <Attribute
   * attribute_type='attribute_type' attribute_value='attribute_value'/>
   * </EntityListMember> </EntityList>
   *
   * @return Element
   * @param includeMembers boolean
   */
  public Element getAsElement(boolean includeMembers, HttpServletRequest request) throws AIGException {
    SessionLogin sessionLogin = null;
    try {
      sessionLogin = SessionLogin.getSessionLogin(request);
    } catch (ServletException e) {
      throw new AIGException(Reason.NO_SESSION_USER, e);
    }
    Element entityListEl = new Element("EntityList");
    entityListEl.setAttribute("name", getName());
    entityListEl.setAttribute("member_count", "" + size());
    entityListEl.setAttribute("description", (getDescription() == null ? "" : getDescription()));
    entityListEl.setAttribute("category", getEntityCategory() + "");
    entityListEl.setAttribute("can_refresh", (getSourceService() != null) + "");

    ExtXMLElement.addAttribute(entityListEl, "created_by",
            sessionLogin.getUserPreferredDisplayName(getCreated_by()), getCreated_by());
    entityListEl.setAttribute("created",
            ExtDate.getDateStringDate(AIGBase.DATE_FORMAT, new java.util.Date(getCreated().getTime()),
            sessionLogin.getUsersTimeZone(), sessionLogin.getUsersTimeZone()));
    ExtXMLElement.addAttribute(entityListEl, "modified_by",
            sessionLogin.getUserPreferredDisplayName(getModified_by()), getModified_by());
    entityListEl.setAttribute("modified",
            ExtDate.getDateStringDate(AIGBase.DATE_FORMAT, new java.util.Date(getModified().getTime()),
            sessionLogin.getUsersTimeZone(), sessionLogin.getUsersTimeZone()));

    switch (getEntityCategory()) {
      case COMPOUNDS:
        entityListEl.setAttribute("icon", "compounds");
        break;
      case PROJECTS:
        entityListEl.setAttribute("icon", "projects");
        break;
      case ASSAYS:
      case LOGICAL_ASSAYS:
        entityListEl.setAttribute("icon", "assays");
        break;
      case MOSAIC_PLATES:
        entityListEl.setAttribute("icon", "mosaic_plates");
        break;
      case ASSAY_TYPES:
        entityListEl.setAttribute("icon", "assays");
        break;
      case LOGICAL_ASSAY_TYPES:
        entityListEl.setAttribute("icon", "assays");
        break;
      case AMGEN_GENES:
        entityListEl.setAttribute("icon", "genes");
        break;
      case GENES:
        entityListEl.setAttribute("icon", "genes");
        break;
      case STUDIES:
      case WATSON_STUDIES:
      case GALILEO_STUDIES:
        entityListEl.setAttribute("icon", "study");
        break;
      case ARRAY_SERVER_PROJECTS:
        entityListEl.setAttribute("icon", "array_server_project");
        break;
      case EXPERIMENTS:
      case CELL_CULTURE_RUNS:
      case PEOPLE:
      case NOTEBOOKS:
      case PLATES:
      default:
        entityListEl.setAttribute("icon", "default");
        break;
    }
    entityListEl.setAttribute("list_id", getIdentifier());
    if (includeMembers) {
      for (EntityListMember member : getEntityListMembers()) {
        Element entityMemberEl = member.getAsElement(true);
        if (entityMemberEl != null) {
          entityListEl.addContent(entityMemberEl);
        }
      }
    }
    return entityListEl;
  }

  /**
   * Attempts to update the list using the original service.
   *
   * @param serviceCache ServiceCache
   * @param modified_by String
   * @return boolean
   * @throws IOException
   * @throws SOAPException
   * @throws JDOMException
   * @throws AIGException
   * @throws ServiceException
   * @throws TransformerException
   * @throws RemoteException
   * @throws WSDLException
   */
  public void updateListFromSourceService(AIGBase requestor) throws IOException, SOAPException, JDOMException, AIGException, ServiceException, TransformerException,
          RemoteException, WSDLException, SQLException {
    if (getSourceService() == null) {
      throw new AIGException("No service available for list", Reason.UNABLE_TO_SET_SERVICE);
    }
    String modifiedBy = requestor.getSessionLogin().getRemoteUser();
    ServiceCache serviceCache = ServiceCache.getServiceCache(requestor);
    ServiceDetails serviceDetails = getSourceService().getServiceDetails(serviceCache);
    ServiceAttributes serviceAttributes= new ServiceAttributes(serviceDetails, requestor.getEntityClassManager());
    if (serviceAttributes.isServiceVQTEngine()) {
      updateListFromVQTSourceService(requestor, serviceDetails);
      return;
    }

    if (!serviceDetails.isServiceReady()) {
      throw new AIGException("No valid service configuration available", Reason.NOT_ALL_PARAMS_SET);
    }

    String treeNodesBinding = null;
    if (serviceDetails.getResultTypeBinding(TModelCommonNameFactory.QUERYTREENODESDEFINITION_tMODELNAME) != null) {
      treeNodesBinding = TModelCommonNameFactory.QUERYTREENODESDEFINITION_tMODELNAME;
    } else if (serviceDetails.getResultTypeBinding(TModelCommonNameFactory.TREENODESXMLDEFINITION_tMODELNAME) != null) {
      treeNodesBinding = TModelCommonNameFactory.TREENODESXMLDEFINITION_tMODELNAME;
    }

    if (treeNodesBinding == null) {
      throw new AIGException("No valid service configuration available", Reason.UNABLE_TO_RUN_SERVICE);
    }
    Document treeNodesDoc = serviceDetails.executeService2JDocument(treeNodesBinding);
    List<Element> queryResultEntityTreeNodes = ExtXMLElement.getXPathElements(treeNodesDoc, "//TREENODE[@SERVICE_DATA_TYPE_CATEGORY]");
    if (queryResultEntityTreeNodes.size() > 0) {
      ServiceDataCategory resultServiceDataCategory = ServiceDataCategory.getServiceDataCategory(queryResultEntityTreeNodes.get(0));
      EntityListCategory resultEntityListCategory = requestor.getEntityClassManager().convertServiceDataCategoryToEntityListCategory(resultServiceDataCategory);
      if (resultEntityListCategory.equals(this.getEntityCategory())) {
        clearListMembers();
        List<Element> resultChildNodes = treeNodesDoc.getRootElement().getChildren("TREENODE");
        for (Element resultChildNode : resultChildNodes) {
          String resultServiceData = resultChildNode.getAttributeValue("SERVICE_DATA");
          if (!ExtString.hasLength(resultServiceData)) {
            resultServiceData = resultChildNode.getAttributeValue("TEXT");
          }
          addListMember(new GenericEntityListMember(resultServiceData, resultServiceData, resultChildNode.getAttributeValue("TITLE"), getEntityCategory()));
        }
        performCommitAll(modifiedBy);
      }
    } else {
      throw new AIGException("Service returned no results. List unchanged.", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }
  }

  /**
   * updateListFromVQTSourceService
   *
   * @param serviceCache ServiceCache
   * @param modified_by String
   * @return boolean
   */
  private void updateListFromVQTSourceService(AIGBase requestor, ServiceDetails serviceDetails) throws AIGException, IOException, JDOMException, RemoteException, ServiceException, WSDLException,
          SQLException {
    String modified_by = requestor.getSessionLogin().getRemoteUser();
    requestor.setServiceParameters(serviceDetails, null);

    if (!serviceDetails.isServiceReady()) {
      throw new AIGException("No valid service configuration available", Reason.NOT_ALL_PARAMS_SET);
    }
    int queryRunID = -1;
    Object vqtResult = serviceDetails.executeService();
    requestor.addRequestLogServiceInvocationDetails(serviceDetails);
    if (vqtResult != null) {
      if (vqtResult instanceof Number) {
        queryRunID = ((Number) vqtResult).intValue();
      } else if (vqtResult instanceof byte[]) {
        queryRunID = Integer.valueOf(new String((byte[]) vqtResult)).intValue();
      }
    }
    VQTResultLoader3 vqtResultLoader = new VQTResultLoader3(requestor, queryRunID, "RG");
    List<EntityListMemberIF> updatedMembers = vqtResultLoader.getEntityListMembers();
    if (updatedMembers.size() > 0) {
      clearListMembers();
      setListMembers(updatedMembers);
    } else {
      throw new AIGException("Service returned no results. List unchanged.", Reason.UNABLE_TO_RETRIEVE_ENTRY);
    }
  }


  /*
   **********************************
   * EntityListIF Implementations ******************************
   */
  /**
   * Get value for list_category
   *
   * @return EntityListCategory
   */
  @Override
  public EntityListCategory getEntityCategory() {
    return EntityListCategory.fromString((String) get("list_category"));
  }

  /**
   * Get name for the list
   *
   * @return String
   */
  @Override
  public String getListName() {
    return getName();
  }

  /**
   * Get description for the list
   *
   * @return String
   */
  @Override
  public String getListDescription() {
    return getDescription();
  }

  /**
   * Returns the members of the list
   *
   * @param delimiter String
   * @return String
   */

  @Override
  public String getListMemberIds(String delimiter) {
    if (!isEmpty()) {
      return ExtString.join(getListMemberIds(), delimiter);
    }
    return null;
  }

  /**
   * Returns the members of the list members IDs
   *
   * @return List
   */
  @Override
  public List<String> getListMemberIds() {
    List<String> listMemberIds = new ArrayList<String>();
    if (!isEmpty()) {
      for (EntityListMemberIF member : getListMembers()) {
        listMemberIds.add(member.getMember());
      }
    }
    return listMemberIds;
  }

  /**
   * Returns the members of the list in the provided List
   *
   * @param memberList List
   * @return List
   */
  @Override
  public List<EntityListMemberIF> getListMembers(List<EntityListMemberIF> memberList) {
    if (memberList != null) {
      memberList.addAll(getListMembers());
    }
    return memberList;
  }

  /**
   * Returns the members of the list
   */
  private EntityListMember[] getEntityListMembers() {
    if (listMembers == null) {
      EntityListMember[] members = (EntityListMember[]) get("listMembers");
      if (ExtArray.hasLength(members)) {
        for (EntityListMember member : members) {
          member.setDataCategory(getEntityCategory());
        }
      }
    }
    return (ExtArray.hasLength(listMembers) ? listMembers : new EntityListMember[0]);
  }

  /**
   * Returns the members of the list in a List
   *
   * @return List
   */
  @Override
  public List<EntityListMemberIF> getListMembers() {
    if (members == null) {
      members = new ArrayList<EntityListMemberIF>();
      EntityListMember[] listMembers = getEntityListMembers();
      for (EntityListMember listMember : listMembers) {
        members.add(new GenericEntityListMember(listMember));
      }
    }
    return members;
  }

  /**
   * Returns the number of members in the provided List
   */
  @Override
  public int getListMemberCount() {
    return getListMembers().size();
  }

  /**
   * Returns whether this list contains a member with this id
   *
   * @param memberID String
   * @return boolean
   */
  @Override
  public boolean containsMember(EntityListMemberIF member) {
    for (EntityListMemberIF entityListMember : getListMembers()) {
      if (entityListMember.getMember().equals(member.getMember())) {
        return true;
      }
    }
    return false;
  }

  /**
   * Returns the service source of the list, if available
   *
   * @return EntityListSourceServiceIF
   */
  @Override
  public EntityListSourceServiceIF getSourceService() {
    setData();
    if (sourceService != null && sourceService.length > 0) {
      return sourceService[0];
    }
    return null;
  }

  /**
   * Returns the number of elements in this list. If this list contains more
   * than <tt>Integer.MAX_VALUE</tt> elements, returns
   * <tt>Integer.MAX_VALUE</tt>.
   *
   * @return the number of elements in this list.
   */
  @Override
  public int size() {
    return getListMembers().size();
  }

  /**
   * Returns <tt>true</tt> if this list contains no elements.
   *
   * @return <tt>true</tt> if this list contains no elements.
   */
  @Override
  public boolean isEmpty() {
    return getListMembers().isEmpty();
  }

  /**
   *
   * Returns <tt>true</tt> if this list contains the specified element. More
   * formally, returns <tt>true</tt> if and only if this list contains at least
   * one element <tt>e</tt> such that
   * <tt>(o==null&nbsp;?&nbsp;e==null&nbsp;:&nbsp;o.equals(e))</tt>.
   *
   * @param o element whose presence in this list is to be tested.
   * @return <tt>true</tt> if this list contains the specified element.
   * @throws ClassCastException if the type of the specified element is
   * incompatible with this list (optional).
   * @throws NullPointerException if the specified element is null and this list
   * does not support null elements (optional).
   */
  @Override
  public boolean contains(Object o) {
    return getListMembers().contains(o);
  }

  /**
   * Returns an iterator over the elements in this list in proper sequence.
   *
   * @return an iterator over the elements in this list in proper sequence.
   */
  @Override
  public Iterator<EntityListMemberIF> iterator() {
    return getListMembers().iterator();
  }

  /**
   * Returns an array containing all of the elements in this list in proper
   * sequence. Obeys the general contract of the <tt>Collection.toArray</tt>
   * method.
   *
   * @return an array containing all of the elements in this list in proper
   * sequence.
   * @see Arrays#asList(Object[])
   */
  @Override
  public Object[] toArray() {
    return getListMembers().toArray();
  }

  /**
   * Returns an array containing all of the elements in this list in proper
   * sequence; the runtime type of the returned array is that of the specified
   * array. Obeys the general contract of the
   * <tt>Collection.toArray(Object[])</tt> method.
   *
   * @param a the array into which the elements of this list are to be stored,
   * if it is big enough; otherwise, a new array of the same runtime type is
   * allocated for this purpose.
   * @return an array containing the elements of this list.
   *
   * @throws ArrayStoreException if the runtime type of the specified array is
   * not a supertype of the runtime type of every element in this list.
   * @throws NullPointerException if the specified array is <tt>null</tt>.
   */
  @Override
  public <EntityListMemberIF> EntityListMemberIF[] toArray(EntityListMemberIF[] a) {
    return getListMembers().toArray(a);
  }

  // Modification Operations
  /**
   * Appends the specified element to the end of this list (optional operation).
   * <p>
   *
   * Lists that support this operation may place limitations on what elements
   * may be added to this list. In particular, some lists will refuse to add
   * null elements, and others will impose restrictions on the type of elements
   * that may be added. List classes should clearly specify in their
   * documentation any restrictions on what elements may be added.
   *
   * @param o element to be appended to this list.
   * @return <tt>true</tt> (as per the general contract of the
   * <tt>Collection.add</tt> method).
   *
   * @throws UnsupportedOperationException if the <tt>add</tt> method is not
   * supported by this list.
   * @throws ClassCastException if the class of the specified element prevents
   * it from being added to this list.
   * @throws NullPointerException if the specified element is null and this list
   * does not support null elements.
   * @throws IllegalArgumentException if some aspect of this element prevents it
   * from being added to this list.
   */
  @Override
  public boolean add(EntityListMemberIF o) {
    return (addListMember(o) != null);
  }

  /**
   * Removes the first occurrence in this list of the specified element
   * (optional operation). If this list does not contain the element, it is
   * unchanged. More formally, removes the element with the lowest index i such
   * that <tt>(o==null ? get(i)==null : o.equals(get(i)))</tt> (if such an
   * element exists).
   *
   * @param o element to be removed from this list, if present.
   * @return <tt>true</tt> if this list contained the specified element.
   * @throws ClassCastException if the type of the specified element is
   * incompatible with this list (optional).
   * @throws NullPointerException if the specified element is null and this list
   * does not support null elements (optional).
   * @throws UnsupportedOperationException if the <tt>remove</tt> method is not
   * supported by this list.
   */
  @Override
  public boolean remove(Object o) {
    return getListMembers().remove(o);
  }

  // Bulk Modification Operations
  /**
   *
   * Returns <tt>true</tt> if this list contains all of the elements of the
   * specified collection.
   *
   * @param c collection to be checked for containment in this list.
   * @return <tt>true</tt> if this list contains all of the elements of the
   * specified collection.
   * @throws ClassCastException if the types of one or more elements in the
   * specified collection are incompatible with this list (optional).
   * @throws NullPointerException if the specified collection contains one or
   * more null elements and this list does not support null elements (optional).
   * @throws NullPointerException if the specified collection is <tt>null</tt>.
   * @see #contains(Object)
   */
  @Override
  public boolean containsAll(Collection<?> c) {
    return getListMembers().containsAll(c);
  }

  /**
   * Appends all of the elements in the specified collection to the end of this
   * list, in the order that they are returned by the specified collection's
   * iterator (optional operation). The behavior of this operation is
   * unspecified if the specified collection is modified while the operation is
   * in progress. (Note that this will occur if the specified collection is this
   * list, and it's nonempty.)
   *
   * @param c collection whose elements are to be added to this list.
   * @return <tt>true</tt> if this list changed as a result of the call.
   *
   * @throws UnsupportedOperationException if the <tt>addAll</tt> method is not
   * supported by this list.
   * @throws ClassCastException if the class of an element in the specified
   * collection prevents it from being added to this list.
   * @throws NullPointerException if the specified collection contains one or
   * more null elements and this list does not support null elements, or if the
   * specified collection is <tt>null</tt>.
   * @throws IllegalArgumentException if some aspect of an element in the
   * specified collection prevents it from being added to this list.
   * @see #add(Object)
   */
  @Override
  public boolean addAll(Collection<? extends EntityListMemberIF> c) {
    for (EntityListMemberIF s : c) {
      add(s);
    }
    return true;
  }

  /**
   * Inserts all of the elements in the specified collection into this list at
   * the specified position (optional operation). Shifts the element currently
   * at that position (if any) and any subsequent elements to the right
   * (increases their indices). The new elements will appear in this list in the
   * order that they are returned by the specified collection's iterator. The
   * behavior of this operation is unspecified if the specified collection is
   * modified while the operation is in progress. (Note that this will occur if
   * the specified collection is this list, and it's nonempty.)
   *
   * @param index index at which to insert first element from the specified
   * collection.
   * @param c elements to be inserted into this list.
   * @return <tt>true</tt> if this list changed as a result of the call.
   *
   * @throws UnsupportedOperationException if the <tt>addAll</tt> method is not
   * supported by this list.
   * @throws ClassCastException if the class of one of elements of the specified
   * collection prevents it from being added to this list.
   * @throws NullPointerException if the specified collection contains one or
   * more null elements and this list does not support null elements, or if the
   * specified collection is <tt>null</tt>.
   * @throws IllegalArgumentException if some aspect of one of elements of the
   * specified collection prevents it from being added to this list.
   * @throws IndexOutOfBoundsException if the index is out of range (index &lt;
   * 0 || index &gt; size()).
   */
  @Override
  public boolean addAll(int index, Collection<? extends EntityListMemberIF> c) {
    return getListMembers().addAll(index, c);
  }

  /**
   * Removes from this list all the elements that are contained in the specified
   * collection (optional operation).
   *
   * @param c collection that defines which elements will be removed from this
   * list.
   * @return <tt>true</tt> if this list changed as a result of the call.
   *
   * @throws UnsupportedOperationException if the <tt>removeAll</tt> method is
   * not supported by this list.
   * @throws ClassCastException if the types of one or more elements in this
   * list are incompatible with the specified collection (optional).
   * @throws NullPointerException if this list contains one or more null
   * elements and the specified collection does not support null elements
   * (optional).
   * @throws NullPointerException if the specified collection is <tt>null</tt>.
   * @see #remove(Object)
   * @see #contains(Object)
   */
  @Override
  public boolean removeAll(Collection<?> c) {
    return getListMembers().removeAll(c);
  }

  /**
   * Retains only the elements in this list that are contained in the specified
   * collection (optional operation). In other words, removes from this list all
   * the elements that are not contained in the specified collection.
   *
   * @param c collection that defines which elements this set will retain.
   *
   * @return <tt>true</tt> if this list changed as a result of the call.
   *
   * @throws UnsupportedOperationException if the <tt>retainAll</tt> method is
   * not supported by this list.
   * @throws ClassCastException if the types of one or more elements in this
   * list are incompatible with the specified collection (optional).
   * @throws NullPointerException if this list contains one or more null
   * elements and the specified collection does not support null elements
   * (optional).
   * @throws NullPointerException if the specified collection is <tt>null</tt>.
   * @see #remove(Object)
   * @see #contains(Object)
   */
  @Override
  public boolean retainAll(Collection<?> c) {
    return getListMembers().retainAll(c);
  }

  /**
   * Removes all of the elements from this list (optional operation). This list
   * will be empty after this call returns (unless it throws an exception).
   *
   * @throws UnsupportedOperationException if the <tt>clear</tt> method is not
   * supported by this list.
   */
  @Override
  public void clear() {
    getListMembers().clear();
  }

  // Comparison and hashing
  // Positional Access Operations
  /**
   * Returns the element at the specified position in this list.
   *
   * @param index index of element to return.
   * @return the element at the specified position in this list.
   *
   * @throws IndexOutOfBoundsException if the index is out of range (index &lt;
   * 0 || index &gt;= size()).
   */
  @Override
  public EntityListMemberIF get(int index) {
    return getListMembers().get(index);
  }

  /**
   * Replaces the element at the specified position in this list with the
   * specified element (optional operation).
   *
   * @param index index of element to replace.
   * @param element element to be stored at the specified position.
   * @return the element previously at the specified position.
   *
   * @throws UnsupportedOperationException if the <tt>set</tt> method is not
   * supported by this list.
   * @throws ClassCastException if the class of the specified element prevents
   * it from being added to this list.
   * @throws NullPointerException if the specified element is null and this list
   * does not support null elements.
   * @throws IllegalArgumentException if some aspect of the specified element
   * prevents it from being added to this list.
   * @throws IndexOutOfBoundsException if the index is out of range (index &lt;
   * 0 || index &gt;= size()).
   */
  @Override
  public EntityListMemberIF set(int index, EntityListMemberIF element) {
    throw new UnsupportedOperationException();
  }

  /**
   * Inserts the specified element at the specified position in this list
   * (optional operation). Shifts the element currently at that position (if
   * any) and any subsequent elements to the right (adds one to their indices).
   *
   * @param index index at which the specified element is to be inserted.
   * @param element element to be inserted.
   *
   * @throws UnsupportedOperationException if the <tt>add</tt> method is not
   * supported by this list.
   * @throws ClassCastException if the class of the specified element prevents
   * it from being added to this list.
   * @throws NullPointerException if the specified element is null and this list
   * does not support null elements.
   * @throws IllegalArgumentException if some aspect of the specified element
   * prevents it from being added to this list.
   * @throws IndexOutOfBoundsException if the index is out of range (index &lt;
   * 0 || index &gt; size()).
   */
  @Override
  public void add(int index, EntityListMemberIF element) {
    throw new UnsupportedOperationException();
  }

  /**
   * Removes the element at the specified position in this list (optional
   * operation). Shifts any subsequent elements to the left (subtracts one from
   * their indices). Returns the element that was removed from the list.
   *
   * @param index the index of the element to removed.
   * @return the element previously at the specified position.
   *
   * @throws UnsupportedOperationException if the <tt>remove</tt> method is not
   * supported by this list.
   * @throws IndexOutOfBoundsException if the index is out of range (index &lt;
   * 0 || index &gt;= size()).
   */
  @Override
  public EntityListMemberIF remove(int index) {
    return getListMembers().remove(index);
  }

  /**
   * Returns the index in this list of the first occurrence of the specified
   * element, or -1 if this list does not contain this element. More formally,
   * returns the lowest index <tt>i</tt> such that <tt>(o==null ? get(i)==null :
   * o.equals(get(i)))</tt>, or -1 if there is no such index.
   *
   * @param o element to search for.
   * @return the index in this list of the first occurrence of the specified
   * element, or -1 if this list does not contain this element.
   * @throws ClassCastException if the type of the specified element is
   * incompatible with this list (optional).
   * @throws NullPointerException if the specified element is null and this list
   * does not support null elements (optional).
   */
  @Override
  public int indexOf(Object o) {
    return getListMembers().indexOf(o);
  }

  /**
   * Returns the index in this list of the last occurrence of the specified
   * element, or -1 if this list does not contain this element. More formally,
   * returns the highest index <tt>i</tt> such that <tt>(o==null ? get(i)==null
   * : o.equals(get(i)))</tt>, or -1 if there is no such index.
   *
   * @param o element to search for.
   * @return the index in this list of the last occurrence of the specified
   * element, or -1 if this list does not contain this element.
   * @throws ClassCastException if the type of the specified element is
   * incompatible with this list (optional).
   * @throws NullPointerException if the specified element is null and this list
   * does not support null elements (optional).
   */
  @Override
  public int lastIndexOf(Object o) {
    return getListMembers().lastIndexOf(o);
  }

  // List Iterators
  /**
   * Returns a list iterator of the elements in this list (in proper sequence).
   *
   * @return a list iterator of the elements in this list (in proper sequence).
   */
  @Override
  public ListIterator<EntityListMemberIF> listIterator() {
    return getListMembers().listIterator();
  }

  /**
   * Returns a list iterator of the elements in this list (in proper sequence),
   * starting at the specified position in this list. The specified index
   * indicates the first element that would be returned by an initial call to
   * the <tt>next</tt> method. An initial call to the <tt>previous</tt> method
   * would return the element with the specified index minus one.
   *
   * @param index index of first element to be returned from the list iterator
   * (by a call to the <tt>next</tt> method).
   * @return a list iterator of the elements in this list (in proper sequence),
   * starting at the specified position in this list.
   * @throws IndexOutOfBoundsException if the index is out of range (index &lt;
   * 0 || index &gt; size()).
   */
  @Override
  public ListIterator<EntityListMemberIF> listIterator(int index) {
    return getListMembers().listIterator(index);
  }

  /**
   * Returns a view of the portion of this list between the specified
   * <tt>fromIndex</tt>, inclusive, and <tt>toIndex</tt>, exclusive. (If
   * <tt>fromIndex</tt> and <tt>toIndex</tt> are equal, the returned list is
   * empty.) The returned list is backed by this list, so non-structural changes
   * in the returned list are reflected in this list, and vice-versa. The
   * returned list supports all of the optional list operations supported by
   * this list.<p>
   *
   * This method eliminates the need for explicit range operations (of the sort
   * that commonly exist for arrays). Any operation that expects a list can be
   * used as a range operation by passing a subList view instead of a whole
   * list. For example, the following idiom removes a range of elements from a
   * list:
   * <pre>
   *	    list.subList(from, to).clear();
   * </pre> Similar idioms may be constructed for <tt>indexOf</tt> and
   * <tt>lastIndexOf</tt>, and all of the algorithms in the <tt>Collections</tt>
   * class can be applied to a subList.<p>
   *
   * The semantics of the list returned by this method become undefined if the
   * backing list (i.e., this list) is <i>structurally modified</i> in any way
   * other than via the returned list. (Structural modifications are those that
   * change the size of this list, or otherwise perturb it in such a fashion
   * that iterations in progress may yield incorrect results.)
   *
   * @param fromIndex low endpoint (inclusive) of the subList.
   * @param toIndex high endpoint (exclusive) of the subList.
   * @return a view of the specified range within this list.
   *
   * @throws IndexOutOfBoundsException for an illegal endpoint index value
   * (fromIndex &lt; 0 || toIndex &gt; size || fromIndex &gt; toIndex).
   */
  @Override
  public List<EntityListMemberIF> subList(int fromIndex, int toIndex) {
    return getListMembers().subList(fromIndex, toIndex);
  }

  /**
   * @return the entityClassManager
   */
  public EntityClassManager getEntityClassManager() {
    if (entityClassManager== null) {
      entityClassManager= new EntityClassManager();
    }
    return entityClassManager;
  }
}
