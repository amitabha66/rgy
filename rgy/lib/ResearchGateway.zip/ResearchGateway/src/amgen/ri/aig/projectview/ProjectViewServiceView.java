package amgen.ri.aig.projectview;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jdom.Document;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.AIGServlet;
import amgen.ri.aig.AIGException.Reason;
import amgen.ri.aig.AIGServlet.ExtJSVersion;
import amgen.ri.aig.cache.item.ServiceResultCacheItem;
import amgen.ri.aig.jawr.JawrLinkRenderer;
import amgen.ri.aig.preferences.PreferenceManager;
import amgen.ri.aig.projectview.model.ProjectViewModel;
import amgen.ri.aig.view.EntityServiceView;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.html.GenericHTMLElement;
import amgen.ri.html.HTMLElement;
import amgen.ri.html.Image;
import amgen.ri.html.Span;
import amgen.ri.html.Table;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.servlet.SessionLogin;
import amgen.ri.xml.ExtXMLElement;

public class ProjectViewServiceView extends EntityServiceView {

  public ProjectViewServiceView(AIGServlet aigServlet) {
    super(aigServlet);
  }

  /**
   * renderServiceResult
   *
   * @param resultItem ServiceResultCacheItem
   * @param outWriter Writer
   * @param outStream OutputStream
   * @throws IOException
   */
  public void renderServiceResult(Object resultObj, ServiceResultCacheItem projectViewResult, ServiceDetails serviceDetails, HttpServletRequest request, HttpServletResponse response) throws
          IOException, AIGException {
    AIGServlet aigServlet = getAigServlet();
    HTMLElement html = aigServlet.createRGHTMLElement("AIG Project View", ExtJSVersion.VERSION_2);
    HTMLElement body = (HTMLElement) html.addMemberElement(new GenericHTMLElement("BODY"));
    body.addMemberElement("SCRIPT").setText("document.domain='amgen.com'");
    ProjectViewModel projViewModel;

    try {
      String resultKey = projectViewResult.getResultKey();
      SessionLogin sessionLogin = SessionLogin.getSessionLogin(getAigServlet().getHttpServletRequest());
      Document pvDef = (Document) resultObj;

      if (ExtXMLElement.getXPathElement(pvDef, "/CompoundResults/AvailableViews[1]") == null
              && projectViewResult.getProperty("PROJECTVIEWDETAILS") != null) {
        projViewModel = (ProjectViewModel) projectViewResult.getProperty("PROJECTVIEWDETAILS");
        pvDef = projViewModel.getProjectViewDocument();
      }
      String projectName = ExtXMLElement.getXPathValue(pvDef, "/CompoundResults/AvailableViews/View[1]/@project_name");
      Number projectId = ExtXMLElement.getXPathNumberValue(pvDef, "/CompoundResults/AvailableViews/View[1]/@project_id");

      ServiceDetails pvPagingServiceDetails = aigServlet.getLooselyCoupledServiceDetails("PROJECTVIEW");
      projViewModel = (ProjectViewModel) projectViewResult.getProperty("PROJECTVIEWDETAILS");
      if (projViewModel == null) {
        projViewModel = new ProjectViewModel(pvDef, projectId.intValue(), projectName, projectViewResult.getResultKey(), getAigServlet());
        projectViewResult.setProperty("PROJECTVIEWDETAILS", projViewModel);
        projectViewResult.setServiceDetails(pvPagingServiceDetails);
      }
    } catch (Exception e) {
      e.printStackTrace();
      throw new AIGException("Unable to load project view", Reason.UNABLE_TO_RUN_SERVICE);
    }

    //Load the preferences from the saved preferences
    new PreferenceManager(getAigServlet(), projViewModel).setPreferences();
    
    HTMLElement loadingDiv = (HTMLElement) body.addMemberElement(new GenericHTMLElement("DIV"));
    loadingDiv.setId("init-loading");
    loadingDiv.setClassName("init-loading");
    Table loadingIndicatorDiv = (Table) loadingDiv.addMemberElement(new Table());
    Table.TableRow tableRow = loadingIndicatorDiv.addRow();
    Table.TableCell tableCell = tableRow.addCell();
    tableCell.addAttribute("VALIGN", "MIDDLE");
    Image loadingIndicatorImg = (Image) tableCell.addMemberElement(new Image("http://rg-resources/ext3/resources/images/default/s.gif"));
    loadingIndicatorImg.setWidth(32);
    loadingIndicatorImg.setHeight(32);
    loadingIndicatorImg.setStyle("margin-right:8px;");
    loadingIndicatorImg.setAlign(Image.ABSMIDDLE);
    loadingIndicatorImg.setClassName("init-loading-img");
    Table.TableCell textCell = tableRow.addCell("init-loading-cell");
    textCell.addAttribute("VALIGN", "MIDDLE");
    textCell.addMemberElement(new Span("Loading View...", "init-loading"));

    aigServlet.addCoreExtJsScripts(body, ExtJSVersion.VERSION_2, null);

    JawrLinkRenderer jawrLinkRenderer = new JawrLinkRenderer(aigServlet);
    jawrLinkRenderer.appendScriptLinks("/bundles/rgcore.js", body);
    jawrLinkRenderer.appendScriptLinks("/bundles/rgmainresources.js", body);
    jawrLinkRenderer.appendScriptLinks("/bundles/rgprojview.js", body);
    aigServlet.addJsScripts(body, "supplemental_imports.projectview");

    JSONObject viewportConfig = new JSONObject();
    try {
      JSONObject viewData = projViewModel.createViewJSON();
      viewportConfig.put("viewData", viewData);
      viewportConfig.put("url", "/aig/projectviewupdater.go?resultKey=" + projectViewResult.getResultKey());
    } catch (JSONException e) {
      throw new AIGException("Unable to create viewport configuration", AIGException.Reason.NOT_ALL_PARAMS_SET, e);
    }
    HTMLElement script = (HTMLElement) body.addMemberElement(new GenericHTMLElement("SCRIPT"));
    StringWriter scriptContents = new StringWriter();
    PrintWriter scriptContentsWriter = new PrintWriter(scriptContents);
    scriptContentsWriter.println("Ext.onReady(function(){var config= {};");
    scriptContentsWriter.println("try {Ext.fly('init-loading').remove();} catch (e) {}");

    scriptContentsWriter.println("createAIGProjectViewViewport(" + viewportConfig + ");");
    scriptContentsWriter.println("});");
    script.setText(scriptContents.toString());
    html.write(response.getWriter());
  }

  /**
   * Returns the mimetype for the view
   *
   * @return String
   */
  public String getViewMimetype() {
    return "text/html";
  }

  private void addKeyIfNotNull(JSONObject map, String key, Object value) {
    if (value == null) {
      map.remove(key);
    } else {
      try {
        map.put(key, value);
      } catch (JSONException ex) {
      }
    }
  }

  private void addKeyIfNotValue(JSONObject map, String key, Object value, Object invalidValue) {
    if (value == null || value.equals(invalidValue)) {
      map.remove(key);
    } else {
      try {
        map.put(key, value);
      } catch (JSONException ex) {
      }
    }
  }

}
