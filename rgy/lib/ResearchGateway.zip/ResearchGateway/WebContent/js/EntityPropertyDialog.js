/**
 * Window which displays an entity property Grid
 *
 *
 * @author    J. McDowell
 * @date      23 March 2009
 * @version   $Id: EntityPropertyDialog.js,v 1.2 2011/11/01 21:07:08 cvs Exp $
 *
 */
AIG.EntityPropertyDialog= Ext.extend(Ext.Window, {
  layout: 'border',
  stateful: false,
  resizable: true,
  closeAction: 'hide',
  plain: true,
  maximizable: true, 
  width: 500,
  height: 550,
  
  initComponent: function(){
    var dialog= this
    Ext.applyIf(this, {
      title: 'Entity Details',
      width: 500,
      height: 550,
      dialogType: 'entityproperties',
      suppressHeaderMaximize: true
    })
    switch (this.dialogType) {
      case 'selectablecontent':
        this.items = {
          region: 'center',
          border: true,
          bodyStyle: 'padding: 3px',
          html: this.content,
          autoScroll: true
        }
        break
      default:
        this.items = new AIG.EntityPropertyGrid({
          region: 'center',
          params: this.params,
          type: this.type,
          autoLoadStore: true
        })
        break;
    }
    this.buttons = [{
      text: 'Close',
      handler: function(){
        dialog.close()
      }
    }]
    AIG.EntityPropertyDialog.superclass.initComponent.call(this)
  },
  // private
  initEvents : function(){
    AIG.EntityPropertyDialog.superclass.initEvents.call(this);
    if (this.suppressHeaderMaximize) {
      this.header.un('dblclick', this.toggleMaximize, this)
    }
  }
})
  
  

