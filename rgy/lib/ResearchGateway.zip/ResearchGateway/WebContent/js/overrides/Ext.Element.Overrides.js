/* 
 * Ext.Element Overrides
 */
/*
 * This is an override that fixes the problem with IE9 and returning namespaced-attributes 
 * in an Element. It appears to be fixed in Ext3.4, so I commented it out. 
 * If needed later, I am keeping it around. (JM)
 */


/*
Ext.override(Ext.Element, {
  
  // Returns the value of a namespaced attribute from the element's underlying DOM node.
  // @param {String} namespace The namespace in which to look for the attribute
  // @param {String} name The attribute name
  // @return {String} The attribute value
  
  getAttributeNS: function(ns, name) {
    return this.getAttribute(name, ns);
  },

  getAttribute: (Ext.isIE && !(Ext.isIE9 && document.documentMode === 9)) ?

  // Essentially all web browsers (Firefox, Internet Explorer, recent versions of Opera, Safari, Konqueror, and iCab,
  // as a non-exhaustive list) return null when the specified attribute does not exist on the specified element.
  // The DOM specification says that the correct return value in this case is actually the empty string, and some
  // DOM implementations implement this behavior. The implementation of getAttribute in XUL (Gecko) actually follows
  // the specification and returns an empty string. Consequently, you should use hasAttribute to check for an attribute's
  // existence prior to calling getAttribute() if it is possible that the requested attribute does not exist on the specified element.
  //
  // https://developer.mozilla.org/en-US/docs/DOM/element.getAttribute
  // http://www.w3.org/TR/DOM-Level-2-Core/core.html#ID-745549614

  function(name, ns) {
    var d = this.dom,
    type;
    if (ns) {
      type = typeof d[ns + ":" + name];
      if (type != 'undefined' && type != 'unknown') {
        return d[ns + ":" + name] || null;
      }
      return null;
    }
    if (name === "for") {
      name = "htmlFor";
    }
    return d[name] || null;
  } : function(name, ns) {
    var d = this.dom;
    if (ns) {
      return d.getAttributeNS(ns, name) || d.getAttribute(ns + ":" + name);
    }
    return  d.getAttribute(name) || d[name] || null;
  }
})
*/