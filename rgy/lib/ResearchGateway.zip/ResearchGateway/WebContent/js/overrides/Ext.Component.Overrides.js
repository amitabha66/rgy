/* 
 * Ext.Component overrides
 */



Ext.override(Ext.Component, {
  findParentByInstanceOf : function(cls) {
    return this.findParentBy( function(p) {
      var cstr = p.constructor
      if (cstr === cls) {
        return true
      }
      var scls = cstr.superclass
      while (scls != null) {
        if (scls.constructor === cls) {
          return true
        }
        scls = scls.constructor.superclass
      }
    })
  }
})