/**
 * Ext.form.Field overrides
 */
Ext.override(Ext.form.Field, {
  initComponent : function() {
    Ext.form.Field.superclass.initComponent.call(this);
    this.on("render", function() {
      if (this.helpText || this.helpURL) {
        var wrapDiv = this.getEl().up('div.x-form-item');
        var label = wrapDiv.child('label');
        
        if (label) {
          var quickTipTag = null
          if (this.helpURL) {
            var helpTag = label.createChild({
              tag :'a',
              target :'_blank',
              href :this.helpURL,
              children :[{
                tag :'img',
                src :'/aig/img/information.png',
                style :'margin-bottom: 0px; margin-left: 5px; padding: 0px;'
              }]
            })
            quickTipTag = helpTag.first()

            helpTag.addListener("click", function(evt, element) {
              evt = evt.browserEvent || evt;
              var t = evt.target || evt.srcElement
              if (Ext.type(this.helpClickCB) == 'function') {
                this.helpClickCB.call(this.helpClickCBScope || this, this, helpTag)
              }
              
            }, this)
          } else {
            helpTag = label.createChild({
              tag :'img',
              src :'/aig/img/help2.gif',
              style :'margin-bottom: 0px; margin-left: 5px; padding: 0px;'
            })
            quickTipTag = helpTag
          }
          if (this.helpText) {
            Ext.QuickTips.register({
              target :quickTipTag,
              title :'',
              text :this.helpText,
              enabled :true
            })
          }
        }
      }
    }, this)
  },  
  /**
 * add a set Field label to Fields
 * 
 * @param {Object} text
 */
  setFieldLabel : function(text) {
    if (this.rendered) {
      this.el.up('.x-form-item', 10, true).child('.x-form-item-label').update(text + (this.labelSeparator || ':'));
    }
    this.fieldLabel = text;
  }
});
