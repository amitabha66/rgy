
Ext.override(Ext.data.Connection, {
  doFormUpload : function(o, ps, url) {
    var id = Ext.id();
    var frame = document.createElement('iframe');
    frame.id = id;
    frame.name = id;
    frame.className = 'x-hidden';
    if (Ext.isIE) {
      frame.src = Ext.SSL_SECURE_URL;
    }
    document.body.appendChild(frame);
    
    if (Ext.isIE) {
      document.frames[id].name = id;
    }
    
    var form = Ext.getDom(o.form);
    form.target = id;
    form.method = 'POST';
    form.enctype = form.encoding = 'multipart/form-data';
    if (url) {
      form.action = url;
    }
    var hiddens, hd;
    if (ps) { // add dynamic params
      hiddens = [];
      ps = Ext.urlDecode(ps, false);
      for ( var k in ps) {
        if (ps.hasOwnProperty(k)) {
          hd = document.createElement('input');
          hd.type = 'hidden';
          hd.name = k;
          hd.value = ps[k];
          form.appendChild(hd);
          hiddens.push(hd);
        }
      }
    }
    
    function cb() {
      var r = { // bogus response object
        responseText :'',
        responseXML :null
      };
      
      r.argument = o ? o.argument : null;
      
      try {
        var doc;
        if (Ext.isIE) {
          doc = frame.contentWindow.document;
        } else {
          doc = (frame.contentDocument || window.frames[id].document);
        }
        var ajaxResp = getMultipartAjaxResponse(window.frames[id])
        r.responseXML = ajaxResp.xml
        r.responseText = ajaxResp.text
      } catch (e) {
      }
      Ext.EventManager.removeListener(frame, 'load', cb, this);
      var validResponse = true
      var status = null

      try {
        if (hasLength(r.responseText)) {
          var textJson = Ext.util.JSON.decode(r.responseText)
          if (Ext.type(textJson) == 'object' && Ext.type(textJson.status) == 'object' && Ext.type(textJson.status.code) == 'number') {
            status = textJson.status
            var code = new Number(status.code)
            if (code && !isNaN(code) && code != 200 && code != 0) {
              validResponse = false
              if (o) {
                o.status = status
              }
              this.fireEvent("requestexception", this, r, o, status);
            }
          }
        }
      } catch (e) {
      }
      
      if (validResponse) {
        this.fireEvent("requestcomplete", this, r, o);
        Ext.callback(o.success, o.scope, [r, o]);
        Ext.callback(o.callback, o.scope, [o, true, r]);
      } else {
        Ext.callback(o.failure, o.scope, [r, o, status]);
      }
      
      setTimeout( function() {
        Ext.removeNode(frame);
      }, 100);
    }
    
    Ext.EventManager.on(frame, 'load', cb, this);
    form.submit();
    
    if (hiddens) { // remove dynamic params
      for ( var i = 0, len = hiddens.length; i < len; i++) {
        Ext.removeNode(hiddens[i]);
      }
    }
  }
})
