/**
 * Ext.form.DateField overrides
 * 
 * Includes updating the altFormats to accept the Java default Date String format
 */
Ext.override(Ext.form.DateField, {
  altFormats : "m/d/Y|n/j/Y|n/j/y|m/j/y|n/d/y|m/j/Y|n/d/Y|m-d-y|m-d-Y|m/d|m-d|md|mdy|mdY|d|Y-m-d|D M d G:i:s T Y"
})