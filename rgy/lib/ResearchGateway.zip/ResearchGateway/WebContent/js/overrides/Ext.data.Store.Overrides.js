/* 
 * Changes to Ext.data.Store
 */


/**
 * Override the Store sortData to optionally add a custom comparator to a field
 */

if (Ext.version.match(/^2\./)) {
  Ext.override(Ext.data.Store, {
    sortData : function(f, direction) {
      direction = direction || 'ASC';
      var fld = this.fields.get(f), st = fld.sortType;
      var fn = fld.comparator || function(r1, r2) {
        var v1 = st(r1.data[f]), v2 = st(r2.data[f]);
        // ADDED THIS FOR CASE INSENSITIVE SORT
        if (!this.sortCaseSensitive) {
          if (v1.toLowerCase && v2.toLowerCase) {
            v1 = v1.toLowerCase();
            v2 = v2.toLowerCase();
          }
        }
        return v1 > v2 ? 1 : (v1 < v2 ? -1 : 0);
      };
    
      this.data.sort(direction, fn);
      if (this.snapshot && this.snapshot != this.data) {
        this.snapshot.sort(direction, fn);
      }
    }, 
    /**
 * Change the sort on stores to case-insensitive
 * 
 * @param {Object} f
 * @param {Object} direction
 */
    sortIndexedData: function(f, direction) {
      direction = direction || 'ASC';
      var st = this.fields.get(f).sortType;
      var fn = function(r1, r2) {
        var v1 = st(r1.data[f])
        var v2 = st(r2.data[f]);
        // ADDED THIS FOR CASE INSENSITIVE SORT
        if (!this.sortCaseSensitive) {
          if (v1.toLowerCase) {
            v1 = v1.toLowerCase();
            v2 = v2.toLowerCase();
          }
        }
        return v1 > v2 ? 1 : (v1 < v2 ? -1 : 0);
      };
      this.data.sort(direction, fn);
      if (this.snapshot && this.snapshot != this.data) {
        this.snapshot.sort(direction, fn);
      }
    }
  })


 /**
 * This override adds a special optional sort field to the GroupingStore for doing the groupBy sort. The groupOrderField must have the same set of values for
 * the rows as the groupField BUT may be a different sortType than that of the groupField. i.e. groupField is generally string so the grouping is alphabetical
 * by that value, but suppose the required order is not alphabetical. Use the groupOrderField as the field to specify the group order. If the groupOrderField
 * and groupField values do not correspond THE GROUPING WILL GET ALL SCREWED UP!! So use carefully.
 * 
 * Also- this fixes a bug that requires sortInfo to be in the GroupingStore config. It doesn't.
 */
  Ext.override(Ext.data.GroupingStore, {
    // private
    applySort : function() {
      Ext.data.GroupingStore.superclass.applySort.call(this);
      if (!this.groupOnSort && !this.remoteGroup) {
        var si = this.sortInfo || {};
        var gs = this.getGroupState();
        if (gs && gs != si.field) {
          this.sortData(this.groupOrderField || this.groupField, this.groupOrderDir);
        }
      }
    }
  })
}