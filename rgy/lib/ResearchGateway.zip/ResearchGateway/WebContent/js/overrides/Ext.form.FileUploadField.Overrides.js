/* 
 * Ext.form.FileUploadField overrides
 */




/**
 * Override the Ext.form.FileUploadField.onShow to properly set the size of the textfield. The appears to be a bug in the implementation of the field when the
 * field is hidden/shown. http://www.extjs.com/forum/showthread.php?t=59556 describes a bit, but does not have this fix.
 */
Ext.override(Ext.form.FileUploadField, {
  initComponent : function() {
    Ext.form.FileUploadField.superclass.initComponent.call(this);
    /*
     * This doesn't appear necessary for Ext3.
     * Keeping in case its necessary. (JM)
     * 
     * 
    this.on("show", function(f) {
      if (!f.buttonOnly) {           
        var w = f.wrap.getWidth() - f.button.getEl().getWidth() - f.buttonOffset;        
        f.el.setWidth(w);
      }
    }, this)
    */
  }
})
