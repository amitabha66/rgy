/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 * Add the insertAtCursor function to TextField objects (including subclasses NumberField, TextArea, TriggerField)
 * 
 * @param {Object} text
 */
Ext.override(Ext.form.TextField, {
  insertAtCursor : function(text, selectOffset) {
    var field = this.getEl().dom
    if (document.selection) {// IE support
    field.focus();
    var sel = document.selection.createRange();
    sel.text = text;
    if (selectOffset) {
      sel.collapse(false);
      sel.moveEnd('character', selectOffset);
      sel.select()
    }
  } else if (field.selectionStart || field.selectionStart == '0') {// MOZILLA/NETSCAPE support
    field.focus();
    var startPos = field.selectionStart;
    var endPos = field.selectionEnd;
    field.value = field.value.substring(0, startPos) + text + field.value.substring(endPos, field.value.length);
    if (selectOffset != null) {
      field.setSelectionRange(startPos + text.length + selectOffset, startPos + text.length + selectOffset);
    }
  } else {
    field.value += text;
  }
},
getCursorPosition : function() {
  var field = this.getEl().dom
  var caretPos = 0;
  if (document.selection) { // IE Support
    field.focus();
    var sel = document.selection.createRange();
    var selLength = document.selection.createRange().text.length;
    sel.moveStart('character', -field.value.length);
    caretPos = sel.text.length - selLength;
  } else if (field.selectionStart || field.selectionStart == '0') { // Firefox support
    caretPos = field.selectionStart;
  }
  return caretPos
},
setCursorPosition : function(pos) {
  var field = this.getEl().dom
  if (field.setSelectionRange) {
    field.focus();
    field.setSelectionRange(pos, pos);
  } else if (field.createTextRange) {
    var range = field.createTextRange();
    range.collapse(true);
    range.moveEnd('character', pos);
    range.moveStart('character', pos);
    range.select();
  }
}
})
