/**
 * Set of Ext overrides and extensions for use in AIG
 * 
 * 
 * @author J. McDowell
 * @date 23 March 2009
 * @version $Id: aigoverrides.js,v 1.15 2015/03/05 22:26:06 jemcdowe Exp $
 * 
 */

try {
  Ext.menu.RangeMenu.prototype.icons = {
    gt :'http://uslv-papp-rgb02.amgen.com:9090/extjs/ext3/resources/images/greater_than.png',
    lt :'http://uslv-papp-rgb02.amgen.com:9090/extjs/ext3/resources/images/less_than.png',
    eq :'http://uslv-papp-rgb02.amgen.com:9090/extjs/ext3/resources/images/equals.png'
  };
  Ext.grid.filter.StringFilter.prototype.icon = 'http://uslv-papp-rgb02.amgen.com:9090/extjs/ext3/resources/images/find.png';
} catch (e) {
}


function toClipboard(text, show, append) {
  if (append) {
    text = window.clipboardData.getData("Text") + "\n\n" + text
  }
  window.clipboardData.setData("Text", text)

  if (show) {
    alert(text)
  }
}


/**
 * Exports the provided grid to Excel using the grids store. This also will export any subrows. Hidden columns will be exported if includeHidden is true.
 * 
 * Requires the RG middle tier.
 * 
 * @param {Object} grid The source grid
 * @param {Object} includeHidden Whether hidden columns are included in the export. Default= false
 */
AIG.excelExporter = function(grid, includeHidden, exportURL) {
  var cm = grid.getColumnModel()
  var store = grid.store
  exportURL = exportURL || "/aig/json2excel.go"

  var createJSON = function() {
    var table = {
      title :grid.title,
      columns :[],
      rows :[]
    }
    for ( var i = 0; i < cm.getColumnCount(); i++) {
      if ((includeHidden || !cm.isHidden(i)) && cm.getColumnId(i) != 'expander') {
        var column = {}
        table.columns.push(column)
        column.width = cm.getColumnWidth(i)
        column.header = cm.getColumnHeader(i)
        var fld = store.recordType.prototype.fields.get(cm.getDataIndex(i));
        if (!fld) {
          fld = {
            type :'string'
          }
        }
        column.type = fld.type
      }
    }
    for ( var i = 0, it = store.data.items, l = it.length; i < l; i++) {
      var r = it[i].data
      var row = []
      table.rows.push(row)
      for ( var j = 0; j < cm.getColumnCount(); j++) {
        if ((includeHidden || !cm.isHidden(j)) && cm.getColumnId(j) != 'expander') {
          row.push({
            value :r[cm.getDataIndex(j)],
            celltype :'normal'
          })
        }
      }
      if (it[i].subdata && Ext.type(it[i].subdata.records) == 'array') {
        for ( var j = 0; j < it[i].subdata.records.length; j++) {
          var subdata = it[i].subdata.records[j].data
          var subrow = []
          table.rows.push(subrow)
          for ( var k = 0; k < cm.getColumnCount(); k++) {
            if ((includeHidden || !cm.isHidden(k)) && cm.getColumnId(k) != 'expander') {
              subrow.push({
                value :Ext.util.Format.stripTags(subdata[cm.getDataIndex(k)]),
                celltype :'subdata'
              })
            }
          }
        }
      }
    }
    return table
  }
  if (!Ext.fly('form_temp')) {
    var frm = document.createElement('form');
    frm.id = 'form_temp';
    frm.name = id;
    frm.className = 'x-hidden';
    document.body.appendChild(frm);
  }
  Ext.Ajax.request({
    url :exportURL,
    method :'POST',
    form :Ext.fly('form_temp'),
    isUpload :true,
    params :{
      table :Ext.util.JSON.encode(createJSON())
    }
  })
}

