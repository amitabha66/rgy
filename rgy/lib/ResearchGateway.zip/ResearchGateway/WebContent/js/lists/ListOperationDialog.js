/**
 * Creates a List Operations Dialog
 * @author jemcdowe
 */
AIG.showListOperationDialog= function(config){
  config = config ||
  {}
  //View Layout
  var listOperationDialogOptions = {
    store: new Ext.data.SimpleStore({
      data: [['UNION', 'Union'], ['INTERSECTION', 'Intersection'], ['DIFFERENCE', 'Difference'], ['XOR', 'Complement']],
      fields: [{
        name: 'value'
      }, {
        name: 'name'
      }]
    }),
    fieldLabel: "List Operations",
    emptyText: "Please select an operation",
    allowBlank: false,
    mode: 'local',
    width: 230,
    displayField: "name",
    valueField: "value",
    value: config.value || 'UNION',
    disabled: config.disabled,
    forceSelection: true,
    editable: true,
    triggerAction: 'all',
    hiddenName: 'op',
    tpl: new Ext.XTemplate('<tpl for=".">', '<div class="x-combo-list-item">', 
      '<img src="/aig/img/list-{value:lowercase}.gif" align="absmiddle" border=0 style="margin-right:3px">{name}</div>', 
      '</tpl>')
  }
    
  var listOperationFormConfig = {
    frame: true,
    bodyStyle: 'padding:5px 5px 0',
    items: [{
      xtype: 'textfield',
      name: 'name',
      allowBlank: false,
      fieldLabel: 'Name',
      width: 230
    }, {
      xtype: 'textarea',
      name: 'description',
      fieldLabel: 'Description',
      width: 230,
      height: 75
    }, new Ext.form.ComboBox(listOperationDialogOptions)],
    itemCls: 'nowrap',
    autoWidth: true
  }
  var formPanel = new Ext.FormPanel(listOperationFormConfig)
    
  var listOperationDialog = new Ext.Window({
    title: config.title || 'Create New List By Combining',
    //layout: 'border',
    width: 400,
    height: 230,
    stateful: false,
    resizable: false,
    closeAction: 'hide',
    plain: true,
    items: [formPanel],
    buttons: [{
      text: 'Submit',
      scope: this,
      handler: function(){
        if (formPanel.getForm().isValid()) {
          var formValues = formPanel.getForm().getValues(false)
          listOperationDialog.close();
          listOperationDialog = null
          if (Ext.type(config.handler) == 'function') {
            config.handler.call(config.scope, formValues)
          }
                    
        }
      }
    }, {
      text: 'Close',
      handler: function(){
        listOperationDialog.close();
        listOperationDialog = null
      }
    }],
    listeners: {
      show: function(window){
        formPanel.items.get(0).focus(true, 100)
      }
    }
  });
  listOperationDialog.show()
}
