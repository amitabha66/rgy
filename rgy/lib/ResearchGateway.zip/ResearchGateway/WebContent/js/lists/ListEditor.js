/**
 * @author jemcdowe
 */
/*
 ********************************************************
 * Defines the AIG List Editor
 ********************************************************
 */
AIG.showListEditorWindow = function(config){
    config.region = 'center'
    var dialog = new Ext.Window({
        title: config.title || 'Edit List',
        iconCls: 'edit-list',
        layout: 'border',
        width: config.winWidth || 372,
        height: config.winHeight || 410,
        stateful: false,
        resizable: true,
        closeAction: 'hide',
        plain: true,
        modal: true,
        updateHandler: config.updateHandler,
        deleteHandler: config.deleteHandler,
        scope: config.scope,
        items: [new AIG.ListEditor(config)],
        buttons: [{
            cls: 'x-btn-text-icon',
            icon: '/aig/img/savelist.gif',
            text: (config.updateText ? config.updateText : 'Update'),
            handler: function(){
                var listEditor= dialog.getComponent(0)
                var fields= listEditor.getListFields()
                dialog.updateHandler.call(dialog.scope, fields.name, fields.description, fields.members)
                dialog.hide();
                dialog = null
            }
        }, {
            cls: 'x-btn-text-icon',
            icon: '/aig/img/delete.gif',
            text: 'Delete List',
            handler: function(){
                dialog.deleteHandler.call(dialog.scope)
                dialog.hide();
                dialog = null
            }
        }, {
            text: 'Cancel',
            handler: function(){
                dialog.hide();
                dialog = null
            }
        }]
    })
    dialog.show(config.target);
}
AIG.ListEditor = function(config){
    config = config ||
    {}
    
    this.listNameField = new Ext.form.TextField({
        name: "name",
        fieldLabel: "Name",
        width: 230,
        allowBlank: false
    })
    this.listDescField = new Ext.form.TextArea({
        name: "description",
        fieldLabel: "Description",
        width: 230,
        allowBlank: false
    })
    this.listMemberField = new Ext.form.TextArea({
        name: "members",
        fieldLabel: "Members",
        width: 230,
        height: 230,
        allowBlank: false
    })
    
    this.formPanel = new Ext.form.FormPanel({
        frame: true,
        autoScroll: true,
        items: [this.listNameField, this.listDescField, this.listMemberField]
    })
    if (config.showButtons) {
        this.updateButton = new Ext.Button({
            text: (config.updateText ? config.updateText : 'Update'),
            handler: config.updateHandler,
            scope: config.scope
        })
        this.deleteButton = new Ext.Button({
            text: (config.deleteText ? config.updateText : 'Delete'),
            handler: config.deleteHandler,
            scope: config.scope
        })
        var buttonPanel = new Ext.Panel({
            layout: "table",
            layoutConfig: {
                columns: 2
            },
            items: [this.updateButton, this.deleteButton]
        })
        config.items = [this.formPanel, buttonPanel]
    } else {
        config.items = [this.formPanel]
    }
    config.listeners = {
        render: function(panel){
            if (config.list_id) {
                panel.setListFieldsFromListID(panel.list_id)
            }
        }
    }
    Ext.apply(this, config)
    AIG.ListEditor.superclass.constructor.call(this)
}

Ext.extend(AIG.ListEditor, Ext.Panel, {
    setListFields: function(name, description, members){
        if (name) {
            this.listNameField.setValue(name)
        }
        if (description) {
            this.listDescField.setValue(description)
        }
        if (members) {
            if (Ext.isArray(members)) {
                this.listMemberField.setValue(members.join("\n"))
            } else {
                this.listMemberField.setValue(members)
            }
        }
    },
    getListFields: function(){
        return this.formPanel.getForm().getValues(false)
    },
    setListFieldsFromListID: function(listID){
        Ext.Ajax.request({
            url: "/aig/entitylist.go",
            success: function(response){
                var listName = selectSingleNodeValue(response.responseXML, '/EntityLists/EntityList/@name')
                var listDesc = selectSingleNodeValue(response.responseXML, '/EntityLists/EntityList/@description')
                var listMembers = selectNodeValues(response.responseXML, '/EntityLists/EntityList/EntityListMember/@member')
                this.setListFields(listName, listDesc, listMembers)
            },
            failure: function(response){
                Ext.MessageBox.show({
                    title: 'Update List',
                    msg: 'Unable to retrieve list.\n' + response.responseText,
                    buttons: Ext.MessageBox.OK,
                    icon: Ext.MessageBox.ERROR
                })
            },
            scope: this,
            params: {
                list_id: listID
            }
        })
    }
})




