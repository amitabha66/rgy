/**
 * Creates the Lists Panel 
 */
RG.Lists.ListsPanel2 = Ext.extend(Ext.grid.GridPanel, {
  autoScroll: true,
  autoExpandColumn: 'name',
  disableExportMenu: true,
  ddGroup :'aiglist',
  loadMask: true,
  defaultTemplate: new Ext.Template(
    '<div class="x-grid3-row ux-explorerview-detailed-icon-row {alt}">',
    '<table class="x-grid3-row-table"><tbody><tr><td class="x-grid3-col x-grid3-cell ux-explorerview-icon"><img src="/aig/icon.go?type=list&category={category}"></td>',
    '<td class="x-grid3-col x-grid3-cell"><div class="x-grid3-cell-inner" unselectable="on">{name}<br><span>{category_label}<br>{member_count} members</span></div></td></tr>',
    '</tbody></table></div>'
    ),
  defaultTemplate2: new Ext.Template(
    '<div class="x-grid3-row ux-explorerview-detailed-icon-row {alt}">',
    '<table class="x-grid3-row-table" style="background-color:white!important"><tbody><tr><td class="x-grid3-col x-grid3-cell ux-explorerview-icon"><img src="/aig/icon.go?type=list&category={category}"></td>',
    '<td class="x-grid3-col x-grid3-cell"><div class="x-grid3-cell-inner" unselectable="on">{name}<br><span>{category_label}<br>{member_count} members</span></div></td></tr>',
    '</tbody></table></div>'
    ),      
  view: new Ext.ux.grid.ExplorerView({
    rowTemplate: new Ext.Template(
      '<div class="x-grid3-row ux-explorerview-detailed-icon-row {alt}">',
      '<table class="x-grid3-row-table"><tbody><tr><td class="x-grid3-col x-grid3-cell ux-explorerview-icon"><img src="/aig/icon.go?type=list&category={category}"></td>',
      '<td class="x-grid3-col x-grid3-cell"><div class="x-grid3-cell-inner" unselectable="on">{name}<br><span>{category_label}<br>{member_count} members</span></div></td></tr>',
      '</tbody></table></div>'
      )
  }),  
  initComponent : function() {
    var panel= this        
    this.viewFormat= 'explorer'
    this.tbar= new Ext.Toolbar({
      items  : [{
        text: 'View Toggle',
        iconCls: 'x-group-by-icon',
        handler: panel.toggleView.createDelegate(panel)  
      },{      
        text: 'Filter',
        iconCls: 'ix-v0-16-funnel',        
        menu: new RG.Lists.FilterMenu({
          grid: panel
        })
      }]
    })    

    this.store = new Ext.data.Store({
      reader: new Ext.data.JsonReader({
        root: 'lists'
      }, RG.Record.ListRecord),
      url: '/aig/store.go?request=LISTS',
      sortInfo: {
        field: 'modified',
        direction: 'DESC'
      },
      autoLoad: true
    })
      
    this.columns = [{
      header: 'Name',
      id: 'name',
      sortable: true,
      dataIndex: 'name',
      renderer: function(value, metaData, record) {
        if (panel.viewFormat=='explorer') {
          return value
        }
        return '<img style="float:left;vertical-align:middle;padding-right: 20px" src="/aig/icon.go?type=list&category='+record.data.category+'">'+
        '<div style="vertical-align:middle">'+ value + '</div>'
      }
    }, {
      header: 'Created',
      width: 125,
      sortable: true,
      renderer: Ext.util.Format.dateRenderer('m/d/Y h:m A'),
      dataIndex: 'created'
    }, {
      header: 'Modified',
      width: 125,
      sortable: true,
      renderer: Ext.util.Format.dateRenderer('m/d/Y h:m A'),
      dataIndex: 'modified'
    }, {
      header: 'Type',
      width: 125,
      sortable: true,
      dataIndex: 'category_label'
    }, {
      header: 'Members',
      width: 125,
      sortable: true,
      dataIndex: 'member_count',
      align: 'right'
    }]    
  
    this.on('render', function(grid) {
      grid.initializeDragDropZones()
    })
    
    this.on('dblclick', function(e) {
      var record= null
      var t = Ext.lib.Event.getTarget(e);
      if (t) {
        var rowIndex = panel.getView().findRowIndex(t);
        if (rowIndex !== false) {         
          record= panel.getStore().getAt(rowIndex)
        }
      }
      if (!record || !record.data.list_id) {
        return
      }
      panel.loadList(record)
    })

    this.on("contextmenu", function(e) {
      e.preventDefault()
      e.stopPropagation()
      var record= null
      var t = Ext.lib.Event.getTarget(e);
      if (t) {
        var rowIndex = panel.getView().findRowIndex(t);
        if (rowIndex !== false) {         
          record= panel.getStore().getAt(rowIndex)
        }
      }
      if (!record || !record.data.list_id) {
        return
      }
      this.menuTargetRecord = record
      if (!this.menu) {
        this.menu = new Ext.menu.Menu({
          items: [{
            text: 'Open',
            icon: '/aig/img/openlist.gif',
            scope: this,
            handler: function(){
              this.loadList(this.menuTargetRecord)
            }
          }, {
            text: 'Refresh',
            icon: '/aig/img/refreshlist.gif',
            scope: this,
            handler: function(){
              this.refreshList({
                list_id: this.menuTargetRecord.data.list_id,
                name: this.menuTargetRecord.data.name
              })
            }
          }, {
            text: 'Edit',
            icon: '/aig/img/editlist.gif',
            scope: this,
            handler: function(){
              AIG.showListEditorWindow({
                //id: listEditorId,
                list_id: this.menuTargetRecord.data.list_id,
                updateHandler: function(name, desc, members){
                  this.updateList({
                    list_id: this.menuTargetRecord.data.list_id,
                    name: name,
                    description: desc,
                    members: members
                  })
                },
                deleteHandler: function(){
                  this.deleteList({
                    list_id: this.menuTargetRecord.data.list_id,
                    name: this.menuTargetRecord.data.name
                  })
                },
                scope: this
              })
            }
          }, {
            text: 'Copy',
            icon: '/aig/img/copylist.gif',
            scope: this,
            handler: function(){
              this.copyList({
                list_id: this.menuTargetRecord.data.list_id,
                name: this.menuTargetRecord.data.name
              })
            }
          }, {
            text: 'Copy List To Clipboard',
            icon: '/aig/img/copy.gif',
            scope: this,
            handler: function(){
              this.copyListToClipboard({
                list_id: this.menuTargetRecord.data.list_id,
                name: this.menuTargetRecord.data.name
              })
            }
          }, {
            text: 'Add to Favorites/Share',
            icon: '/aig/img/launchpad/favorites.gif',
            scope: this,
            handler: function(){
              RG.Favorites.createFavorite({
                name: this.menuTargetRecord.data.name,
                description: this.menuTargetRecord.data.description,
                type: 'LIST',
                key: this.menuTargetRecord.data.list_id
              })
            }
          }, {
            text: 'Delete',
            icon: '/aig/img/delete.gif',
            scope: this,
            handler: function(){
              this.deleteList({
                list_id: this.menuTargetRecord.data.list_id,
                name: this.menuTargetRecord.data.name
              })
            }
          }]
        })
      }
      this.menu.items.get(1).setDisabled(!this.menuTargetRecord.data.can_refresh)
      this.menu.showAt(e.getXY())
    })
    
    RG.Lists.ListsPanel2.superclass.initComponent.call(this);
  },  
  initializeDragDropZones : function() {
    var panel= this
    this.dropZone = new Ext.dd.DropZone(this.getEl(), {
      ddGroup :'aiglist',
      dropAllowed :panel.dropAllowed,
      grid :this,
      getTargetFromEvent : function(e) {
        var t = Ext.lib.Event.getTarget(e);
        if (t) {
          var rowIndex = this.grid.getView().findRowIndex(t);
          if (rowIndex !== false) {
            var sm = this.grid.selModel;
            if (!sm.isSelected(rowIndex) || e.hasModifier()) {
              sm.handleMouseDown(this.grid, rowIndex, e);
            }
            var record= sm.getSelections()[0]
            return {
              grid :this.grid,
              ddel :this.ddel,
              rowIndex :rowIndex,
              record :record,
              id: record.id
            };
          }
        }
        return false
      },
      onNodeOver : function(target, dd, e, data) {
        return panel.isValidDrop(target, data)
      },
      onNodeDrop : function(target, dd, e, data) {
        return panel.handleDrop(target, data)
      }
    });
    this.dropZone.addToGroup('aignodes')
    
    this.dragZone = new Ext.grid.GridDragZone(this, {
      ddGroup :'aiglist',
      getDragData : function(e) {
        var t = Ext.lib.Event.getTarget(e);
        if (t) {
          var rowIndex = this.view.findRowIndex(t);
          if (rowIndex !== false) {
            var sm = this.grid.selModel;
            if (!sm.isSelected(rowIndex) || e.hasModifier()) {
              sm.handleMouseDown(this.grid, rowIndex, e);
            }
            if (sm.getSelections().length == 0) {
              return false
            } else if (sm.getSelections().length == 1) {
              var record = sm.getSelections()[0]              
              if (!record || !record.data.list_id) {
                return false
              }
              return {
                grid :this.grid,
                ddel :this.ddel,
                rowIndex :rowIndex,
                record :record
              }
            } else if (sm.getSelections().length > 1) {
              return {
                grid :this.grid,
                ddel :this.ddel,
                rowIndex :rowIndex,
                record :sm.getSelections()
              }
            }
          }
        }
        return false;
      },
      onInitDrag : function(e) {
        var data = this.dragData;
        var dragRecords = data.record
        
        if (Ext.type(dragRecords) == 'object') {    
          this.ddel.innerHTML= panel.defaultTemplate.apply(dragRecords.data)
          this.proxy.update(this.ddel.innerHTML);
          return
        } else if (Ext.type(dragRecords) == 'array') {
          this.ddel.innerHTML = Ext.DomHelper.markup({
            tag :'span',
            unselectable :"on",
            style :"white-space: nowrap !important;",
            children :[{
              tag :'img',
              src :Ext.BLANK_IMAGE_URL,
              width :16,
              height :16,
              "class" :'multiple-dnd',
              style :"background-position: center center; background-repeat: no-repeat; border: 0 none; height: 16px; margin: 0; padding: 0; vertical-align: middle; width: 16px;"
            }, {
              tag :'span',
              unselectable :"on",
              style :"padding-left: 2px",
              html :dragRecords.length + ' selections'
            }]
          })
        } else {
          return
        }
        this.proxy.update(this.ddel);
      }
    });
  },  
  toggleView: function() {
    if (this.viewFormat== 'explorer') {
      this.viewFormat= 'grid'
      this.getView().changeTemplate(null)
    } else {
      this.viewFormat= 'explorer'
      this.getView().changeTemplate(this.defaultTemplate)      
    }
  },
  isValidDrop: function(target, data){
    var node = data.node
    //
    //Handles a DnD from a treenodes element DnD node
    if (node && node.attributes) {
      return this.isValidNodeDrop(target, node)
    } else {
      //
      //Handles a DnD from a list view element DnD node
      var dragRecord = data.record
      if (!dragRecord) {
        return Ext.dd.DragZone.dropNotAllowed
      }
      var dragRecordData = dragRecord.data
      var dragRecordListID = dragRecordData.list_id
      if (!target.record) {
        return Ext.dd.DragZone.dropNotAllowed
      }
      var targetRecordData = target.record.data
      if (!targetRecordData || !targetRecordData.category) {
        return Ext.dd.DragZone.dropNotAllowed
      }
      var targetRecordListID = targetRecordData.list_id
      if (targetRecordListID == dragRecordListID) {
        return Ext.dd.DragZone.dropNotAllowed
      }
      if (dragRecordData.category != targetRecordData.category) {
        return Ext.dd.DragZone.dropNotAllowed
      }
      return Ext.dd.DropZone.prototype.dropAllowed                        
    }
    return Ext.dd.DragZone.dropNotAllowed
  },
  /**
    * Returns whether the drop node data is valid for the target
    * @param {Object} target
    * @param {Object} node
    */
  isValidNodeDrop: function(target, node){
    if (!node || !node.attributes) {
      return Ext.dd.DragZone.dropNotAllowed
    }
    var attr = node.attributes
    var nodeType = attr.node_type
    if (!nodeType) {
      return Ext.dd.DragZone.dropNotAllowed
    }
    var hasChildNodes = (node.childNodes && node.childNodes.length > 0)
    switch (nodeType) {
      case "RESULTNODE":
      case "SERVICENODE":
        if (!hasChildNodes) {
          return Ext.dd.DragZone.dropNotAllowed
        }
        var record = this.store.getById(target.id)
        if (!record) {
          if (target.id == this.id) {
            return Ext.dd.DropZone.prototype.dropAllowed;
          }
          return Ext.dd.DragZone.dropNotAllowed
        }
        if (!RG.entityMatch(node, record)) {
          return Ext.dd.DragZone.dropNotAllowed
        }
        return Ext.dd.DropZone.prototype.dropAllowed
      case "ENTITYNODE":
        var record = this.store.getById(target.id)
        if (!record) {
          return Ext.dd.DragZone.dropNotAllowed
        }
        var recordData = record.data
        var serviceDataTypeCategory = null
        if (attr && attr.service_data_type_category) {
          serviceDataTypeCategory = attr.service_data_type_category
        }
        if (!serviceDataTypeCategory || !recordData || !recordData.category) {
          return Ext.dd.DragZone.dropNotAllowed
        }
        if (!RG.entityMatch(serviceDataTypeCategory, recordData.category)) {
          return Ext.dd.DragZone.dropNotAllowed
        }
        return Ext.dd.DropZone.prototype.dropAllowed
    }
  },
  handleDrop: function(target, data) {
    var node = data.node
    //
    //Handles a DnD from a treenodes element DnD node
    if (node && node.attributes) {
      if (this.isValidNodeDrop(target, node) != Ext.dd.DropZone.prototype.dropAllowed) {
        return false
      }
      var attr = node.attributes
      var nodeType = attr.node_type
                        
      switch (nodeType) {
        case "RESULTNODE":
        case "SERVICENODE":
          var record = this.store.getById(target.id)
          if (!record) {
            if (target.id == this.id) {
              this.createNewListFromNode(node)
              return true
            }
            return false
          }
          var recordData = record.data
          var node = {
            uuid: node.attributes.uuid,
            name: getNodeBaseText(node.attributes.text)
          }
                                
          var listID = recordData.list_id
          this.showListOperationDialog(node, recordData, null)
          return true;
        case "ENTITYNODE":
          var record = this.store.getById(target.id)
          if (!record) {
            return Ext.dd.DragZone.dropNotAllowed
          }
          var recordData = record.data
          var nodeUUID = node.attributes.uuid
          var listID = recordData.list_id
          this.addToListFromEntityNode(listID, node, recordData.name)
          return true
      }
    } else {
      //
      //Handles a DnD from a list view element DnD node
      var dragRecord = data.record
      if (!dragRecord) {
        return false
      }
      var dragRecordData = dragRecord.data
      var dragRecordListID = dragRecordData.list_id
      var targetRecord = this.store.getById(target.id)
      if (!targetRecord) {
        return false
      }
      var targetRecordData = targetRecord.data
      if (!targetRecordData || !targetRecordData.category) {
        return false
      }
      var targetRecordListID = targetRecordData.list_id
      if (targetRecordListID == dragRecordListID) {
        return false
      }
      if (dragRecordData.category != targetRecordData.category) {
        return false
      }
      this.showListOperationDialog(null, dragRecordData, targetRecordData)
      return true
    }
    return false    
  },
  /**
     * Load a list from the list panel
     * @param {Object} record
     */
  loadList: function(record){
    RG.Load.loadEntityList({
      list_id: record.data.list_id,
      list_name: record.data.name
    })
  },
  /**
     * Reloads the list store after a change
     */
  updateListPanel: function(){
    this.store.reload()
  },
  /**
     * Updates the list form after an update or delete
     * @param {Object} updateOrDelete
     */
  updateListForm: function(updateOrDelete){
    updateOrDelete = (updateOrDelete == null ? true : updateOrDelete)
    if (updateOrDelete) {
      Ext.getCmp("aig-tab-settings").updateIfView("list")
    } else {
      Ext.getCmp("aig-tab-settings").resetResourceSettingsPanel()
    }
  },
  updateList: function(listRecord){
    var entityListPanel = this
    entityListPanel.getEl().mask("Updating List")
    Ext.Ajax.request({
      url: "/aig/treenodeoperation.go",
      success: function(response){
        entityListPanel.getEl().unmask()
        if (!AIG.showErrorMessage(response)) {
          showInformationDialog('List updated.');
          entityListPanel.updateListPanel()
          entityListPanel.updateListForm()
        }
      },
      failure: function(){
        entityListPanel.getEl().unmask()
        Ext.MessageBox.show({
          title: 'Update List',
          msg: 'Unable to update list.',
          buttons: Ext.MessageBox.OK,
          icon: Ext.MessageBox.ERROR
        })
      },
      scope: this,
      params: {
        op: 'updatelist',
        list_id: listRecord.list_id,
        name: listRecord.name,
        description: listRecord.description,
        members: listRecord.members
      }
    })
  },
  refreshList: function(listRecord){
    Ext.Msg.show({
      title: 'Refresh List?',
      msg: 'This will attempt to refresh the list based on the original query used to create the list. ' +
      '<BR>Any changed made since the list was created will be lost.<BR>Continue?',
      width: 300,
      modal: true,
      buttons: Ext.MessageBox.YESNO,
      icon: Ext.MessageBox.WARNING,
      fn: function(buttonId){
        if (buttonId != 'yes') {
          return
        }
        var entityListPanel = this
        entityListPanel.getEl().mask("Refreshing List " + listRecord.name)
        Ext.Ajax.request({
          url: "/aig/treenodeoperation.go",
          success: function(response){
            entityListPanel.getEl().numask()
            if (!AIG.showErrorMessage(response)) {
              entityListPanel.updateListPanel()
              entityListPanel.updateListForm()
            }
          },
          failure: function(){
            entityListPanel.getEl().unmask()
            Ext.MessageBox.show({
              title: 'Refresh List',
              msg: 'Unable to update list.',
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
          },
          scope: this,
          params: {
            op: 'refreshlist',
            list_id: listRecord.list_id,
            name: listRecord.name
          }
        })
      },
      scope: this
    })
        
        
  },
  addToListFromEntityNode: function(listID, entityNode, listName){
    var entityListPanel = this
    entityListPanel.getEl().mask("Updating List " + listName)
    Ext.Ajax.request({
      url: "/aig/treenodeoperation.go",
      success: function(response){
        entityListPanel.getEl().unmask()
        if (!AIG.showErrorMessage(response)) {
          showInformationDialog('Added Entity to List')
          entityListPanel.updateListPanel()
          entityListPanel.updateListForm()
        }
      },
      failure: function(response){
        entityListPanel.getEl().unmask()
        this.updateListForm()
        Ext.MessageBox.show({
          title: 'Update List',
          msg: 'Unable to update list.\n' + response.responseText,
          buttons: Ext.MessageBox.OK,
          icon: Ext.MessageBox.ERROR
        })
      },
      scope: this,
      params: {
        op: 'addtolist',
        uuid: entityNode.attributes.uuid,
        list_id: listID
      }
    })
  },
  deleteList: function(listRecord){
    Ext.MessageBox.show({
      title: 'Delete List?',
      msg: 'Do you want to delete list ' + listRecord.name + '?',
      buttons: Ext.MessageBox.YESNO,
      fn: function(buttonId){
        if (buttonId != 'yes') {
          return
        }
        this.getEl().mask('Deleting list ' + listRecord.name)
        Ext.Ajax.request({
          url: "/aig/treenodeoperation.go",
          success: function(response){
            this.getEl().unmask()
            if (!AIG.showErrorMessage(response)) {
              showInformationDialog('List Deleted')
              this.updateListPanel()
              this.updateListForm()
            }
          },
          failure: function(){
            this.getEl().unmask()
            Ext.MessageBox.show({
              title: 'Delete List',
              msg: 'Unable to delete list.',
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
          },
          scope: this,
          params: {
            op: 'deletelist',
            list_id: listRecord.list_id
          }
        })
      },
      scope: this,
      icon: Ext.MessageBox.QUESTION
    });
  },
  showListOperationDialog: function(node, record1, record2){
    var listID1 = record1.list_id
    var listID2 = (record2 ? record2.list_id : null)
        
    AIG.showListOperationDialog({
      handler: function(values){
        var operation = values.op
        var title = (record2 ? record1.name + " " + operation + " " + record2.name : node.name + " " + operation + " " + record1.name)
        this.getEl().mask("Performing Operation: " + title)
        Ext.Ajax.request({
          url: "/aig/treenodeoperation.go",
          success: function(response){
            this.getEl().unmask()
            if (AIG.showErrorMessage(response)) {
              return
            }
            var data = null
            try {
              data = Ext.util.JSON.decode(response.responseText)
            } catch (e) {
            }
            if (data != null) {
              if (data.results == 0) {
                showInformationDialog('Operation returned no results.');
              } else {
                showInformationDialog("Created new list '" +
                  data.list_name +
                  "' with " +
                  data.results +
                  ' members');
                this.updateListPanel()
                this.updateListForm()
              }
            } else {
              this.updateListPanel()
              this.updateListForm()
            }
          },
          failure: function(response){
            this.getEl().unmask()
            this.updateListForm()
            Ext.MessageBox.show({
              title: 'List Combination',
              msg: 'Unable to save list.',
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
          },
          scope: this,
          params: {
            op: values.op,
            uuid: (node ? node.uuid : null),
            list_id1: listID1,
            list_id2: listID2,
            name: values.name,
            description: hasLength(values.description) || title
          }
        })
      },
      scope: this
    })
  },
  createNewListFromNode: function(node){
    var nodeUUID = (node ? node.attributes.uuid : null)
    if (!nodeUUID) {
      return
    }
    var entityListPanel = this
    AIG.NameDescriptionDialog({
      title: 'Create New List',
      ok_text: 'Save List',
      handler: function(values){               
        var name = values.name
        var description = values.description
        if (!name || name.length == 0) {
          Ext.MessageBox.show({
            title: 'Unable to Save List',
            msg: 'List name required.',
            buttons: Ext.MessageBox.OK,
            icon: Ext.MessageBox.ERROR
          })
          return
        }
        if (!description || description.length == 0) {
          description = 'List ' + name
        }
        entityListPanel.getEl().mask("Saving list " + name)
        Ext.Ajax.request({
          url: "/aig/treenodeoperation.go",
          success: function(){
            entityListPanel.getEl().unmask()
            showInformationDialog('List Created')
            var launcher= new RG.Loft.AppLauncher()
            launcher.reloadDialog(launcher.dialogIDs.LISTS_TOOL)
          },
          failure: function(){
            entityListPanel.getEl().unmask()
            Ext.MessageBox.show({
              title: 'Save List',
              msg: 'Unable to save list.',
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
          },
          scope: this,
          params: {
            op: 'savelist',
            uuid: nodeUUID,
            name: name,
            description: description
          }
        })
      }
    })
  },
  copyList: function(listRecord){
    var entityListPanel = this
    entityListPanel.getEl().mask("Copying list " + listRecord.name)
    Ext.Ajax.request({
      url: "/aig/treenodeoperation.go",
      success: function(response){
        entityListPanel.getEl().unmask()
        if (!AIG.showErrorMessage(response)) {
          showInformationDialog('List Copied')
          entityListPanel.updateListPanel()
          entityListPanel.updateListForm()
        }
      },
      failure: function(){
        entityListPanel.getEl().unmask()
        Ext.MessageBox.show({
          title: 'Copy List',
          msg: 'Unable to copy list.',
          buttons: Ext.MessageBox.OK,
          icon: Ext.MessageBox.ERROR
        })
      },
      scope: this,
      params: {
        op: 'copylist',
        list_id: listRecord.list_id
      }
    })
        
  },
  copyListToClipboard: function(listRecord){
    Ext.Ajax.request({
      url: "/aig/entitylist.go",
      success: function(response){
        var listName = selectSingleNodeValue(response.responseXML, '/EntityLists/EntityList/@name')
        var listDesc = selectSingleNodeValue(response.responseXML, '/EntityLists/EntityList/@description')
        var listMembers = selectNodeValues(response.responseXML, '/EntityLists/EntityList/EntityListMember/@member')
        AIG.ClipboardCtrl.setClipboardText((Ext.isArray(listMembers) ? listMembers.join("\n") : listMembers))
        showInformationDialog("List members copied to clipboard.")
      },
      failure: function(response){
        showErrorDialog('Error Copying List', 'Unable to retrieve list.\n' + response.responseText)
      },
      scope: this,
      params: {
        list_id: listRecord.list_id
      }
    })
  },
  handleFilter: function(filter) {
    var isFiltered= false
    this.getStore().filterBy(function(listRecord) {
      var category= listRecord.data.category          
      if (Ext.isBoolean(filter[category])) {
        if (!filter[category]) {
          isFiltered= true
        }
        return filter[category]
      }
      return true
    }, this)
    this.setViewFilter(isFiltered)    
  },
  setViewFilter: function(isFiltered) {
    var filterToolbarButton= this.getTopToolbar().find('text', 'Filter')[0]
    filterToolbarButton.setIconClass((isFiltered ? 'x-rg-16-funnel_red' : 'ix-v0-16-funnel'))
  }
})


RG.Lists.FilterMenu = Ext.extend(Ext.menu.Menu, {  
  initComponent: function() { 
    this.filterState= {}
    this.disabled= true
    this.on('show', this.onMenuLoad, this);
    
    this.items= [
    ]
    
    RG.Lists.FilterMenu.superclass.initComponent.call(this);
  },
    
  onMenuLoad: function(){      
    if (this.el) {
      this.removeAll()      
      this.types= new Ext.util.MixedCollection()      
      this.el.sync();
      var appRecordCollection= this.grid.store.snapshot || this.grid.store.data
      appRecordCollection.each(function(record){
        var category= record.data.category
        if (category) {
          this.types.add(category, category)          
        }        
      }, this)
      
      var sort= function(a, b) {
        return (a > b ? 1 : (a < b ? -1 : 0))
      }      
      this.types.sort('ASC', sort)
      
      if (this.types.getCount()> 0) {
        var menuItems= []     
        this.types.each(function(item) {
          menuItems.push({
            text: RG.categoryLabel(item),
            category: item.toUpperCase(),            
            checked: (Ext.isBoolean(this.filterState[item.toUpperCase()]) ? this.filterState[item.toUpperCase()] : true),
            hideOnClick: false,        
            checkHandler: this.updateFiltering.createDelegate(this)
          })
        }, this)
        this.add('<b class="rg-apps-menu-title">Choose Types</b>')  
        this.add({
          text: 'Select All/None',
          iconCls: 'ix-v0-16-check',
          hideOnClick: false,        
          handler: this.handleSelectAll.createDelegate(this),
          scope: this
        })                   
        this.add(menuItems)
      }
      this.setDisabled(this.types.getCount()<= 0)  
    }
  },
  handleSelectAll: function(item) {
    var allSelected= true
    this.items.each(function(item) {
      if (item.checked=== false) {
        allSelected= false
        return false
      }
    })
    this.items.each(function(item) {
      if (Ext.isFunction(item.setChecked)) {
        item.setChecked(!allSelected, true)
      }
    })     
    this.updateFiltering()
  },
  updateFiltering: function() {
    this.items.each(function(item) {
      if (Ext.isBoolean(item.checked)) {
        this.filterState[item.category]= item.checked
      }
    }, this)
    this.grid.handleFilter(this.filterState)
  }
});



// ------------------------------------------------------------------------------------------------------------
//               TO BE DELETED
// ------------------------------------------------------------------------------------------------------------

/**
   * Creates the Lists Panel 
   */
RG.Lists.ListsPanel = Ext.extend(Ext.Panel, {
  layout: 'anchor',
  autoScroll: true,
  initComponent : function() {
    var panel= this
    this.items= []
    this.categoryViewMap= {}
    this.tbar= new Ext.Toolbar({
      items  : ['Sorting order:', '-'],
      plugins: new Ext.ux.ToolbarReorderer(),
      listeners: {
        scope    : this,
        reordered: function(button) {
          this.changeSortDirection(button, false);
        }
      }        
    })

    this.tbar.add(this.createSorterButton({
      text: 'Name',
      sortData: {
        field: 'name',
        direction: 'ASC'
      }
    }));
    
    this.tbar.add(this.createSorterButton({
      text: 'Size',
      sortData: {
        field: 'member_count',
        direction: 'ASC'
      }
    }));
    this.tbar.add('-')
    
    this.tbar.add({
      text: 'Expand All',
      handler: function() {
        panel.expandCollapseListViews()
      },
      scope: this
    })
    this.tbar.add({
      text: 'Collapse All',
      handler: function() {
        panel.expandCollapseListViews(true)
      },
      scope: this
    })
    RG.Lists.ListsPanel.superclass.initComponent.call(this);
    this.loadPanels()
  },
  reloadCategory: function(category) {
    if (this.categoryViewMap[category]) {
      this.categoryViewMap[category].store.load({
        callback: function() {
          this.categoryViewMap[category].refresh()
        },
        scope: this
      })
    } else {
      this.loadPanels()
    }
  },
  loadPanels : function() {
    var panel= this
    this.removeAll()
    
    Ext.Ajax.request({
      url: '/aig/store.go?request=LISTS',
      scope: panel,
      success: function(resp) {       
        var json= Ext.decode(resp.responseText)
        var categories= []
        try {
          var categoryHash= {}
          Ext.each(json.lists, function(a) {
            if (!categoryHash[a.category]) {
              categoryHash[a.category] =true
              categories.push(a.category)
            }
          })
        } catch(e) {}   
    
    
        var height= 100/categories.length
        for(var i=0; i< categories.length; i++) {
          var title= 'My'
          var words= categories[i].split(/[_ ]+/)
          Ext.each(words, function(word) {          
            title= title +" " + word.charAt(0).toUpperCase()+word.substring(1).toLowerCase();
          })
          this.categoryViewMap[categories[i]]= new RG.Lists.ListView({
            category: categories[i],
            categoryLabel: title,
            region: 'center',
            id: Ext.id()
          })
      
          this.add(new Ext.Panel({
            items: this.categoryViewMap[categories[i]], 
            layout:'border',
            border: false,
            flex: 1,
            cls: 'rg-lists-header',        
            title: title,
            collapsible: true,
            hideCollapseTool: true,
            titleCollapse: true,
            anchor: '100% '+height+'%',
            listeners: {
              beforeexpand: function(p) {
                p.header.removeClass('rg-lists-header-collapsed')
              },
              beforecollapse: function(p) {
                p.header.addClass('rg-lists-header-collapsed')
              }
            }
          }))      
        }
        this.doLayout()
      }
    })    
  },
    
  /**
     * Convenience function for creating Toolbar Buttons that are tied to sorters
     * @param {Object} config Optional config object
     * @return {Ext.Button} The new Button object
     */
  createSorterButton: function (config) {
    var panel = this
    config = config || {};
              
    Ext.applyIf(config, {
      listeners: {
        click: function(button, e) {
          panel.changeSortDirection(button, true);                    
        }
      },
      iconCls: 'sort-' + config.sortData.direction.toLowerCase(),
      reorderable: true
    });
        
    return new Ext.Button(config);
  },
  /**
     * Callback handler used when a sorter button is clicked or reordered
     * @param {Ext.Button} button The button that was clicked
     * @param {Boolean} changeDirection True to change direction (default). Set to false for reorder
     * operations as we wish to preserve ordering there
     */
  changeSortDirection: function (button, changeDirection) {
    var sortData = button.sortData,
    iconCls  = button.iconCls;
        
    if (sortData != undefined) {
      if (changeDirection !== false) {
        button.sortData.direction = button.sortData.direction.toggle("ASC", "DESC");
        button.setIconClass(iconCls.toggle("sort-asc", "sort-desc"));
      }
      var sorters = [];
        
      Ext.each(this.getTopToolbar().findByType('button'), function(button) {
        if (button.sortData) {
          sorters.push(button.sortData)
        }
      }, this);
        
      for(var category in this.categoryViewMap) {   
        var categoryView= this.categoryViewMap[category]
        categoryView.store.clearFilter();
        categoryView.store.sort(sorters, "ASC");
      }
    }
  },
  expandCollapseListViews: function(collapse) {
    var views= this.find('collapsible', true)
    for(var i=0; i< views.length; i++) {
      if (collapse) {
        views[i].collapse()
      } else {
        views[i].expand()
      }
    }
  }
})


RG.Lists.ListView = Ext.extend(Ext.DataView, {
  dropAllowed: Ext.dd.DragZone.prototype.dropAllowed,
  dropNotAllowed: Ext.dd.DragZone.prototype.dropNotAllowed,
  tpl: new Ext.XTemplate(
    '<tpl for=".">',
    '<dd class="rg-lists">',
    '<table><tr>',
    '<td ><img src="/aig/icon.go?type=list&category={category}"></td>',
    '<td class="rg-lists">',
    '<span class="rg-lists">{name}</span>',
    '</td></tr></table>',
    '</dd>',
    '</tpl>'  
    ),
  cls: 'rg-lists',
  itemSelector: 'dd.rg-lists',
  //overClass: 'rg-lists-hover',
  singleSelect: true,
  multiSelect: true,
  autoScroll: true,
  initComponent : function() {
    var panel= this
    panel.loadingText= 'Loading '+this.categoryLabel
    
    this.store = new Ext.data.Store({
      reader: new Ext.data.JsonReader({
        root: 'lists'
      }, RG.Record.ListRecord),
      url: '/aig/store.go?request=LISTS',
      baseParams: {
        list_category: panel.category
      },
      sortInfo: {
        field: 'modified',
        direction: 'DESC'
      },
      autoLoad: true
    })  
    panel.on("dblclick", function(view, index, node, e){
      var record = panel.getRecordFromEvent(e)

      if (record && record.data.list_id) {
        this.loadList(record)
      }
    })
    panel.on("click", function(view, index, node, e){
      var record = panel.getRecordFromEvent(e)

      if (record && record.data.list_id) {
        var listID = record.data.list_id
        Ext.getCmp("aig-tab-settings").setEntityListForm({
          list_id: listID,
          updateHandler: function(name, desc, members){
            this.updateList({
              list_id: listID,
              name: name,
              description: desc,
              members: members
            })
          },
          deleteHandler: function(){
            this.deleteList({
              list_id: listID,
              name: record.data.name
            })
          },
          scope: this
        })
      }
    })
    
    panel.on("contextmenu", function(view, index, node, e){
      e.preventDefault()
      e.stopPropagation()
      
      var record = panel.getRecordFromEvent(e)
      if (!record || !record.data.list_id) {
        return
      }
      this.menuTargetRecord = record
      if (!this.menu) {
        this.menu = new Ext.menu.Menu({
          items: [{
            text: 'Open',
            icon: '/aig/img/openlist.gif',
            scope: this,
            handler: function(){
              this.loadList(this.menuTargetRecord)
            }
          }, {
            text: 'Refresh',
            icon: '/aig/img/refreshlist.gif',
            scope: this,
            handler: function(){
              this.refreshList({
                list_id: this.menuTargetRecord.data.list_id,
                name: this.menuTargetRecord.data.name
              })
            }
          }, {
            text: 'Edit',
            icon: '/aig/img/editlist.gif',
            scope: this,
            handler: function(){
              AIG.showListEditorWindow({
                //id: listEditorId,
                list_id: this.menuTargetRecord.data.list_id,
                updateHandler: function(name, desc, members){
                  this.updateList({
                    list_id: this.menuTargetRecord.data.list_id,
                    name: name,
                    description: desc,
                    members: members
                  })
                },
                deleteHandler: function(){
                  this.deleteList({
                    list_id: this.menuTargetRecord.data.list_id,
                    name: this.menuTargetRecord.data.name
                  })
                },
                scope: this
              })
            }
          }, {
            text: 'Copy',
            icon: '/aig/img/copylist.gif',
            scope: this,
            handler: function(){
              this.copyList({
                list_id: this.menuTargetRecord.data.list_id,
                name: this.menuTargetRecord.data.name
              })
            }
          }, {
            text: 'Copy List To Clipboard',
            icon: '/aig/img/copy.gif',
            scope: this,
            handler: function(){
              this.copyListToClipboard({
                list_id: this.menuTargetRecord.data.list_id,
                name: this.menuTargetRecord.data.name
              })
            }
          }, {
            text: 'Add to Favorites/Share',
            icon: '/aig/img/launchpad/favorites.gif',
            scope: this,
            handler: function(){
              RG.Favorites.createFavorite({
                name: this.menuTargetRecord.data.name,
                description: this.menuTargetRecord.data.description,
                type: 'LIST',
                key: this.menuTargetRecord.data.list_id
              })
            }
          }, {
            text: 'Delete',
            icon: '/aig/img/delete.gif',
            scope: this,
            handler: function(){
              this.deleteList({
                list_id: this.menuTargetRecord.data.list_id,
                name: this.menuTargetRecord.data.name
              })
            }
          }]
        })
      }
      this.menu.items.get(1).setDisabled(!this.menuTargetRecord.data.can_refresh)
      this.menu.showAt(e.getXY())
    })
    RG.Lists.ListView.superclass.initComponent.call(this);    
  },
  // private
  afterRender: function(){
    Ext.DataView.prototype.afterRender.call(this);    
    var view= this   
    this.tip = new Ext.rx.AnchorToolTip({
      target: this.getEl(),
      delegate: this.itemSelector,
      trackMouse: false,
      showDelay: 1500,
      quickShowInterval: 0,
      renderTo: document.body,
      autoHide: true,
      closable: false,
      anchor: 'left',
      tpl: new Ext.XTemplate(
        '<tpl for=".">',
        "<B>{name}</B><BR>Type: {category}<BR>Created: {created_by} ({created})",
        "<BR>Modified: {modified_by} ({modified})<BR>Size: {member_count}",
        '</tpl>'  
        ),      
      listeners: {
        beforeshow: function(){
          if (view.isDragging=== true || (view.menu && view.menu.isVisible())) {
            return false
          }
          try {
            var record = this.getRecord(this.tip.triggerElement)
            if (Ext.isRecord(record)) {                       
              this.tip.tpl.overwrite(this.tip.body, record.data)
              return true
            }
          } catch (e) {
          }
          return false
        },
        scope: this
      }
    })     
    
    view.dragZone = new Ext.dd.DragZone(view.getEl(), {
      ddGroup: 'aiglist',
      getDragData: function(e){
        var sourceEl = e.getTarget(view.itemSelector, 10);
        if (sourceEl) {
          d = sourceEl.cloneNode(true);
          d.id = Ext.id();
          return view.dragData = {
            sourceEl: sourceEl,
            repairXY: Ext.fly(sourceEl).getXY(),
            ddel: d,
            record: view.getRecord(sourceEl)
          }
        }          
      },
      onStartDrag: function(){
        var dragEl = Ext.get(this.getDragEl());
        var ghostEl = this.getProxy().getGhost()
        setAllChildClass(this.getProxy().getEl(), 'whiteBackground')
        ghostEl.applyStyles({
          border: 'none'
        })
        this.getProxy().hide()
      },
                
      beforeDragDrop: function(target, e, id){
        return true
      },
      getRepairXY: function(){
        return this.dragData.repairXY;
      }
    })



    //create the dropzone for the DataView
    view.dropZone = new Ext.dd.DropZone(view.getEl(), {
      ddGroup: 'aignodes',
                
      //  Returns the target dataitem in the DataView if it is in the event source
      getTargetFromEvent: function(e){
        return view.getRecordFromEvent(e)
      },
      // While over a target node, return the default drop allowed class which
      // places a "tick" icon into the drag proxy.
      onNodeOver: function(target, dd, e, data){
        var node = data.node
        //
        //Handles a DnD from a treenodes element DnD node
        if (node && node.attributes) {
          return this.isValidNodeDrop(target, node)
        } else {
          //
          //Handles a DnD from a list view element DnD node
          var dragRecord = data.record
          if (!dragRecord) {
            return Ext.dd.DragZone.dropNotAllowed
          }
          var dragRecordData = dragRecord.data
          var dragRecordListID = dragRecordData.list_id
          var targetRecord = view.store.getById(target.id)          
          if (!targetRecord) {
            return Ext.dd.DragZone.dropNotAllowed
          }
          var targetRecordData = targetRecord.data
          if (!targetRecordData || !targetRecordData.category) {
            return Ext.dd.DragZone.dropNotAllowed
          }
          var targetRecordListID = targetRecordData.list_id
          if (targetRecordListID == dragRecordListID) {
            return Ext.dd.DragZone.dropNotAllowed
          }
          if (dragRecordData.category != targetRecordData.category) {
            return Ext.dd.DragZone.dropNotAllowed
          }
          return Ext.dd.DropZone.prototype.dropAllowed
                        
        }
        return Ext.dd.DragZone.dropNotAllowed
      },
      // On node drop, we can interrogate the target node and the dragged node
      // and if valid, update the list.
      onNodeDrop: function(target, dd, e, data){
        var entityListPanel = view
        var node = data.node
        //
        //Handles a DnD from a treenodes element DnD node
        if (node && node.attributes) {
          if (this.isValidNodeDrop(target, node) != Ext.dd.DropZone.prototype.dropAllowed) {
            return false
          }
          var attr = node.attributes
          var nodeType = attr.node_type
                        
          switch (nodeType) {
            case "RESULTNODE":
            case "SERVICENODE":
              var record = view.store.getById(target.id)
              if (!record) {
                if (target.id == view.id) {
                  view.createNewListFromNode(node)
                  return true
                }
                return false
              }
              var recordData = record.data
              var node = {
                uuid: node.attributes.uuid,
                name: getNodeBaseText(node.attributes.text)
              }
                                
              var listID = recordData.list_id
              entityListPanel.showListOperationDialog(node, recordData, null)
              return true;
            case "ENTITYNODE":
              var record = view.store.getById(target.id)
              if (!record) {
                return Ext.dd.DragZone.dropNotAllowed
              }
              var recordData = record.data
              var nodeUUID = node.attributes.uuid
              var listID = recordData.list_id
              entityListPanel.addToListFromEntityNode(listID, node, recordData.name)
              return true
          }
        } else {
          //
          //Handles a DnD from a list view element DnD node
          var dragRecord = data.record
          if (!dragRecord) {
            return false
          }
          var dragRecordData = dragRecord.data
          var dragRecordListID = dragRecordData.list_id
          var targetRecord = view.store.getById(target.id)
          if (!targetRecord) {
            return false
          }
          var targetRecordData = targetRecord.data
          if (!targetRecordData || !targetRecordData.category) {
            return false
          }
          var targetRecordListID = targetRecordData.list_id
          if (targetRecordListID == dragRecordListID) {
            return false
          }
          if (dragRecordData.category != targetRecordData.category) {
            return false
          }
          view.showListOperationDialog(null, dragRecordData, targetRecordData)
          return true
        }
        return false
      },
      /**
         * Returns whether the drop node data is valid for the target
         * @param {Object} target
         * @param {Object} node
         */
      isValidNodeDrop: function(target, node){
        if (!node || !node.attributes) {
          return Ext.dd.DragZone.dropNotAllowed
        }
        var attr = node.attributes
        var nodeType = attr.node_type
        if (!nodeType) {
          return Ext.dd.DragZone.dropNotAllowed
        }
        var hasChildNodes = (node.childNodes && node.childNodes.length > 0)
        switch (nodeType) {
          case "RESULTNODE":
          case "SERVICENODE":
            if (!hasChildNodes) {
              return Ext.dd.DragZone.dropNotAllowed
            }
            var record = view.store.getById(target.id)
            if (!record) {
              if (target.id == view.id) {
                return Ext.dd.DropZone.prototype.dropAllowed;
              }
              return Ext.dd.DragZone.dropNotAllowed
            }
            /*
            var recordData = record.data
            var serviceDataTypeCategory = null
            if (attr && attr.service_data_type_category) {
              serviceDataTypeCategory = attr.service_data_type_category
            } else {
              var firstChildNode = node.childNodes[0]
              var firstChildNodeAttr = firstChildNode.attributes
              if (firstChildNodeAttr && firstChildNodeAttr.service_data_type_category) {
                serviceDataTypeCategory = firstChildNodeAttr.service_data_type_category
              }
            }
            if (!serviceDataTypeCategory || !recordData || !recordData.category) {
              return Ext.dd.DragZone.dropNotAllowed
            }
               */
            if (!RG.entityMatch(node, record)) {
              return Ext.dd.DragZone.dropNotAllowed
            }
            return Ext.dd.DropZone.prototype.dropAllowed
          case "ENTITYNODE":
            var record = view.store.getById(target.id)
            if (!record) {
              return Ext.dd.DragZone.dropNotAllowed
            }
            var recordData = record.data
            var serviceDataTypeCategory = null
            if (attr && attr.service_data_type_category) {
              serviceDataTypeCategory = attr.service_data_type_category
            }
            if (!serviceDataTypeCategory || !recordData || !recordData.category) {
              return Ext.dd.DragZone.dropNotAllowed
            }
            if (!RG.entityMatch(serviceDataTypeCategory, recordData.category)) {
              return Ext.dd.DragZone.dropNotAllowed
            }
            return Ext.dd.DropZone.prototype.dropAllowed
        }
      }
    })
    view.dropZone.addToGroup('aiglist');

  },
  handleDropResort: function(sourceRecord, targetRecord) {
    var records = this.store.getRange()
    var order= []
    var targetPos= -1
    for(var i=0; i< records.length; i++) {
      var id= records[i].id
      if (id!= sourceRecord.id) {
        order.push(records[i].id)
        if (id== targetRecord.id) {
          targetPos= i
        }
      }
    }
    order.splice(targetPos, 0, sourceRecord.id)
    for(var i=0; i< order.length; i++) {
      var record= this.store.getById(order[i])
      record.data.order= i      
    }
    this.store.sortData()
    this.refresh()  
  },  
  /**
     * Load a list from the list panel
     * @param {Object} record
     */
  loadList: function(record){
    RG.Load.loadEntityList({
      list_id: record.data.list_id,
      list_name: record.data.name
    })
  },
  /**
     * Reloads the list store after a change
     */
  updateListPanel: function(){
    this.store.reload()
  },
  /**
     * Updates the list form after an update or delete
     * @param {Object} updateOrDelete
     */
  updateListForm: function(updateOrDelete){
    updateOrDelete = (updateOrDelete == null ? true : updateOrDelete)
    if (updateOrDelete) {
      Ext.getCmp("aig-tab-settings").updateIfView("list")
    } else {
      Ext.getCmp("aig-tab-settings").resetResourceSettingsPanel()
    }
  },
  updateList: function(listRecord){
    var entityListPanel = this
    entityListPanel.getEl().mask("Updating List")
    Ext.Ajax.request({
      url: "/aig/treenodeoperation.go",
      success: function(response){
        entityListPanel.getEl().unmask()
        if (!AIG.showErrorMessage(response)) {
          showInformationDialog('List updated.');
          entityListPanel.updateListPanel()
          entityListPanel.updateListForm()
        }
      },
      failure: function(){
        entityListPanel.getEl().unmask()
        Ext.MessageBox.show({
          title: 'Update List',
          msg: 'Unable to update list.',
          buttons: Ext.MessageBox.OK,
          icon: Ext.MessageBox.ERROR
        })
      },
      scope: this,
      params: {
        op: 'updatelist',
        list_id: listRecord.list_id,
        name: listRecord.name,
        description: listRecord.description,
        members: listRecord.members
      }
    })
  },
  refreshList: function(listRecord){
    Ext.Msg.show({
      title: 'Refresh List?',
      msg: 'This will attempt to refresh the list based on the original query used to create the list. ' +
      '<BR>Any changed made since the list was created will be lost.<BR>Continue?',
      width: 300,
      modal: true,
      buttons: Ext.MessageBox.YESNO,
      icon: Ext.MessageBox.WARNING,
      fn: function(buttonId){
        if (buttonId != 'yes') {
          return
        }
        var entityListPanel = this
        entityListPanel.getEl().mask("Refreshing List " + listRecord.name)
        Ext.Ajax.request({
          url: "/aig/treenodeoperation.go",
          success: function(response){
            entityListPanel.getEl().numask()
            if (!AIG.showErrorMessage(response)) {
              entityListPanel.updateListPanel()
              entityListPanel.updateListForm()
            }
          },
          failure: function(){
            entityListPanel.getEl().unmask()
            Ext.MessageBox.show({
              title: 'Refresh List',
              msg: 'Unable to update list.',
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
          },
          scope: this,
          params: {
            op: 'refreshlist',
            list_id: listRecord.list_id,
            name: listRecord.name
          }
        })
      },
      scope: this
    })
        
        
  },
  addToListFromEntityNode: function(listID, entityNode, listName){
    var entityListPanel = this
    entityListPanel.getEl().mask("Updating List " + listName)
    Ext.Ajax.request({
      url: "/aig/treenodeoperation.go",
      success: function(response){
        entityListPanel.getEl().unmask()
        if (!AIG.showErrorMessage(response)) {
          showInformationDialog('Added Entity to List')
          entityListPanel.updateListPanel()
          entityListPanel.updateListForm()
        }
      },
      failure: function(response){
        entityListPanel.getEl().unmask()
        this.updateListForm()
        Ext.MessageBox.show({
          title: 'Update List',
          msg: 'Unable to update list.\n' + response.responseText,
          buttons: Ext.MessageBox.OK,
          icon: Ext.MessageBox.ERROR
        })
      },
      scope: this,
      params: {
        op: 'addtolist',
        uuid: entityNode.attributes.uuid,
        list_id: listID
      }
    })
  },
  deleteList: function(listRecord){
    Ext.MessageBox.show({
      title: 'Delete List?',
      msg: 'Do you want to delete list ' + listRecord.name + '?',
      buttons: Ext.MessageBox.YESNO,
      fn: function(buttonId){
        if (buttonId != 'yes') {
          return
        }
        this.getEl().mask('Deleting list ' + listRecord.name)
        Ext.Ajax.request({
          url: "/aig/treenodeoperation.go",
          success: function(response){
            this.getEl().unmask()
            if (!AIG.showErrorMessage(response)) {
              showInformationDialog('List Deleted')
              this.updateListPanel()
              this.updateListForm()
            }
          },
          failure: function(){
            this.getEl().unmask()
            Ext.MessageBox.show({
              title: 'Delete List',
              msg: 'Unable to delete list.',
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
          },
          scope: this,
          params: {
            op: 'deletelist',
            list_id: listRecord.list_id
          }
        })
      },
      scope: this,
      icon: Ext.MessageBox.QUESTION
    });
  },
  showListOperationDialog: function(node, record1, record2){
    var listID1 = record1.list_id
    var listID2 = (record2 ? record2.list_id : null)
        
    AIG.showListOperationDialog({
      handler: function(values){
        var operation = values.op
        var title = (record2 ? record1.name + " " + operation + " " + record2.name : node.name + " " + operation + " " + record1.name)
        this.getEl().mask("Performing Operation: " + title)
        Ext.Ajax.request({
          url: "/aig/treenodeoperation.go",
          success: function(response){
            this.getEl().unmask()
            if (AIG.showErrorMessage(response)) {
              return
            }
            var data = null
            try {
              data = Ext.util.JSON.decode(response.responseText)
            } catch (e) {
            }
            if (data != null) {
              if (data.results == 0) {
                showInformationDialog('Operation returned no results.');
              } else {
                showInformationDialog("Created new list '" +
                  data.list_name +
                  "' with " +
                  data.results +
                  ' members');
                this.updateListPanel()
                this.updateListForm()
              }
            } else {
              this.updateListPanel()
              this.updateListForm()
            }
          },
          failure: function(response){
            this.getEl().unmask()
            this.updateListForm()
            Ext.MessageBox.show({
              title: 'List Combination',
              msg: 'Unable to save list.',
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
          },
          scope: this,
          params: {
            op: values.op,
            uuid: (node ? node.uuid : null),
            list_id1: listID1,
            list_id2: listID2,
            name: values.name,
            description: hasLength(values.description) || title
          }
        })
      },
      scope: this
    })
  },
  createNewListFromNode: function(node){
    var nodeUUID = (node ? node.attributes.uuid : null)
    if (!nodeUUID) {
      return
    }
    var entityListPanel = this
    AIG.NameDescriptionDialog({
      title: 'Create New List',
      ok_text: 'Save List',
      handler: function(values){               
        var name = values.name
        var description = values.description
        if (!name || name.length == 0) {
          Ext.MessageBox.show({
            title: 'Unable to Save List',
            msg: 'List name required.',
            buttons: Ext.MessageBox.OK,
            icon: Ext.MessageBox.ERROR
          })
          return
        }
        if (!description || description.length == 0) {
          description = 'List ' + name
        }
        entityListPanel.getEl().mask("Saving list " + name)
        Ext.Ajax.request({
          url: "/aig/treenodeoperation.go",
          success: function(){
            entityListPanel.getEl().unmask()
            showInformationDialog('List Created')
            var launcher= new RG.Loft.AppLauncher()
            launcher.reloadDialog(launcher.dialogIDs.LISTS_TOOL)
          },
          failure: function(){
            entityListPanel.getEl().unmask()
            Ext.MessageBox.show({
              title: 'Save List',
              msg: 'Unable to save list.',
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
          },
          scope: this,
          params: {
            op: 'savelist',
            uuid: nodeUUID,
            name: name,
            description: description
          }
        })
      }
    })
  },
  copyList: function(listRecord){
    var entityListPanel = this
    entityListPanel.getEl().mask("Copying list " + listRecord.name)
    Ext.Ajax.request({
      url: "/aig/treenodeoperation.go",
      success: function(response){
        entityListPanel.getEl().unmask()
        if (!AIG.showErrorMessage(response)) {
          showInformationDialog('List Copied')
          entityListPanel.updateListPanel()
          entityListPanel.updateListForm()
        }
      },
      failure: function(){
        entityListPanel.getEl().unmask()
        Ext.MessageBox.show({
          title: 'Copy List',
          msg: 'Unable to copy list.',
          buttons: Ext.MessageBox.OK,
          icon: Ext.MessageBox.ERROR
        })
      },
      scope: this,
      params: {
        op: 'copylist',
        list_id: listRecord.list_id
      }
    })
        
  },
  copyListToClipboard: function(listRecord){
    Ext.Ajax.request({
      url: "/aig/entitylist.go",
      success: function(response){
        var listName = selectSingleNodeValue(response.responseXML, '/EntityLists/EntityList/@name')
        var listDesc = selectSingleNodeValue(response.responseXML, '/EntityLists/EntityList/@description')
        var listMembers = selectNodeValues(response.responseXML, '/EntityLists/EntityList/EntityListMember/@member')
        AIG.ClipboardCtrl.setClipboardText((Ext.isArray(listMembers) ? listMembers.join("\n") : listMembers))
        showInformationDialog("List members copied to clipboard.")
      },
      failure: function(response){
        showErrorDialog('Error Copying List', 'Unable to retrieve list.\n' + response.responseText)
      },
      scope: this,
      params: {
        list_id: listRecord.list_id
      }
    })
  },
  //  Returns the target dataitem in the DataView if it is in the event source
  getRecordFromEvent: function(e){
    var sourceEl = e.getTarget(this.itemSelector, 10);
    if (sourceEl) {
      return this.getRecord(sourceEl)
    } 
    return null
  }
});


/**
   * Loops through all childrean and sets the class
   * @param {Object} el
   * @param {Object} cssClass
   */
function setAllChildClass(el, cssClass){
  if (el) {
    if (el.dom.childNodes) {
      for (var i = 0; i < el.dom.childNodes.length; i++) {
        var child = Ext.get(el.dom.childNodes[i])
        setAllChildClass(child, cssClass)
      }
    }
    el.addClass(cssClass)
  }
}


