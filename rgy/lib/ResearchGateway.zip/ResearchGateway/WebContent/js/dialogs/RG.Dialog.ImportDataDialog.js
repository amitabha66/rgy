/**
 * @author jemcdowe
 */
RG.Dialog.ImportDataDialog = Ext.extend(RG.Dialog.AnimatedWindow, {
  title: 'Import Data',
  width: 450,
  height: 400,
  fileLoaded: false,
  layout: 'border',
  initComponent: function(){
    var dialog = this
        
    this.columnMapStore = new Ext.data.Store({
      autoLoad: true,
      proxy: new Ext.data.MemoryProxy([]),
      reader: new Ext.data.JsonReader({
        root: 'columns',
        id: 'name'
      }, Ext.data.Record.create([{
        name: 'name'
      }, {
        name: 'type'
      }, {
        name: 'types'
      }]))
    })
        
    this.items = [(dialog.form = new Ext.form.FormPanel({
      frame: true,
      region: 'center',
      fileUpload: true,
      height: 80,
      items: [new Ext.form.ComboBox({
        fieldLabel: 'Import Type',
        store: new Ext.data.Store({
          autoLoad: true,
          url: '/aig/entitytableimport.go',
          reader: new Ext.data.JsonReader({
            root: 'importTypes'
          }, Ext.data.Record.create([{
            name: 'import_type'
          }])),
          baseParams: {
            op: 'IMPORT_TYPES'
          }
        }),
        typeAhead: true,
        editable: false,
        triggerAction: 'all',
        mode: 'local',
        value: 'Compounds',
        selectOnFocus: true,
        width: 300,
        name: 'type',
        displayField: 'import_type',
        valueField: 'import_type',
        hiddenName: 'type',
        listeners: {
          beforeselect: function(combo, record, index){
            if (!dialog.fileLoaded) {
              return true
            }
            var newValue = record.data[this.valueField || this.displayField]
            var oldValue = combo.getValue()
            Ext.Msg.show({
              title: 'Change Import Type?',
              msg: 'This will reset the form. Continue?',
              buttons: Ext.Msg.YESNO,
              fn: function(btn){
                if (btn == 'yes') {
                  dialog.resetForm(newValue)
                } else {
                  combo.setValue(oldValue)
                }
              },
              icon: Ext.MessageBox.QUESTION
            });
          }
        }
      }), new Ext.form.FileUploadField({
        fieldLabel: 'Import File',
        name: 'import_data_file',
        emptyText: 'Select a file',
        width: 300,
        buttonText: 'Browse',
        listeners: {
          fileselected: function(input, file){
            dialog.processFile()
          }
        }
      })]
    })), (dialog.columnMapGrid = new Ext.grid.EditorGridPanel({
      title: 'Column Mappings',
      region: 'south',
      split: true,
      height: 230,
      clicksToEdit: 1,
      enableHdMenu: false,
      enableDragDrop: false,
      enableColumnMove: false,
      enableColumnHide: false,
      store: this.columnMapStore,
      columns: [{
        dataIndex: 'name',
        header: 'Column',
        sortable: false,
        editable: false,
        width: 200
      }, {
        header: 'Type',
        dataIndex: 'type',
        editable: true,
        sortable: false,
        width: 200,
        editor: new Ext.form.ComboBox({
          width: 200,
          resizable: true,
          listWidth: 150,
          store: new Ext.data.SimpleStore({
            autoDestroy: true,
            idIndex: 0,
            fields: ['column_type']
          }),
          valueField: 'column_type',
          displayField: 'column_type',
          triggerAction: 'all',
          mode: 'local'
        })
      }],
      listeners: {
        beforeedit: function(evt){
          var grid = evt.grid
          var record = evt.record
          var colIndex = evt.column
          var rowIndex = evt.row
          var editor = grid.colModel.getCellEditor(colIndex, rowIndex)
          if (Ext.type(record.data.types) != 'array' || record.data.types.length == 0) {
            return false
          }
          editor.field.store.loadData(record.data.types)
        }
      }
    }))]
        
    this.buttons = [{
      text: 'OK',
      handler: function(){
        dialog.doImport()
      },
      scope: this
    }, {
      text: 'Cancel',
      handler: function(){
        dialog.close();
      }
    }]
    RG.Dialog.ImportDataDialog.superclass.initComponent.call(this);
  },
  processFile: function(){
    this.getEl().mask('Loading File')
    this.fileLoaded = false
    Ext.Ajax.request({
      url: '/aig/entitytableimport.go',
      success: function(response, options){
        this.getEl().unmask()
        var columnJSON = Ext.util.JSON.decode(response.responseText)
        this.columnMapStore.loadData(columnJSON)
        this.importServiceDataType = columnJSON.import_service_data_type
        this.form.find("name", "type")[0].setValue(columnJSON.import_table_type)
        this.fileLoaded = true
      },
      failure: function(response, options){
        this.getEl().unmask()
        this.fileLoaded = false
        this.form.getForm().reset()
        this.columnMapStore.loadData({
          columns: []
        })
        showErrorDialog("Unable To Process Import File", options.status.msg)
      },
      scope: this,
      form: this.form.getForm().getEl(),
      params: {
        op: 'PROCESS_DATA_FILE'
      }
    })
  },
  doImport: function(){
    if (!this.fileLoaded) {
      return
    }
    this.columnMapGrid.stopEditing()
    var colMapValues = []
    var colMapGridRecords = this.columnMapGrid.getStore().getRange()
    var importServiceDataTypeCount = 0
    for (var i = 0; i < colMapGridRecords.length; i++) {
      colMapValues.push(colMapGridRecords[i].data.type)
      importServiceDataTypeCount += (colMapGridRecords[i].data.type == this.importServiceDataType ? 1 : 0)
    }
    if (importServiceDataTypeCount == 0) {
      showWarningDialog("Unable to Import", this.importServiceDataType + " column must be selected")
      return
    } else if (importServiceDataTypeCount > 1) {
      showWarningDialog("Unable to Import", "Only one " + this.importServiceDataType + " column should be selected")
      return
    }
        
    AIG.closeLaunchPad()
    var transactionID = null
    var progressBox = Ext.Msg.show({
      title: 'Status',
      msg: 'Importing Data...',
      buttons: Ext.Msg.CANCEL,
      closable: false,
      wait: true,
      modal: true,
      minWidth: 250,
      fn: function(buttonID, text){
        if (transactionID && Ext.Ajax.isLoading(transactionID)) {
          progressBox.updateProgress(0, ' ', '')
          Ext.Ajax.abort(transactionID)
        }
      }
    })
        
    transactionID = Ext.Ajax.request({
      url: '/aig/entitytableimport.go',
      success: function(response, options){
        this.close();
        progressBox.updateProgress(0, ' ', '')
        progressBox.hide()
        var openAfterLoadcb = {
          fn: function(node){
            node.select.defer(450, node)
            RG.Load.openEntityDefaultViewFromNode.defer(400, this, [{
              node: node
            }])
          },
          scope: this
        }
        addTreeNodesFromQueryResult(response, openAfterLoadcb)
        transactionID = null
      },
      failure: function(response, options){
        this.close();
        progressBox.hide()
        progressBox.updateProgress(0, ' ', '')
        Ext.Msg.alert('Error', "Unable to run service. Reason: " + (response.responseText || "Unknown"))
        transactionID = null
      },
      scope: this,
      form: this.form.getForm().getEl(),
      params: {
        op: 'IMPORT_DATA_FILE',
        typeMap: Ext.util.JSON.encode(colMapValues)
      }
    })
  },
  resetForm: function(importType){
    this.form.getForm().reset()
    this.fileLoaded = false
    this.columnMapGrid.getStore().loadData({
      columns: []
    })
    try {
      Ext.fly(this.form.body.id).dom.reset()
    } catch(e) {}
        
    this.form.items.each(function(item){
      if (Ext.type(item.reset) == 'function') {
        item.reset()
      }
      if (item.getName() == 'type') {
        item.setValue(importType)
      }
    }, this)
  }    
});

