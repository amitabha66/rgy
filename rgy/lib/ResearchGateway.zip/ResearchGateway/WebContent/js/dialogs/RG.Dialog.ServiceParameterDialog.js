/**
 * Window which displays the parameters for a service
 *
 *
 * @author    J. McDowell
 * @date      23 March 2009
 * @version   $Id: RG.Dialog.ServiceParameterDialog.js,v 1.42 2015/05/16 00:07:13 jemcdowe Exp $
 *
 */
RG.Dialog.ServiceParameterDialog = Ext.extend(RG.Dialog.AnimatedWindow, {
  constructor: function (config) {
	config = config || {}
	Ext.applyIf(config, {
	  title: 'Service Parameters',
	  widthMax: 680,
	  heightMax: 550,
	  canSaveService: true,
	  showResources: false
	})
	Ext.apply(config, {
	  layout: 'border',
	  shadow: false,
	  resizable: true,
	  plain: false,
	  maximizable: true
	})
	RG.Dialog.ServiceParameterDialog.superclass.constructor.call(this, config)
  },
  initComponent: function () {
	var dialog = this
	this.formConfig = this.formConfig || {}
	this.formConfig.region = 'center'
	this.formConfig.hidden = true

	dialog.form = this.generateFormPanel(this.formConfig)
	this.formContainerPanel = new Ext.Panel({
	  region: 'center',
	  items: dialog.form,
	  autoScroll: true,
	  bodyStyle: 'background: #DFE8F6 none repeat scroll 0 0'
	})

	if (this.showResources === true && this.serviceRecord.data.ShowResources === true) {
	  var store = new Ext.data.Store({
		url: '/aig/store.go?request=services',
		baseParams: {
		  responseFormat: 'XML',
		  queryType: 'SEARCH_DIALOG_RESOURCES',
		  category: this.serviceRecord.data.CategoryTag,
		  queryServiceKey: this.serviceRecord.data.ServiceKey
		},
		listeners: {
		  beforeload: function (store) {
		  },
		  load: function (store) {
			var records = []
			store.each(function (r) {
			  if (r.data.IsDefaultView) {
				records.push(r)
			  }
			})
			try {
			  dialog.serviceSelectionGrid.getSelectionModel().selectRecords(records, false)
			} catch (e) {
			}
		  },
		  loadexception: function (store, options, error) {
			aigErrorHandler(error)
		  }
		},
		reader: new Ext.data.XmlReader({
		  record: 'Service',
		  id: 'ID'
		}, RG.Record.ServiceRecord),
		autoLoad: true
	  })


	  var sm = new Ext.grid.CheckboxSelectionModel();
	  // create the grid
	  this.serviceSelectionGrid = new Ext.grid.GridPanel({
		tbar: [
		  new RG.Form.SearchField({
			emptyText: 'Enter a keyword to filter on',
			store: store,
			width: 320,
			searchOnKeyPress: true,
			listeners: {
			  search: function (field, value) {
				if (hasLength(value)) {
				  field.store.filter('Name', value, true, false, false)
				} else {
				  field.store.clearFilter()
				}
			  },
			  clear: function (field) {
				field.store.clearFilter()
			  }
			}
		  })
		],
		store: store,
		autoExpandColumn: 'selectservice-name',
		enableColumnMove: false,
		disableSelection: false,
		loadMask: true,
		region: 'center',
		sm: sm,
		columnLines: true,
		columns: [sm, {
			id: "selectservice-name",
			header: 'Resource Name',
			dataIndex: 'Name',
			menuDisabled: true,
			sortable: true,
			renderer: function (value, metaData, record, rowIndex, colIndex, store) {
			  var icon = record.data.Icon
			  var iconCls = record.data.IconCls

			  if (hasLength(iconCls)) {
				icon = '/aig/img/s.gif'
				iconCls = RG.Icon.Utils.getSizedIconClass(iconCls, 16)
			  } else if (!hasLength(icon) && !hasLength(iconCls)) {
				icon = '/aig/img/s.gif'
				iconCls = "ix-v0-16-gears_run"
			  } else if (!hasLength(iconCls)) {
				iconCls = null
			  } else {
				icon = '/aig/img/s.gif'
			  }
			  return String.format(
				  "<div style='height: 17px;padding-left: 20px' class={0}><img src={1} align='absMiddle'></img>{2}</div>",
				  iconCls, icon, value)
			}
		  }, {
			header: "Category",
			dataIndex: 'Category',
			width: 140,
			sortable: true
		  }],
		//Field methods
		isFormField: true,
		hideLabel: true
	  })

	  this.formContainerPanel.items.add(new Ext.Spacer({
		height: 20
	  }))

	  this.formContainerPanel.items.add(
		  this.selectedResourcesFieldSet = (new Ext.form.FieldSet({
			height: 200,
			collapsible: true,
			bodyStyle: 'padding-top:20px',
			padding: 10,
			layout: 'border',
			title: 'Choose Resources to Initially Load',
			items: {
			  layout: 'border',
			  region: 'center',
			  border: false,
			  items: this.serviceSelectionGrid
			}
		  })))
	}

	this.items = [this.formContainerPanel]

	this.buttons = [{
		text: 'Submit',
		handler: function () {
		  if (dialog.form.getForm().isValid()) {
			var formValues = dialog.form.getForm().getValues()
			if (Ext.type(dialog.handler) == 'function') {
			  var addArgs = {}
			  if (dialog.serviceSelectionGrid) {
				addArgs.resourceServiceRecords = {
				  serviceRecords: dialog.serviceSelectionGrid.getSelectionModel().getSelections(),
				  entityCategory: dialog.serviceRecord.data.EntityCategory
				}
			  }
			  dialog.handler.call(dialog.scope, true, formValues, dialog.form.getForm(), addArgs)
			}
			dialog.close()
		  }
		}
	  }, {
		text: 'Save',
		disabled: (this.canSaveService !== true),
		handler: function () {
		  dialog.saveServiceParameters()
		}
	  }, {
		text: 'Clear',
		handler: function () {
		  dialog.clearServiceParameters()
		}
	  }, {
		text: 'Cancel',
		handler: function () {
		  dialog.close()
		  if (Ext.type(dialog.handler) == 'function') {
			dialog.handler.call(dialog, false)
		  }
		}
	  }]

	var handlePreparedForm = function (currentForm) {
	  dialog.form = currentForm
	  currentForm.setVisible(true)
	  new Ext.util.DelayedTask().delay(100, function () {
		if (dialog.serviceRecord.data.IsParametersSaveable) {
		  dialog.setInitialParameterValues()
		}
	  })
	}

	this.form.on('render', function () {
	  var formContainerPanel = this.formContainerPanel
	  var currentForm = formContainerPanel.items.get(0)

	  currentForm.getForm().items.each(function (f) {
		f.on('hide', dialog.doLayoutOnselectedResourcesFieldSet.createDelegate(dialog))
		f.on('show', dialog.doLayoutOnselectedResourcesFieldSet.createDelegate(dialog))
	  })

	  var extFormName = selectSingleNodeValue(this.serviceXML, '/Service/ParameterSet/ExtForm/ComponentName')
	  var extFormSrc = selectSingleNodeValue(this.serviceXML, '/Service/ParameterSet/ExtForm/ComponentSource')
	  if (extFormName && extFormSrc) {
		var loader = new RG.rx.DynamicFunction({
		  src: extFormSrc,
		  functionName: extFormName
		})
		loader.on('ready', function (f) {
		  try {
			var form = new f(dialog.formConfig)
			formContainerPanel.remove(currentForm)
			currentForm = formContainerPanel.add(form)
		  } catch (e) {
			f = null
		  }
		  dialog.formContainerPanel.doLayout()
		  handlePreparedForm(currentForm)
		})
		loader.on('fail', function () {
		  handlePreparedForm(currentForm)
		})
		loader.prepare()
	  } else {
		handlePreparedForm(currentForm)
	  }
	}, this)

	RG.Dialog.ServiceParameterDialog.superclass.initComponent.call(this)
  },
  doLayoutOnselectedResourcesFieldSet: function () {
	if (this.selectedResourcesFieldSet) {
	  this.selectedResourcesFieldSet.doLayout()
	}
  },
  saveServiceParameters: function () {
	RG.Favorites.createFavorite({
	  type: 'SERVICE',
	  title: 'Save Search',
	  iconCls: 'ix-v0-16-star_yellow',
	  key: this.serviceRecord.data.ServiceKey,
	  serviceParams: this.form.getForm().getValues()
	})
  },
  clearServiceParameters: function () {
	this.serviceRecord.getServiceXML(function (serviceXML) {
	  this.serviceXML = serviceXML
	  var formOwnerPanel = this.form.ownerCt
	  formOwnerPanel.remove(this.form)
	  this.form = this.generateFormPanel(this.formConfig)
	  formOwnerPanel.insert(0, this.form)
	  this.doLayout()
	}, this, {
	  disableParameterCache: "true",
	  entityTableKey: this.entityTableKey
	})
  },
  handleEnterKeySubmit: function () {
	if (this.form.getForm().isValid()) {
	  var formValues = this.form.getForm().getValues()
	  if (Ext.type(this.handler) == 'function') {
		this.handler.call(this.scope, true, formValues, this.form.getForm())
	  }
	  this.close()
	}
  },
  generateFormPanel: function (formConfig) {
	var win = this
	formConfig.hiddenParams = formConfig.hiddenParams || {}
	//var xml = response.responseXML
	if (window.ActiveXObject) {
	  this.serviceXML.setProperty("SelectionLanguage", "XPath")
	}
	var serviceFormID = new UUID() + ""
	var standardFields = new Array()
	var advancedFields = new Array()
	var formException = null

	var helpDoc = selectSingleNodeValue(this.serviceXML, '/Service/HelpDoc')
	var isFileUpload = hasNode(this.serviceXML, '/Service/ParameterSet//Parameter[Type="file"]')

	var parameterConfig = {
	  fieldWidth: 400,
	  labelWidth: 150,
	  formConfig: formConfig || {}
	}

	parameterConfig.formConfig.formID = serviceFormID

	// serviceKey hidden field
	standardFields.push(new Ext.form.Hidden({
	  name: 'serviceKey',
	  value: this.serviceRecord.data.ServiceKey
	}))
	// Description
	var description = selectSingleNodeValue(this.serviceXML, '/Service/Description')
	if (description) {
	  // standardFields.push(new Ext.form.Label({
	  // text: description,
	  // style: 'font-size:medium;border:1 solid black;padding:2px'
	  // }))
	  var descTableCells = [{
		  tag: 'td',
		  style: 'font-size:8pt;font-weight:bold',
		  html: description
		}]
	  if (helpDoc) {
		descTableCells.push({
		  tag: 'td',
		  style: 'padding-left:5px',
		  children: [{
			  tag: 'a',
			  href: helpDoc,
			  target: '_blank',
			  children: [{
				  tag: 'img',
				  src: '/aig/img/help.gif'
				}]
			}]
		})
	  }
	  standardFields.push({
		html: {
		  tag: 'table',
		  children: [{
			  tag: 'tr',
			  children: descTableCells
			}]
		},
		frame: true,
		border: true,
		style: 'margin-bottom:5px'
	  })
	}

	// Hidden fields
	var hiddenFieldNodes = selectNodes(this.serviceXML, '/Service/ParameterSet//Parameter')
	for (var i = 0; i < hiddenFieldNodes.length; i++) {
	  var name = selectSingleNodeValue(hiddenFieldNodes[i], "Name")
	  var editable = selectSingleNodeValue(hiddenFieldNodes[i], "Editable", 'true')
	  if (formConfig.hiddenParams[name]) {
		editable = 'false'
	  }
	  if (editable == 'false') {
		var defaultValue = selectSingleNodeValue(hiddenFieldNodes[i], "DefaultValue")
		var fieldValue = selectSingleNodeValue(hiddenFieldNodes[i], "Value")
		var currentValue = defaultValue
		if (fieldValue) {
		  currentValue = fieldValue
		}
		var hiddenParamConfig = new Object()
		if (currentValue != null) {
		  hiddenParamConfig.value = currentValue
		}
		if (name != null) {
		  hiddenParamConfig.name = name
		  standardFields.push(new Ext.form.Hidden(hiddenParamConfig))
		}
	  }
	}
	var structureFieldNodes = selectNodes(this.serviceXML, '/Service/ParameterSet/Parameter[Type/@system="mimetype" and Type="chemical/x-mdl-molfile"]')
	for (var i = 0; i < structureFieldNodes.length; i++) {
	  parameterConfig.level = 'standard'
	  var name = selectSingleNodeValue(structureFieldNodes[i], "Name")
	  var editable = selectSingleNodeValue(structureFieldNodes[i], "Editable", 'true')
	  if (formConfig.hiddenParams[name]) {
		editable = 'false'
	  }
	  if (editable != 'false') {
		try {
		  var fieldParameter = win.createParameter(structureFieldNodes[i], null, parameterConfig)
		  if (fieldParameter != null) {
			standardFields.push(fieldParameter)
		  }
		} catch (e) {
		  throw e
		  formException = e + ""
		}
	  }
	}

	// Default Parameter Group
	// ORDER BY ORDER
	var defaultParameterGroupFieldNodes = selectNodes(this.serviceXML, '/Service/ParameterSet/Parameter[count(GroupName)=0 and Type!="chemical/x-mdl-molfile"]')

	for (var i = 0; i < defaultParameterGroupFieldNodes.length; i++) {
	  parameterConfig.level = 'standard'
	  var name = selectSingleNodeValue(defaultParameterGroupFieldNodes[i], "Name")
	  var editable = selectSingleNodeValue(defaultParameterGroupFieldNodes[i], "Editable", 'true')
	  if (formConfig.hiddenParams[name]) {
		editable = 'false'
	  }
	  if (editable != 'false') {
		try {
		  var fieldParameter = win.createParameter(defaultParameterGroupFieldNodes[i], null, parameterConfig)
		  if (fieldParameter != null) {
			standardFields.push(fieldParameter)
		  }
		} catch (e) {
		  throw e
		  formException = e + ""
		}
	  }
	}

	// Range Parameters (strings/numbers/selections)
	var rangeParameterFieldSets = win.createRangeParameter(this.serviceXML, null, parameterConfig)
	if (rangeParameterFieldSets.length > 0) {
	  for (var j = 0; j < rangeParameterFieldSets.length; j++) {
		standardFields.push(rangeParameterFieldSets[j])
	  }
	}

	// Standard Parameter Group
	// ORDER BY ORDER
	var standardParameterGroupNodes = selectNodes(this.serviceXML, '/Service/ParameterSet/ParameterGroup[Level="Standard"]')
	for (var i = 0; i < standardParameterGroupNodes.length; i++) {
	  parameterConfig.level = 'standard'
	  var groupFieldComponents = new Array()
	  var groupName = selectSingleNodeValue(standardParameterGroupNodes[i], "Name")
	  if (groupName != null) {
		var groupLabel = selectSingleNodeValue(standardParameterGroupNodes[i], "GroupLabel")
		var standardParameterGroupFieldNodes = selectNodes(this.serviceXML, '/Service/ParameterSet/Parameter[GroupName="' + groupName + '" and Type!="chemical/x-mdl-molfile"]')
		for (var j = 0; j < standardParameterGroupFieldNodes.length; j++) {
		  var name = selectSingleNodeValue(standardParameterGroupFieldNodes[j], "Name")
		  var editable = selectSingleNodeValue(standardParameterGroupFieldNodes[j], "Editable", 'true')
		  if (formConfig.hiddenParams[name]) {
			editable = 'false'
		  }
		  if (editable != 'false') {
			try {
			  var fieldParameter = win.createParameter(standardParameterGroupFieldNodes[j], null, parameterConfig)
			  if (fieldParameter != null) {
				groupFieldComponents.push(fieldParameter)
			  }
			} catch (e) {
			  throw e
			  formException = e + ""
			}
		  }
		}
		if (groupFieldComponents.length > 0 && groupLabel != null) {
		  var fieldSetConfig = new Object()
		  fieldSetConfig.layout = 'form'
		  fieldSetConfig.layoutConfig = {
			columns: 4
		  }
		  fieldSetConfig.title = groupLabel
		  fieldSetConfig.itemCls = 'nowrap'
		  fieldSetConfig.labelWidth = parameterConfig.labelWidth
		  fieldSetConfig.autoHeight = true
		  fieldSetConfig.collapsible = true
		  fieldSetConfig.items = groupFieldComponents
		  standardFields.push(new Ext.form.FieldSet(fieldSetConfig))
		}
		// Range Parameters (strings/numbers/selections)
		rangeParameterFieldSets = win.createRangeParameter(this.serviceXML, groupName, parameterConfig)
		if (rangeParameterFieldSets.length > 0) {
		  for (var j = 0; j < rangeParameterFieldSets.length; j++) {
			standardFields.push(rangeParameterFieldSets[j])
		  }
		}
	  }
	}
	// Advanced Parameter Group
	// ORDER BY ORDER
	var advancedParameterGroupNodes = selectNodes(this.serviceXML, '/Service/ParameterSet/ParameterGroup[Level="Advanced"]')
	for (var i = 0; i < advancedParameterGroupNodes.length; i++) {
	  parameterConfig.level = 'advanced'
	  var groupFieldComponents = new Array()
	  var groupName = selectSingleNodeValue(advancedParameterGroupNodes[i], "Name")
	  if (groupName != null) {
		var groupLabel = selectSingleNodeValue(advancedParameterGroupNodes[i], "GroupLabel")
		var advancedParameterGroupFieldNodes = selectNodes(this.serviceXML, '/Service/ParameterSet/Parameter[GroupName="' + groupName + '" and Type!="chemical/x-mdl-molfile"]')
		for (var j = 0; j < advancedParameterGroupFieldNodes.length; j++) {
		  var name = selectSingleNodeValue(advancedParameterGroupFieldNodes[j], "Name")
		  var editable = selectSingleNodeValue(advancedParameterGroupFieldNodes[j], "Editable", 'true')
		  if (formConfig.hiddenParams[name]) {
			editable = 'false'
		  }
		  if (editable != 'false') {
			try {
			  var fieldParameter = win.createParameter(advancedParameterGroupFieldNodes[j], null, parameterConfig)
			  if (fieldParameter != null) {
				groupFieldComponents.push(fieldParameter)
			  }
			} catch (e) {
			  throw e
			  formException = e + ""
			}
		  }
		}
		if (groupFieldComponents.length > 0 && groupLabel != null) {
		  var fieldSetConfig = new Object()
		  fieldSetConfig.layout = 'form'
		  fieldSetConfig.layoutConfig = {
			columns: 4
		  }
		  fieldSetConfig.title = groupLabel
		  fieldSetConfig.itemCls = 'nowrap'
		  fieldSetConfig.labelWidth = parameterConfig.labelWidth
		  fieldSetConfig.autoHeight = true
		  fieldSetConfig.collapsible = true
		  fieldSetConfig.items = groupFieldComponents
		  advancedFields.push(new Ext.form.FieldSet(fieldSetConfig))
		}
		// Range Parameters (strings/numbers/selections)
		rangeParameterFieldSets = win.createRangeParameter(this.serviceXML, groupName, parameterConfig)
		if (rangeParameterFieldSets.length > 0) {
		  for (var j = 0; j < rangeParameterFieldSets.length; j++) {
			advancedFields.push(rangeParameterFieldSets[j])
		  }
		}
	  }
	}

	var serviceFieldPanels = new Array()
	if (standardFields.length > 0) {
	  serviceFieldPanels.push({
		items: [{
			layout: 'form',
			itemCls: 'nowrap',
			items: standardFields
		  }]
	  })
	}
	if (advancedFields.length > 0) {
	  this.advancedPanel = new Ext.Panel({
		bodyStyle: 'padding-top: 5px',
		collapsible: true,
		collapsed: true,
		hideCollapseTool: true,
		// title: 'Advanced',
		frame: false,
		items: [{
			layout: 'form',
			itemCls: 'nowrap',
			items: advancedFields
		  }],
		listeners: {
		  collapse: function (advPanel) {
			advPanel.showHideButton.setText('Show Advanced')
			win.doLayoutOnselectedResourcesFieldSet()
		  },
		  expand: function (advPanel) {
			advPanel.showHideButton.setText('Hide Advanced')
			win.doLayoutOnselectedResourcesFieldSet()
		  }
		}
	  })
	  serviceFieldPanels.push((this.advancedPanel.showHideButton = new Ext.Button({
		text: 'Show Advanced',
		enableToggle: true,
		allowDepress: true,
		targetPanel: this.advancedPanel,
		handler: function (button) {
		  button.targetPanel.toggleCollapse()
		}
	  })))

	  serviceFieldPanels.push(this.advancedPanel)
	}

	if (standardFields.length > 0) {
	  var serviceFormConfig = {
		region: formConfig.region,
		labelAlign: formConfig.labelAlign || 'left'
	  }

	  serviceFormConfig.id = serviceFormID
	  serviceFormConfig.frame = true
	  serviceFormConfig.border = false
	  serviceFormConfig.title = formConfig.serviceName
	  // serviceFormConfig.bodyStyle = 'padding:5px 5px 0'

	  serviceFormConfig.items = serviceFieldPanels
	  // serviceFormConfig.itemCls = 'nowrap'
	  if (formConfig.renderTo) {
		serviceFormConfig.renderTo = formConfig.renderTo
	  }
	  serviceFormConfig.timeout = 300000
	  serviceFormConfig.fileUpload = isFileUpload
	  serviceFormConfig.keys = {
		key: Ext.EventObject.ENTER,
		fn: function (key, evt) {
		  var form = Ext.getCmp(serviceFormID)
		  var field = Ext.getCmp(evt.getTarget().id)
		  if (field && field.allowEnterKeySubmit) {
			if (form.getForm().isValid()) {
			  win.handleEnterKeySubmit()
			}
		  }
		}
	  }
	  serviceFormConfig.listeners = {
		afterlayout: function (form) {
		  form.hide()
		  var showFunc = function () {
			win.updateDependencies(null, form)
			form.show()
		  }
		  showFunc.defer(10, this)
		}
	  }

	  serviceFormConfig.showMask = function (msg) {
		if (this.loadMask != null) {
		  this.loadMask.hide()
		}
		this.loadMask = new Ext.LoadMask(this.getEl(), {
		  msg: msg
		})
		this.loadMask.show()
	  }
	  serviceFormConfig.hideMask = function () {
		if (this.loadMask != null) {
		  this.loadMask.hide()
		  this.loadMask = null
		}
	  }

	  if (formException == null) {
		return new Ext.form.FormPanel(serviceFormConfig);
	  } else {
		Ext.Msg.alert('Cannot Run ' + formConfig.serviceName + ' Service', formException);
		return null
	  }
	}
  },
  createRangeParameter: function (xml, groupName, parameterConfig) {
	var win = this
	var rangeParameterFieldSets = new Array()
	var rangeParameterXPath = '/Service/ParameterSet/ParameterRange[count(GroupName)=0 and (Parameter/Editable="true" or count(Parameter/Editable)=0)]'

	if (groupName != null) {
	  rangeParameterXPath = '/Service/ParameterSet/ParameterRange[GroupName="' + groupName + '" and (Parameter/Editable="true" or count(Parameter/Editable)=0)]'
	}
	// Range Parameters (strings/numbers/selections)
	// ORDER BY ORDER
	var parameterRangeNodes = selectNodes(xml, rangeParameterXPath)
	for (var i = 0; i < parameterRangeNodes.length; i++) {
	  var rangeFieldComponents = new Array()
	  var rangeLabel = selectSingleNodeValue(parameterRangeNodes[i], "RangeLabel")
	  var rangeFieldNodes = selectNodes(parameterRangeNodes[i], 'Parameter')
	  for (var j = 0; j < rangeFieldNodes.length; j++) {
		var name = selectSingleNodeValue(rangeFieldNodes[j], "Name")
		var editable = selectSingleNodeValue(rangeFieldNodes[j], "Editable", 'true')
		if (parameterConfig.formConfig.hiddenParams[name]) {
		  editable = 'false'
		}
		if (editable != 'false') {
		  var fieldParameter = win.createParameter(rangeFieldNodes[j], (j == 0 ? "From" : "To"), parameterConfig)
		  if (fieldParameter != null) {
			rangeFieldComponents.push(fieldParameter)
		  }
		}
	  }
	  if (rangeFieldComponents.length > 0 && rangeLabel != null) {
		var fieldSetConfig = new Object()
		fieldSetConfig.layout = 'form'
		fieldSetConfig.layoutConfig = {
		  columns: 4
		}
		fieldSetConfig.title = rangeLabel
		fieldSetConfig.itemCls = 'nowrap'
		fieldSetConfig.labelWidth = parameterConfig.labelWidth
		fieldSetConfig.autoHeight = true
		fieldSetConfig.collapsible = true
		fieldSetConfig.items = rangeFieldComponents
		rangeParameterFieldSets.push(new Ext.form.FieldSet(fieldSetConfig))
	  }
	}
	return rangeParameterFieldSets
  },
  createParameter: function (parameterNode, defaultLabel, parameterConfig) {
	var win = this
	var fieldName = selectSingleNodeValue(parameterNode, "Name")
	//var fieldValue = selectSingleNodeValue(parameterNode, "Value")
	var fieldValue = this.getInitialFieldValue(fieldName, parameterNode)
	var fieldLabel = selectSingleNodeValue(parameterNode, "Label")
	var helpText = selectSingleNodeValue(parameterNode, "HelpText")
	var helpURL = selectSingleNodeValue(parameterNode, "HelpURL")
	if (fieldLabel == null || fieldLabel.length == 0) {
	  fieldLabel = (defaultLabel == null ? fieldName : defaultLabel)
	}
	var fieldType = selectSingleNodeValue(parameterNode, "Type/@type") || selectSingleNodeValue(parameterNode, "Type")

	var fieldTypeSystem = selectSingleNodeValue(parameterNode, "Type/@system")

	var defaultValue = selectSingleNodeValue(parameterNode, "DefaultValue")
	var required = selectSingleNodeValue(parameterNode, "RequirementLevel")
	var acceptsList = Ext.type(selectSingleNode(parameterNode, "AcceptsList")) || false
	var listSeparator = selectSingleNodeValue(parameterNode, "AcceptsList/@delimiter") || ';'
	var contingencyDependencies = selectNodes(parameterNode, "ParameterDependencySet/ParameterDependency[DependencyType='Enabled']/Contingency")
	var bindingDependency = selectSingleNode(parameterNode, "ParameterDependencySet/ParameterDependency[DependencyType='Binding']/DataSource")

	var forceSelection = selectSingleNodeValue(parameterNode, "Selection/@force_selection", true)

	if (Ext.type(forceSelection) == 'string') {
	  forceSelection = (forceSelection != 'false')
	}
	var currentValue = defaultValue
	if (fieldValue) {
	  currentValue = fieldValue
	}

	if (fieldType == null) {
	  fieldType = 'string'
	}
	fieldType = fieldType.toLowerCase()

	var fieldComponentOptions = {
	  name: fieldName,
	  fieldLabel: fieldLabel,
	  width: parameterConfig.fieldWidth,
	  level: parameterConfig.level,
	  allowBlank: (required == null || required != 'Required'),
	  deps: [],
	  helpText: helpText,
	  helpURL: helpURL,
	  helpClickCB: function (field, helpEl) {
		if (!helpEl.getAttribute("origHRef")) {
		  helpEl.set({
			origHRef: helpEl.getAttribute("href")
		  })
		}
		var origHRef = helpEl.getAttribute("origHRef")
		if (origHRef) {
		  var updatedHRef = win.updateURLFromParameters(origHRef, field)
		  helpEl.set({
			href: updatedHRef
		  })
		}
	  },
	  allowEnterKeySubmit: false,
	  initDefaultValue: defaultValue
	}

	if (contingencyDependencies) {
	  for (var i = 0; i < contingencyDependencies.length; i++) {
		var contingencyNode = contingencyDependencies[i]
		var cDepParam = selectSingleNodeValue(contingencyNode, "ParameterName")
		var cDepValues = selectNodes(contingencyNode, "ContingentValue")
		var cDepLogic = selectSingleNodeValue(contingencyNode, "@logic")
		var cDepComp = selectSingleNodeValue(contingencyNode, "Comparison")

		for (var j = 0; j < cDepValues.length; j++) {
		  var cDepValue = selectSingleNodeValue(cDepValues[j], ".")
		  fieldComponentOptions.deps.push({
			type: 'Enabled',
			param: cDepParam,
			value: cDepValue,
			comp: (cDepComp ? cDepLogic.toLowerCase() : "equals"),
			logic: (cDepLogic ? cDepLogic.toLowerCase() : "and")
		  })
		}
	  }
	}
	if (bindingDependency) {
	  var dataSource = selectSingleNodeValue(bindingDependency, ".")
	  var xPath = selectSingleNodeValue(bindingDependency, "@xpath")
	  fieldComponentOptions.deps.push({
		type: 'Binding',
		datasource: dataSource,
		xpath: xPath
	  })
	}

	var updateDependenciesFunc = function (field) {
	  win.updateDependencies(field)
	}

	if (selectSingleNode(parameterNode, "Selection/FilterSource") != null) {
	  var dataSource = selectSingleNodeValue(parameterNode, "Selection/FilterSource")
	  var queryParam = selectSingleNodeValue(parameterNode, "Selection/FilterSource/@query_param", fieldComponentOptions.name)
	  var minimumSearchCharacters = selectSingleNodeValue(parameterNode, "Selection/FilterSource/@minimum_search_characters", 3)
	  var emptyText = selectSingleNodeValue(parameterNode, "Selection/FilterSource/@empty_text", 'Type ' + fieldLabel + ' (min. ' + minimumSearchCharacters + ' characters)')
	  var template = selectSingleNodeValue(parameterNode, "Selection/Qualifier/Template")
	  var delimiter = (template ? selectSingleNodeValue(template, "@delimiter", "|") : null)
	  var filterSource = deserializeRequest(dataSource)
	  var filterParams = (filterSource.query ? filterSource.query : {})

	  // Set up the options
	  Ext.apply(fieldComponentOptions, {
		store: new Ext.data.Store({
		  reader: new Ext.data.XmlReader({
			record: 'Option'
		  }, ['Label', 'Value']),
		  url: '/aig/xmldataproxy.go',
		  baseParams: {
			src: filterSource.url
		  },
		  filterParams: filterParams,
		  fields: ['Label', 'Value'],
		  formID: parameterConfig.formConfig.formID,
		  listeners: {
			beforeload: function (store, options) {
			  var form = Ext.getCmp(store.formID)
			  var formValues = form.getForm().getValues()
			  for (var paramName in store.filterParams) {
				var filterParamValue = store.filterParams[paramName]
				for (var formPName in formValues) {
				  if (filterParamValue == "[" + formPName + "]" || filterParamValue == "{" + formPName + "}") {
					filterParamValue = formValues[formPName]
				  }
				}
				store.baseParams[paramName] = filterParamValue
			  }
			},
			load: function (store, r, options) {
			  var form = Ext.getCmp(store.formID)
			  var combo = form.find("name", fieldName)[0]
			  delete combo.lastQuery
			}
		  }
		}),
		triggerClass: 'x-form-clear-trigger',
		displayField: 'Label',
		valueField: 'Value',
		queryParam: queryParam,
		hiddenName: fieldComponentOptions.name,
		typeAhead: false,
		emptyText: emptyText,
		loadingText: 'Retrieving...',
		resizable: true,
		minChars: minimumSearchCharacters,
		handleHeight: 10,
		height: 10,
		hideTrigger: false,
		forceSelection: true,
		listWidth: parameterConfig.fieldWidth,
		onTriggerClick: function () {
		  this.collapse();
		  this.clearValue()
		},
		rgtype: 'filteredcombo'
	  })
	  Ext.apply(fieldComponentOptions.listeners, {
		beforequery: function (qe) {
		  delete qe.combo.lastQuery;
		}
	  })
	  if (acceptsList) {
		Ext.apply(fieldComponentOptions, {
		  separator: listSeparator,
		  valueDelimiter: listSeparator,
		  stackItems: true,
		  grow: true,
		  rgtype: 'multiselectfilteredcombo'
		})

		Ext.apply(fieldComponentOptions.listeners, {
		  select: updateDependenciesFunc,
		  additem: updateDependenciesFunc,
		  newitem: updateDependenciesFunc,
		  removeitem: updateDependenciesFunc
		})

		comboBox = new Ext.ux.form.SuperBoxSelect(fieldComponentOptions)
	  } else {
		return new Ext.form.ComboBox(fieldComponentOptions)

	  }
	} else if (selectSingleNode(parameterNode, "Selection") != null) {
	  var comboBox = null
	  var dataSource = selectSingleNodeValue(parameterNode, "Selection/DataSource")
	  var template = selectSingleNodeValue(parameterNode, "Selection/Qualifier/Template")
	  var includeOptionDescriptions = selectSingleNodeValue(parameterNode, "Selection/Qualifier/IncDescriptions")

	  if (dataSource != null) {
		//Create a Store        
		fieldComponentOptions.store = new Ext.data.Store({
		  url: '/aig/xmldataproxy.go',
		  baseParams: {
			src: dataSource
		  },
		  autoLoad: true,
		  dataSource: dataSource,
		  formID: parameterConfig.formConfig.formID,
		  reader: new Ext.data.XmlReader({
			record: 'Option'
		  }, ['Label', 'Value', 'Category', 'Description']),
		  method: 'GET',
		  fields: ['Label', 'Value', 'Category', 'Description'],
		  listeners: {
			beforeload: function (store) {
			  var formFields = Ext.getCmp(store.formID).getForm().getValues()
			  var dataSrc = dataSource
			  for (var name in formFields) {
				var value = formFields[name]
				if (!Ext.isEmpty(value)) {
				  dataSrc = dataSrc.replace("{" + name + "}", escape(value))
				}
			  }
			  store.setBaseParam('src', dataSrc)
			  store.un('beforeload', arguments.callee)
			}
		  }
		})

		if (hasLength(fieldValue)) {
		  fieldComponentOptions.store.on('load', function () {
			var fields = win.form.find('name', fieldName)
			if (Ext.isArray(fields) && fields.length > 0) {
			  fields[0].setValue(fieldValue)
			}
		  })
		}
		// Set up the options
		fieldComponentOptions.loadingText = 'Loading...'
		fieldComponentOptions.emptyText = 'Please select a value'
		fieldComponentOptions.valueField = 'Value'
		fieldComponentOptions.displayField = 'Label'
		fieldComponentOptions.triggerAction = 'all'
		fieldComponentOptions.editable = true
		fieldComponentOptions.forceSelection = forceSelection
		fieldComponentOptions.mode = 'local'

		if (template) {
		  fieldComponentOptions.tpl = new Ext.XTemplate(template.replace(/[\t\n\r]+/g, ""))
		} else if (includeOptionDescriptions) {
		  fieldComponentOptions.tpl = new Ext.XTemplate(
			  '<tpl for="."><div class="queryform-combobox-item">',
			  '<h3><span>{Category}<br/></span>{Label}</h3>',
			  '{Description}',
			  '</div></tpl>'
			  ),
			  fieldComponentOptions.itemSelector = 'div.queryform-combobox-item'
		}

		fieldComponentOptions.resizable = true
		fieldComponentOptions.listeners = {
		  select: updateDependenciesFunc
		}
		fieldComponentOptions.hiddenName = fieldComponentOptions.name
		fieldComponentOptions.name = fieldComponentOptions.name
		fieldComponentOptions.listWidth = parameterConfig.fieldWidth

		if (acceptsList) {
		  fieldComponentOptions.separator = listSeparator
		  fieldComponentOptions.valueDelimiter = listSeparator

		  fieldComponentOptions.listeners = {
			select: updateDependenciesFunc,
			additem: updateDependenciesFunc,
			newitem: updateDependenciesFunc,
			removeitem: updateDependenciesFunc
		  }
		  fieldComponentOptions.stackItems = true
		  fieldComponentOptions.grow = true
		  fieldComponentOptions.rgtype = 'multiselectdyncombo'

		  comboBox = new Ext.ux.form.SuperBoxSelect(fieldComponentOptions)
		} else {
		  fieldComponentOptions.rgtype = 'dyncombo'
		  comboBox = new Ext.form.ComboBox(fieldComponentOptions)
		}
		fieldComponentOptions.store.on("load", function () {
		  win.setInitialParameterValues(comboBox)
		})
	  } else {
		var optionNodes = selectNodes(parameterNode, "Selection/Option")
		var comboBoxStoreData = new Array()
		for (var i = 0; i < optionNodes.length; i++) {
		  var value = selectSingleNodeValue(optionNodes[i], "Value")
		  var label = selectSingleNodeValue(optionNodes[i], "Label", value)
		  comboBoxStoreData.push([label, value])
		}
		var comboBoxStoreConfig = {
		  fields: ['name', 'value'],
		  data: comboBoxStoreData
		}
		var comboBoxStore = new Ext.data.SimpleStore(comboBoxStoreConfig)
		// Set up the options
		// fieldComponentOptions.emptyText = 'Please select a value'
		fieldComponentOptions.store = comboBoxStore
		fieldComponentOptions.valueField = 'value'
		fieldComponentOptions.displayField = 'name'
		fieldComponentOptions.triggerAction = 'all'
		fieldComponentOptions.emptyText = 'Please select a value'
		fieldComponentOptions.editable = true
		fieldComponentOptions.forceSelection = forceSelection
		fieldComponentOptions.mode = 'local'
		fieldComponentOptions.resizable = true
		fieldComponentOptions.listeners = {
		  select: updateDependenciesFunc
		}
		fieldComponentOptions.hiddenName = fieldComponentOptions.name
		fieldComponentOptions.name = fieldComponentOptions.name
		fieldComponentOptions.listWidth = parameterConfig.fieldWidth

		if (currentValue) {
		  fieldComponentOptions.value = currentValue
		}
		if (acceptsList) {
		  fieldComponentOptions.separator = listSeparator
		  fieldComponentOptions.valueDelimiter = listSeparator
		  fieldComponentOptions.listeners = {
			select: updateDependenciesFunc,
			additem: updateDependenciesFunc,
			newitem: updateDependenciesFunc,
			removeitem: updateDependenciesFunc
		  }
		  fieldComponentOptions.rgtype = 'multiselectcombo'
		  comboBox = new Ext.ux.form.SuperBoxSelect(fieldComponentOptions)
		} else {
		  fieldComponentOptions.rgtype = 'combo'

		  comboBox = new Ext.form.ComboBox(fieldComponentOptions)
		  if (!fieldComponentOptions.forceSelection) {
			comboBox.on('blur', function () {
			  var r = this.findRecord(this.displayField, this.getRawValue());
			  if (!r) {
				if (this.store) {
				  var rec = new this.store.recordType({
					name: this.getRawValue(),
					value: this.getRawValue()
				  });
				  rec.commit()
				  this.store.add(rec)
				  this.setValue(this.getRawValue())
				}
			  }
			}, comboBox)
		  }
		}
	  }
	  return comboBox
	} else if (fieldType == 'integer' || fieldType == 'double') {
	  var minValue = selectSingleNodeValue(parameterNode, "Range/MinimumValue")
	  var maxValue = selectSingleNodeValue(parameterNode, "Range/MaximumValue")
	  if (minValue != null) {
		fieldComponentOptions.minValue = minValue
	  }
	  if (maxValue != null) {
		fieldComponentOptions.maxValue = maxValue
	  }
	  if (currentValue) {
		fieldComponentOptions.value = currentValue
	  }
	  fieldComponentOptions.allowDecimals = (fieldType != 'integer')
	  fieldComponentOptions.listeners = {
		change: updateDependenciesFunc
	  }
	  fieldComponentOptions.allowEnterKeySubmit = true
	  fieldComponentOptions.rgtype = 'number'
	  return new Ext.form.NumberField(fieldComponentOptions)
	} else if (fieldType == 'boolean') {
	  fieldComponentOptions.checked = (currentValue == 'true')
	  fieldComponentOptions.listeners = {
		check: updateDependenciesFunc
	  }
	  fieldComponentOptions.rgtype = 'checkbox'
	  return new Ext.rx.form.XCheckbox(fieldComponentOptions)
	} else if (fieldType == 'date') {
	  if (currentValue) {
		fieldComponentOptions.value = currentValue
	  }
	  fieldComponentOptions.listeners = {
		change: updateDependenciesFunc
	  }
	  fieldComponentOptions.allowEnterKeySubmit = true
	  fieldComponentOptions.rgtype = 'date'
	  return new Ext.form.DateField(fieldComponentOptions)
	} else if (fieldType == 'datetime') {
	} else if (fieldType == 'amgen assayresult identifier') {
	  var resultTypes = selectSingleNodeValue(parameterNode, "Type/Qualifier[@name='result_types']")
	  fieldComponentOptions.isFormField = true
	  fieldComponentOptions.result_types = resultTypes
	  fieldComponentOptions.rgtype = 'assay'
	  return new AIG.AssaySelectorField(fieldComponentOptions)
	} else if (fieldType == 'amgen person identifier' || fieldType == 'amgen login') {
	  if (acceptsList) {
		fieldComponentOptions.rgtype = 'people'
		return new RG.rx.UserSelectorField(fieldComponentOptions)
	  } else {
		return new RG.rx.UserSelectorCombo(fieldComponentOptions)
	  }
	} else if (fieldType == 'file') {
	  fieldComponentOptions.emptyText = 'Select a file'
	  fieldComponentOptions.buttonCfg = {
		text: 'Browse'
	  }
	  fieldComponentOptions.rgtype = 'file'

	  Ext.apply(fieldComponentOptions, {
		setSize1: function (w, h) {
		  Ext.log(w + "," + h)
		  Ext.ux.form.FileUploadField.superclass.setSize.call(this, w, h);
		},
		// private
		onResize1: function (w, h) {
		  Ext.ux.form.FileUploadField.superclass.onResize.call(this, w, h);

		  this.wrap.setWidth(w);

		  if (!this.buttonOnly) {
			var w = this.wrap.getWidth() - this.button.getEl().getWidth() - this.buttonOffset;
			this.el.setWidth(w);
		  }
		}
	  })
	  return new Ext.form.FileUploadField(fieldComponentOptions)
	} else if (fieldTypeSystem != null && fieldTypeSystem == 'mimetype') {
	  switch (fieldType) {
		case ('chemical/x-mdl-molfile') :
		  fieldComponentOptions.allowEmpty = fieldComponentOptions.allowBlank
		  fieldComponentOptions.autoLoadEditor = false
		  if (hasLength(fieldValue)) {
			fieldComponentOptions.initialStructure = {
			  mol: fieldValue
			}
		  }
		  fieldComponentOptions.rgtype = 'chemstructure'
		  return new SMSC.StructureField(fieldComponentOptions)
		default :
		  return null
	  }
	} else {
	  var minValue = selectSingleNodeValue(parameterNode, "Range/MinimumValue")
	  var maxValue = selectSingleNodeValue(parameterNode, "Range/MaximumValue")
	  var pattern = selectSingleNodeValue(parameterNode, "Type/@pattern")
	  if (minValue != null) {
		fieldComponentOptions.minLength = minValue
	  }
	  if (maxValue != null) {
		fieldComponentOptions.maxLength = maxValue
	  }
	  if (currentValue) {
		fieldComponentOptions.value = currentValue
	  }
	  if (pattern != null) {
		fieldComponentOptions.regex = new RegExp(pattern)
		fieldComponentOptions.regexText = "Parameter invalid"
	  }
	  var multiLine = selectSingleNodeValue(parameterNode, "Type/@multiline")

	  if (multiLine != null && multiLine == 'true') {
		fieldComponentOptions.enableKeyEvents = true
		fieldComponentOptions.listeners = {
		  keydown: {
			fn: function (field, e) {
			  var key = Ext.EventObject.getKey();
			  if (key === 13) {
				e.stopPropagation();
			  }
			},
			scope: this
		  },
		  change: updateDependenciesFunc
		}
		fieldComponentOptions.rgtype = 'textarea'
		return new Ext.form.TextArea(fieldComponentOptions)
	  } else {
		fieldComponentOptions.listeners = {
		  change: updateDependenciesFunc
		}
		fieldComponentOptions.allowEnterKeySubmit = true
		fieldComponentOptions.rgtype = 'text'
		return new Ext.form.TextField(fieldComponentOptions)
	  }
	}
  },
  updateDependencies: function (field, form) {
	// Ext.log('Dependencies update')
	if (!form && field) {
	  form = field.findParentByType('form')
	}
	if (!form) {
	  return
	}
	// All Form Parameters
	var formItems = form.getForm().items
	var assayFields = form.findByType('rg-assay')
	if (!Ext.isEmpty(assayFields)) {
	  for (var i = 0; i < assayFields.length; i++) {
		if (!formItems.containsKey(assayFields[i].id)) {
		  formItems.add(assayFields[i].id, assayFields[i])
		}
	  }
	}

	formItems.each(function (item) {
	  if (field != item && item.deps) {
		Ext.each(item.deps, function (dep) {
		  if (dep.type == 'Binding' && item.store) {
			var paramValues = form.getForm().getValues(false)
			var datasource = dep.datasource
			var replaceSearchTerm1 = (field == null ? 1 : datasource.indexOf("{" + field.name + "}"))
			var replaceSearchTerm2 = (field == null ? 1 : datasource.indexOf("[" + field.name + "]"))
			if (replaceSearchTerm1 > -1 || replaceSearchTerm2 > -1) {
			  for (var name in paramValues) {
				var value = paramValues[name]
				if (name != null) {
				  var depDefaultValue = formItems.get(formItems.findIndex("name", name))
				  var value = paramValues[name]
				  if (Ext.type(value) == 'array') {
					value = value.join(';')
				  }
				  if (!hasLength(value) && depDefaultValue && depDefaultValue.initDefaultValue) {
					value = depDefaultValue.initDefaultValue
				  }
				  if (hasLength(value)) {
					datasource = datasource.replace("{" + name + "}", escape(value))
					datasource = datasource.replace("[" + name + "]", escape(value))
				  }
				}
			  }
			  datasource = datasource.replace(/\[\w+\]/g, "")
			  // datasource = datasource.replace(/\n/g, "\t")
			  if (datasource.search(/{\w+}/) == -1) {
				// Ext.log('Binding: ' + field.name + " " + item.name + " = " + datasource)
				item.store.proxy.conn.url = '/aig/xmldataproxy.go'
				item.store.baseParams.src = datasource

				form.showMask('Updating Options')
				item.store.load({
				  callback: function (r, options, success) {
					if (success) {
					  var selectedValues = selectNodeValues(item.store.reader.xmlData, '//Option[Selected]/Value')
					  if (item.rgtype == "multiselectdyncombo") {
						item.clearValue()
					  }
					  if (item.rgtype == "multiselectdyncombo" && Ext.isArrayNotEmpty(selectedValues)) {
						item.setValue(selectedValues)
					  } else if (Ext.type(item.getValue()) == 'string' && item.getValue().length == 0 && item.initDefaultValue) {
						item.setValue(item.initDefaultValue)
					  }
					}
					if (Ext.isFunction(item.collapse)) {
					  item.collapse()
					}
					form.hideMask()
				  }
				})
			  } else {
				// Ext.log('No Binding: ' + item.name + " = " + datasource)
			  }
			}

		  }
		})
	  }
	})

	// Handle Enabled Parameters
	formItems.each(function (item) {
	  var paramValues = form.getForm().getValues(false)
	  if (item.deps) {
		var orSet = undefined
		var andSet = true
		Ext.each(item.deps, function (dep) {
		  if (dep.type == 'Enabled') {
			var comp = dep.comp
			var param = dep.param
			var logic = dep.logic
			var value = dep.value
			var condition_met = true
			switch (comp.substr(0, 1)) {
			  case "e" :
				if (Ext.type(paramValues[param]) == 'array') {
				  condition_met = false
				  Ext.each(paramValues[param], function (val) {
					if (equalsIgnoreCase(val, value)) {
					  condition_met = true
					}
				  })
				} else {
				  if (paramValues[param] && !equalsIgnoreCase(paramValues[param], value)) {
					condition_met = false
				  }
				}
				//console.log(item.name+" "+param + " " + value + " " + condition_met)
				break
			  case "l" :
				if (paramValues[param] && paramValues[param] <= value) {
				  condition_met = false
				}
				break
			  case "g" :
				if (paramValues[param] && paramValues[param] >= value) {
				  condition_met = false
				}
				break
			}
			if (logic === 'and') {
			  if (!condition_met) {
				andSet = false
			  }
			} else {
			  if (orSet === undefined) {
				orSet = false
			  }
			  if (condition_met && paramValues[param]) {
				orSet = true
			  }
			}
		  }
		})
		var visible = ((orSet === undefined || orSet) && andSet)
		item.setVisible(visible)
		try {
		  var parent = item.el.up('div.x-form-item')
		  if (parent) {
			parent.setVisible(visible);
		  }
		} catch (e) {
		}
	  } else {
		item.setVisible(true)
		try {
		  var parent = item.el.up('div.x-form-item')
		  if (parent) {
			parent.setVisible(true);
		  }
		} catch (e) {
		}
	  }
	})
  },
  updateURLFromParameters: function (baseURL, field, form) {
	if (!form && field) {
	  form = field.findParentByType('form')
	}
	if (!form) {
	  return
	}
	// All Form Parameters
	var formItems = form.getForm().items

	formItems.each(function (item) {
	  var paramValues = form.getForm().getValues(false)
	  for (var name in paramValues) {
		var value = paramValues[name]
		if (name != null) {
		  var depDefaultValue = formItems.get(formItems.findIndex("name", name))
		  var value = paramValues[name]
		  if (hasLength(value)) {
			baseURL = baseURL.replace("{" + name + "}", value)
		  }
		}
	  }
	})
	return baseURL
  },
  /**
   * Method which is called after the form is rendered OR after a dynamic load event.
   * This is used to set the initial values for certain fields which need handled after rendering.
   */
  setInitialParameterValues: function (field) {
	if (!this.serviceRecord.data.IsParametersSaveable) {
	  return
	}
	var fields
	if (field) {
	  fields = [field]
	} else {
	  fields = this.form.findBy(function (item) {
		return (Ext.isString(item.rgtype))
	  })
	}
	for (var i = 0; i < fields.length; i++) {
	  var fld = fields[i]
	  var parameterName = fld.name
	  var parameterNode = selectSingleNode(this.serviceXML, '/Service//Parameter[Name="' + parameterName + '"]')
	  switch (fld.rgtype) {
		//Types that have special handling
		case 'filteredcombo':
		  var fieldValue = this.getInitialFieldValue(parameterName, parameterNode)
		  var dataSource = selectSingleNodeValue(parameterNode, "Selection/FilterSource")
		  var queryParam = selectSingleNodeValue(parameterNode, "Selection/FilterSource/@id_param")
			  || selectSingleNodeValue(parameterNode, "Selection/FilterSource/@query_param", parameterName)
		  var filterSource = deserializeRequest(dataSource)
		  var params = (filterSource.query ? filterSource.query : {})
		  params[queryParam] = fieldValue
		  params.src = filterSource.url
		  if (hasLength(fieldValue)) {
			Ext.Ajax.request({
			  url: '/aig/xmldataproxy.go',
			  success: function (response) {
				var queryValue = selectSingleNodeValue(response.responseXML, '//Value') || selectSingleNodeValue(response.responseXML, '//Label')
				this.getStore().loadData(response.responseXML)
				this.setValue(queryValue)
				if (Ext.isFunction(this.collapse)) {
				  this.collapse()
				}
			  },
			  params: params,
			  scope: fld
			})
		  }
		  break
		case 'person':
		  var fieldValue = this.getInitialFieldValue(parameterName, parameterNode)
		  if (hasLength(fieldValue)) {
			Ext.Ajax.request({
			  url: '/aig/store.go?request=PEOPLE',
			  params: {
				username: fieldValue
			  },
			  success: function (response) {
				var people = Ext.decode(response.responseText)
				this.getStore().loadData(people)
				if (this.getStore().getCount() > 0) {
				  var userRecord = this.getStore().getAt(0)
				  this.setValue(userRecord.data.username)
				}
				if (Ext.isFunction(this.collapse)) {
				  this.collapse()
				}
			  },
			  scope: fld
			})
		  }
		  break
		case 'people':
		  parameterNode = selectSingleNode(this.serviceXML, '/Service//Parameter[Name="' + fld.hiddenName + '"]')
		  var fieldValue = this.getInitialFieldValue(fld.hiddenName, parameterNode)
		  if (hasLength(fieldValue)) {
			Ext.Ajax.request({
			  url: "/aig/personquery.go",
			  success: function (response) {
				try {
				  var resultUsers = Ext.util.JSON.decode(response.responseText).names
				  var userRecords = []
				  for (var i = 0; i < resultUsers.length; i++) {
					userRecords.push(new RG.Record.UserRecord({
					  name: resultUsers[i].name,
					  title: resultUsers[i].title,
					  costcenter: resultUsers[i].costcenter,
					  location: resultUsers[i].location,
					  bldg: resultUsers[i].bldg,
					  phone: resultUsers[i].phone,
					  manager: resultUsers[i].manager,
					  manager_username: resultUsers[i].manager_username,
					  obj_class: resultUsers[i].obj_class,
					  username: resultUsers[i].username,
					  employee_id: resultUsers[i].employee_id
					}))
				  }
				  this.updateMessage()
				} catch (e) {
				}
				this.setValue(null, userRecords)
			  },
			  scope: fld,
			  params: {
				includeGroups: 'N',
				username: fieldValue
			  }
			})
		  }
		  break
		  //Listed here, but are handled elsewhere
		case 'multiselectdyncombo':
		  break
		case 'dyncombo':
		  break
		case 'multiselectcombo':
		  break
		case 'combo':
		  break
		case 'number':
		  break
		case 'checkbox':
		  break
		case 'date':
		  break
		case 'assay':
		  break
		case 'file':
		  break
		case 'chemstructure':
		  break
		case 'textarea':
		  break
		case 'text':
		  break
	  }
	  //If any value is in the advanced sections, expand the advanced panel
	  parameterNode = selectSingleNode(this.serviceXML, '/Service//Parameter[Name="' + parameterName + '"]')
	  if (!parameterNode && fld.hiddenName) {
		parameterNode = selectSingleNode(this.serviceXML, '/Service//Parameter[Name="' + fld.hiddenName + '"]')
	  }
	  if (parameterNode) {
		var fieldValue = this.getInitialFieldValue(parameterName, parameterNode)
		var defaultValue = selectSingleNodeValue(this.serviceXML, '/Service//Parameter[Name="' + parameterName + '"]/DefaultValue')
		if (hasLength(fieldValue) && !String.equals(fieldValue, defaultValue)) {
		  if (fld.level == 'advanced') {
			if (this.advancedPanel)
			  this.advancedPanel.expand()
		  }
		}
	  }
	}
  },
  getInitialFieldValue: function (parameterName, parameterNode) {
	if (Ext.isObject(this.serviceRecord.get('InitialParameterValues'))) {
	  return this.serviceRecord.get('InitialParameterValues')[parameterName]
	}
	return selectSingleNodeValue(parameterNode, 'Value')
  }

})
