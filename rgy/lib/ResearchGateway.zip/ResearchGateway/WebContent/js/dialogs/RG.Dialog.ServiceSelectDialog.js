/**
 * Creates a selection dialog window for selecting and running services
 */

RG.Dialog.ServiceSelectDialog= Ext.extend(RG.Dialog.AnimatedWindow, {  
  initComponent: function(){  
    var dialog= this
    Ext.apply(this, {
      layout: 'border',
      shadow: false,
      maximizable: true,
      stateful: false,
      resizable: true,
      closeAction: 'hide',
      plain: true
    })
    Ext.applyIf(this, {
      queryType: 'query',
      title: 'Select Resource',
      canSaveService: true,
      autoSelectSingleResource: false      
    })
    Ext.applyIf(this.queryParams, {
      responseFormat: 'XML'
    })

    var store = new Ext.data.Store({
      url: '/aig/store.go?request=services',
      baseParams: this.queryParams,
      listeners: {
        beforeload: function(store){
        },
        load: function(store){     
          dialog.handlerServicesLoaded()
        },
        loadexception: function(store, options, error){
          aigErrorHandler(error)
        }
      },
      reader: new Ext.data.XmlReader({
        record: 'Service',
        id: 'ID'
      }, RG.Record.ServiceRecord),
      autoLoad: true
    })    
    
    // create the grid
    this.serviceSelectionGrid = new Ext.grid.GridPanel({
      store: store,
      autoExpandColumn: 'selectservice-name',
      enableColumnMove: false,
      disableSelection: false,
      loadMask: true,
      border: false,
      //height: 200,
      split: true,
      region: 'center',
      ddGroup :'rg-tb-dd',      
      parentContainer: dialog.parentContainer,
      entityTableKey: dialog.entityTableKey,
      columns: [{
        id: "selectservice-name",
        header: 'Resource Name',
        dataIndex: 'Name',
        menuDisabled: true,
        sortable: true,
        renderer: function(value, metaData, record, rowIndex, colIndex, store) {
          var icon= record.data.Icon
          var iconCls= record.data.IconCls
          
          if (hasLength(iconCls)) {
            icon= '/aig/img/s.gif'
            iconCls= RG.Icon.Utils.getSizedIconClass(iconCls, 16)            
          } else if (!hasLength(icon) && !hasLength(iconCls)) {
            icon= '/aig/img/s.gif'
            iconCls= "ix-v0-16-gears_run"
          } else if (!hasLength(iconCls)) {
            iconCls= null            
          } else {
            icon= '/aig/img/s.gif'
          }
          return String.format(
            "<div style='height: 17px;padding-left: 20px' class={0}><img src={1} align='absMiddle'></img>{2}</div>", 
            iconCls, icon, value)              
        }
      }, {
        header: "Category",
        dataIndex: 'Category',
        width: 140,
        sortable: true
      },{
        id: 'LastUsed',
        header: "Last Used",
        dataIndex: 'LastUsed',
        menuDisabled: true,
        sortable: true,
        width: 140,
        renderer :Ext.util.Format.dateRenderer('m/d/Y h:i:s A')
      }],
      listeners :{
        render : function(grid) {
          if (dialog.queryType== 'query') {
            grid.initializeDragDropZones()
          }
        }
      },
      initializeDragDropZones: function() {        
        this.dropZone = new Ext.dd.DropZone(this.getEl(), {
          ddGroup :this.ddGroup,
          grid :this,
          getTargetFromEvent : function(e) {
            var t = Ext.lib.Event.getTarget(e);
            if (t) {
              var rowIndex = this.grid.getView().findRowIndex(t);
              if (rowIndex !== false) {
                var sm = this.grid.selModel;
                if (!sm.isSelected(rowIndex) || e.hasModifier()) {
                  sm.handleMouseDown(this.grid, rowIndex, e);
                }
                return {
                  grid :this.grid,
                  ddel :this.ddel,
                  rowIndex :rowIndex,
                  record :sm.getSelections()[0]
                };
              }
            }
            return false
          },
          onNodeOver : function(target, dd, e, data) {
            return false
          },
          onNodeDrop : function(target, dd, e, data) {
            return false
          }
        });
        this.dragZone = new Ext.grid.GridDragZone(this, {
          ddGroup :this.ddGroup,
          getDragData : function(e) {
            var t = Ext.lib.Event.getTarget(e);            
            if (t) {
              var rowIndex = this.view.findRowIndex(t);
              if (rowIndex !== false) {
                var sm = this.grid.selModel;
                if (!sm.isSelected(rowIndex) || e.hasModifier()) {
                  sm.handleMouseDown(this.grid, rowIndex, e);
                }
                if (sm.getSelections().length != 1) {
                  return false
                }
                var record = sm.getSelections()[0]                 
                if (!record || !record.id) {                  
                  return false
                }
                return {
                  servicegrid :this.grid,
                  ddel :this.ddel,
                  rowIndex :rowIndex,
                  record :record
                }                
              }
            }
            return false;
          },
          onInitDrag : function(e) {
            var data = this.dragData;
            if (!Ext.isObject(data.record)) {
              return
            }
            var icon= data.record.data.icon
            var iconCls= data.record.data.iconCls
          
            if (!hasLength(icon) && !hasLength(iconCls)) {
              icon= '/aig/img/s.gif'
              iconCls= "ix-v0-16-gears_run"
            } else if (!hasLength(iconCls)) {
              iconCls= null            
            } else {
              icon= '/aig/img/s.gif'
            }
            this.ddel.innerHTML =  String.format(
              "<div style='height: 17px;padding-left: 20px' class={0}><img src={1} align='absMiddle'></img>{2}</div>", 
              iconCls, icon, data.record.data.Name)              
            this.proxy.update(this.ddel);
          }
        })
      }  
    }
    )
    
    this.items= [this.serviceSelectionGrid, (this.descriptionPanel= new Ext.Panel({
      region: 'south',
      height: 150,
      split: true,
      border: false,
      bodyStyle: {
        background: '#ffffff',
        padding: '7px'
      },
      html: '<i>Please select a resource</i>',
      tpl: new Ext.Template(['Name: {Name}<br/>', 'Description: {Description}<br/>'])
    }))]
  
    this.tbar= [
    new RG.Form.SearchField({
      emptyText: 'Enter a keyword to filter on',
      store: store,
      width:320,
      searchOnKeyPress: true,
      listeners: {
        search: function(field, value) {
          dialog.handleFilterChange(value)
        },
        clear: function(field) {
          dialog.handleFilterChange()
        }
      }
    })
    ]

    this.buttons= [{
      text: 'OK',
      handler: function(){
        dialog.launchService()
      }
    }, {
      text: 'Cancel',
      handler: function(){
        dialog.doNotLaunchService()        
      }
    }]
  
    this.serviceSelectionGrid.getSelectionModel().on('rowselect', function(sm, rowIdx, r) {      
      dialog.descriptionPanel.tpl.overwrite(dialog.descriptionPanel.body, r.data);
    })
    this.serviceSelectionGrid.on('rowdblclick', function(grid, rowIdx){
      dialog.launchService()
    })    
    
    RG.Dialog.ServiceSelectDialog.superclass.initComponent.call(this)
  }, 
  handlerServicesLoaded: function() {
    if (this.autoSelectSingleResource=== true && this.serviceSelectionGrid.getStore().getCount()==1) {
      this.launchService(this.serviceSelectionGrid.getStore().getAt(0))      
    }
  },
  launchService: function(record) {
    var dialog= this
    record = record || this.serviceSelectionGrid.getSelectionModel().getSelected()
    if (!record) {
      return
    }  
    dialog.hide() 
    this.getServiceParameters(record)  
  },
  doNotLaunchService: function() {
    if (Ext.type(this.cb)== 'function') {             
      this.hide() 
      this.cb.call(this.scope, false)
    }
  },
  getServiceParameters: function(record){    
    var dialog= this    
    if (record.data.EditableParams > 0) {
      var serviceName = record.data.Name      
      record.getServiceXML(function(serviceXML){      
        if (serviceXML) {
          dialog.showServiceParameterDialog(record, serviceXML)
        } else {
          Ext.MessageBox.alert('Unable to load service', serviceName)
        }
      }, this, {
        entityTableKey: dialog.entityTableKey
      }) 
    } else {
      dialog.cb.call(dialog.scope, true, record)
    }
  },
  //Private  
  showServiceParameterDialog: function(serviceRecord, serviceXML) {     
    var paramDialog = new RG.Dialog.ServiceParameterDialog({
      title: serviceRecord.data.Name + " Parameters",
      serviceRecord: serviceRecord ,
      showResources: this.showResources,
      serviceXML: serviceXML,
      canSaveService: this.canSaveService,            
      entityTableKey: this.entityTableKey,   
      width: 740,
      handler: function(submit, formValues, form, args) {
        if (Ext.type(this.cb)== 'function') {             
          this.cb.call(this.scope, submit, serviceRecord, formValues, form, args)
        }
      },
      scope: this
    })
    paramDialog.show()
  },
  handleFilterChange: function(filterValue) {
    if (hasLength(filterValue)) {      
      this.serviceSelectionGrid.getStore().filter('Name', filterValue, true, false, false)
    } else {
      this.serviceSelectionGrid.getStore().clearFilter()
    }
  }  
})
