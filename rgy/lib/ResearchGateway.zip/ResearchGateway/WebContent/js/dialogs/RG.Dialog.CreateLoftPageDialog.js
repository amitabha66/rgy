/**
 * @author jemcdowe
 */
RG.Dialog.CreateLoftPageDialog= Ext.extend(RG.Dialog.AnimatedWindow, {
  layout: 'border',
  shadow: false,
  title: 'Create New App Page',
  iconCls: 'ix-v0-16-table_add',
  border: true,
  draggable: true,
  resizable: true,
  closable: true,
  header: true,
  constrain: true,
  closeAction: 'close',  
  initComponent: function(){
    var win= this
    
    this.formPanel= new Ext.form.FormPanel({
      region: 'north',
      height: 80,
      frame: true,
      labelWidth: 160,  
      padding :'20 0 20 0',
      items:[{
        xtype: 'textfield',
        width: 300,
        maxLength: 50,
        fieldLabel: 'Enter new page name',
        labelStyle: 'font-weight:bold;font-size:10pt',
        name: 'pageName',
        allowBlank:false,
        emptyText: 'page name'
      }]
    })
    
    this.appSelectorPanel= new Ext.grid.GridPanel({
      title: 'Select Apps to Initially Add To The New Page- You Can More Later',
      region: 'center',
      autoExpandColumn: 'name',
      disableSelection: false,
      hideHeaders: true,
      trackMouseOver: false,
      loadMask: true,      
      selModel: new Ext.grid.RowSelectionModel({
        // private
        handleMouseDown : function(g, rowIndex, e){
          if(e.button !== 0 || this.isLocked()){
            return;
          }
          var view = this.grid.getView();
          if(e.shiftKey && !this.singleSelect && this.last !== false){
            var last = this.last;
            this.selectRange(last, rowIndex, e.ctrlKey);
            this.last = last; // reset the last
            view.focusRow(rowIndex);
          }else{
            var isSelected = this.isSelected(rowIndex);
            if(isSelected){
              this.deselectRow(rowIndex);
            }else if(!isSelected){
              this.selectRow(rowIndex, true);
              view.focusRow(rowIndex);
            }
          }
        }
      }),
      nameCellTpl: new Ext.XTemplate(
        '<tpl for=".">',
        '<table>',
        '<tr>',
        '<td rowspan="2" style="width:32px;padding-right: 5px" valign= "top">',
        '<img src="/aig/img/s.gif" style="width:32px;height:32px;border:none" class="{[RG.Icon.Utils.getSizedIconClass(values.className, 32)]}"/>',
        '</td>',
        '<td unselectable="on"><b>{name}</b></td>',
        '</tr>',
        '<tr>',
        '<td unselectable="on">{description}</td>',
        '</tr>',        
        '</table>',
        '</tpl>'
        ),
      store: new Ext.data.Store({
        autoLoad :false,
        sortInfo: {
          field: 'order',
          direction: 'ASC'
        },       
        proxy : new Ext.data.MemoryProxy(),
        reader :new Ext.data.ArrayReader({}, 
          RG.Record.AppRecord)        
      }),
      columns: [{
        id:'name',
        header: "Name", 
        sortable: true, 
        dataIndex: 'name',
        renderer: function(value, metaData, record, rowIndex, colIndex, store) {
          return win.appSelectorPanel.nameCellTpl.apply(record.data)
        }
      }]
    })
 
    this.items = [{
      headerCfg1 : {
        tag : 'div',            
        cls : 'x-rg-appselector-grid-panel-header',            
        cn : [{
          tag : 'img',                
          cls : 'x-rg-appselector-grid-panel-header-icon ix-v0-32-table_add',                
          src : '/aig/img/s.gif'
        }, {
          tag : 'span',                
          cls : 'x-rg-appselector-grid-panel-header-text',                
          html : 'Create New App Page'
        }]
      },
      layout: 'border',
      region: 'center',
      border: false,
      items: [this.formPanel, this.appSelectorPanel]    
    }]
    
    
    this.buttons= [{
      text: 'OK',
      handler: function() {
        if (!win.formPanel.getForm().isValid()) {
          return
        }
        var pageName= win.formPanel.getForm().getValues().pageName
        var selectedAppRecords= win.appSelectorPanel.getSelectionModel().getSelections()
        if (Ext.isFunction(win.handler)) {
          win.handler.call(win.scope, pageName, selectedAppRecords)
        }
        win.close()
      }
    }, {
      text: 'Cancel',
      handler: function() {
        win.close()
      }
    }]
    
    RG.Dialog.CreateLoftPageDialog.superclass.initComponent.call(this)
    
    if (this.appRecords) {
      this.appSelectorPanel.getStore().add(this.appRecords)
    }
  }

})

