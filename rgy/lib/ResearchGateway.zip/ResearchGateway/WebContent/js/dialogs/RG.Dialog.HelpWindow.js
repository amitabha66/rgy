/**
 * Help documents and Suggestion Form Window
 * @author jemcdowe
 */
RG.Dialog.HelpWindow = Ext.extend(Ext.Window, {
  id: 'aig-help-window',
  title: 'Help',
  width: 500,
  height: 500,
  minWidth: 500,
  minHeight: 500,
  layout: 'border',
  bodyStyle: 'padding:5px;',
  closeAction: 'hide',
  buttonAlign: 'center',
  initComponent: function() {
    this.items= [{
      title: 'Research Gateway: ' + RG_BUILD,
      region: 'north',
      layout: "fit",
      height: 100,
      autoScroll: true,
      items: new Ext.DataView({
        tpl: new Ext.XTemplate('<table cellpadding="5" cellspacing="3"><tpl for=".">', '<TR>', 
          '<TD><img src="/aig/img/help.gif" align="middle" /></td>', 
          '<TD><div class="help-doc-item">', 
          '<a href="{href}"  target="_blank">{name}</a></h3></td></tr>', 
          '</div></tpl></table>'),
        store: new Ext.data.Store({
          autoLoad: true,
          url: '/aig/supportfiles.go',
          reader: new Ext.data.JsonReader({
            root: 'SupportFiles'
          }, Ext.data.Record.create([{
            name: 'name'
          }, {
            name: 'url'
          }, {
            name: 'usemht',
            type: 'boolean'
          }, {
            name: 'href',
            convert: function fullName(v, data){
              if (!Ext.isIE && data.usemht=== true) {
                return '/aig/supportfiles.go?name=' + data.name
              } else {
                return data.url
              }
            }
          }]))
        }),
        itemSelector: 'div.help-doc-item'
      })
    }, new Ext.form.FormPanel({
      id: 'aig-help-window-form',
      title: 'Submit a Question, Problem or Suggestion to Research Gateway Support',
      region: 'center',
      frame: true,
      labelWidth: 55,
      defaultType: 'textfield',
        
      items: [{
        fieldLabel: 'Subject',
        name: 'subject',
        allowBlank: false,
        value: 'Research Gateway',
        anchor: '100%' // anchor width by percentage
      }, {
        xtype: 'textarea',
        hideLabel: true,
        allowBlank: false,
        fieldLabel: 'Description',
        name: 'message',
        anchor: '100% -30' // anchor width by percentage and height by raw adjustment
      }]
    })]
    this.buttons= [{
      text: 'Send',
      scope: this,
      handler: function(){
        var form = Ext.getCmp('aig-help-window-form')
        var window = Ext.getCmp('aig-help-window')
        if (form.getForm().isValid()) {
          var values = form.getForm().getValues(true)
          window.hide()
          Ext.Ajax.request({
            url: "/aig/sendsupportmessage.go",
            params: values,
            success: function(response, options){
              showMessageDialog('Message Sent', 'Research Gateway Global Support')
            },
            failure: function(response){
            },
            scope: this
          })
        }            
      }        
    }, {
      text: 'Cancel',
      scope: this,
      handler: function(){
        Ext.getCmp('aig-help-window').hide()
      }
        
    }]
    this.on('show', function(win){
      win.items.get(1).getForm().clearInvalid()
    }
    )
    RG.Dialog.HelpWindow.superclass.initComponent.call(this)
  }
})
