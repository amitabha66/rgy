
RG.Dialog.CacheManager = Ext.extend(Ext.Window, {
  title: 'Research Gateway Cache Status',
  iconCls: 'ix-v0-16-data_refresh',
  width: 550,
  height: 400,
  layout: 'border',
  initComponent: function () {
	this.modal = true
	var me = this
	this.items = [this.statusGrid = new Ext.grid.GridPanel({
		region: 'center',
		viewConfig: {
		  forceFit: true
		},
		hideHeaders: true,
		disableSelection: true,
		store: new Ext.data.Store({
		  autoLoad: true,
		  url: '/aig/cachemgr.go',
		  reader: new Ext.data.JsonReader({
			root: "properties"
		  }, [{
			  name: 'property'
			}, {
			  name: 'value'
			}])
		}),
		autoExpandColumn: 'property',
		enableHdMenu: false,
		columns: [{
			id: 'property',
			header: 'Property',
			sortable: false,
			dataIndex: 'property'
		  }, {
			header: 'Value',
			sortable: false,
			dataIndex: 'value'
		  }]
	  })]
	this.buttonAlign = 'left'
	this.fbar = [{
		text: 'Refresh Cache',
		handler: function () {
		  Ext.MessageBox.show({
			title: 'Refreshing Cache',
			msg: 'This can take several minutes. Please wait...',
			progressText: 'Refreshing...',
			width: 300,
			wait: true,
			closable: true,
			waitConfig: {interval: 200},
			icon: 'ix-v0-32-data_replace'
		  });
		  Ext.Ajax.request({
			url: '/aig/cachemgr.go',
			params: {
			  req: 'REFRESH'
			},
			success: function (response, options) {
			  Ext.MessageBox.show({
				title: 'Research Gateway Cache',
				msg: 'Refresh Complete',
				width: 300,
				buttons: Ext.MessageBox.OK,
				icon: Ext.MessageBox.INFO
			  })
			  me.statusGrid.getStore().reload()
			},
			failure: function (response) {
			  Ext.MessageBox.show({
				title: 'Research Gateway Cache',
				msg: 'Refresh Failed',
				width: 300,
				buttons: Ext.MessageBox.OK,
				icon: Ext.MessageBox.ERROR
			  })
			  me.statusGrid.getStore().reload()
			},
			timeout: (15 * 1000 * 60),
			scope: this
		  })
		}}, {
		text: 'Refresh Service',
		handler: function () {
		  Ext.Msg.show({
			title: 'Refresh Service',
			msg: 'Please enter service key:',
			buttons: Ext.Msg.OKCANCEL,
			minWidth: 300,
			scope: this,
			prompt: true,
			multiline: 80,
			fn: function (btn, text) {
			  if (btn == 'ok') {
				Ext.Ajax.request({
				  url: '/aig/cachemgr.go',
				  params: {
					req: 'REFRESH_SERVICE',
					keys: text
				  },
				  success: function (response, options) {
					showInformationDialog('Refresh Service Complete', 'Research Gateway Cache')
				  },
				  failure: function (response) {
					Ext.MessageBox.show({
					  title: 'Research Gateway Cache',
					  msg: 'Refresh Service Failed',
					  width: 300,
					  buttons: Ext.MessageBox.OK,
					  icon: Ext.MessageBox.ERROR
					})
					me.statusGrid.getStore().reload()
				  },
				  timeout: (15 * 1000 * 60),
				  scope: this
				})
			  }
			}
		  })
		}}, {
		text: 'Cached-Disabled Services',
		handler: function () {
		  Ext.Ajax.request({
			url: '/aig/cachemgr.go',
			params: {
			  req: 'GET_NOCACHE_SERVICES'
			},
			success: function (response, options) {
			  var cachedDisabledServiceKeys = Ext.decode(response.responseText).keys

			  Ext.Msg.show({
				title: 'Cached-Disabled Services',
				msg: 'Please enter service keys to disable service caching:',
				buttons: Ext.Msg.OKCANCEL,
				minWidth: 300,
				scope: this,
				prompt: true,
				multiline: 80,
				value: (cachedDisabledServiceKeys.join('\n')),
				fn: function (btn, text) {
				  if (btn == 'ok') {
					Ext.Ajax.request({
					  url: '/aig/cachemgr.go',
					  params: {
						req: 'SET_NOCACHE_SERVICES',
						keys: text
					  },
					  success: function (response, options) {
						showInformationDialog('Cached-Disabled Services Updated', 'Research Gateway Cache')
					  },
					  failure: function (response) {
						Ext.MessageBox.show({
						  title: 'Research Gateway Cache',
						  msg: 'Cached-Disabled Services Update Failed',
						  width: 300,
						  buttons: Ext.MessageBox.OK,
						  icon: Ext.MessageBox.ERROR
						})
						me.statusGrid.getStore().reload()
					  },
					  timeout: (15 * 1000 * 60),
					  scope: this
					})
				  }
				}
			  })
			},
			failure: function (response) {
			  Ext.MessageBox.show({
				title: 'Research Gateway Cache',
				msg: 'Lookup Cache-Disabled Services Failed',
				width: 300,
				buttons: Ext.MessageBox.OK,
				icon: Ext.MessageBox.ERROR
			  })
			},
			scope: this
		  })


		}}, {
		text: 'Disable All Caching',
		handler: function () {
		  Ext.Ajax.request({
			url: '/aig/cachemgr.go',
			params: {
			  req: 'GET_NOCACHING'
			},
			success: function (response, options) {
			  var cacheDisabled = Ext.decode(response.responseText).caching_disabled

			  Ext.Msg.show({
				title: 'Disable All Caching',
				msg: 'Caching is currently ' + (cacheDisabled ? 'DISABLED' : 'ENABLED') + '.<br/>Disable all caching?',
				buttons: Ext.Msg.YESNOCANCEL,
				icon: Ext.Msg.QUESTION,
				minWidth: 300,
				scope: this,
				fn: function (btn) {
				  if (btn != 'cancel') {
					Ext.Ajax.request({
					  url: '/aig/cachemgr.go',
					  params: {
						req: 'SET_NOCACHING',
						caching_disabled: btn
					  },
					  success: function (response, options) {
                        cacheDisabled = Ext.decode(response.responseText).caching_disabled						
						showInformationDialog('Cache ' + (cacheDisabled ? 'DISABLED' : 'ENABLED'), 'Research Gateway Cache')
					  },
					  failure: function (response) {
						Ext.MessageBox.show({
						  title: 'Research Gateway Cache',
						  msg: 'Disable Cache Update Failed',
						  width: 300,
						  buttons: Ext.MessageBox.OK,
						  icon: Ext.MessageBox.ERROR
						})
						me.statusGrid.getStore().reload()
					  },
					  timeout: (15 * 1000 * 60),
					  scope: this
					})
				  }
				}
			  })
			},
			failure: function (response) {
			  Ext.MessageBox.show({
				title: 'Research Gateway Cache',
				msg: 'Disable Cache Update Failed',
				width: 300,
				buttons: Ext.MessageBox.OK,
				icon: Ext.MessageBox.ERROR
			  })
			},
			scope: this
		  })


		}}, '->', {
		text: 'Close',
		handler: function () {
		  me.close()
		}
	  }]
	RG.Dialog.CacheManager.superclass.initComponent.call(this);
  }
});
