/**
 * @author jemcdowe
 */
AIG.UserPreferencesUi = Ext.extend(RG.Dialog.AnimatedWindow, {
  id: 'aig_preferences-dialog',
  title :'Research Gateway Preferences',
  layout :'border',
  shadow: false,
  height :500,
  width :525,
  iconCls :'rg_preferences_icon',
  modal :true,
  updateCount :0,
  initComponent : function() {
    var vp = this
    vp.prefGroupNode = new Ext.tree.AsyncTreeNode({
      text :'Preferences',
      iconCls :'user_prefs',
      expanded :true,
      leaf :false
    })
    var prefPanelColModel = new Ext.grid.ColumnModel([{
      header :"Name",
      dataIndex :'name',
      width :120,
      sortable :false,
      editable :false
    }, {
      header :"Value",
      id :'value',
      dataIndex :'value',
      sortable :false,
      editable :true,
      renderer: function(value, md, record) {        
        if (record.data.hasLabel) {
          return record.data.label
        } else if (record.data.type== 'COLOR') {   
          var baseColor= record.data.value || 'FFFFFF'
          if (!/^#/.test(baseColor)) {
            baseColor= '#' + baseColor
          }
          md.attr= 'style="background-color:' + baseColor +';color:'+AIG.getContrastColor(baseColor.substr(1)) +'"'
          return '<I><B>Click to Edit</B></I>'
        }
        return value
      }
    }])
    prefPanelColModel.getCellEditor = vp.getPreferenceEditor.createDelegate(vp, null, true)

    var PrefPanelUi = Ext.extend(Ext.grid.EditorGridPanel, {
      initComponent : function() {
        var grid = this
        this.store = propertyStore = new Ext.data.Store({
          autoLoad :false,
          url :'/aig/userprefs.go',
          reader :new Ext.data.JsonReader({
            root :"preferences",
            id :'id'
          }, [{
            name :'name'
          }, {
            name :'desc'
          }, {
            name :'group_id'
          }, {
            name :'group_name'
          }, {
            name :'value'
          }, {
            name :'label'
          }, {
            name :'hasLabel',
            type: 'boolean',
            defaultValue: false
          }, {
            name :'type'
          }, {
            name :'extfield_config'
          }, {
            name :'options'
          }])
        })
        this.store.on('update', function(store, record, operation) {
          vp.setButtonsDisabled(false)
        })
        this.cm = prefPanelColModel
        this.autoExpandColumn = 'value'
        this.enableHdMenu = false
        this.enableColumnMove = false
        this.clicksToEdit = 1
        PrefPanelUi.superclass.initComponent.call(this);
      }
    })

    this.propertiesPanel = new PrefPanelUi({
      region :'center',
      title :'Preferences'
    })
    this.propertyDescPanel = new Ext.Panel({
      region :'south',
      frame :true,
      split :true,
      autoScroll :true,
      height :100
    })
    this.propertiesPanel.getSelectionModel().on('selectionchange', function(model, selection) {
      var html = ""
      if (selection && selection.record) {
        var record = selection.record
        html = String.format('<h2><b><h2><u>{0}</u></h2></b><br/>{1}</h2>', record.data.name, record.data.desc)
      }
      if (!vp.prefDescEl) {
        vp.propertyDescPanel.body.update('').addClass('x-panel-mc');
        vp.prefDescEl = vp.propertyDescPanel.body.createChild();
      }
      vp.prefDescEl.hide().update(html).slideIn('l', {
        stopFx :true,
        duration :.2
      });
    })

    this.propertiesGroupTreeView = new Ext.tree.TreePanel({
      title :'Preferences',
      width :150,
      autoScroll :true,
      animate :true,
      containerScroll :true,
      root :vp.prefGroupNode,
      rootVisible :false,
      region :'west',
      split :true,
      loader :new Ext.tree.TreeLoader({
        url :'/aig/userprefs.go',
        createNode : function(attr) {
          attr.iconCls = 'rg_preferences_group'
          return Ext.tree.TreeLoader.prototype.createNode.call(this, attr);
        }
      }),
      listeners :{
        click : function(node) {
          vp.loadPreferenceGroup({
            node :node
          })
        }
      }
    })

    var mainPanel = new Ext.Panel({
      xtype :'panel',
      items :[vp.propertiesGroupTreeView, {
        region :'center',
        layout :'border',
        items :[this.propertiesPanel, this.propertyDescPanel]
      }],
      border :false,
      region :'center',
      layout :'border'
    })

    this.items = mainPanel

    this.on('render', function(vp) {
      if (Ext.type(vp.selectedGroup) == 'string') {
        vp.propertiesGroupTreeView.root.on('load', function() {
          var groupNode = vp.propertiesGroupTreeView.root.findChild('text', vp.selectedGroup)
          if (groupNode) {
            vp.propertiesGroupTreeView.selectPath(groupNode.getPath(), null, vp.loadPreferenceGroup.createDelegate(vp, [{
              node :groupNode
            }]))
          }
        })
      }
    })
    this.buttons = [{
      text :'OK',
      disabled :true,
      handler : function() {
        vp.savePreferences( function(values) {
          vp.close()
          if (Ext.type(vp.handler) == 'function') {
            vp.handler.call(vp.scope, {
              values :values,
              updated :vp.updateCount,
              operation :'ok'
            })
          }
        })
      }
    }, {
      text :'Cancel',
      handler : function() {
        vp.close()
      }
    }, {
      text :'Restore Defaults',
      disabled :true,
      handler : function() {
        vp.resetPreferenceGroup( function(values) {
          this.loadPreferenceGroup()
          if (Ext.type(this.handler) == 'function') {
            this.handler.call(this.scope, {
              values :values,
              updated :vp.updateCount,
              operation :'reset'
            })
          }
        })
      },
      scope :vp
    }, {
      text :'Apply',
      disabled :true,
      handler : function() {
        vp.savePreferences( function(values) {
          this.loadPreferenceGroup()
          if (Ext.type(vp.handler) == 'function') {
            vp.handler.call(vp.scope, {
              values :values,
              updated :vp.updateCount,
              operation :'apply'
            })
          }
        })
      }
    }]
    AIG.UserPreferencesUi.superclass.initComponent.call(this);
  },
  loadPreferenceGroup : function(source) {
    var node = null
    if (Ext.type(source) == 'object') {
      node = source.node
    } else {
      node = this.propertiesGroupTreeView.getSelectionModel().getSelectedNode()
    }
    var groupID = (node ? node.id : null)
    if (!groupID) {
      return
    }
    this.propertiesPanel.store.load({
      params :{
        id :groupID
      },
      callback : function() {
        this.groupID = groupID
        this.setButtonsDisabled(true)
      },
      scope :this
    })
    this.propertiesPanel.setTitle(node.text + ' Preferences')
  },
  setButtonsDisabled : function(disabled) {
    var okButton = this.buttons[0]
    var resetButton = this.buttons[2]
    var applyButton = this.buttons[3]
    okButton.setDisabled(disabled)
    resetButton.setDisabled((this.groupID == null))
    applyButton.setDisabled(disabled)
  },
  getPreferenceEditor : function(colIndex, rowIndex) {
    var record = this.propertiesPanel.store.getAt(rowIndex)
    var type = record.data.type
    var options = record.data.options
    var extConfig = record.data.extfield_config
    var fieldConfig = ""
    try {
      fieldConfig= Ext.util.JSON.decode(extConfig)
    } catch(e) {}
    
    var grid = this.propertiesPanel
    var editorConfig= {}
    
    if (fieldConfig.xtype== 'backgroundimagefield') {      
      return new Ext.grid.GridEditor(new Ext.form.ComboBox({
        typeAhead :true,
        mode :'local',
        triggerAction :'all',
        forceSelection :true,
        editable :false,
        store :options,
        tpl: new Ext.XTemplate('<tpl for=".">', '<div class="x-combo-list-item">', 
          '<tpl if="xindex== 1">',
          '<img src="/aig/img/s.gif" width="24" align="absmiddle" border=0 style="margin-right:3px">{field1}</div>', 
          '</tpl>',
          '<tpl if="xindex!= 1">',
          '<img src="/aig/userprefs.go?op=img_thumb&name={[escape(values.field1)]}" align="absmiddle" border=0 style="margin-right:3px">{field1}</div>', 
          '</tpl>',
          '</tpl>'),
        grid :this.propertiesPanel,        
        listeners :{
          select : function(combo) {
            combo.grid.stopEditing(false)
          }
        }
      }))
    }
    
    if (Ext.type(options) == 'array') {
      return new Ext.grid.GridEditor(new Ext.form.ComboBox({
        typeAhead :true,
        mode :'local',
        triggerAction :'all',
        forceSelection :true,
        editable :false,
        store :options,
        grid :this.propertiesPanel,
        listeners :{
          select : function(combo) {
            combo.grid.stopEditing(false)
          }
        }
      }))
    }
    if (!this.propertiesPanel.prefEditors) {
      this.propertiesPanel.prefEditors = {}
    }
    if (this.propertiesPanel.prefEditors[type] == null) {
      extConfig.selectOnFocus = true

      switch (fieldConfig.xtype) {
        case 'numberfield' :
          if (Ext.type(options) == 'object') {
            fieldConfig.minValue = options.minValue
            fieldConfig.maxValue = options.maxValue
          }
          break;
        case 'uxspinner' :
          if (type == 'XINTEGER') {
            fieldConfig.strategy = {
              xtype :'number',
              incrementValue :1
            }
            if (Ext.type(options) == 'object') {
              fieldConfig.strategy.minValue = options.minValue
              fieldConfig.strategy.maxValue = options.maxValue
            }
          }
          break
        case 'colorpickerfield':
          fieldConfig.showHexValue= false
          fieldConfig.grid= this.propertiesPanel
          fieldConfig.hideHtmlCode= true
          fieldConfig.listeners={
            select : function(field) {
              field.grid.stopEditing(false)
            }
          }
          editorConfig.allowBlur= false				
          break
      }
      var field = Ext.ComponentMgr.create(fieldConfig, 'field')
      this.propertiesPanel.prefEditors[type] = new Ext.grid.GridEditor(field, editorConfig)
    }
        
    return this.propertiesPanel.prefEditors[type]
  },
  getPreferenceValues : function() {
    var modRecords = this.propertiesPanel.store.getModifiedRecords()
    var updatedPreferences = []
    for ( var i = 0; i < modRecords.length; i++) {
      var modRecord = modRecords[i]
      updatedPreferences.push({
        preference_id :modRecord.id,
        name :modRecord.data.name,
        group_id :modRecord.data.group_id,
        group_name :modRecord.data.group_name,
        value :modRecord.data.value
      })
    }
    return updatedPreferences
  },
  savePreferences : function(cb) {
    var updatedPreferences = this.getPreferenceValues()
    if (Ext.type(updatedPreferences) == 'array' && updatedPreferences.length > 0) {
      Ext.Ajax.request({
        url :'/aig/userprefs.go',
        params :{
          op :'save',
          preferences :Ext.util.JSON.encode(updatedPreferences)
        },
        success : function(response, options) {
          var results = Ext.util.JSON.decode(response.responseText)
          this.updateCount += results.updates
          if (Ext.type(cb) == 'function') {
            cb.call(this, updatedPreferences)
          }
          AIG.reopenLaunchPad(true)
        },
        failure : function(response) {
          Ext.MessageBox.show({
            title :'Problem Updating Preferences',
            msg :'Unable to update preferences.\n' + response.responseText,
            buttons :Ext.MessageBox.OK,
            icon :Ext.MessageBox.ERROR
          })
          if (Ext.type(cb) == 'function') {
            cb.call(this)
          }
        },
        scope :this
      })
    }
  },
  resetPreferenceGroup : function(cb) {
    if (this.groupID) {
      Ext.Ajax.request({
        url :'/aig/userprefs.go',
        params :{
          op :'reset',
          id :this.groupID
        },
        success : function(response, options) {
          var results = Ext.util.JSON.decode(response.responseText)
          this.updateCount += results.updates
          if (Ext.type(cb) == 'function') {
            cb.call(this)
          }
          AIG.reopenLaunchPad(true)
        },
        failure : function(response) {
          Ext.MessageBox.show({
            title :'Problem Updating Preferences',
            msg :'Unable to update preferences.\n' + response.responseText,
            buttons :Ext.MessageBox.OK,
            icon :Ext.MessageBox.ERROR
          })
          if (Ext.type(cb) == 'function') {
            cb.call(this)
          }
        },
        scope :this
      })
    }
  }
});
