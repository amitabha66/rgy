/**
 * A Dialog for selecting users based on ActiveDirectory
 * @author jemcdowe
 */
RG.Dialog.UserSelector = Ext.extend(RG.Dialog.AnimatedWindow, {
  width: 600,
  height: 300,
  layout: 'border',
  title: 'Select Users',
  modal: true,
  initComponent: function(){
    var win = this
    Ext.applyIf(this, {
      includeGroups: true,
      singleSelect: false,
      separator: ','
    })
    var selectModel = new Ext.grid.CheckboxSelectionModel({
      singleSelect: win.singleSelect
    })
    selectModel.selectRow = function(index, keepExisting, preventViewNotify){
      Ext.grid.CheckboxSelectionModel.superclass.selectRow.call(this, index, true, preventViewNotify)
    }
        
    this.items = [(this.grid= new Ext.grid.GridPanel({
      xtype: 'grid',
      loadMask: true,
      region: 'center',
      enableColumnMove: false,
      enableColumnHide: false,
      enableDragDrop: false,
      enableHdMenu: false,
      disableExportMenu: true,
      viewConfig: {
        forceFit: true
      },
      sm: selectModel,
      store: new Ext.data.Store({
        reader: new Ext.data.ArrayReader({}, 
          RG.Record.UserRecord),
        data: []
      }),
      columns: [selectModel, {
        header: '',
        sortable: true,
        resizable: true,
        width: 16,
        dataIndex: 'obj_class',
        renderer: function(value, md){
          if (value == 'group') {
            md.attr = "style='background:url(/aig/img/usergroup.png ) no-repeat center center !important'"
          }
          return ""
        }
      }, {
        header: 'Name',
        sortable: true,
        resizable: true,
        width: 150,
        dataIndex: 'name'
      }, {
        header: 'Cost Center',
        sortable: true,
        resizable: true,
        width: 150,
        dataIndex: 'costcenter'
      }, {
        header: 'Title',
        sortable: true,
        resizable: true,
        width: 150,
        dataIndex: 'title'
      }],
      listeners: {
        render: function(grid){
          grid.loadMask = new Ext.LoadMask(grid.bwrap);
          if (win.usernames || win.query) {
            new Ext.util.DelayedTask().delay(20, function(){
              if (Ext.type(win.usernames) == 'array' && win.usernames.length > 0) {
                win.queryForUsers(null, win.usernames, win.select_usernames)
              } else if (Ext.type(win.usernames) == 'string' && win.usernames.length > 0) {
                win.queryForUsers(null, win.usernames.split(win.separator), true)
              } else if (Ext.type(win.query) == 'string') {
                win.queryForUsers(win.query, null, false)
              }
            })
          }
        },
        rowclick: function(grid){
          grid.ownerCt.updateMessage()
        },
        rowdblclick: function(grid, rowIndex, evt){
          var record = grid.getStore().getAt(rowIndex)
          if (record.data.obj_class == 'group') {
            win.showGroupMembers(record)
          } else if (record.data.obj_class == 'person') {
            win.showUserInformation(record)
          }
        },
        cellcontextmenu: function(grid, rowIndex, columnIndex, evt){
          if (evt.hasModifier()) {
            return
          }
          evt.preventDefault()
          evt.stopPropagation()
          if (!grid.menu) {
            grid.menu = new Ext.menu.Menu({
              items: [{
                text: 'Show Members',
                icon: '/aig/img/usergroup_small.png',
                handler: function(){
                  win.showGroupMembers(grid.menu.record)
                },
                scope: this
              }],
              listeners: {
                beforeshow: function(menu){
                  var item = menu.findMenuItemByText('Show Members')
                  item.setDisabled(menu.record.data.obj_class!= 'group')                  
                }
              }
            })
            var record = grid.getStore().getAt(rowIndex)
            var fieldName = grid.getColumnModel().getDataIndex(columnIndex)
            var data = record.get(fieldName)
            grid.menu.record = record
            grid.menu.fieldName = fieldName
            grid.menu.data = data
          }
          grid.menu.showAt(evt.getXY())
        }
      }
    }))];
    this.tbar = new Ext.Toolbar({
      items: [new RG.Dialog.UserSelectorSearchField({
        onTrigger1Click: function(){
          win.clear(true)
        },
        onTrigger2Click: function(){
          var query = this.getRawValue();
          if (query.length < 1) {
            return;
          }
          win.queryForUsers(query)
        }
      })],
      listeners: {
        render: function(tb){
          tb.displayEl = Ext.fly(tb.el.dom).createChild({
            cls: 'x-paging-info'
          })  
        }
      }
    })
        
    this.buttonAlign = 'right'
    this.buttons = [{
      text: 'OK',
      handler: function(){
        if (Ext.type(win.handler) == 'function') {
          var grid = win.grid
          var selections = grid.getSelectionModel().getSelections()
          win.handler.call(win.scope, selections, grid)
        }
        win.close()
      }
    }, {
      text: 'Cancel',
      handler: function(){
        win.close()
      }
    }]
  
    this.on('render', function(win) {
      win.focusQueryTextField.defer(1000, win)
    })
    RG.Dialog.UserSelector.superclass.initComponent.call(this);
  },
  /**
   * Return current selections
   */
  getSelectedRecords: function() {
    return this.grid.getSelectionModel().getSelections()
  },
  /**
   * Update the toolbar message
   */
  updateMessage: function(){
    var grid = this.grid
    if (this.getTopToolbar().displayEl) {
      var format = "{0} Users(s), {1} Selected"
      var count = grid.store.getCount();
      this.getTopToolbar().displayEl.update(String.format(format, count, grid.getSelectionModel().getCount()));
    }
  },
  /**
   * Performs the search
   */
  queryForUsers: function(query, lookupUsernames, selectNewUsers){
    var grid = this.grid
    if (grid.isLoading) {
      return
    }
    var store = grid.store
    var previousSelections = grid.getSelectionModel().getSelections()
    var records = [].concat(previousSelections)
    var usernames = {}
    for (var i = 0; i < previousSelections.length; i++) {
      usernames[previousSelections[i].get('username')] = previousSelections[i]
    }
    if (grid.loadMask) {
      grid.loadMask.show()
    }
    
    Ext.Ajax.request({
      url: "/aig/personquery.go",
      success: function(response){
        grid.loadMask.hide()
        var resultUsers = null
        try {
          resultUsers = Ext.util.JSON.decode(response.responseText).names
          var newRecords = []
          for (var i = 0; i < resultUsers.length; i++) {
            if (usernames[resultUsers[i].username] == null) {
              newRecords.push(new RG.Record.UserRecord({
                name: resultUsers[i].name,
                title: resultUsers[i].title,
                costcenter: resultUsers[i].costcenter,
                location: resultUsers[i].location,
                bldg: resultUsers[i].bldg,
                phone: resultUsers[i].phone,
                manager: resultUsers[i].manager,
                manager_username: resultUsers[i].manager_username,
                obj_class: resultUsers[i].obj_class,
                username: resultUsers[i].username,
                employee_id: resultUsers[i].employee_id
              }))
            }
          }
          records = records.concat(newRecords)
          store.removeAll()
          store.add(records)
          grid.getSelectionModel().selectRecords(previousSelections)
          if (selectNewUsers) {
            grid.getSelectionModel().selectRecords(newRecords)
          }
          this.updateMessage()
        } catch (e) {
        }
        grid.isLoading = false
      },
      failure: function(){
        grid.loadMask.hide()
        grid.isLoading = false
        AIG.showErrorMessage('Unable to search users.', 'Search Users')
      },
      scope: this,
      params: {
        query: query,
        includeGroups: (this.includeGroups=== false ? "N" : "Y"),
        username: (Ext.type(lookupUsernames) == 'array' ? lookupUsernames.join(",") : null)
      }
    })
  },
  /**
   * Clears the grid optionally keeping the current selected records
   */
  clear: function(keepSelected){
    var grid = this.grid
    var store = grid.store
    var selections = grid.getSelectionModel().getSelections()
    store.removeAll()
    if (keepSelected) {
      store.add(selections)
      grid.getSelectionModel().selectRecords(selections)
    }
    this.updateMessage()
  },
  /**
   * Opens the Group member viewer for the given record
   */  
  showGroupMembers: function(record){
    new RG.Dialog.GroupMemberUi({
      group_username: record.data.username,
      group_name: record.data.name,
      parentWin: this
    }).show()        
  },
  /**
   * Opens the user viewer for the given record
   */  
  showUserInformation: function(record){
    var username = (Ext.type(record) == 'string' ? record : record.data.username)
    if (Ext.type(username) == 'string') {
      new RG.Dialog.UserInformationUi({
        username: username,
        parentWin: this
      }).show()
    }
  },
  /**
   * Opens the staff directory for the given record  
   */ 
  openStaffDirectory: function(record){
    var empID = (Ext.type(record) == 'string' ? record : record.data.employee_id)
    if (Ext.type(empID) == 'string') {
      var url = "http://corewww.amgen.com/StaffDirectory/Staff_Info.asp?Emp_Id=" + empID
      window.open(url, '_blank')
    }
  },
  focusQueryTextField: function() {
    this.getTopToolbar().items.get(0).wrap.first('.x-form-text').dom.focus()
  }
    
})

/** 
 * Extends the TwinTriggerField for use in the toolbar
 */
RG.Dialog.UserSelectorSearchField = Ext.extend(Ext.form.TwinTriggerField, {
  initComponent: function(){
    RG.Dialog.UserSelectorSearchField.superclass.initComponent.call(this);
    this.on('specialkey', function(f, e){
      if (e.getKey() == e.ENTER) {
        this.onTrigger2Click();
      }
    }, this);
  },
  validationEvent: false,
  validateOnBlur: false,
  trigger1Class: 'x-form-clear-trigger',
  trigger2Class: 'x-form-search-trigger',
  hideTrigger1: false,
  width: 180,
  hasSearch: false,
  paramName: 'query'
});

/**
 * Windows for displaying Group Members
 */
RG.Dialog.GroupMemberUi = Ext.extend(Ext.Window, {
  width: 365,
  height: 364,
  layout: 'border',
  initComponent: function(){
    var win = this
    this.title = this.group_name + ' Members'
    this.items = {
      region: 'center',
      xtype: 'grid',
      autoScroll: true,
      hideHeaders: true,
      loadMask: true,
      store: new Ext.data.Store({
        url: '/aig/personquery.go',
        autoLoad: true,
        baseParams: {
          group_username: win.group_username
        },
        reader: new Ext.data.JsonReader({
          root: "members"
        }, RG.Record.UserRecord)
      }),
      columns: [{
        header: "Member",
        dataIndex: 'name'
      }],
      listeners: {
        rowdblclick: function(grid, rowIndex){
          var record = grid.getStore().getAt(rowIndex)
          if (record.data.obj_class == 'person') {
            win.parentWin.showUserInformation(record.data.username)
          }
        }
      },
      viewConfig: {
        forceFit: true
      }
    }
        
    this.buttons = [{
      text: 'Close',
      handler: function(){
        win.close()
      }
    }]
        
    RG.Dialog.GroupMemberUi.superclass.initComponent.call(this);
  }
});
/**
 * Window to display user information
 */
RG.Dialog.UserInformationUi = Ext.extend(Ext.Window, {
  title: 'Information',
  width: 582,
  height: 468,
  layout: 'border',
  initComponent: function(){
    var win = this
        
    this.photoField = new Ext.Panel({
      fieldLabel: 'Photo',
      anchor: '100%',
      fieldClass: "x-form-field",
      isFormField: true,
      style: 'cursor: pointer; cursor: hand; text-decoration: underline;',
      items: {
        xtype: 'box',
        width: 100,
        height: 100,
        autoEl: {
          tag: 'img',
          width: 100,
          height: 100,
          src: Ext.BLANK_IMAGE_URL
        }
      },
      getName: function(){
        return ''
      }
    })
    this.nameTextField = new Ext.form.TextField({
      xtype: 'textfield',
      name: 'name',
      fieldLabel: 'Name',
      anchor: '100%',
      readOnly: true,
      style: 'cursor: pointer; cursor: hand; text-decoration: underline'
    })
    this.managerTextField = new Ext.form.TextField({
      name: 'manager',
      fieldLabel: 'Manager',
      anchor: '100%',
      readOnly: true,
      style: 'cursor: pointer; cursor: hand; text-decoration: underline'
    })
        
        
    this.items = [{
      xtype: 'form',
      region: 'center',
      frame: true,
      items: [this.photoField, this.nameTextField, {
        xtype: 'textfield',
        name: 'title',
        fieldLabel: 'Title',
        anchor: '100%',
        readOnly: true
      }, {
        xtype: 'textfield',
        name: 'costcenter',
        fieldLabel: 'Cost Center',
        anchor: '100%',
        readOnly: true
      }, {
        xtype: 'textfield',
        name: 'location',
        fieldLabel: 'Location',
        anchor: '100%',
        readOnly: true
      }, {
        xtype: 'textfield',
        name: 'bldg',
        fieldLabel: 'Bldg/Room',
        anchor: '100%',
        readOnly: true
      }, {
        xtype: 'textfield',
        name: 'phone',
        fieldLabel: 'Phone',
        anchor: '100%',
        readOnly: true
      }, this.managerTextField, {
        xtype: 'grid',
        width: 100,
        border: true,
        style: "border:1px solid #B5B8C8",
        isFormField: true,
        store: new Ext.data.Store({
          autoLoad: true,
          proxy: new Ext.data.MemoryProxy([]),
          reader: new Ext.data.JsonReader({
            root: "reports"
          }, RG.Record.UserRecord)
        }),
        getName: function(){
          return 'reports'
        },
        setValue: function(value){
          if (Ext.type(value) == 'array') {
            this.getStore().loadData({
              reports: value
            })
          } else {
            this.getStore().loadData({
              reports: []
            })
          }
        },
        fieldLabel: 'Reports',
        anchor: '100%',
        hideHeaders: true,
        height: 100,
        autoExpandColumn: 'name',
        columns: [{
          xtype: 'gridcolumn',
          header: 'Column',
          sortable: true,
          width: 100,
          id: 'name',
          dataIndex: 'name',
          renderer: function(value, md){
            md.attr = 'style= "cursor: pointer; cursor: hand; text-decoration: underline"'
            return value
          }
        }],
        listeners: {
          rowclick: function(grid, rowIndex){
            var record = grid.getStore().getAt(rowIndex)
            win.parentWin.showUserInformation(record)
          }
        }
      }]
    }];
        
    this.buttons = [{
      text: 'Close',
      handler: function(){
        win.close()
      }
    }]
        
    this.on('render', function(win){
      if (win.username) {
        new Ext.util.DelayedTask().delay(5, function(){
          var form = win.items.get(0)
          form.getEl().mask('Loading...', 'x-mask-loading')
          Ext.Ajax.request({
            url: '/aig/personquery.go',
            params: {
              username: win.username,
              extended_information: 'y',
              includeGroups: (this.includeGroups=== false ? "N" : "Y")
            },
            success: function(response, options){
              form.getEl().unmask()
              var data = null
              try {
                data = Ext.util.JSON.decode(response.responseText)
              } catch (e) {
              }
              win.user_record = null
              if (data != null && Ext.type(data.names) == 'array' && data.names.length > 0) {
                win.user_record = new RG.Record.UserRecord({
                  name: data.names[0].name,
                  title: data.names[0].title,
                  costcenter: data.names[0].costcenter,
                  location: data.names[0].location,
                  bldg: data.names[0].bldg,
                  phone: data.names[0].phone,
                  manager: data.names[0].manager,
                  manager_username: data.names[0].manager_username,
                  obj_class: data.names[0].obj_class,
                  username: data.names[0].username,
                  employee_id: data.names[0].employee_id,
                  reports: data.names[0].reports
                })
              }
                            
              if (win.user_record) {
                form.getForm().loadRecord(win.user_record)
                win.photoField.items.get(0).el.dom.src = "http://corewww.amgen.com/image/default.asp?staff_id=" + data.names[0].employee_id
                win.setTitle(win.user_record.data.name + ' - Information')
              }
            },
            failure: function(response, options){
              form.getEl().unmask()
            },
            scope: this
          })
                    
          win.managerTextField.getEl().on('click', function(evt, el){
            evt.preventDefault()
            evt.stopEvent()
            evt.stopPropagation()
            win.managerTextField.selectText(0, 0)
            win.parentWin.showUserInformation(win.user_record.data.manager_username)
          })
          win.photoField.getEl().on('click', function(evt, el){
            evt.preventDefault()
            evt.stopEvent()
            evt.stopPropagation()
            win.nameTextField.selectText(0, 0)
            win.parentWin.openStaffDirectory(win.user_record)
          })
          win.nameTextField.getEl().on('click', function(evt, el){
            evt.preventDefault()
            evt.stopEvent()
            evt.stopPropagation()
            win.nameTextField.selectText(0, 0)
            win.parentWin.openStaffDirectory(win.user_record)
          })
        })
      }
    })
    RG.Dialog.UserInformationUi.superclass.initComponent.call(this);
  }
});

