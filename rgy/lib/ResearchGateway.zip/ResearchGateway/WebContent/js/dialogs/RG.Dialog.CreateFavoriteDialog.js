/**
 * @author jemcdowe
 */
/**
 * Creates a new favorite
 * @param {Object} config {
 * name: default name of the favorite
 * description: default description of the favorite
 * type: type of favorite (LIST, ENTITY TABLE, PROJECT VIEW)
 * key: key (type identifier) of favorite
 *
 */
RG.Favorites.createFavorite= function(config){
  new RG.Dialog.CreateFavoriteDialog(config).show()
}

RG.Dialog.CreateFavoriteDialog = Ext.extend(Ext.Window, {
  title: 'Create Favorite',
  iconCls: 'ix-v0-16-star_yellow',
  width: 400,
  height: 230,
  layout: 'border',
  initComponent: function(){
    this.modal = true
    var win = this
    this.items = [{
      xtype: 'form',
      region: 'center',
      frame: true,
      items: [{
        xtype: 'textfield',
        fieldLabel: 'Name',
        value: win.name,
        anchor: '100%',
        name: 'name',
        blankText: 'Name for saved table is required',
        allowBlank: false
      }, {
        xtype: 'textarea',
        anchor: '100%',
        fieldLabel: 'Description',
        value: win.description,
        name: 'desc'
      }, {
        xtype: 'trigger',
        fieldLabel: 'Folder',
        anchor: '100%',
        triggerClass: 'x-form-search-trigger',
        name: 'folder',
        defaultAutoCreate: {
          tag: "input",
          type: "text",
          size: "16",
          autocomplete: "off",
          contenteditable: false
        },
        onTriggerClick: function(){
          new AIG.Favorites.FavoriteFolderSelectorDialog({
            title: 'Favorite Folders',
            path: this.pathIDs,
            handler: function(folderInfo){
              this.folderID = folderInfo.folder_id
              this.pathIDs = folderInfo.path_ids
              this.setValue(folderInfo.path)
            },
            scope: this
          }).show()                    
        }
      }, {
        xtype: 'trigger',
        fieldLabel: 'Share With',
        anchor: '100%',
        triggerClass: 'x-form-search-trigger',
        name: 'share',
        defaultAutoCreate: {
          tag: "input",
          type: "text",
          size: "16",
          autocomplete: "off",
          contenteditable: false
        },
        onTriggerClick: function(){
          new RG.Dialog.UserSelector({
            title: 'Share With..',
            usernames: this.shareWith,
            select_usernames: true,
            handler: function(users){
              users = users ||
              []
              var usernames = []
              var display = []
              for (var i = 0; i < users.length; i++) {
                usernames.push(users[i].data.username)
                display.push(users[i].data.name)
              }
              this.shareWith = usernames
              this.setValue(display.join(";"))
            },
            scope: this
          }).show()
                    
        }
      }]
    }];
    this.buttonAlign = 'right'
    this.buttons = [{
      text: 'OK',
      handler: function(){
        var form = win.items.get(0)
        var values = form.getForm().getValues(false);
        var shareEl = form.find('name', 'share')[0]
        var folderEl = form.find('name', 'folder')[0]
                
        if (!form.getForm().isValid()) {
          return
        }
                
        var createFavoriteParams = {
          op: 'CREATE',
          favorite_type: win.type,
          key: win.key,
          name: values.name,
          description: values.desc,
          folderID: folderEl.folderID,
          shareWith: shareEl.shareWith,
          serviceParams: (Ext.isObject(win.serviceParams) ? Ext.encode(win.serviceParams) : null)
        }
        for (var i = 0; i <= 10; i++) {
          if (win["key" + i]) {
            createFavoriteParams["key" + i] = win["key" + i]
          }
        }
        win.close()
        RG.Dialog.showProgressDialog('Creating favorite, please wait...', 'Please wait...')        
        Ext.Ajax.request({
          url: '/aig/store.go?request=ITEMS',          
          success: function(response){
            Ext.Msg.hide()            
            if (!AIG.showErrorMessage(response)) {
              var newItem= RG.decode(response.responseText)
              var msg= 'Created New Favorite'
              if (Ext.isObject(newItem) && newItem.item) {
                msg= msg + ' '+newItem.item.name
              }
              notify(msg)
            }
          },
          failure: function(){
            Ext.Msg.hide()
            AIG.showErrorMessage('Unable to create favorite.', 'Create Favorite')
          },
          scope: this,
          params: createFavoriteParams
        })
      }
    }, {
      text: 'Cancel',
      handler: function(){
        win.close()
      }
    }]
    this.on("show", function(win){
      win.items.get(0).items.get(0).focus(true, 20)
    })
        
    RG.Dialog.CreateFavoriteDialog.superclass.initComponent.call(this);
  }
});
