RG.Dialog.AnimatedWindow = Ext.extend(Ext.Window, {
  initComponent: function() {    
    Ext.applyIf(this, {
      parentContainer: Ext.getBody(),
      parentContainerInitFraction: 0.97,
      widthMax: 680,
      heightMax: 550
    })
    
    if (this.renderToMain=== true) {
      Ext.apply(this, {
        parentContainer: Ext.get('rg-main-container-panel'),
        widthMax: Ext.get('rg-main-container-panel').getWidth(),
        heightMax: Ext.get('rg-main-container-panel').getHeight()
      })      
      this.renderTo= this.parentContainer      
    }     
    Ext.applyIf(this, {
      width: Math.min(this.parentContainer.getSize().width * this.parentContainerInitFraction, this.widthMax),
      height: Math.min(this.parentContainer.getSize().height * this.parentContainerInitFraction, this.heightMax)
    })

    var w= this
    var vpBox= Ext.getBody().getBox()
    var duration= this.openDuration || 0.3
    
      
    var animFn= function() {
      if (this.animateTarget) {
        return
      }
      if (w.el.shadow) {
        w.el.disableShadow();
      }      
      w.un('show', animFn)
      w.proxy.show();
      w.proxy.setBox({
        x: vpBox.width/2, 
        y: vpBox.height/2, 
        width: 1, 
        height: 1
      });
      w.proxy.setOpacity(0);
      var b = w.getBox();
      w.el.setStyle('display', 'none');
      w.proxy.shift(Ext.apply(b, {
        callback: function() {
          w.afterShow(true)
          if (w.el.shadow) {
            w.el.enableShadow(true)
          }
        },
        scope: w,
        easing: 'easeNone',
        duration: duration,
        opacity: 0.5
      }));
    }
    this.on('show', animFn)
    this.on('beforeshow', function(win) {
      try {
        if (win.center=== true) {
          var vpSize= Ext.getBody().getSize()
          var winSize= win.getSize()
          var winPos= win.getPosition()
          var x= 0.5 *  (vpSize.width- winSize.width)
          var y= 0.5 *  (vpSize.height- winSize.height)
          x= (x> 0 ? x : winPos[0])
          y= (y> 0 ? y : winPos[1])
          win.setPosition(x, y)          
        }
      } catch(e) {}
    })
    RG.Dialog.AnimatedWindow.superclass.initComponent.call(this)
  }
}
)
