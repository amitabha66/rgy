/**
 * Defines the AIG Explorer service results/tabs panel
 * 
 * @param {Object} config
 * @author    J. McDowell
 * @date      23 March 2009
 * @version   $Id: RG.Dialog.WidgetDialog.js,v 1.1 2013/04/18 23:04:26 jemcdowe Exp $
 * 
 */
RG.Main.WidgetDialog= Ext.extend(RG.Dialog.AnimatedWindow, {    
  initComponent: function(){      
    var url= this.serviceRecord.get('WidgetURL').replace(/@(dialog|blank)(\(([0-9]+),\s*([0-9]+)\)){0,1}$/i, '')
    
    Ext.applyIf(this, {
      closable: true,
      plain: true,
      layout: 'fit',
      maximizable: true,
      constrain: true,
      closeAction: 'close',      
      title: this.serviceRecord.get('Name'),
      items: new Ext.ux.ManagedIframePanel({
        defaultSrc: url 
      })
    })       
    RG.Main.WidgetDialog.superclass.initComponent.apply(this, arguments);
  }      
})
