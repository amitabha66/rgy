    
RG.Dialog.WelcomeDialog= Ext.extend(Ext.Window, {
  iconCls :'ix-v0-16-colors',
  resizable:false,
  constrain:true,
  constrainHeader:true,
  minimizable : false,
  maximizable : false,
  modal: true,
  shim:true,
  buttonAlign:"center",
  width:500,
  height:290,
  minHeight: 80,
  plain:true,
  footer:true,
  closable:false,
  border: false,
  closeAction: 'hide',
  initComponent: function() {
    var dialog= this
    Ext.applyIf(this, {
      title: 'Research Gateway Version 2'
    })

    var msg= "To begin, please "+
              "select an option below that best matches your area. " +
              "After this step, you can personalize the Launch Pad "+
              "with the “Add App to Launch Pad” button to install any additional tools, searches, or favorites."    
    
    this.items= new Ext.form.FormPanel({
      labelAlign: 'top',
      frame: true,
      defaults: {
        style: {
          marginBottom: '20px'
        }
      },        
      items: [{
        xtype: 'label',
        html: '<table style="margin-bottom:20px" cellspacing="0" cellpadding="0" >'+
          '<tr><td valign="center"><img src="/aig/img/s.gif" style= "height:48px;width:48px;padding-right:8px" class="ix-v0-48-colors"/></td>'+
          '<td valign="center"><h1 style="font-size: 14pt">Welcome to Research Gateway<br/>Let\'s get started!</h1></td>'+
          '</tr></table>'
      }, {
        xtype: 'label',
        html: '<div style="font-size: 11pt;margin-bottom:20px;text-align: justify">'+msg+'</div>'
      }, new Ext.form.ComboBox({
        fieldLabel: 'Please Select Initial Apps',
        store: new Ext.data.Store({
          autoLoad :true,
          url: '/aig/store.go?request=rgapps',
          baseParams: {
            responseFormat: 'JSON',
            loftrx: 'APPROLES'
          },
          reader :new Ext.data.JsonReader({
            root :"roles"          
          }, Ext.data.Record.create([
          {
            name: 'role'
          }
          ]))
        }),
        width: 300,
        displayField: 'role',
        valueField: 'role',
        typeAhead: true,
        forceSelection: true,
        editable: false,
        triggerAction: 'all',
        value:'Standard',
        selectOnFocus:true,
        tpl: new Ext.XTemplate('<tpl for=".">', '<div class="x-combo-list-item">', 
          '<img src="http://rg-resources/ix/png/plain/24/cubes.png" align="absmiddle" border=0 style="margin-right:3px">',
          '{role} Apps</div>', 
          '</tpl>')
      })
      ]
    })
    this.fbar= new Ext.Toolbar({
      enableOverflow: false,
      items: [{
        text: 'OK',
        handler: function() {
          var role= dialog.findByType('combo')[0].getValue()
          dialog.hide()
          dialog.view.showUpdateProgress()
              
          Ext.Ajax.request({
            url: '/aig/store.go?request=RGAPPS&loftrx=RESETAPPS',
            params: {
              role: role
            },
            success: function() {
              dialog.view.store.reload()
              dialog.rgToolbar.reloadLoftItems()
              dialog.view.handleFilter()
              Ext.Msg.hide()                  
              if (Ext.isFunction(dialog.cb)) {
                dialog.cb.call(dialog.scope, true)
              }              
            }, 
            failure: function(options) {
              Ext.Msg.hide()                  
              if (Ext.isFunction(dialog.cb)) {
                dialog.cb.call(dialog.scope, false)
              }              
              showResponseError(options, 'Unable to reset your Launch Pad')
            },
            scope: dialog.view
          })
        }
      }]
    })
    RG.Dialog.WelcomeDialog.superclass.initComponent.call(this)
  }
})