
/**
 * @class AIG.ImageToolTip
 * @extends Ext.ToolTip
 * A tooltip implementation for whcih displays an image.
 * @constructor
 * Create a new Tooltip
 * @param {Object} config The configuration options
 */
AIG.ImageToolTip = function(treeNodeUI) {
  var nodeAttributes= treeNodeUI.node.attributes
	var treeNodeToolTipConfig= new Object()
  treeNodeToolTipConfig.target = Ext.id(treeNodeUI.elNode);
  treeNodeToolTipConfig.autoHeight= true
  treeNodeToolTipConfig.trackMouse= true
	
  AIG.ImageToolTip.superclass.constructor.call(this, treeNodeToolTipConfig);
  var ttPanel= {
         title:	nodeAttributes.text,
         autoLoad: {url: "/aig/generateentitynodetooltip.go?uuid="+nodeAttributes.uuid, text: "Loading...", nocache: true},
         width:150,
         border: false  
  }
  this.add(ttPanel)  
};

Ext.extend(AIG.ImageToolTip, Ext.ToolTip)

