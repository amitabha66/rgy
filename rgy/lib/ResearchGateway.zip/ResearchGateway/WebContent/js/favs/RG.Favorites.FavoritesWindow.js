/**
 * @author jemcdowe
 */
RG.Favorites.FavoritesWindow = Ext.extend(RG.Dialog.AnimatedWindow, {
  id: 'aig_favorites-dialog',
  layout: 'border',
  shadow: false,
  border: false,
  draggable: true,
  resizable: true,
  closable: true,
  constrain: true,
  maximizable: true,
  closeAction: 'close',
  title: 'My Favorites',
  isDialog: true,
  initComponent: function(){
    var win= this           
    
    this.items= [(this.appPanel= new AIG.Favorites.FavoriteFolderPanel({
      region: 'center'
    }))]
  
    this.relayEvents(this.appPanel, ['itemsdeleted', 'itemrenamed'])
    RG.Favorites.FavoritesWindow.superclass.initComponent.call(this);    
  } 
})

