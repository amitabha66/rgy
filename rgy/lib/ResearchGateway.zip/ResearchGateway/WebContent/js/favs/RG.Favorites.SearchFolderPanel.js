/**
 * Provides a folder selector used for the Favorites and SharedFavorites.
 * 
 * @author jemcdowe
 * 
 */
AIG.Favorites.SearchFolderPanel = Ext.extend(Ext.tree.TreePanel, {
	initComponent : function() {
		var tree = this
		//this.baseURL = '/aig/channel.go?channel=FAVORITESTREE&folders_only=true'
		this.baseURL = '/aig/store.go?request=ITEMS&rx=searchfolders'

		Ext.apply(this, {
			rootVisible :false,
			autoScroll :true,
			loader :new Ext.tree.TreeLoader({
				url :this.baseURL,
				createNode : function(attr) {
					return Ext.tree.TreeLoader.prototype.createNode.call(this, attr);
				}

			}),
			root :new Ext.tree.AsyncTreeNode({
				text :'Search Folders',
				leaf :true,
				expanded : true,
				iconCls :'favorite',
				type :'ROOT',
				id :'root'
			})
		})
		AIG.Favorites.SearchFolderPanel.superclass.initComponent.call(this);
	},
	/**
	 * Reloads a node is it has been previously loaded specified by either a
	 * Node object or its ID. If expands the node if it had been. Also provides
	 * a callback. If node is null or not yet loaded, the callback occurs
	 * immediately,; otherwise, after the reload
	 * 
	 * @param {Object} node
	 * @param {Object} cb
	 * @param {Object} scope
	 */
	reloadNode : function(node, cb, scope) {
		if (Ext.type(node) == 'string') {
			node = this.getNodeById(node)
		}
		if (node && !node.isLeaf() && node.isLoaded()) {
			var expanded = node.isExpanded()
			node.reload( function() {
				if (expanded) {
					node.expand(false, true, function() {
						if (Ext.type(cb) == 'function') {
							cb.call(scope, node)
						}
					})
				} else {
					if (Ext.type(cb) == 'function') {
						cb.call(scope, node)
					}
				}
			})
		} else {
			if (Ext.type(cb) == 'function') {
				cb.call(scope, node)
			}
		}
	}
});
