/**
 * Provides a folder selector used for the Favorites and SharedFavorites.
 * 
 * @author jemcdowe
 * 
 */
AIG.Favorites.FavoriteFolderPanel = Ext.extend(Ext.Panel, {
  initComponent: function() {
    var panel = this
    this.addEvents(
            /**
             * @event itemsdeleted
             * Fires when items have been deleted
             * @param {FavoriteFolderPanel} this
             * @param {Records} r Array of deleted records
             */
            'itemsdeleted',
            /**
             * @event itemrenamed
             * Fires when items have been renamed or description changed
             * @param {FavoriteFolderPanel} this
             * @param {Record} Renamed record
             * @param {String} the new name
             * @param {String} the new description
             */
            'itemrenamed')

    //    this.baseURL = '/aig/channel.go?channel=FAVORITESTREE'
    this.cacheID = new UUID()
    this.baseURL = '/aig/store.go?request=ITEMS&cacheID=' + this.cacheID

    this.dropAllowed = 'x-drop-folder-into'
    this.dropNotAllowed = Ext.dd.DragZone.prototype.dropNotAllowed

    this.folderTree = new AIG.Favorites.FavoriteFolderSelector({
      rootExpanded: false,
      region: 'center',
      show_special_folders: "true",
      enableDD: true,
      ddGroup: 'favFolderDDGroup',
      dragConfig: {
        ddGroup: 'favFolderDDGroup',
        getDragData: function(e) {
          var dragData = Ext.dd.Registry.getHandleFromEvent(e)
          if (dragData) {
            dragData.record = new AIG.Favorites.FolderItemsRecord(dragData.node.attributes)
            if (!dragData.record.data.id || dragData.record.data.id == 'root') {
              return false
            }
            return dragData
          }
          return false
        }
      },
      dropConfig: {
        ddGroup: 'favFolderDDGroup',
        dropAllowed: panel.dropAllowed,
        getTargetFromEvent: function(e) {
          var target = Ext.dd.Registry.getTargetFromEvent(e)
          if (target) {
            return {
              node: target.node,
              ddel: this.ddel,
              record: new AIG.Favorites.FolderItemsRecord(target.node.attributes)
            }
          }
          return false
        },
        onNodeOver: function(target, dd, e, data) {
          return panel.isValidDrop(data, target)
        },
        onNodeDrop: function(target, dd, e, data) {
          return panel.handleDrop(data, target)
        }
      }
    })

    this.folderItemsGrid = new RG.Favorites.FavoriteFolderGrid({
      title: 'Favorites',
      region: 'center',
      baseURL: this.baseURL,
      parentPanel: this
    })

    this.tbar = new Ext.Toolbar({
      id: (this.tbID = Ext.id()),
      items: [new Ext.Button({
          icon: "/aig/img/favs/refresh_folder.png",
          text: 'Refresh Folder',
          cls: 'x-btn-text-icon',
          tooltip: 'Refresh a folder or entire tree',
          handler: function() {
            panel.refreshFolder()
          },
          scope: this
        }), new Ext.Button({
          icon: "/aig/img/favs/add_folder.png",
          text: 'Add Folder',
          cls: 'x-btn-text-icon',
          tooltip: 'Create a folder',
          disabled: true,
          handler: function() {
            if (panel.currFolderRecord) {
              panel.handleCreateFolder(panel.currFolderRecord)
            }
          },
          scope: this
        }), new Ext.Button({
          icon: "/aig/img/shared_add.gif",
          text: 'Share',
          cls: 'x-btn-text-icon',
          tooltip: 'Share Favorite',
          disabled: true,
          handler: function() {
            if (panel.canShareRecord(panel.currRecord)) {
              panel.handleShareItem(panel.currRecord)
            }
          },
          scope: this
        }), new Ext.Button({
          icon: "/aig/img/favs/edit_name.png",
          text: 'Edit Name',
          cls: 'x-btn-text-icon',
          tooltip: 'Edit names and description',
          disabled: true,
          handler: function() {
            if (panel.canEditNameRecord(panel.currRecord)) {
              panel.handleEditNameRecord(panel.currRecord)
            }
          },
          scope: this
        }),
        new Ext.Button({
          text: 'Add To Launch Pad',
          cls: 'x-btn-text-icon',
          iconCls: 'ix-v0-16-add2',
          tooltip: 'Add To Launch Pad',
          disabled: true,
          handler: function() {
            if (panel.folderItemsGrid.getSelectionModel().getSelections().length == 1) {
              panel.handleAddItemToLaunchPad(panel.currRecord)
            }
          },
          scope: this
        }),
        new Ext.Button({
          icon: "/aig/img/delete.gif",
          text: 'Delete',
          cls: 'x-btn-text-icon',
          tooltip: 'Delete',
          disabled: true,
          handler: function() {
            if (panel.folderItemsGrid.getSelectionModel().getSelections().length > 1) {
              panel.handleDeleteMultipleItems(panel.folderItemsGrid.getSelectionModel().getSelections())
            } else if (panel.canDeleteRecord(panel.currRecord)) {
              panel.handleDeleteItem(panel.currRecord)
            }
          },
          scope: this
        }), '->',
        {
          xtype: 'tbtext',
          text: 'Search'
        }, new RG.Form.SearchField({
          emptyText: 'Enter text to search on',
          width: 300,
          searchOnKeyPress: false,
          listeners: {
            search: function(field, value) {
              panel.folderItemsGrid.filterBy(value)
            },
            clear: function() {
              panel.folderItemsGrid.clearFilters()
            }
          }
        })

      ],
      updateButtons: function() {
        panel.setButtonsEnabled(this)
      },
      updateFolderButtons: function() {
        panel.setFolderButtonsEnabled(this)
      }
    })

    this.ctxMenu = new Ext.menu.Menu({
      items: [new Ext.menu.Item({
          icon: "/aig/img/favs/refresh_folder.png",
          text: 'Refresh Folder',
          handler: function() {
            panel.refreshFolder()
          },
          scope: panel
        }), new Ext.menu.Item({
          icon: "/aig/img/favs/add_folder.png",
          text: 'Add Folder',
          disabled: true,
          handler: function() {
            if (panel.currFolderRecord) {
              panel.handleCreateFolder(panel.currFolderRecord)
            }
          },
          scope: panel
        }), new Ext.menu.Item({
          icon: "/aig/img/shared_add.gif",
          text: 'Share',
          disabled: true,
          handler: function() {
            if (panel.canShareRecord(panel.currRecord)) {
              panel.handleShareItem(panel.currRecord)
            }
          },
          scope: panel
        }), new Ext.menu.Item({
          icon: "/aig/img/favs/edit_name.png",
          text: 'Edit Name',
          disabled: true,
          handler: function() {
            if (panel.canEditNameRecord(panel.currRecord)) {
              panel.handleEditNameRecord(panel.currRecord)
            }
          },
          scope: panel
        }), new Ext.menu.Item({
          icon: "/aig/img/delete.gif",
          text: 'Delete',
          disabled: true,
          handler: function() {
            if (panel.canDeleteRecord(panel.currRecord)) {
              panel.handleDeleteItem(panel.currRecord)
            }
          },
          scope: panel
        })],
      listeners: {
        beforeshow: function() {
          panel.setButtonsEnabled(this)
          panel.setFolderButtonsEnabled(this)
        }
      }
    })

    this.folderTree.on('contextmenu', function(node, evt) {
      evt.preventDefault()
      evt.stopPropagation()
      var r = new AIG.Favorites.FolderItemsRecord(node.attributes)
      r.node = node

      if (Ext.type(panel.currRecord) != 'object' || r.data.id != panel.currRecord.data.id) {
        panel.selectNodeAndSetFolderItems(r.node, function(record) {
          this.ctxMenu.show(node.ui.getAnchor())
        }, this)
      } else {
        this.ctxMenu.show(node.ui.getAnchor())
      }
    }, panel)

    this.folderItemsGrid.on('rowclick', function(grid, rowIndex) {
      var r = grid.store.getAt(rowIndex)
      this.setCurrentRecord(r)
    }, panel)

    this.folderItemsGrid.on('rowdblclick', function(grid, rowIndex) {
      var r = grid.store.getAt(rowIndex)
      var type = AIG.Favorites.Util.getType(r)
      if (type == 'Folder' || type == 'System Folder') {
        this.handleOpenChildFolder(r)
      } else {
        if (this.canOpenRecord(r)) {
          new RG.Loft.AppLauncher({
            favRecord: r
          }).launch()
          //AIG.openFavorite(r)
        }
      }
    }, panel)

    this.folderItemsGrid.getSelectionModel().on('selectionchange', function() {
      this.updateTitle()
    }, panel)

    this.folderItemsGrid.on('rowcontextmenu', function(grid, rowIndex, evt) {
      evt.preventDefault()
      evt.stopPropagation()
      var r = grid.store.getAt(rowIndex)
      this.setCurrentRecord(r)
      this.ctxMenu.showAt(evt.getXY())
    }, panel)

    this.on('render', function() {
      new Ext.util.DelayedTask().delay(10, function() {
        var rootNode = panel.folderTree.root
        var record = new AIG.Favorites.FolderItemsRecord(rootNode.attributes)
        rootNode.expand(false, true, function() {
          panel.selectNodeAndSetFolderItems(rootNode)
        })
      })
      var keyMap = new Ext.KeyMap(this.getEl(), [{
          key: [Ext.EventObject.DELETE],
          fn: function() {
            if (panel.folderItemsGrid.getSelectionModel().getSelections().length > 1) {
              panel.handleDeleteMultipleItems(panel.folderItemsGrid.getSelectionModel().getSelections())
            } else if (panel.canDeleteRecord(panel.currRecord)) {
              panel.handleDeleteItem(panel.currRecord)
            }
          }
        }, {
          key: [Ext.EventObject.F2],
          fn: function() {
            if (panel.canEditNameRecord(panel.currRecord)) {
              panel.handleEditNameRecord(panel.currRecord)
            }
          }
        }])
      keyMap.stopEvent = true
    }, this)


    this.searchFoldersPanel = new AIG.Favorites.SearchFolderPanel({
      region: 'north',
      width: 200,
      height: 200,
      split: true,
      collapsible: true,
      collapseMode: 'mini',
      hideCollapseTool: true
    })


    this.folderTree.on('click', function(node) {
      var r = new AIG.Favorites.FolderItemsRecord(node.attributes)
      r.node = node
      this.setFolderItems(r)
      this.searchFoldersPanel.getSelectionModel().clearSelections()
    }, panel)

    this.searchFoldersPanel.on('click', function(node) {
      var r = new AIG.Favorites.FolderItemsRecord(node.attributes)
      r.node = node
      this.setFolderItems(r)
      this.folderTree.getSelectionModel().clearSelections()
    }, panel)


    Ext.apply(this, {
      layout: 'border',
      items: [{
          layout: 'border',
          region: 'west',
          width: 200,
          height: 200,
          split: true,
          collapsible: true,
          collapseMode: 'mini',
          hideCollapseTool: true,
          border: false,
          items: [this.searchFoldersPanel, this.folderTree]
        }, this.folderItemsGrid,
        (this.infoPanel = new AIG.Favorites.FavoriteInfoPanel({
          region: 'south',
          height: 100,
          baseURL: this.baseURL
        }))
      ]
    })

    AIG.Favorites.FavoriteFolderPanel.superclass.initComponent.call(this);
  },
  /*
   * BASIC SETTERS AND LOOKUP
   */
  getParentNode: function(record) {
    if (!record || Ext.type(record) != 'object') {
      return null
    }
    if (!record.data && record.attributes) {
      record = new AIG.Favorites.FolderItemsRecord(record.attributes)
    }
    var parentID = record.data.parent_id
    if (parentID != 'root' && parentID == -1) {
      parentID = 'root'
    }

    return this.folderTree.getNodeById(parentID)

  },
  getNameAndIconMarkup: function(record) {
    var type = AIG.Favorites.Util.getType(record)
    var icon = ""
    switch (type) {
      case 'Folder' :
        icon = "ix-v0-16-folder"
        break
      case 'System Folder' :
        icon = 'ix-v0-16-folder_blue' //(record.data.has_new ? 'special-folder-fav-new' : 'special-folder-fav')
        break
      case 'Table' :
        icon = "ix-v0-16-table_sql"
        break
      case 'List' :
        icon = "ix-v0-16-notebook"
        break
      case 'Project View' :
        icon = "ix-v0-16-pie-chart_view"
        break
      case 'Search' :
        icon = "ix-v0-16-signpost"
        break
    }
    var showSharedLabel = false
    if (record.data.is_owner && Ext.type(record.data.shared_with) == 'string' && record.data.shared_with.length > 0) {
      showSharedLabel = true
    }
    return Ext.DomHelper.markup({
      tag: 'span',
      unselectable: "on",
      style: "white-space: nowrap !important;",
      children: [{
          tag: 'img',
          src: Ext.BLANK_IMAGE_URL,
          width: 16,
          height: 16,
          "class": icon,
          style: "background-position: center center; background-repeat: no-repeat; border: 0 none; height: 16px; margin: 0; padding: 0; vertical-align: middle; width: 16px;"
        }, {
          tag: 'span',
          unselectable: "on",
          style: "padding-left: 2px",
          html: Ext.util.Format.htmlEncode(record.data.name) + (showSharedLabel ? ' (shared)' : '')
        }]
    })
  },
  /**
   * Returns the record category and icon for the record
   * 
   * ---------------------------------------------------------
   * THE ASSOCIATION OF THE ICONS NEEDS TO BE SMARTER!!!
   * ---------------------------------------------------------
   * 
   */
  getCategoryAndIconMarkup: function(record) {
    if (record.data.type == 'ITEM' || record.data.type == 'SHARED_ITEM' || record.data.type == 'FOLDER') {
      var category = AIG.Favorites.Util.getCategory(record)
      var icon = null
      var label = record.data.category_label
      switch (category) {
        case 'COMPOUNDS' :
          icon = "compounds"
          break
        case 'SUBSTANCES' :
          icon = 'substances'
          break
        case 'ASSAYS' :
          icon = 'assays'
          break
        case 'PROJECTS' :
          icon = 'projects'
          break
        case 'PEOPLE' :
          icon = 'people'
          break
        case 'NOTEBOOKS' :
          icon = 'notebooks'
          break
        case 'AMGEN_GENES' :
          icon = 'genes'
          break;
        default :
          if (record.data.type == 'FOLDER') {
            label = 'Folder'
            icon = 'folder-fav'
          } else {
            icon = 'results'
          }
          break
      }

      var markup
      if (icon) {
        markup = Ext.DomHelper.markup({
          tag: 'span',
          unselectable: "on",
          style: "white-space: nowrap !important;",
          children: [{
              tag: 'img',
              src: Ext.BLANK_IMAGE_URL,
              width: 16,
              height: 16,
              "class": icon,
              style: "background-position: center center; background-repeat: no-repeat; border: 0 none; height: 16px; margin: 0; padding: 0; vertical-align: middle; width: 16px;"
            }, {
              tag: 'span',
              unselectable: "on",
              style: "padding-left: 2px",
              html: label
            }]
        })
      } else {
        markup = Ext.DomHelper.markup({
          tag: 'span',
          unselectable: "on",
          style: "padding-left: 2px",
          html: record.data.category_label
        })
      }
      return markup
    }
    return record.data.category_label

  },
  /**
   * Sets the currently selected record
   * 
   * @param {Object} record
   */
  setCurrentRecord: function(record) {
    if (record) {
      this.currRecord = record
      this.infoPanel.setItem(this.currRecord)
    }
    Ext.getCmp(this.tbID).updateButtons()
  },
  /**
   * Sets the currently displayed folder record
   * 
   * @param {Object} record
   */
  setCurrentDisplayedFolderRecord: function(record) {
    this.currFolderRecord = record
    this.updateTitle()
    Ext.getCmp(this.tbID).updateFolderButtons()
  },
  updateTitle: function() {
    try {
      if (this.currFolderRecord && this.currFolderRecord.node) {
        var re = /Search Folders\/([\w ]+)/;
        var nodeText = this.currFolderRecord.node.getPath('text')
        if (re.exec(nodeText) != null) {
          nodeText = RegExp.$1
        }
        var title = nodeText + " [" + this.folderItemsGrid.getStore().getTotalCount() + " items"
                + (this.folderItemsGrid.getSelectionModel().getCount() > 0 ? ", " + this.folderItemsGrid.getSelectionModel().getCount() + " selected" : "") + "]"

        this.folderItemsGrid.setTitle(title)
      } else {
        this.folderItemsGrid.setTitle("Favorites")
      }
    } catch (e) {
      this.folderItemsGrid.setTitle("Favorites")
    }
  },
  selectNodeAndSetFolderItems: function(node, cb, scope) {
    if (!Ext.type(node) == 'object') {
      return
    }
    var record = new AIG.Favorites.FolderItemsRecord(node.attributes)
    record.node = node
    node.select()
    this.setFolderItems(record, cb, (scope || this))
  },
  /**
   * Sets the items in the folder items grid and then setCurrentRecord and setCurrentDisplayedFolderRecord
   * 
   * @param {Object} record
   */
  setFolderItems: function(record, cb, scope) {
    if (!record) {
      cb.call(scope)
      return
    }
    this.folderItemsGrid.setFolderItems(record, function() {
      this.setCurrentRecord(record)
      this.setCurrentDisplayedFolderRecord(record)
      if (Ext.type(cb) == 'function') {
        cb.call(scope, record)
      }
    },
            this
            )
  },
  /*
   * REFRESH OPERATIONS
   */
  /**
   * Refreshes the current folder record or the root if none has yet been selected
   */
  refreshFolder: function() {
    var node = this.folderTree.root
    if (this.currFolderRecord) {
      node = this.folderTree.getNodeById(this.currFolderRecord.data.id)
    }
    this.folderTree.reloadNode(node, function() {
      this.folderItemsGrid.refreshFolder()
    }, this)
  },
  /**
   * Reloads nodes and possibly the folder items grid after a change. Preserves the expansions, if possible. This is done in carefully. If a node is the child
   * of another, this child is not reloaded; otherwise, state gets all screwed up. Up to 2 nodes can be provided
   * 
   * @param {Object} node1
   * @param {Object} node2
   */
  updateViewsAfterChange: function(node1, node2) {
    var node1ID = (node1 == null ? null : node1.attributes.id)
    var node2ID = (node2 == null ? null : node2.attributes.id)

    var node1Expanded = (node1 == null ? null : node1.isExpanded())
    var node2Expanded = (node2 == null ? null : node2.isExpanded())

    if (node1 != null && node2 != null) {
      if (node1.contains(node2)) {
        node2 = null
      }
    }
    if (node1 != null && node2 != null) {
      if (node2.contains(node1)) {
        node1 = null
      }
    }

    var currentSelectedNodeID = null
    if (this.currFolderRecord && this.currFolderRecord.node) {
      currentSelectedNodeID = this.currFolderRecord.node.attributes.id
    }
    this.folderTree.reloadNode(node1, function() {
      this.folderTree.reloadNode(node2, function() {
        if (node1Expanded && node1ID) {
          var node = this.folderTree.getNodeById(node1ID)
          if (node) {
            node.expand()
          }
        }
        if (node2Expanded && node2ID) {
          var node = this.folderTree.getNodeById(node2ID)
          if (node) {
            node.expand()
          }
        }
        if (!this.currFolderRecord) {
          return
        }
        if (currentSelectedNodeID) {
          var node = this.folderTree.getNodeById(currentSelectedNodeID) ||
                  this.searchFoldersPanel.getNodeById(currentSelectedNodeID)
          if (node) {
            node.select()
            var r = new AIG.Favorites.FolderItemsRecord(node.attributes)
            r.node = node
            this.setFolderItems(r)
          }
        } else if ((node1ID && this.currFolderRecord.data.id == node1ID) || (node2ID && this.currFolderRecord.data.id == node2ID)) {
          this.folderItemsGrid.refreshFolder()
        }

      }, this)
    }, this)
  },
  /*
   * RECORD OPERATIONS VERIFIERS
   */
  /**
   * Returns whether a record can be opened
   * 
   * @param {Object} record
   */
  canOpenRecord: function(record) {
    if (Ext.type(record) == 'array' && record.length == 1) {
      record = record[0]
    }
    if (Ext.type(record) != 'object') {
      return false
    }
    if (AIG.Favorites.Util.getType(record) == 'Folder') { // Is a
      // folder
      return false
    }
    if (AIG.Favorites.Util.getType(record) == 'System Folder') { // Is a
      // system
      // folder
      return false
    }
    switch (record.data.type) {
      case 'SHARED_ITEM' :
        return true
      case 'ITEM' :
        return true
      default :
        return false
    }
  },
  /**
   * Returns whether a record can be renamed
   * 
   * @param {Object} record
   */
  canEditNameRecord: function(record) {
    if (Ext.type(record) == 'array' && record.length == 1) {
      record = record[0]
    }
    if (Ext.type(record) != 'object') {
      return false
    }
    if (!record.data.parent_id) { // Is a root node
      return false
    }
    if (AIG.Favorites.Util.getType(record) == 'System Folder') { // Is a
      // folder
      return false
    }

    if (!record.data.is_owner) {
      return false
    }
    if (record.data.type == 'ITEM' || record.data.type == 'SHARED_ITEM') {
      return true
    }
    return true
  },
  /**
   * Returns whether the record can have its star toggled
   */
  canToggleStar: function(record) {
    if (Ext.type(record) == 'array' && record.length == 1) {
      record = record[0]
    }
    if (Ext.type(record) != 'object') {
      return false
    }
    if (!record.data.parent_id) { // Is a root node
      return false
    }
    if (AIG.Favorites.Util.getType(record) == 'System Folder') { // Is a folder
      return false
    }
    if (record.data.type == 'ITEM' || record.data.type == 'SHARED_ITEM') {
      return true
    }
    return false
  },
  /**
   * Returns whether a record can be shared
   * 
   * @param {Object} record
   */
  canShareRecord: function(record) {
    if (Ext.type(record) == 'array' && record.length == 1) {
      record = record[0]
    }
    if (Ext.type(record) != 'object') {
      return false
    }
    if (!record.data.parent_id) { // Is a root node
      return false
    }
    if (AIG.Favorites.Util.getType(record) == 'System Folder') { // Is a
      // folder
      return false
    }
    if (!record.data.is_owner) {
      return false
    }
    if (record.data.type == 'ITEM') {
      return true
    }
    return false
  },
  canAddToLaunchPad: function(record) {
    if (Ext.type(record) == 'array' && record.length == 1) {
      record = record[0]
    }
    if (Ext.type(record) != 'object') {
      return false
    }
    if (!record.data.parent_id) { // Is a root node
      return false
    }
    if (AIG.Favorites.Util.getType(record) == 'System Folder') { // Is a
      // folder
      return false
    }
    if (record.data.type == 'ITEM') {
      return true
    }
    return false
  },
  /**
   * Returns whether a record can be deleted
   * 
   * @param {Object} record
   */
  canDeleteRecord: function(record) {
    var records = []
    if (Ext.type(record) == 'object') {
      records.push(record)
    } else if (Ext.type(record) == 'array') {
      records = record
    }
    if (records.length == 0) {
      return false
    }
    for (var i = 0; i < records.length; i++) {
      record = records[i]
      if (record) {
        if (!record.data.parent_id) { // Is a root node
          return false
        }
        if (AIG.Favorites.Util.getType(record) == 'System Folder') { // Is a
          // system folder
          return false
        }

        switch (record.data.type) {
          case 'SHARED_ITEM' :
            if (!record.data.can_delete) {
              return false
            }
            break
          case 'ITEM' :
            if (!record.data.is_owner) {
              return false
            }
            break
          case 'FOLDER' :
            if (!record.data.is_owner) {
              return false
            }
            break
          default :
            break
        }
      }
    }
    return true
  },
  canMoveRecord: function(sourceRecord, targetFolderRecord) {
    if (Ext.type(sourceRecord) != 'object' || Ext.type(targetFolderRecord) != 'object') {
      return false
    }
    if (!sourceRecord.data.parent_id) { // Source is a root node
      return false
    }
    if (AIG.Favorites.Util.getType(sourceRecord) == 'System Folder') { // Is a
      // system
      // folder
      return false
    }

    if (sourceRecord.data.id == targetFolderRecord.data.id) {
      return false
    }
    // Try to determine if the source is already a child of
    // target
    // This only works if the target node has been loaded
    // This could also be done by an Ajax call, but I don't
    // think it is needed
    var sourceNode = this.folderTree.getNodeById(sourceRecord.data.id)
    var targetFolderNode = this.folderTree.getNodeById(targetFolderRecord.data.id)
    if (sourceNode && targetFolderNode && targetFolderNode.indexOf(sourceNode) > -1) {
      return false
    }
    // Try to ensure the source does not contain the target
    if (sourceNode && targetFolderNode && sourceNode.contains(targetFolderNode)) {
      return false
    }
    switch (AIG.Favorites.Util.getType(targetFolderRecord)) {
      case 'Root Folder' : // Folders are OK
      case 'Folder' :
        return true
      case 'System Folder' : // Not system folders
        return false
      default : // Anything else- no
        return false
    }
  },
  canCreateFolder: function(parentFolderRecord) {
    var type = AIG.Favorites.Util.getType(parentFolderRecord)
    return (type == 'Folder' || type == 'Root Folder')
  },
  setButtonsEnabled: function(container) {
    var shareButton = container.items.get(container.items.findIndex('text', 'Share'))
    var deleteButton = container.items.get(container.items.findIndex('text', 'Delete'))
    var editNameButton = container.items.get(container.items.findIndex('text', 'Edit Name'))
    var addFolderButton = container.items.get(container.items.findIndex('text', 'Add Folder'))
    var addToLaunchPadButton = container.items.get(container.items.findIndex('text', 'Add To Launch Pad'))

    if (!this.currRecord) {
      RG.setDisabled(shareButton, true)
      RG.setDisabled(deleteButton, true)
      RG.setDisabled(editNameButton, true)
    } else {
      RG.setDisabled(shareButton, !this.canShareRecord(this.currRecord))
      RG.setDisabled(deleteButton, !this.canDeleteRecord(this.currRecord))
      RG.setDisabled(editNameButton, !this.canEditNameRecord(this.currRecord))
      RG.setDisabled(addToLaunchPadButton, !this.canAddToLaunchPad(this.currRecord))
    }
  },
  setFolderButtonsEnabled: function(container) {
    var addFolderButton = container.items.get(container.items.findIndex('text', 'Add Folder'))
    RG.setDisabled(addFolderButton, !this.canCreateFolder(this.currFolderRecord))
  },
  /*
   * DnD UTILITY METHODS
   */
  /**
   * Returns whether a source -> target is a valid drop point
   * 
   * @param {Object} source
   * @param {Object} target
   */
  isValidDrop: function(source, target) {
    if (!source || !source.record || !target || !target.record) {
      return this.dropNotAllowed
    }
    if (Ext.type(source.record) == 'array') {
      for (var i = 0; i < source.record.length; i++) {
        if (this.canMoveRecord(source.record[i], target.record)) {
          return this.dropAllowed
        }
      }
      return this.dropNotAllowed
    }
    return (this.canMoveRecord(source.record, target.record) ? this.dropAllowed : this.dropNotAllowed)
  },
  /**
   * Handles a drop request- just means a move
   * 
   * @param {Object} source
   * @param {Object} target
   */
  handleDrop: function(source, target) {
    if (!source || !source.record || !target || !target.record) {
      return false
    }
    if (Ext.type(source.record) == 'array') {
      for (var i = 0; i < source.record.length; i++) {
        if (this.canMoveRecord(source.record[i], target.record)) {
          return this.handleMoveAllItems(source.record, target.record)
        }
      }
      return false
    }
    return this.handleMoveItem(source.record, target.record)
  },
  /*
   * Handlers for operations
   */
  /**
   * Handler for when a folder is double-clicked in the folder items grid
   * 
   * @param {Object} record
   */
  handleOpenChildFolder: function(record) {
    if (AIG.Favorites.Util.getType(record) != 'Folder' && AIG.Favorites.Util.getType(record) != 'System Folder') {
      return
    }
    var node = this.folderTree.getSelectionModel().getSelectedNode()
    if (node) {
      var panel = this
      node.expand(false, true, function() {
        var childNode = panel.folderTree.getNodeById(record.data.id)
        if (childNode) {
          childNode.expand()
          panel.folderTree.selectPath(childNode.getPath())
          record.node = childNode
          panel.setFolderItems(record)
        }
      })
    }
  },
  /**
   * Handler for moving the sourceRecord to the targetFolderRecord
   * 
   * @param {Object} sourceRecord
   * @param {Object} targetFolderRecord
   */
  handleMoveItem: function(sourceRecord, targetFolderRecord) {
    if (!this.canMoveRecord(sourceRecord, targetFolderRecord)) {
      return false
    }
    var folderIDs = RG.Record.join([sourceRecord], "id", null, "type", "FOLDER")
    var itemIDs = []
    itemIDs = itemIDs.concat(RG.Record.join([sourceRecord], "id", null, "type", "ITEM"))
    itemIDs = itemIDs.concat(RG.Record.join([sourceRecord], "id", null, "type", "SHARED_ITEM"))

    Ext.Ajax.request({
      url: this.baseURL,
      params: {
        op: 'move',
        folder_ids: folderIDs.join(","),
        item_ids: itemIDs.join(","),
        newparent_node: targetFolderRecord.data.id
      },
      success: function(response) {
        var panel = this
        if (!AIG.Favorites.Util.processError(response.responseText)) {
          return
        }
        var origParentNode = panel.getParentNode(sourceRecord)
        var targetFolderNode = panel.folderTree.getNodeById(targetFolderRecord.data.id)
        panel.updateViewsAfterChange(origParentNode, targetFolderNode)
        showInformationDialog('Item(s) moved')
      },
      scope: this
    })
    return true
  },
  /**
   * Handler for moving multiple sourceRecords to the targetFolderRecord
   * 
   * @param {Array} sourceRecords
   * @param {Object} targetFolderRecord
   */
  handleMoveAllItems: function(sourceRecords, targetFolderRecord) {
    if (Ext.type(sourceRecords) != 'array' || sourceRecords.length == 0) {
      return false
    }
    var moveRecords = []
    for (var i = 0; i < sourceRecords.length; i++) {
      if (this.canMoveRecord(sourceRecords[i], targetFolderRecord)) {
        moveRecords.push(sourceRecords[i])
      }
    }
    if (moveRecords.length == 0) {
      return false
    }

    var folderIDs = RG.Record.join(moveRecords, "id", null, "type", "FOLDER")
    var itemIDs = []
    itemIDs = itemIDs.concat(RG.Record.join(moveRecords, "id", null, "type", "ITEM"))
    itemIDs = itemIDs.concat(RG.Record.join(moveRecords, "id", null, "type", "SHARED_ITEM"))

    var origParentNode = this.getParentNode(moveRecords[0])

    Ext.Ajax.request({
      url: this.baseURL,
      params: {
        op: 'move_all',
        folder_ids: folderIDs.join(","),
        item_ids: itemIDs.join(","),
        newparent_node: targetFolderRecord.data.id
      },
      success: function(response) {
        var panel = this
        if (!AIG.Favorites.Util.processError(response.responseText)) {
          return
        }
        var targetFolderNode = panel.folderTree.getNodeById(targetFolderRecord.data.id)
        panel.updateViewsAfterChange(origParentNode, targetFolderNode)
        showInformationDialog('Item(s) moved')
      },
      scope: this
    })
    return true
  },
  /**
   * Creates a new folder in the given folder provided as a record
   * 
   * @param {Object} record
   */
  handleCreateFolder: function(record) {
    AIG.Favorites.Util.handleCreateFolder(record, this.baseURL, function(record) {
      var node = this.folderTree.getNodeById(record.data.id)
      this.updateViewsAfterChange(node)
      showInformationDialog('Folder created')
    }, this)
  },
  /**
   * Deletes an item or folder
   * 
   * @param {Object} record
   */
  handleDeleteItem: function(record) {
    if (!this.canDeleteRecord(record)) {
      return
    }
    var msg = "Do you want to delete '" + Ext.util.Format.htmlEncode(record.data.name) + "'"
    if (record.data.type == 'FOLDER') {
      msg = msg + '<BR/>including all contents'
    }

    var folderIDs = RG.Record.join([record], "id", null, "type", "FOLDER")
    var itemIDs = []
    itemIDs = itemIDs.concat(RG.Record.join(record, "id", null, "type", "ITEM"))
    itemIDs = itemIDs.concat(RG.Record.join(record, "id", null, "type", "SHARED_ITEM"))

    Ext.MessageBox.show({
      title: 'Confirm ' + (record.data.type == 'FOLDER' ? 'Folder' : 'Favorite') + ' Delete',
      msg: msg + '?',
      buttons: Ext.MessageBox.YESNO,
      fn: function(buttonId) {
        if (buttonId != 'yes') {
          return
        }
        Ext.Ajax.request({
          url: this.baseURL,
          success: function(response) {
            AIG.Favorites.Util.processError(response.responseText)
            var parentNode = this.getParentNode(record)
            this.updateViewsAfterChange(parentNode)
            if (this.currFolderRecord && this.currFolderRecord.data.id == record.data.id) {
              this.selectNodeAndSetFolderItems(parentNode)
            }
            showInformationDialog('Item(s) deleted')
            this.fireEvent('itemsdeleted', this, [record])
          },
          failure: function() {
            AIG.showErrorMessage('Unable to delete ' + Ext.util.Format.htmlEncode(record.data.name) + '.', 'Message')
            var parentNode = this.getParentNode(record)
            this.updateViewsAfterChange(parentNode)
          },
          scope: this,
          params: {
            op: 'delete',
            folder_ids: folderIDs.join(","),
            item_ids: itemIDs.join(",")
          }
        })
      },
      scope: this,
      icon: Ext.MessageBox.QUESTION
    })
  },
  /**
   * Deletes the multiple records
   */
  handleDeleteMultipleItems: function(records) {
    if (Ext.type(records) != 'array' || records.length == 0) {
      return
    }
    Ext.MessageBox.show({
      title: 'Confirm  Delete',
      msg: 'Do you want to delete all ' + records.length + ' selections including all contents?',
      buttons: Ext.MessageBox.YESNO,
      fn: function(buttonId) {
        if (buttonId != 'yes') {
          return
        }
        var deleteRecords = []
        for (var i = 0; i < records.length; i++) {
          if (this.canDeleteRecord(records[i])) {
            deleteRecords.push(records[i])
          }
        }
        if (deleteRecords.length == 0) {
          return
        }
        var folderIDs = RG.Record.join(deleteRecords, "id", null, "type", "FOLDER")
        var itemIDs = []
        itemIDs = itemIDs.concat(RG.Record.join(deleteRecords, "id", null, "type", "ITEM"))
        itemIDs = itemIDs.concat(RG.Record.join(deleteRecords, "id", null, "type", "SHARED_ITEM"))

        var parentNode = this.getParentNode(deleteRecords[0])


        Ext.Ajax.request({
          url: this.baseURL,
          success: function(response) {
            AIG.Favorites.Util.processError(response.responseText)
            this.updateViewsAfterChange(parentNode)
            if (this.currFolderRecord && this.currFolderRecord.data.id == deleteRecords[0].data.id) {
              this.selectNodeAndSetFolderItems(parentNode)
            }
            showInformationDialog('Item(s) deleted')
            this.fireEvent('itemsdeleted', this, records)
          },
          failure: function() {
            AIG.showErrorMessage('Unable to delete selections.', 'Message')
            this.updateViewsAfterChange(parentNode)
          },
          scope: this,
          params: {
            op: 'delete_all',
            folder_ids: folderIDs.join(","),
            item_ids: itemIDs.join(",")
          }
        })
      },
      scope: this,
      icon: Ext.MessageBox.QUESTION
    })
  },
  /**
   * Creates a new folder in the given folder provided as a record
   * 
   * @param {Object} record
   */
  handleEditNameRecord: function(record) {
    if (!this.canEditNameRecord(record)) {
      return
    }
    var folderIDs = RG.Record.join([record], "id", null, "type", "FOLDER")
    var itemIDs = []
    itemIDs = itemIDs.concat(RG.Record.join(record, "id", null, "type", "ITEM"))
    itemIDs = itemIDs.concat(RG.Record.join(record, "id", null, "type", "SHARED_ITEM"))

    AIG.Favorites.Util.getNameDesc('Update Name and Description', record.data.name, record.data.description, function(name, desc) {
      Ext.Ajax.request({
        url: this.baseURL,
        params: {
          op: 'rename',
          folder_ids: folderIDs.join(","),
          item_ids: itemIDs.join(","),
          name: name,
          desc: desc
        },
        success: function(response) {
          AIG.Favorites.Util.processError(response.responseText)
          var parentNode = this.getParentNode(record)
          this.updateViewsAfterChange(parentNode)
          this.fireEvent('itemrenamed', this, record, name, desc)
        },
        failure: function() {
          AIG.showErrorMessage('Unable to rename', 'Message')
          var parentNode = this.getParentNode(record)
          this.updateViewsAfterChange(parentNode)
        },
        scope: this
      })
    }, this)
  },
  handleAddItemToLaunchPad: function(record) {
    var launchPad = Ext.getCmp('aig_launchpad')
    if (!launchPad) {
      return false
    }
    launchPad.appPanel.appView.handleAddApp(record, function(success) {
      if (success) {
        showInformationDialog('Added "' + record.get('name') + '" to Launch Pad')
      } else {
        showInformationDialog('Unable to Add "' + record.get('name') + '" to Launch Pad')
      }
    })
  },
  toggleStar: function(record) {
    if (!this.canToggleStar(record)) {
      return
    }
    var itemIDs = []
    itemIDs = itemIDs.concat(RG.Record.join(record, "id", null, "type", "ITEM"))
    itemIDs = itemIDs.concat(RG.Record.join(record, "id", null, "type", "SHARED_ITEM"))

    Ext.Ajax.request({
      url: this.baseURL,
      params: {
        op: 'star',
        item_ids: itemIDs.join(",")
      },
      success: function(response) {
        AIG.Favorites.Util.processError(response.responseText)
        var parentNode = this.getParentNode(record)
        this.updateViewsAfterChange(parentNode)
      },
      failure: function() {
        AIG.showErrorMessage('Unable to update item', 'Message')
        var parentNode = this.getParentNode(record)
        this.updateViewsAfterChange(parentNode)
      },
      scope: this
    })
  },
  handleShareItem: function(record) {
    if (!this.canShareRecord(record)) {
      return
    }
    var itemIDs = []
    itemIDs = itemIDs.concat(RG.Record.join(record, "id", null, "type", "ITEM"))
    itemIDs = itemIDs.concat(RG.Record.join(record, "id", null, "type", "SHARED_ITEM"))

    new RG.Dialog.UserSelector({
      title: 'Share ' + Ext.util.Format.htmlEncode(record.data.name) + ' With..',
      usernames: record.data.shared_with,
      select_usernames: true,
      handler: function(users) {
        users = users || []
        var usernames = []
        for (var i = 0; i < users.length; i++) {
          usernames.push(users[i].data.username)
        }

        Ext.Ajax.request({
          url: this.baseURL,
          success: function(response) {
            AIG.Favorites.Util.processError(response.responseText)
            var parentNode = this.getParentNode(record)
            this.updateViewsAfterChange(parentNode)
            showInformationDialog('Item(s) sharing updated')
          },
          failure: function() {
            AIG.showErrorMessage('Unable to share favorites.', 'Share Favorite')
          },
          scope: this,
          params: {
            op: 'SHARE',
            item_ids: itemIDs.join(","),
            shareWith: usernames.join(";")
          }
        })
      },
      scope: this
    }).show()
  }
});

/**
 * Common Favorites utility functions
 */
AIG.Favorites.Util = {
  /**
   * Returns the type of record. Returns either : Root Folder Folder Table List Project View Search
   * 
   * @param {Object} record
   */
  getType: function(record) {
    if (!record || Ext.type(record) != 'object') {
      return 'Unknown'
    }
    if (record.data.type == 'FOLDER') {
      switch (record.data.subtype) {
        case 'ROOT' :
          return 'Root Folder'
        case 'INCOMING':
          return 'System Folder'
        default :
          return 'Folder'
      }
    } else if (record.data.type == 'ROOT') {
      return 'Root Folder'
    } else if (record.data.type == 'ITEM' || record.data.type == 'SHARED_ITEM') {
      switch (record.data.subtype) {
        case 'ENTITYTABLE' :
          return 'Table'
        case 'LIST' :
          return 'List'
        case 'PROJECTVIEW' :
          return 'Project View'
        case 'SERVICE' :
          return 'Search'
      }
    }
    return ""
  },
  getCategory: function(record) {
    if (!record || Ext.type(record) != 'object' || Ext.type(record.data.category) != 'string') {
      return 'Unknown'
    }
    return record.data.category.toUpperCase()
  },
  /**
   * Creates a new folder in the given folder provided as a record
   * 
   * @param {Object} record The parent folder record
   * @param {Object} cb Optional callback function after a successful create folder
   * @param {Object} scope Optional scope of the callback
   */
  handleCreateFolder: function(record, baseURL, cb, scope) {
    switch (AIG.Favorites.Util.getType(record)) {
      case 'Root Folder' : // Folders are OK
      case 'Folder' :
        break
      case 'System Folder' : // Not System Folders
        break
      default : // Anything else- no
        return false
    }
    AIG.Favorites.Util.getNameDesc('Enter Folder Name', null, null, function(name, desc) {
      Ext.Ajax.request({
        url: baseURL,
        success: function(response) {
          AIG.Favorites.Util.processError(response.responseText)
          if (Ext.type(cb) == 'function') {
            cb.call((scope || this), record)
          }
          // var node = this.folderTree.getNodeById(record.data.id)
          // this.updateViewsAfterChange(node)
        },
        failure: function() {
          AIG.showErrorMessage('Unable to create Folder.', 'Message')
        },
        scope: this,
        params: {
          op: 'NEWFOLDER',
          newparent_node: record.data.id,
          name: name,
          desc: desc
        }
      })
    }, this)
  },
  /**
   * Gets a new/updated name and description
   * 
   * @param {Object} title Title of the dialog
   * @param {Object} name The current name
   * @param {Object} desc The current description
   * @param {Object} cb Optional callback function
   * @param {Object} cbScope Optional callback function scope
   */
  getNameDesc: function(title, name, desc, cb, cbScope) {
    var win = new Ext.Window({
      title: title || 'Provide Name and Description',
      closable: true,
      closeAction: 'close',
      width: 400,
      height: 170,
      layout: 'form',
      modal: true,
      resizable: false,
      bodyStyle: 'padding: 5px;',
      items: [{
          xtype: 'textfield',
          name: 'name',
          width: 250,
          fieldLabel: 'Name',
          enableKeyEvents: true,
          value: name,
          listeners: {
            keypress: function(field, evt) {
              if (evt.getKey() == Ext.EventObject.ENTER) {
                win.okClicked()
              }
            },
            scope: this
          }
        }, {
          xtype: 'textarea',
          name: 'desc',
          width: 250,
          fieldLabel: 'Description',
          value: desc
        }],
      listeners: {
        show: function(window) {
          window.items.get(0).focus(true, 500)
        }
      },
      okClicked: function() {
        var name = this.items.get(0).getValue().trim()
        var desc = this.items.get(1).getValue().trim()
        if (name.length == 0) {
          Ext.Msg.alert('Name Required', 'You must specify a name.');
          return
        }
        this.hide()
        if (Ext.type(cb) == 'function') {
          cb.call(cbScope, name, desc)
        }
      },
      buttons: [{
          text: 'OK',
          handler: function() {
            win.okClicked()
          },
          scope: this
        }, {
          text: 'Cancel',
          handler: function() {
            win.hide()
          },
          scope: this
        }]
    })
    win.show(this)
  },
  getIcon: function(record) {
    var type = AIG.Favorites.Util.getType(record)
    switch (type) {
      case 'Folder' :
        return "ix-v0-16-folder"
      case 'System Folder' :
        return 'ix-v0-16-folder_blue' //(record.data.has_new ? 'special-folder-fav-new' : 'special-folder-fav')
      case 'Table' :
        return "ix-v0-16-table_sql"
      case 'List' :
        return "ix-v0-16-notebook"
      case 'Project View' :
        return "ix-v0-16-pie-chart_view"
      case 'Search' :
        return "ix-v0-16-signpost"
    }
    return "ix-v0-16-star_green"
  },
  /**
   * Determines if the responseText contains an error. If so, it displays the error. Returns true if no error. false otherwise
   * 
   * @param {Object} responseText
   */
  processError: function(responseText) {
    var json = null
    try {
      json = Ext.util.JSON.decode(responseText)
      if (json.error) {
        AIG.showErrorMessage(json.error, 'Request Problem')
        return false
      }
      return true
    } catch (e) {
    }
    AIG.showErrorMessage("Unknown error occurred", 'Request Problem')
    return false
  }
}
