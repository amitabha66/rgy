/**
 * Provides a folder selector used for the Favorites and SharedFavorites.
 * 
 * @author jemcdowe
 * 
 */
AIG.Favorites.FavoriteInfoPanel = Ext.extend(Ext.Panel, {
  initComponent : function() {
    var panel = this
    this.bodyStyle= {
      backgroundColor: '#dfe8f6'
    }
    this.store= new Ext.data.Store({
      // load using HTTP
      url :this.baseURL,
      baseParams :{
        rx: 'ITEMDETAILS'
      },
      autoLoad :false,
      reader :new Ext.data.JsonReader({
        root :"children"
      }, AIG.Favorites.FolderItemsRecord)
    })    
    this.store.on('load', this.updateDetails.createDelegate(this), this)
    AIG.Favorites.FavoriteInfoPanel.superclass.initComponent.call(this);
  },
  setItem: function(record) {
    if (record) {
      this.itemRecord= record      
      var folderID= null
      var itemID= null
      switch (AIG.Favorites.Util.getType(record)) {
        case 'Root Folder' :
        case 'Folder' :
        case 'System Folder' :
          folderID= record.data.id
          break
        default :
          itemID= record.data.id
          break
      }
      
      this.store.load({
        params: {
          folder_id: folderID,
          item_id: itemID
        }
      })
    }
  },
  updateDetails: function(store, records) {
    try {
      if (!Ext.isArray(records) || records.length== 0) {
        return
      }
      var record= records[0]
      if(!this.detailEl){
        var bd = this.body;
        bd.update('').setStyle('background','#fff');
        this.detailEl = bd.createChild(); //create default empty div
      }
      var detailsChildren= []
    
      detailsChildren.push({
        tag :'div',
        unselectable :"on",
        style :"padding: 2px",
        html : '<B>Name: </B>'+Ext.util.Format.htmlEncode(record.data.name)
      })
      detailsChildren.push({
        tag :'div',
        unselectable :"on",
        style :"padding: 2px",
        html : '<B>Type: </B>'+AIG.Favorites.Util.getType(record) + (record.data.category_label ? ' ('+record.data.category_label + ')' : '')
      })
      detailsChildren.push({
        tag :'div',
        unselectable :"on",
        style :"padding: 2px",
        html : '<B>Created: </B>'+record.data.created.format('m/d/Y h:i:s A')
      })
      detailsChildren.push({
        tag :'div',
        unselectable :"on",
        style :"padding: 2px",
        html : '<B>Created By: </B>'+record.data.created_by_name
      })   
    
      this.detailEl.hide().update(Ext.DomHelper.markup({
        tag :'span',
        unselectable :"on",
        style :"white-space: nowrap !important;",
        children :[{
          tag: 'table',
          children: [{
            tag: 'tr',
            children: [{
              tag: 'td',
              children: [{
                tag :'img',
                src :Ext.BLANK_IMAGE_URL,
                width :48,
                height :48,
                "class" :RG.Icon.Utils.getSizedIconClass(AIG.Favorites.Util.getIcon(record), 48),
                style :"background-position: center center; background-repeat: no-repeat; border: 0 none; margin: 0; padding: 5; vertical-align: middle; width: 48px; height: 48px"
              }
              ]
            }, {
              tag: 'td',
              valign: 'middle',
              children: detailsChildren
            }
            ]
          }
          ]
        }
        ]
      })).slideIn('l', {
        stopFx:true,
        duration:.2
      });
    } catch(e) {}
        
  }
})