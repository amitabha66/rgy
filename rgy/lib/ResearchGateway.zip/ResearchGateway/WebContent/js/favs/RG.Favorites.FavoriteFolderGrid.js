/**
 * Provides the Grid uses to display items
 */
RG.Favorites.FavoriteFolderGrid= Ext.extend(Ext.grid.GridPanel, {
  constructor: function(config) {
    Ext.applyIf(config, {      
      autoExpandColumn :'name',
      enableHdMenu :true,
      enableColumnMove :false,
      enableColumnHide: false,
      disableExportMenu :true,
      // enableDragDrop: true,
      loadMask: false,
      ddGroup :'favFolderDDGroup',
      sm :new Ext.grid.RowSelectionModel({
        singleSelect :false
      }),
      viewConfig :{
        forceFit :true
      }
    })
    Ext.grid.GridPanel.prototype.constructor.call(this, config)
  },  
  initComponent: function() {  
    var grid= this
    var parentPanel= this.parentPanel
    this.pageSize= 25
    this.store= new Ext.data.Store({
      // load using HTTP
      url :this.baseURL,
      baseParams :{
        rx: 'folder',
        node: '',
        show_special_folders :'false'
      },
      autoLoad :false,
      remoteSort: true,
      reader :new Ext.data.JsonReader({
        root :"children",
        totalProperty: 'total'
      }, AIG.Favorites.FolderItemsRecord)
    })
    
    var colDefs= [{
      id :'name',
      header :'Name',
      sortable :true,
      dataIndex :'name',
      renderer : function(value, md, record) {
        return parentPanel.getNameAndIconMarkup(record)
      }
    }, {
      header :'Description',
      dataIndex :'description',
      sortable :true
    }, {
      header :'Type',
      dataIndex :'subtype',
      sortable :true,
      renderer : function(value, md, record) {
        var typeLabel = AIG.Favorites.Util.getType(record)
        return typeLabel
      }
    }, {
      header :'Category',
      dataIndex :'category_label',
      sortable :true,
      renderer : function(value, md, record) {
        return parentPanel.getCategoryAndIconMarkup(record)
      }
    }, {
      header :'Owner',
      dataIndex :'created_by',
      sortable :true,
      renderer: function(value, metaData, record, rowIndex, colIndex, store) {
        if (record.data.created_by_name && record.data.created_by_name.length> 0) {
          return record.data.created_by_name
        }
        return value
      }
    }, {
      header :'Date Created',
      dataIndex :'created',
      renderer :Ext.util.Format.dateRenderer('m/d/Y h:i:s A'),
      filterType: 'date',      
      sortable :true
    }, {
      header :'Date Shared',
      dataIndex :'shared',
      renderer :Ext.util.Format.dateRenderer('m/d/Y h:i:s A'),
      filterType: 'date',
      sortable :true
    }, {
      header :'Star',
      dataIndex :'starred',
      width: 40,
      sortable :true,
      filterType:{
        type: 'list',
        options: ['Starred', 'Not Starred']     
      },   
      renderer: function(value, metaData, record, rowIndex, colIndex, store) {     
        if (record.data.type=='ITEM' || record.data.type=='SHARED_ITEM') {
          return Ext.DomHelper.markup({
            tag :'div',
            unselectable :"on",
            style :"text-align:center;white-space: nowrap !important;",
            children :[{
              tag :'img',
              src :Ext.BLANK_IMAGE_URL,
              width :16,
              height :16,
              "class" :(value ? 'ix-v0-16-star_yellow' : 'ix-v0-16-star_grey'),
              style :"cursor: pointer;background-position: center center; background-repeat: no-repeat; border: 0 none; height: 16px; margin: 0; padding: 0; vertical-align: middle; width: 16px;"
            }]
          })
        } else {
          return ''
        }
      }
    }]
    
    this.colModel= new Ext.grid.ColumnModel({     
      defaults: {
        width: 100,
        sortable: true
      },
      columns: colDefs
    }) 
    
    this.bbar= new Ext.PagingToolbar({
      pageSize: this.pageSize,
      store: this.store,
      displayInfo: true,
      displayMsg: 'Displaying {0} - {1} of {2}',
      emptyMsg: "Nothing to display",
      items: ['-', {
        text: 'Page Size',
        menu: {
          items: [
          '<b class="folder-grid-menu-title">Rows Per Page</b>',
          {
            text: '10',
            checked: (this.pageSize== 10),
            group: 'pageSize',
            checkHandler: this.updatePageSize.createDelegate(this, [10])
          },{
            text: '25',
            checked: (this.pageSize== 25),
            group: 'pageSize',
            checkHandler: this.updatePageSize.createDelegate(this, [25])
          }, {
            text: '50',
            checked: (this.pageSize== 50),
            group: 'pageSize',
            checkHandler: this.updatePageSize.createDelegate(this, [50])
          }, {
            text: '100',
            checked: (this.pageSize== 100),
            group: 'pageSize',
            checkHandler: this.updatePageSize.createDelegate(this, [100])
          }, {
            text: '250',
            checked: (this.pageSize== 250),
            group: 'pageSize',
            checkHandler: this.updatePageSize.createDelegate(this, [250])
          }, {
            text: '500',
            checked: (this.pageSize== 500),
            group: 'pageSize',
            checkHandler: this.updatePageSize.createDelegate(this, [500])
          }
          ]
        }
      }]
    })             
      
    this.addFilterPlugins(this.colModel.config)
    this.on('render', this.initializeDragDropZones.createDelegate(this))
    this.on('cellclick', this.cellClicked.createDelegate(this))
    Ext.grid.GridPanel.prototype.initComponent.call(this)   
  },
  initializeDragDropZones : function() {
    var parentPanel= this.parentPanel
    this.dropZone = new Ext.dd.DropZone(this.getEl(), {
      ddGroup :'favFolderDDGroup',
      dropAllowed :parentPanel.dropAllowed,
      grid :this,
      getTargetFromEvent : function(e) {
        var t = Ext.lib.Event.getTarget(e);
        if (t) {
          var rowIndex = this.grid.getView().findRowIndex(t);
          if (rowIndex !== false) {
            var sm = this.grid.selModel;
            if (!sm.isSelected(rowIndex) || e.hasModifier()) {
              sm.handleMouseDown(this.grid, rowIndex, e);
            }
            return {
              grid :this.grid,
              ddel :this.ddel,
              rowIndex :rowIndex,
              record :sm.getSelections()[0]
            };
          }
        }
        return false
      },
      onNodeOver : function(target, dd, e, data) {
        return parentPanel.isValidDrop(data, target)
      },
      onNodeDrop : function(target, dd, e, data) {
        return parentPanel.handleDrop(data, target)
      }
    });
    this.dragZone = new Ext.grid.GridDragZone(this, {
      ddGroup :'favFolderDDGroup',
      getDragData : function(e) {
        var t = Ext.lib.Event.getTarget(e);
        if (t) {
          var rowIndex = this.view.findRowIndex(t);
          if (rowIndex !== false) {
            var sm = this.grid.selModel;
            if (!sm.isSelected(rowIndex) || e.hasModifier()) {
              sm.handleMouseDown(this.grid, rowIndex, e);
            }
            if (sm.getSelections().length == 0) {
              return false
            } else if (sm.getSelections().length == 1) {
              var record = sm.getSelections()[0]
              if (!record || !record.data.id) {
                return false
              }
              return {
                grid :this.grid,
                favorites: true,
                ddel :this.ddel,
                rowIndex :rowIndex,
                record :record
              }
            } else if (sm.getSelections().length > 1) {
              return {
                grid :this.grid,
                favorites: true,
                ddel :this.ddel,
                rowIndex :rowIndex,
                record :sm.getSelections()
              }
            }
          }
        }
        return false;
      },
      onInitDrag : function(e) {
        var data = this.dragData;
        var dragRecords = data.record
        if (Ext.type(dragRecords) == 'object') {
          this.ddel.innerHTML = parentPanel.getNameAndIconMarkup(dragRecords)
        } else if (Ext.type(dragRecords) == 'array') {
          this.ddel.innerHTML = Ext.DomHelper.markup({
            tag :'span',
            unselectable :"on",
            style :"white-space: nowrap !important;",
            children :[{
              tag :'img',
              src :Ext.BLANK_IMAGE_URL,
              width :16,
              height :16,
              "class" :'multiple-dnd',
              style :"background-position: center center; background-repeat: no-repeat; border: 0 none; height: 16px; margin: 0; padding: 0; vertical-align: middle; width: 16px;"
            }, {
              tag :'span',
              unselectable :"on",
              style :"padding-left: 2px",
              html :dragRecords.length + ' selections'
            }]
          })
        } else {
          return
        }
        this.proxy.update(this.ddel);
      }
    });
  }, 
  /**
   * Change the page size of the grid
   */
  updatePageSize: function(pageSize) {
    var newPageSize= this.pageSize
    if (Ext.isNumber(pageSize)) {
      newPageSize= pageSize
    }
    if (newPageSize== this.pageSize) {
      return
    }
    var pbar= this.getBottomToolbar()
    this.pageSize= newPageSize
    pbar.pageSize= this.pageSize
    pbar.doLoad(0)
  },
  addFilterPlugins: function(colDefs) {
    if (Ext.isArray(colDefs)) {
      var filterSpec= []
      for(var i=0; i<colDefs.length; i++) {
        var colDef= colDefs[i]
        colDef.filterable= false
        if (colDef.dataIndex) {
          if (Ext.isObject(colDef.filterType) && colDef.filterType.options) {
            filterSpec.push({
              type: 'list',
              dataIndex: colDef.dataIndex,              
              options: colDef.filterType.options     
            })
          } else {
            filterSpec.push({
              type: (colDef.filterType== null ? 'string' :colDef.filterType),
              dateFormat: 'm/d/Y h:i:s A',
              dataIndex: colDef.dataIndex      
            })   
          }
          colDef.filterable= true
        }
      }
      if (filterSpec.length> 0) {
        if (!Ext.isArray(this.plugins)) {
          this.plugins= []
        }
        this.plugins.push(new Ext.ux.grid.GridFilters({        
          local: false,  
          filters: filterSpec
        })) 
      }
    }
  },
  filterBy: function(value, field) {
    if (Ext.isString(value) && hasLength(value)) {
      this.filters.clearFilters()
      var fieldFilter= this.filters.getFilter((field || 'name'))
      fieldFilter.setValue(value)
      fieldFilter.setActive(true)
    }
  },
  clearFilters: function() {
    this.filters.clearFilters()
  },
  refreshFolder: function() {
    this.store.setBaseParam("refresh", "true")
    //this.store.reload()
    var pbar= this.getBottomToolbar()
    pbar.doLoad(0)
    Ext.log('Refresh Folder!!')
    this.store.setBaseParam("refresh", "false")
  },  
  /**
   * Sets the items in the folder items grid and then setCurrentRecord and setCurrentDisplayedFolderRecord
   * 
   * @param {Object} record
   */
  setFolderItems : function(record, cb, scope) {
    if (!record) {
      cb.call(scope)
      return
    }
    this.getStore().setBaseParam('node', record.data.id)
    var reloadParams= {}
    var pbar= this.getBottomToolbar()
    if (pbar && pbar.getParams()) {
      var pn = pbar.getParams();
      reloadParams[pn.start] = 0
      reloadParams[pn.limit] = pbar.pageSize
    }  
    this.getStore().load({
      params: reloadParams,
      callback : function(r) {
        if (Ext.type(cb) == 'function') {
          cb.call(scope, record)
        }
      },
      scope :this
    })
  },
  cellClicked: function(grid, rowIndex, columnIndex, evt) {
    var record = this.getStore().getAt(rowIndex); 
    var fieldName = this.getColumnModel().getDataIndex(columnIndex); 
    if (fieldName== 'starred') {
      this.parentPanel.toggleStar(record)
    }
  }

})