/**
 * Provides a dialog to select Favorite folder.
 * @author jemcdowe
 *
 *
 */
AIG.Favorites.FavoriteFolderSelectorDialog = Ext.extend(Ext.Window, {
  width: 286,
  height: 352,
  layout: 'border',
  initComponent: function(){
    var win = this
    this.cacheID= new UUID()
    this.baseURL = '/aig/store.go?request=ITEMS&cacheID='+this.cacheID        
    this.tree = new AIG.Favorites.FavoriteFolderSelector({
      region: 'center',
      baseURL: this.baseURL
    })
    this.items = this.tree;
        
    var id = Ext.id()
    this.buttons = [{
      text: 'Make New Folder',
      handler: function(){
        var node = (win.tree.getSelectionModel().getSelectedNode() || win.tree.root)
        var record = new AIG.Favorites.FolderItemsRecord(node.attributes)
        AIG.Favorites.Util.handleCreateFolder(record, win.baseURL, function(record){
          var node = win.tree.getNodeById(record.data.id)
          node.expand()
          win.tree.reloadNode(node)
        }, this)
      },
      scope: this
    }, {
      text: 'OK',
      id: id,
      handler: function(){
        if (Ext.type(win.handler) == 'function') {
          var node = (win.tree.getSelectionModel().getSelectedNode() || win.tree.root)
          var record = new AIG.Favorites.FolderItemsRecord(node.attributes)
          win.handler.call(win.scope, {
            path: node.getPath('text'),
            path_ids: node.getPath(),
            folder_id: record.data.id
          })
          win.close()
        }
      }
    }, {
      text: 'Cancel',
      handler: function(){
        if (Ext.type(win.cancelHandler) == 'function') {
          win.cancelHandler.call(win.scope)
        }
        win.close()
      }
    }]
    this.defaultButton = id
        
    this.on('render', function(){
      if (this.path) {
        new Ext.util.DelayedTask().delay(100, function(){
          this.tree.selectPath(this.path)
        }, this)
      }
    }, this)
        
    AIG.Favorites.FavoriteFolderSelectorDialog.superclass.initComponent.call(this);
  }
});
