/**
 * @author jemcdowe
 */
AIG.QuickChartDialog = Ext.extend(Ext.Window, {
    width: 400,
    height: 400,
    modal: false,
    maximizable: true,
    layout: 'border',
    initComponent: function(){
        var dialog = this
        this.items = new  Ext.ux.ManagedIframePanel({
            region: 'center',
            defaultSrc: "/aig/jsp/quickchart.jsp?url="+ escape(this.url)+"&yaxis="+escape(this.yaxis)
        })
        this.buttons = [{
            text: 'Close',
            handler: function(){
                this.close()
            },
            scope: this
        }]
        AIG.QuickChartDialog.superclass.initComponent.call(this);
    }
});

