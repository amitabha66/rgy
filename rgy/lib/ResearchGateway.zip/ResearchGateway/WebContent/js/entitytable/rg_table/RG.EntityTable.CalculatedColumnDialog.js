/**
 * @author jemcdowe
 */
RG.EntityTable.CalculatedColumnDialog = Ext.extend(Ext.Window, {
    title: 'Create Calculated Column',
    width: 550,
    height: 558,
    layout: 'fit',
    modal: true,
    maximizable: true,
    iconCls: 'add-calc-column',
    initComponent: function(){
        var dialog = this
        
        var editor = (this.calcConfig != null && this.calcConfig.columnDataIndex != null)
        this.calcConfig = this.calcConfig ||
        {}
        
        this.setTitle((editor ? 'Update' : 'Create') + ' Calculated Column')
        this.groupFieldID = Ext.id()
        this.headerFieldID = Ext.id()
        this.columnGridID = Ext.id()
        this.tabPanelID = Ext.id()
        this.expressionCalculationFieldID = Ext.id()
        this.advCalculationFieldID = Ext.id()
        
        var cm = this.entityTable.getColumnModel()
        var groups = this.entityTable.getHeaderGroups()
        
        var columnData = []
        for (var i = 1; i < cm.getColumnCount(); i++) {
            var index = i
            var name = cm.getColumnHeader(i)
            var dataIndex = cm.getDataIndex(i)
            columnData.push([index, name, dataIndex])
        }
        
        var columnGroupData = []
        columnGroupData.push(["[default]", "0"])
        for (var i = 1; i < groups.length; i++) {
            var name = groups[i].header
            var dataIndex = groups[i].id
            var isEntityIDDataIndex = false
            if (this.entityTable.entityIDDataIndexes.length > 0) {
                var parentColumn = this.entityTable.getParentColumnForChildColumnDataIndex(this.entityTable.entityIDDataIndexes[0])
                
                if (parentColumn && parentColumn.id && parentColumn.id == dataIndex) {
                    isEntityIDDataIndex = true
                }
            }
            if (!isEntityIDDataIndex) {
                columnGroupData.push([name, dataIndex])
            }
        }
        
        var columnGroupStore = new Ext.data.SimpleStore({
            fields: [{
                name: 'group_header'
            }, {
                name: 'data_index'
            }]
        });
        columnGroupStore.loadData(columnGroupData);
        
        var columnStore = new Ext.data.SimpleStore({
            fields: [{
                name: 'column_number',
                type: 'int'
            }, {
                name: 'column_header'
            }, {
                name: 'data_index'
            }]
        });
        columnStore.loadData(columnData);
        
        
        
        if (editor) {
            this.calcConfig.expressionCalculationOrig = this.calcConfig.expressionCalculation
            this.calcConfig.advFunctionOrig = this.calcConfig.advFunction
            for (var i = 0; i < columnStore.getCount(); i++) {
                var columnRecord = columnStore.getAt(i)
                var columnName = "<" + columnRecord.data.column_header + "(" + columnRecord.data.column_number + ")>"
                
                this.calcConfig.expressionCalculationOrig = this.calcConfig.expressionCalculationOrig.split("<" + columnRecord.data.data_index + ">").join(columnName)
                this.calcConfig.advFunctionOrig = this.calcConfig.advFunctionOrig.split("<" + columnRecord.data.data_index + ">").join(columnName)
            }
            /*
             Would be nice to have this test- but may throw false positive errors
            var columnRegEx = new RegExp("(<[A-Za-z0-9\-]+>)")
            if (columnRegEx.test(this.calcConfig.expressionCalculationOrig)) {                
                var match = columnRegEx.$1
                this.on('render', function(){
                    new Ext.util.DelayedTask().delay(10, function(){
                        showErrorDialog("Script Error", "There appears to be an error in the script.<BR>" +
                        "This is likely due to a reference to a deleted column.")
                    })
                    this.un("render", arguments.callee)
                }, this)
            } else if (columnRegEx.test(this.calcConfig.advFunctionOrig)) {
                this.on('render', function(){
                    new Ext.util.DelayedTask().delay(10, function(){
                        showErrorDialog("Script Error", "There appears to be an error in the script.<BR>" +
                        "This is likely due to a reference to a deleted column.")
                    })
                    this.un("render", arguments.callee)
                }, this)
            }
            */
            
            
        }
        this.buttons = [{
            text: (editor ? 'Update' : 'OK'),
            handler: function(){
                if (Ext.type(this.cb) == 'function') {
                    var calcConfig = this.getCalculationConfig()
                    var calcFormat = this.calcFormat
                    var editor = (this.calcConfig != null && this.calcConfig.columnDataIndex != null)
                    if (editor) {
                        calcConfig.columnDataIndex = this.calcConfig.columnDataIndex
                    }
                    
                    if (!hasLength(calcConfig.header)) {
                        showErrorDialog("Required Field(s) Missing", "Please Specify the Column Header")
                        return
                    }
                    var calculationType = calcConfig.calculationType
                    
                    if (calculationType == 'EXPRESSION' && !hasLength(calcConfig.expressionCalculationOrig)) {
                        showErrorDialog("Required Field(s) Missing", "Please Provide the Calculation")
                        return
                    }
                    if (calculationType == 'ADVANCED' && !hasLength(calcConfig.advFunctionOrig)) {
                        showErrorDialog("Required Field(s) Missing", "Please Provide the Function Body")
                        return
                    }
                    //Quick test for JS errors
                    dialog.showMask("Compiling script")
                    Ext.Ajax.request({
                        url: this.entityTable.sourceURL,
                        success: function(response, options){
                            dialog.hideMask()
                            var updatedConfig = null
                            try {
                                updatedConfig = Ext.util.JSON.decode(response.responseText)
                            } catch (e) {
                                return
                            }
                            if (updatedConfig.scriptError) {
                                showErrorDialog("Script Error", updatedConfig.scriptError)
                                return
                            }
                            this.close()
                            this.cb.call(this.scope, calcConfig, this.calcFormat)
                        },
                        failure: function(response, options){
                            dialog.hideMask()
                            showErrorDialog("Error communicating with RG", response.responseText)
                        },
                        params: {
                            op: 'evaluatecalculatedcolumn',
                            calccolumn_config: Ext.util.JSON.encode(calcConfig)
                        },
                        scope: this
                    })
                }
            },
            scope: this
        }, {
            text: 'Cancel',
            handler: function(){
                this.close()
            },
            scope: this
        }]
        
        this.items = {
            layout: 'border',
            hideBorders: false,
            items: [{
                xtype: 'panel',
                region: 'north',
                width: 100,
                layout: 'column',
                height: 70,
                autoScroll: true,
                frame: true,
                labelWidth: 125,
                items: [{
                    xtype: 'panel',
                    layout: 'form',
                    autoScroll: true,
                    tpl: '',
                    labelAlign: 'top',
                    frame: false,
                    width: 225,
                    items: [{
                        xtype: 'combo',
                        id: this.groupFieldID,
                        fieldLabel: 'Add To or Create New Column Group',
                        hiddenField: 'group',
                        anchor: '100%',
                        mode: 'local',
                        typeAhead: false,
                        triggerAction: 'all',
                        displayField: 'group_header',
                        valueField: 'data_index',
                        store: columnGroupStore,
                        value: this.calcConfig.groupIndex || 0,
                        forceSelection: false,
                        disabled: editor
                    }]
                }, {
                    xtype: 'panel',
                    columnWidth: 0.8,
                    layout: 'fit',
                    html: '&nbsp;'
                }, {
                    xtype: 'panel',
                    layout: 'form',
                    autoScroll: true,
                    labelAlign: 'top',
                    frame: false,
                    width: 250,
                    items: [{
                        xtype: 'textfield',
                        id: this.headerFieldID,
                        fieldLabel: 'New Column Header',
                        anchor: '100%',
                        width: 200,
                        value: this.calcConfig.header
                    }]
                }]
            }, {
                xtype: 'panel',
                title: 'Create Calculation',
                region: 'center',
                width: 100,
                layout: 'border',
                items: [{
                    xtype: 'grid',
                    id: this.columnGridID,
                    //title: 'Columns (double-click to add)',
                    store: columnStore,
                    height: 150,
                    region: 'center',
                    disableExportMenu: true,
                    viewConfig: {
                        forceFit: true
                    },
                    columns: [{
                        xtype: 'numbercolumn',
                        header: '#',
                        sortable: true,
                        resizable: true,
                        width: 10,
                        format: '0',
                        align: 'left',
                        dataIndex: 'column_number'
                    }, {
                        xtype: 'gridcolumn',
                        header: 'Columns (double-click to add)',
                        sortable: true,
                        resizable: true,
                        width: 100,
                        dataIndex: 'column_header'
                    }],
                    listeners: {
                        rowdblclick: function(grid, rowIndex, evt){
                            var store = grid.getStore()
                            dialog.addColumnToCalculation(store.getAt(rowIndex))
                        }
                    }
                }, {
                    xtype: 'tabpanel',
                    id: this.tabPanelID,
                    activeTab: (this.calcConfig.calculationType && this.calcConfig.calculationType === 'ADVANCED' ? 1 : 0),
                    region: 'south',
                    height: 300,
                    split: true,
                    tbar: [{
                        icon: '/aig/img/entitytable_method.png',
                        iconCls: 'x-btn-text-icon',
                        tooltip: 'Add a method to the calculation',
                        handler: function(){
                            new RG.EntityTable.CalculatedColumnMethods({
                                sourceURL: this.entityTable.sourceURL,
                                cb: function(methodRecord){
                                    this.addMethodToCalculation(methodRecord)
                                },
                                scope: dialog
                            }).show()
                        },
                        scope: dialog
                    }, {
                        icon: '/aig/img/column_format.gif',
                        iconCls: 'x-btn-text-icon',
                        tooltip: 'Define the format of the calculated column',
                        handler: function(){
                            new RG.EntityTable.ColumnFormatDialog({
                                initFormat: this.calcFormat,
                                cb: function(column, type, format){
                                    this.calcFormat = {
                                        type: type,
                                        format: format
                                    }
                                },
                                scope: dialog
                            }).show()
                        },
                        scope: dialog
                    }],
                    items: [{
                        xtype: 'panel',
                        title: 'Expression',
                        layout: 'fit',
                        items: [{
                            xtype: 'form',
                            labelWidth: 100,
                            labelAlign: 'top',
                            layout: 'border',
                            frame: false,
                            items: [{
                                xtype: 'textarea',
                                region: 'center',
                                split: true,
                                emptyText: 'Enter Expression',
                                autoCreate: {
                                    tag: "textarea",
                                    style: "width:100px;height:60px;",
                                    autocomplete: "off",
                                    spellcheck: false
                                },
                                id: this.expressionCalculationFieldID,
                                fieldLabel: 'Expression',
                                style: {
                                    fontFamily: 'monospace'
                                },
                                anchor: '100%',
                                height: 140,
                                value: this.calcConfig.expressionCalculationOrig
                            }]
                        }]
                    }, {
                        xtype: 'panel',
                        title: 'Advanced',
                        layout: 'fit',
                        items: [{
                            xtype: 'form',
                            labelWidth: 100,
                            labelAlign: 'top',
                            layout: 'border',
                            frame: false,
                            items: [{
                                xtype: 'textarea',
                                region: 'center',
                                split: true,
                                emptyText: 'Enter Function Body',
                                autoCreate: {
                                    tag: "textarea",
                                    style: "width:100px;height:60px;",
                                    autocomplete: "off",
                                    spellcheck: false
                                },
                                id: this.advCalculationFieldID,
                                fieldLabel: 'Function Body',
                                style: {
                                    fontFamily: 'monospace'
                                },
                                anchor: '100%',
                                height: 140,
                                //width: 300,
                                hideLabel: false,
                                
                                //xtype: 'codepress',
                                //language: 'javascript',
                                
                                value: this.calcConfig.advFunctionOrig
                            }]
                        }]
                    }]
                }]
            }]
        }
        RG.EntityTable.CalculatedColumnDialog.superclass.initComponent.call(this);
    },
    getCalculationConfig: function(){
        var columnStore = Ext.getCmp(this.columnGridID).getStore()
        
        var expressionCalculation = Ext.getCmp(this.expressionCalculationFieldID).getValue() || ""
        var advFunction = Ext.getCmp(this.advCalculationFieldID).getValue() || ""
        for (var i = 0; i < columnStore.getCount(); i++) {
            var columnRecord = columnStore.getAt(i)
            var columnName = "<" + columnRecord.data.column_header + "(" + columnRecord.data.column_number + ")>"
            
            expressionCalculation = expressionCalculation.split(columnName).join("<" + columnRecord.data.data_index + ">")
            advFunction = advFunction.split(columnName).join("<" + columnRecord.data.data_index + ">")
        }
        var calculationType = Ext.getCmp(this.tabPanelID).getActiveTab().title.toUpperCase()
        
        var groupHeaderBox = Ext.getCmp(this.groupFieldID)
        groupHeaderBox.doQuery(this.allQuery, true)
        var selection = groupHeaderBox.store.find('group_header', groupHeaderBox.getRawValue())
        var groupHeaderDataIndex = (selection >= 0 ? groupHeaderBox.store.getAt(selection).data.data_index : null)
        
        return {
            group: Ext.getCmp(this.groupFieldID).getRawValue(),
            groupIndex: groupHeaderDataIndex,
            header: Ext.getCmp(this.headerFieldID).getValue(),
            calculationType: calculationType,
            expressionCalculationOrig: Ext.getCmp(this.expressionCalculationFieldID).getValue(),
            advFunctionOrig: Ext.getCmp(this.advCalculationFieldID).getValue(),
            expressionCalculation: expressionCalculation,
            advFunction: advFunction
        }
    },
    
    addMethodToCalculation: function(methodRecord){
        var calcConfig = this.getCalculationConfig()
        var calcField = null
        var field = null
        switch (calcConfig.calculationType) {
            case "EXPRESSION":
                field = Ext.getCmp(this.expressionCalculationFieldID)
                break
            case "ADVANCED":
                field = Ext.getCmp(this.advCalculationFieldID)
                break
            default:
                return
        }
        if (!field) {
            return
        }
        if (!hasLength(calcConfig.header)) {
            Ext.getCmp(this.headerFieldID).setValue(methodRecord.method_label)
        }
        var method = methodRecord.method_group + "." + methodRecord.method_name + "()"
        field.preFocus()
        field.insertAtCursor(method, -1)
    },
    addColumnToCalculation: function(columnRecord){
        var calcConfig = this.getCalculationConfig()
        var columnName = "<" + columnRecord.data.column_header + "(" + columnRecord.data.column_number + ")>"
        var field = null
        switch (calcConfig.calculationType) {
            case "EXPRESSION":
                field = Ext.getCmp(this.expressionCalculationFieldID)
                break
            case "ADVANCED":
                field = Ext.getCmp(this.advCalculationFieldID)
                break
            default:
                return
        }
        field.preFocus()
        field.insertAtCursor(columnName, 0)
    },
    showMask: function(msg){
        if (this.loadMask != null) {
            this.loadMask.hide()
        }
        this.loadMask = new Ext.LoadMask(this.getEl(), {
            msg: msg
        })
        this.loadMask.show()
    },
    hideMask: function(){
        if (this.loadMask != null) {
            this.loadMask.hide()
            this.loadMask = null
        }
    }
    
});


RG.EntityTable.CalculatedColumnMethods = Ext.extend(Ext.Window, {
    title: 'Methods Available- Double-Click To Add To Formula',
    width: 500,
    height: 400,
    layout: 'border',
    modal: false,
    maximizable: true,
    iconCls: 'titleicon-question',
    initComponent: function(){
        var dialog = this
        
        this.buttons = [{
            text: 'Close',
            handler: function(){
                this.ownerCt.close()
            }
        }]
        this.items = [{
            xtype: 'grid',
            region: 'center',
            store: new Ext.data.GroupingStore({
                url: this.sourceURL,
                baseParams: {
                    op: 'getavailablemethods'
                },
                groupField: 'method_group',
                sortInfo: {
                    field: 'method_name',
                    direction: "ASC"
                },
                reader: new Ext.data.JsonReader({
                    root: "methods"
                }, [{
                    name: 'method_name'
                }, {
                    name: 'method_label'
                }, {
                    name: 'method_group'
                }, {
                    name: 'method_description'
                }, {
                    name: 'method_parmeter_list'
                }, {
                    name: 'method_help'
                }]),
                autoLoad: true
            }),
            autoScroll: true,
            hideHeaders: false,
            enableHdMenu: false,
            enableColumnHide: false,
            enableColumnMove: false,
            frame: false,
            border: false,
            height: 90,
            disableExportMenu: true,
            view: new Ext.grid.GroupingView({
                forceFit: true,
                showGroupName: false
                //groupTextTpl: '{text} ({[values.rs.length]} {[values.rs.length > 1 ? "Items" : "Item"]})'
            }),
            columns: [{
                xtype: 'gridcolumn',
                header: 'Methods (double-click to add)',
                sortable: true,
                resizable: true,
                menuDisabled: true,
                width: 75,
                dataIndex: 'method_name'
            
            }, {
                xtype: 'gridcolumn',
                header: 'Group',
                sortable: true,
                resizable: true,
                hidden: true,
                dataIndex: 'method_group'
            
            }, {
                xtype: 'gridcolumn',
                id: 'other-nowrap',
                header: 'Description',
                sortable: true,
                resizable: true,
                menuDisabled: true,
                dataIndex: 'method_description',
                renderer: function(value, md, record){
                    var dom = {
                        tag: 'div',
                        "ext:qtip": Ext.util.Format.htmlEncode(value),
                        style: 'cursor: hand;text-decoration: underline',
                        html: value
                    }
                    return Ext.DomHelper.markup(dom)
                }
            }],
            listeners: {
                rowdblclick: function(grid, rowIndex, evt){
                    var store = grid.getStore()
                    if (Ext.type(dialog.cb) == 'function') {
                        var record = store.getAt(rowIndex)
                        if (record) {
                            dialog.cb.call(dialog.scope, {
                                method_label: record.data.method_label,
                                method_group: record.data.method_group,
                                method_name: record.data.method_name
                            })
                        }
                    }
                    dialog.close()
                },
                cellclick: function(grid, rowIndex, columnIndex, evt){
                    var store = grid.getStore()
                    var record = store.getAt(rowIndex)
                    if (columnIndex != 2) {
                        return
                    }
                    var helpHtml = record.data.method_help || ""
                    
                    var help = {
                        tag: 'table',
                        cellpadding: '5',
                        cellspacing: '10',
                        children: [{
                            tag: 'tr',
                            children: [{
                                tag: 'td',
                                children: [{
                                    tag: 'div',
                                    style: 'font: bold 12px tahoma, arial, helvetica, sans-serif;border-bottom: solid 1px black',
                                    html: 'Method'
                                }]
                            }]
                        }, {
                            tag: 'tr',
                            children: [{
                                tag: 'td',
                                children: [{
                                    tag: 'div',
                                    style: 'font: normal 11px tahoma, arial, helvetica, sans-serif;',
                                    html: record.data.method_group + "." + record.data.method_name + "(" + (hasLength(record.data.method_parmeter_list) ? "<code>" + record.data.method_parmeter_list + "</code>" : "") + ")"
                                }]
                            }]
                        }, {
                            tag: 'tr',
                            children: [{
                                tag: 'td',
                                children: [{
                                    tag: 'div',
                                    style: 'font: bold 12px tahoma, arial, helvetica, sans-serif;border-bottom: solid 1px black',
                                    html: 'Description'
                                }]
                            }]
                        }, {
                            tag: 'tr',
                            children: [{
                                tag: 'td',
                                children: [{
                                    tag: 'div',
                                    style: 'font: normal 11px tahoma, arial, helvetica, sans-serif;',
                                    html: record.data.method_description
                                }]
                            }]
                        }, {
                            tag: 'tr',
                            children: [{
                                tag: 'td',
                                children: [{
                                    tag: 'div',
                                    style: 'font: bold 12px tahoma, arial, helvetica, sans-serif;border-bottom: solid 1px black',
                                    html: 'Details'
                                }]
                            }]
                        }, {
                            tag: 'tr',
                            children: [{
                                tag: 'td',
                                children: [{
                                    tag: 'div',
                                    style: 'font: normal 11px tahoma, arial, helvetica, sans-serif;',
                                    html: record.data.method_help
                                }]
                            }]
                        }]
                    }
                    new Ext.Window({
                        title: 'Method Help',
                        width: 400,
                        height: 400,
                        layout: 'fit',
                        modal: false,
                        maximizable: true,
                        iconCls: 'titleicon-question',
                        buttons: [{
                            text: 'Close',
                            handler: function(){
                                this.ownerCt.close()
                            }
                        }],
                        items: {
                            layout: 'border',
                            hideBorders: false,
                            items: {
                                xtype: 'panel',
                                region: 'center',
                                autoScroll: true,
                                html: help
                            }
                        }
                    }).show()
                }
            }
        }]
        RG.EntityTable.CalculatedColumnMethods.superclass.initComponent.call(this);
    }
})
