
/**
 * EntityTable class
 * 
 * @author jemcdowe
 */
RG.EntityTable.Grid = Ext.extend(Ext.grid.EditorGridPanel, {
  initComponent : function() {
    var me= this
    Ext.apply(this, {
      region: 'center',
      stripeRows:true,
      disableExportMenu: true,
      rowHeight: this.rowHeight.makeDivisible(5),
      refreshCounter :0
    })
    this.setTableConfig(this.tableConfig || {})
    
    this.addEvents('columndeleted', 'cellover', 'cellout')
    
    this.viewConfig = {
      templates :{
        cell :new Ext.Template(
          '<td class="x-grid3-col x-grid3-cell x-grid3-td-{id} x-selectable {css}" style="{style}" tabIndex="0" {cellAttr}>',
          '<div class="x-grid3-cell-inner x-grid3-col-{id}" {attr}>{value}</div>',
          '</td>')
      },
      getCell : function(row, col) {
        var row = this.getRow(row)
        return row.getElementsByTagName('table')[0].rows[0].cells[col]
      },
      cellSelectorDepth :20,
      onLoad :Ext.emptyFn,
      listeners :{
        beforerefresh : function(v) {
          v.scrollTop = v.scroller.dom.scrollTop;
          v.scrollHeight = v.scroller.dom.scrollHeight;
        },
        refresh : function(v) {
          // v.scroller.dom.scrollTop = v.scrollTop;
          v.scroller.dom.scrollTop = v.scrollTop + (v.scrollTop == 0 ? 0 : v.scroller.dom.scrollHeight - v.scrollHeight);
        }
      }
    }

    this.listeners = {
      headercontextmenu : function(grid, columnIndex, evt) {
        grid.showHeaderContextMenu(grid, columnIndex, evt)
      },
      /**
       * afteredithandler- Update the model with a new value
       * 
       * @param {Object} evt
       */
      afteredit : function(evt) {
        var grid = evt.grid
        var dataIndex = evt.field
        var row = evt.row
        var value = evt.value
        Ext.Ajax.request({
          url :grid.sourceURL,
          success : function(response, options) {
          },
          failure : function(response, options) {
            showErrorDialog("Data Update Failed", response.responseText)
          },
          params :{
            op :'updateeditablecellvalue',
            pagedRowIndex :row,
            columnDataIndex :dataIndex,
            value :value
          }
        })
      },
      cellclick : function(grid, row, col, evt) {
        grid.cellSelection(grid, row, col, evt)
      },
      cellcontextmenu : function(grid, rowIndex, columnIndex, evt) {
        grid.handleCellContextMenu({
          grid :grid,
          rowIndex :rowIndex,
          columnIndex :columnIndex,
          event :evt
        })
      },
      columnmove : function(oldIndex, newIndex) {
        this.handleColumnViewConfigChange()        
      },
      columngroupmove : function(data) {
        this.handleColumnViewConfigChange()
      },
      columnresize : function(columnIndex, newSize) {
        this.handleColumnViewConfigChange()
      },
      columndeleted : function() {
        this.handleColumnViewConfigChange()
      },
      columnhidden : function() {
        this.handleColumnViewConfigChange()
      },
      resize: function(grid, aW, aH, oW, oH) {
        grid.getTopToolbar().toggleDisplayInfo(aW)      
      },
      mouseover: function (e, t) {
        var rowIndex = me.getView().findRowIndex(t);
        var cellIndex = me.getView().findCellIndex(t);

        if (rowIndex !== false && cellIndex !== false) {
          var cell = me.getView().getCell(rowIndex, cellIndex);
          me.fireEvent('cellover', rowIndex, cellIndex, cell)
        }
      },
      mouseout: function (e, t) {
        //Ext.log('out')
        var rowIndex = me.getView().findRowIndex(t);
        var cellIndex = me.getView().findCellIndex(t);
        var cell= null
        if (rowIndex !== false && cellIndex !== false) {
          cell = me.getView().getCell(rowIndex, cellIndex);
        }
        me.fireEvent('cellout', rowIndex, cellIndex, cell)
      },
      headerclick: function(grid, columnIndex) {
        if (columnIndex== 0) {
          var cm = grid.getColumnModel()    
          var column= cm.getColumnById(cm.getColumnId(0))
          column.headerClicked()
          return
        }
      }
    }

    this.ddServiceStore = new Ext.data.Store({
      // load using HTTP
      url :'/aig/entitytabledrilldownservicelookup.go?entityTableKey=' + this.entityTableKey,
      listeners :{
        loadexception : function(store, options, error) {
          aigErrorHandler(error)
        }
      },
      // the return will be XML, so lets set up a reader
      reader :new Ext.data.XmlReader({
        // records will have an "Service" tag
        record :'Service',
        id :'ServiceKey'
      }, ['Name', {
        name :'Default',
        type :'boolean'
      }, 'Organization', 'Contact', 'Description'])
    })

    var store = new Ext.data.Store({
      url :this.sourceURL,
      autoLoad :true,
      remoteSort :true,
      reader :new Ext.data.JsonReader({
        root :this.root,
        totalProperty :this.totalProperty
      }, this.fields.concat('entity_id'))
    })
    var colModel= this.createColumnModel(this.columngroups)
    
    Ext.applyIf(this, {
      // autoWidth: true,
      //autoExpandColumn :this.columns[1].dataIndex,
      sm :new Ext.grid.CellSelectionModel(),
      store :store,
      colModel: colModel,
      tbar :new RG.EntityTable.Toolbar({
        pageSize :this.pageSize,
        store :store,
        displayInfo :true,
        displayMsg :'{0} - {1} of {2}',
        grid :this,
        minWidthToDisplayInfo: 880
      }),
      plugins :[colModel.columnHeaderGroup]
    })
    Ext.apply(this, {
      keys: [{
        key: '4',
        ctrl:true,
        fn: function(){
          this.runStructureDetailsColumns()
        },
        scope: this
      }, {
        key: '5',
        ctrl:true,
        fn: function(){
        }
      }, {
        key: '6',
        //ctrl:true,
        fn: function(){
          this.handleImport()
        },
        scope: this
      }
      ]
    })

    RG.EntityTable.Grid.superclass.initComponent.call(this);

  },
  createColumnModel: function(columnGroups) {    
    var columnSorterFn= function(a1, a2) {
      var index1= Ext.data.SortTypes.asInt(a1.index)
      var index2= Ext.data.SortTypes.asInt(a2.index)
      return (index1 > index2 ? 1 : (index1 < index2 ? -1 : 0))      
    }
        
    var columnGroupsCollection= new Ext.util.MixedCollection()
    columnGroupsCollection.addAll(columnGroups)   

    columnGroupsCollection.sort('ASC', columnSorterFn)  
    var rowNumberColumn= new RG.EntityTable.PagedRowNumberer({
      grid: this
    })
    this.columns= [rowNumberColumn]
    var colDefs= []
    colDefs.push({
      header: "&nbsp;",
      align: 'center',
      colDefs: [rowNumberColumn],
      colspan: 1
    })
    for(var i=0; i< columnGroupsCollection.getCount(); i++) {
      var columnGroup= columnGroupsCollection.get(i)
      var columnCollection= new Ext.util.MixedCollection()
      columnCollection.addAll(columnGroup.columns)      
      columnCollection.sort('ASC', columnSorterFn)  
      var group= []
      for(var j=0; j< columnCollection.getCount(); j++) {
        var column= columnCollection.get(j)
        column.renderer = RG.EntityTable.CellRenderer.createDelegate(this)
        column.tipRenderer = RG.EntityTable.TipRenderer.createDelegate(this)
        column.sortable= true
        if (column.type == 'subtable') {
          column.style = 'padding: 0px 0px 0px 0px !important;padding-left: 0 !important;padding-right: 0 !important;'
        }        
        if (column.editable) {
          column.editor = new Ext.form.TextField()
        }        
        group.push(column)
        this.columns.push(column)
      }
      colDefs.push({
        header: columnGroup.header,
        align: columnGroup.align,
        colDefs: group,
        colspan: columnGroup.colspan
      })  
    }
    var columnHeaderGroup= new Ext.ux.grid.ColumnHeaderGroup({
      rows: [colDefs]
    })        
    return new Ext.grid.ColumnModel({
      columns :this.columns,
      columnHeaderGroup: columnHeaderGroup,
      defaults:{
        sortable: true
      },
      columnMoveNoEvent : function(oldIndex, newIndex) {
        var c = this.config[oldIndex];
        this.config.splice(oldIndex, 1);
        this.config.splice(newIndex, 0, c);
        this.dataMap = null;
      },
      listeners :{
        hiddenchange : function(cm, columnIndex, hidden) {
          var viewport = Ext.getCmp("enttable-viewport")
          var entityTable = viewport.getComponent(0)
          entityTable.fireEvent('columnhidden', cm, columnIndex, hidden)
        }
      }
    })    
  },
  onRender : function(ct, position) {
    RG.EntityTable.Grid.superclass.onRender.call(this, ct, position);
    this.drillDownWindowMgr = new AIG.DrillDownWindowManager({
      parentContainer :this
    })
    this.tip = new RG.EntityTable.ToolTip({
      grid :this,
      view :this.getView(),
      target :this.getView().mainBody,
      trackMouse :true,
      renderTo :document.body,
      listeners :{
        beforeshow : function updateTipBody(tip) {
          try {
            var grid = tip.grid
            var columnId = grid.getColumnModel().getColumnId(tip.sourceTarget.col)
            var fieldName = grid.getColumnModel().getDataIndex(tip.sourceTarget.col);
            var columnModel = grid.getColumnModel().getColumnById(columnId)
            var record = grid.getStore().getAt(tip.sourceTarget.row)

            if (Ext.type(columnModel.tipRenderer) == 'function') {
              var content = columnModel.tipRenderer.call(grid, record, tip.sourceTarget.row, tip.sourceTarget.col, tip.sourceTarget.subTableCell, grid.getStore())
              if (content) {
                tip.body.dom.innerHTML = content
                return true
              }
            }
          } catch (e) {
          }
          return false
        }
      }
    })
      
  },
  reconfigure : function(config) {
    Ext.apply(this, config)
    this.sourceURL = config.sourceURL
    if (config.tableConfig) {
      this.setTableConfig(config.tableConfig)
    }
    var store = new Ext.data.Store({
      url :config.sourceURL,
      autoLoad :true,
      remoteSort :true,
      reader :new Ext.data.JsonReader({
        root :config.root,
        totalProperty :config.totalProperty
      }, config.fields.concat('entity_id'))
    })
    var colModel= this.createColumnModel(config.columngroups)
    /*
    Ext.each(config.columns, function(column) {
      column.renderer = RG.EntityTable.CellRenderer.createDelegate(this)
      column.tipRenderer = RG.EntityTable.TipRenderer.createDelegate(this)
      if (column.type == 'subtable') {
        column.style = 'padding: 0px 0px 0px 0px !important;padding-left: 0 !important;padding-right: 0 !important;'
      }
    }, this)
    var c = [new Ext.grid.PagedRowNumberer()]
    config.columns = c.concat(config.columns)
    var h = [{
      "header" :"&nbsp;",
      "colspan" :1
    }]
    config.headers[0] = h.concat(config.headers[0])

    Ext.each(config.columns, function(column) {
      if (column.dataIndex) {
        var idx = this.getColumnModel().findColumnIndex(column.dataIndex)
        if (idx && idx >= 0) {
          if (this.getColumnModel().isHidden(idx)) {
            column.hidden = true
          }
          if (this.getColumnModel().getColumnWidth(idx)) {
            var prevWidth = this.getColumnModel().getColumnWidth(idx)
            column.width = (column.width ? column.width : prevWidth)
          }
        }
      }
      if (column.editable) {
        column.editor = new Ext.form.TextField()
      }
    }, this)
    var colModel = new Ext.grid.ColumnModel({
      columns :config.columns,
      defaultSortable :true,
      rows :config.headers
    })
    */
    if (this.rowHeight) {
      this.rowHeight = this.rowHeight.makeDivisible(5)
    }
    this.getTopToolbar().rowHeight.syncWithGrid()
    //this.plugins[0]= colModel.columnHeaderGroup
    //this.plugins[0].init(this)
    Ext.applyIf(colModel, colModel.columnHeaderGroup.config);
    Ext.apply(this.getView(), colModel.columnHeaderGroup.viewConfig)

    RG.EntityTable.Grid.superclass.reconfigure.call(this, store, colModel)
    this.getTopToolbar().bind(store)
    this.doLayout()
  },
  setTableConfig : function(tableConfig) {
    this.tableConfig = Ext.applyIf(tableConfig, {
      enableDDLoading :true
    })
    return this.tableConfig
  },
  /**
   * Updates the midtier model regarding changes to the column order
   * 
   */
  handleColumnViewConfigChange : function() {
    var columnGroupConfigs = this.getColumnViewConfig()
    Ext.Ajax.request({
      url :this.sourceURL,
      success : function(response, options) {
      },
      failure : function(response, options) {
      },
      params :{
        op :'resetviewconfig',
        column_configs :Ext.util.JSON.encode({
          column_groups :columnGroupConfigs
        }),
        table_config :Ext.util.JSON.encode(this.tableConfig)
      },
      scope: this
    })
  },
  rowSelectionsUpdated: function(record, selected) {
    var entityID= record.get("entity_id")
    var selections= this.tableConfig.rowSelections || {}
    if (selected) {
      selections[entityID]= true
    } else {
      delete selections[entityID]
    }
  },
  createSubTable:function() {
    var cm = this.getColumnModel()
    var column= cm.getColumnById(cm.getColumnId(0))
    var selections= column.selections
    var entityIDs= []
    selections.eachKey(function(id) {
      entityIDs.push(id)
    })
    top.RG.Load.createSubtable(this.entityTableKey, entityIDs)
  },
  /**
   * Updates the midtier model regarding changes to the column order
   * 
   */
  getColumnViewConfig : function() {
    var columnGroupConfigs = []
    var groups = this.getHeaderGroups()
    var cm = this.getColumnModel()

    var columnIndex = 1

    for ( var i = 1; i < groups.length; i++) {
      var columnGroupConfig = {
        index :i-1, //groups[i].id,
        header :groups[i].header,
        colspan :groups[i].colspan,
        column_configs :[]
      }
      for ( var j = 0; j < columnGroupConfig.colspan; j++) {
        var cIndex = columnIndex++
        var columnId = cm.getColumnId(cIndex)
        var column_config = {}
        columnGroupConfig.column_configs.push(column_config)
        var column = cm.getColumnById(columnId)
        for (var name in column) {
          if (Ext.type(column[name]) && Ext.type(column[name]) != 'object') {
            column_config[name] = column[name]
          }
        }
        column_config.index= j
      }
      columnGroupConfigs.push(columnGroupConfig)
    }        
    return columnGroupConfigs
  },
  runAddColumnService : function(config) {
    if (!config.serviceKey) {
      return
    }
    var params = {}
    if (config.serviceParams) {
      for ( var key in config.serviceParams) {
        params[key] = config.serviceParams[key]
      }
    }
    params.serviceKey = config.serviceKey
    var transactionID = null
    var progressBox = Ext.Msg.show({
      title :'Adding Columns',
      msg :'Running...',
      progressText :config.serviceName,
      buttons :Ext.Msg.CANCEL,
      closable :false,
      wait :true,
      modal :true,
      minWidth :250,
      fn : function(buttonID, text) {
        if (transactionID && Ext.Ajax.isLoading(transactionID)) {
          progressBox.updateProgress(0, ' ', '')
          Ext.Ajax.abort(transactionID)
        }
      }
    })
    transactionID = Ext.Ajax.request({
      url :this.sourceURL,
      success : function(response, options) {
        progressBox.updateProgress(0, ' ', '')
        progressBox.hide()
        
        if (!showResponseError(response, 'Failed to Add Columns')) {
          var updatedConfig = Ext.util.JSON.decode(response.responseText)
          if (updatedConfig.noResults) {
            Ext.Msg.alert('Add Column', 'No results returned.')
          } else {
            AIG.reloadEntityTable(updatedConfig)
          }
        }
      },
      failure : function(response, options) {
        progressBox.updateProgress(0, ' ', '')
        progressBox.hide()
        showErrorDialog("Service Call Failed", response.responseText)
      },
      params :params
    })
  },
  runStructureDetailsColumns: function() {
    var transactionID = null
    var progressBox = Ext.Msg.show({
      title :'Adding Structure Properties',
      msg :'Running...',
      buttons :Ext.Msg.CANCEL,
      closable :false,
      wait :true,
      modal :true,
      minWidth :250,
      fn : function(buttonID, text) {
        if (transactionID && Ext.Ajax.isLoading(transactionID)) {
          progressBox.updateProgress(0, ' ', '')
          Ext.Ajax.abort(transactionID)
        }
      }
    })
    transactionID = Ext.Ajax.request({
      url :this.sourceURL,
      success : function(response, options) {
        progressBox.updateProgress(0, ' ', '')
        progressBox.hide()        
        if (!showResponseError(response, 'Failed to Add Columns')) {
          var updatedConfig = Ext.util.JSON.decode(response.responseText)
          if (updatedConfig.noResults) {
            Ext.Msg.alert('Add Column', 'No results returned.')
          } else {
            AIG.reloadEntityTable(updatedConfig)
          }
        }
      },
      failure : function(response, options) {
        progressBox.updateProgress(0, ' ', '')
        progressBox.hide()
        showErrorDialog("Service Call Failed", response.responseText)
      },
      params :{
        op: "ADDSTRUCTUREDETAILS"
      }
    })  
  },
  /**
   * Returns the parent header at a given child column index
   * 
   * @param {Object} col
   */
  getParentHeader : function(columnIndex) {
    var cm = this.getColumnModel()
    var row = 0
    var r = cm.rows[row];
    if (r) {
      for ( var i = 0, gcol = 0, len = r.length; i < len; i++) {
        var group = r[i];
        if (columnIndex >= gcol && columnIndex < gcol + group.colspan) {
          return {
            col :gcol,
            colspan :group.colspan,
            header :group.header,
            id :group.id
          };
        }
        gcol += group.colspan;
      }
      return {
        col :gcol,
        colspan :0,
        id :null
      };
    }
    return {
      col :col,
      colspan :1,
      id :null
    };
  },
  /**
   * Returns a Column object representing the Parent column for a given child
   * 
   * @param {Object} dataIndex
   */
  getParentColumnForChildColumnDataIndex : function(dataIndex) {
    var columnIndex = this.getColumnModel().findColumnIndex(dataIndex)
    return this.getParentHeader(columnIndex)
  },
  getHeaderGroups : function() {
    var cm = this.getColumnModel()
    var groups = []
    var r = cm.rows[0];
    if (r) {
      for ( var i = 0, len = r.length; i < len; i++) {
        groups.push(r[i])
      }
    }
    return groups
  },
  resetSortState : function() {
    if (this.store.sortInfo) {
      var sortColumn = this.getColumnModel().findColumnIndex(this.store.sortInfo.field)
      var headerEl = this.getView().getHeaderCell(sortColumn)
      Ext.get(headerEl).removeClass(["sort-asc", "sort-desc"]);
      delete this.store.sortInfo
    }
  },
  showHeaderContextMenu : function(grid, columnIndex, evt) {
    evt.preventDefault()
    evt.stopPropagation()

    var dataIndex = grid.getColumnModel().getDataIndex(columnIndex)
    var target = Ext.lib.Event.getTarget(evt)
    if (!target || !dataIndex) {
      return
    }
    var column= grid.getColumnModel().getColumnById(grid.getColumnModel().getColumnId(columnIndex))
    var can_refresh = column.can_refresh
    var can_delete = column.can_delete

    var isEntityIDDataIndex = (this.entityIDDataIndexes.indexOf(dataIndex) > -1)
    var parentLevel = 0
    for ( var i = 0; i < 5; i++) {
      if (Ext.fly(target).findParent("td.ux-grid-hd-group-row-" + i)) {
        parentLevel = i + 1
        break
      }
    }    
    
    var menu = new Ext.menu.Menu({
      items :[{
        text :'Rename Header',
        icon :'/aig/img/column_header_edit.gif',
        scope :this,
        handler : function() {
          var header
          if (parentLevel == 0) {
            header = grid.getColumnModel().getColumnHeader(columnIndex)
          } else {
            header = grid.getParentHeader(columnIndex).header
          // for (var i = column.col; i < column.col + column.colspan; i++) {
          // grid.getColumnModel().setHidden(i, true)
          // }
          }
          // Prompt for user data and process the result using a callback:
          Ext.Msg.prompt('Change Header', 'Header:', function(btn, text) {
            if (btn == 'ok') {
              Ext.Ajax.request({
                url :this.sourceURL,
                success : function(response, options) {
                  var updatedConfig = Ext.util.JSON.decode(response.responseText)
                  if (updatedConfig.noResults) {
                    showInformationDialog('No columns updated.')
                  } else {
                    AIG.reloadEntityTable(updatedConfig)
                  }
                },
                failure : function(response, options) {
                  showErrorDialog("Change Column Header Failed", response.responseText)
                },
                params :{
                  op :'xcolumnheader',
                  columnDataIndex :dataIndex,
                  columnGroupLevel :parentLevel,
                  columnHeader :text
                }
              })
            }
          }, this, false, header)
        }
      }, {
        text :'Hide Column',
        icon :'/aig/img/hide_column.gif',
        scope :this,
        handler : function() {
          if (parentLevel == 0) {
            grid.getColumnModel().setHidden(columnIndex, true)
          } else {
            var column = grid.getParentHeader(columnIndex)
            for ( var i = column.col; i < column.col + column.colspan; i++) {
              grid.getColumnModel().setHidden(i, true)
            }
          }
        }
      }, {
        text :'Column Width',
        icon :'/aig/img/column_width.gif',
        scope :this,
        handler : function() {
          if (parentLevel == 0) {
            new AIG.NumberPrompt({
              title :'Column Width',
              fieldLabel :'Width',
              value :grid.getColumnModel().getColumnWidth(columnIndex),
              modal :true,
              cb : function(width) {
                grid.getColumnModel().setColumnWidth(columnIndex, width)
              },
              scope :this
            }).show()
          } else {
            new AIG.NumberPrompt({
              title :'Column Width',
              fieldLabel :'Width',
              value :grid.getColumnModel().getColumnWidth(columnIndex),
              modal :true,
              cb : function(width) {
                var column = grid.getParentHeader(columnIndex)
                for ( var i = column.col; i < column.col + column.colspan; i++) {
                  grid.getColumnModel().setColumnWidth(i, width)
                }
              },
              scope :this
            }).show()
          }
        }
      }, {
        text :'Column Format',
        icon :'/aig/img/column_format.gif',
        scope :this,
        handler : function() {
          grid.formatColumn(column)          
        }
      }, {
        text :'Delete Column',
        icon :'/aig/img/delete.gif',
        scope :this,
        disabled :!can_delete,
        handler : function() {
          Ext.Ajax.request({
            url :this.sourceURL,
            success : function(response, options) {
              var updatedConfig = Ext.util.JSON.decode(response.responseText)
              if (updatedConfig.noResults) {
                showInformationDialog('No columns deleted.')
              } else {
                showInformationDialog('Column Deleted')
                AIG.reloadEntityTable(updatedConfig)
                grid.fireEvent("columndeleted", grid)
              }
            },
            failure : function(response, options) {
              showErrorDialog("Delete Column Failed", response.responseText)
            },
            params :{
              op :'deletecolumn',
              columnDataIndex :dataIndex,
              columnGroupLevel :parentLevel
            }
          })
        }
      }, {
        text :'Refresh',
        icon :'/aig/img/refreshlist.gif',
        scope :this,
        disabled :!can_refresh,
        handler : function() {
          this.showProcessingMask('Refreshing column..')
          Ext.Ajax.request({
            url :this.sourceURL,
            success : function(response, options) {
              this.hideProcessingMask()
              var updatedConfig = Ext.util.JSON.decode(response.responseText)
              if (updatedConfig.scriptError) {
                showErrorDialog("Script Error", updatedConfig.scriptError)
                showInformationDialog('Unable to refresh columns')
                return
              }
              
              if (updatedConfig.noResults) {
                showInformationDialog('No columns refreshed')
              } else {
                showInformationDialog('Column Refreshed')
                AIG.reloadEntityTable(updatedConfig)
              }
            },
            failure : function(response, options) {
              this.hideProcessingMask()
              showErrorDialog("Refresh Column Failed", response.responseText)
            },
            params :{
              op :'REFRESHCOLUMN',
              columnDataIndex :dataIndex
            },
            scope :this
          })
        }
      }, {
        text :'Edit Calculation',
        icon :'/aig/img/refreshlist.gif',
        scope :grid,
        disabled :!can_refresh,
        handler : function() {
          Ext.Ajax.request({
            url :this.sourceURL,
            success : function(response, options) {
              var calcConfig = Ext.util.JSON.decode(response.responseText)
              var columnFormat = grid.getColumnModel().columns[columnIndex].format
              if (!calcConfig || (calcConfig.simpleCalculationOrig && calcConfig.advFunctionOrig)) {
                showInformationDialog('No calculation found')
              } else {
                grid.handleCalculatedColumnRequest(calcConfig, columnFormat, null, true)
              }
            },
            failure : function(response, options) {
              showErrorDialog("Calculation Retrieval Failed", response.responseText)
            },
            params :{
              op :'getcalculatedcolumnconfig',
              columnDataIndex :dataIndex
            }
          })
        }
      }, {
        text :'Quick Chart (Experimental)',
        icon :'/aig/img/quickchart.png',
        scope :grid,
        disabled :isEntityIDDataIndex,
        hidden :true,
        handler : function() {
          new AIG.QuickChartDialog({
            title :grid.getColumnModel().getColumnHeader(columnIndex),
            yaxis :grid.getColumnModel().getColumnHeader(columnIndex),
            url :serializeRequest(this.sourceURL, {
              op :'COLUMNVALUES',
              columnDataIndex :dataIndex
            })
          }).show()
        }
      }]
    })
    var deleteColumnMenuItem = menu.items.find( function(item) {
      return (item.text == 'Delete Column')
    }, this)
    if (can_delete) {
      deleteColumnMenuItem.setDisabled(isEntityIDDataIndex)
    }
    var formatColumnMenuItem = menu.items.find( function(item) {
      return (item.text == 'Column Format')
    }, this)
    formatColumnMenuItem.setDisabled(isEntityIDDataIndex || (parentLevel != 0))
    menu.showAt(evt.getXY())
  },
  cellSelection : function(grid, rowIndex, columnIndex, evt) {    
    if (evt.hasModifier()) {
      return
    }
    var store = grid.getStore()
    var cm = grid.getColumnModel()
    var record = store.getAt(rowIndex); // Get the Record
    var dataIndex = cm.getDataIndex(columnIndex); // Get field name
    
    
    if (columnIndex== 0) {
      var column= cm.getColumnById(cm.getColumnId(0))
      column.toggleSelected(record)
      return
    }
    
    if (!this.tableConfig.enableDDLoading) {
      return
    }
    this.ddServiceStore.load({
      params :{
        columnDataIndex :dataIndex
      },
      callback : function(records, options, success) {
        if (!success) {
          return
        }
        var ddServiceRecord = null
        for ( var i = 0; i < records.length; i++) {
          if (records[i].data.Default) {
            ddServiceRecord = records[i]
          }
        }
        if (ddServiceRecord) {
          this.runDrillDownService({
            grid :this,
            rowIndex :rowIndex,
            columnIndex :columnIndex,
            serviceKey :ddServiceRecord.id,
            serviceName :(ddServiceRecord.data.Name || "Details")
          })
        }
      },
      scope :this
    })
  },
  /**
   * Runs a drill-down service and creates/updated the tabbed window. The config object contains the following fields: grid rowIndex columnIndex serviceKey
   * serviceName
   * 
   * @param {Object} config
   * @param {Object} grid
   * @param {Object} rowIndex
   * @param {Object} columnIndex
   */
  runDrillDownService : function(config) {
    var store = this.getStore()
    var cm = this.getColumnModel()
    var record = store.getAt(config.rowIndex); // Get the Record
    var dataIndex = cm.getDataIndex(config.columnIndex); // Get field name
    var data = record.get(dataIndex);
    var entityDataRecord = record.get(this.entityIDDataIndexes[0]);
    var pagedRowIndexStart = (store.lastOptions.params && store.lastOptions.params.start ? store.lastOptions.params.start : 0)
    var pagedRowIndex = pagedRowIndexStart + config.rowIndex
    var column = cm.getColumnById(cm.getColumnId(config.columnIndex))
    if (!config.serviceKey) {
      return
    }
    var cellIndex = dataIndex + ":" + entityDataRecord

    var windowName = this.getParentHeader(config.columnIndex).header + ":" + column.header + " (" + entityDataRecord + ")"

    var serviceURL = '/aig/executeentityservice.go'
    serviceURL = serviceURL + (serviceURL.indexOf('?') != -1 ? '&' : '?') + Ext.urlEncode({
      serviceKey :config.serviceKey,
      resultTypeName :'RG DD HTML Definition',
      entityTableKey :this.entityTableKey,
      pagedRowIndex :pagedRowIndex,
      columnDataIndex :dataIndex
    })
    this.drillDownWindowMgr.createDrillDownServiceView({
      windowTitle :windowName,
      windowID :cellIndex,
      serviceURL :serviceURL,
      serviceTitle :(config.serviceName || "Details")
    })
  },
  /**
   * Runs an export service on the table
   */
  runServiceExport : function(config) {
    if (!config.serviceKey) {
      return
    }
    var downloadURL = this.sourceURL + "&op=EXPORT&target=SERVICE&serviceKey=" + config.serviceKey
    callDocumentDownViaIFrame({
      src :downloadURL
    })
    showInformationDialog('Export Started')
  },
  copyCell : function(grid, rowIndex, columnIndex) {
    var store = grid.getStore()
    var cm = grid.getColumnModel()
    var record = store.getAt(rowIndex); // Get the Record
    var dataIndex = cm.getDataIndex(columnIndex); // Get field name
    var data = record.get(dataIndex);
  
    if (typeof data == "string") {
      top.AIG.ClipboardCtrl.setClipboardText(data)
    } else if (data.image) {
      showErrorDialog("Copy Failed", 'Sorry, RG can only copy text')
    } else if (Ext.type(data.values) == 'array') {
      if (data.values.length == 0) {
        top.AIG.ClipboardCtrl.setClipboardText("")
      } else if (data.values.length == 1) {
        top.AIG.ClipboardCtrl.setClipboardText(data.values[0])
      } else {
        var arrayValues = []
        for ( var i = 0; i < data.values.length; i++) {
          arrayValues.push(data.values[i] || "")
        }
        top.AIG.ClipboardCtrl.setClipboardText(arrayValues.join("\r\n"))
      }
    }
  },
  copyRow : function(grid, rowIndex) {
    var store = grid.getStore()
    var cm = grid.getColumnModel()
    var record = store.getAt(rowIndex)
    if (!record) {
      return
    }
    var cellValues = []
    var regex = new RegExp('"', "g")
    for ( var i = 1; i < cm.getColumnCount(); i++) {
      var dataIndex = cm.getDataIndex(i)
      var data = record.get(dataIndex)
      if (typeof data == "string") {
        cellValues.push(data)
      } else if (data.image) {
        cellValues.push("<image>")
      } else if (Ext.type(data.values) == 'array') {
        if (data.values.length == 0) {
          cellValues.push("")
        } else if (data.values.length == 1) {
          cellValues.push(data.values[0])
        } else {
          var arrayValues = []
          for ( var j = 0; j < data.values.length; j++) {
            var v = data.values[j] || ""
            arrayValues.push(v.replace(regex, ""))
          }
          cellValues.push('"' + arrayValues.join(String.fromCharCode(10)) + '"')
        }
      } else {
        cellValues.push("")
      }
    }
    top.AIG.ClipboardCtrl.setClipboardText(cellValues.join('\t'))
  },
  handleCellContextMenu : function(config) {
    if (config.event.hasModifier()) {
      return
    }
    config.event.stopEvent()
    if (config.columnIndex == 0) {
      this.handleRowContextMenu(config)
      return
    }
  
    var grid = config.grid

    var store = grid.getStore()
    var cm = grid.getColumnModel()
    var record = store.getAt(config.rowIndex); // Get the Record
    var dataIndex = cm.getDataIndex(config.columnIndex); // Get field name
    var data = record.get(dataIndex);
    var entityDataRecord = record.get(grid.entityIDDataIndexes[0]);
    var pagedRowIndexStart = (store.lastOptions.params && store.lastOptions.params.start ? store.lastOptions.params.start : 0)
    var pagedRowIndex = pagedRowIndexStart + config.rowIndex
    var column = cm.getColumnById(cm.getColumnId(config.columnIndex))
    var drillDownWindowName = grid.getParentHeader(config.columnIndex).header + ":" + column.header + " (" + entityDataRecord + ")"

    if (!grid.cellmenu) {
      grid.cellmenu = new RG.menu.StoreMenu({
        title :'Drill Down Resources',
        grid :this,
        alwaysLoad :true,
        store :new Ext.data.Store({
          // load using HTTP
          url :'/aig/entitytabledrilldownservicelookup.go?entityTableKey=' + grid.entityTableKey,
          listeners :{
            beforeload : function(store, options) {
              options.params = {
                columnDataIndex :store.menu.columnDataIndex,
                pagedRowIndex :store.menu.pagedRowIndex
              }
            },
            load : function(store) {
            },
            loadexception : function(store, options, error) {
              aigErrorHandler(error)
            }
          },
          // the return will be XML, so lets set up a reader
          reader :new Ext.data.XmlReader({
            // records will have an "Service" tag
            record :'Service',
            id :'ServiceKey'
          }, ['Name', {
            name :'Default',
            type :'boolean'
          }, 'Organization', 'Contact', 'Description'])
        }),
        processRecords : function(store, records) {
          if (records) {
            for ( var i = 0; i < records.length; i++) {
              var style = {
                "font-weight" :(records[i].data.Default ? 'bold' : 'normal')
              }
              records[i].menu = {
                text :records[i].data.Name,
                icon :'/aig/img/treenodeicons/service.gif',
                style :style,
                record :records[i],
                tooltip :{
                  text :records[i].data.Description
                }
              }
            }
            records.push({
              menu :{
                text :'Copy',
                icon :'/aig/img/copy.gif',
                scope :grid,
                disabled :!top.AIG.ClipboardCtrl.hasClipboardAccess(),
                handler : function() {
                  grid.copyCell(grid, grid.cellmenu.rowIndex, grid.cellmenu.columnIndex)
                },
                tooltip :{
                  text :"Copy the cell contents"
                }
              }
            })

            if (grid.hasStructures) {
              top.AIG.StructureMenu.addStructureSubmenu(records, function() {
                var store = grid.getStore()
                var cm = grid.getColumnModel()
                var record = store.getAt(grid.cellmenu.rowIndex); // Get the Record
                var dataIndex = cm.getDataIndex(grid.cellmenu.columnIndex); // Get field name
                return record.get(dataIndex)
              }, grid, true)
            }
          }
        },
        listeners :{
          itemclick : function(item) {
            if (item.record) {
              var serviceKey = item.record.id
              var serviceName = item.record.data.Name

              this.grid.runDrillDownService({
                grid :this.grid,
                rowIndex :this.rowIndex,
                columnIndex :this.columnIndex,
                serviceKey :serviceKey,
                serviceName :serviceName
              })
            }
          }
        },
        menuLoaded : function() {
          RG.menu.StoreMenu.prototype.menuLoaded.call(this)
          var grid = this.grid
          var sm = grid.getSelectionModel()
          var cell = sm.getSelectedCell()
          var store = grid.getStore()
          var cm = grid.getColumnModel()
          var record = store.getAt(this.rowIndex); // Get the Record
          var dataIndex = cm.getDataIndex(this.columnIndex); // Get field name
          var data = record.get(dataIndex);
          var column = cm.getColumnById(cm.getColumnId(this.columnIndex))

          if (top.AIG.ClipboardCtrl.hasClipboardAccess()) {
            var copyMenuItem = this.getMenuItemByTitle('Copy')
            var structureMenuItem = this.getMenuItemByTitle('Structure')
            if (column.type == 'structure') {
              if (structureMenuItem) {
                structureMenuItem.setDisabled(false)
                structureMenuItem.setVisible(true)
              }
          
              copyMenuItem.setDisabled(true)
              copyMenuItem.setVisible(false)
            } else {
              if (structureMenuItem) {
                structureMenuItem.setDisabled(true)
                structureMenuItem.setVisible(false)
              }
          
              copyMenuItem.setDisabled(false)
              copyMenuItem.setVisible(true)
            }
          }
        }
      })
    }
  
    grid.cellmenu.rowIndex = config.rowIndex
    grid.cellmenu.pagedRowIndex = pagedRowIndex
    grid.cellmenu.columnIndex = config.columnIndex
    grid.cellmenu.columnDataIndex = dataIndex
    grid.cellmenu.entityDataRecord = entityDataRecord
    grid.cellmenu.drillDownWindowName = drillDownWindowName
    grid.cellmenu.showAt(config.event.getXY())
  },
  handleRowContextMenu : function(config) {
    if (config.event.hasModifier()) {
      return
    }
    config.event.stopEvent()
    var grid = config.grid

    if (!grid.rowmenu) {
      grid.rowmenu = new Ext.menu.Menu({
        grid :this,
        items :[{
          text :'Copy Row',
          icon :'/aig/img/copy.gif',
          scope :grid,
          handler : function() {
            this.copyRow(this, this.rowmenu.rowIndex)
          }
        }, {
          text :'Move Row to Top',
          icon :'/aig/img/treenodes-first.gif',
          scope :grid,
          handler : function() {
            Ext.Ajax.request({
              url :this.sourceURL,
              success : function(response, options) {
                grid.getStore().reload()
                grid.resetSortState()
              },
              failure : function(response, options) {
                showErrorDialog("Move Row Failed", response.responseText)
              },
              params :{
                op :'MOVEROWTOP',
                pagedRowIndex :this.rowmenu.rowIndex
              },
              scope :this
            })
          }
        }, {
          text :'Move Row to Bottom',
          icon :'/aig/img/treenodes-last.gif',
          scope :grid,
          handler : function() {
            Ext.Ajax.request({
              url :this.sourceURL,
              success : function(response, options) {
                grid.getStore().reload()
                grid.resetSortState()
              },
              failure : function(response, options) {
                showErrorDialog("Move Row Failed", response.responseText)
              },
              params :{
                op :'MOVEROWBOTTOM',
                pagedRowIndex :this.rowmenu.rowIndex
              },
              scope :this
            })
          }
        }]
      })
    }
    grid.rowmenu.rowIndex = config.rowIndex
    grid.rowmenu.showAt(config.event.getXY())
  },
  handleCalculatedColumnRequest : function(calcConfig, columnFormat, scriptError, recalculate) {
    var operation = (recalculate ? 'recalculatecolumn' : 'addcalculatedcolumn')

    new RG.EntityTable.CalculatedColumnDialog({
      entityTable :this,
      calcConfig :calcConfig,
      calcFormat :columnFormat,
      cb : function(calcConfig, calcFormat) {
        this.showProcessingMask('Running script..')
        Ext.Ajax.request({
          url :this.sourceURL,
          success : function(response, options) {
            this.hideProcessingMask()
            var updatedConfig = null
            try {
              updatedConfig = Ext.util.JSON.decode(response.responseText)
            } catch (e) {
            }
            if (!updatedConfig) {
              showErrorDialog("Add Column Failed", "Unable to add new column due to unknown error")
            } else if (updatedConfig.noResults) {
              showInformationDialog('No columns added.')
              if (updatedConfig.scriptError) {
                if (updatedConfig.calcConfig) {
                  this.handleCalculatedColumnRequest(updatedConfig.calcConfig, columnFormat, updatedConfig.scriptError, recalculate)
                } else {
                  showErrorDialog("Script Error", updatedConfig.scriptError)
                }
              }
            } else {
              AIG.reloadEntityTable(updatedConfig)
              if (operation == 'recalculatecolumn') {
                showInformationDialog('Calculation Updated and Refreshed')
              }
            }
          },
          failure : function(response, options) {
            this.hideProcessingMask()
            showErrorDialog("Script Failed", response.responseText)
          },
          params :{
            op :operation,
            columnHeader :calcConfig.header,
            columnGroupDataIndex :calcConfig.groupIndex,
            columnGroupHeader :calcConfig.group,
            calccolumn_config :Ext.util.JSON.encode(calcConfig),
            calccolumn_format :(calcFormat == null ? null : Ext.util.JSON.encode(calcFormat))
          },
          scope :this
        })
      },
      scope :this,
      listeners :{
        show : function(win) {
          if (scriptError) {
            new Ext.util.DelayedTask().delay(10, function() {
              showErrorDialog("Script Error", scriptError)
            })
          }
        }
      }
    }).show()
  },
  handleVQTToggle : function() {
    Ext.Ajax.request({
      url :this.sourceURL,
      success : function(response, options) {
        var updatedConfig = Ext.util.JSON.decode(response.responseText)
        AIG.reloadEntityTable(updatedConfig)
      },
      failure : function(response, options) {
        showErrorDialog("Reformat failed.", response.responseText)
      },
      params :{
        op :'updateformat',
        vnt_toggle :'T'
      },
      scope :this
    })
  },
  formatColumn: function(column) {
    new RG.EntityTable.ColumnFormatDialog({
      grid: this,
      column: column,
      cb : function(column, type, format) {
        if (!column) {
          showErrorDialog('Unable To Format Column', 'Please Select a Column To Format')
          return false
        }
        Ext.Ajax.request({
          url :this.sourceURL,
          success : function(response, options) {
            var updatedConfig = Ext.util.JSON.decode(response.responseText)
            if (updatedConfig.noResults) {
              showInformationDialog('Column not updated.')
            } else {
              showInformationDialog('Column Formatted')
              AIG.reloadEntityTable(updatedConfig)
            }
          },
          failure : function(response, options) {
            showErrorDialog("Column format failed", response.responseText)
          },
          params :{
            op :'updateformat',
            columnDataIndex :column.dataIndex,
            columnFormat :Ext.util.JSON.encode({
              type :type,
              format :format
            })
          }
        })
      },
      scope :this
    }).show()
  },
  handleImport : function() {
    var dialog = new Ext.Window({
      title :'Enter New IDs',
      width :290,
      height :381,
      modal :true,
      layout :'border',
      items :[{
        xtype :'textarea',
        region :'center'
      }],
      buttons :[{
        text :'OK',
        handler : function() {
          dialog.items.get(0).getValue()
          this.doImport(dialog.items.get(0).getValue())
          dialog.close()
        },
        scope :this
      }, {
        text :'Cancel',
        handler : function() {
          dialog.close();
        }
      }]
    })
    dialog.show()
  },
  doImport : function(ids) {
    if (!hasLength(ids)) {
      return
    }
    Ext.Ajax.request({
      url :this.sourceURL,
      success : function(response, options) {
        try {
          updatedConfig = Ext.util.JSON.decode(response.responseText)
        } catch (e) {
        }
        if (!updatedConfig) {
          showErrorDialog("Import Failed", "Unable to add rows due to unknown error")
        } else if (updatedConfig.noResults) {
          showInformationDialog('No new rows added.')
        } else {
          AIG.reloadEntityTable(updatedConfig)
        }
      },
      failure : function(response, options) {
        showErrorDialog("Import failed.", response.responseText)
      },
      params :{
        op :'import',
        importValues :ids
      },
      scope :this
    })

  },
  refreshTable : function() {
    Ext.Ajax.request({
      url :this.sourceURL,
      success : function(response, options) {
        var updatedConfig = Ext.util.JSON.decode(response.responseText)
        AIG.reloadEntityTable(updatedConfig)
      },
      failure : function(response, options) {
        showErrorDialog("Table refresh failed.", response.responseText)
      },
      params :{
        op :'updateformat',
        update_prefs :'T'
      },
      scope :this
    })
  },
  handleLoadDDWindows : function(enabled) {
    this.tableConfig.enableDDLoading = enabled
    this.handleColumnViewConfigChange()
  },
  getRowHeight : function(asPixels) {
    asPixels = asPixels || true
    return (!asPixels ? this.rowHeight : this.rowHeight * 17 / 12.75)
  },
  exportDebug : function() {
    window.open(this.sourceURL + "&op=DEBUG", '_blank')
  },

  showProcessingMask : function(msg) {
    if (this.processingMask != null) {
      this.processingMask.hide()
    }
    this.processingMask = new Ext.LoadMask(this.getEl(), {
      msg :msg
    })
    this.processingMask.show()
  },
  hideProcessingMask : function() {
    if (this.processingMask != null) {
      this.processingMask.hide()
      delete this.processingMask
    }
  },
  canSave : function() {
    if (!this.savedTableID || !this.savedTableCreatedBy || this.savedTableCreatedBy != AIG.USER_SESSION_INFO.LOGIN) {
      return false
    }
    return true
  }
})

