
/**
 * Tootip Class
 * 
 * @param {Object} e
 */
RG.EntityTable.ToolTip = Ext.extend(Ext.ToolTip, {
  onTargetOver : function(e) {
    if (this.disabled) {
      return
    }
    try {
      if (this.sourceTarget && e.within(this.sourceTarget.el, true)) {
        return;
      }
    } catch (e) {
    }
    var t = this.getTarget(e);
    if (t) {
      this.sourceTarget = t;
      this.clearTimer('hide');
      this.targetXY = e.getXY();
      this.delayShow();
    }
  },
  onMouseMove : function(e) {
    var t = this.getTarget(e);
    if (t) {
      this.targetXY = e.getXY();
      if (this.sourceTarget && t.el === this.sourceTarget.el) {
        if (!this.hidden && this.trackMouse) {
          this.setPagePosition(this.getTargetXY());
        }
      } else {
        this.hide();
        this.lastActive = new Date(0);
        this.onTargetOver(e);
      }
    } else if (!this.closable && this.isVisible()) {
      this.hide();
    }
  },
  getTarget : function(e) {
    var row
    var col
    var subTableCell
    var t = e.getTarget('.x-grid3-subtable')
    if (t) {
      row = this.view.findRowIndex(t.parentElement)
      col = this.view.findCellIndex(t.parentElement)
      subTableCell = t
    } else {
      t = e.getTarget('.x-grid3-cell')
      if (!t) {
        return
      }
      row = this.view.findRowIndex(t)
      col = this.view.findCellIndex(t)
    }
    return {
      el :t,
      row :row,
      col :col,
      subTableCell :subTableCell
    }
  },
  hide : function() {
    this.clearTimer('dismiss');
    this.lastActive = new Date();
    delete this.sourceTarget;
    Ext.ToolTip.superclass.hide.call(this);
  }
});


/**
 * Renderer for the tooltip object for a column
 * 
 * @param {Object} record
 * @param {Object} rowIndex
 * @param {Object} colIndex
 * @param {Object} subTableCell
 * @param {Object} store
 */
RG.EntityTable.TipRenderer = function(record, rowIndex, colIndex, subTableCell, store) {
  if (subTableCell) {
    var subCell = Ext.fly(subTableCell).child(".x-grid3-cell-inner")
    if (subCell) {
      return subCell.dom.textContent || subCell.dom.innerText
    }
  }
  return null
}