
/**
 * Row Number column defintion class
 * 
 * @param {Object} config
 */
RG.EntityTable.PagedRowNumberer = Ext.extend(Object,  {
  constructor: function(config) {
    var me= this
    Ext.apply(this, config);
    Ext.applyIf(this, {
      header :"<DIV class='x-grid3-td-pagednumberer-selectall-hd'>&nbsp;</DIV>",
      width :23,
      sortable :false,
      fixed :true,
      menuDisabled :true,
      dataIndex :'',
      id :'pagednumberer',
      rowspan :undefined,
      overRowIndex: new Ext.util.MixedCollection(),
      selections: new Ext.util.MixedCollection()
    })
    if (this.rowspan) {
      this.renderer = this.renderer.createDelegate(this);
    }
    
    this.grid.on('cellover', this.handleCellOver.createDelegate(this))
    this.grid.on('cellout', this.handleCellOut.createDelegate(this))
    this.grid.getView().on('refresh', this.updateCellSelections.createDelegate(this))
    
  }, 
  renderer : function(v, p, record, rowIndex, colIndex, store) {
    if (this.rowspan) {
      p.cellAttr = 'rowspan="' + this.rowspan + '"';
    }
    var rowHeader = 0
    if (store.lastOptions.params && store.lastOptions.params.start) {
      rowHeader = store.lastOptions.params.start
    }
    if (isNaN(rowHeader)) {
      rowHeader = 0;
    }
    rowHeader = rowHeader + rowIndex + 1
    return rowHeader.toFixed(0)
  },
  handleCellOver: function(rowIndex, cellIndex, cell) {
    if (cellIndex!= 0) {
      this.clearCellOver()
      return
    }
    if (this.overRowIndex.containsKey(rowIndex)) {
      return
    }    
    this.clearCellOver()
    var fly= this.fly(cell)
    if (!fly.hasClass('x-grid3-td-pagednumberer-selected')) {
      this.fly(cell).addClass('x-grid3-td-pagednumberer-over');
      this.overRowIndex.add(rowIndex,rowIndex)   
    }
  },
  handleCellOut: function(rowIndex, cellIndex, cell) {
    if (!cell) {
      this.clearCellOver()
    }
  },
  clearCellOver: function() {
    if (this.overRowIndex.getCount()> 0) {
      var currCell = this.grid.getView().getCell(this.overRowIndex.first(), 0);
      if (currCell) {
        this.fly(currCell).removeClass('x-grid3-td-pagednumberer-over');
      }
    } 
    this.overRowIndex.clear()
  },
  updateCellSelections: function() {
    var records= this.grid.getStore().getRange()
    for(var i=0; i< records.length; i++) {
      var entityId= records[i].get('entity_id')
      var selected= this.selections.containsKey(entityId)
      var cell = this.grid.getView().getCell(i, 0);
      var fly= this.fly(cell)
      if (selected) {      
        fly.removeClass('x-grid3-td-pagednumberer-over')
        fly.addClass('x-grid3-td-pagednumberer-selected')
      } else {
        fly.removeClass('x-grid3-td-pagednumberer-selected')        
      }
    }
  },
  toggleSelected: function(record) {
    var entityId= record.get('entity_id')
    if (this.selections.containsKey(entityId)) {
      this.selections.removeKey(entityId)
    } else {
      this.selections.add(entityId, record)
    }
    this.updateCellSelections()
    this.grid.rowSelectionsUpdated(record, this.selections.containsKey(entityId))
  },
  headerClicked: function() {
    if (this.selections.getCount()> 0) {
      this.selections.clear()
    } else {
      var records= this.grid.getStore().getRange()
      for(var i=0; i< records.length; i++) {
        var entityId= records[i].get('entity_id')
        this.selections.add(entityId, records[i])
      }
    }
    this.updateCellSelections()
  },
  fly : function(el){
    if(!this._flyweight){
      this._flyweight = new Ext.Element.Flyweight(document.body);
    }
    this._flyweight.dom = el;
    return this._flyweight;
  }  
})