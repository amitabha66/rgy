/**
 * @author jemcdowe
 */
RG.EntityTable.Toolbar = Ext.extend(Ext.PagingToolbar, {  
  initComponent : function() {
    var tb= this
    this.enableOverflow= true
    this.items= ['Page Size',
    new Ext.form.ComboBox({
      store :new Ext.data.SimpleStore({
        fields :['num', 'txt'],
        data :[['5', '5'], ['10', '10'], ['25', '25'], ['50', '50'], ['100', '100'], ['0', 'ALL']]
      }),
      displayField :'txt',
      typeAhead :true,
      mode :'local',
      triggerAction :'all',
      selectOnFocus :true,
      resizable :true,
      listWidth :50,
      width :50,
      value :this.pageSize + '',
      toolbar :this,
      listeners :{
        select : function(pageSizeBox, record, index) {
          var toolbar = pageSizeBox.toolbar
          var grid = pageSizeBox.toolbar.ownerCt
          var gridStore = grid.store
          if (pageSizeBox.getValue() != 'ALL') {
            toolbar.pageSize = parseInt(pageSizeBox.getValue());
          } else {
            toolbar.pageSize = gridStore.getTotalCount();
          }
          toolbar.cursor = 0;
          gridStore.load({
            params :{
              start :toolbar.cursor,
              limit :toolbar.pageSize
            }
          })
        }
      }
    }),      
    // Row Height
    'Row Height',
    this.rowHeight = new Ext.ux.form.Spinner({
      width :60,
      height :26,
      value :this.grid.rowHeight,
      toolbar :this,
      enableKeyEvents :true,
      updateGrid : function(rowHeight) {
        var toolbar = tb
        var grid = toolbar.ownerCt
        var gridStore = grid.store
        if (grid.rowHeight != rowHeight) {
          grid.rowHeight = rowHeight
          transactionID = Ext.Ajax.request({
            url :grid.sourceURL,
            success : function(response, options) {
              var updatedConfig = Ext.util.JSON.decode(response.responseText)
              AIG.reloadEntityTable(updatedConfig)
            },
            failure : function(response, options) {
              showErrorDialog("Resize Row Heights Failed", response.responseText)
            },
            params :{
              op :'updateformat',
              row_height :rowHeight
            }
          })
        }
      },
      syncWithGrid : function() {
        var toolbar = tb
        var grid = toolbar.ownerCt
        if (grid.rowHeight != this.getValue()) {
          this.setValue(grid.rowHeight)
        }
      },
      strategy :{
        xtype :'number',
        minValue :50,
        maxValue :500,
        incrementValue :5
      },
      checkValue : function() {
        var val = new Number(this.getValue())
        val = Math.max(this.strategy.minValue, val)
        val = Math.min(this.strategy.maxValue, val)
        this.setValue(val)
      },
      listeners :{
        afterspin : function(spinner, value) {
          spinner.checkValue()
          spinner.updateGrid(spinner.getValue())
        },
        change : function(spinner, value) {
          spinner.checkValue()
          spinner.updateGrid(spinner.getValue())
        },
        keydown : function(spinner, evt) {
          var k = evt.getKey()
          if (k == evt.RETURN) {
            evt.stopEvent()
            spinner.checkValue()
            spinner.updateGrid(spinner.getValue())
          }
        }
      }
    }),
    '-',
    this.advSort = new Ext.Button({
      tooltip :'Advanced Sorting',
      iconCls :"adv-sorting",
      disabled :false,
      scope :this,
      handler : function() {
        new RG.EntityTable.SortDialog({
          entityTable :this.grid,
          handler : function(sortInfo) {
            if (sortInfo.sort.length == 0) {
              return
            }
            if (sortInfo.sort.length == 1) {
              try {
                if (this.grid.store.lastOptions.params.caseSensitive == sortInfo.caseSensitive) {
                  this.grid.store.sort(sortInfo.sort[0], sortInfo.direction[0])
                  return
                }
              } catch (e) {
                if (sortInfo.caseSensitive == 'NO') {
                  this.grid.store.sort(sortInfo.sort[0], sortInfo.direction[0])
                  return
                }
              }
            }
            var toolbar = this.grid.getTopToolbar()
            this.grid.resetSortState()
            this.grid.getStore().load({
              params :{
                start :toolbar.cursor,
                limit :toolbar.pageSize,
                caseSensitive :sortInfo.caseSensitive,
                sort :sortInfo.sort.join("\t"),
                dir :sortInfo.direction.join("\t")
              },
              callback : function(records, options, success) {
                this.grid.resetSortState()
              },
              scope :this
            })
          },
          scope :this
        }).show()
      }
    }),
    this.vntToggle = new Ext.Button({
      tooltip :'Toggle Assay Format Between Value and Value, Aggregation Count(N) and Total (T)',
      iconCls :"vnt_toggle",
      disabled :false,
      scope :this,
      handler : function() {
        this.grid.handleVQTToggle()
      }
    }),
    new Ext.Button({
      tooltip :'Change Configuration',
      iconCls :"rg_preferences_icon",
      scope :this,
      handler : function(item) {
        new AIG.UserPreferencesUi({
          selectedGroup :'Table View',
          handler : function(preferences) {
            if ((preferences.operation == 'ok' || preferences.operation == 'reset' || preferences.operation == 'apply') && preferences.updated > 0) {
              this.refreshTable()
            }
          },
          scope :this.grid
        }).show()

      }
    }), {
      tooltip :'Change a Column Format',
      icon :'/aig/img/column_format.gif',
      scope :this,
      handler : function() {
        this.grid.formatColumn()
      }
    },
    '-',
    /*
             * this.conditionalFormatting = this.addButton({ tooltip: 'Conditional Formatting', iconCls: "conditional-formatting", disabled: false, handler:
             * function(){ } })
             */
            
    new Ext.Button({
      tooltip :'Add Rows',
      iconCls :"add-row",
      scope :this,
      handler : function(item) {
        this.grid.handleImport()
      }
    }),
           
    new Ext.Button({
      tooltip :'Create child table from selections',
      iconCls :"ix-v0-16-table_sql_select",
      scope :this,
      handler : function(item) {
        this.grid.createSubTable()
      }
    }),
    
    
    
    /*
             * this.conditionalFormatting = this.addButton({ tooltip: 'Conditional Formatting', iconCls: "conditional-formatting", disabled: false, handler:
             * function(){ } })
             */
    '-',
    this.addNewColumn = new AIG.BoundSplitButton({
      text :'Add Columns',
      disabled :false,
      tooltip :'Add a new column to the table',
      iconCls :"add-column",
      menu :{
        items :[{
          text :'Add Data',
          tooltip :'Add Data To Table',
          iconCls :"add-column",
          disabled :false,
          handler : function(item) {   
            new RG.Dialog.ServiceSelectDialog({
              title: 'Add Column(s)',
              iconCls: 'ix-v0-16-column_add',
              entityTableKey: this.grid.entityTableKey,
              canSaveService: false,
              queryParams: {
                queryType: 'TABLE_SERVICES',
                entityTableKey: this.grid.entityTableKey
              },      
              parentSize: this.grid.getSize(),
              cb: function(submit, serviceRecord, formValues, form) {                    
               if (submit) {  
                  this.grid.runAddColumnService({
                    serviceKey: serviceRecord.data.ServiceKey,
                    serviceName: serviceRecord.data.Name,
                    serviceParams: formValues
                  })
                }
              },
              scope: this
            }).show()  
          },
          scope :this
        },{
          text :'Add Structure Properties',
          tooltip :'Add Basic Structure Properties To Table',
          iconCls :"add-structuredetails-column",
          disabled :(this.grid.entityType!= 'COMPOUNDS' && this.grid.entityType!= 'SUBSTANCES'),
          handler : function(item) {                    
            this.grid.runStructureDetailsColumns()
          },        
          scope :this
        }, {
          text :'Add Editable Column',
          tooltip :'Add An Editable Column To The Table',
          iconCls :"add-editable-column",
          handler : function(item) {
            var grid = this.grid
            // Prompt for user data and process the result using a
            // callback:
            Ext.Msg.prompt('New Column Header', 'Header:', function(btn, text) {
              if (btn == 'ok') {
                Ext.Ajax.request({
                  url :grid.sourceURL,
                  success : function(response, options) {
                    var updatedConfig = null
                    try {
                      updatedConfig = Ext.util.JSON.decode(response.responseText)
                    } catch (e) {
                    }
                    if (!updatedConfig) {
                      showErrorDialog("Add Column Failed", "Unable to add new column due to unknown error")
                    }
                    else if (updatedConfig.noResults) {
                      showInformationDialog('No columns added.')
                    } else {
                      AIG.reloadEntityTable(updatedConfig)
                    }
                  },
                  failure : function(response, options) {
                    showErrorDialog("Add Column Failed", response.responseText)
                  },
                  params :{
                    op :'addeditablecolumn',
                    columnHeader :text
                  }
                })
              }
            }, this)
          },
          scope :this
        }, {
          text :'Add Calculated Column',
          tooltip :'Add A Calculated Column To The Table',
          iconCls :"add-calc-column",
          disabled :false,
          handler : function(item) {
            var grid = this.grid
            grid.handleCalculatedColumnRequest(null, null, null, false)
          },
          scope :this
        }]
      }
    }),
    '-',
    this.specialExportTable = new AIG.BoundSplitButton({
      text :'Special Export',
      disabled :false,
      tooltip :'Exports the table',
      iconCls :"rg_export",
      menu :new RG.menu.StoreMenu({
        title :'Drill Down Resources',
        grid :this.grid,
        alwaysLoad :false,
        staticItems :{
          top :[{
            tooltip :'Export Table To Excel',
            iconCls :"export-excel-entitytable",
            text :'Export to Excel',
            disabled :false,
            handler : function() {
              var downloadURL = this.grid.sourceURL + "&op=EXPORT&target=EXCEL"
              callDocumentDownViaIFrame({
                src :downloadURL
              })
              showInformationDialog('Export Started')
              if (this.grid.hasStructures=== true) {
                Ext.MessageBox.alert(
                  "Export Started...",
                  "The export has begun. "+
                  "This may take a moment if structures need to be retrieved.<BR>"+
                  "<BR>Note: To see structures in the Excel document:<UL START='1'>"+
                  "<LI>Be sure Isentris for Excel is installed</LI>"+
                  "<LI>Click on the Add-Ins tab</LI>"+
                  "<LI>Click Convert Molfiles to Structure from the Amgen Functions menu.</LI><UL>"
                  )
              }
            }, 
            scope :this
          },{
            tooltip :'Export Table To SDFile',
            iconCls :"ix-v0-16-shape_hexagon",
            text :'Export to SDFile',
            disabled :(this.grid.entityType!= 'COMPOUNDS' && this.grid.entityType!= 'SUBSTANCES'),
            handler : function() {
              var downloadURL = this.grid.sourceURL + "&op=EXPORT&target=SDFILE"
              callDocumentDownViaIFrame({
                src :downloadURL
              })
              showInformationDialog('Export Started')
              Ext.MessageBox.alert(
                "Export Started...",
                "The export has begun. "+
                "This may take a moment if structures need to be retrieved.<BR>"+
                "<BR>Note: To see structures in the Excel document:<UL START='1'>"+
                "<LI>Be sure Isentris for Excel is installed</LI>"+
                "<LI>Click on the Add-Ins tab</LI>"+
                "<LI>Click Convert Molfiles to Structure from the Amgen Functions menu.</LI><UL>"
                )
            },
            scope :this
          }, {
            tooltip :'Open table in Spotfire',
            iconCls :"export-spotfire-entitytable",
            text :'Export to Spotfire',
            disabled :false,
            handler : function() {
              var downloadURL = this.grid.sourceURL + "&op=EXPORT&target=SPOTFIRE"
              callDocumentDownViaIFrame({
                src :downloadURL
              })
              showInformationDialog('Export Started')
            },
            scope :this
          }]
        },
        store :new Ext.data.Store({
          // load using HTTP
          url :'/aig/entitytableexportservicelookup.go?entityTableKey=' + this.grid.entityTableKey,
          listeners :{
            loadexception : function(store, options, error) {
              aigErrorHandler(error)
            }
          },
          // the return will be XML, so lets set up a reader
          reader :new Ext.data.XmlReader({
            // records will have an "Service" tag
            record :'Service',
            id :'ServiceKey'
          }, RG.Record.ServiceRecord)
        }),
        processRecords : function(store, records) {
          if (records) {
            for ( var i = 0; i < records.length; i++) {
              var style = {
                "font-weight" :(records[i].data.Default ? 'bold' : 'normal')
              }
              records[i].menu = {
                text :records[i].data.Name,
                iconCls :(hasLength(records[i].data.IconClass) ? "export-" + records[i].data.IconClass : "rg_export"),
                style :style,
                record :records[i],
                tooltip : records[i].data.Description || records[i].data.Name,
                handler : function(item) {
                  if (item.record) {
                    var serviceKey = item.record.id
                    var serviceName = item.record.data.Name
                    this.grid.runServiceExport({
                      serviceKey :serviceKey,
                      serviceName :serviceName
                    })
                  }
                },
                scope :this
              }
            }
          }
        },
        menuLoaded : function() {
          RG.menu.StoreMenu.prototype.menuLoaded.call(this)
        }
      })
    }),
    '-']
    
    
    
    var saveAsAction = new Ext.Action({
      handler : function() {
        new AIG.SaveEntityTableDialog({
          grid :this.grid
        }).show()
      },
      scope :this,
      iconCls :'saveas-entitytable',
      tooltip :'Create a new saved table'
    })

    var saveAction = new Ext.Action({
      text :'Save',
      handler : function() {
        Ext.Ajax.request({
          url :this.grid.sourceURL,
          success : function(response, options) {
            showInformationDialog("Saved Table")
          },
          failure : function(response, options) {
            showErrorDialog("Save Table Failed", response.responseText)
          },
          params :{
            op :'SAVE'
          },
          scope :this
        })
      },
      scope :this,
      iconCls :'save-entitytable',
      tooltip :'Save this table to the currently saved table'
    })
    if (this.grid.canSave()) {
      saveAsAction.setText('Save As...')
      this.saveTable = new Ext.Button({
        iconCls :'save-entitytable',
        menu :[saveAction, saveAsAction]
      })
      this.items.push(this.saveTable)
    } else {
      this.saveTable = new Ext.Button(saveAsAction)
      this.items.push(this.saveTable)
    }    
    
    RG.EntityTable.Toolbar.superclass.initComponent.call(this)
    
    tb.inputItem.on('keydown', function(field, evt) {
      var k = evt.getKey()
      if (evt.hasModifier() && k == evt.RETURN) {
        evt.stopEvent()
        tb.ownerCt.exportDebug()        
      }
    })   
    
  },
  toggleDisplayInfo: function(winWidth) {
  //this.displayEl.setVisible((winWidth>= this.minWidthToDisplayInfo))
  },          
  // private
  onRender : function(ct, position) {
    AIG.EntityTablePagingToolbar.superclass.onRender.call(this, ct, position)
    return
    this.addText("Page Size");
    this.addField(new Ext.form.ComboBox({
      store :new Ext.data.SimpleStore({
        fields :['num', 'txt'],
        data :[['5', '5'], ['10', '10'], ['25', '25'], ['50', '50'], ['100', '100'], ['0', 'ALL']]
      }),
      displayField :'txt',
      typeAhead :true,
      mode :'local',
      triggerAction :'all',
      selectOnFocus :true,
      resizable :true,
      listWidth :50,
      width :50,
      value :this.initialPageSize + '',
      toolbar :this,
      listeners :{
        select : function(pageSizeBox, record, index) {
          var toolbar = pageSizeBox.toolbar
          var grid = pageSizeBox.toolbar.ownerCt
          var gridStore = grid.store
          if (pageSizeBox.getValue() != 'ALL') {
            toolbar.pageSize = parseInt(pageSizeBox.getValue());
          } else {
            toolbar.pageSize = gridStore.getTotalCount();
          }
          toolbar.cursor = 0;
          gridStore.load({
            params :{
              start :toolbar.cursor,
              limit :toolbar.pageSize
            }
          })
        }
      }
    }))

    // Row Height
    this.addText("Row Height");
    this.rowHeight = new Ext.ux.form.Spinner({
      width :60,
      height :26,
      value :this.grid.rowHeight,
      toolbar :this,
      enableKeyEvents :true,
      updateGrid : function(rowHeight) {
        var toolbar = this.toolbar
        var grid = toolbar.ownerCt
        var gridStore = grid.store
        if (grid.rowHeight != rowHeight) {
          grid.rowHeight = rowHeight
          transactionID = Ext.Ajax.request({
            url :grid.sourceURL,
            success : function(response, options) {
              var updatedConfig = Ext.util.JSON.decode(response.responseText)
              AIG.reloadEntityTable(updatedConfig)
            },
            failure : function(response, options) {
              showErrorDialog("Resize Row Heights Failed", response.responseText)
            },
            params :{
              op :'updateformat',
              row_height :rowHeight
            }
          })
        }
      },
      syncWithGrid : function() {
        var toolbar = this.toolbar
        var grid = toolbar.ownerCt
        if (grid.rowHeight != this.getValue()) {
          this.setValue(grid.rowHeight)
        }
      },
      strategy :{
        xtype :'number',
        minValue :50,
        maxValue :500,
        incrementValue :5
      },
      checkValue : function() {
        var val = new Number(this.getValue())
        val = Math.max(this.strategy.minValue, val)
        val = Math.min(this.strategy.maxValue, val)
        this.setValue(val)
      },
      listeners :{
        afterspin : function(spinner, value) {
          spinner.checkValue()
          spinner.updateGrid(spinner.getValue())
        },
        change : function(spinner, value) {
          spinner.checkValue()
          spinner.updateGrid(spinner.getValue())
        },
        keydown : function(spinner, evt) {
          var k = evt.getKey()
          if (k == evt.RETURN) {
            evt.stopEvent()
            spinner.checkValue()
            spinner.updateGrid(spinner.getValue())
          }
        }
      }
    })
    this.add(this.rowHeight)

    this.addSeparator();
    this.advSort = this.addButton({
      tooltip :'Advanced Sorting',
      iconCls :"adv-sorting",
      disabled :false,
      scope :this,
      handler : function() {
        new AIG.SortDialog({
          entityTable :this.grid,
          handler : function(sortInfo) {
            if (sortInfo.sort.length == 0) {
              return
            }
            if (sortInfo.sort.length == 1) {
              try {
                if (this.grid.store.lastOptions.params.caseSensitive == sortInfo.caseSensitive) {
                  this.grid.store.sort(sortInfo.sort[0], sortInfo.direction[0])
                  return
                }
              } catch (e) {
                if (sortInfo.caseSensitive == 'NO') {
                  this.grid.store.sort(sortInfo.sort[0], sortInfo.direction[0])
                  return
                }
              }
            }
            var toolbar = this.grid.getTopToolbar()
            this.grid.resetSortState()
            this.grid.getStore().load({
              params :{
                start :toolbar.cursor,
                limit :toolbar.pageSize,
                caseSensitive :sortInfo.caseSensitive,
                sort :sortInfo.sort.join("\t"),
                dir :sortInfo.direction.join("\t")
              },
              callback : function(records, options, success) {
                this.grid.resetSortState()
              },
              scope :this
            })
          },
          scope :this
        })
      }
    });
    this.vntToggle = this.addButton({
      tooltip :'Toggle Assay Format Between Value and Value, Aggregation Count(N) and Total (T)',
      iconCls :"vnt_toggle",
      disabled :false,
      scope :this,
      handler : function() {
        this.grid.handleVQTToggle()
      }
    })
    this.add(new Ext.Button({
      tooltip :'Change Configuration',
      iconCls :"rg_preferences_icon",
      scope :this,
      handler : function(item) {
        new AIG.UserPreferencesUi({
          selectedGroup :'Table View',
          handler : function(preferences) {
            if ((preferences.operation == 'ok' || preferences.operation == 'reset' || preferences.operation == 'apply') && preferences.updated > 0) {
              this.refreshTable()
            }
          },
          scope :this.grid
        }).show()

      }
    }))
    /*
             * this.conditionalFormatting = this.addButton({ tooltip: 'Conditional Formatting', iconCls: "conditional-formatting", disabled: false, handler:
             * function(){ } })
             */
    this.addSeparator();
            
    this.add(new Ext.Button({
      tooltip :'Add Rows',
      iconCls :"add-row",
      scope :this,
      handler : function(item) {
        this.grid.handleImport()
      }
    }))
    /*
             * this.conditionalFormatting = this.addButton({ tooltip: 'Conditional Formatting', iconCls: "conditional-formatting", disabled: false, handler:
             * function(){ } })
             */
    this.addSeparator();

    this.addNewColumn = this.add(new AIG.BoundSplitButton({
      text :'Add Columns',
      disabled :false,
      tooltip :'Add a new column to the table',
      iconCls :"add-column",
      menu :{
        items :[{
          text :'Add Data',
          tooltip :'Add Data To Table',
          iconCls :"add-column",
          disabled :false,
          handler : function(item) {                     
            new RG.Dialog.ServiceSelectDialog({
              title: 'Add Column(s)',
              iconCls: 'ix-v0-16-column_add',
              entityTableKey: this.grid.entityTableKey,
              canSaveService: false,
              queryParams: {
                queryType: 'TABLE_SERVICES',
                entityTableKey: this.grid.entityTableKey
              },      
              parentSize: this.grid.getSize(),
              cb: function(submit, serviceRecord, formValues, form) {   
                if (submit) {
                  this.grid.runAddColumnService({
                    serviceKey: serviceRecord.data.ServiceKey,
                    serviceName: serviceRecord.data.Name,
                    serviceParams: formValues
                  })
                }
              },
              scope: this
            }).show()  
          },
          scope :this
        },{
          text :'Add Structure Properties',
          tooltip :'Add Basic Structure Properties To Table',
          iconCls :"add-structuredetails-column",
          disabled :(this.grid.entityType!= 'COMPOUNDS' && this.grid.entityType!= 'SUBSTANCES'),
          handler : function(item) {                    
            this.grid.runStructureDetailsColumns()
          },        
          scope :this
        }, {
          text :'Add Editable Column',
          tooltip :'Add An Editable Column To The Table',
          iconCls :"add-editable-column",
          handler : function(item) {
            var grid = this.grid
            // Prompt for user data and process the result using a
            // callback:
            Ext.Msg.prompt('New Column Header', 'Header:', function(btn, text) {
              if (btn == 'ok') {
                Ext.Ajax.request({
                  url :grid.sourceURL,
                  success : function(response, options) {
                    var updatedConfig = null
                    try {
                      updatedConfig = Ext.util.JSON.decode(response.responseText)
                    } catch (e) {
                    }
                    if (!updatedConfig) {
                      showErrorDialog("Add Column Failed", "Unable to add new column due to unknown error")
                    } else if (updatedConfig.noResults) {
                      showInformationDialog('No columns added.')
                    } else {
                      AIG.reloadEntityTable(updatedConfig)
                    }
                  },
                  failure : function(response, options) {
                    showErrorDialog("Add Column Failed", response.responseText)
                  },
                  params :{
                    op :'addeditablecolumn',
                    columnHeader :text
                  }
                })
              }
            }, this)
          },
          scope :this
        }, {
          text :'Add Calculated Column',
          tooltip :'Add A Calculated Column To The Table',
          iconCls :"add-calc-column",
          disabled :false,
          handler : function(item) {
            var grid = this.grid
            grid.handleCalculatedColumnRequest(null, null, null, false)
          },
          scope :this
        }]
      }
    }))
    this.addSeparator();

    this.specialExportTable = new AIG.BoundSplitButton(
    {
      text :'Special Export',
      disabled :false,
      tooltip :'Exports the table',
      iconCls :"rg_export",
      menu :new RG.menu.StoreMenu(
      {
        title :'Drill Down Resources',
        grid :this.grid,
        alwaysLoad :false,
        staticItems :{
          top :[{
            tooltip :'Export Table To Excel',
            iconCls :"export-excel-entitytable",
            text :'Export to Excel',
            disabled :false,
            handler : function() {
              var downloadURL = this.grid.sourceURL + "&op=EXPORT&target=EXCEL"
              callDocumentDownViaIFrame({
                src :downloadURL
              })
              showInformationDialog('Export Started')
              Ext.MessageBox.alert(
                "Export Started...",
                "The export has begun. "+
                "This may take a moment if structures need to be retrieved.<BR>"+
                "<BR>Note: To see structures in the Excel document:<UL START='1'>"+
                "<LI>Be sure Isentris for Excel is installed</LI>"+
                "<LI>Click on the Add-Ins tab</LI>"+
                "<LI>Click Convert Molfiles to Structure from the Amgen Functions menu.</LI><UL>"
                )
            },
            scope :this
          },{
            tooltip :'Export Table To SDFile',
            iconCls :"ix-v0-16-shape_hexagon",
            text :'Export to SDFile',
            disabled :(this.grid.entityType!= 'COMPOUNDS' && this.grid.entityType!= 'SUBSTANCES'),
            handler : function() {
              var downloadURL = this.grid.sourceURL + "&op=EXPORT&target=SDFILE"
              callDocumentDownViaIFrame({
                src :downloadURL
              })
              showInformationDialog('Export Started')
              Ext.MessageBox.alert(
                "Export Started...",
                "The export has begun. "+
                "This may take a moment if structures need to be retrieved.<BR>"+
                "<BR>Note: To see structures in the Excel document:<UL START='1'>"+
                "<LI>Be sure Isentris for Excel is installed</LI>"+
                "<LI>Click on the Add-Ins tab</LI>"+
                "<LI>Click Convert Molfiles to Structure from the Amgen Functions menu.</LI><UL>"
                )
            },
            scope :this
          }, {
            tooltip :'Open table in Spotfire',
            iconCls :"export-spotfire-entitytable",
            text :'Export to Spotfire',
            disabled :false,
            handler : function() {
              var downloadURL = this.grid.sourceURL + "&op=EXPORT&target=SPOTFIRE"
              callDocumentDownViaIFrame({
                src :downloadURL
              })
              showInformationDialog('Export Started')
            },
            scope :this
          }]
        },
        store :new Ext.data.Store({
          // load using HTTP
          url :'/aig/entitytableexportservicelookup.go?entityTableKey=' + this.grid.entityTableKey,
          listeners :{
            loadexception : function(store, options, error) {
              aigErrorHandler(error)
            }
          },
          // the return will be XML, so lets set up a reader
          reader :new Ext.data.XmlReader({
            // records will have an "Service" tag
            record :'Service',
            id :'ServiceKey'
          }, RG.Record.ServiceRecord)
        }),
        processRecords : function(store, records) {
          if (records) {
            for ( var i = 0; i < records.length; i++) {
              var style = {
                "font-weight" :(records[i].data.Default ? 'bold' : 'normal')
              }
              records[i].menu = {
                text :records[i].data.Name,
                iconCls :(hasLength(records[i].data.IconClass) ? "export-" + records[i].data.IconClass : "rg_export"),
                style :style,
                record :records[i],
                tooltip : records[i].data.Description || records[i].data.Name,
                handler : function(item) {
                  if (item.record) {
                    var serviceKey = item.record.id
                    var serviceName = item.record.data.Name
                    this.grid.runServiceExport({
                      serviceKey :serviceKey,
                      serviceName :serviceName
                    })
                  }
                },
                scope :this
              }
            }
          }
        },
        menuLoaded : function() {
          RG.menu.StoreMenu.prototype.menuLoaded.call(this)
        }
      })
    })

    this.add(this.specialExportTable)
    this.addSeparator();
            
    var saveAsAction = new Ext.Action({
      handler : function() {
        new AIG.SaveEntityTableDialog({
          grid :this.grid
        }).show()
      },
      scope :this,
      iconCls :'saveas-entitytable',
      tooltip :'Create a new saved table'
    })

    var saveAction = new Ext.Action({
      text :'Save',
      handler : function() {
        Ext.Ajax.request({
          url :this.grid.sourceURL,
          success : function(response, options) {
            showInformationDialog("Saved Table")
          },
          failure : function(response, options) {
            showErrorDialog("Save Table Failed", response.responseText)
          },
          params :{
            op :'SAVE'
          },
          scope :this
        })
      },
      scope :this,
      iconCls :'save-entitytable',
      tooltip :'Save this table to the currently saved table'
    })
    if (this.grid.canSave()) {
      saveAsAction.setText('Save As...')
      this.saveTable = this.addButton({
        iconCls :'save-entitytable',
        menu :[saveAction, saveAsAction]
      })
    } else {
      this.saveTable = this.addButton(saveAsAction)
    }
  }
})