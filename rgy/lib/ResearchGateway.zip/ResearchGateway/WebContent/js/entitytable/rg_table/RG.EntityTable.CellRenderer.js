
/**
 * Defined the renderer used in the EntityTable. Note- This is called via a delegate, so it has EntityTable as its scope!
 * 
 * @param {Object} value
 * @param {Object} metadata
 * @param {Object} record
 * @param {Object} rowIndex
 * @param {Object} colIndex
 * @param {Object} store
 */
RG.EntityTable.CellRenderer = function (value, metadata, record, rowIndex, colIndex, store) {
  var grid = this
  metadata.css = 'nopadding'
  var columnId = grid.getColumnModel().getColumnId(colIndex)
  var columnModel = grid.getColumnModel().getColumnById(columnId)
  var columnType = columnModel.type
  if (columnModel.source && columnModel.source[columnType]) {
	var imgSourceId = columnModel.source[columnType].imgsource_id
	if (imgSourceId && sourceConfigs[imgSourceId]) {
	  imgValue = (typeof value == "object" ? value.value : value)
	  var imgSourceURL = sourceConfigs[imgSourceId].url
	  var replacement = (columnType === 'person' ? 'login' : 'id')
	  var imgTag = AIG.createEntityTableRendererImgTag(grid, rowIndex, colIndex, imgSourceURL, replacement, imgValue, grid.getRowHeight(), grid.getRowHeight(), value)
	  return imgTag
	}
  }

  if (typeof value == "string") {
	/*
	 * Work for setting the background color record.data.backgroundColor= "00FF00" if (record.data.backgroundColor) { //if
	 * (Ext.util.CSS.getRule("entity-table-color-" + record.data.backgroundColor)) { metadata.css= "entity-table-color-" + record.data.backgroundColor //} }
	 */
	if (columnType == 'html') {
	  return value
	} else {
	  return Ext.util.Format.nl2br(Ext.util.Format.htmlEncode(value.replace(/<BR\/>/gi, '\n')))
	}
  }

  if (value.image) {
	return RG.EntityTable.generateCellImageTag(grid, rowIndex, colIndex, value.image, null, null, value.imageWidth, value.imageHeight, value)
  } else if (Ext.type(value.values) == 'array') {
	metadata.attr = 'style = "padding: 0px 0px 0px 0px !important;padding-left: 0 !important;padding-right: 0 !important;"'
	var tpl = new Ext.XTemplate('<div>',
		'<table width="100%" cellspacing="0" cellpadding="0" border="0" class="x-grid3-row-table">',
		'<tpl for="values">',
		'<tr>', '<td class="x-grid3-row x-grid3-col x-grid3-cell x-grid3-cell-first x-grid3-subtable">',
		'<div style="white-space: nowrap !important;" unselectable="on" class="x-grid3-cell-inner">',
		'<tpl if="values.length &gt; 0">', '{.}',
		'</tpl>',
		'<tpl if="values.length === 0">',
		'-',
		'</tpl>',
		'</td>', '</tr>',
		'</tpl>',
		'</table>',
		'</div>')
	return tpl.apply(value)
  } else if (Ext.type(value) == 'object' && value.value) {
	if (columnModel.linkout_template && Ext.type(value.linkout_tokens) == 'array') {
	  var urlTokens = [columnModel.linkout_template].concat(value.linkout_tokens)
	  return Ext.DomHelper.markup({
		tag: 'A',
		target: '_blank',
		href: String.format.apply(this, urlTokens),
		html: Ext.util.Format.nl2br(Ext.util.Format.htmlEncode(value.value.replace(/<BR\/>/gi, '\n')))
	  })
	} else {
	  return Ext.util.Format.nl2br(Ext.util.Format.htmlEncode(value.value.replace(/<BR\/>/gi, '\n')))
	}
  } else if (Ext.type(value) == 'object' && Ext.type(value.links) == 'array') {
	if (columnModel.linkout_template) {
	  var links = []
	  for (var i = 0; i < value.links.length; i++) {
		if (value.links[i].linkout_tokens && !Ext.isArray(value.links[i].linkout_tokens)) {
		  value.links[i].linkout_tokens = [value.links[i].linkout_tokens]
		}
		if (Ext.isArray(value.links[i].linkout_tokens)) {
		  var urlTokens = [columnModel.linkout_template].concat(value.links[i].linkout_tokens)

		  links.push(Ext.DomHelper.markup({
			tag: 'A',
			target: '_blank',
			href: String.format.apply(this, urlTokens),
			html: Ext.util.Format.nl2br(Ext.util.Format.htmlEncode(value.links[i].value.replace(/<BR\/>/gi, '\n')))
		  }))
		}
	  }
	  return links.join("<BR/><BR/>")
	} else {
	  return Ext.util.Format.nl2br(Ext.util.Format.htmlEncode(value.value.replace(/<BR\/>/gi, '\n')))
	}
  }
  return ""
}


/**
 * Builds a IMG DOM object
 */
RG.EntityTable.generateCellImageTag = function (grid, rowIndex, colIndex, baseURL, replacementTerm, replacementVal, imgWidth, imgHeight, valueObj) {
  var columnId = grid.getColumnModel().getColumnId(colIndex)
  var columnModel = grid.getColumnModel().getColumnById(columnId)
  var columnType = columnModel.type || 'unknown'
  var altText = "Not Available"
  imgHeight = (imgHeight || imgWidth)
  var styleWidth = (imgWidth ? imgWidth + 'px' : 'auto')
  var styleHeight = (imgHeight ? imgHeight + 'px' : (imgWidth ? imgWidth + 'px' : 'auto'))

  var iURL = baseURL
  var imgTag

  if (replacementTerm) {
	iURL = baseURL.replace(new RegExp("\\[" + replacementTerm + "\\]"), replacementVal).replace(/\[width\]/, imgWidth)

	if (columnType === 'person') {
	  imgTag = Ext.DomHelper.markup({
		tag: 'IMG',
		src: iURL,
		height: imgHeight,
		width: imgHeight
	  })
	} else {
	  imgTag = Ext.DomHelper.markup({
		tag: 'DIV',
		// align: 'center',
		style: {
		  height: styleHeight,
		  width: styleWidth,
		  border: "none",
		  background: 'transparent url(' + iURL + ') no-repeat center center'
		}
	  })
	}
  } else {
	var store = grid.getStore()
	var cm = grid.getColumnModel()
	var record = store.getAt(rowIndex); // Get the Record
	var dataIndex = cm.getDataIndex(colIndex); // Get field name
	var pagedRowIndexStart = (store.lastOptions.params && store.lastOptions.params.start ? store.lastOptions.params.start : 0)
	var pagedRowIndex = pagedRowIndexStart + rowIndex

	iURL = grid.sourceURL + (grid.sourceURL.indexOf('?') != -1 ? '&' : '?') + Ext.urlEncode({
	  op: 'GETCELLIMAGE',
	  pagedRowIndex: pagedRowIndex,
	  columnDataIndex: dataIndex,
	  rg_non_op: grid.refreshCounter++
	})

	imgTag = Ext.DomHelper.markup({
	  tag: 'DIV',
	  style: {
		height: styleHeight,
		width: styleWidth,
		border: "none",
		background: 'transparent url(' + iURL + ') no-repeat center center'
	  }
	})
  }

  if (Ext.type(valueObj) == 'object' && columnModel.linkout_template && Ext.type(valueObj.linkout_tokens) == 'array') {
	var urlTokens = [columnModel.linkout_template].concat(valueObj.linkout_tokens)
	return Ext.DomHelper.markup({
	  tag: 'A',
	  target: '_blank',
	  style: 'cursor: pointer !important',
	  href: String.format.apply(this, urlTokens),
	  html: imgTag
	})
  }

  return imgTag
}