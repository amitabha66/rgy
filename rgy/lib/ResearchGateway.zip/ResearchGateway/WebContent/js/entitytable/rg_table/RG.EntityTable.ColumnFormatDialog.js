/**
 * @author jemcdowe
 */
RG.EntityTable.ColumnFormatDialog = Ext.extend(Ext.Window, {
  title: 'Column Format',
  width: 391,
  height: 440,
  modal: true,
  layout: 'border',
  initComponent: function(){
    var dialog = this
            
    if (Ext.isObject(dialog.column)) {
      this.initFormat= dialog.column.format
    }        
    var initDataIndex= null
    this.columns= []
    if (this.grid) {
      var cm = this.grid.getColumnModel()

      for (var i = 1; i < cm.getColumnCount(); i++) {
        var dataIndex = cm.getDataIndex(i)
        var isEntityIDDataIndex = (this.grid.entityIDDataIndexes.indexOf(dataIndex) > -1)
      
        if (!isEntityIDDataIndex) {
          var column= cm.getColumnById(cm.getColumnId(i))
          this.columns.push({
            dataIndex: dataIndex, 
            header: column.header
          })
          if (this.column && this.column.dataIndex== dataIndex) {
            initDataIndex= dataIndex
          }
        }
      }         
    }
        
    dialog.formatTypes = ['General', 'Number', 'Date']
        
    dialog.predefinedFormats = {}
    dialog.predefinedFormats.General = []
    dialog.predefinedFormats.Date = ['01/01/2007 3:30:05 PM', '01/01/2007 3:30 PM', '01/01/2007 15:30:05', '01/01/2007 15:30', '01/01/2007', 'Jan 1, 2007 3:30:05 PM', 'Jan 1, 2007 3:30 PM', 'Jan 1, 2007 15:30:05', 'Jan 1, 2007 15:30', 'Jan 1, 2007', '1 Jan 2007 3:30:05 PM', '1 Jan 2007 3:30 PM', '1 Jan 2007 15:30:05', '1 Jan 2007 15:30', '1 Jan 2007', 'Jan 1 2007 3:30:05 PM', 'Jan 1 2007 3:30 PM', 'Jan 1 2007 15:30:05', 'Jan 1 2007 15:30', 'Jan 1 2007', '3:30 PM', '3:30:05 PM', '15:30', '15:30:05']
    dialog.predefinedFormats.Currency = ['United States', 'Albania', 'Algeria', 'Argentina', 'Australia', 'Austria', 'Bahrain', 'Belarus', 'Belgium', 'Bolivia', 'Brazil', 'Bulgaria', 'Canada', 'Chile', 'China', 'Colombia', 'Costa Rica', 'Croatia', 'Cyprus', 'Czech Republic', 'Denmark', 'Dominican Republic', 'Ecuador', 'Egypt', 'El Salvador', 'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Guatemala', 'Honduras', 'Hong Kong', 'Hungary', 'Iceland', 'India', 'Indonesia', 'Iraq', 'Ireland', 'Israel', 'Italy', 'Japan', 'Jordan', 'Kuwait', 'Latvia', 'Lebanon', 'Libya', 'Lithuania', 'Luxembourg', 'Macedonia', 'Malaysia', 'Malta', 'Mexico', 'Montenegro', 'Morocco', 'Netherlands', 'New Zealand', 'Nicaragua', 'Norway', 'Oman', 'Panama', 'Paraguay', 'Peru', 'Philippines', 'Poland', 'Portugal', 'Puerto Rico', 'Qatar', 'Romania', 'Russia', 'Saudi Arabia', 'Serbia', 'Singapore', 'Slovakia', 'Slovenia', 'South Africa', 'South Korea', 'Spain', 'Sudan', 'Sweden', 'Switzerland', 'Syria', 'Taiwan', 'Thailand', 'Tunisia', 'Turkey', 'Ukraine', 'United Arab Emirates', 'United Kingdom', 'Uruguay', 'Venezuela', 'Vietnam', 'Yemen']
        
    this.items = [{
      xtype: 'form',
      region: 'center',
      frame: true,
      labelAlign: 'top',
      items: [(this.columnCombo = new Ext.form.ComboBox({
        fieldLabel: 'Column To Format',
        emptyText: (this.columns.length== 0 ? undefined : 'Select a column to format'),
        displayField: 'header',
        valueField: 'dataIndex',
        value: initDataIndex,
        anchor: '100%',
        typeAhead: true,
        mode: 'local',
        forceSelection: true,
        triggerAction: 'all',
        editable: false,
        disabled: (this.columns.length== 0),
        store: new Ext.data.Store({
          reader: new Ext.data.JsonReader({
            root: 'columns',
            idProperty: 'dataIndex',
            fields: ['dataIndex', 'header']
          }),
          autoLoad: true,
          data: {
            columns: this.columns
          }          
        }),
        listeners: {
          select: function(combo, record, index){
            var dataIndex= record.get('dataIndex')
            var column= null
            if (dialog.grid) {
              var cm= dialog.grid.getColumnModel()
              var colIndx= cm.findColumnIndex(dataIndex)
              column= cm.getColumnById(cm.getColumnId(colIndx))
              dialog.initFormat= column.format            
              dialog.updateFormatOptions(true)      
              
            }            
          }
        }
      })),(this.typeCombo = new Ext.form.ComboBox({
        fieldLabel: 'Type',
        anchor: '100%',
        typeAhead: true,
        mode: 'local',
        forceSelection: true,
        triggerAction: 'all',
        editable: false,
        store: dialog.formatTypes,
        listeners: {
          select: function(combo, record, index){
            dialog.type = record.get('field1')
            dialog.updateFormatOptions()
          }
        }
      })), (this.formatComboPanel = new Ext.Panel({
        layout: 'form',
        items: [(this.formatCombo = new Ext.form.ComboBox({
          fieldLabel: 'Format (select predefined option or type a custom format)',
          anchor: '100%',
          name: 'format',
          hiddenName: 'format',
          typeAhead: false,
          mode: 'local',
          forceSelection: false,
          triggerAction: 'all',
          editable: true,
          store: []
        }))]
      })), this.decimalFormatForm = new AIG.DecimalFormatForm()]
    }, (this.detailsPanel = new Ext.Panel({
      title: 'Details',
      region: 'south',
      width: 100,
      height: 150,
      autoScroll: true,
      split: true
    }))]
        
    this.on('render', function(){
      new Ext.util.DelayedTask().delay(10, function(){
        this.setInitValues()
      }, dialog)
    })
    this.buttons = [{
      text: 'OK',
      handler: function(){
        var decimalFormat = this.decimalFormatForm.getValues()
        if (!hasLength(dialog.type)) {
          return
        }
        var formatObj = {}
        switch (dialog.type) {
          case 'General':
            break
          case 'Number':
            formatObj = decimalFormat
            break
          case 'Date':
            formatObj.specifier = dialog.formatCombo.getRawValue()
            break
          case 'Currency':
            formatObj.specifier = dialog.formatCombo.getRawValue()
            break
        }
                
        if (Ext.type(dialog.cb) == 'function') {
          var column= null
          if (dialog.grid) {
            var cm= dialog.grid.getColumnModel()
            var colIndx= cm.findColumnIndex(dialog.columnCombo.getValue())
            if (colIndx>=0) {
              column= cm.getColumnById(cm.getColumnId(colIndx))
            }
          }
          var ret= dialog.cb.call(dialog.scope, column, dialog.type, formatObj)
          if (ret=== false) {
            return
          }
        }
        dialog.close()
      },
      scope: this
    }, {
      text: 'Cancel',
      handler: function(){
        this.close()
      },
      scope: this
    }]
    RG.EntityTable.ColumnFormatDialog.superclass.initComponent.call(this);
  },
  updateFormatOptions: function(setInit){
    if (setInit === true) {
      this.type = this.getInitType()
      this.typeCombo.setValue(this.type)
    }
    if (this.predefinedFormats[this.type]) {
      this.formatCombo.store.loadData(this.predefinedFormats[this.type])
    }
    switch (this.type.toUpperCase()) {
      case 'GENERAL':
        this.formatCombo.setDisabled(true)
        this.formatComboPanel.setVisible(false)
        this.decimalFormatForm.setVisible(false)
        this.detailsPanel.load({
          url: '/aig/help/generalformatting.html'
        })
        break;
      case 'NUMBER':
        this.formatCombo.setDisabled(false)
        this.formatCombo.setEditable(true)
        this.formatComboPanel.setVisible(false)
        this.decimalFormatForm.setVisible(true)
        if (this.getInitType() == 'Number') {
          this.decimalFormatForm.notationType.setValue(this.initFormat.format.notation)
          this.decimalFormatForm.decimals.setValue(this.initFormat.format.decimals)
          this.decimalFormatForm.custom.setValue(this.initFormat.format.custom)
        } else {
          this.decimalFormatForm.notationType.setValue('Standard')
          this.decimalFormatForm.decimals.setValue('2')
        }
        this.detailsPanel.load({
          url: '/aig/help/decimalformatting.html'
        })
        break
      case 'DATE':
        this.formatCombo.setDisabled(false)
        this.formatCombo.setEditable(true)
        this.formatComboPanel.setVisible(true)
        this.decimalFormatForm.setVisible(false)
        if (this.getInitType() == 'Date') {
          this.formatCombo.setValue(this.initFormat.format.specifier)
        } else {
          this.formatCombo.setValue(this.formatCombo.store.getAt(0).get('field1'))
        }
        this.detailsPanel.load({
          url: '/aig/help/dateformatting.html'
        })
        break
      case 'CURRENCY':
        this.formatCombo.setDisabled(false)
        this.formatCombo.setEditable(false)
        this.formatComboPanel.setVisible(true)
        this.decimalFormatForm.setVisible(false)
        if (this.getInitType() == 'Currency') {
          this.formatCombo.setValue(this.initFormat.format.specifier)
        } else {
          this.formatCombo.setValue(this.formatCombo.store.getAt(0).get('field1'))
        }
    }
  },
  setInitValues: function(){
    if (!this.initFormat || !this.initFormat.format) {
      this.type = 'General'
      this.updateFormatOptions(true)
    } else {
      this.updateFormatOptions(true)
    }
  },
  getInitType: function(){
    if (!this.initFormat || !this.initFormat.format || !this.initFormat.type) {
      return 'General'
    }
    return this.initFormat.type.substring(0, 1).toUpperCase() + this.initFormat.type.substring(1).toLowerCase()
  }
});

AIG.DecimalFormatForm = Ext.extend(Ext.Panel, {
  labelWidth: 50,
  border: false,
  layout: 'form',
  initComponent: function(){
    var form = this
    this.notation = this.notation || 'Standard'
    this.decimals = this.decimals || 2
    this.items = [{
      xtype: 'panel',
      layout: 'column',
      border: false,
      items: [{
        xtype: 'panel',
        layout: 'form',
        columnWidth: 0.5,
        border: false,
        labelWidth: 55,
        labelAlign: 'top',
        layoutConfig: {
          labelSeparator: ' '
        },
        items: [(this.notationType = new Ext.form.ComboBox({
          xtype: 'combo',
          fieldLabel: 'Notation',
          anchor: '95%',
          typeAhead: true,
          mode: 'local',
          forceSelection: true,
          triggerAction: 'all',
          editable: false,
          value: this.notation,
          store: ['Standard', 'Scientific', 'Engineering', 'Percentage', 'Custom'],
          listeners: {
            select: function(combo, record, index){
              form.setupFields()
            }
          }
        }))]
      }, {
        xtype: 'panel',
        layout: 'form',
        labelAlign: 'top',
        labelWidth: 50,
        columnWidth: 0.5,
        border: false,
        items: [(this.decimals = new Ext.ux.form.Spinner({
          xtype: 'uxspinner',
          fieldLabel: 'Decimals',
          anchor: '95%',
          defaultValue: 2,
          strategy: new Ext.ux.form.Spinner.NumberStrategy({
            minValue: 0,
            maxValue: 20,
            incrementValue: 1
          }),
          minValue: 0,
          maxValue: 20,
          incrementValue: 1,
          value: this.decimals
        }))]
      }]
    }, (this.custom = new Ext.form.TextField({
      xtype: 'textfield',
      fieldLabel: 'Custom',
      anchor: '100%'
    }))];
        
    this.on('render', function(){
      new Ext.util.DelayedTask().delay(10, function(){
        this.setupFields()
      }, form)
    })
    this.on('show', function(){
      new Ext.util.DelayedTask().delay(10, function(){
        this.setupFields()
      }, form)
    })
        
    AIG.DecimalFormatForm.superclass.initComponent.call(this);
  },
  setupFields: function(){
    if (this.notationType.getRawValue() == 'Custom') {
      this.decimals.setDisabled(true)
      this.custom.setDisabled(false)
    } else {
      this.decimals.setDisabled(false)
      this.custom.setDisabled(true)
    }
  },
  getValues: function(){
    return {
      decimals: this.decimals.getValue(),
      notation: this.notationType.getRawValue(),
      custom: this.custom.getValue()
    }
  }
});
