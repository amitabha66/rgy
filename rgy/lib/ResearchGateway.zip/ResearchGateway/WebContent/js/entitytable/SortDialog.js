/**
 * @author jemcdowe
 */
AIG.SortDialog = function(config){
  config = config ||
  {}
  this.entityTable = config.entityTable
    
  var columnComboStore = [['(none)', '(none)']]
  var cm = this.entityTable.getColumnModel()
  for (var i = 0; i < cm.getColumnCount(); i++) {
    if (cm.isSortable(i)) {
      var column = cm.getColumnById(cm.getColumnId(i))
      columnComboStore.push([column.dataIndex, column.hierarchy])
    }
  }
  var form = new Ext.FormPanel({
    region: 'center',
    labelAlign: 'top',
    frame: true,
    width: 280,
    autoScroll: true,
    items: [{
      layout: 'column',
      items: [{
        columnWidth: .5,
        layout: 'form',
        items: [new Ext.form.ComboBox({
          fieldLabel: 'Sort By',
          store: columnComboStore,
          typeAhead: true,
          triggerAction: 'all',
          mode: 'local',
          value: '(none)',
          selectOnFocus: true,
          disabled: !(columnComboStore.length > 1)
        }), new Ext.form.ComboBox({
          hideLabel: true,
          store: columnComboStore,
          typeAhead: true,
          triggerAction: 'all',
          mode: 'local',
          value: '(none)',
          selectOnFocus: true,
          disabled: !(columnComboStore.length > 2)
        }), new Ext.form.ComboBox({
          hideLabel: true,
          store: columnComboStore,
          typeAhead: true,
          triggerAction: 'all',
          mode: 'local',
          value: '(none)',
          selectOnFocus: true,
          disabled: !(columnComboStore.length > 3)
        }), new Ext.form.ComboBox({
          hideLabel: true,
          store: columnComboStore,
          typeAhead: true,
          triggerAction: 'all',
          mode: 'local',
          value: '(none)',
          selectOnFocus: true,
          disabled: !(columnComboStore.length > 4)
        }), new Ext.form.ComboBox({
          hideLabel: true,
          store: columnComboStore,
          typeAhead: true,
          triggerAction: 'all',
          mode: 'local',
          value: '(none)',
          selectOnFocus: true,
          disabled: !(columnComboStore.length > 5)
        })]
      }, {
        columnWidth: .5,
        layout: 'form',
        items: [new Ext.form.ComboBox({
          fieldLabel: 'Direction',
          store: [['ASC', 'Ascending'], ['DESC', 'Descending']],
          typeAhead: true,
          triggerAction: 'all',
          mode: 'local',
          value: 'ASC',
          selectOnFocus: true,
          width: 100,
          disabled: !(columnComboStore.length > 1)
        }), new Ext.form.ComboBox({
          hideLabel: true,
          store: [['ASC', 'Ascending'], ['DESC', 'Descending']],
          typeAhead: true,
          triggerAction: 'all',
          mode: 'local',
          value: 'ASC',
          selectOnFocus: true,
          width: 100,
          disabled: !(columnComboStore.length > 2)
        }), new Ext.form.ComboBox({
          hideLabel: true,
          store: [['ASC', 'Ascending'], ['DESC', 'Descending']],
          typeAhead: true,
          triggerAction: 'all',
          mode: 'local',
          value: 'ASC',
          selectOnFocus: true,
          width: 100,
          disabled: !(columnComboStore.length > 3)
        }), new Ext.form.ComboBox({
          hideLabel: true,
          store: [['ASC', 'Ascending'], ['DESC', 'Descending']],
          typeAhead: true,
          triggerAction: 'all',
          mode: 'local',
          value: 'ASC',
          selectOnFocus: true,
          width: 100,
          disabled: !(columnComboStore.length > 4)
        }), new Ext.form.ComboBox({
          hideLabel: true,
          store: [['ASC', 'Ascending'], ['DESC', 'Descending']],
          typeAhead: true,
          triggerAction: 'all',
          mode: 'local',
          value: 'ASC',
          selectOnFocus: true,
          width: 100,
          disabled: !(columnComboStore.length > 5)
        })]
      }]
    }, new Ext.form.ComboBox({
      fieldLabel: 'Case Sensitive',
      hideLabel: false,
      store: [['YES', 'Yes'], ['NO', 'No']],
      typeAhead: true,
      triggerAction: 'all',
      mode: 'local',
      value: 'NO',
      selectOnFocus: true,
      width: 100,
      disabled: !(columnComboStore.length > 1)
    })]
  })
  var dialog = new Ext.Window({
    title: 'Sort',
    layout: 'border',
    width: 360,
    height: 320,
    stateful: false,
    resizable: true,
    closeAction: 'hide',
    plain: true,
    items: [form],
    buttons: [{
      text: 'OK',
      handler: function(){
        var sortPanel = form.items.get(0).items.get(0)
        var directionPanel = form.items.get(0).items.get(1)
        var sort = []
        var direction = []
        for (var i = 0; i < 5; i++) {
          if (!sortPanel.items.get(i).disabled) {
            var sortColumn = sortPanel.items.get(i).getValue()
            var sortDirection = directionPanel.items.get(i).getValue()
            if (sortColumn != '(none)') {
              sort.push(sortColumn)
              direction.push(sortDirection)
            }
          }
        }
        var caseSensitive = form.items.get(1).getValue()
        if (Ext.type(config.handler) == 'function' && sort.length > 0) {
          config.handler.call(config.scope, {
            sort: sort,
            direction: direction,
            caseSensitive: caseSensitive
          })
        }
        dialog.hide();
        dialog = null
      }
    }, {
      text: 'Cancel',
      handler: function(){
        dialog.hide();
        dialog = null
      }
    }]
  })
  dialog.show();
}
