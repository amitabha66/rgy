/**
 * Creates a Toolbar SplitButton that retain the last menu selection and uses that as the button
 * @author jemcdowe
 */
AIG.BoundSplitButton = Ext.extend(Ext.Toolbar.SplitButton, {
    initComponent: function(){
        var button = this
        this.handler = function(){
            if (button.lastAddDataItem) {
                button.lastAddDataItem.handler.call(button.lastAddDataItem.scope, button.lastAddDataItem)
            }
        }
        AIG.BoundSplitButton.superclass.initComponent.call(this);
        this.menu.on("click", function(menu, item, evt){
            this.setCurrentDefaultItem(item)
        }, this)
    },
    onRender: function(ct, position){
        Ext.Toolbar.SplitButton.prototype.onRender.call(this, ct, position)
        if (this.menu.store) {
            this.menu.on("menuload", function(menu){
                menu.un("menuload", arguments.callee)
                if (menu.items.getCount() > 0) {
                    this.setCurrentDefaultItem(menu.items.get(0))
                }                
            }, this)
            this.menu.store.load()
        } else if (this.menu.items.getCount() > 0) {
            this.setCurrentDefaultItem(this.menu.items.get(0))
        }
    },
    setCurrentDefaultItem: function(item){
        this.lastAddDataItem = item
        if (this.getText()) {
            this.setText(this.lastAddDataItem.text)
        }
        if (this.lastAddDataItem.iconCls) {
            this.setIconClass(this.lastAddDataItem.iconCls)
        } else {
            this.setIconClass(this.iconCls)
        }
        
        var btnEl = this.getEl().child(this.buttonSelector)
        Ext.QuickTips.register({
            target: btnEl.id,
            text: this.lastAddDataItem.tooltip
        });
    }
    
})
Ext.reg('boundsplitbutton', AIG.BoundSplitButton);
