/*
 ********************************************************
 * Defines the AIG Explorer service results/tabs panel
 ********************************************************
 */
RG.Main.MainContainerPanel = Ext.extend(Ext.Panel, {
  id: 'rg-main-container-panel',
  region: 'center',
  layout: 'fit',
  margins: '2 5 5 0',
  border: true,
  bodyStyle: 'background: white url(/aig/img/rg_watermark.gif) no-repeat center',
  serviceTabsWindows: new Ext.util.MixedCollection(),
  showWindow: function(windowID, maximized) {
    if (this.serviceTabsWindows.containsKey(windowID)) {
      if (maximized) {
        this.serviceTabsWindows.get(windowID).maximize()
      }
      this.serviceTabsWindows.get(windowID).show()
      this.serviceTabsWindows.get(windowID).minimized = false
    }
  },
  minimizeWindow: function minimizeWin(windowID) {
    if (this.serviceTabsWindows.containsKey(windowID)) {
      this.serviceTabsWindows.get(windowID).minimized = true;
      this.serviceTabsWindows.get(windowID).hide();
    }
  },
  closeServiceTabsWindow: function(serviceTabsWindow) {
    this.removeTaskbarButton(serviceTabsWindow.windowID)
    this.serviceTabsWindows.removeKey(serviceTabsWindow.windowID)

  },
  closeWindows: function() {
    var keys = new Array()
    this.serviceTabsWindows.eachKey(function(key) {
      keys.push(key)
    })
    Ext.each(keys, function(key) {
      try {
        this.serviceTabsWindows.get(key).close()
      } catch (e) {
      }
    }, this)
  },
  minimizeWindows: function() {
    this.serviceTabsWindows.eachKey(function(key) {
      this.minimizeWindow(key)
    }, this)
  },
  getWindowCount: function() {
    return this.serviceTabsWindows.getCount()
  },
  createServiceView: function(serviceViewConfig) {
    if (!this.serviceTabsWindows.containsKey(serviceViewConfig.nodeKey)) {
      var tabIconClass = this.getTabIconClsFromNode(serviceViewConfig.iconCls)
      this.serviceTabsWindows.add(serviceViewConfig.nodeKey, new RG.Main.ResourcesWindow({
        title: serviceViewConfig.nodeTitle,
        renderToMain: true,
        windowID: serviceViewConfig.nodeKey,
        nodeKey: serviceViewConfig.nodeKey,
        parentContainer: this,
        parentContainerInitFraction: 1,
        iconCls: tabIconClass
      }))
      var windowToolbarButton = this.addTaskbarButton(serviceViewConfig.nodeKey)
      this.serviceTabsWindows.get(serviceViewConfig.nodeKey).windowToolbarButton = windowToolbarButton
      this.serviceTabsWindows.get(serviceViewConfig.nodeKey).animateTarget = windowToolbarButton.el;
      this.serviceTabsWindows.get(serviceViewConfig.nodeKey).show()
      this.serviceTabsWindows.get(serviceViewConfig.nodeKey).minimized = false
    }
    var newTab = this.serviceTabsWindows.get(serviceViewConfig.nodeKey).getTabPanel().createServiceView(serviceViewConfig)
    if (newTab) {
      this.serviceTabsWindows.get(serviceViewConfig.nodeKey).show()
      if (this.serviceTabsWindows.get(serviceViewConfig.nodeKey).getTabPanel().items.getCount() == 1) {
        this.activateTab(serviceViewConfig.nodeKey, newTab)
      }
    }
    return newTab
  },
  /*
   * Creates a Widget Windows in the tab view
   */
  createWidgetView: function(serviceRecord) {
    var key = serviceRecord.get('ServiceKey')
    if (!this.serviceTabsWindows.containsKey(key)) {
      this.serviceTabsWindows.add(key, new RG.Main.WidgetWindow({
        title: serviceRecord.get("Name"),
        serviceRecord: serviceRecord,
        renderToMain: true,
        windowID: key,
        parentContainer: this,
        parentContainerInitFraction: 1,
        iconCls: RG.Icon.Utils.getSizedIconClass(serviceRecord.get('IconCls'), 16)
      }))
      var windowToolbarButton = this.addTaskbarButton(key)
      this.serviceTabsWindows.get(key).windowToolbarButton = windowToolbarButton
      this.serviceTabsWindows.get(key).animateTarget = windowToolbarButton.el;
      this.serviceTabsWindows.get(key).show()
      this.serviceTabsWindows.get(key).minimized = false
    }
  },
  activateTab: function(windowKey, tabPanel) {
    if (this.serviceTabsWindows.get(windowKey)) {
      this.serviceTabsWindows.get(windowKey).show()
      this.serviceTabsWindows.get(windowKey).getTabPanel().activate(tabPanel)
    }
  },
  createEmptyServiceWindow: function(serviceViewConfig, entityNode) {
    var serviceWindow = this.serviceTabsWindows.get(serviceViewConfig.nodeKey)
    if (!serviceWindow) {
      var tabIconClass = this.getTabIconClsFromNode(serviceViewConfig.iconCls)
      this.serviceTabsWindows.add(serviceViewConfig.nodeKey, new RG.Main.ResourcesWindow({
        title: serviceViewConfig.nodeTitle,
        renderToMain: true,
        windowID: serviceViewConfig.nodeKey,
        nodeKey: serviceViewConfig.nodeKey,
        parentContainer: this,
        parentContainerInitFraction: 1,
        iconCls: tabIconClass
      }))
      var windowToolbarButton = this.addTaskbarButton(serviceViewConfig.nodeKey)
      serviceWindow = this.serviceTabsWindows.get(serviceViewConfig.nodeKey)
      serviceWindow.windowToolbarButton = windowToolbarButton
      serviceWindow.animateTarget = windowToolbarButton.el;
      serviceWindow.minimized = false
    }
    if (serviceWindow.getTabPanel().items.getCount() == 0) {
      //Add selected resources- if available
      //Search the parent nodes for them
      var preloadResourceServiceRecords = null
      var parentNode = entityNode
      while (Ext.isObject(parentNode)) {
        if (Ext.isObject(parentNode.resourceServiceRecords) &&
                Ext.isArray(parentNode.resourceServiceRecords.serviceRecords) &&
                parentNode.resourceServiceRecords.serviceRecords.length > 0 &&
                equalsIgnoreCase(parentNode.resourceServiceRecords.entityCategory, entityNode.attributes.entity_category)
                ) {
          preloadResourceServiceRecords = parentNode.resourceServiceRecords
          break
        }
        parentNode = parentNode.parentNode
      }
      if (Ext.isObject(preloadResourceServiceRecords) && Ext.isArray(preloadResourceServiceRecords.serviceRecords) && preloadResourceServiceRecords.serviceRecords.length > 0) {
        for (var i = 0; i < preloadResourceServiceRecords.serviceRecords.length; i++) {
          var serviceRecord = preloadResourceServiceRecords.serviceRecords[i]
          this.createServiceView({
            nodeKey: serviceViewConfig.nodeKey,
            nodeTitle: serviceViewConfig.nodeTitle,
            iconCls: serviceViewConfig.iconCls,
            serviceTitle: serviceRecord.data.Name,
            serviceURL: "/aig/executeentityservice.go?treeNodeKey=" + serviceViewConfig.nodeKey + "&serviceKey=" + serviceRecord.data.ServiceKey,
            serviceKey: serviceRecord.data.ServiceKey
          })
        }
      } else {
        serviceWindow.addResource(function(win, resourceAdded) {
          if (resourceAdded) {
            win.show()
          } else {
            win.close()
          }
        }, this)
      }
    } else {
      serviceWindow.show()
    }
  },
  getTabIconClsFromNode: function(nodeIconCls) {
    var tabIconClass = "results"
//    if (!nodeIconCls || !nodeIconCls.match(/Node$/)) {
    if (!nodeIconCls) {
      return tabIconClass
    }
    return nodeIconCls.replace(/Node$/, "")
  },
  addTaskbarButton: function(windowID) {
    var tb = Ext.getCmp('aig_main-panel').getBottomToolbar()
    var window = this.serviceTabsWindows.get(windowID)
    var toolbarButton = tb.addButton({
      iconCls: window.iconCls,
      icon: '/aig/img/window.gif',
      windowID: windowID,
      parentServiceTabsWindowContainer: this,
      handler: function(button, evt) {
        this.parentServiceTabsWindowContainer.showWindow(button.windowID)
      },
      text: Ext.util.Format.ellipsis(window.title, 12)
    })
    tb.doLayout()
    window.toolbarButton = toolbarButton
    return toolbarButton
  },
  removeTaskbarButton: function(windowID) {
    var tb = Ext.getCmp('aig_main-panel').getBottomToolbar()
    var window = this.serviceTabsWindows.get(windowID)
    var button = window.toolbarButton
    if (button) {
      button.destroy();
    }
    tb.doLayout()
  },
  tile: function(orientation, window) {
    var nonMinimizedWindows = []
    for (var i = 0; i < this.serviceTabsWindows.getCount(); i++) {
      if (!this.serviceTabsWindows.item(i).minimized) {
        nonMinimizedWindows.push(this.serviceTabsWindows.item(i))
      }
    }
    if (window && !window.minimized) {
      nonMinimizedWindows = [window]
      orientation = 'tile'
    }
    orientation = orientation || 'tile'
    var conWidth = this.getInnerWidth()
    var conHeight = this.getInnerHeight()
    var headerOffset = (this.header == null ? 0 : this.header.getHeight())
    var toolBarOffset = (this.getTopToolbar() == null ? 0 : this.getTopToolbar().getSize().height)
    var winCount = nonMinimizedWindows.length
    var cols
    var rows

    switch (orientation.toLowerCase().charAt(0)) {
      case 'h':
        cols = 1
        rows = winCount
        break
      case 'v':
        cols = winCount
        rows = 1
        break
      default:
        cols = Math.ceil(Math.sqrt(winCount))
        rows = Math.ceil(winCount / cols)
        break
    }
    var lastRow = winCount - cols * (rows - 1);
    var width = conWidth / cols
    var height = conHeight / (lastRow == 0 ? rows - 1 : rows)

    var row = 0
    var previousWin = null
    for (var i = 0; i < winCount; i++) {
      var win = nonMinimizedWindows[i]
      win.setWidth(width)
      win.setHeight(height)
      if (i % cols == 0) {
        var x = 0
        var y = row * height + headerOffset + toolBarOffset
        var offsetCoords = win.getEl().getAlignToXY(this.getId(), "tl-tl", [x, y])
        win.setPagePosition(offsetCoords[0], offsetCoords[1])
        row++
      } else {
        win.alignTo(previousWin.getId(), 'tl-tr', null, true)
      }
      previousWin = win
    }
  },
  syncWindowWithParent: function(window, direction) {
    var conWidth = this.getInnerWidth()
    var conHeight = this.getInnerHeight()
    var headerOffset = (this.header == null ? 0 : this.header.getHeight())
    var toolBarOffset = (this.getTopToolbar() == null ? 0 : this.getTopToolbar().getSize().height)
    var x = 0
    var y = headerOffset + toolBarOffset
    var offsetCoords = window.getEl().getAlignToXY(this.getId(), "tl-tl", [x, y])

    switch (direction) {
      case 'x':
        window.setPagePosition(offsetCoords[0], window.getPosition()[1]) //offsetCoords[1])
        if (window.minWidth) {
          window.setWidth(Math.max(conWidth, window.minWidth))
        } else {
          window.setWidth(conWidth)
        }
        break
      case 'y':
        window.setPagePosition(window.getPosition()[0], offsetCoords[1])
        if (window.minHeight) {
          window.setHeight(Math.max(conHeight, window.minHeight))
        } else {
          window.setHeight(conHeight)
        }
        break
    }
  }
})




