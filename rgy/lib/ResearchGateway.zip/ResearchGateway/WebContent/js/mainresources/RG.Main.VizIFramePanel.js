/**
 * Defines the RG.Main.VizIFramePanel used to view service results 
 * in a tab panel
 *
 * @class RG.Main.VizIFramePanel
 * @extends RG.Main.ResourceIFramePanel
 *
 */
RG.Main.VizIFramePanel = Ext.extend(Ext.Panel, {
  layout: 'border',
  iconCls: 'service-needs-updating-tab',
  initComponent: function() {
    var me = this

    Ext.applyIf(this, {
      vizConfig: this.serviceViewConfig.vizConfig,
      vizTarget: 'WEBPLAYER'
    })

    this.vizRecordStore = new Ext.data.Store({
      autoLoad: true,
      reader: new Ext.data.JsonReader({
        root: "urls",
        idProperty: 'id'
      }, RG.Record.VizRecord),
      data: {
        urls: this.vizConfig.urls
      }
    })
    var dataSetNodes = []
    this.vizRecordStore.each(function(r) {
      dataSetNodes.push({
        id: r.get('id'),
        rid: r.get('id'),
        text: r.get('name'),
        qtip: r.get('desc') || r.get('name'),
        leaf: true,
        iconCls: "tree-icon-24 ix-v0-24-text_code_colored"
      })
    })
    this.datasetsPanel = new Ext.tree.TreePanel({
      region: 'west',
      title: 'Select A Dataset and Target',
      tbar: [{
          text: 'Spotfire WebPlayer',
          enableToggle: true,
          toggleGroup: 'sf_target',
          iconCls: 'ix-v0-16-text_code_colored',
          pressed: true,
          tooltip: 'Open the visualization using the Spotfire WebPlayer tool. The visualization will appear in the RG browser window.',
          listeners: {
            toggle: function(button, pressed) {
              if (pressed) {
                me.vizTarget = 'WEBPLAYER'
              }
            }
          }
        }, {
          text: 'Spotfire Desktop',
          enableToggle: true,
          toggleGroup: 'sf_target',
          iconCls: 'ix-v0-16-target3',
          pressed: false,
          tooltip: 'Open the visualization in the Spotfire desktop client application the Spotfire WebPlayer tool.' +
                  ' Note that the Spotfire desktop client must be installed.',
          listeners: {
            toggle: function(button, pressed) {
              if (pressed) {
                me.vizTarget = 'DXP'
              }
            }
          }
        }],
      width: 250,
      autoScroll: true,
      rootVisible: false,
      split: true,
      collapsible: true,
      collapseMode: 'mini',
      hideCollapseTool: true,
      collapsed: (this.vizRecordStore.getCount() == 1),
      useSplitTips: true,
      root: new Ext.tree.AsyncTreeNode({
        text: 'Datasets',
        expandable: true,
        expanded: true,
        children: dataSetNodes
      }),
      listeners: {
        click: me.setVizURL.createDelegate(me),
        collapse: function(panel) {
          var f = function() {
            var minButtonEl = me.getEl().child("div.x-layout-cmini-west")
            if (!minButtonEl.tooltip) {
              minButtonEl.tooltip = new Ext.rx.AnchorToolTip({
                anchor: 'left',
                baseCls: 'x-tipyellow',
                title: 'Datasets Selector Is Hidden',
                html: 'To change datasets<BR/>Press arrow to reopen.',
                adjustPosition: function(x, y) {
                  return {
                    x: x,
                    y: y
                  }
                },
                showBy: function(el) {
                  if (!this.rendered) {
                    this.render(Ext.getBody());
                  }
                  this.showAt(this.el.getAlignToXY(el, 'c-r', [15, -12]));
                }
              })
            }
            minButtonEl.tooltip.showBy(minButtonEl);
          }
          f.defer(10)
        }
      }})

    this.items = []

    if (this.vizRecordStore.getCount() == 1) {
      this.iFramePanel = new RG.Main.ResourceIFramePanel({
        region: 'center',
        defaultSrc: this.vizRecordStore.getAt(0).get('wpURL'),
        serviceViewConfig: this.serviceViewConfig
      })
      this.items.push(this.datasetsPanel, this.iFramePanel)
    } else if (this.vizRecordStore.getCount() > 1) {
      this.iFramePanel = new RG.Main.ResourceIFramePanel({
        region: 'center',
        defaultSrc: "about:blank",
        serviceViewConfig: this.serviceViewConfig
      })
      this.items.push(this.datasetsPanel, this.iFramePanel)
    }

    RG.Main.VizIFramePanel.superclass.initComponent.call(this)

    this.addEvents('documentloaded', 'activate')
    this.relayEvents(this.iFramePanel, ['documentloaded', 'activate'])

    this.on('documentloaded', function() {
      me.setLoadedStatus('complete')
      if (Ext.getCmp("aig-tab-settings")) {
        Ext.getCmp("aig-tab-settings").setServiceQueryForm(this)
      }
      var win = me.findParentByInstanceOf(Ext.Window)
      try {
        win.doLayout()
      } catch (e) {
      }
    })
    this.on('activate', function() {
      if (me.loadedStatus == 'uninitialized') {
        me.setLoadedStatus('loading')
      }
    })
  },
  setVizURL: function(node) {
    var me = this
    var vizRecord = (RG.isRecordType(node, 'VizRecord') ? node : this.vizRecordStore.getById(node.attributes.rid))
    if (Ext.isRecord(vizRecord)) {
      switch (me.vizTarget) {
        case 'DXP':
          callDocumentDownViaIFrame({
            src: vizRecord.get('dxpURL')
          })
          break;
        default:
          Ext.MessageBox.show({
            msg: 'Loading dataset, please wait...',
            progressText: 'Loading...',
            width: 200,
            wait: true,
            waitConfig: {interval: 200}
          });
          Ext.MessageBox.hide.defer(4000, Ext.MessageBox)
          me.datasetsPanel.collapse()
          me.iFramePanel.setSrc(vizRecord.get('wpURL'), true, function() {
          })
          break
      }
    }
  },
  /**
   * Sets the load status of the iframe and resets the icon
   * @param {String} loaded- uninitialized | loading | complete
   */
  setLoadedStatus: function(loaded) {
    this.loadedStatus = loaded
    this.updateIcon()
  },
  /**
   * Properly updates the window/tab icon
   */
  updateIcon: function() {
    var iconCls = 'service-done-tab'
    switch (this.loadedStatus) {
      case 'uninitialized':
        iconCls = 'service-needs-updating-tab'
        break
      case 'loading':
        iconCls = 'service-running-tab'

        break
      case 'complete':
      default:
        iconCls = 'service-done-tab'
        break
    }
    var currIconCls = this.iconCls
    if (currIconCls != iconCls) {
      if (this.ownerCt != null) {
        switch (this.ownerCt.getXType()) {
          case 'window':
            this.ownerCt.setIconClass(iconCls)
            break
          default:
            this.setIconClass(iconCls)
            this.fireEvent('titlechange', this, null, currIconCls)
            break
        }
      }
    }
  }
})
