/**
 * Defines the AIG Explorer service results/tabs panel
 * 
 * @param {Object} config
 * @author    J. McDowell
 * @date      23 March 2009
 * @version   $Id: RG.Main.ResourcesWindow.js,v 1.1 2013/12/03 17:36:25 jemcdowe Exp $
 * 
 */
RG.Main.ResourcesWindow = Ext.extend(RG.Dialog.AnimatedWindow, {
  closable: true,
  plain: true,
  layout: 'fit',
  maximizable: true,
  minimizable: true,
  minHeight: 200,
  minWidth: 200,
  constrain: true,
  closeAction: 'close',
  initComponent: function() {
    this.tabPanel = new RG.Main.ResourceTabsPanel({
      windowID: this.windowID,
      addTabText: "Add Resources",
      plugins: [Ext.ux.AddTabButton],
      createTab: function() {
        this.ownerCt.addResource()
      }
    })
    this.items = [this.tabPanel]

    this.plugins = [new Ext.ux.IconMenu({
        customItems: ['separator', {
            text: 'Full Window',
            iconCls: 'icon-zoom',
            scope: this,
            handler: function() {
              try {
                var cmp = Ext.getCmp('layout-browser')
                cmp.collapse(true)
                this.maximized = false
                this.maximize()
              } catch (e) {
              }
            }
          }]
      })]

    this.windowID = this.windowID
    this.parentServiceTabsWindowContainer = this.parentContainer

    this.on('close', function(win) {
      win.parentServiceTabsWindowContainer.closeServiceTabsWindow(win)
    })
    this.on('minimize', function(win) {
      win.parentServiceTabsWindowContainer.minimizeWindow(win.windowID)
    })
    this.on('show', function(win) {
      if (Ext.type(win.callback) == 'function') {
        win.callback.call(win.callback, win)
        if (!win.callbackeveryshow) {
          win.callback = Ext.emptyFn
        }
      }
    }
    )
    /*
     this.tools= [{
     id: 'help',
     handler: function() {}
     }]
     */
    RG.Main.ResourcesWindow.superclass.initComponent.apply(this, arguments);
  },
  getTabPanel: function() {
    return this.tabPanel
  },
  activateTabByTitle: function(title) {
    var panel = this.getTabPanel().find('title', title)
    if (panel && panel.length > 0) {
      this.getTabPanel().activate(panel[0])
    }
  },
  /**
   * Override the Window method to properly accommodate the header/footer toolbars
   */
  fitContainer: function() {
    var vs = this.container.getViewSize();
    var serviceViewsContainerPanel = Ext.getCmp("rg-main-container-panel")
    var containerHeader = serviceViewsContainerPanel.header
    var topToolbar = serviceViewsContainerPanel.getTopToolbar()
    var bottomToolbar = serviceViewsContainerPanel.getBottomToolbar()

    var headerOffset = (containerHeader == null ? 0 : containerHeader.getHeight())
    var topToolBarOffset = (topToolbar == null ? 0 : topToolbar.getSize().height)
    var bottomToolbarOffset = (bottomToolbar == null ? 0 : bottomToolbar.getSize().height)
    this.setSize(vs.width, vs.height - topToolBarOffset - bottomToolbarOffset);
  },
  addResource: function(cb, scope) {
    new RG.Dialog.ServiceSelectDialog({
      queryParams: {
        queryType: 'NODE_RESOURCES',
        query: this.nodeKey
      },
      autoSelectSingleResource: true,
      scope: this,
      cb: function(submit, serviceRecord, paramValues) {
        var serviceTabsPanel = Ext.getCmp("rg-main-container-panel")
        var serviceTabURL
        if (submit) {
          serviceTabURL = "/aig/executeentityservice.go?treeNodeKey=" + this.nodeKey + "&serviceKey=" + serviceRecord.data.ServiceKey
          var newTab = serviceTabsPanel.createServiceView({
            nodeKey: this.nodeKey,
            nodeTitle: this.nodeTitle,
            iconCls: this.iconCls,
            serviceTitle: serviceRecord.data.Name,
            serviceURL: serviceTabURL,
            serviceKey: serviceRecord.data.ServiceKey,
            serviceParams: paramValues
          })
          if (newTab) {
            serviceTabsPanel.activateTab(this.nodeKey, newTab)
          }
        }
        if (Ext.isFunction(cb)) {
          cb.call(scope, this, submit)
        }
      }
    }).show()
  }

})
