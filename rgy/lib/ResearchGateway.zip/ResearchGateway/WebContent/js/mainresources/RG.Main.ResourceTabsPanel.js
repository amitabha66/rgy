/*
 ********************************************************
 * Defines the AIG Explorer content panel used to populate 
 * content windows
 ********************************************************
 */
/*
 RG.Main.ResourceTabsPanel = function(config) {
 config = config ||
 {}
 this.windowID = config.windowID
 config.plain = true
 config.activeItem = 0
 config.plugins = config.plugins || []
 config.plugins.push(new Ext.ux.TabCloseMenu())
 
 config.defaults = {
 bodyStyle: 'padding:0px'
 }
 config.enableTabScroll = true
 
 config.listeners = {
 tabchange: function(tabPanel, tab) {
 tabPanel.tabChange(tabPanel, tab)
 }
 }
 Ext.apply(this, config)
 RG.Main.ResourceTabsPanel.superclass.constructor.call(this)
 }
 */
RG.Main.ResourceTabsPanel = Ext.extend(Ext.TabPanel, {
  initComponent: function() {
    Ext.apply(this, {
      plain: true,
      activeItem: 0,
      defaults: {
        bodyStyle: 'padding:0px'
      },
      enableTabScroll: true
    })

    this.on('tabchange', function(tabPanel, tab) {
      tabPanel.tabChange(tabPanel, tab)
    })

    Ext.applyIf(this, {
      plugins: []
    })
    this.plugins.push(new Ext.ux.TabCloseMenu())

    RG.Main.ResourceTabsPanel.superclass.initComponent.call(this)
  },
  initEvents: function() {
    RG.Main.ResourceTabsPanel.superclass.initEvents.call(this);
    this.mon(this.strip, {
      scope: this,
      dblclick: function(evt, el, obj) {
        evt.preventDefault();
        var t = this.findTargets(evt);
        if (t.item) {
          t.item.fireEvent('tabdblclick')
        }
      }
    });


  },
  createServiceView: function(serviceViewConfig) {
    if (Ext.isObject(serviceViewConfig.vizConfig)) {
      return this.createVizView(serviceViewConfig)
    } else {
      return this.createBasicServiceView(serviceViewConfig)
    }
  },
  createBasicServiceView: function(serviceViewConfig) {
    if (!serviceViewConfig.resultKey && !serviceViewConfig.isRawURL) {
      serviceViewConfig.resultKey = new UUID()
      serviceViewConfig.serviceURL = serviceViewConfig.serviceURL +
              (serviceViewConfig.serviceURL.indexOf("?") > 0 ? "&" : "?") +
              "resultKey=" + serviceViewConfig.resultKey
    }
    var mif = new RG.Main.ResourceIFramePanel({
      title: serviceViewConfig.serviceTitle,
      defaultSrc: serviceViewConfig.serviceURL,
      serviceViewConfig: serviceViewConfig,
      closable: true
    })
    this.add(mif)
    return mif
  },
  createVizView: function(serviceViewConfig) {
    if (Ext.isObject(serviceViewConfig.vizConfig) &&
            Ext.isArray(serviceViewConfig.vizConfig.urls)
            && serviceViewConfig.vizConfig.urls.length > 0) {
      var viz = new RG.Main.VizIFramePanel({
        title: serviceViewConfig.serviceTitle,
        defaultSrc: serviceViewConfig.serviceURL,
        serviceViewConfig: serviceViewConfig,
        closable: true
      })
      this.add(viz)
      return viz
    }
    return null
  },
  onItemTitleChanged: function(item, title, oldIconCls) {
    var el = this.getTabEl(item);
    if (el) {
      var span = Ext.fly(el).child('span.x-tab-strip-text');
      if (title) {
        span.update(title);
      }
      if (oldIconCls) {
        span.replaceClass(oldIconCls, item.iconCls);
      }
    }
  },
  tabChange: function(tabPanel, tab) {
    if (Ext.getCmp("aig-tab-settings")) {
      Ext.getCmp("aig-tab-settings").setServiceQueryForm(tab)
    }

    if (Ext.isFunction(tab.tabSelected)) {
      tab.tabSelected.call(tab, this)
    }
  }

})
