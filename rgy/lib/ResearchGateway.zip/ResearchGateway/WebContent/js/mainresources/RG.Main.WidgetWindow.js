/**
 * Defines the AIG Explorer service results/tabs panel
 * 
 * @param {Object} config
 * @author    J. McDowell
 * @date      23 March 2009
 * @version   $Id: RG.Main.WidgetWindow.js,v 1.1 2013/12/03 17:36:25 jemcdowe Exp $
 * 
 */
RG.Main.WidgetWindow= Ext.extend(RG.Dialog.AnimatedWindow, {
  closable: true,
  plain: true,
  layout: 'fit',
  maximizable: true,
  minimizable: true,
  minHeight: 200,
  minWidth: 200,
  constrain: true,
  closeAction: 'close',
    
  initComponent: function(){    
    var htmlDocument= this.serviceRecord.get('WidgetURL')
        
    this.items = new Ext.ux.ManagedIframePanel({
      defaultSrc: htmlDocument
    })    
    
    this.plugins= [new Ext.ux.IconMenu({
      customItems: ['separator', {
        text: 'Full Window',
        iconCls: 'icon-zoom',
        scope: this,
        handler: function(){
          try {
            var cmp = Ext.getCmp('layout-browser')
            cmp.collapse(true)
            this.maximized= false
            this.maximize()
          } catch (e) {
          }
        }
      }]
    })]    
    
    this.windowID = this.windowID
    this.parentServiceTabsWindowContainer = this.parentContainer
       
    this.on('close', function(win){
      win.parentServiceTabsWindowContainer.closeServiceTabsWindow(win)
    })
    this.on('minimize', function(win){
      win.parentServiceTabsWindowContainer.minimizeWindow(win.windowID)
    })
    this.on('show', function(win){
      if (Ext.type(win.callback) == 'function') {
        win.callback.call(win.callback, win)
        if (!win.callbackeveryshow) {
          win.callback = Ext.emptyFn
        }
      }
    }
    )
    RG.Main.WidgetWindow.superclass.initComponent.apply(this, arguments);
  },
  /**
 * Override the Window method to properly accommodate the header/footer toolbars
 */
  fitContainer: function(){
    var vs = this.container.getViewSize();
    var serviceViewsContainerPanel = Ext.getCmp("rg-main-container-panel")
    var containerHeader = serviceViewsContainerPanel.header
    var topToolbar = serviceViewsContainerPanel.getTopToolbar()
    var bottomToolbar = serviceViewsContainerPanel.getBottomToolbar()
        
    var headerOffset = (containerHeader == null ? 0 : containerHeader.getHeight())
    var topToolBarOffset = (topToolbar == null ? 0 : topToolbar.getSize().height)
    var bottomToolbarOffset = (bottomToolbar == null ? 0 : bottomToolbar.getSize().height)
    this.setSize(vs.width, vs.height - topToolBarOffset - bottomToolbarOffset);
  }
      
})
