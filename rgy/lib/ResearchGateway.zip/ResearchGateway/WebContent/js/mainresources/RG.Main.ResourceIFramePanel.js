/**
 * Defines the RG.Main.ResourceIFramePanel used to view service results 
 * in a tab panel
 *
 * @class RG.Main.ResourceIFramePanel
 * @extends Ext.ux.ManagedIframePanel
 *
 */
RG.Main.ResourceIFramePanel = Ext.extend(Ext.ux.ManagedIframePanel, {
  initComponent: function() {
    var me = this
    Ext.apply(this, {
      frameConfig: {
        marginHeight: '0',
        marginWidth: '0'
      }}
    )

    this.on('documentloaded', function(tabItem) {
      me.setLoadedStatus('complete')
      if (Ext.getCmp("aig-tab-settings")) {
        Ext.getCmp("aig-tab-settings").setServiceQueryForm(this)
      }
      var win = me.findParentByInstanceOf(Ext.Window)
      try {
        win.doLayout()
      } catch (e) {
      }
    })
    this.on('activate', function() {
      if (me.loadedStatus == 'uninitialized') {
        me.setLoadedStatus('loading')
      }
    })
    this.on('destroy', function() {
      if (me.serviceViewConfig && me.serviceViewConfig.resultKey) {
        AIG.removeSessionCacheItem(me.serviceViewConfig.resultKey)
      }
    })
    if (!this.iconCls) {
      this.serviceIcon = true
      this.iconCls = 'service-needs-updating-tab'
    }
    this.setLoadedStatus('uninitialized')
    RG.Main.ResourceIFramePanel.superclass.initComponent.call(this)
  },
  /**
   * Sets the load status of the iframe and resets the icon
   * @param {String} loaded- uninitialized | loading | complete
   */
  setLoadedStatus: function(loaded) {
    this.loadedStatus = loaded
    if (this.serviceIcon) {
      this.updateIcon()
    }
  },
  /**
   * Properly updates the window/tab icon
   */
  updateIcon: function() {
    var iconCls = 'service-done-tab'
    switch (this.loadedStatus) {
      case 'uninitialized':
        iconCls = 'service-needs-updating-tab'
        break
      case 'loading':
        iconCls = 'service-running-tab'

        break
      case 'complete':
      default:
        iconCls = 'service-done-tab'
        break
    }
    var currIconCls = this.iconCls
    if (currIconCls != iconCls) {
      if (this.ownerCt != null) {
        switch (this.ownerCt.getXType()) {
          case 'window':
            this.ownerCt.setIconClass(iconCls)
            break
          default:
            this.setIconClass(iconCls)
            this.fireEvent('titlechange', this, null, currIconCls)
            break
        }
      }
    }
  },
  /**
   * Reloads the iframe- forcing it to not use the cache
   * @param {Object} queryForm
   * @param {Object} formAction
   */
  updateTabFromForm: function(queryForm, formAction) {
    this.setSrc(null, null, null, true)
  }
})
