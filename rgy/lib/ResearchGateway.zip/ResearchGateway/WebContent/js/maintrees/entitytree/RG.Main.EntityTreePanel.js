/*
 ********************************************************
 * Defines the AIG Explorer entity/data items tree
 ********************************************************
 */

AIG.entityTreePanel = new Ext.tree.TreePanel({
  initComponent: function() {    
    Ext.tree.TreePanel.prototype.initComponent.call(this)
  },
  id: 'entity-tree-panel',
  region: 'center',
  autoScroll: true,
  // tree-specific configs:
  rootVisible: true,
  lines: true,
  singleExpand: false,
  dblClickExpand: false,
  useArrows: false,
  enableDD: true,
  ddGroup: 'aignodes',
  loader: new AIG.XMLTreeLoader(),
  selModel: new RG.Main.EntityTreeSelectionModel(),
  root: new Ext.tree.TreeNode({
    text: 'Research Gateway',
    id: 'query',
    icon: '/aig/img/treenodeicons/query.gif',
    leaf: false,
    node_type: 'querynode',
    allowDrag: false
  }),
  tbar: new Ext.Toolbar({
    enableOverflow: true,
    cls: 'x-panel-header',
    items: [{
      xtype: 'tbtext', 
      text: 'Data Items',
      cls: 'x-data-items-header'
    },
    {
      xtype: 'tbspacer', 
      width: 10
    }, '-', {
      xtype: 'button',
      iconCls: 'ix-v0-16-window_add',
      text: 'Resources',
      disabled: true,
      minWidth: 50,
      handler: function() {
        AIG.entityTreePanel.openWindowForSelectedNodes()
      }    
    }, {
      xtype: 'button',
      iconCls: 'ix-v0-16-form_green',
      text: 'Properties',
      disabled: true,
      minWidth: 50,
      handler: function() {
        Ext.getCmp('properties-panel').toggleCollapse()
      }    
    }
    ]
  }),
  listeners: {
    dblclick: function(node, evt) {
      var tree= node.getOwnerTree()
      tree.openWindowForSelectedNodes()
    }
  },  
  handleSelectionChanged: function() {
    var validResourcesNodes= false
    var selectedEntityNodes = this.getSelectionModel().getSelectedNodes()
    if (selectedEntityNodes) {  
      if (Ext.isArray(selectedEntityNodes)) {
        validResourcesNodes= (selectedEntityNodes.length> 0)
      } else {
        validResourcesNodes= true
      }
    }    
    var openResourcesButton= this.getTopToolbar().find('text', 'Resources')[0]
    var openPropertiesButton= this.getTopToolbar().find('text', 'Properties')[0]
    openResourcesButton.setDisabled(!validResourcesNodes)   
    openPropertiesButton.setDisabled(!validResourcesNodes)   
    
  },
  openWindowForSelectedNodes: function (nodes) {  
    var selectedEntityNodes= null
    
    if (Ext.isObject(nodes) || Ext.isArray(nodes)) {
      if (Ext.isArray(nodes)) {
        selectedEntityNodes= nodes
      } else {
        selectedEntityNodes= [nodes]
      }
    } else {
      selectedEntityNodes = this.getSelectionModel().getSelectedNodes()
    }    
    if (!Ext.isArray(selectedEntityNodes) || selectedEntityNodes.length==0) {
      return
    }  
    
    //If the node is a single-node and is a service or result node, open a table
    if (selectedEntityNodes.length==1) {
      if (RG.Node.Utils.isNodeType(selectedEntityNodes[0], ['resultnode', 'servicenode'])) {
        RG.Load.openEntityTableFromNode(selectedEntityNodes[0])      
        return
      }      
    }
    
    var entityNodeUUID = ""
    var entityNodeTitle = ""
    Ext.each(selectedEntityNodes, function(n){
      if (n && n.attributes) {
        entityNodeUUID = entityNodeUUID + (entityNodeUUID.length > 0 ? "," : "") + n.attributes.uuid
        entityNodeTitle = entityNodeTitle + (entityNodeTitle.length > 0 ? "|" : "") + n.text
      }
    }, this)
    
    if (entityNodeUUID == null) {
      return
    }    
    
    //If any are document nodes, only open and return
    var checkforDocumentNodes= false
    for(var i=0; i< selectedEntityNodes.length; i++) {      
      if (RG.Node.Utils.openDocumentNode(selectedEntityNodes[i])) {
        checkforDocumentNodes= true
      }
    }      
    if (checkforDocumentNodes) {
      return
    }
    
    var serviceTabsPanel = Ext.getCmp("rg-main-container-panel")
    serviceTabsPanel.createEmptyServiceWindow({
      nodeKey: entityNodeUUID,
      nodeTitle: entityNodeTitle,
      iconCls: selectedEntityNodes[0].attributes.iconCls
    }, selectedEntityNodes[0])
  }, 
  openServiceForResultNode: function(node) {  
    if (!Ext.isObject(node)) {
      return
    }
    var resultNodeUUID = node.attributes.uuid    
    if (!resultNodeUUID) {
      return
    }    
    new RG.Service.Launcher({
      resultKey: resultNodeUUID,
      showResources: true
    }).launch()
    
  },
  renameNode: function(node) {
    if (!Ext.isObject(node)) {
      return
    }    
    var nodeType = node.attributes.node_type.toLowerCase()
    if (nodeType!= 'resultnode' && nodeType!= 'servicenode') {
      return
    }
    if (!Ext.isArray(node.childNodes) || node.childNodes.length==0) {
      return
    }
    Ext.Msg.prompt('Rename', 'Please enter new name:', function(btn, text){
      if (btn == 'ok'){
        node.attributes.baseParams = {
          request: "rename",
          newname: text
        }
        node.reload()            
      }
    }, this, false, this.getNodeText(node));    
  },
  /**
   * Gets the text of a node w/o the [#] or [# of #] suffix
   * @param {Object} node
   */
  getNodeText: function(node){
    var text = node.text
    var baseTitleReg1 = /(.+) \[\d+\]/;
    var baseTitleReg2 = /(.+) \[\d+ - \d+ of \d+\]/;
    if (text.search(baseTitleReg1) > -1) {
      text = RegExp.$1
    } else if (text.search(baseTitleReg2) > -1) {
      text = RegExp.$1
    }
    return text
  },
  /**
   * Creates the context menus for each node type
   */
  setupMenus: function(){
    this.menus = {
      resultnode: new Ext.menu.Menu({
        items: [new Ext.menu.Item({
          text: 'Open Resources',
          iconCls: 'ix-v0-16-window_add',
          scope: this,
          handler: function(){
            this.openWindowForSelectedNodes(this.ctxNode)
          }
        }), new Ext.menu.Item({
          text: 'Open App',
          iconCls: 'ix-v0-16-gears_run',
          mtype: 'app-menu-item',
          scope: this,
          handler: function(){
            this.openServiceForResultNode(this.ctxNode)
          }
        }),
        '-', 
        new Ext.menu.Item({
          text: 'Save List',
          icon: '/aig/img/savelist.gif',
          scope: this,
          handler: function(){
            if (this.ctxNode) {
              this.saveEntityList(this.ctxNode)
            }
          }
        }), new Ext.menu.Item({
          text: 'Save Search',
          icon: '/aig/img/launchpad/favorites.gif',
          scope: this,
          handler: function(){
            if (!this.ctxNode || !this.ctxNode.attributes || !this.ctxNode.attributes.uuid) {
              return
            }
            RG.Favorites.createFavorite({
              type: 'SERVICE',
              title: 'Save Search',
              iconCls: 'ix-v0-16-star_yellow',
              key: this.ctxNode.attributes.uuid
            })
          }
        }), '-', new Ext.menu.Item({
          text: 'Sort Ascending',
          icon: '/aig/img/menu_asc.gif',
          scope: this,
          handler: function(){
            if (this.ctxNode) {
              this.ctxNode.attributes.baseParams = {
                sort: "asc"
              }
              this.ctxNode.reload()
            }
          }
        }), new Ext.menu.Item({
          text: 'Sort Descending',
          icon: '/aig/img/menu_desc.gif',
          scope: this,
          handler: function(){
            if (this.ctxNode) {
              this.ctxNode.attributes.baseParams = {
                sort: "desc"
              }
              this.ctxNode.reload()
            }
          }
        }), new Ext.menu.Item({
          text: 'First Page',
          icon: '/aig/img/treenodes-first.gif',
          scope: this,
          handler: function(){
            if (this.ctxNode) {
              this.ctxNode.attributes.baseParams = {
                request: "first"
              }
              this.ctxNode.reload()
            }
          }
        }), new Ext.menu.Item({
          text: 'Last Page',
          icon: '/aig/img/treenodes-last.gif',
          scope: this,
          handler: function(){
            if (this.ctxNode) {
              this.ctxNode.attributes.baseParams = {
                request: "last"
              }
              this.ctxNode.reload()
            }
          }
        }), new Ext.menu.Item({
          text: 'Search',
          icon: '/aig/img/search.gif',
          scope: this,
          handler: function(){
            if (this.ctxNode) {
              // Prompt for user data and process the result using a callback:
              Ext.Msg.prompt('Node Search', 'Find:', function(btn, text){
                if (btn == 'ok') {
                  this.ctxNode.attributes.baseParams = {
                    request: "search",
                    find: text
                  }
                  this.ctxNode.reload()
                }                                
              }, this)
            }
          }
        }), new Ext.menu.Separator(), new Ext.menu.Item({
          text: 'Create Subset Result',
          icon: '/aig/img/createsubresult.gif',
          scope: this,
          handler: function(){
            if (!this.ctxNode || !this.ctxNode.attributes || !this.ctxNode.attributes.uuid) {
              return
            }
            this.createSubResult(this.ctxNode)
          }
        }), new Ext.menu.Item({
          text: 'Copy',
          icon: '/aig/img/copy.gif',
          scope: this,
          disabled: !AIG.ClipboardCtrl.hasClipboardAccess(),
          handler: function(){
            if (!this.ctxNode || !this.ctxNode.attributes || !this.ctxNode.attributes.uuid) {
              return
            }
            AIG.ClipboardCtrl.setClipboardText(this.getNodeText(this.ctxNode))
          }
        }), new Ext.menu.Item({
          text: 'Copy Members',
          icon: '/aig/img/copy.gif',
          scope: this,
          disabled: !AIG.ClipboardCtrl.hasClipboardAccess(),
          handler: function(){
            if (!this.ctxNode || !this.ctxNode.attributes || !this.ctxNode.attributes.uuid) {
              return
            }
            Ext.Ajax.request({
              url: "/aig/treenodecacheretrieval.go",
              success: function(response){
                var listMembers = selectNodeValues(response.responseXML, '//EntityListMember/@label')
                AIG.ClipboardCtrl.setClipboardText((Ext.isArray(listMembers) ? listMembers.join("\n") : listMembers))
                showInformationDialog("Results copied to clipboard.")
              },
              failure: function(response){
                showErrorDialog('Error Copying List', 'Unable to retrieve list.\n' + response.responseText)
              },
              scope: this,
              params: {
                uuid: this.ctxNode.attributes.uuid,
                op: 'aslist'
              }
            })
          }
        }), '-', 
        new Ext.menu.Item({
          text: 'Rename...',
          iconCls: 'ix-v0-16-pencil2',           
          mtype: 'rename-item',
          scope: this,
          handler: function(){
            this.renameNode(this.ctxNode)
          }
        }), new Ext.menu.Item({
          text: 'Delete',
          icon: '/aig/img/delete.gif',
          scope: this,
          handler: function(){
            if (this.ctxNode) {
              this.deleteNode(this.ctxNode)
            }
          }
        })],
        listeners: {
          beforeshow: function(){
            this.ctxNode = AIG.entityTreePanel.ctxNode
            if (!this.ctxNode || !Ext.isObject(this.ctxNode)) {
              return false
            }
            var saveSearchItem = this.findMenuItemByText("Save Search")
            var saveListItem = this.findMenuItemByText("Save List")
            var openAppItem= this.find('mtype', 'app-menu-item').pop()
            var renameNodeItem= this.find('mtype', 'rename-item').pop()
            saveSearchItem.setDisabled((this.ctxNode.attributes.service_key == null))
            saveListItem.setDisabled((this.ctxNode.childNodes.length <= 0))
            renameNodeItem.setDisabled((this.ctxNode.childNodes.length <= 0))
            
            if (this.ctxNode.attributes.service_key) {              
              if (this.ctxNode.attributes.service_icon) {
                var iconCls= RG.Icon.Utils.getSizedIconClass(this.ctxNode.attributes.service_icon, 16)
                openAppItem.setIconClass(iconCls)
              }
              if (this.ctxNode.attributes.service_name) {
                openAppItem.setText(this.ctxNode.attributes.service_name)              
              }
              openAppItem.setDisabled(false)              
            } else {
              openAppItem.setDisabled(true)
            }    

          }
        }
      }),
      servicenode: new Ext.menu.Menu({
        items: [new Ext.menu.Item({
          text: 'Open Resources',
          iconCls: 'ix-v0-16-window_add',
          scope: this,
          handler: function(){
            this.openWindowForSelectedNodes(this.ctxNode)
          }
        }), '-', new Ext.menu.Item({
          text: 'Sort Ascending',
          icon: '/aig/img/menu_asc.gif',
          scope: this,
          handler: function(){
            if (this.ctxNode) {
              this.ctxNode.attributes.baseParams = {
                sort: "asc"
              }
              this.ctxNode.reload()
            }
          }
        }), new Ext.menu.Item({
          text: 'Sort Descending',
          icon: '/aig/img/menu_desc.gif',
          scope: this,
          handler: function(){
            if (this.ctxNode) {
              this.ctxNode.attributes.baseParams = {
                sort: "desc"
              }
              this.ctxNode.reload()
            } 
          }
        }), new Ext.menu.Item({
          text: 'First Page',
          icon: '/aig/img/treenodes-first.gif',
          scope: this,
          handler: function(){
            if (this.ctxNode) {
              this.ctxNode.attributes.baseParams = {
                request: "first"
              }
              this.ctxNode.reload()
            }
          }
        }), new Ext.menu.Item({
          text: 'Last Page',
          icon: '/aig/img/treenodes-last.gif',
          scope: this,
          handler: function(){
            if (this.ctxNode) {
              this.ctxNode.attributes.baseParams = {
                request: "last"
              }
              this.ctxNode.reload()
            }
          }
        }), new Ext.menu.Item({
          text: 'Search',
          icon: '/aig/img/search.gif',
          scope: this,
          handler: function(){
            if (this.ctxNode) {
              // Prompt for user data and process the result using a callback:
              Ext.Msg.prompt('Node Search', 'Find:', function(btn, text){
                if (btn == 'ok') {
                  this.ctxNode.attributes.baseParams = {
                    request: "search",
                    find: text
                  }
                  this.ctxNode.reload()
                }
                                
              }, this)
            }
          }
        }), new Ext.menu.Separator(), new Ext.menu.Item({
          text: 'Save List',
          icon: '/aig/img/savelist.gif',
          scope: this,
          listeners: {
            beforeshow: function(){
              if (this.ctxNode.childNodes.length <= 0) {
                this.disable()
              }
            }
          },
          handler: function(){
            if (this.ctxNode) {
              this.saveEntityList(this.ctxNode)
            }
          }
        }), new Ext.menu.Separator(), new Ext.menu.Item({
          text: 'Copy',
          icon: '/aig/img/copy.gif',
          scope: this,
          disabled: !AIG.ClipboardCtrl.hasClipboardAccess(),
          handler: function(){
            if (!this.ctxNode || !this.ctxNode.attributes || !this.ctxNode.attributes.uuid) {
              return
            }
            AIG.ClipboardCtrl.setClipboardText(this.getNodeText(this.ctxNode))
          }
        }), new Ext.menu.Item({
          text: 'Copy Members',
          icon: '/aig/img/copy.gif',
          scope: this,
          disabled: !AIG.ClipboardCtrl.hasClipboardAccess(),
          handler: function(){
            if (!this.ctxNode || !this.ctxNode.attributes || !this.ctxNode.attributes.uuid) {
              return
            }
            Ext.Ajax.request({
              url: "/aig/treenodecacheretrieval.go",
              success: function(response){
                var listMembers = selectNodeValues(response.responseXML, '//EntityListMember/@label')
                AIG.ClipboardCtrl.setClipboardText((Ext.isArray(listMembers) ? listMembers.join("\n") : listMembers))
                showInformationDialog("Results copied to clipboard.")
              },
              failure: function(response){
                showErrorDialog('Error Copying List', 'Unable to retrieve list.\n' + response.responseText)
              },
              scope: this,
              params: {
                uuid: this.ctxNode.attributes.uuid,
                op: 'aslist'
              }
            })
          }
        }), '-', new Ext.menu.Item({
          text: 'Rename...',
          iconCls: 'ix-v0-16-pencil2',           
          mtype: 'rename-item',
          scope: this,
          handler: function(){
            this.renameNode(this.ctxNode)
          }
        })],
        listeners: {
          beforeshow: function(){
            this.ctxNode = AIG.entityTreePanel.ctxNode
            if (!this.ctxNode || !Ext.isObject(this.ctxNode)) {
              return false
            }
            var saveListItem = this.findMenuItemByText("Save List")
            var renameNodeItem= this.find('mtype', 'rename-item').pop()
            saveListItem.setDisabled((this.ctxNode.childNodes.length <= 0))
            renameNodeItem.setDisabled((this.ctxNode.childNodes.length <= 0))
          }
        }
      }),
      entitynode: new Ext.menu.Menu({
        items: [new Ext.menu.Item({
          text: 'Open Resources',
          iconCls: 'ix-v0-16-window_add',
          scope: this,
          handler: function(){
            this.openWindowForSelectedNodes(this.ctxNode)
          }
        }), 
        new Ext.menu.Item({
          text: 'Properties',
          iconCls: 'ix-v0-16-form_green',
          scope: this,
          handler: function(){
            this.showProperties(this.ctxNode)
          }
        }), 
        '-', new Ext.menu.Item({
          text: 'Copy',
          icon: '/aig/img/copy.gif',
          scope: this,
          disabled: !AIG.ClipboardCtrl.hasClipboardAccess(),
          handler: function(){
            if (!this.ctxNode || !this.ctxNode.attributes || !this.ctxNode.attributes.uuid) {
              return
            }
            AIG.ClipboardCtrl.setClipboardText(this.getNodeText(this.ctxNode))
          }
        })],
        listeners: {
          beforeshow: function(){
            this.ctxNode = AIG.entityTreePanel.ctxNode
            if (!this.ctxNode) {
              return false
            }
          }
        }
      })
    }
  },
  /**
   * Handles saving an entity list
   * @param {Object} node
   */
  createSubResult: function(node){
    var tree = this
    var nodeUUID = node.attributes.uuid
    if (!nodeUUID) {
      return
    }
        
    var SelectMembersWindowUi = Ext.extend(Ext.Window, {
      title: 'Create New Result From ' + tree.getNodeText(node),
      width: 400,
      height: 400,
      layout: 'border',
      modal: true,
      initComponent: function(){
        var win = this
        this.autoExpandColumn = 'description'
        this.nameForm = new Ext.form.FormPanel({
          region: 'north',
          height: 110,
          frame: true,
          items: [{
            xtype: 'textfield',
            width: 250,
            name: 'name',
            fieldLabel: 'Name',
            value: tree.getNodeText(node)
          }, {
            xtype: 'textarea',
            anchor: '95%',
            name: 'description',
            fieldLabel: 'Description',
            value: node.attributes.title
          }]
        })
        var selModel = new Ext.grid.CheckboxSelectionModel()
        this.grid = new Ext.grid.GridPanel({
          title: 'Select Members',
          region: 'center',
          autoExpandColumn: 'description',
          store: new Ext.data.Store({
            url: '/aig/treenodecacheretrieval.go?uuid=' + node.attributes.uuid,
            baseParams: {
              op: 'allchildren'
            },
            reader: new Ext.data.JsonReader({
              root: 'nodes',
              id: 'key'
            }, [{
              name: 'name'
            }, {
              name: 'description'
            }]),
            autoLoad: true
          }),
          selModel: selModel,
          columns: [selModel, {
            id: 'name',
            dataIndex: 'name',
            header: 'Name',
            sortable: true,
            width: 100
          }, {
            id: 'description',
            dataIndex: 'description',
            header: 'Description',
            sortable: true,
            width: 100
          }]
        })
        this.items = [this.nameForm, this.grid]
        this.buttons = [{
          text: 'OK',
          handler: function(){
            var selectionKeys = []
            win.grid.getSelectionModel().each(function(record){
              selectionKeys.push(record.id)
            })
            if (selectionKeys.length > 0) {
              var nameVals = win.nameForm.getForm().getValues()
              Ext.Ajax.request({
                url: "/aig/treenodeoperation.go",
                success: function(response){
                  if (AIG.showErrorMessage(response)) {
                    return
                  }
                  addTreeNodesFromQueryResult(response)
                },
                failure: function(response){
                  Ext.MessageBox.show({
                    title: 'Create New Result',
                    msg: 'Unable to create new result.',
                    buttons: Ext.MessageBox.OK,
                    icon: Ext.MessageBox.ERROR
                  })
                },
                scope: this,
                params: {
                  op: 'CREATESUBRESULT',
                  uuid1: node.attributes.uuid,
                  uuids: selectionKeys.join(','),
                  name: nameVals.name,
                  description: nameVals.description
                }
              })
            }
            win.close()
          }
        }, {
          text: 'Cancel',
          handler: function(){
            win.close()
          }
        }]
        SelectMembersWindowUi.superclass.initComponent.call(this);
      }
    });
    new SelectMembersWindowUi().show()
  },
  /**
   * Handles saving an entity list
   * @param {Object} node
   */
  saveEntityList: function(node){
    var nodeUUID = node.attributes.uuid
        
    if (!nodeUUID) {
      return
    }
    AIG.NameDescriptionDialog({
      title: 'Create New List',
      ok_text: 'Save List',
      handler: function(values){
        var name = values.name
        var description = values.description
        if (!name || name.length == 0) {
          Ext.MessageBox.show({
            title: 'Unable to Save List',
            msg: 'List name required.',
            buttons: Ext.MessageBox.OK,
            icon: Ext.MessageBox.ERROR
          })
          return
        }
        if (!description || description.length == 0) {
          description = 'List ' + name
        }
        Ext.Ajax.request({
          url: "/aig/treenodeoperation.go",
          success: function(){
            showInformationDialog('List Created')
            var launcher= new RG.Loft.AppLauncher()
            launcher.reloadDialog(launcher.dialogIDs.LISTS_TOOL)
          },
          failure: function(){
            Ext.MessageBox.show({
              title: 'Save List',
              msg: 'Unable to save list.',
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
          },
          scope: this,
          params: {
            op: 'savelist',
            uuid: nodeUUID,
            name: name,
            description: description
          }
        })
      }
    })
  },
  deleteNode: function(node){
    var treeNodeUUID = node.attributes.uuid
    var treeNodeText = node.text
    var nodeType = node.attributes.node_type
    if (!treeNodeUUID || !nodeType || nodeType.toLowerCase() != 'resultnode') {
      return
    }
    Ext.MessageBox.show({
      title: 'Delete Tree Node',
      msg: 'Do you want to delete the selected node ' + treeNodeText + '?',
      buttons: Ext.MessageBox.YESNO,
      fn: function(buttonId){
        if (buttonId != 'yes') {
          return
        }
        Ext.Ajax.request({
          url: "/aig/treenodeoperation.go",
          success: function(){
            node.remove()
            showInformationDialog("Node deleted.")
          },
          failure: function(){
            Ext.MessageBox.show({
              title: 'Delete Tree Node',
              msg: 'Unable to delete selected node.',
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
          },
          scope: this,
          params: {
            op: 'deletenode',
            uuid: treeNodeUUID
          }
        })
      },
      icon: Ext.MessageBox.QUESTION
    })
  },
  showProperties: function(node) {
    if (!Ext.isObject(node)) {
      return
    }
    node.select()
    Ext.getCmp('properties-panel').expand()    
  }
})



AIG.entityTreePanel.on('render', function(tree){
  tree.dropZone = new Ext.tree.TreeDropZone(tree, {
    ddGroup: 'aignodes',
    // While over a target node, return the default drop allowed class which
    // places a "tick" icon into the drag proxy.
    onNodeOver: function(target, dd, e, data){
      var sourceNode = data.node || data.record
      var targetNode = target.node
      return this.isValidNodeDrop(sourceNode, targetNode)
    },
    // On node drop, we can interrogate the target node and the dragged node
    // and if valid, update the list.
    onNodeDrop: function(target, dd, e, data){
      var sourceNode = data.node || data.record
      var targetNode = target.node
      if (this.isValidNodeDrop(sourceNode, targetNode) != this.dropAllowed) {
        return false
      }
            
      var sourceType = (sourceNode.data ? "LIST" : sourceNode.attributes.node_type)
      var targetType = targetNode.attributes.node_type
            
      AIG.showListOperationDialog({
        title: 'Create New Result By Combining',
        disabled: (sourceType == 'ENTITYNODE'),
        handler: function(values){
          var operation = values.op || "UNION"
          Ext.Ajax.request({
            url: "/aig/treenodeoperation.go",
            success: function(response){
              if (AIG.showErrorMessage(response)) {
                return
              }
              addTreeNodesFromQueryResult(response, {
                fn: function(node){                  
                  if (node.attributes.table_key) {
                    node.select.defer(450, node)
                    RG.Load.openEntityTableFromNode.defer(400, this, [node, true])
                  }
                },
                scope: this
              })
            },
            failure: function(response){
              Ext.MessageBox.show({
                title: 'Result Combination',
                msg: 'Unable to create new result.',
                buttons: Ext.MessageBox.OK,
                icon: Ext.MessageBox.ERROR
              })
            },
            scope: this,
            params: {
              op: operation,
              list_id: (sourceType == 'LIST' ? sourceNode.data.list_id : null),
              uuid1: (sourceType != 'LIST' ? sourceNode.attributes.uuid : null),
              uuid2: targetNode.attributes.uuid,
              name: values.name,
              description: hasLength(values.description) || 'test'
            }
          })
        },
        scope: this
      })
            
      return true
    },
    /**
     * Returns whether the drop node data is valid for the target
     * @param {Object} target
     * @param {Object} node
     */
    isValidNodeDrop: function(sourceNode, targetNode){
      if (RG.isNode(sourceNode) && RG.isNode(targetNode)) {
        if (sourceNode.isAncestor(targetNode) || targetNode.isAncestor(sourceNode)) {
          return this.dropNotAllowed
        }
      }
      var node1= sourceNode
      var node2= targetNode
      
      if (RG.isNode(node1)) {
        var type= node1.attributes.node_type
        if (!type) {
          return this.dropNotAllowed
        }
        if (type== "RESULTNODE" || type== "SERVICENODE") {
          if (!Ext.isArray(node1.childNodes) || node1.childNodes.length<=0) {
            return this.dropNotAllowed
          }
          node1= node1.childNodes[0]
        }
      }
      
      if (RG.isNode(node2)) {
        var type= node2.attributes.node_type
        if (!type) {
          return this.dropNotAllowed
        }
        if (type== "RESULTNODE" || type== "SERVICENODE") {
          if (!Ext.isArray(node2.childNodes) || node2.childNodes.length<=0) {
            return this.dropNotAllowed
          }
          node2= node2.childNodes[0]
        }
      }
      return (RG.entityMatch(node1, node2) ? this.dropAllowed : this.dropNotAllowed)
    }
  })
  tree.dropZone.addToGroup('aiglist');
})


AIG.entityTreePanel.on('contextmenu', function(node, evt){
  if (this.menus == null) {
    this.setupMenus()
  }
  this.ctxNode = node
  if (this.menus[node.attributes.node_type.toLowerCase()]) {
    this.menus[node.attributes.node_type.toLowerCase()].show(node.ui.getAnchor())
  }
})

AIG.entityTreePanel.getSelectionModel().on('selectionchange', function(selectionModel, nodes){
  if (!nodes) {
    return
  }
  nodes = (Ext.isArray(nodes) ? nodes : [nodes])
  if (nodes.length == 0) {
    return
  }
  var node = nodes[0]
  node.getOwnerTree().handleSelectionChanged()
  //If selected node is invalid, update the resources & bail
  if (!node.attributes.node_type) {
    return
  }
  var nodeType = node.attributes.node_type.toLowerCase()
  //If selected node is the query node, show the query window & bail
  if (nodeType == 'querynode') {
    return
  }
  AIG.NodeDetailsPanel.updateNodeDetails(node)  
})

AIG.entityTreePanel.on('click', function(node, evt){
  //Debug- Show TreeNodeXML
  if (evt.ctrlKey && evt.shiftKey && node.attributes.uuid) {
    var win = new Ext.Window({
      title: node.text + " (uuid=" + node.attributes.uuid + ")",
      closable: true,
      width: 500,
      height: 500,
      layout: 'fit',
      maximizable: true,
      items: [new Ext.ux.ManagedIframePanel({
        defaultSrc: '/aig/treenodecacheretrieval.go?uuid=' + node.attributes.uuid + '&nopaging=1&includeparent=1',        
        loadMask: false
      })]
    })
    win.show(this);
    return
  }
    
  //If selected node is invalid, update the resources & bail
  if (!node.attributes.node_type) {
    return
  }
  var nodeType = node.attributes.node_type.toLowerCase()
  //If selected node is the query node, show the query window & bail
  if (nodeType == 'querynode') {
    return
  }
  var sn = this.selModel.selNode ||
  {};
  //ignore currently selected node
  if (node.id == sn.id) {
    return
  }
  //If the node is a page up/down, call the refresh and bail
  switch (nodeType) {
    case 'pageupnode':
      var parentNode = node.parentNode
      var request = "previous"
      if (!parentNode.attributes.page || parentNode.attributes.page <= 0) {
        parentNode.attributes.page = 0
      }
      if (evt.hasModifier()) {
        request = 'first'
      }
      parentNode.attributes.baseParams = {
        page: parentNode.attributes.page,
        request: request
      }
      parentNode.reload()
      break
    case 'pagedownnode':
      var parentNode = node.parentNode
      var request = "next"
      if (!parentNode.attributes.page || parentNode.attributes.page <= 0) {
        parentNode.attributes.page = 0
      }
      if (evt.hasModifier()) {
        request = 'last'
      }
      parentNode.attributes.baseParams = {
        page: parentNode.attributes.page,
        request: request
      }
      parentNode.reload()
      break
    case ('resultnode'):
    case ('servicenode'):
      //RG.Load.openEntityTableFromNode(node)
      break
    case ('entitynode'):
      RG.Load.openEntityDefaultViewFromNode({
        node: node
      })
      break
  }
})

