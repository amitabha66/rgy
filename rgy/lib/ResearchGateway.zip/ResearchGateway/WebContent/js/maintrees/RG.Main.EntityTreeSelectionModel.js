/**
 * @author jemcdowe
 */
RG.Main.EntityTreeSelectionModel = Ext.extend(Ext.tree.MultiSelectionModel, {
    select: function(node, e, keepExisting){
        if (!e || !e.ctrlKey) {
            this.clearSelections()
        }
        if (this.verifySelection(node) && this.fireEvent('beforeselect', this, node) !== false) {
            return RG.Main.EntityTreeSelectionModel.superclass.select.call(this, node, e, keepExisting)
        }
    },
    verifySelection: function(node){
        if (this.isSelected(node)) {
            return false
        }
        if (!node.attributes || !node.attributes.node_type) {
            return false
        }
        var nodeType = node.attributes.node_type.toLowerCase()
        switch (nodeType) {
            case ('resultnode'):
            case ('servicenode'):
            case ('entitynode'):
                break
            default:
                return false
        }
        if (this.getSelectedNodes().length == 0) {
            return true
        }
        var prevNode = this.getSelectedNodes()[this.getSelectedNodes().length - 1]
        if (node.attributes.service_data_type_category != prevNode.attributes.service_data_type_category) {
            return false
        }
        return true
    }
})
