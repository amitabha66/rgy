/**
 * Creates the panel used to display node details
 *
 *
 * @author    J. McDowell
 * @date      23 March 2009
 * @version   $Id: NodeDetailsPanel.js,v 1.1 2011/06/17 20:41:21 cvs Exp $
 *
 */
AIG.NodeDetailsPanel = new Ext.Panel({
    id: 'node-details-panel',
    title: 'Selection Details',
    border: false,
    layout: 'border',
    items: [new AIG.EntityPropertyGrid({
        url: '/aig/entitydetailshandler.go',
        region: 'center'
    })],
    iconCls: 'details',
    iconClass: 'details',
    updateNodeDetails: function(entityNode){
        var entityText = entityNode.text
        var entityNodeID = entityNode.attributes.uuid
        if (!entityNodeID) {
            this.setTitle('Selection Details')
            AIG.NodeDetailsPanelStore.load({
                params: {
                    uuid: ''
                }
            });
            return
        }
        this.setTitle(entityText + ' Details')
        var iconCls = entityNode.attributes.image
        if (!iconCls) {
            iconCls = "details"
        }
        if (this.iconClass != iconCls) {
            this.getEl().child('.x-panel-inline-icon').replaceClass(this.iconClass, iconCls)
            this.iconClass = iconCls
        }
        AIG.NodeDetailsPanel.items.get(0).store.load({
            params: {
                uuid: entityNodeID
            }
        })
    }
})
