/**
 * @version $Id: RG.Main.js,v 1.18 2015/09/02 23:38:05 jemcdowe Exp $
 * 
 * RG.Main: Initializes the RG main window
 */

AIG.servicePropertiesPanel = {
  id :'properties-panel',
  title :'Properties',
  region :'east',
  width :400,
  minSize :175,
  // maxSize: 400,
  split :true,
  collapsible :true,
  collapsed :true,
  titleCollapse :true,
  floatable :true,
  collapsedIcon :"/aig/img/properties90.gif",
  plugins :[new Ext.rx.CollapsedPanelTitlePlugin(true)],
  
  margins :'0 0 0 1',
  layout :'accordion',
  layoutConfig :{
    animate :true
  },
  listeners: {
    render: function(p) {
      p.el= new Ext.Layer({}, p.el);
    },
    expand: function(propPanel) {
      var zIndex= -1
      var winCount= 0
      var winManager= Ext.WindowMgr;
      winManager.each(function(win) {
        zIndex= Math.max(zIndex, win.el.getZIndex())
        winCount++
      })
      //propPanel.el.setStyle('z-index', Ext.WindowMgr.zseed + (winCount*10))
      propPanel.el.setZIndex(Ext.WindowMgr.zseed + (winCount*10))
    }
  },
  items :[AIG.NodeDetailsPanel, new AIG.TabSettingsPanel()]
};

// Finally, build the main layout once all the pieces are ready. This is also a
// good
// example of putting together a full-screen BorderLayout within a Viewport.


var aigPanel = new Ext.Panel({
  id :'aig_main-panel',
  region :'center',
  layout :'border',
  loadMask :true,
  tbar: new RG.Loft.Toolbar(),
  bbar: new RG.Main.BottomToolBar(),
  // hidden: true,
  items :[{
    layout :'border',
    id :'layout-browser',
    region :'west',
    border :false,
    split :true,
    collapsible :true,
    collapseMode :'mini',
    hideCollapseTool: true,
    margins :'2 0 5 5',
    width :275,
    minSize :100,
    maxSize :500,
    items :[AIG.entityTreePanel],
    useSplitTips :true,
    listeners :{
      collapse : function(panel) {
        var minButtonEl = panel.ownerCt.getEl().child("div.x-layout-mini-west")
        if (!minButtonEl.tooltip) {
          minButtonEl.tooltip = new Ext.rx.AnchorToolTip({
            anchor :'left',
            baseCls :'x-tipyellow',
            title :'Data Items Panel Is Hidden',
            html :'To reopen the Data Items Panel,<BR>press this arrow.',
            adjustPosition : function(x, y) {
              return {
                x :x,
                y :y
              }
            }
          })
        }
        var splitEl = panel.ownerCt.layout.west.splitEl
        var xy = [splitEl.getWidth() + 15, minButtonEl.getY() + 8]
        minButtonEl.tooltip.showAt(xy)

      }
    }
  }, new RG.Main.MainContainerPanel(), AIG.servicePropertiesPanel]
});
//
// This is the main layout definition.
//
var defaultSecurityDomain = document.domain

Ext.onReady( function() {
  try {
    Ext.fly('init-loading').remove();
  } catch (e) {
  }
    
  Ext.QuickTips.init();
  document.domain = "amgen.com"
  /*
  var search = new Ext.ux.TwinCombo({
    store :new Ext.data.Store({
      url :'/aig/quicksearchservicelookup.go',
      listeners :{
        loadexception : function(store, options, error) {
          aigErrorHandler(error)
        }
      },
      reader :new Ext.data.XmlReader({
        record :'Service',
        id :'ServiceKey'
      }, ['Name', 'Organization', 'Contact', 'Description', 'QuickSearchType', 'QuickSearchParameter', 'QuickSearchParameterLabel', 'QuickSearchQuery'])
    }),
    trigger1Class :'x-quick-search-clear-trigger',
    trigger2Class :'x-quick-search-config-trigger',
    displayField :'title',
    typeAhead :false,
    emptyText :'Enter Quick Search',
    loadingText :'Searching...',
    width :300,
    minChars :3,
    maxHeight :500,
    height :10,
    handleHeight :5,
    hideTrigger :false,
    cls :'quick-search',
    tpl :new Ext.XTemplate('<tpl for=".">', '<div class="quick-search-box">', '<span class="service-name">{Name}</span><BR/>', '<span class="service-description">{Description}</span><BR/>',
      '<div class="service-parameter">[<span class="service-parameter-name">{QuickSearchParameterLabel}</span> = <span class="service-parameter-value">{QuickSearchQuery}</span>]</div>', '</div>',
      '</tpl>'),
    itemSelector :'div.quick-search-box',
    onTrigger1Click : function() {
      this.collapse();
      this.clearValue()
    },
    onTrigger2Click : function() {
      this.collapse()
      var showDefaultViewItemIndx = this.optionsMenu.items.findIndex('text', 'Load Default Views')
      this.optionsMenu.items.get(showDefaultViewItemIndx).setChecked(!this.searchOptions.disableLoadDefaultView)
      this.optionsMenu.show(this.getTrigger(1), 'bl')
    },
    searchOptions :{
      disableLoadDefaultView :false
    },
    optionsMenu :new Ext.menu.Menu({
      items :[{
        text :'Search By Structure',
        icon :'/aig/img/compound16.gif',
        handler : function() {
          SMSC.showStructureEditDialog({
            src :{
              db :'acrf',
              id :'id',
              regex :"^\\d+(\\#\\d+)?$",
              invalidText :'Enter root number or root#lot',
              label :'Root or Root#Lot'
            },
            showSearchType :true,
            showExactSearchType :false,
            handler : function(structure) {
              if (!structure) {
                return
              }
              RG.Load.loadEntityList({
                service_key :"structure_search",
                service_params :structure,
                progress_title :'Running Structure Search',
                searchOptions :this.searchOptions
              })
            },
            scope :search
          })
        },
        scope :search
      }, '-', {
        text :'Load Default Views',
        checked :true,
        listeners :{
          checkchange : function(item, checked) {
            search.searchOptions.disableLoadDefaultView = !checked
          }
        },
        scope :search
      }]
    }),
    onSelect : function(record) {
      this.collapse();
      var serviceKey = record.id
      var paramName = record.data.QuickSearchParameter
      var paramValue = record.data.QuickSearchQuery
      this.clearValue()
      var serviceParams = {}
      serviceParams[paramName] = paramValue

      if (serviceKey == 'CorporateDirectory') {
        new RG.Dialog.UserSelector({
          title :'Corporate Directory',
          query :paramValue
        }).show()
      } else {
        RG.Load.loadEntityList({
          service_key :serviceKey,
          service_params :serviceParams,
          progress_title :'Running ' + record.data.Name,
          searchOptions :this.searchOptions
        })
      }
    }
  });
    */
  new Ext.Viewport({
    id :'aig_main-viewport',
    layout :'border',
    // hidden: true,
    border :false,
    items :[aigPanel],
    listeners :{
      resize : function(vp, adjWidth, adjHeight, rawWidth, rawHeight) {
        new Ext.util.DelayedTask().delay(100, function() {
          AIG.initViewport()
          AIG.reopenLaunchPad(false)
        }, vp)        
      },
      render : function(vp, adjWidth, adjHeight, rawWidth, rawHeight) {
        new Ext.util.DelayedTask().delay(500, function() {
          if (loadLaunchPad) {
            AIG.openLaunchPad()
          }
          AIG.showSessionMessages()
          
        }, vp)        
      }
    }
  })

  new Ext.KeyMap("aig_main-panel", [{
    key :"tvhx",
    ctrl :true,
    shift :true,
    fn : function(key) {
      var serviceTabsWindowsContainerPanel = Ext.getCmp("rg-main-container-panel")
      if (serviceTabsWindowsContainerPanel) {
        if (serviceTabsWindowsContainerPanel.getWindowCount() > 0) {
          var charVal = String.fromCharCode(key).toLowerCase()
          switch (charVal) {
            case ('t') :
            case ('v') :
            case ('h') :
              serviceTabsWindowsContainerPanel.tile(charVal)
              break
            case ('x') :
              Ext.MessageBox.confirm("Confirm", "Close all windows?", function(button_id) {
                if (button_id == 'yes') {
                  serviceTabsWindowsContainerPanel = Ext.getCmp("rg-main-container-panel")
                  if (serviceTabsWindowsContainerPanel) {
                    serviceTabsWindowsContainerPanel.closeWindows()
                  }
                }
              })
              break
          }
        }
      }
    }
  }]);    

  // Use the SessionPinger to update the SMSESSION Token
  AIG.Security.SessionPinger.on("ping", function(response) {
    AIG.Security.reloadSMToken()
  })

  AIG.Security.SessionPinger.start()
  /*
   * Clear the session cache jut befoe the window closes
   */
  Ext.EventManager.on(window, 'beforeunload', function() {
    AIG.clearSessionCache()
  }, this);
    
  if (AIG.USER_SESSION_INFO && AIG.USER_SESSION_INFO.DISPLAY_NAME && RG_VERSION) {
    switch (RG_VERSION) {
      case "DEV" :
      case "TEST" :
        document.title = "Research Gateway (" + RG_VERSION.toLowerCase() + ") - " + AIG.USER_SESSION_INFO.DISPLAY_NAME
        break
      default :
        document.title = "Research Gateway - " + AIG.USER_SESSION_INFO.DISPLAY_NAME
        break
    }
  }
  //AIG.ClipboardCtrl.setClipboardAccess()
});

Ext.override(Ext.tree.TreeNodeUI, {
  setIconCls : function(iconCls) {
    if (this.iconNode) {
      var el = Ext.fly(this.iconNode);
      el.replaceClass(this.node.attributes.iconCls, iconCls);
    }
    this.node.attributes.iconCls = iconCls;
  },
  setIcon : function(icon) {
    if (this.iconNode) {
      var el = Ext.fly(this.iconNode);
      el.dom.src = icon ? icon : this.emptyIcon;
      el[icon ? 'addClass' : 'removeClass']('x-tree-node-inline-icon');
    }
    this.node.attributes.icon = icon;
  }
});

/**
 * This is called 10ms after the Viewport rendered to take care of any
 * additional processing. The scope is the viewport. config contains any objects
 * passed by the Viewport call
 * 
 * @param {Object} config
 */
AIG.initViewport = function(config) {
  }

window.onbeforeunload = function() {
  var serviceTabsContainerPanel = Ext.getCmp("rg-main-container-panel")
  if (serviceTabsContainerPanel) {
    serviceTabsContainerPanel.closeWindows()
  }
  Ext.destroy.createDelegate(Ext, [serviceTabsContainerPanel, AIG.servicePropertiesPanel, AIG.aigPanel])
}


AIG.getMainViewport= function() {
  return Ext.getCmp('aig_main-viewport')
}