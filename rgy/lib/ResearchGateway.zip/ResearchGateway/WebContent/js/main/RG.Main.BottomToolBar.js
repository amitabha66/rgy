RG.Main.BottomToolBar= Ext.extend(Ext.Toolbar, {
  constructor: function(config) {
    config = config || {}    
    config.id= 'aig_main-bottomtoolbar'
    RG.Main.BottomToolBar.superclass.constructor.call(this, config)
  },
  initComponent : function() {
    var tb= this
    
    this.items= [new Ext.Toolbar.Button({
      iconCls: 'x-rg-16-rg_home',
      tooltip: 'Launch Pad',
      handler: tb.handleToggleLaunchPad.createDelegate(tb)
    }), '-'
    ]
    
    this.on("render", function() {
      tb.getEl().on('contextmenu', tb.handleContextMenu.createDelegate(tb))      
    })
    RG.Main.BottomToolBar.superclass.initComponent.call(this)
  },
  handleContextMenu: function(evt) {
    var tb= this
    var windowOwner= Ext.getCmp("rg-main-container-panel")

    evt.preventDefault()
    evt.stopPropagation()
    var menu = new Ext.menu.Menu({
      items: [{   
        text: 'Launch Pad',
        iconCls: 'x-rg-16-rg_home',
        scope: this,
        handler: tb.handleToggleLaunchPad.createDelegate(tb)
      }, {
        text: 'Tile Windows',
        icon: '/aig/img/tile.gif',
        scope: this,
        handler: function(){
          windowOwner.tile()
        }
      }, {
        text: 'Tile Windows Horizontally',
        icon: '/aig/img/tile_horizontal.gif',
        scope: this,
        handler: function(){
          windowOwner.tile('h')
        }
      }, {
        text: 'Tile Windows Vertically',
        icon: '/aig/img/tile_vertical.gif',
        scope: this,
        handler: function(){
          windowOwner.tile('v')
        }
      }, {
        text: 'Minimize All Windows',
        icon: '/aig/img/minimize_all.gif',
        scope: this,
        handler: function(){
          windowOwner.minimizeWindows()
        }
      }, {
        text: 'Windows',
        icon: '/aig/img/window.gif',
        menu: {
          items: []
        }
      }, {
        text: 'Close All',
        icon: '/aig/img/delete.gif',
        scope: this,
        handler: function(){
          windowOwner.closeWindows()
        }
      }],
      listeners: {
        beforeshow: function(menu){
          var windowMenuItems = []
          windowOwner.serviceTabsWindows.each(function(serviceTabsWindow){
            windowMenuItems.push({
              text: serviceTabsWindow.title,
              icon: '/aig/img/window.gif',
              window: serviceTabsWindow,
              handler: function(item){
                item.window.show()
              }
            })
          }, windowOwner)
          var button = menu.items.find(function(item){
            return (item.text == 'Windows')
          })
          if (button) {
            button.menu.removeAll()
            for (var i = 0; i < windowMenuItems.length; i++) {
              button.menu.addMenuItem(windowMenuItems[i])
            }
            button.setDisabled((windowMenuItems.length == 0))
          }
        }
      }
    })
    if (windowOwner.serviceTabsWindows.getCount() == 0) {
      menu.items.last().disable()
    }
    menu.showAt(evt.getXY())    
  },
  handleToggleLaunchPad: function() {
    if (!AIG.openLaunchPad()) {
      AIG.closeLaunchPad()
    }  
  } 
})