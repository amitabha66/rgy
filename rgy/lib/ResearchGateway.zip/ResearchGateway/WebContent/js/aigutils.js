/**
 * Set of utility functions
 * 
 * 
 * @author J. McDowell
 * @date 23 March 2009
 * @version $Id: aigutils.js,v 1.12 2013/05/20 15:52:57 jemcdowe Exp $
 * 
 */
function dropMatch(dropCategory, listCategory) {
  if (dropCategory == null || listCategory == null) {
    return false
  }
  dropCategory = dropCategory.toUpperCase().replace(/\s/g, '_');
  listCategory = listCategory.toUpperCase().replace(/\s/g, '_');
  if (dropCategory == listCategory) {
    return true
  }
  switch (listCategory) {
    case 'COMPOUNDS' :
      return (dropCategory == 'AMGEN_ROOT_ID')
    case 'PROJECTS' :
      return (dropCategory == 'PROJECT')
    case 'ASSAYS' :
      return (dropCategory == 'ASSAY_IDENTIFIER')
    case 'GENES' :
      return (dropCategory == 'ENTREZGENE_IDENTIFIER')

    case 'AMGEN_ROOT_ID' :
      return (dropCategory == 'COMPOUNDS')
    case 'PROJECT' :
      return (dropCategory == 'PROJECTS')
    case 'ASSAY_IDENTIFIER' :
      return (dropCategory == 'ASSAYS')
    case 'ENTREZGENE_IDENTIFIER' :
      return (dropCategory == 'GENES')
    case 'ASSAY_TYPES' :
    case 'PLATES' :
    case 'EXPERIMENTS' :
    case 'PEOPLE' :
    case 'NOTEBOOKS' :
    default :
      return false
  }
}

/**
 * Returns the initial portion of a tree node text, removing the index. e.g. <name> returns <name> <name> [x] returns <name> <name> [x - y of z] returns <name>
 * 
 * @param {Object} nodeText
 */
function getNodeBaseText(nodeText) {
  var baseTitleReg1 = /(.+) \[\d+\]/;
  var baseTitleReg2 = /(.+) \[\d+ - \d+ of \d+\]/;
  if (nodeText.search(baseTitleReg1) > -1) {
    return RegExp.$1
  } else if (nodeText.search(baseTitleReg2) > -1) {
    return RegExp.$1
  }
  return nodeText
}

/**
 * Find or creates a hidden iframe used to make a download call
 * 
 * @param {Object} src the src url of the download
 */
function callDocumentDownViaIFrame(config) {
  AIG.downloadFile(config)
}

AIG.downloadFile = function(config) {
  
  // create hidden target iframe
  var id = Ext.id();
  var frame = document.createElement('iframe');
  frame.id = id;
  frame.name = id;
  frame.className = 'x-hidden';
  frame.src = Ext.SSL_SECURE_URL;
  document.body.appendChild(frame);
  
  if (Ext.isIE) {
    document.frames[id].name = id;
  }
  
  var hiddenFields = []
  var form = Ext.DomHelper.append(document.body, {
    tag :'form',
    method :'post',
    action :config.src,
    "accept-charset" :"UTF-8",
    target :id
  });
  var formNode = document.body.appendChild(form);
  if (Ext.type(config.params) == 'object') {
    for ( var k in config.params) {
      if (config.params.hasOwnProperty(k)) {
        var hd = document.createElement('input');
        hd.type = 'hidden';
        hd.name = k;
        hd.value = config.params[k];
        form.appendChild(hd);
        hiddenFields.push(hd);
      }
    }
  }
  var callback = function(e) {
    var rstatus = Ext.isIE ? this.readyState : e.type;
    
    switch (rstatus) {
      case 'interactive' : // IE
      case 'loading' : // IE has several readystate transitions, ignore these
        if (config.callback && typeof (config.callback) === "function") {
          Ext.callback(config.callback, config.scope, [rstatus]);
        }
        
        break;
      
      case 'complete' : // IE readyState == done
      case 'load' : // Gecko, Opera, others == done
        var fnCleanup = function() {
          this.src = "javascript:false"; // cleanup
          Ext.fly(this).remove(); // kill frame
          Ext.fly(form).remove(); // kill form
        };
        if (config.callback && typeof (config.callback) === "function") {
          Ext.callback(config.callback, config.scope, [rstatus]);
        }
        
        if (config.complete && typeof (config.complete) === "function") {
          Ext.callback(config.complete, config.scope, [this]);
        }
        // 'this' refers to the frame object, ie. the dom object not the Ext element
        //fnCleanup.defer(30000, this);
        break;
      
      default :
        break;
    }
  };
  frame[Ext.isIE ? 'onreadystatechange' : 'onload'] = callback.createDelegate(frame);
  form.submit();
};

/**
 * Returns the general node category- Compound, Gene, Project, Assay, Person, Unknown
 * 
 * @param {Object} node
 */
function getNodeCategory(node) {
  if (!node || !node.attributes || !node.attributes.node_type) {
    return "UNKNOWN"
  }
  var nodeCategory = "unknown"
  switch (node.attributes.node_type) {
    case "ENTITYNODE" :
    case "RESULTNODE" :
      nodeCategory = node.attributes.service_data_type_category || "unknown"
      break
    case "SERVICENODE" :
      if (node.childNodes && node.childNodes.length > 0) {
        return getNodeCategory(node.childNodes[0])
      }
      break
  }
  switch (nodeCategory.toUpperCase()) {
    case 'PROJECT' :
      return "PROJECT"
    case 'AMGEN ROOT ID' :
    case 'AMGEN_ROOT_ID' :
      return "COMPOUND"
    case 'ASSAY IDENTIFIER' :
    case 'ASSAY_IDENTIFIER' :
      return "ASSAY"
    default :
      return "UNKNOWN"
  }
}


/**
 * Copies a value from a grid to the clipboard
 * 
 * @param {Object} grid
 * @param {Object} rowIndex
 * @param {Object} columnIndex
 */
AIG.copyCell = function(grid, rowIndex, columnIndex) {
  var store = grid.getStore()
  var cm = grid.getColumnModel()
  var record = store.getAt(rowIndex); // Get the Record
  var dataIndex = cm.getDataIndex(columnIndex); // Get field name
  var data = record.get(dataIndex);
  
  if (typeof data == "string") {
    top.AIG.ClipboardCtrl.setClipboardText(Ext.util.Format.stripTags(data))
  } else if (data.image) {
    showErrorDialog("Copy Failed", 'Sorry, RG can only copy text')
  } else if (Ext.type(data.values) == 'array') {
    if (data.values.length == 0) {
      top.AIG.ClipboardCtrl.setClipboardText("")
    } else if (data.values.length == 1) {
      top.AIG.ClipboardCtrl.setClipboardText(data.values[0])
    } else {
      var arrayValues = []
      for ( var i = 0; i < data.values.length; i++) {
        arrayValues.push(data.values[i] || "")
      }
      top.AIG.ClipboardCtrl.setClipboardText(arrayValues.join("\r\n"))
    }
  }
}

AIG.registerTip = function(component, title, tip) {
  Ext.QuickTips.register({
    target :component.getEl(),
    title :'Test',
    text :tip
  })
}

AIG.selectUser = function(config) {
  new RG.Dialog.UserSelector(config).show()
}
