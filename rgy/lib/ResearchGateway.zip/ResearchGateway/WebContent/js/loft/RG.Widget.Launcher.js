
/**
 * Creates an AppsPad 
 */
RG.Widget.Launcher = Ext.extend(Ext.util.Observable, {
  constructor: function (config) {
	Ext.apply(this, config, {
	  dialogScale: 0.85
	})
	Ext.applyIf(this, config)

	Ext.applyIf(this, {
	  size: AIG.getMainViewport().getSize()
	})

	this.addEvents(
		"beforelaunch",
		"launch"
		)

	RG.Widget.Launcher.superclass.constructor.call(this, config)
  },
  launch: function () {
	if (this.serviceRecord && this.serviceRecord.data.IsWidget && this.serviceRecord.get('WidgetURL')) {
	  this.loadWidget()
	}
  },
  loadWidget: function (serviceRecord) {
	serviceRecord = serviceRecord || this.serviceRecord
	if (!RG.isRecordType(serviceRecord, 'ServiceRecord') || !serviceRecord.data.IsWidget || !this.serviceRecord.get('WidgetURL')) {
	  return
	}
	var widgetURL = serviceRecord.get('WidgetURL')
	var widgetProperties = serviceRecord.get('WidgetProperties')
	if (Ext.isString(widgetURL)) {
	  if (widgetURL.match(/@blank$/i) || widgetProperties.indexOf('LAUNCH_IN_BLANK_WINDOW') > -1) {
		this.openBlankWindowWidget(serviceRecord)
	  } else if (widgetURL.match(/@dialog(\(([0-9]+),\s*([0-9]+)\)){0,1}$/i)) {
		this.openDialogWindowWidget(serviceRecord, true)
	  } else if (widgetProperties.indexOf('LAUNCH_IN_DIALOG_WINDOW') > -1) {
		this.openDialogWindowWidget(serviceRecord)
	  } else {
		this.openManagedWindowWidget(serviceRecord)
	  }
	}
  },
  openBlankWindowWidget: function (serviceRecord) {
	window.open(serviceRecord.get('WidgetURL').replace(/@blank$/i, ''), "_blank")
  },
  openManagedWindowWidget: function (serviceRecord) {
	AIG.closeLaunchPad()
	var serviceTabsPanel = Ext.getCmp("rg-main-container-panel")
	serviceTabsPanel.createWidgetView(serviceRecord)
  },
  openDialogWindowWidget: function (serviceRecord, hasWinSize) {
	var width = undefined
	var height = undefined
	if (hasWinSize === true) {
	  width = (RegExp.$2 && !isNaN(RegExp.$2) ? new Number(RegExp.$2).valueOf() : undefined)
	  height = (RegExp.$3 && !isNaN(RegExp.$3) ? new Number(RegExp.$3).valueOf() : undefined)
	}
	new RG.Main.WidgetDialog({
	  serviceRecord: serviceRecord,
	  width: width,
	  height: height
	}).show()
  }
});
