
/**
 * Creates an AppsPad 
 */
RG.Loft.AppLauncher = Ext.extend(Ext.util.Observable, {
  constructor: function(config) {
    if (Ext.isObject(config) && Ext.isObject(config.data)) {
      config = {
        appRecord: config
      }
    }

    this.dialogScale = 0.9

    Ext.applyIf(this, config)
    Ext.applyIf(this, {
      size: AIG.getMainViewport().getSize()
    })
    this.addEvents(
            "beforelaunch",
            "beforeservicelaunch",
            "launch"
            )

    this.launchHandlers = {
      FAVORITES_TOOL: this.launchFavoritesToolHandler.createDelegate(this),
      PREFERENCES_TOOL: this.launchPreferencesToolHandler.createDelegate(this),
      TABLE_IMPORT_TOOL: this.launchTableImportToolHandler.createDelegate(this),
      DOCUMENTS_TOOL: this.launchDocumentsToolHandler.createDelegate(this),
      EXPLORE_TOOL: this.launchExploreToolHandler.createDelegate(this),
      VQT_TOOL: this.launchVQTToolHandler.createDelegate(this),
      LISTS_TOOL: this.launchListToolHandler.createDelegate(this),
      PROJECT_VIEW_TOOL: this.launchProjectViewToolHandler.createDelegate(this),
      STRUCTURE_SEARCH_TOOL: this.launchStructureSearchToolHandler.createDelegate(this),
      FAVORITE: this.launchFavoriteHandler.createDelegate(this),
      SERVICE: this.launchServiceHandler.createDelegate(this)
    }


    this.dialogIDs = {
      FAVORITES_TOOL: 'aig_favorites-dialog',
      PREFERENCES_TOOL: 'aig_preferences-dialog',
      TABLE_IMPORT_TOOL: 'aig_table-import-dialog',
      DOCUMENTS_TOOL: 'aig_documents-dialog',
      EXPLORE_TOOL: 'aig_explore-dialog',
      VQT_TOOL: 'aig_vqt-dialog',
      LISTS_TOOL: 'aig_lists-dialog',
      STRUCTURE_SEARCH_TOOL: 'aig_sss-dialog',
      PROJECT_VIEW_TOOL: 'aig_pv_tool-dialog'
    }
    RG.Loft.AppLauncher.superclass.constructor.call(this, config)
  },
  launch: function() {
    if (!this.appRecord && !this.favRecord) {
      return
    }
    if (this.fireEvent('beforelaunch', this, (this.appRecord || this.favRecord)) !== false) {
      var launchResp = this.launchHandler()
      this.fireEvent('launch', this, (this.appRecord || this.favRecord), launchResp)
    }
  },
  reloadDialog: function(dialogID) {
    var dialog = Ext.getCmp(dialogID)
    if (!dialog || !Ext.isFunction(dialog.reload)) {
      return
    }
    dialog.reload.call(dialog)
  },
  launchHandler: function() {
    var xLaunchHandler = null
    if (this.favRecord) {
      xLaunchHandler = this.launchHandlers['FAVORITE']
    } else {
      xLaunchHandler = this.launchHandlers[this.appRecord.data.type.toUpperCase()]
    }
    if (Ext.isFunction(xLaunchHandler)) {
      xLaunchHandler.call(this)
      return true
    } else {
      return false
    }
  },
  launchStructureSearchToolHandler: function() {

    //coreServiceKeyValue

    Ext.Ajax.request({
      url: "/aig/store.go?request=SERVICES",
      params: {
        queryType: 'SERVICE',
        responseFormat: 'JSON',
        coreServiceKeyValue: 'QUICK_SEARCH_SSS'
      },
      success: function(response, request) {
        var json = Ext.decode(response.responseText)
        if (Ext.isObject(json) && Ext.isArray(json.services) && json.services.length > 0) {
          var serviceRecord = new RG.Record.ServiceRecord(json.services[0])
          serviceRecord.getServiceXML(function(sdXML) {
            var initialMol = selectSingleNodeValue(sdXML, "//CoreServiceParameterSet/Parameter[Name='mol']/Value")
            SMSC.showStructureEditDialog({
              src: {
                db: 'acrf',
                id: 'id',
                regex: "^\\d+(\\#\\d+)?$",
                invalidText: 'Enter root number or root#lot',
                label: 'Root or Root#Lot'
              },
              title: 'Structure Search',
              showSearchType: true,
              showExactSearchType: false,
              mol: initialMol,
              handler: function(structure) {
                if (!structure) {
                  return
                }

                RG.Load.loadEntityList({
                  service_key: "structure_search",
                  service_params: structure,
                  progress_title: 'Running Structure Search',
                  searchOptions: this.searchOptions
                })
              },
              scope: this
            })
          }, this, {
            coreServiceKeyValue: 'QUICK_SEARCH_SSS'
          })
        }
      },
      failure: function(result, request) {
      },
      scope: this
    })
  },
  launchFavoritesToolHandler: function() {
    var favWindow = Ext.getCmp(this.dialogIDs['FAVORITES_TOOL'])
    if (!favWindow) {
      favWindow = new RG.Favorites.FavoritesWindow({
        height: this.dialogScale * this.size.height,
        width: this.dialogScale * this.size.width,
        center: true,
        iconCls: 'ix-v0-16-star_yellow',
        listeners: {
          itemsdeleted: function() {
            var launchPad = Ext.getCmp('aig_launchpad')
            if (launchPad & launchPad.isVisible()) {
              launchPad.refresh()
            }
          },
          itemrenamed: function() {
            var launchPad = Ext.getCmp('aig_launchpad')
            if (launchPad && launchPad.isVisible()) {
              launchPad.refresh()
            }
          }
        }
      })
    }
    favWindow.show()
  },
  launchPreferencesToolHandler: function() {
    var prefWindow = Ext.getCmp(this.dialogIDs['PREFERENCES_TOOL'])
    if (!prefWindow) {
      prefWindow = new AIG.UserPreferencesUi({
        selectedGroup: 'Launch Pad',
        center: true
      })
    }
    prefWindow.show()
  },
  launchTableImportToolHandler: function() {
    var tableImportWindow = Ext.getCmp(this.dialogIDs['TABLE_IMPORT_TOOL'])
    if (!tableImportWindow) {
      tableImportWindow = new RG.Dialog.ImportDataDialog({
        modal: true,
        center: true
      })
    }
    tableImportWindow.show()
  },
  launchDocumentsToolHandler: function() {
    var docsWindow = Ext.getCmp(this.dialogIDs['DOCUMENTS_TOOL'])
    if (!docsWindow) {
      docsWindow = new RG.Dialog.AnimatedWindow({
        height: this.dialogScale * this.size.height,
        width: this.dialogScale * this.size.width,
        center: true,
        layout: 'border',
        shadow: false,
        border: false,
        draggable: true,
        resizable: true,
        closable: true,
        constrain: true,
        maximizable: true,
        closeAction: 'close',
        title: 'My Documents',
        iconCls: 'ix-v0-16-folder_document',
        items: [new RG.docrepo.DocumentRepositoryUI({
            region: 'center'
          })]
      })
    }
    docsWindow.show()
  },
  launchExploreToolHandler: function() {
    var launcher = this
    new RG.Service.Launcher({
      size: this.size,
      dialogScale: this.dialogScale,
      showResources: true,
      listeners: {
        beforelaunch: function(serviceRecord, values) {
          AIG.closeLaunchPad()
          return launcher.fireEvent('beforeservicelaunch', this, serviceRecord, values)
        }
      }
    }).launch()
    //Ext.getCmp("rg-main-container-panel").activateQueryWindowTab("Explore");
  },
  launchVQTToolHandler: function() {
    //Ext.getCmp("rg-main-container-panel").activateQueryWindowTab("Visual Query Tool");
    var vqtWindow = Ext.getCmp(this.dialogIDs['VQT_TOOL'])
    if (!vqtWindow) {
      vqtWindow = new RG.Dialog.AnimatedWindow({
        id: this.dialogIDs['VQT_TOOL'],
        iconCls: 'ix-v0-16-pie-chart_view',
        title: "Visual Query Tool",
        layout: 'fit',
        buttonAlign: 'center',
        resizable: true,
        constrain: true,
        renderToMain: true,
        maximizable: true,
        shadow: true,
        closeAction: 'close',
        parentContainerInitFraction: 1,
        initComponent: function() {
          this.items = new RG.Main.ResourceIFramePanel({
            id: 'vqt_query_panel',
            closable: false,
            iconCls: 'vqt-tab',
            defaultSrc: VQT[AIG_VERSION]
          })
          RG.Dialog.AnimatedWindow.prototype.initComponent.call(this);
        }
      })
    }
    vqtWindow.show()
    AIG.closeLaunchPad()
    return vqtWindow
  },
  launchListToolHandler: function() {
    var listsWindow = Ext.getCmp(this.dialogIDs['LISTS_TOOL'])
    if (!listsWindow) {
      listsWindow = new RG.Dialog.AnimatedWindow({
        id: this.dialogIDs['LISTS_TOOL'],
        iconCls: 'ix-v0-16-notebook',
        title: "My Lists",
        layout: 'fit',
        buttonAlign: 'center',
        resizable: false,
        constrain: true,
        maximizable: true,
        renderToMain: true,
        parentContainerInitFraction: 1,
        shadow: true,
        closeAction: 'close',
        items: new RG.Lists.ListsPanel2(),
        reload: function() {
          this.get(0).getStore().reload()
        }
      })
    }
    listsWindow.show()
    AIG.closeLaunchPad()
    return listsWindow
  },
  launchProjectViewToolHandler: function() {
    var viewLoaderWindow = Ext.getCmp(this.dialogIDs['PROJECT_VIEW_TOOL'])
    if (!viewLoaderWindow) {
      viewLoaderWindow = new RG.Dialog.AnimatedWindow({
        id: this.dialogIDs['PROJECT_VIEW_TOOL'],
        iconCls: 'ix-v0-16-pie-chart_view',
        width: 620,
        height: 500,
        title: "View Loader",
        layout: 'fit',
        buttonAlign: 'center',
        resizable: false,
        constrain: true,
        shadow: true,
        closeAction: 'close',
        initComponent: function() {
          this.items = createViewSelectionPanel(this)
          RG.Dialog.AnimatedWindow.prototype.initComponent.call(this);
        }
      })
    }
    if (viewLoaderWindow.isVisible()) {
      viewLoaderWindow.close()
      this.launchProjectViewToolHandler()
    } else {
      viewLoaderWindow.show()
    }
  },
  launchFavoriteHandler: function() {
    var launcher = this
    var favRecord = this.favRecord
    if (!favRecord) {
      favRecord = new AIG.Favorites.FolderItemsRecord(this.appRecord.data.sourceRecord)
    }
    if (!favRecord) {
      return
    }

    AIG.closeLaunchPad()
    AIG.closeFavoritesWindow()

    if (favRecord.data.subtype.toUpperCase() == 'SERVICE') {
      Ext.Ajax.request({
        url: "/aig/store.go?request=SERVICES&queryType=SERVICE&responseFormat=JSON&folderItemID=" + favRecord.data.id,
        success: function(response, request) {
          var json = Ext.decode(response.responseText)
          if (Ext.isObject(json) && Ext.isArray(json.services) && json.services.length > 0) {
            var serviceRecord = new RG.Record.ServiceRecord(json.services[0])
            new RG.Service.Launcher({
              size: launcher.size,
              appLauncher: launcher,
              serviceRecord: serviceRecord,
              dialogScale: launcher.dialogScale,
              //showResources: launcher.showResources,
              showResources: true,
              listeners: {
                beforelaunch: function(serviceRecord, values) {
                  AIG.closeLaunchPad()
                  return launcher.fireEvent('beforeservicelaunch', this, serviceRecord, values)
                }
              }
            }).launch()
          }
        },
        failure: function(result, request) {
        },
        scope: this
      })
      return
    }
    var transactionID = null
    var progressBox = Ext.Msg.show({
      title: 'Status',
      msg: 'Loading ' + favRecord.data.name + '...',
      buttons: Ext.Msg.CANCEL,
      closable: false,
      wait: true,
      modal: true,
      minWidth: 250,
      fn: function(buttonID, text) {
        if (transactionID && Ext.Ajax.isLoading(transactionID)) {
          progressBox.updateProgress(0, ' ', '')
          Ext.Ajax.abort(transactionID)
        }
      }
    })
    var openAfterLoadcb = null

    switch (favRecord.data.subtype.toUpperCase()) {
      case 'RSS':
        break
      case 'ENTITYTABLE':
        openAfterLoadcb = {
          fn: function(node) {
            node.select.defer(450, node)
            RG.Load.openEntityTableFromNode.defer(400, this, [node, true])
          },
          scope: this
        }
        break
      case 'LIST':
        break
      case 'SERVICE':
        openAfterLoadcb = {
          fn: function(node) {
            node.select.defer(450, node)
            RG.Load.openEntityDefaultViewFromNode.defer(400, this, [{
                node: node
              }])
          },
          scope: this
        }
        break
      case 'PROJECTVIEW':
        openAfterLoadcb = {
          fn: function(node) {
            RG.Load.openEntityDefaultViewFromNode.defer(400, this, [{
                node: node.firstChild,
                tabTitle: 'Project View'
              }])
          },
          scope: this
        }
        break
    }

    transactionID = Ext.Ajax.request({
      url: '/aig/executequeryservice.go',
      success: function(response, options) {
        progressBox.updateProgress(0, " ", "")
        progressBox.hide()
        addTreeNodesFromQueryResult(response, openAfterLoadcb)
      },
      failure: function(response) {
        progressBox.updateProgress(0, " ", "")
        progressBox.hide()
        showErrorDialog("Problem Loading Favorite", response.statusText)
      },
      scope: this,
      params: {
        favorite_folderitem_id: favRecord.data.id
      }
    })
  },
  launchFavoriteByIDHandler: function(favoriteID) {
    var launcher = this
    AIG.closeLaunchPad()
    AIG.closeFavoritesWindow()

    RG.Dialog.showProgressDialog('Loading Favorite, please wait...', 'Loading...')

    Ext.Ajax.request({
      url: "/aig/store.go?request=FAVORITES&favoriteID=" + favoriteID,
      success: function(response, request) {
        Ext.Msg.hide()
        if (!showResponseError(response, 'Unable to load favorite')) {
          var json = Ext.decode(response.responseText)
          if (Ext.isObject(json) && Ext.isArray(json.folderItems) && json.folderItems.length > 0) {
            var folderItem = new AIG.Favorites.FolderItemsRecord(json.folderItems[0])
            launcher.favRecord = folderItem
            launcher.launchFavoriteHandler()
          }
        }
      },
      failure: function(response, request) {
        Ext.Msg.hide()
        showResponseError(response, 'Unable to load favorite')
      },
      scope: this
    })
  },
  launchServiceHandler: function() {
    var launcher = this    
    this.appRecord.getServiceRecord(function(serviceRecord) {
      if (!serviceRecord) {
        showErrorDialog('Unable to Load App', this.appRecord.get('name') + ' is offline')
        return
      }
      new RG.Service.Launcher({
        size: this.size,
        serviceRecord: serviceRecord,
        showResources: launcher.showResources,
        dialogScale: this.dialogScale,
        listeners: {
          beforelaunch: function(serviceRecord, values) {
            AIG.closeLaunchPad()
            return launcher.fireEvent('beforeservicelaunch', this, serviceRecord, values)
          }
        }
      }).launch()
    }, this)

  }
});


