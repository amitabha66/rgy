
RG.Loft.StoreMenu = Ext.extend(Ext.menu.Menu, {  
  loadingText: Ext.LoadMask.prototype.msg || 'Loading...',
  loaded: false,
  initComponent: function() {
    Ext.applyIf(this, {
      buttonDefaults: {
        xtype: 'button',
        scale: 'large',
        width: '100%',
        iconAlign: 'top',
        removeMode: 'container'        
      },
      emptyText: 'No items to display'
    })
    this.plain= true
    this.autoWidth= true
    this.on('show', this.onMenuLoad, this);
    this.store.on('beforeload', this.onBeforeLoad, this);
    this.store.on('load', this.onLoad, this);
    this.on('hide', function() {
      if (this.alwaysReload=== true) {
        this.removeAll();
        this.loaded= false
      }
    }, this);
    this.store.menu= this
    RG.Loft.StoreMenu.superclass.initComponent.call(this);
  },
    
  onMenuLoad: function(){
    if (!this.loaded) {
      this.store.load();
    }
  },
  menuLoaded: function(){
  },
  updateMenuItems: function(loadedState, records){        
    this.removeAll();
    if (this.el) {      
      this.el.sync();      
      if (loadedState) {
        if (records.length> 0) {
          var buttonGroup= {
            xtype: 'buttongroup',
            title: this.title,
            width: 60,
            columns: 1,
            defaults: this.buttonDefaults,
            removeMode: 'container',
            items: []                    
          }
          for (var i = 0, len = records.length; i < len; i++) {
            if (Ext.isObject(records[i].button)) {
              buttonGroup.items.push(records[i].button)
            }
          }
          this.add(buttonGroup)
        }   
        if (this.items.getCount()== 0) {
          this.add(new Ext.menu.TextItem({
            html: '<span>' + this.emptyText + '</span>'
          }))
        }       
      } else {
        this.add(new Ext.menu.TextItem({
          removeMode: 'container',
          html: '<span class="loading-indicator">' + this.loadingText + '</span>'
        }));
      }
      this.loaded = loadedState;
    }
  },
  onRemove: function(c) {
  //Ext.log('removed: '+ Ext.fly(c))
  },
    
  onBeforeLoad: function(store){
    this.store.baseParams = this.baseParams;
    this.updateMenuItems(false);
  },
  onLoad: function(store){
    var records= store.getRange()
    this.processRecords(store, records)
    this.updateMenuItems(true, records)
    this.menuLoaded()
  },
  processRecords: function(store, records){
  },
  getMenuItemByTitle: function(text){
    return this.items.find(function(item){
      return (item.text == text)
    })
  }    
});
