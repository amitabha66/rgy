
RG.Loft.Toolbar = Ext.extend(Ext.Toolbar, {
  constructor: function(config) {
    config = config || {}    
    config.id= 'aig_main-toptoolbar'   
    config.MAX_ITEMS= 5
    RG.Loft.Toolbar.superclass.constructor.call(this, config)
  },
  initComponent : function() {
    var tb= this  
    this.cls= "rg-apps-tb"
    tb.height= 55
    tb.loftStartPos= 3

    this.plugins= [
    new RG.Loft.ToolbarDroppable(),
    new RG.Loft.ToolbarDraggable()
    ]    
    this.store= new Ext.data.Store({
      autoLoad :false,
      url: '/aig/store.go?request=rgapps',
      baseParams: {
        loftrx: 'QUICKAPPS',
        responseFormat: 'JSON'
      },
      sortInfo: {
        field: 'quickAppOrder',
        direction: 'ASC'
      },
      reader :new Ext.data.JsonReader({
        root :"apps",
        idProperty :'id'
      }, RG.Record.AppRecord)
    })
    //this.store.on("datachanged", this.updateLoftItems, this);
    this.store.on("add", function() {    
      this.saveLoftItems(function() {
        this.updateLoftItems()        
      }, this)
    }, this);
    
    this.store.on("remove", function() {    
      this.saveLoftItems(function() {
        this.updateLoftItems()        
      }, this)
    }, this);            
    
    this.items= [{
      xtype: 'button',
      icon: '/aig/img/rg_home.png',
      scale: 'large',
      iconAlign: 'top',
      text: 'Launch Pad',
      ctCls: 'rg-apps-tb-button-over',
      cls: 'rg-apps-tb-button',
      minWidth: 50,
      handler: tb.handleOpenLaunchpad.createDelegate(tb, [false])
    },{
      xtype: 'button',
      iconCls: 'ix-v0-32-window_sidebar',
      scale: 'large',
      iconAlign: 'top',
      text: 'Workspace',
      ctCls: 'rg-apps-tb-button-over',
      cls: 'rg-apps-tb-button',
      minWidth: 50,
      handler: tb.handleCloseLaunchpad.createDelegate(tb)
    }]
  
    this.items.push(new RG.Loft.ToolbarSeparator())
    
    if (AIG.USER_SESSION_INFO.SHOW_CACHEREFRESH) { // && false) {
      this.items.push({
        xtype: 'button',
        icon: 'http://rg-resources/ix/png/plain/32/data_refresh.png',
        scale: 'large',
        iconAlign: 'top',
        text: 'Cache',
        ctCls: 'rg-apps-tb-button-over',
        cls: 'rg-apps-tb-button',
        minWidth: 50,
        handler: function() {
		  new RG.Dialog.CacheManager().show()
		} 
      })
      this.items.push(new RG.Loft.ToolbarSeparator())
      tb.loftStartPos+= 2
    }

    //A test button for the toolbar!!- 
    // Normall shoudl be commented out
    
    //  this.items.push({
    //    xtype: 'button',
    //    icon: 'http://ussf-papp-dweb1.amgen.com/rg/ix/png/plain/32/bug_green.png',
    //    scale: 'large',
    //    iconAlign: 'top',
    //    text: 'Test Button',
    //    ctCls: 'rg-apps-tb-button-over',
    //    cls: 'rg-apps-tb-button',
    //    minWidth: 50,
    //    handler: AIG.performTest.createDelegate(tb) 
    //  })
    //  this.items.push(new RG.Loft.ToolbarSeparator())
    //  tb.loftStartPos+= 2
    


    this.items.push({
      xtype: 'tbfill'
    })
        
    this.items.push(new RG.Loft.ToolbarSeparator())

    this.items.push({
      xtype: 'button', 
      icon: 'http://rg-resources/ix/png/plain/32/view.png',
      iconAlign: 'top',
      text: 'Quick Search',
      scale: 'large',
      ctCls: 'rg-apps-tb-button-over',
      cls: 'rg-apps-tb-button',
      minWidth: 50,
      tb: tb,
      menu: new RG.Loft.QuickSearchMenu({
        })    
    })

    this.items.push({
      icon: 'http://rg-resources/ix/png/plain/32/clock.png',
      iconAlign: 'top',
      text: 'Recent',
      scale: 'large',
      ctCls: 'rg-apps-tb-button-over',
      cls: 'rg-apps-tb-button',
      minWidth: 50,
      tb: tb,
      menu: new RG.Loft.StoreMenu({
        title :'Recent Searches',
        alwaysReload: true,
        store :new Ext.data.Store({
          // load using HTTP
          url :'/aig/store.go?request=SERVICES&queryType=RECENT&responseFormat=XML', 
          sortInfo: {
            field: 'LastUsed',
            direction: 'DESC'
          },
          listeners :{
            loadexception : function(store, options, error) {
              aigErrorHandler(error)
            }
          },
          // the return will be XML, so lets set up a reader
          reader :new Ext.data.XmlReader({
            // records will have an "Service" tag
            record :'Service',
            id :'ServiceKey'
          }, RG.Record.ServiceRecord)
        }),
        processRecords : function(store, records) {
          if (Ext.isArray(records) && records.length> 0) {          
            for ( var i = 0; i < records.length; i++) {
              var style = {
                "font-weight" :(records[i].data.Default ? 'bold' : 'normal')
              }
              var iconCls= RG.Icon.Utils.getSizedIconClass(records[i].data.IconCls, 32, "ix-v0-32-gears_run")
               
              records[i].button = {
                text : Ext.util.Format.htmlEncode(records[i].data.Name),
                iconCls :iconCls,
                style :style,
                record :records[i],
                handler : function(item) {
                  var button= this.findParentByType('button')
                  button.menu.hide()
                  if (item.record) {
                    button.tb.handleLaunchService(item.record)
                  }
                }
              }
            }
          }
        },
        menuLoaded : function() {
          RG.Loft.StoreMenu.prototype.menuLoaded.call(this)
        }
      })      
    })
    this.items.push({
      xtype: 'button', 
      text: '<B>R</B>esearch <B>G</B>ateway',
      scale: 'large',
      cls: 'rg-apps-tb-logo',
      ctCls: 'rg-apps-tb-logo rg-apps-tb-btn',
      overCls: 'rg-apps-tb-logo-over',      
      tooltip: RG_LOGOTEXT,
      handler: tb.handleLogoClick.createDelegate(tb)
    })
    this.items.push({
      xtype: 'button',
      icon: 'http://rg-resources/ix/png/plain/32/help.png',
      iconAlign: 'top',
      text: '&nbsp;Help&nbsp;',
      scale: 'large',
      ctCls: 'rg-apps-tb-button-over',
      cls: 'rg-apps-tb-button',
      minWidth: 50,
      handler: tb.handleHelpClick.createDelegate(tb)      
    })
    RG.Loft.Toolbar.superclass.initComponent.call(this);
  },
  // private
  afterRender: function(){
    var tb= this
    Ext.Toolbar.prototype.afterRender.call(this);    
    
    //Add the contextmenu
    this.getEl().on('contextmenu', function(evt, el, obj) {
      evt.preventDefault();
      evt.stopPropagation();
      
      var sourceEl= evt.getTarget('.rg-apps-tb-button')
      if (sourceEl && sourceEl.id) {	
        var cmp= Ext.getCmp(sourceEl.id)      
        if (cmp && cmp.recordID) {
          var record= tb.store.getById(cmp.recordID)
          if (record) {
            tb.handleNodeContextmenu(record, sourceEl, evt)
          }
        }
      }      
    })   
    
    //Add the tooltips
    tb.tip = new Ext.rx.AnchorToolTip({
      target: this.getEl(),
      delegate: '.rg-apps-tb-button',
      trackMouse: false,
      showDelay: 1500,
      quickShowInterval: 0,
      renderTo: document.body,
      autoHide: true,
      closable: false,
      //bodyCssClass: 'rg-apps-tt',
      anchor: 'left',
      tpl: new Ext.XTemplate(
        '<tpl for=".">',
        '<table cellspacing="0" class="rg-apps-tt">',
        '<tr>',
        '<th width="32"><div class="{className}" ><img width="32" height="32" src="/aig/img/s.gif"/></div></th>',
        '<th> <span>{[fm.htmlEncode(values.name)]}</span></th>',
        '</tr><tr>',
        '<td colspan="2">{[fm.htmlEncode(values.description)]}</td>',
        '</tr>',
        '</table>',
        '</tpl>'  
        ),      
      listeners: {
        beforeshow: function(){
          if (tb.isDragging=== true || (tb.menu && tb.menu.isVisible())) {
            return false
          }
          try {
            if (this.tip.triggerElement && this.tip.triggerElement.id) {	
              var cmp= Ext.getCmp(this.tip.triggerElement.id)      
              if (cmp && cmp.recordID) {
                var record= tb.store.getById(cmp.recordID)
                if (record) {
                  var ttData= {
                    className: RG.Icon.Utils.getSizedIconClass(record.data.className, 32),
                    name: record.data.name,
                    description: record.data.description
                  }              
                  this.tip.tpl.overwrite(this.tip.body, ttData)
                  return true
                }
              }
            }            
          } catch (e) {
          }
          return false
        },
        scope: tb
      }
    })
    this.reloadLoftItems()
  },
  handleNodeContextmenu: function(record, node, evt) {
    this.menuTargetRecord = record
    if (!this.menu) {
      this.menu = new Ext.menu.Menu({
        items: [{
          text: 'Remove',
          icon: '/aig/img/delete.gif',
          scope: this,
          handler: function(){
            this.handleRemoveLoftItem(this.menuTargetRecord)
          }
        }]
      })
    }
    this.menu.showAt(evt.getXY())
  },  
  reloadLoftItems: function() {
    this.store.removeAll(true)  
    this.store.reload({
      callback: function(r) { 
        this.updateLoftItems()        
      },
      scope: this
    })
  },
  updateLoftItems: function() {
    var tb= this
    if (!this.rendered) {
      return
    }
    var items= this.items.items
    var count= items.length    
    
    var removeItems= []
    for (var index = 0; index < count; index++) {
      var item = items[index]
      if (Ext.type(item.recordID)) {
        removeItems.push(item)
      }
    }
    Ext.each(removeItems, function(removeItem) {
      this.remove(removeItem)
    }, this)    
        
    if (this.store) {  
      this.store.each(function(record, index) {        
        var className= RG.Icon.Utils.getSizedIconClass(record.data.className, 32)
        var itemName= Ext.util.Format.ellipsis(record.data.name ,15)
        itemName= Ext.util.Format.htmlEncode(itemName)
        var tbButton= new Ext.Button({
          iconCls: className,
          iconAlign: 'top',
          text: itemName,
          scale: 'large',
          ctCls: 'rg-apps-tb-button-over',
          cls: 'rg-apps-tb-button',
          minWidth: 50,
          recordID: record.data.id,
          handler: tb.handleLoftItemClick.createDelegate(tb)
        })
        this.insert(this.loftStartPos + index, tbButton)
      }, this)        
    }
    this.doLayout()
  },
  handleLogoClick: function() {
    Ext.MessageBox.confirm("Confirm", "Restart Research Gateway?", function(button_id) {
      if (button_id == 'yes') {
        AIG.Security.SessionPinger.restartSession()
      }
    })
  },
  handleHelpClick: function() {
    var helpWin= Ext.getCmp('aig-help-window')
    if (!helpWin) {
      helpWin= new RG.Dialog.HelpWindow()
    }
    helpWin.show()
  },
  handleOpenLaunchpad: function(isToggle) {
    if (!AIG.openLaunchPad() && isToggle!== false) {
      AIG.closeLaunchPad()
    }    
  },
  handleCloseLaunchpad: function() {
    AIG.closeLaunchPad()
  },
  handleFindEntryPosition: function(event) {
    var tb= this 
    var entryIndex = -1
    var items= tb.items.items
    var count= items.length
    var xTotal= tb.getEl().getXY()[0]
    var xHover= event.getXY()[0] - xTotal
    
    for (var index = 0; index < count; index++) {
      var item= items[index]
      if (Ext.type(item.record)=='object') {
        var width    = item.getEl().getWidth()
        var midpoint = xTotal + width / 2
            
        xTotal += width;
            
        if (xHover < midpoint) {
          entryIndex = index;       

          break;
        } else {
          entryIndex = index + 1;
        }
      }
    }
    return (entryIndex<0 ? 4 : entryIndex)
    
  },
  handleCreateQuickItem: function(dragSource, event, data) {
    if (!this.handleCanDrop(dragSource, event, data)) {
      return false
    }  
    if (this.isFull()) {
      showWarningDialog('Unable To Add More Apps To Toolbar', 
        'Maximum number of apps in toolbar ('+this.MAX_ITEMS+') has been reached.'+
        '<br/>Please remove some apps from the toolbar to add others.')
      return false    
    } else {
      this.store.add([data.record])   
      return true
    }
  },  
  handleRemoveLoftItem: function(record) {
    if (record) {
      var localRecord= this.store.getById(record.id)
      if (localRecord) {
        this.store.remove(localRecord)
      }
      return true
    }
  },
  handleCanDrop: function(dragSource, event, data) {
    if (data && data.record && data.record.data.className && data.record.data.type) {
      return true
    }
    return false
  },
  handleLoftItemClick: function(item, evt) {
    if (!item) {
      return 
    } 
    var appRecord= this.store.getById(item.recordID)
    
    if (!appRecord) {
      return
    }
    if (appRecord) {
      var appLauncher= new RG.Loft.AppLauncher({
        appRecord: appRecord,
        showResources: true,
        listeners: {
          launch: function(launcher, record, launched) {            
            if (!launched) {
              return
            }
            switch(record.data.type) {
              case "FAVORITES_TOOL":
                break;
              case "PREFERENCES_TOOL":
                break;
              case "IMPORT_TABLE_TOOL":
                break
              case "DOCUMENTS_TOOL":
                break
              case "EXPLORE_TOOL":
                break;
              case "VQT_TOOL":
                break;
              case "LISTS_TOOL":
                break;
              case "PROJECT_VIEW_TOOL":
                break;
              case "FAVORITE":
                break;
              case "SERVICE":
                break;
            }
          },
          beforeservicelaunch: function(record, serviceValues) {
          }
        }
      }) 
      appLauncher.launch()
    }
  },
  handleLaunchService: function(serviceRecord) {
    if (!RG.isRecordType(serviceRecord, 'ServiceRecord')) {
      return
    }
    new RG.Service.Launcher({
      size: this.size,
      serviceRecord: serviceRecord,
      showResources: true,
      listeners: {
        beforelaunch: function(serviceRecord, values) {
          AIG.closeLaunchPad()
        }
      }
    }).launch() 
  },
  hasApp: function(record) {
    var ret= false
    if (RG.isRecordType(record, 'AppRecord')) {
      this.store.each(function(r, index) {        
        if (r.data.id== record.data.id) {
          ret= true
        }
      })
    }    
    return ret
  },
  getItemCount: function() {
    return this.store.getCount()
  },
  isFull: function() {
    return (this.store.getCount()>= this.MAX_ITEMS)
  },
  saveLoftItems: function(cb, scope) {
    var recordIDs= []
    this.store.each(function(record, index) {        
      recordIDs.push(record.data.id)
    })
    Ext.Ajax.request({
      url: '/aig/store.go?request=rgapps',      
      params: {
        loftrx: 'SAVEQUICKAPPS',
        quickApps: Ext.encode({
          ids: recordIDs
        })
      }, 
      success: function() {
        if (Ext.isFunction(cb)) {
          cb.call(scope)
        }
      }
    }) 
  }
})      
 
RG.Loft.ToolbarSeparator= Ext.extend(Ext.Toolbar.Separator, {
  reorderable: false,
  onRender: function(ct, position){
    ct.setStyle({
      "padding-top": "3", 
      "vertical-align": "top"
    })
    this.el = ct.createChild({
      tag: 'span',
      cls: 'xtb-sep',
      style: 'height:45px; background-repeat: repeat-y;'
    }, position);
  }
})         


