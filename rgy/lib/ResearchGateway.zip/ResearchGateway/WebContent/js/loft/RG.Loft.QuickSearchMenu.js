
RG.Loft.QuickSearchMenu= Ext.extend(RG.Loft.StoreMenu, {    
  alwaysReload: true,
  initComponent: function() {    
    var menu= this
    this.store= new Ext.data.Store({
      // load using HTTP
      url :'/aig/store.go?request=SERVICES&queryType=QUICK_SERVICES&responseFormat=XML', 
      sortInfo: {
        field: 'LastUsed',
        direction: 'DESC'
      },
      listeners :{
        loadexception : function(store, options, error) {
          aigErrorHandler(error)
        }
      },
      // the return will be XML, so lets set up a reader
      reader :new Ext.data.XmlReader({
        // records will have an "Service" tag
        record :'Service',
        id :'ServiceKey'
      }, RG.Record.ServiceRecord)
    })  
    RG.Loft.QuickSearchMenu.superclass.initComponent.call(this);
  },
  updateMenuItems: function(loadedState, records){
    var menu= this
    this.removeAll();
    if (this.el) {      
      this.el.sync();      
      if (loadedState) {
        if (records.length> 0) {
          if (!this.radioButtonLabelTpl) {
            this.radioButtonLabelTpl = new Ext.XTemplate('<span>',
              '<img src="/aig/img/s.gif" class={IconCls16} style= "height:16px;vertical-align:middle"></img>',
              '<span style= "padding-left:3px">{CategoryTag}</span>',                
              '</span>');
            this.radioButtonLabelTpl.compile();
          }
          var radioButtons= []
          var comboServiceRecords= new Ext.util.MixedCollection()
          for(var i=0; i< Math.min(3, records.length); i++) {
            var serviceRecord= records[i]
            radioButtons.push({
              xtype: 'radio',
              boxLabel: this.radioButtonLabelTpl.apply(serviceRecord.data), 
              name: 'rb-serviceKey', 
              inputValue: serviceRecord.data.ServiceKey,
              serviceRecord: serviceRecord,
              checked: (i==0)
            })
          }
          for(var i= 3; i<records.length; i++) {
            //for(var i= 0; i<records.length; i++) {
            comboServiceRecords.add(records[i])
          }          
          
          radioButtons.push({
            xtype: 'radio',
            boxLabel: this.radioButtonLabelTpl.apply({
              IconCls16: 'ix-v0-16-colors', 
              CategoryTag: 'Other Types'
            }), 
            name: 'rb-serviceKey', 
            inputValue: '_otherTypes',
            checked: false,
            disabled: (comboServiceRecords.length<=0),
            listeners: {
              check: this.otherToggle.createDelegate(this)
            }
          })          
          
          this.form= new Ext.form.FormPanel({      
            frame: true,
            btype: 'form',
            layout: 'form',
            removeMode: 'container',
            hideOnClick: false,
            labelAlign: 'top',
            width:350,
            height:330,          
            labelWidth: 100,                                                              
            items:[{
              xtype: 'fieldset',
              title: 'Search For', 
              items:[{
                xtype: 'radiogroup',
                hideLabel: true,
                columns: 1,
                items: radioButtons
              }, new Ext.form.ComboBox({
                xtype:'combo',
                hideLabel: true,
                width: 280,
                maxHeight: 100,              
                valueField: 'ServiceKey',
                displayField: 'CategoryTag',  
                emptyText: 'Select other search type',
                typeAhead :true,
                editable :true,
                resizable :true,
                forceSelection: true,
                disabled: true,
                mode :'local',
                triggerAction :'all',              
                selectOnFocus: true,
                tpl: new Ext.XTemplate(
                  '<tpl for="."><div class="search-item" style= "height:18px;margin-top:5px;margin-bottom:5px">',
                  '<img src="/aig/img/s.gif" class={IconCls16} style= "height:16px;vertical-align:middle"></img>',
                  '<span style= "padding-left:3px">{CategoryTag}</span>',                
                  '</div></tpl>'
                  ),
                style: {
                  marginLeft: '25px'
                },                    
                itemSelector: 'div.search-item',                  
                store: new Ext.data.Store({
                  proxy : new Ext.data.MemoryProxy(),
                  autoLoad: false,
                  reader :new Ext.data.ArrayReader({}, 
                    RG.Record.ServiceRecord)
                }),
                getListParent: function() {
                  return this.el.up('.x-menu');
                }, 
                listeners: {
                  select: function(combo, record) {
                    combo.serviceRecordKey= record.id
                  }
                }               
              })]
            }, (this.otherFieldSet= new Ext.form.FieldSet({
              xtype: 'fieldset',
              title: 'Enter Search Term and Press [Enter]',
              items: [(menu.queryField= new Ext.form.TwinTriggerField({
                name: 'query',
                hideLabel: true,
                width: 280,
                trigger1Class: 'x-form-clear-trigger',
                trigger2Class: 'x-form-search-trigger',
                hideTrigger1: false,
                initComponent: function(){
                  Ext.form.TwinTriggerField.prototype.initComponent.call(this);
                  this.on('specialkey', function(f, e){
                    if (e.getKey() == e.ENTER) {
                      this.onTrigger2Click();
                    }
                  }, this);
                },
                onTrigger1Click: function(evt) {
                  this.reset()
                },
                onTrigger2Click: function(evt) {
                  menu.performSearch()
                }
              }))]
            }))
            ]
          })
          this.add(this.form)
          this.otherServiceCombo= this.form.find('xtype', 'combo')[0]
          if (comboServiceRecords.getCount()> 0) {
            comboServiceRecords.sort('ASC', function(r1, r2) {
              var c1= r1.data.CategoryTag
              var c2= r2.data.CategoryTag
              return (c1 > c2 ? 1 : (c1 < c2 ? -1 : 0))
            })
            this.otherServiceCombo.store.add(comboServiceRecords.getRange())
          } 
          menu.queryField.focus(true, 50)

        } else {
          this.hide() 
        }
      } else {
        this.add('<span class="loading-indicator">' + this.loadingText + '</span>');
      }
      this.loaded = loadedState;
          
    } 
  },
  otherToggle: function(button, checked) {
    this.otherServiceCombo.setDisabled(!checked)   
    if (checked) {
      this.otherServiceCombo.onTriggerClick ()
    }
  },
  performSearch: function() {
    var formValues= this.form.getForm().getValues()
    var queryValue= formValues.query       
    var serviceRecordKey= formValues['rb-serviceKey']
    var serviceRecord    
    
    if (Ext.isString(serviceRecordKey)) {
      if (serviceRecordKey== '_otherTypes') {
        serviceRecord= this.store.getById(this.otherServiceCombo.serviceRecordKey)
      } else {
        serviceRecord= this.store.getById(serviceRecordKey)
      }
    }
    
    if (!Ext.isRecord(serviceRecord)) {
      showErrorDialog("Unable to run quick search", "No search selected")
      return
    }

    if (!Ext.isString(queryValue) || !hasLength(queryValue)) {
      showErrorDialog("Unable to run quicks search", "No query provided")
      return
    }
    this.hide() 
    
    new RG.Service.Launcher({
      listeners: {
        beforelaunch: function() {
          AIG.closeLaunchPad()
        }
      }
    }).executeQuickService(serviceRecord, queryValue)
  }
})
