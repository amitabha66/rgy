RG.Loft.WelcomeWindow = Ext.extend(Ext.Window, {
  title: 'Welcome to Research Gateway',
  iconCls: 'ix-v0-16-colors force-border-box',
  resizable: false,
  constrain: true,
  constrainHeader: true,
  minimizable: false,
  maximizable: false,
  modal: true,
  shim: true,
  buttonAlign: "center",
  width: 400,
  height: 400,
  minHeight: 80,
  plain: true,
  footer: true,
  closable: true,
  border: false,
  closeAction: 'hide',
  layout: 'border',
  initComponent: function() {
    var me = this
    var rgToolbar= Ext.getCmp('aig_main-toptoolbar')
    
    this.items = [{
        region: 'north',
        height: 200,
        html: {
          cls: 'welcome-logo',
          tag: 'div',
          children: [{
              tag: 'div',
              id: 'welcome-title',
              html: 'Welcome to Research Gateway'
            }, {
              tag: 'div',
              id: 'welcome-content',
              html: 'Please select your initial apps from the sets below.'
            }, {
              tag: 'div',
              id: 'welcome-content',
              html: 'You can add additional apps by using the ' +
                      '<i>Add App To Launch Pad</i> tool access by clicking ' +
                      'the button in the upper-left corner.'
            }
          ]
        }
      }, {
        xtype: 'form',
        region: 'center',
        labelAlign: 'top',
        frame: true,
        items: [new Ext.form.ComboBox({
            fieldLabel: 'Please Select Your Initial Apps',
            store: new Ext.data.Store({
              autoLoad: true,
              url: '/aig/store.go?request=rgapps',
              baseParams: {
                responseFormat: 'JSON',
                loftrx: 'APPROLES'
              },
              reader: new Ext.data.JsonReader({
                root: "roles"
              }, Ext.data.Record.create([
                {
                  name: 'role'
                }
              ]))
            }),
            width: 300,
            displayField: 'role',
            valueField: 'role',
            typeAhead: true,
            forceSelection: true,
            editable: false,
            triggerAction: 'all',
            value: 'Standard',
            selectOnFocus: true,
            tpl: new Ext.XTemplate('<tpl for=".">', '<div class="x-combo-list-item">',
                    '<img src="http://rg-resources/ix/png/plain/24/cubes.png" align="absmiddle" border=0 style="margin-right:3px">',
                    '{role} Apps</div>',
                    '</tpl>')
          })
        ]
      }]
    this.fbar = new Ext.Toolbar({
      enableOverflow: false,
      items: [{
          text: 'OK',
          handler: function() {
            var role = me.findByType('combo')[0].getValue()
            me.hide()
            me.view.showUpdateProgress()

            Ext.Ajax.request({
              url: '/aig/store.go?request=RGAPPS&loftrx=RESETAPPS',
              params: {
                role: role
              },
              success: function() {
                me.view.store.reload()
                rgToolbar.reloadLoftItems()
                me.view.handleFilter()
                Ext.Msg.hide()                
              },
              failure: function(options) {
                Ext.Msg.hide()                
              }
            })
          }
        }]
    })
    RG.Loft.WelcomeWindow.superclass.initComponent.call(this)
  }
})
    