
/**
 *  @class RG.Service.Launcher
 *  @extends Ext.util.Observable
 *   
 *  The RG.Service.Launcher handles all service launches from various sources including
 *  LaunchPad, Entity (Data Items) Tree, Quick Launch, Toolbars...
 *  This includes loading the service XML into the record, and if necessary loading the 
 *  service parameter dialog before invoking.
 *  
 */
RG.Service.Launcher = Ext.extend(Ext.util.Observable, {
  constructor: function(config) {
    Ext.apply(this, config, {
      dialogScale: 0.85
    })
    Ext.applyIf(this, config)

    Ext.applyIf(this, {
      size: AIG.getMainViewport().getSize(),
      launchPad: Ext.getCmp('aig_launchpad')
    })

    this.addEvents(
            "beforelaunch",
            "launch"
            )
    RG.Service.Launcher.superclass.constructor.call(this, config)
  },
  launch: function() {
    if (this.serviceRecord) {
      if (this.serviceRecord.data.IsWidget) {
        if (this.serviceRecord.data.WidgetURL) {
          this.loadWidget(this.serviceRecord)
        }
      } else if (this.serviceRecord.data.IsVQT) {
        this.serviceRecord.getServiceXML(function(serviceXML) {
          this.loadVQTQuery(this.serviceRecord, serviceXML)
        }, this)
      } else {
        this.getServiceParameters(this.serviceRecord, function(submit, formValues, form, args) {
          if (submit) {
            this.executeServiceByForm(this.serviceRecord, formValues, form, args)
          }
        })
      }
    } else if (this.resultKey) {
      this.getAndLaunchServiceFromResultKey(this.resultKey)
    } else {
      this.launchSelectService()
    }
  },
  loadVQTQuery: function(serviceRecord, serviceXML) {
    if (!RG.isRecordType(serviceRecord, 'ServiceRecord') || !serviceRecord.data.IsVQT) {
      return
    }
    AIG.closeLaunchPad()
    var vqtQueryXMLText = selectSingleNodeValue(serviceXML, "//Parameter[Name='QueryRequest']/Value")
    var vqtWindow = new RG.Loft.AppLauncher().launchVQTToolHandler()

    var vqtPanel = vqtWindow.find('id', "vqt_query_panel")
    if (!vqtPanel || vqtPanel.length == 0) {
      return
    }
    vqtPanel = vqtPanel[0]
    var retry = 0
    var maxRetry = 25
    var loadFunc = function() {
      try {
        document.getElementById(vqtPanel.getFrame().id).contentWindow.IRIS.App.VQT.rebuildFromXml(vqtQueryXMLText)
      } catch (e) {
        retry++
        if (retry < maxRetry) {
          loadFunc.defer(1000)
        } else {
          showWarningDialog('VQT Query Load Paused',
                  'VQT seems to be taking a while to load. This is probably not be a problem. After VQT loads, please try reloading your VQT query.')
        }
      }
    }
    if (vqtPanel.getFrameDocument()) {
      //document.getElementById(vqtPanel.getFrame().id).contentWindow.IRIS.App.VQT.rebuildFromXml(vqtQueryXMLText)
      loadFunc.defer(100)
    } else {
      vqtPanel.on('documentloaded', function(p) {
        loadFunc.defer(1000)
        p.un('load', arguments.callee)
      })
    }
  },
  loadWidget: function(serviceRecord) {
    var widgetLauncher = new RG.Widget.Launcher({
      parentLauncher: this,
      serviceRecord: serviceRecord
    })
    this.relayEvents(widgetLauncher, ["beforelaunch", "launch"])
    widgetLauncher.launch()
  },
  launchSelectService: function() {
    new RG.Dialog.ServiceSelectDialog({
      title: 'Select Search',
      iconCls: 'ix-v0-16-signpost',
      showResources: this.showResources,
      queryParams: {
        queryType: 'query'
      },
      cb: function(submit, serviceRecord, formValues, form, args) {
        if (submit) {
          this.executeServiceByForm(serviceRecord, formValues, form, args)
        }
      },
      scope: this
    }).show()
  },
  launchAndExecuteService: function(serviceRecord) {
    if (!RG.isRecordType(serviceRecord, 'ServiceRecord') && Ext.isObject(serviceRecord)) {
      serviceRecord = new RG.Record.ServiceRecord(serviceRecord)
    }
    if (!RG.isRecordType(serviceRecord, 'ServiceRecord') && Ext.isString(serviceRecord)) {
      try {
        serviceRecord = new RG.Record.ServiceRecord(Ext.decode(serviceRecord))
      } catch (e) {
      }
    }
    this.getServiceParameters(serviceRecord, function(submit, formValues, form, args) {
      if (submit) {
        this.executeServiceByForm(serviceRecord, formValues, form, args)
      }
    })
  },
  getServiceParameters: function(serviceRecord, cb) {
    var dialog = this
    if (!RG.isRecordType(serviceRecord, 'ServiceRecord') && Ext.isObject(serviceRecord)) {
      serviceRecord = new RG.Record.ServiceRecord(serviceRecord)
    }
    if (!RG.isRecordType(serviceRecord, 'ServiceRecord') && Ext.isString(serviceRecord)) {
      try {
        serviceRecord = new RG.Record.ServiceRecord(Ext.decode(serviceRecord))
      } catch (e) {
      }
    }

    if (serviceRecord.data.EditableParams > 0) {
      if (Ext.WindowMgr.findFirstRecordWindow('serviceRecord', 'ServiceKey', serviceRecord, true)) {
        return
      }

      var serviceName = serviceRecord.data.Name
      serviceRecord.getServiceXML(function(serviceXML) {
        if (serviceXML) {
          var paramDialog = new RG.Dialog.ServiceParameterDialog({
            title: serviceName + " Parameters",
            serviceRecord: serviceRecord,
            serviceXML: serviceXML,
            showResources: this.showResources,
            handler: function(submit, formValues, form, args) {
              cb.call(dialog, submit, formValues, form, args)
            },
            scope: dialog
          })
          paramDialog.show()
        } else {
          showInformationDialog('Error Loading Service', 'Unable to load service ' + serviceName)
          dialog.hide()
        }
      }, this, {
        resultKey: this.resultKey
      })
    } else {
      cb.call(dialog, true)
    }
  },
  getAndLaunchServiceFromResultKey: function(resultKey) {
    Ext.Ajax.request({
      url: '/aig/store.go?request=SERVICES',
      params: {
        queryType: 'SERVICE',
        resultKey: resultKey,
        responseFormat: 'JSON'
      },
      success: function(response, options) {
        var recordObj = Ext.decode(response.responseText)
        if (recordObj && Ext.isArray(recordObj.services) && recordObj.services.length) {
          var serviceRecord = new RG.Record.ServiceRecord(recordObj.services[0])
          if (RG.isRecordType(serviceRecord, 'ServiceRecord')) {
            if (serviceRecord.data.IsVQT) {
              serviceRecord.getServiceXML(function(serviceXML) {
                this.loadVQTQuery(serviceRecord, serviceXML)
              }, this, {
                resultKey: resultKey
              })
            } else {
              this.getServiceParameters(serviceRecord, function(submit, formValues, form) {
                if (submit) {
                  this.executeServiceByForm(serviceRecord, formValues, form)
                }
              })
            }
          }
        }
      },
      failure: function(options) {
        showResponseError(options, 'Unable to load app')
      },
      scope: this
    })
  },
  executeServiceByForm: function(serviceRecord, values, serviceForm, args) {
    var launcher = this
    if (Ext.type(this.transactionID) !== false || !serviceForm || !serviceForm.isValid()) {
      return
    }
    if (launcher.fireEvent('beforelaunch', this, serviceRecord) === false) {
      return
    }

    var progressBox = Ext.Msg.show({
      title: 'Status',
      msg: 'Running...',
      progressText: serviceRecord.data.Name,
      icon: 'ix-v0-32-hourglass',
      buttons: Ext.Msg.CANCEL,
      closable: false,
      wait: true,
      modal: true,
      minWidth: 250,
      fn: function(buttonID, text) {
        if (launcher.transactionID != null && Ext.Ajax.isLoading(launcher.transactionID)) {
          progressBox.updateProgress(0, ' ', '')
          Ext.Ajax.abort(launcher.transactionID)
          launcher.transactionID = null
        }
      }
    })

    var additionalParams = {}

    if (Ext.isObject(args) && Ext.isObject(args.resourceServiceRecords) && Ext.isArray(args.resourceServiceRecords.serviceRecords)) {
      additionalParams.resourceServiceKeys = RG.Record.join(args.resourceServiceRecords.serviceRecords, "ServiceKey", ",")
    }

    launcher.transactionID = Ext.Ajax.request({
      url: '/aig/executequeryservice.go',
      success: function(response, options) {
        progressBox.updateProgress(0, ' ', '')
        progressBox.hide()
        addTreeNodesFromQueryResult(response, {
          fn: launcher.loadTreeNodesCallBack.createDelegate(),
          scope: this
        }, args)
        launcher.transactionID = null
        launcher.fireEvent('launch', launcher, serviceRecord, response, true)

      },
      failure: function(response, options) {
        progressBox.hide()
        progressBox.updateProgress(0, ' ', '')
        Ext.Msg.alert('Error', "Unable to run service. Reason: " + (hasLength(response.responseText) ? response.responseText : "No Results"))
        launcher.transactionID = null
        launcher.fireEvent('launch', launcher, serviceRecord, response, false)
      },
      form: serviceForm.getEl(),
      params: additionalParams
    })
  },
  executeQuickService: function(serviceRecord, queryValue) {
    var launcher = this
    if (Ext.type(this.transactionID) !== false || !Ext.isString(queryValue) || !hasLength(queryValue)) {
      return
    }
    if (launcher.fireEvent('beforelaunch', this, serviceRecord) === false) {
      return
    }

    var progressBox = Ext.Msg.show({
      title: 'Status',
      msg: 'Running...',
      icon: 'ix-v0-32-hourglass',
      progressText: serviceRecord.data.Name,
      buttons: Ext.Msg.CANCEL,
      closable: false,
      wait: true,
      modal: true,
      minWidth: 250,
      fn: function(buttonID, text) {
        if (launcher.transactionID != null && Ext.Ajax.isLoading(launcher.transactionID)) {
          progressBox.updateProgress(0, ' ', '')
          Ext.Ajax.abort(launcher.transactionID)
          launcher.transactionID = null
        }
      }
    })
    launcher.transactionID = Ext.Ajax.request({
      url: '/aig/executequeryservice.go?quick_search',
      success: function(response, options) {
        progressBox.updateProgress(0, ' ', '')
        progressBox.hide()
        var args = {}
        var store = new Ext.data.Store({
          reader: new Ext.data.XmlReader({
            record: 'Service',
            id: 'ID'
          }, RG.Record.ServiceRecord),
          autoLoad: false
        })
        store.loadData(response.responseXML)

        var defaultResources = store.getRange()
        if (Ext.isArray(defaultResources) && defaultResources.length > 0) {
          args.resourceServiceRecords = {
            serviceRecords: defaultResources,
            entityCategory: serviceRecord.data.EntityCategory
          }
        }
        addTreeNodesFromQueryResult(response, {
          fn: launcher.loadTreeNodesCallBack.createDelegate(),
          scope: this
        }, args)
        launcher.transactionID = null
        launcher.fireEvent('launch', launcher, serviceRecord, response, true)
      },
      failure: function(response, options) {
        progressBox.hide()
        progressBox.updateProgress(0, ' ', '')
        if (!showResponseError(response, 'Unable to Run Service')) {
          Ext.Msg.alert('Unable to Run Service', (hasLength(response.responseText) ? response.responseText : "No Results"))
        }
        launcher.transactionID = null
        launcher.fireEvent('launch', launcher, serviceRecord, response, false)
      },
      params: {
        query: queryValue,
        serviceKey: serviceRecord.id
      }
    })
  },
  /**
   * This is mostly for debugging
   */
  loadQueryResultFromQueryRunID: function(queryRunID) {
    var launcher = this
    if (Ext.type(this.transactionID) !== false || !hasLength(queryRunID)) {
      return
    }

    var progressBox = Ext.Msg.show({
      title: 'Status',
      msg: 'Running...',
      icon: 'ix-v0-32-hourglass',
      progressText: 'Loading Query Result',
      buttons: Ext.Msg.CANCEL,
      closable: false,
      wait: true,
      modal: true,
      minWidth: 250,
      fn: function(buttonID, text) {
        if (launcher.transactionID != null && Ext.Ajax.isLoading(launcher.transactionID)) {
          progressBox.updateProgress(0, ' ', '')
          Ext.Ajax.abort(launcher.transactionID)
          launcher.transactionID = null
        }
      }
    })
    launcher.transactionID = Ext.Ajax.request({
      url: '/aig/executequeryservice.go',
      success: function(response, options) {
        progressBox.updateProgress(0, ' ', '')
        progressBox.hide()
        var args = {}
        var store = new Ext.data.Store({
          reader: new Ext.data.XmlReader({
            record: 'Service',
            id: 'ID'
          }, RG.Record.ServiceRecord),
          autoLoad: false
        })
        store.loadData(response.responseXML)

        var defaultResources = store.getRange()
        if (Ext.isArray(defaultResources) && defaultResources.length > 0) {
          args.resourceServiceRecords = {
            serviceRecords: defaultResources,
            entityCategory: serviceRecord.data.EntityCategory
          }
        }
        addTreeNodesFromQueryResult(response, {
          fn: function(node) {
            node.select.defer(450, node)
            RG.Load.openEntityTableFromNode.defer(400, this, [node, true])
            RG.Load.openVisualizationFromNode.defer(400, this, [node])
          },
          scope: this
        })

        launcher.transactionID = null
      },
      failure: function(response, options) {
        progressBox.hide()
        progressBox.updateProgress(0, ' ', '')
        if (!showResponseError(response, 'Unable to Run Service')) {
          Ext.Msg.alert('Unable to Run Service', (hasLength(response.responseText) ? response.responseText : "No Results"))
        }
        launcher.transactionID = null
      },
      params: {
        query_run_id: queryRunID,
        serviceKey: 'VQTViewLoader'
      }
    })
  },
  executeLaunchService: function(serviceRecord, serviceParamsKey) {
    var launcher = this
    if (Ext.type(this.transactionID) !== false) {
      return
    }
    if (!RG.isRecordType(serviceRecord, 'ServiceRecord') && Ext.isObject(serviceRecord)) {
      serviceRecord = new RG.Record.ServiceRecord(serviceRecord)
    }
    if (!RG.isRecordType(serviceRecord, 'ServiceRecord') && Ext.isString(serviceRecord)) {
      try {
        serviceRecord = new RG.Record.ServiceRecord(Ext.decode(serviceRecord))
      } catch (e) {
      }
    }

    if (launcher.fireEvent('beforelaunch', this, serviceRecord) === false) {
      return
    }

    var progressBox = Ext.Msg.show({
      title: 'Status',
      msg: 'Running...',
      icon: 'ix-v0-32-hourglass',
      progressText: serviceRecord.data.Name,
      buttons: Ext.Msg.CANCEL,
      closable: false,
      wait: true,
      modal: true,
      minWidth: 250,
      fn: function(buttonID, text) {
        if (launcher.transactionID != null && Ext.Ajax.isLoading(launcher.transactionID)) {
          progressBox.updateProgress(0, ' ', '')
          Ext.Ajax.abort(launcher.transactionID)
          launcher.transactionID = null
        }
      }
    })
    launcher.transactionID = Ext.Ajax.request({
      url: '/aig/executequeryservice.go',
      params: {
        service_params: serviceParamsKey,
        serviceKey: serviceRecord.get("ServiceKey")
      },
      success: function(response, options) {
        progressBox.updateProgress(0, ' ', '')
        progressBox.hide()
        var args = {}
        var store = new Ext.data.Store({
          reader: new Ext.data.XmlReader({
            record: 'Service',
            id: 'ID'
          }, RG.Record.ServiceRecord),
          autoLoad: false
        })
        store.loadData(response.responseXML)

        var defaultResources = store.getRange()
        if (Ext.isArray(defaultResources) && defaultResources.length > 0) {
          args.resourceServiceRecords = {
            serviceRecords: defaultResources,
            entityCategory: serviceRecord.get("EntityCategory")
          }
        }

        addTreeNodesFromQueryResult(response, {
          fn: launcher.loadTreeNodesCallBack.createDelegate(),
          scope: this
        }, args)
        launcher.transactionID = null
        launcher.fireEvent('launch', launcher, serviceRecord, response, true)
      },
      failure: function(response, options) {
        progressBox.hide()
        progressBox.updateProgress(0, ' ', '')
        if (!showResponseError(response, 'Unable to Run Service')) {
          Ext.Msg.alert('Unable to Run Service', (hasLength(response.responseText) ? response.responseText : "No Results"))
        }
        launcher.transactionID = null
        launcher.fireEvent('launch', launcher, serviceRecord, response, false)
      }
    })
  },
  /**
   * This is a function used strictly as a delegated-callback when loading TreeNodes from a search form or Quick search
   */
  loadTreeNodesCallBack: function(node) {
    if (node.attributes.defaultview_exists && node.attributes.defaultview_exists == 'T') {
      node.select.defer(450, node)
      RG.Load.openEntityTableFromNode.defer(400, this, [node, true])
    } else if (Ext.isArray(node.childNodes) && node.childNodes.length == 1 &&
            Ext.isObject(node.resourceServiceRecords) && Ext.isArray(node.resourceServiceRecords.serviceRecords) &&
            node.resourceServiceRecords.serviceRecords.length > 0) {
      var entityNode = node.childNodes[0]
      var entityNodeUUID = entityNode.attributes.uuid
      var entityNodeTitle = entityNode.attributes.text
      var iconCls = entityNode.attributes.iconCls
      var serviceTabsPanel = Ext.getCmp("rg-main-container-panel")
      if (!equalsIgnoreCase('DATA_ANALYSES', node.attributes.entity_category)) {
        serviceTabsPanel.createEmptyServiceWindow({
          nodeKey: entityNodeUUID,
          nodeTitle: entityNodeTitle,
          iconCls: iconCls
        }, entityNode)
      } else {
        //Nothing can be done with a DATA Analysis node, so ...
      }
    } else if (!node.attributes.default_view_key || !node.attributes.default_view_url) {
      RG.Load.openEntityDefaultViewFromNode({
        node: node
      })
    }
  }
});
