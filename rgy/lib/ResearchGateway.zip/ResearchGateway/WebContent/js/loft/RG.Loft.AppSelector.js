/**
 * @author jemcdowe
 */
RG.Loft.AppSelector = Ext.extend(RG.Dialog.AnimatedWindow, {
  id: 'aig_appselector',
  layout: 'border',
  shadow: false,
  title: 'Add App to Launch Pad',
  border: true,
  draggable: true,
  resizable: true,
  closable: true,
  header: true,
  constrain: true,
  closeAction: 'close',
  initComponent: function(){
    var win= this
    
    this.appTree= new Ext.tree.TreePanel({
      useArrows: true,
      autoScroll: true,
      animate: true,
      enableDD: true,
      containerScroll: true,
      border: true,
      region: 'west',
      split: true,
      width: 200,
      collapsible :true,
      collapseMode :'mini',      
      hideCollapseTool: true,
      rootVisible: false,
      loader: new Ext.tree.TreeLoader({
        autoLoad :true,
        url: '/aig/store.go?request=rgapps',
        baseParams: {
          responseFormat: 'JSON',
          loftrx: 'APPSELECTOR'
        },
        processResponse : function(response, node, callback, scope){
          var json = response.responseText;
          try {
            var o = Ext.decode(json);
            var nodes
            if (Ext.isObject(o) && Ext.isArray(o.nodes)) {
              nodes= o.nodes
            }
            if (Ext.isArray(nodes)) {
              node.beginUpdate();
              for(var i = 0, len = nodes.length; i < len; i++){
                var n = this.createNode(nodes[i]);
                if(n){
                  node.appendChild(n);
                }
              }
              node.endUpdate();
              this.runCallback(callback, scope || node, [node]);
            }
          }catch(e){
            this.handleFailure(response);
          }
        },
        createNode: function(attr) {
          if (attr.iconCls) {
            attr.baseIconCls= RG.Icon.Utils.getSizedIconClass(attr.iconCls, 32)
            attr.iconCls= 'x-rg-appselector-tree-icon-32 '+ attr.baseIconCls
          } else {
            attr.iconCls= 'x-rg-appselector-tree-icon-32'
          }
          attr.cls= 'x-rg-appselector-tree-text-32'
          return Ext.tree.TreeLoader.prototype.createNode.call(this, attr);
        }    
      }),
      root: {
        nodeType: 'async',
        text: 'Apps',
        draggable: false,
        id: 'root',
        expanded: true,
        iconCls: 'ix-v0-32-add2',
        listeners: {
          load: function(rootNode) {
            var firstChild= rootNode.firstChild
            if (firstChild) {
              firstChild.select.defer(100, firstChild)
            }
          }
        }
      }
    })
    var gridStore= new Ext.data.GroupingStore({
      autoLoad :false,
      url: '/aig/store.go?request=rgapps',
      baseParams: {
        responseFormat: 'JSON',
        loftrx: 'APPSELECTOR'
      },
      sortInfo: {
        field: 'order',
        direction: 'ASC'
      },
      groupField: 'category',
      reader :new Ext.data.JsonReader({
        root :"apps",
        idProperty :'id'
      }, RG.Record.AppRecord)
    })
    this.appSelectorPanel= new Ext.grid.GridPanel({
      region: 'center',
      disableSelection: true,
      hideHeaders: true,
      trackMouseOver: false,
      loadMask: true,
      headerCfg : {
        tag : 'div',            
        cls : 'x-rg-appselector-grid-panel-header',            
        cn : [{
          tag : 'img',                
          cls : 'x-rg-appselector-grid-panel-header-icon ix-v0-32-window_add',                
          src : '/aig/img/s.gif'
        }, {
          tag : 'span',                
          cls : 'x-rg-appselector-grid-panel-header-text',                
          html : 'Applications'
        }]
      },      
      nameCellTpl: new Ext.XTemplate(
        '<tpl for=".">',
        '<table>',
        '<tr>',
        '<td rowspan="2" style="width:32px;padding-right: 5px" valign= "top">',
        '<img src="/aig/img/s.gif" style="width:32px;height:32px;border:none" class="{[RG.Icon.Utils.getSizedIconClass(values.className, 32)]}"/>',
        '</td>',
        '<td><b>{name}</b></td>',
        '</tr>',
        '<tr>',
        '<td>{description}</td>',
        '</tr>',        
        '</table>',
        '</tpl>'
        ),
      installCellTpl: new Ext.XTemplate(
        '<tpl for=".">',
        '<table id={[this.getLinkId()]} recordID= {id} cellpadding="0" cellspacing="0" style="cursor:pointer;border:solid 1px #273c56;background-color:#538cd3;height:18px;width:80px">',
        '<tr>',
        '<td style="width:16px;padding-right: 5px;padding-top: 2px" valign= "middle">',
        '<img src="/aig/img/s.gif" style="width:16px;height:16px;border:none" class="{[values.onLaunchPad ? "ix-v0-16-delete2" : "ix-v0-16-add2"]}"/>',
        '</td>',
        '<td style="color:white;height:20px" valign= "middle"><b><div style="padding-top: 4px" >{[values.onLaunchPad ? "Remove" : "Install"]}</div></b></td>',
        '</tr>',                
        '</table>',
        '</tpl>', {
          getLinkId: function(values) {
            var result = Ext.id();
            this.addListener.defer(1, this, [result]);
            return result;
          },
          addListener: function(id) {
            Ext.get(id).on('click', function(e){
              e.stopEvent();
              var fly= Ext.fly(this)
              var recordID= fly.getAttribute('recordID')              
              var record= win.appSelectorPanel.getStore().getById(recordID)
              win.onInstallClicked(record)
            })
          }
        }),
      store: gridStore,
      columns: [{
        id:'name',
        header: "Name", 
        width: 60, 
        sortable: true, 
        dataIndex: 'name',
        renderer: function(value, metaData, record, rowIndex, colIndex, store) {
          return win.appSelectorPanel.nameCellTpl.apply(record.data)
        }
      }, {
        header: "On Launch Pad", 
        width: 20, 
        sortable: true, 
        dataIndex: 'onLaunchPad',
        renderer: function(value, metaData, record, rowIndex, colIndex, store) {
          return win.appSelectorPanel.installCellTpl.apply(record.data)
        }
      },  {
        header: "Category", 
        dataIndex: 'category',
        hidden: true
      }      
      ],
      view: new Ext.grid.GroupingView({
        forceFit:true,
        groupTextTpl: '{group}'
      })
    })
 
    this.appTree.getSelectionModel().on('selectionchange', function(selModel, node) {
      if (node.isLeaf()) {
        win.onNodeSelect(node)
      }
    }) 
    this.appTree.getSelectionModel().on('beforeselect', function(selModel, newNode, oldNode) {
      return !(win.appSelectorPanel.loading===true)
    })  
    this.appSelectorPanel.getStore().on('beforeload', function(store) {
      store.removeAll()
      win.appSelectorPanel.loading= true
    })  
    this.appSelectorPanel.getStore().on('load', function(store) {
      win.appSelectorPanel.loading= false
    })      
    this.appSelectorPanel.getStore().on('exception', function(store) {
      win.appSelectorPanel.loading= false
    })  
    
    this.items = [this.appTree, this.appSelectorPanel]
    
    this.tbar= ['->',
    new RG.Form.SearchField({
      emptyText: 'Enter a keyword to filter apps',
      store: gridStore,
      width:320,
      searchOnKeyPress: true,
      listeners: {
        search: function(field, value) {
          if (hasLength(value)) {  
            var nameFn= gridStore.createFilterFn('name', value, true, false)
            var descFn= gridStore.createFilterFn('description', value, true, false)
            var fn= function(r, id) {
              return nameFn.call(null, r, id) || descFn.call(null, r, id)
            }
            gridStore.filterBy(fn)
          } else {
            gridStore.clearFilter()
          }
        },
        clear: function(field) {
          gridStore.clearFilter()
        }
      }
    })
    ]    
    
    this.buttons= [{
      text: 'Reset Launch Pad',
      handler: function() {
        win.resetLaunchPad()
      }
    }, {
      text: 'Close',
      handler: function() {
        win.close()
      }
    }]
    
    RG.Loft.AppSelector.superclass.initComponent.call(this)
  },
  onNodeSelect: function(node) {
    this.appSelectorPanel.header.child('.x-rg-appselector-grid-panel-header-text').update(node.attributes.text)
    var iconEl= this.appSelectorPanel.header.child('.x-rg-appselector-grid-panel-header-icon')
    var currentIconCls= iconEl.dom.className.split(' ')[1]
    iconEl.replaceClass(currentIconCls, node.attributes.baseIconCls)     
    if (node.attributes.grouped=== true) {
      this.appSelectorPanel.getStore().groupField = 'category';
    } else {
      this.appSelectorPanel.getStore().groupField = false
    }    
    this.appSelectorPanel.getStore().load({
      params: {
        node: node.id
      }
    })
  },
  onInstallClicked: function(record) {
    var install= !record.data.onLaunchPad
    if (install) {
      this.appPanel.handleAddApp(record, function(result) {
        this.appSelectorPanel.getStore().reload()
      }, this)
    } else {
      this.appPanel.handleRemoveApp(record, function(result) {
        this.appSelectorPanel.getStore().reload()
      }, this)
    }
  },
  resetLaunchPad: function() {
    this.appPanel.resetLaunchPad(null, function(result) {
      this.appSelectorPanel.getStore().reload()
    }, this)
  }

})

