/**
 * @author jemcdowe
 */
RG.Loft.LoftWindow = Ext.extend(Ext.Window, {
  id: 'aig_launchpad',
  layout: 'border',
  shadow: false,
  border: false,
  draggable: true,
  resizable: true,
  closable: false,
  header: false,
  constrain: true,
  closeAction: 'hide',
  //title: 'Research Gateway Launch Pad',
  initComponent: function() {
    var win = this
    this.appPanel = new RG.Loft.AppPadPanel({
      region: 'center',
      win: win,
      store: new Ext.data.Store({
        autoLoad: true,
        url: '/aig/store.go?request=rgapps',
        baseParams: {
          responseFormat: 'JSON'
        },
        sortInfo: {
          field: 'order',
          direction: 'ASC'
        },
        reader: new Ext.data.JsonReader({
          root: "apps",
          idProperty: 'id'
        }, RG.Record.AppRecord)
      })
    })
    this.items = [this.appPanel]

    //this.tools=[{
    //  id:'refresh',
    //   handler: function(event, toolEl, panel){
    //     win.refresh()
    //  }
    // }]

    var resizefunc = function() {
      if (win.isVisible()) {
        win.resizeToViewport()
      }
    }
    AIG.getMainViewport().on("resize", resizefunc)

    this.on('beforedestroy', function() {
      AIG.getMainViewport().un("resize", resizefunc)
      win.appPanel.panelClosing()
    })

    this.on('show', function() {
      win.checkForModalDialogs()
    })

    this.on('beforehide', function() {
      this.appPanel.appView.saveCurrentSort()
    })
    this.on('beforeclose', function() {
      this.appPanel.appView.saveCurrentSort()
    })

    this.appPanel.store.on('exception', function(proxy, type, action, options, response, arg) {
      if (type === 'response') { //means the reader could not get any records :(
        new Ext.util.DelayedTask().delay(100, function() {
          new RG.Loft.WelcomeWindow({view: win.appPanel.appView}).show()
        })
      }
    })
    RG.Loft.LoftWindow.superclass.initComponent.call(this)
  },
  resizeToViewport: function() {
    var size = Ext.getBody().getViewSize();
    var top = 58
    size.height -= top - 2
    this.setPagePosition(0, top)
    this.setSize(size)
    this.checkForModalDialogs()
  },
  onWindowResize: function() {
    try {
      RG.Loft.LoftWindow.superclass.onWindowResize.call(this)
    } catch (e) {
    }
  },
  refresh: function() {
    this.appPanel.appView.saveCurrentSort(function() {
      this.appPanel.store.reload()
      var rgToolbar = Ext.getCmp('aig_main-toptoolbar')
      if (rgToolbar && rgToolbar.rendered) {
        rgToolbar.reloadLoftItems()
      }
    }, this)
  },
  checkForModalDialogs: function() {
    Ext.WindowMgr.each(function(win) {
      if (win.rendered && win.isVisible() && (win.modal || win.isDialog === true)) {
        if (Ext.isFunction(win.center)) {
          win.center()
        } else {
          RG.centerInViewport(win)
        }
        Ext.WindowMgr.bringToFront(win)
      }
    })
  }
})

