
RG.Loft.ButtonBar = Ext.extend(Ext.Toolbar, {  
  enableOverflow: true,
  initComponent : function() {
    var tb= this      
    this.plugins= [new RG.Loft.ButtonBarDroppable()] 
    
    this.store= new Ext.data.Store({
      autoLoad :false,
      url: '/aig/store.go?request=rgapps',
      baseParams: {
        loftrx: 'OWNERPAGES',
        responseFormat: 'JSON'
      },
      reader :new Ext.data.JsonReader({
        root :"pages",
        idProperty :'id'
      }, RG.Record.PageRecord)
    })
    this.store.on("add", function() {    
      this.updateToolbarItems()
    }, this);
    
    this.store.on("remove", function() {    
      this.updateToolbarItems()
    }, this);    
    
    this.leftItems= this.leftItems || []
    
    this.leftItems.push({      
      text: 'All Apps',
      iconCls: 'ix-v0-16-tables',        
      handler: this.handleAllClick.createDelegate(this)
    })
        
    this.items= []
    if (Ext.isArray(this.leftItems)) {
      this.items= this.items.concat(this.leftItems)
    }
    if (Ext.isArray(this.rightItems)) {
      this.items.push('->')
      this.items= this.items.concat(this.rightItems)
    }    
    RG.Loft.ButtonBar.superclass.initComponent.call(this);
  },
  afterRender: function(){
    var me= this
    this.reloadToolbarItems()
    RG.Loft.ButtonBar.superclass.afterRender.call(this);

    //Add the contextmenu
    this.getEl().on('contextmenu', function(evt, el, obj) {
      evt.preventDefault();
      evt.stopPropagation();
      
      var sourceEl= evt.getTarget('.rg-page-tb-button')
      if (sourceEl && sourceEl.id) {	
        var cmp= Ext.getCmp(sourceEl.id)      
        if (cmp && cmp.pageID) {
          var record= me.store.getById(cmp.pageID)
          if (record) {
            me.handlePageContextMenu(record, sourceEl, evt)
          }
        }
      }      
    })       
  },  
  reloadToolbarItems: function(cb, scope) {
    this.store.removeAll(true)  
    this.store.reload({
      callback: function(r) { 
        this.updateToolbarItems()        
        if (Ext.isFunction(cb)) {
          cb.call(scope, this)
        }
      },
      scope: this
    })
  },
  updateToolbarItems: function() {
    var me= this
    if (!this.rendered) {
      return
    }
    var items= this.items.items
    var count= items.length    
    
    var removeItems= []
    for (var index = 0; index < count; index++) {
      var item = items[index]
      if (Ext.type(item.pageID)) {
        removeItems.push(item)
      }
    }
    Ext.each(removeItems, function(removeItem) {
      this.remove(removeItem)
    }, this)    
    
    if (this.store && this.store.getCount()> 0) {  
      this.store.each(function(record, index) { 
        var pageID= record.get('id')
        var pressed= (me.currentPageRecord && me.currentPageRecord.get('id')== pageID)
        var tbButton= new Ext.Button({
          iconCls: 'ix-v0-16-table',
          cls: 'rg-page-tb-button',
          text: record.get('name'),
          pageID: record.get('id'),
          pressed: pressed,
          toggleGroup: 'app_page_toggle_group',
          toggleHandler: me.handlePageClick.createDelegate(me),
          listeners: {
            contextmenu: me.handlePageContextMenu.createDelegate(me)
          }
        })
        this.insert(this.leftItems.length + index, tbButton)
      }, this)        
    }
    this.doLayout()
  },
  handleCanDrop: function(dragSource, evt, data) {
    var buttonTargetEl= evt.getTarget('.rg-page-tb-button')
    if (!buttonTargetEl) {
      return false
    }
    if (data && data.record && data.record.data.className && data.record.data.type) {
      data.pageRecord= this.store.getById(Ext.getCmp(buttonTargetEl.id).pageID)      
      var tags= (Ext.isArray(data.record.get('page_tags'))  ? data.record.get('page_tags') : [])
      if (tags.indexOf(data.pageRecord.get('id')) >= 0) {
        return false
      }
      return true
    }
    return false
  },
  handleDrop: function(dragSource, evt, data) {
    var buttonTargetEl= evt.getTarget('.rg-page-tb-button')
    if (!buttonTargetEl) {
      return false
    }
    if (this.handleCanDrop(dragSource, evt, data)) {
      this.appView.appPanel.handleTagPageToApp(data.record, data.pageRecord)
      return true
    }
    return false
  },
  handlePageClick: function(button, state) {   
    var pageRecord= this.store.getById(button.pageID)    
    if (!pageRecord) {
      return    
    }
    this.currentPageRecord= (state ? pageRecord : null)
    this.appView.handlePageFilter(pageRecord, state)
  },  
  handleAllClick: function() {
    var buttons= this.findBy(function(item) {
      return (item.pageID ? true : false)
    })
    for(var i=0; i< buttons.length; i++) {
      buttons[i].toggle(false, true) 
    }
    this.currentPageRecord= null
    this.appView.handlePageFilter(null, false)
  },
  handlePageContextMenu: function(record, sourceEl, evt) {
    var me =this
    me.menuTargetRecord = record
    if (!this.menu) {
      this.menu = new Ext.menu.Menu({
        items: [{
          text: 'Rename Page',
          iconCls: 'ix-v0-16-table_edit',
          scope: this,
          handler: function(){
            this.appView.appPanel.handleRenamePage(this.menuTargetRecord)
          }
        }, {
          text: 'Remove Page',
          iconCls: 'ix-v0-16-tables_delete',
          scope: this,
          handler: function(){
            this.appView.appPanel.handleRemovePage(this.menuTargetRecord)
          }
        }, '-', {
          text: 'Show At Startup',
          xtype: 'menucheckitem',
          scope: this,
          listeners: {
            checkchange: function(item, checked){
              me.store.each(function(pageRecord) {
                if (pageRecord.get('id')== me.menuTargetRecord.get('id')) {
                  pageRecord.set('is_default', checked)
                } else {
                  pageRecord.set('is_default', false)                  
                }
              }, me)
              me.appView.appPanel.handleSetDefault(me.menuTargetRecord, checked)
            }
          }
        }],
        listeners: {
          beforeshow: function(menu) {
            var showAtStartupItem= menu.find('text', 'Show At Startup')[0]
            showAtStartupItem.setChecked(me.menuTargetRecord.get('is_default'), true)
          }
        }
      })
    }
    this.menu.showAt(evt.getXY())        
  },
  toggleDefaultPage: function() {
    this.store.each(function(pageRecord) {
      if (pageRecord.get('is_default')=== true) {
        var pageButton= this.findButtonForPageRecord(pageRecord)
        if (pageButton) {
          pageButton.toggle(true, false)
        } 
        return false
      }
    }, this)
  },
  toggleUp: function() {
    if (this.store.getCount()== 0) {
      return
    } 
    if (!this.currentPageRecord) {
      var firstPageRecord= this.store.getAt(0)
      var pageButton= this.findButtonForPageRecord(firstPageRecord)
      if (pageButton) {
        pageButton.toggle(true, false)
      } 
    } else {
      var indx= this.store.indexOf(this.currentPageRecord)
      if (indx== this.store.getCount() - 1) {
        this.handleAllClick()
      } else {
        var nextPageRecord= this.store.getAt(indx+1)
        var pageButton= this.findButtonForPageRecord(nextPageRecord)
        if (pageButton) {
          pageButton.toggle(true, false)
        }      
      }    
    }    
  },
  toggleDown: function() {
    if (this.store.getCount()== 0) {
      return
    }
    if (!this.currentPageRecord) {
      var lastPageRecord= this.store.getAt(this.store.getCount()-1)
      var pageButton= this.findButtonForPageRecord(lastPageRecord)
      if (pageButton) {
        pageButton.toggle(true, false)
      } 
    } else {
      var indx= this.store.indexOf(this.currentPageRecord)
      if (indx== 0) {
        this.handleAllClick()
      } else {
        var prevPageRecord= this.store.getAt(indx-1)
        var pageButton= this.findButtonForPageRecord(prevPageRecord)
        if (pageButton) {
          pageButton.toggle(true, false)
        }      
      }    
    }
  },
  findButtonForPageRecord: function(pageRecord) {
    var buttons= this.findBy(function(item) {
      return (item.pageID && item.pageID== pageRecord.get('id')  ? true : false)
    })
    return (buttons.length==0 ? null : buttons[0])
  },
  showHelp: function() {
    var buttons= this.findBy(function(item) {
      return (item.pageID ? true : false)
    })
    if (buttons.length== 0) {
      return
    }
    var button= buttons[0]
    if (!this.helpToolTip) {
      this.helpToolTip = new Ext.rx.AnchorToolTip({
        anchor :'top',
        baseCls :'x-tipyellow',
        title :'Launch Pad Pages',
        dismissDelay: 15000,
        html :'Uses Pages to organize RG Apps.'+
        '<P style="padding-top: 3px">Drag and drop Apps onto Page names to add an App to a Page.</P>'+
        '<P style="padding-top: 3px">Select a Page to view the Page.</P>'+
        '<P style="padding-top: 3px">Unselect Pages to view all Apps.</P>',
        adjustPosition : function(x, y) {
          return {
            x :x,
            y :y
          }
        }
      })
    }
    var box = button.getBox()
    var xy = [(box.x + 0.5 * box.width)- 12, (box.y + box.height)+8]
    this.helpToolTip.showAt(xy)
  }
})      
 
 
/*
 * Plugin which allows items to be dropped onto a toolbar
 */
RG.Loft.ButtonBarDroppable = Ext.extend(Object, {
  constructor: function(config) {
    Ext.applyIf(this, config, {
      ddGroup: 'rg-bb-dd'
    })
  },
  /**
   * Initializes the DropTarget on the toolbar
   */
  init: function(toolbar) {
    this.toolbar = toolbar      
    this.toolbar.on({
      scope: this,
      render: this.createDropTarget
    })
  },
  /**
   * Creates a drop target on the toolbar
   */
  createDropTarget: function() {        
    this.dropTarget = new Ext.dd.DropTarget(this.toolbar.getEl(), {
      ddGroup: this.ddGroup,
      notifyOver: this.notifyOver.createDelegate(this),
      notifyDrop: this.notifyDrop.createDelegate(this)
    });
  },   
  /**
   * The function a {@link Ext.dd.DragSource} calls continuously while it is being dragged over the target.
   * This method will be called on every mouse movement while the drag source is over the drop target.
   * This default implementation simply returns the dropAllowed config value.
   * @param {Ext.dd.DragSource} source The drag source that was dragged over this drop target
   * @param {Event} e The event
   * @param {Object} data An object containing arbitrary data supplied by the drag source
   * @return {String} status The CSS class that communicates the drop status back to the source so that the
   * underlying {@link Ext.dd.StatusProxy} can be updated
   */
  notifyOver: function(dragSource, event, data) {
    return this.isValidDrop(dragSource, event, data) ? this.dropTarget.dropAllowed : this.dropTarget.dropNotAllowed;
  },    
  /**
 * The function a {@link Ext.dd.DragSource} calls once to notify this drop target that the dragged item has
 * been dropped on it.  This method has no default implementation and returns false, so you must provide an
 * implementation that does something to process the drop event and returns true so that the drag source's
 * repair action does not run.
 * @param {Ext.dd.DragSource} source The drag source that was dragged over this drop target
 * @param {Event} e The event
 * @param {Object} data An object containing arbitrary data supplied by the drag source
 * @return {Boolean} True if the drop was valid, else false
 */  
  notifyDrop: function(dragSource, event, data) {
    return this.toolbar.handleDrop(dragSource, event, data)
  },
  /**
 * The function which returns whether the proposed drop is valid
 * @param {Ext.dd.DragSource} source The drag source that was dragged over this drop target
 * @param {Event} e The event
 * @param {Object} data An object containing arbitrary data supplied by the drag source
 * @return {Boolean} True if the drop was valid, else false
 */    
  isValidDrop: function(dragSource, event, data) {    
    return this.toolbar.handleCanDrop(dragSource, event, data)
  }  
});