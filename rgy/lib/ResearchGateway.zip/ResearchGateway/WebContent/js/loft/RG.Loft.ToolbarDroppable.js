/*
 * Plugin which allows items to be dropped onto a toolbar
 */
RG.Loft.ToolbarDroppable = Ext.extend(Object, {
  constructor: function(config) {
    Ext.applyIf(this, config, {
      ddGroup: 'rg-tb-dd'
    })
  },
  /**
   * Initializes the DropTarget on the toolbar
   */
  init: function(toolbar) {
    this.toolbar = toolbar      
    this.toolbar.on({
      scope: this,
      render: this.createDropTarget
    })
  },
  /**
   * Creates a drop target on the toolbar
   */
  createDropTarget: function() {    
    this.dropTarget = new Ext.dd.DropTarget(this.toolbar.getEl(), {
      ddGroup: this.ddGroup,
      notifyOver: this.notifyOver.createDelegate(this),
      notifyDrop: this.notifyDrop.createDelegate(this)
    });
  },   
  /**
   * The function a {@link Ext.dd.DragSource} calls continuously while it is being dragged over the target.
   * This method will be called on every mouse movement while the drag source is over the drop target.
   * This default implementation simply returns the dropAllowed config value.
   * @param {Ext.dd.DragSource} source The drag source that was dragged over this drop target
   * @param {Event} e The event
   * @param {Object} data An object containing arbitrary data supplied by the drag source
   * @return {String} status The CSS class that communicates the drop status back to the source so that the
   * underlying {@link Ext.dd.StatusProxy} can be updated
   */
  notifyOver: function(dragSource, event, data) {
    return this.isValidDrop(dragSource, event, data) ? this.dropTarget.dropAllowed : this.dropTarget.dropNotAllowed;
  },    
  /**
 * The function a {@link Ext.dd.DragSource} calls once to notify this drop target that the dragged item has
 * been dropped on it.  This method has no default implementation and returns false, so you must provide an
 * implementation that does something to process the drop event and returns true so that the drag source's
 * repair action does not run.
 * @param {Ext.dd.DragSource} source The drag source that was dragged over this drop target
 * @param {Event} e The event
 * @param {Object} data An object containing arbitrary data supplied by the drag source
 * @return {Boolean} True if the drop was valid, else false
 */  
  notifyDrop: function(dragSource, event, data) {
    return this.toolbar.handleCreateQuickItem(dragSource, event, data)
  },
  /**
 * The function which returns whether the proposed drop is valid
 * @param {Ext.dd.DragSource} source The drag source that was dragged over this drop target
 * @param {Event} e The event
 * @param {Object} data An object containing arbitrary data supplied by the drag source
 * @return {Boolean} True if the drop was valid, else false
 */    
  isValidDrop: function(dragSource, event, data) {
    return this.toolbar.handleCanDrop(dragSource, event, data)
  }  
});