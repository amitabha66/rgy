
/**
 * Creates an AppsPad 
 */
RG.Loft.AppPadPanel = Ext.extend(Ext.Panel, {
  initComponent : function() {
    var panel= this
    this.layout= 'fit'
    
    this.filterOptions= [
    "Compounds/Substances",
    "Projects",
    "People"      
    ]
    
    this.appView= new RG.Loft.AppPadView({
      store: panel.store,
      appPanel: this
    })
    this.items= this.appView
    
    //Create Toolbar    
    var toolbarItems= [{
      xtype: 'button',
      cls:'x-btn-text-icon',
      icon: ' http://rg-resources/ix/png/plain/16/add2.png',
      text: 'Add App to Launch Pad',
      handler: this.appView.handleAddApp.createDelegate(this.appView)
    }
    ,'-']
    
    toolbarItems.push({      
      text: 'Filter',
      tb: 'filter',
      iconCls: 'ix-v0-16-funnel',        
      menu: new RG.Loft.FilterMenu({
        appPanel: panel
      })
    })
    
    //Create sort menu item
    this.sortSplitButton= new Ext.Toolbar.SplitButton({
      text: 'Sort',
      direction: 'ASC',
      handler: this.appView.handleFieldSort.createDelegate(this.appView, [null, null]),
      icon: 'http://rg-resources/ix/png/plain/16/sort_az_ascending.png',        
      menu : {
        items: [{
          text: 'By Name', 
          icon: 'http://rg-resources/ix/png/plain/16/text_normal.png',        
          handler: this.appView.handleFieldSort.createDelegate(this.appView, ['name', null])
        }, {
          text: 'By Type', 
          icon: 'http://rg-resources/ix/png/plain/16/cubes.png',        
          handler: this.appView.handleFieldSort.createDelegate(this.appView, ['type', null])        
        }, {
          text: 'By Date Added', 
          icon: 'http://rg-resources/ix/png/plain/16/calendar.png',        
          handler: this.appView.handleFieldSort.createDelegate(this.appView, ['created', null])        
        }]
      }
    })    
    toolbarItems.push(this.sortSplitButton)
    
    toolbarItems.push({      
      text: 'Settings',
      tb: 'preferences',
      iconCls: 'ix-v0-16-gear_preferences',        
      menu: {
        items:[{
          text: 'Refresh',
          iconCls: 'ix-v0-16-refresh',        
          handler: panel.refresh.createDelegate(this)
        }, {
          iconCls: 'ix-v0-16-colorwheel',   
          text: 'Background Color',
          menu: new Ext.ux.menu.ColorMenu({        
            listeners: {
              beforeshow: function(menu) {
                if (panel.customStyle["background-color"]) {
                  menu.setColor(panel.customStyle["background-color"])
                  menu.initColor= panel.customStyle["background-color"].replace("#", "").toUpperCase()
                }
              },
              hide: function(menu) {
                try {
                  var color= menu.picker.hexaCmp.value
                  if (color) {
                    color= color.replace("#", "").toUpperCase()
                    if (menu.initColor && menu.initColor!= color && menu.inRequest!==true) {
                      menu.inRequest= true
                      Ext.Ajax.request({
                        url: '/aig/store.go?request=RGAPPS&loftrx=UPDATEPREFERENCES&color='+color,
                        scope: panel,
                        success: function(resp) { 
                          menu.inRequest= false
                          AIG.reopenLaunchPad(true)
                        },
                        failure: function() {
                          menu.inRequest= false
                        }
                      }, panel)      
                    }
                  }
                } catch(e) {}
              }
            }
          })
        }]
      }
    })    
    
    
    toolbarItems.push('-')
    toolbarItems.push({      
      text: 'Add Page',
      iconCls: 'ix-v0-16-table_add',        
      handler: this.handleCreatePage.createDelegate(this)
    })    
    
    this.tbar= new RG.Loft.ButtonBar({
      appView: this.appView,
      leftItems: toolbarItems,
      rightItems: [
      new RG.Form.SearchField({
        emptyText: 'Enter a keyword to filter apps',
        store: panel.store,
        width:200,
        searchOnKeyPress: true,
        listeners: {
          search: function(field, value) {
            if (hasLength(value)) { 
              panel.appView.textFilter= value
              panel.appView.handleFilter()
            } else {
              panel.appView.textFilter= null
              panel.appView.handleFilter()
            }
          },
          clear: function(field) {
            panel.appView.textFilter= null
            panel.appView.handleFilter()
          }
        }
      })  
      ]
    })
    
    this.on('render', function() {
      Ext.Ajax.request({
        url: '/aig/store.go?request=RGAPPS&loftrx=PREFERENCES',
        scope: panel,
        success: function(resp) {       
          try {
            var json= Ext.decode(resp.responseText)
            
            if (json && json.backgroundColor && !json.backgroundColor.startsWith('#')) {
              json.backgroundColor= '#'+json.backgroundColor
            }          
            var color= json.backgroundColor          
            var tile= (json.tileImage== null ? false : json.tileImage)
            var backgroundImg= json.backgroundImage
            var style= {}
            
            if (color) {
              style["background-color"]= color
            }
            if (backgroundImg) {
              var backgroundImg2= serializeRequest(backgroundImg, {
                width: panel.body.getWidth(),
                height: panel.body.getHeight(),
                no_cache: new UUID() + ""
              })
              style["background-image"]= "url("+backgroundImg2+")"
              style["background-repeat"]= (tile ? "repeat" : "no-repeat")
              if (!tile) {
                style["background-position"]= "center center"
              }
            }          
            panel.body.applyStyles(style)
            panel.customStyle= style
          } catch(e) {}
        }
      }, panel)
    })
    this.store.on('load', function() {
      if (this.store.getCount()== 0) {
        this.appView.showWelcomeDialog.defer(100, this.appView)      
      }
      this.appView.handleFilter()
      
      if (!this.loaded) {
        this.loaded= true
        this.getTopToolbar().toggleDefaultPage.defer(250, this.getTopToolbar()) 
      }
      
    }, this)
    RG.Loft.AppPadPanel.superclass.initComponent.call(this);
  },
  panelClosing: function() {
    this.appView.viewClosing()
  },
  resetLaunchPad: function(title, cb, scope) {
    this.appView.resetLaunchPad(title, cb, scope)
  },
  handleCreatePage: function() {
    var me= this
    new RG.Dialog.CreateLoftPageDialog({
      appRecords: me.appView.getStore().getRange(),
      handler: function(pageName, selectedAppRecords) {    
        Ext.Ajax.request({
          url: '/aig/store.go?request=RGAPPS',
          params: {
            loftrx: 'ADDPAGE',
            name: pageName,
            appIDs: RG.Record.join(selectedAppRecords, 'id', ',')
          },
          success: function(response) {                     
            me.getTopToolbar().reloadToolbarItems(function(tb) {
              var newPage= RG.decode(response, {})
              var newPageID= newPage.page_id
              if (newPageID) {
                var pageRecord= tb.store.getById(newPageID)
                var appIDs= newPage.app_ids
                if (Ext.isArray(appIDs)) {
                  for(var i=0; i< appIDs.length; i++) {
                    var appRecord= me.appView.getStore().getById(appIDs[i])
                    if (RG.isRecordType(appRecord, 'AppRecord')) {
                      var tags= (Ext.isArray(appRecord.get('page_tags'))  ? appRecord.get('page_tags') : [])               
                      if (tags.indexOf(pageRecord.get('id')) < 0) {
                        tags.push(pageRecord.get('id'))
                      }        
                      appRecord.set('page_tags', tags)
                    }
                  }
                }
                
                
                showInformationDialog('Created Page "' + pageRecord.get('name') + '"', 'Created New Page')
              }
              me.appView.handleFilter()  
              if (tb.store.getCount()==1) {
                me.getTopToolbar().showHelp()
              }
            }, this)
          }, 
          failure: function(options) {
            showResponseError(options, 'Unable To Create New Page')                     
          },
          scope: this
        })
      },
      scope: this 
    }).show()
    
  },
  handleRenamePage: function(pageRecord) {
    var me= this
    Ext.Msg.prompt('Rename Page', 'Enter new page name:', function(btn, text){      
      if (btn == 'ok'){       
        text= text.trim()
        if (text.length>20) {
          showErrorDialog('Name Too Long', 'Page name cannot be longer than 100 characters')
          return
        }
        Ext.Ajax.request({
          url: '/aig/store.go?request=RGAPPS',
          params: {
            loftrx: 'RENAMEPAGE',
            pageID: pageRecord.get('id'),
            name: text
          },
          success: function() {            
            me.getTopToolbar().reloadToolbarItems(function(tb) {
              showInformationDialog('Renamed Page "' + pageRecord.get('name') + '" to "'+ text+'"', 'Renamed Page')              
              me.appView.handleFilter()  
            }, this)
          }, 
          failure: function(options) {
            showResponseError(options, 'Unable To Create New Page')                     
          },
          scope: this
        })
      }
    }, this, false, pageRecord.get('name'))
  },
  handleRemovePage: function(pageRecord) {
    var me= this
    Ext.Msg.confirm('Remove Page', 'Remove Page "'+pageRecord.get('name')+'"?', function(btn){      
      if (btn == 'yes'){               
        Ext.Ajax.request({
          url: '/aig/store.go?request=RGAPPS',
          params: {
            pageID: pageRecord.get('id'),
            loftrx: 'REMOVEPAGE'
          },
          success: function() {              
            if (RG.compareRecords(me.appView.pageFilterRecord, pageRecord)) {
              me.appView.pageFilterRecord= null
            }             
            me.getTopToolbar().reloadToolbarItems(function() {
              showInformationDialog('Removed Page "' + pageRecord.get('name') + '"', 'Remove Page')              
              me.appView.handleFilter()                          
            }, this)
          }, 
          failure: function(options) {
            showResponseError(options, 'Unable To Remove Page')                     
          },
          scope: this
        })
      }
    }, this)
  },
  handleTagPageToApp: function(appRecord, pageRecord) {
    var me= this              
    Ext.Ajax.request({
      url: '/aig/store.go?request=RGAPPS',
      params: {
        pageID: pageRecord.get('id'),
        appID: appRecord.get('id'),
        loftrx: 'TAGPAGE'
      },
      success: function() {            
        var tags= (Ext.isArray(appRecord.get('page_tags'))  ? appRecord.get('page_tags') : [])               
        if (tags.indexOf(pageRecord.get('id')) < 0) {
          tags.push(pageRecord.get('id'))
        }        
        appRecord.set('page_tags', tags)
        me.getTopToolbar().reloadToolbarItems(function() {
          showInformationDialog('Added "'+appRecord.get('name') + '" to Page "' + pageRecord.get('name') + '"', 'Add App To Page')              
          me.appView.handleFilter()      
        }, this)
      }, 
      failure: function(options) {
        showResponseError(options, 'Unable To Update App')                     
      },
      scope: this
    })
  },
  handleUntagPageFromApp: function(appRecord) {
    var me= this              
    var pageRecord= this.appView.pageFilterRecord
    if (!RG.isRecordType(pageRecord, 'PageRecord')) {
      return
    }
    Ext.Msg.confirm('Remove App From Page', 'Remove "'+appRecord.get('name')+'" from page "'+pageRecord.get('name')+'"?', function(btn){      
      if (btn == 'yes'){     
        Ext.Ajax.request({
          url: '/aig/store.go?request=RGAPPS',
          params: {
            pageID: pageRecord.get('id'),
            appID: appRecord.get('id'),
            loftrx: 'UNTAGPAGE'
          },
          success: function() {            
            var tags= (Ext.isArray(appRecord.get('page_tags'))  ? appRecord.get('page_tags') : [])    
            tags.remove(pageRecord.get('id'))
            
            appRecord.set('page_tags', tags)
            me.getTopToolbar().reloadToolbarItems(function() {
              showInformationDialog('Removed "'+appRecord.get('name') + '" from Page "' + pageRecord.get('name') + '"', 'Remove App From Page')              
              me.appView.handleFilter()      
            }, this)
          }, 
          failure: function(options) {
            showResponseError(options, 'Unable To Update App')                     
          },
          scope: this
        })
      }
    }, this)
  },
  handleSetDefault: function(pageRecord, setDefault) {
    var me = this
    Ext.Ajax.request({
      url: '/aig/store.go?request=RGAPPS',
      params: {
        pageID: pageRecord.get('id'),
        setDefaultView: (setDefault ? 1 : 0),
        loftrx: 'SETDEFAULTPAGE'
      },
      success: function() {
      }, 
      failure: function(options) {
        showResponseError(options, 'Unable To Update Page')
      },
      scope: this
    })
  },
  setViewFilter: function(isFiltered) {
    var filterToolbarButton= this.getTopToolbar().find('tb', 'filter')[0]
    filterToolbarButton.setIconClass((isFiltered ? 'x-rg-16-funnel_red' : 'ix-v0-16-funnel'))
    
    if (isFiltered) {
      var appRecordCollection= this.store.snapshot || this.store.data
      var total= appRecordCollection.length
      filterToolbarButton.setText(String.format('Filter (Showing {0} of {1})', this.store.data.length, total))
    } else {
      filterToolbarButton.setText('Filter')
    }
  },
  refresh: function() {    
    this.appView.saveCurrentSort(function(){
      this.store.reload()
      var rgToolbar= Ext.getCmp('aig_main-toptoolbar')
      if (rgToolbar && rgToolbar.rendered) {
        rgToolbar.reloadLoftItems()
      }
    }, this)
  }
})


RG.Loft.AppPadView = Ext.extend(Ext.DataView, {
  dropAllowed: Ext.dd.DragZone.prototype.dropAllowed,
  dropNotAllowed: Ext.dd.DragZone.prototype.dropNotAllowed,
  tpl: new Ext.XTemplate(
    '<tpl for=".">',
    '<div class="rg-apps">',
    '<table class="rg-apps" height= "100%" align="center" ><tr>',
    '<td  width="100%" height= "100%"  align="center" >',
    
    '<tpl if="hasLength(className)">',
    //'<span style="position:relative">',
    '<span class="{className}" style="width:100%;height:50px;',
    ' background-position: center center !important; ',
    ' background-repeat: no-repeat">',
    //'<img class="ix-v0-24-star_yellow" style= "position:absolute;top:0px;right:10px;z-index:50;width:24px;height:24px"  src="/aig/img/s.gif"/>',
    //'</span>',
    '</tpl>',
    
    '<tpl if="!hasLength(className)">',
    '<div style="width:100%;height:30px;',
    'background-image: url(/aig/img/base_images/document.png); ',
    ' background-position: center center; ',
    ' background-repeat: no-repeat">',
    '</tpl>',
    
    '<img src="/aig/img/s.gif">',
    '</span>',
    
    '</td>',
    '</tr><tr><td width="100%" align="center" class="rg-apps">',
    '<span class="rg-apps" >',
    '{[RG.Loft.formatAppName(values.name)]}',
    '</span>',
    '</td></tr></table>',
    '</div>',
    '</tpl>'  
    ),
  cls: 'rg-apps',
  itemSelector: 'div.rg-apps',
  overClass: 'rg-apps-hover',  
  id: 'rg-app',        
  singleSelect: true,
  multiSelect: true,
  autoScroll: true,
  recordClickPolicy: new RG.RecordClickPolicy(),
  
  initComponent : function() {
    var panel= this
    
    panel.on('mouseenter', function(view, index, node, evt) {
      panel.handleNodeOverOut(node, true, evt)
      panel.overNode= node
    })    
    panel.on('mouseleave', function(view, index, node, evt) {
      panel.handleNodeOverOut(node, false, evt)
      panel.overNode= null
    })   
    panel.on('click', function(view, index, node, evt) {
      var record= view.getRecord(node)
      if (record) {
        panel.handleNodeClick(record, node, evt)
      }
    })       
    panel.on('contextmenu', function(view, index, node, evt) {
      evt.preventDefault();
      evt.stopPropagation();
      var record= view.getRecord(node)
      if (record) {
        panel.handleNodeContextmenu(record, node, evt)
      }
    })       
    panel.on('selectionchange', panel.handleSelectionChange.createDelegate(panel))
    
    RG.Loft.AppPadView.superclass.initComponent.call(this);
  },
  // private
  afterRender: function(){
    Ext.DataView.prototype.afterRender.call(this);    
    var v= this
    this.tip = new Ext.rx.AnchorToolTip({
      target: this.getEl(),
      delegate: this.itemSelector,
      trackMouse: false,
      showDelay: 1500,
      quickShowInterval: 0,
      renderTo: document.body,
      autoHide: true,
      closable: false,
      //bodyCssClass: 'rg-apps-tt',
      anchor: 'left',
      tpl: new Ext.XTemplate(
        '<tpl for=".">',
        '<table cellspacing="0" class="rg-apps-tt">',
        '<tr>',
        '<th width="32"><div class="{className}" ><img width="32" height="32" src="/aig/img/s.gif"/></div></th>',
        '<th> <span>{[fm.htmlEncode(values.name)]}</span></th>',
        '</tr><tr>',
        '<td colspan="2">{[fm.htmlEncode(values.description)]}</td>',
        '</tr>',
        '</table>',
        '</tpl>'  
        ),      
      listeners: {
        beforeshow: function(){
          if (v.isDragging=== true || (v.menu && v.menu.isVisible())) {
            return false
          }
          try {
            var record = this.getRecord(this.tip.triggerElement)
            if (record) {
              var ttData= {
                className: RG.Icon.Utils.getSizedIconClass(record.data.className, 32),
                name: record.data.name,
                description: record.data.description
              }              
              this.tip.tpl.overwrite(this.tip.body, ttData)
              return true
            }
          } catch (e) {
          }
          return false
        },
        scope: this
      }
    })    
    
    new Ext.KeyMap(this.getEl(), [{
      key: Ext.EventObject.RETURN,
      fn: function(key, evt) {
        if (v.overNode) {
          var r= this.getRecord(v.overNode)
          this.appLaunchHandler(r)
        }
      },
      scope: v
    },{
      key: Ext.EventObject.DELETE,
      fn: function(key, evt) {
        if (v.overNode) {
          var r= this.getRecord(v.overNode)
          this.handleRemoveApp(r)
        }
      },
      scope: v
    }, {
      key: [Ext.EventObject.RIGHT, Ext.EventObject.UP],
      fn: function(key, evt) {
        v.appPanel.getTopToolbar().toggleUp()
      },
      scope: v
    }, {
      key: [Ext.EventObject.LEFT, Ext.EventObject.DOWN],
      fn: function(key, evt) {
        v.appPanel.getTopToolbar().toggleDown()
      },
      scope: v
    }]);
    
    //Initialize the Dragzone      
    v.dragZone = new Ext.dd.DragZone(v.getEl(), {
      onStartDrag: function(x, y) {
        v.isDragging= true
        Ext.dd.DragZone.prototype.onStartDrag.call(this, x, y)
      },
      endDrag: function(evt) {
        v.isDragging= false
        Ext.dd.DragZone.prototype.endDrag.call(this, evt)
      },
      //      On receipt of a mousedown event, see if it is within a draggable element.
      //      Return a drag data object if so. The data object can contain arbitrary application
      //      data, but it should also contain a DOM element in the ddel property to provide
      //      a proxy to drag.
      getDragData: function(e) {
        var sourceNode = e.getTarget(v.itemSelector, 10);
        if (sourceNode) {
          if (!this.ddel) {          
            this.ddel = document.createElement('div')
            this.ddel.className = 'x-rg-apps-dd-wrap'
          }
          var record= v.getRecord(sourceNode)
          if (record && record.data) {    
            var sourceEl= Ext.Element.fly(sourceNode)
            var tableNode= sourceEl.child('table', true)
            
            var width= Ext.Element.fly(tableNode).getWidth()
            var height= Ext.Element.fly(tableNode).getHeight()
            var className= record.data.className
            
            //var ddNode = tableNode.cloneNode(true);
            //ddNode.id = Ext.id();
            this.ddel.innerHTML = Ext.DomHelper.markup({
              tag :'table',
              'class': 'rg-apps-dd',
              unselectable :"on",
              style :"white-space: nowrap !important;background-color: #EEEEEE",
              width: width,
              height: height,
              children :[{
                tag :'tr',
                children: [{
                  tag: 'td',
                  align: 'center',
                  children: [{
                    tag: 'div',
                    "class": className,
                    style: 'width:100%;height:50px;background-position: 50% 50%!important;background-repeat: no-repeat',
                    children: [{
                      tag: 'img',
                      src: '/aig/img/s.gif'
                    }]
                  }]
                }]
              },{
                tag :'tr',
                children: [{
                  tag: 'td',
                  align: 'center',
                  children: [{
                    tag: 'span',
                    html: Ext.util.Format.htmlEncode(record.data.name)
                  }]
                }]
              }]
            })
            return v.dragData = {
              sourceEl: sourceEl,
              repairXY: Ext.fly(sourceNode).getXY(),
              ddel: this.ddel,
              record: v.getRecord(sourceNode)
            }
          }
        }
      },
      //      Provide coordinates for the proxy to slide back to on failed drag.
      //      This is the original XY coordinates of the draggable element.
      getRepairXY: function() {
        return this.dragData.repairXY;
      }
    });
    //Initialize the Dropzone      
    v.dropZone = new Ext.dd.DropZone(v.getEl(), {
      
      //      If the mouse is over a target node, return that node. This is
      //      provided as the "target" parameter in all "onNodeXXXX" node event handling functions
      getTargetFromEvent: function(e) {
        return e.getTarget('.rg-apps');
      },
      
      //      On entry into a target node, highlight that node.
      onNodeEnter : function(target, dd, e, data){ 
        Ext.fly(target).addClass('rg-apps-hover');                
      },
      
      //      On exit from a target node, unhighlight that node.
      onNodeOut : function(target, dd, e, data){ 
        Ext.fly(target).removeClass('rg-apps-hover');
        v.getSortDropPositionImage().setVisible(false)           
      },
      /**
     * Handle the node over events whose logic depends on what the source of the 
     * DnD operation originates. This is determined by presence of a source objects 
     * in the DnD data object
     */
      onNodeOver : function(target, dd, e, data){ 
        v.getSortDropPositionImage().setVisible(false)  
        //DnD from the main toolbar        
        if (data.toolbar) {
          return v.dropAllowed;
        }
        //DnD from a Searches (service) grid
        if (data.servicegrid) {
          return v.dropAllowed;
        }
        //DnD from the Favorites grid
        if (data.favorites && RG.isRecordType(data.record, 'FolderItemsRecord')) {
          if (data.record.data.type== 'FOLDER') {
            return v.dropNotAllowed;
          }
          return v.dropAllowed;
        }        
        //Everything else- DnD from within the LaunchPad
        data.target= null
        var targetNodeAndDir= this.findTargetNodeOfDrop(e)
        if (targetNodeAndDir) {                    
          var targetTableNode= Ext.Element.fly(targetNodeAndDir.node).child('table')                  
          var targetRecord= v.getRecord(targetNodeAndDir.node)  
          if (targetRecord && data.record.id!= targetRecord.id) {            
            data.target= targetNodeAndDir           
            if (targetNodeAndDir.dir== 'left') {
              v.getSortDropPositionImage().setXY([targetTableNode.getX() - 8, targetTableNode.getY()+2])              
            } else {             
              v.getSortDropPositionImage().setXY([targetTableNode.getX() + targetTableNode.getWidth() + 8, targetTableNode.getY()+2])  
            }
            v.getSortDropPositionImage().setHeight(targetTableNode.getHeight() - 4)
            v.getSortDropPositionImage().setVisible(true)
            return v.dropAllowed;
          }
        }
        return v.dropNotAllowed;
      },
      /**
     * Finds the potential target of a Sort drop.
     * for each node, it looks to see if it is in the 
     * leading (left) or trailing (right) rectangle of the
     * node rectangle. If it finds a match, it returns an object with
     * fields: 
     * {
     *   node: node
     *   dir: <left | right>
     * }
     * For instance:
     * 
     *     <left>     node     <right>
     *            +---------+
     *            |    :    | 
     *      |<--  | -->:<-- | -->|
     *            |    :    |
     *            +---------+
     *    
     */
      findTargetNodeOfDrop: function(evt) {
        var x= evt.getPageX()
        var y= evt.getPageY()
        var nodes= v.getNodes()
        for(var i=0; i< nodes.length; i++) {
          var nodeEl= Ext.fly(nodes[i])
          var nodeBox= nodeEl.getBox()
          
          var lx= nodeBox.x - nodeBox.width/2
          var rx= nodeBox.x + nodeBox.width/2
          var ry= nodeBox.y
          var rw= nodeBox.width
          var rh= nodeBox.height
          
          if (RG.Geometry.isInRectangle(lx, ry, rw, rh, x, y)) {
            return {
              node: nodes[i],
              dir: 'left'            
            }
          }
          if (RG.Geometry.isInRectangle(rx, ry, rw, rh, x, y)) {
            return {
              node: nodes[i],
              dir: 'right'            
            }
          }
        }
        return null        
      },
      /**
     * Handle the node drop events whose logic depends on what the source of the 
     * DnD operation originates. This is determined by presence of a source objects 
     * in the DnD data object
     */
      onNodeDrop : function(target, dd, e, data){
        v.getSortDropPositionImage().setVisible(false)            
        //DnD from the main toolbar        
        if (data.toolbar) {          
          return data.toolbar.handleRemoveLoftItem(data.record);
        }
        //DnD from a Searches (service) grid
        if (data.servicegrid) {
          return v.handleAddApp(data.record);
        }
        //DnD from the Favorites grid
        if (data.favorites && RG.isRecordType(data.record, 'FolderItemsRecord')) {
          if (data.record.data.type== 'FOLDER') {
            return false
          }
          return v.handleAddApp(data.record);
        }               
        //Everything else- DnD from within the LaunchPad
        if (!data.target) {
          return false
        }
        var targetRecord= v.getRecord(data.target.node)
        if (!targetRecord) {
          return false
        }
        data.target.record= targetRecord
        return v.handleDropSort(data.record, data.target)        
      }
    })    
    v.dragZone.addToGroup('rg-tb-dd');
    v.dropZone.addToGroup('rg-tb-dd');
    v.dropZone.addToGroup('favFolderDDGroup');    
  },
  handleSelectionChange: function() {    
    var nodes= this.getNodes()
    for(var i= 0; i< nodes.length; i++) {
      var tableEl= Ext.Element.fly(nodes[i]).child('table')
      if (this.isSelected(nodes[i])) {
        tableEl.removeClass('rg-apps-hover-ff')                      
        tableEl.addClass('rg-apps-selected-ff')
      } else {
        tableEl.removeClass('rg-apps-selected-ff')                      
      }
    }
  },
  handleNodeOverOut: function(node, isOver, evt) {
    if (this.isDragging=== true) {
      return
    }
    var sourceNode = evt.getTarget(this.itemSelector, 10);    
    if (!this.isSelected(node)) {
      var sourceTableNode= Ext.Element.fly(sourceNode).child('table')                  
      if (isOver) {
        sourceTableNode.addClass('rg-apps-hover-ff')
      } else {
        sourceTableNode.removeClass('rg-apps-hover-ff')                  
      }
    }
  },
  getSortDropPositionImage: function() {    
    var id= this.getId()+"_dropsort"
    var node= Ext.get(id)
    if (!node) {
      this.getEl().createChild({
        tag: 'div', 
        id: id,
        "class": 'rg-apps-dropsortline'
      })
    }
    return Ext.fly(id)      
  },
  /**
 * Handles the sorting of the records following a drop
 * @param sourceRecord The records whose position is being reset
 * @param targetData The data for where in the record set the new position
 * of the source record will be. The fields are
 *   record: the target record for the new position
 *   dir: left or right i.e. put the new position of the source record before or after
 *   the target
 *   node: the target node object
 */
  handleDropSort: function(sourceRecord, targetData) {
    if (!targetData) {
      return false
    }
    var targetRecord= targetData.record
    if (sourceRecord.id== targetRecord.id) {
      return false
    }
    // Get current ordered records as IDs in an array 
    // excluding the source record and
    // identifing the target record position
    var records = this.store.getRange()
    var order= []
    var targetPos= -1
    for(var i=0; i< records.length; i++) {
      var id= records[i].id
      if (id!= sourceRecord.id) {
        order.push(records[i].id)        
        if (id== targetRecord.id) {
          targetPos= order.length-1
        }
      }
    }   
    //Insert the source record ID into the order array
    // This can be to left (before) or to the right (after) the target
    // If at the beginning or end of the array, do an unshift or push, resp.
    // Otherwise do a splice
    var newIndex= targetPos + (targetData.dir== 'left' ? 0 : 1)
    if (newIndex <=0) {
      order.unshift(sourceRecord.id)
    } else if (newIndex>= order.length) {
      order.push(sourceRecord.id)
    } else {
      order.splice(newIndex, 0, sourceRecord.id)
    }
    
    //Reset the order fields according to their updating positions 
    // in the order array
    for(var i=0; i< order.length; i++) {
      var record= this.store.getById(order[i])
      record.data.order= i      
    }
    //Re-sort the store, refresh the view, and update the sort toolbar button
    this.store.sortData()
    this.refresh()  
    this.handleSwapsort('ASC')
    return true
  },
  handleFieldSort: function(fieldName, direction) {
    var records = this.store.getRange()
    if (!fieldName) {
      for(var i=0; i< records.length; i++) {
        records[i].data.order= records.length- i -1
      }
      direction= (this.ownerCt.sortSplitButton.direction== 'DESC' ? 'ASC' : 'DESC')
    } else {  
      var sortRecords= new Ext.util.MixedCollection()
      sortRecords.addAll(records)      
      direction = direction || 'ASC';
      var st = this.store.fields.get(fieldName).sortType;
      var fn = function(r1, r2){
        var v1 = st(r1.data[fieldName])
        var v2 = st(r2.data[fieldName]);
        return v1 > v2 ? 1 : (v1 < v2 ? -1 : 0);
      };
      sortRecords.sort(direction, fn)    
      for(var i=0; i< sortRecords.getCount(); i++) {
        var id= sortRecords.itemAt(i).id
        this.store.getById(id).data.order= i
      }
    }
    this.store.sortData()
    this.refresh()    
    this.handleSwapsort(direction)
  },
  handleSwapsort: function(direction) {    
    this.ownerCt.sortSplitButton.direction= direction
    if (this.ownerCt.sortSplitButton.direction== 'ASC') {
      this.ownerCt.sortSplitButton.setIcon('http://rg-resources/ix/png/plain/16/sort_az_ascending.png')
    } else {
      this.ownerCt.sortSplitButton.setIcon('http://rg-resources/ix/png/plain/16/sort_az_descending.png')
    }
  },
  viewClosing: function() {
    this.saveCurrentSort()
  },
  saveCurrentSort: function(cb, scope) {
    var records = this.store.getRange()
    var order= {}
    for(var i=0; i< records.length; i++) {
      var id= records[i].id
      order[id]= i
    }   
    Ext.Ajax.request({
      url: '/aig/store.go?request=RGAPPS&loftrx=UPDATESORT',
      params: {
        sort: Ext.encode(order)
      }, 
      success: function() {
        if (Ext.isFunction(cb)) {
          cb.call(scope)
        }
      },
      failure: function(options) {
        showResponseError(options, 'Unable to save your Launch Pad')
      }
    })    
  },
  handleNodeClick: function(record, node, evt) {
    evt.preventDefault()
    evt.stopPropagation()
    
    //Check the click policy- this avoids double-clicking and getting 2 windows of the same app!!
    if (this.recordClickPolicy.validate(record)) {
      this.appLaunchHandler(record)
    }
  }, 
  handleNodeContextmenu: function(record, node, evt) {    
    this.menuTargetRecord = record
    if (!this.menu) {
      var me= this
      this.menu = new Ext.menu.Menu({
        items: [{
          key: 'remove_menuitem',
          text: 'Remove',
          iconCls: 'ix-v0-16-delete2',
          scope: this,
          handler: function(){
            this.handleRemoveApp(this.menuTargetRecord)
          }
        }],
        listeners: {
          beforeshow: function(menu) {
            var removeItem= menu.find('key', 'remove_menuitem')[0]
            if (RG.isRecordType(me.pageFilterRecord, 'PageRecord')) {
              removeItem.setIconClass('ix-v0-16-table_delete')
              removeItem.setText('Remove App From Page "'+me.pageFilterRecord.get('name')+'"')            
            } else {
              removeItem.setIconClass('ix-v0-16-delete2')
              removeItem.setText('Remove App')            
            }
          }
        }
      })
    }
    this.menu.showAt(evt.getXY())
  },
  appLaunchHandler: function(appRecord) {
    if (this.isDragging=== true) {
      return
    }        
    var panel= this
    var panelWin= panel.ownerCt.win
    if (appRecord) {
      var appLauncher= new RG.Loft.AppLauncher({
        appRecord: appRecord,
        launchPad: panelWin,
        showResources: true,
        listeners: {
          launch: function(launcher, record, launched) {            
            if (!launched) {
              return
            }
            switch(record.data.type) {
              case "FAVORITES_TOOL":
                break;
              case "PREFERENCES_TOOL":
                //panelWin.close()
                break;
              case "IMPORT_TABLE_TOOL":
                break
              case "DOCUMENTS_TOOL":
                break
              case "EXPLORE_TOOL":
                //panelWin.close()
                break;
              case "VQT_TOOL":
                AIG.closeLaunchPad()
                break;
              case "LISTS_TOOL":
                AIG.closeLaunchPad()
                break;
              case "PROJECT_VIEW_TOOL":
                break;
              case "FAVORITE":
                break;
              case "SERVICE":
                break;
            }
          },
          beforeservicelaunch: function(record, serviceValues) {
          }
        }
      }) 
      appLauncher.launch()
    }
  },
  handleAddApp: function(record, cb, scope) {
    var me= this
    
    var tagNewAppToCurrentPage= function(appRecords, newAppData) {
      var newAppID= (Ext.isObject(newAppData) ? newAppData.id : newAppData+"")
      if (RG.isRecordType(me.pageFilterRecord, 'PageRecord')) {        
        for(var i=0; i< appRecords.length; i++) {
          var appID= appRecords[i].get('id')
          if (appID== newAppID) {
            me.appPanel.handleTagPageToApp(appRecords[i], me.pageFilterRecord)
          }
        }
      }
    }
    
    if (RG.isRecordType(record, 'ServiceRecord')) {
      this.showUpdateProgress()
      this.saveCurrentSort(function() {
        var app= {
          name: record.data.Name,
          serviceKey: record.data.ServiceKey,
          type: 'SERVICE'
        }
        Ext.Ajax.request({
          url: '/aig/store.go?request=RGAPPS&loftrx=ADDAPP',
          params: {
            app: Ext.encode(app)
          },
          success: function(response) {
            var newAppData= RG.decode(response)
            this.store.reload({
              callback: function(r) {
                tagNewAppToCurrentPage.call(me, r, newAppData)
              }
            })
            me.handleFilter()    
            Ext.Msg.hide()              
            if (Ext.isFunction(cb)) {
              cb.call(scope, true)
            }
          }, 
          failure: function(options) {     
            Ext.Msg.hide()              
            if (Ext.isFunction(cb)) {
              cb.call(scope, false)
            }
            showResponseError(options, 'Unable To Update your Launch Pad')                     
          },
          scope: this
        })
      }, this)
    } else if (RG.isRecordType(record, 'FolderItemsRecord')) {
      this.showUpdateProgress()
      this.saveCurrentSort(function() {
        var app= {
          name: record.data.Name,
          folderItemID: record.data.id,
          type: 'FAVORITE'
        }
        Ext.Ajax.request({
          url: '/aig/store.go?request=RGAPPS&loftrx=ADDAPP',
          params: {
            app: Ext.encode(app)
          },
          success: function(response) {
            var newAppData= RG.decode(response)
            this.store.reload({
              callback: function(r) {
                tagNewAppToCurrentPage.call(me, r, newAppData)
              }
            })
            Ext.Msg.hide()              
            if (Ext.isFunction(cb)) {
              cb.call(scope, true)
            }
          }, 
          failure: function(options) {    
            Ext.Msg.hide()              
            if (Ext.isFunction(cb)) {
              cb.call(scope, false)
            } 
            showResponseError(options, 'Unable To Update your Launch Pad')         
          },
          scope: this
        })
      }, this)
    } else if (RG.isRecordType(record, 'AppRecord')) {
      this.showUpdateProgress()
      this.saveCurrentSort(function() {
        var app= {
          record: record.data,
          type: record.data.type
        }
        Ext.Ajax.request({
          url: '/aig/store.go?request=RGAPPS&loftrx=ADDAPP',
          params: {
            app: Ext.encode(app)
          },
          success: function(response) {
            var newAppData= RG.decode(response)
            this.store.reload({
              callback: function(r) {
                tagNewAppToCurrentPage.call(me, r, newAppData)
              }
            })
            Ext.Msg.hide()              
            if (Ext.isFunction(cb)) {
              cb.call(scope, true)
            }
          }, 
          failure: function(options) {   
            Ext.Msg.hide()              
            if (Ext.isFunction(cb)) {
              cb.call(scope, false)
            }
            showResponseError(options, 'Unable To Update your Launch Pad')          
          },
          scope: this
        })
      }, this)
    } else {
      new RG.Loft.AppSelector({
        modal: true,
        appPanel: this
      }).show()
    }
  },
  handleRemoveApp: function(record, cb, scope) {     
    var view= this
    if (!RG.isRecordType(record, 'AppRecord')) {
      return
    }    
    if (RG.isRecordType(this.pageFilterRecord, 'PageRecord')) {
      this.appPanel.handleUntagPageFromApp(record)
      return
    }
    var rgToolbar= Ext.getCmp('aig_main-toptoolbar')
    Ext.Msg.show({
      title:'Remove App '+record.data.name+'?',
      msg: 'Are you sure you want to remove this from your Launch Pad?' +
      (rgToolbar.hasApp(record) ? '<BR>This will also remove this item from the RG Toolbar.' : ''),
      buttons: Ext.Msg.YESNO,
      fn: function(buttonId) {
        if (buttonId!= 'yes') {
          return
        }
        view.showUpdateProgress()
        
        view.saveCurrentSort(function() {
          Ext.Ajax.request({
            url: '/aig/store.go?request=RGAPPS&loftrx=REMOVEAPP',
            params: {
              appID: record.data.id
            },
            success: function() {
              view.store.reload()
              rgToolbar.handleRemoveLoftItem(record)
              //rgToolbar.reloadLoftItems()
              view.handleFilter()
              Ext.Msg.hide()
              if (Ext.isFunction(cb)) {
                cb.call(scope, true)
              }              
            }, 
            failure: function(options) {
              Ext.Msg.hide()
              if (Ext.isFunction(cb)) {
                cb.call(scope, false)
              }              
              showResponseError(options, 'Unable to remove app to your Launch Pad')
            },
            scope: view
          })
        }, view)             
      },
      icon: Ext.MessageBox.QUESTION
    });
  
  },
  showWelcomeDialog: function() {
    if (!this.welcomeDialog) {
      this.welcomeDialog= new RG.Dialog.WelcomeDialog({
        view: this,
        rgToolbar: Ext.getCmp('aig_main-toptoolbar')
      })
    }
    this.welcomeDialog.show()
  },
  resetLaunchPad: function(title, cb, scope) {     
    var view= this    
    var rgToolbar= Ext.getCmp('aig_main-toptoolbar')
    
    if (!this.roleselectDialog) {    
      this.roleselectDialog= new Ext.Window({
        title: title || 'Reset Launch Pad Apps',
        iconCls :'ix-v0-16-colors',
        resizable:false,
        constrain:true,
        constrainHeader:true,
        minimizable : false,
        maximizable : false,
        modal: true,
        shim:true,
        buttonAlign:"center",
        width:400,
        height:155,
        minHeight: 80,
        plain:true,
        footer:true,
        closable:true,
        border: false,
        closeAction: 'hide',
        items: {
          xtype: 'form',
          labelAlign: 'top',
          frame: true,
          items: [new Ext.form.ComboBox({
            fieldLabel: 'Please Select Apps',
            store: new Ext.data.Store({
              autoLoad :true,
              url: '/aig/store.go?request=rgapps',
              baseParams: {
                responseFormat: 'JSON',
                loftrx: 'APPROLES'
              },
              reader :new Ext.data.JsonReader({
                root :"roles"          
              }, Ext.data.Record.create([
              {
                name: 'role'
              }
              ]))
            }),
            width: 300,
            displayField: 'role',
            valueField: 'role',
            typeAhead: true,
            forceSelection: true,
            editable: false,
            triggerAction: 'all',
            value:'Standard',
            selectOnFocus:true,
            tpl: new Ext.XTemplate('<tpl for=".">', '<div class="x-combo-list-item">', 
              '<img src="http://rg-resources/ix/png/plain/24/cubes.png" align="absmiddle" border=0 style="margin-right:3px">',
              '{role} Apps</div>', 
              '</tpl>')
          }), {
            xtype: 'label',
            text: 'Note: This operation will remove ALL apps from your Launch Pad and reset your apps to the selected set.'
          }
          ]
        },
        fbar: new Ext.Toolbar({
          enableOverflow: false,
          items: [{
            text: 'OK',
            handler: function() {
              var role= view.roleselectDialog.findByType('combo')[0].getValue()
              view.roleselectDialog.hide()
              view.showUpdateProgress()
              
              Ext.Ajax.request({
                url: '/aig/store.go?request=RGAPPS&loftrx=RESETAPPS',
                params: {
                  role: role
                },
                success: function() {
                  view.store.reload()
                  rgToolbar.reloadLoftItems()
                  view.handleFilter()
                  Ext.Msg.hide()                  
                  if (Ext.isFunction(cb)) {
                    cb.call(scope, true)
                  }              
                }, 
                failure: function(options) {
                  Ext.Msg.hide()                  
                  if (Ext.isFunction(cb)) {
                    cb.call(scope, false)
                  }              
                  showResponseError(options, 'Unable to reset your Launch Pad')
                },
                scope: view
              })
            }
          }, {
            text: 'Cancel',
            handler: function() {
              view.roleselectDialog.hide()
            }
          }]
        })
      })
    }
    this.roleselectDialog.show()      
  },
  handleFilter: function(filter) {
    var panel= this
    panel.isFiltered= false
    if (Ext.isObject(filter)) {
      panel.currentFilter= filter
    }
    var pageFilterRecord= this.pageFilterRecord
    var textFilterFn= null
    
    if (Ext.isString(this.textFilter)) {
      var nameFn= this.getStore().createFilterFn('name', this.textFilter, true, false)
      var descFn= this.getStore().createFilterFn('description', this.textFilter, true, false)
      textFilterFn= function(r) {
        return nameFn.call(null, r) || descFn.call(null, r)
      }
    }
    
    this.getStore().filterBy(function(appRecord) {
      if (RG.isRecordType(pageFilterRecord, 'PageRecord')) {
        var pageID= pageFilterRecord.get('id')
        var appPageTags= appRecord.get('page_tags')
        if (!Ext.isArray(appPageTags)) {
          panel.isFiltered= true
          return false
        }
        if (appPageTags.indexOf(pageID)< 0) {
          panel.isFiltered= true
          return false
        }
      }
      
      if (Ext.isFunction(textFilterFn)) {
        var textMatch= textFilterFn.call(this, appRecord)
        if (!textMatch) {
          panel.isFiltered= true
          return false
        }        
      }
      
      if (panel.currentFilter) {
        var filterSortCategory= appRecord.data.filterSortCategory.split(".")
        var type= filterSortCategory[0]
        var category= filterSortCategory[1]          
        if (Ext.isBoolean(panel.currentFilter[type][category])) {
          if (!panel.currentFilter[type][category]) {
            panel.isFiltered= true
          }
          return panel.currentFilter[type][category]
        }
      }
      return true
    }, this)
    this.appPanel.setViewFilter(panel.isFiltered)
  },
  handlePageFilter: function(pageRecord, state) {
    if (state) {
      this.pageFilterRecord= pageRecord
    } else {
      this.pageFilterRecord= null      
    }
    this.handleFilter()
  },  
  showUpdateProgress: function(title) {
    RG.Dialog.showProgressDialog((title|| 'Updating Launch Pad, please wait...'), 'Updating...')
  }  
});

RG.Loft.formatAppName= function(name) {
  var lines= name.wrap(14).split(/\n/)
  if (lines.length== 1) {
    return Ext.util.Format.htmlEncode(lines[0])
  }
  if (lines.length==2) {
    return Ext.util.Format.htmlEncode(lines[0]) + "<BR/>"  + Ext.util.Format.htmlEncode(lines[1])
  } else {
    var line1= Ext.util.Format.htmlEncode(lines.shift())
    var otherLines= Ext.util.Format.ellipsis(lines.join(' '), 14)    
    return line1+"<BR/>"+Ext.util.Format.htmlEncode(otherLines)
  }
}

RG.Loft.FilterMenu = Ext.extend(Ext.menu.Menu, {  
  initComponent: function() { 
    this.filterState= {
      TOOL: {}, 
      SEARCH: {}, 
      FAVORITE: {}
    }
    this.on('show', this.onMenuLoad, this);
    
    this.items= [{
      text: 'Select All/None',
      iconCls: 'ix-v0-16-check',           
      hideOnClick: false,   
      type: 'ALL',
      handler: this.handleSelectAll.createDelegate(this),
      scope: this        
    },      
    (this.toolsMenu= new Ext.menu.Item({
      text: 'Tools',
      iconCls: 'ix-v0-16-windows',
      menu: new Ext.menu.Menu()
    })),
    (this.searchesMenu= new Ext.menu.Item({
      text: 'Searches',
      iconCls: 'ix-v0-16-signpost',
      menu: new Ext.menu.Menu()
    })), 
    (this.favoritesMenu= new Ext.menu.Item({
      text: 'Favorites',
      iconCls: 'ix-v0-16-star_yellow',
      menu: new Ext.menu.Menu()
    }))
    ]    
    RG.Loft.FilterMenu.superclass.initComponent.call(this);
  },
  
  onMenuLoad: function(){      
    if (this.el) {
      this.toolsMenu.menu.removeAll()
      this.searchesMenu.menu.removeAll()
      this.favoritesMenu.menu.removeAll()
      
      this.tools= new Ext.util.MixedCollection()
      this.searches= new Ext.util.MixedCollection()
      this.favorites= new Ext.util.MixedCollection()      
      this.el.sync();
      var appRecordCollection= this.appPanel.store.snapshot || this.appPanel.store.data
      appRecordCollection.each(function(record){
        var category= record.data.filterSortCategory
        if (category) {
          var categoryFields= category.split(".", 2)
          if (categoryFields.length==2) {
            var type= categoryFields[0].toUpperCase()
            var value= categoryFields[1].toUpperCase()
            switch(type) {
              case 'TOOL':
                if (!this.tools.containsKey(value) && value!= 'UNKNOWN') {
                  this.tools.add(value, value)
                }
                break
              case 'SEARCH':
                if (!this.searches.containsKey(value) && value!= 'UNKNOWN') {
                  this.searches.add(value, value)
                } else if (value== 'UNKNOWN') {
                  this.searches.add(value, 'Other')
                }
                break
              case 'FAVORITE':
                if (!this.favorites.containsKey(value) && value!= 'UNKNOWN') {
                  this.favorites.add(value, value)
                }                
                break             
            }
          }
        }        
      }, this)
      
      var sort= function(a, b) {
        return (a > b ? 1 : (a < b ? -1 : 0))
      }
      
      this.tools.sort('ASC', sort)
      this.searches.sort('ASC', sort)
      this.favorites.sort('ASC', sort)
      
      if (this.tools.getCount()> 0) {
        var menuItems= []      
        this.tools.each(function(item) {
          menuItems.push({
            text: RG.categoryLabel(item.replace(/_TOOL$/, '')),
            type: 'TOOL',
            category: item.toUpperCase(),            
            checked: (Ext.isBoolean(this.filterState['TOOL'][item.toUpperCase()]) ? this.filterState['TOOL'][item.toUpperCase()] : true),
            hideOnClick: false,        
            checkHandler: this.updateFiltering.createDelegate(this)
          })
        }, this)
        this.toolsMenu.menu.add('<b class="rg-apps-menu-title">Choose Tools</b>')
        this.toolsMenu.menu.add({
          text: 'Select All/None',
          iconCls: 'ix-v0-16-check',
          type: 'TOOL',
          category: 'All',            
          hideOnClick: false,        
          handler: this.handleSelectAll.createDelegate(this),
          scope: this
        }) 
        this.toolsMenu.menu.add(menuItems)         
        this.toolsMenu.setDisabled(menuItems.length<=1)
      } else {
        this.toolsMenu.setDisabled(true)
      }
      
      if (this.searches.getCount()> 0) {        
        var menuItems= []
        this.searches.each(function(item) {
          menuItems.push({
            text: RG.categoryLabel(item),
            type: 'SEARCH',
            category: item.toUpperCase(),
            checked: (Ext.isBoolean(this.filterState['SEARCH'][item.toUpperCase()]) ? this.filterState['SEARCH'][item.toUpperCase()] : true),
            hideOnClick: false,        
            checkHandler: this.updateFiltering.createDelegate(this)
          })
        }, this)        
        this.searchesMenu.menu.add('<b class="rg-apps-menu-title">Choose Search Types</b>')
        this.searchesMenu.menu.add({
          text: 'Select All/None',
          iconCls: 'ix-v0-16-check',
          type: 'SEARCH',
          category: 'All',            
          hideOnClick: false,        
          handler: this.handleSelectAll.createDelegate(this),
          scope: this    
        })                  
        this.searchesMenu.menu.add(menuItems)
        this.searchesMenu.setDisabled(menuItems.length<=1)
      } else {
        this.searchesMenu.setDisabled(true)
      }
      
      if (this.favorites.getCount()> 0) {        
        var menuItems= []
        this.favorites.each(function(item) {
          menuItems.push({
            text: RG.categoryLabel((item== 'SERVICE' ? 'Search' : item)),  
            type: 'FAVORITE',
            category: item.toUpperCase(),
            checked: (Ext.isBoolean(this.filterState['FAVORITE'][item.toUpperCase()]) ? this.filterState['FAVORITE'][item.toUpperCase()] : true),
            hideOnClick: false,        
            checkHandler: this.updateFiltering.createDelegate(this)
          })
        }, this)
        this.favoritesMenu.menu.add('<b class="rg-apps-menu-title">Choose Favorite Types</b>')        
        this.favoritesMenu.menu.add({
          text: 'Select All/None',
          iconCls: 'ix-v0-16-check',
          type: 'FAVORITE',
          category: 'All',            
          hideOnClick: false,        
          handler: this.handleSelectAll.createDelegate(this),
          scope: this        
        })                          
        this.favoritesMenu.menu.add(menuItems)
        this.favoritesMenu.setDisabled(menuItems.length<=1)
      } else {
        this.favoritesMenu.setDisabled(true)
      }     
    }
  },
  handleSelectAll: function(item) {
    var allSelected
    switch(item.type) {
      case 'FAVORITE':
        allSelected= this.isAllItemsChecked(this.favoritesMenu.menu)
        this.setAllItemsChecked(this.favoritesMenu.menu, !allSelected)      
        break
      case 'TOOL':
        allSelected= this.isAllItemsChecked(this.toolsMenu.menu)
        this.setAllItemsChecked(this.toolsMenu.menu, !allSelected)              
        break
      case 'SEARCH':
        allSelected= this.isAllItemsChecked(this.searchesMenu.menu)
        this.setAllItemsChecked(this.searchesMenu.menu, !allSelected)   
        break 
      case 'ALL':
        allSelected= (this.isAllItemsChecked(this.favoritesMenu.menu) && 
          this.isAllItemsChecked(this.toolsMenu.menu) && 
          this.isAllItemsChecked(this.searchesMenu.menu))
        this.setAllItemsChecked(this.favoritesMenu.menu, !allSelected)   
        this.setAllItemsChecked(this.toolsMenu.menu, !allSelected)   
        this.setAllItemsChecked(this.searchesMenu.menu, !allSelected)                 
        break
    }  
    this.updateFiltering()
  },
  isAllItemsChecked: function(menu) {
    var allSelected= true
    menu.items.each(function(item) {
      if (item.checked=== false) {
        allSelected= false
        return false
      }
    })
    return allSelected
  },
  setAllItemsChecked: function(menu, checked) {
    menu.items.each(function(item) {
      if (Ext.isFunction(item.setChecked)) {
        item.setChecked(checked, true)
      }
    })  
  },
  updateFiltering: function() {
    var menuItems= [
    this.toolsMenu,
    this.favoritesMenu,
    this.searchesMenu      
    ]
    
    for(var i=0; i< menuItems.length; i++) {
      menuItems[i].menu.items.each(function(item) {
        if (Ext.isBoolean(item.checked)) {
          var filterCategories= this.filterState[item.type] || {}
          filterCategories[item.category]= item.checked
          this.filterState[item.type]= filterCategories
        }
      }, this)
    }
    this.appPanel.appView.handleFilter(this.filterState)
  }
});
