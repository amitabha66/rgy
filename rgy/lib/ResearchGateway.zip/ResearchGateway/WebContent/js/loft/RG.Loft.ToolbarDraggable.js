/*
 * Plugin which allows items to be dropped onto a toolbar and be turned into new Toolbar items.
 */


/*!
 * Ext JS Library 3.4.0
 * Copyright(c) 2006-2011 Sencha Inc.
 * licensing@sencha.com
 * http://www.sencha.com/license
 */
/**
 * @class Ext.ux.ToolbarReorderer
 * @extends Ext.ux.Reorderer
 * Plugin which can be attached to any Ext.Toolbar instance. Provides ability to reorder toolbar items
 * with drag and drop. Example:
 * <pre>
 * new Ext.Toolbar({
 *     plugins: [
 *         new Ext.ux.ToolbarReorderer({
 *             defaultReorderable: true
 *         })
 *     ],
 *     items: [
 *       {text: 'Button 1', reorderable: false},
 *       {text: 'Button 2'},
 *       {text: 'Button 3'}
 *     ]
 * });
 * </pre>
 * In the example above, buttons 2 and 3 will be reorderable via drag and drop. An event named 'reordered'
 * is added to the Toolbar, and is fired whenever a reorder has been completed.
 */
RG.Loft.ToolbarDraggable = Ext.extend(Object, {
  constructor: function(config) {
    Ext.apply(this, config || {}, {
      ddGroup: 'rg-tb-dd'
    })
  },
  
  /**
     * Initializes the plugin, decorates the toolbar with additional functionality
     */
  init: function(toolbar) {
    /**
         * This is used to store the correct x value of each button in the array. We need to use this
         * instead of the button's reported x co-ordinate because the buttons are animated when they move -
         * if another onDrag is fired while the button is still moving, the comparison x value will be incorrect
         */
    this.buttonXCache = {};
    this.toolbar = toolbar      

    toolbar.on({
      scope: this,
      add  : function(toolbar, item) {
        if (item.recordID) {
          this.createItemDD(item)
        }
      }
    });
  },
        
  /**
     * Sets up the given Toolbar item as a draggable
     * @param {Mixed} button The item to make draggable (usually an Ext.Button instance)
     */
  createItemDD: function(button) {
    if (!button.rendered) {
      button.on('render', this.createItemDD.createDelegate(this, [button]), this, {
        single: true
      });
      return
    }
    var el= button.getEl()
    var tb= this.toolbar
  
    if (el.dragZone != undefined) {
      return;
    }
    
    el.dragZone = new Ext.dd.DragZone(Ext.getBody(), {      
      getDragData: function(e) {
        var sourceEl= e.getTarget('.rg-apps-tb-button')
        if (sourceEl && sourceEl.id) {	
          var cmp= Ext.getCmp(sourceEl.id)
          if (cmp && cmp.recordID) {
            var record= tb.store.getById(cmp.recordID)
            if (record) {
              var ddel= sourceEl.cloneNode(true);
              ddel.id = Ext.id();
              return el.dragData = {
                sourceEl: sourceEl,
                repairXY: Ext.fly(sourceEl).getXY(),
                ddel: ddel,
                record: record,
                toolbar: tb
              }
            }
          }
        }
      },
      onDrag: function(e) {
      // Manually fix the default position of Ext-generated proxy element
      // Uncomment these line to see the effect
      //var proxy = Ext.DomQuery.select('*', this.getDragEl());				
      //proxy[2].style.position = '';
      },
	
      getRepairXY: function() {
        return this.dragData.repairXY;
      }
    })
  },
    
    
  /**
     * @private
     * Updates the internal cache of button X locations. 
     */
  updateButtonXCache: function() {
    var tbar   = this.target,
    items  = tbar.items,
    totalX = tbar.getEl().getBox(true).x;
            
    items.each(function(item) {
      this.buttonXCache[item.id] = totalX;

      totalX += item.getEl().getWidth();
    }, this);
  }
});

