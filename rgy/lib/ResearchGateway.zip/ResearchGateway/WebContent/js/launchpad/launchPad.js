/*
 ************************************************************************************
 * LaunchPadPanel
 * Version:  1.1
 * Date: 15 Dec 08
 * Author: J. McDowell
 * Description:
 * Set of panels for supporting the Welcome/Quick Items functionality
 ************************************************************************************
 */
LaunchPadPanel = function(config){
  config = config ||
  {}
  config.layout = 'border'
  config.region = 'center'
  config.border = false
  config.split = true
  config.bodyStyle = "background:url(/aig/img/launchpad/bg_dark_gray.png) repeat"
    
  var actionsRecords = {
    records: [{
      name: 'Query',
      action: 'Visual Query Tool',
      icon: '/aig/img/launchpad/query.png',
      tip: {
        tag: 'table',
        children: [{
          tag: 'tr',
          children: [{
            tag: 'td',
            html: '<B>Visual Query Tool</B>'
          }]
        }, {
          tag: 'tr',
          children: [{
            tag: 'td',
            html: 'Create, run, save, and share queries for compounds, substances, assays, and people using the Visual Query Tool (VQT). All queries return a list and table of results. Tables can be used to build a SAR table view.'
          }]
        }, {
          tag: 'tr',
          children: [{
            tag: 'td',
            style: 'padding-top: 10px',
            children: [{
              tag: 'img',
              src: '/aig/img/launchpad_tips/query.gif',
              style: 'border: #99BBE8 1px solid',
              width: 400
            }]
          }]
        }]
      }
    }, {
      name: 'View',
      action: 'View',
      icon: '/aig/img/launchpad/view.png',
      tip: {
        tag: 'table',
        children: [{
          tag: 'tr',
          children: [{
            tag: 'td',
            html: '<B>View</B>'
          }]
        }, {
          tag: 'tr',
          children: [{
            tag: 'td',
            html: 'Load, create, and edit Project and Table Views. Project and Table views contain a list of compounds and assays and related data. These data sets can be used to create SAR tables.'
          }]
        }, {
          tag: 'tr',
          children: [{
            tag: 'td',
            style: 'padding-top: 10px',
            children: [{
              tag: 'img',
              src: '/aig/img/launchpad_tips/views.gif',
              style: 'border: #99BBE8 1px solid',
              width: 400
            }]
          }]
        }]
      }
    }, {
      name: 'Explore',
      action: 'Explore',
      icon: '/aig/img/launchpad/explore.png',
      tip: {
        tag: 'table',
        children: [{
          tag: 'tr',
          children: [{
            tag: 'td',
            html: '<B>Explore</B>'
          }]
        }, {
          tag: 'tr',
          children: [{
            tag: 'td',
            html: 'Search and browse internal and external data for comounds, assays, projects, people, PK studies and more.'
          }]
        }, {
          tag: 'tr',
          children: [{
            tag: 'td',
            style: 'padding-top: 10px',
            children: [{
              tag: 'img',
              src: '/aig/img/launchpad_tips/explore.gif',
              style: 'border: #99BBE8 1px solid',
              width: 400
            }]
          }]
        }]
      }
    }, {
      name: 'Import',
      action: 'Import',
      icon: '/aig/img/launchpad/import_table.png',
      tip: {
        tag: 'table',
        children: [{
          tag: 'tr',
          children: [{
            tag: 'td',
            html: '<B>Import</B>'
          }]
        }, {
          tag: 'tr',
          children: [{
            tag: 'td',
            html: 'Import data from an MS Excel Worksheet or CSV file into a Research Gateway table.'
          }]
        }, {
          tag: 'tr',
          children: [{
            tag: 'td',
            style: 'padding-top: 10px',
            children: [{
              tag: 'img',
              src: '/aig/img/launchpad_tips/import_table_tip.png',
              style: 'border: #99BBE8 1px solid',
              width: 400
            }]
          }]
        }]
      }
    }        /*
         *
         * Commented out until implemented
         *
         * , {
         *   name: 'Report',
         *   action: 'TBD',
         *   icon: '/aig/img/launchpad/report.png'
         * }
         */
    ]
  };
    
  var thingsRecords = {
    records: [{
      name: 'Lists',
      action: 'My Lists',
      icon: '/aig/img/launchpad/lists.png',
      tip: {
        tag: 'table',
        children: [{
          tag: 'tr',
          children: [{
            tag: 'td',
            html: '<B>My Lists</B>'
          }]
        }, {
          tag: 'tr',
          children: [{
            tag: 'td',
            html: 'Create, load, edit, and share lists of compounds, assays, people, projects, PK studies and more.'
          }]
        }, {
          tag: 'tr',
          children: [{
            tag: 'td',
            style: 'padding-top: 10px',
            children: [{
              tag: 'img',
              src: '/aig/img/launchpad_tips/lists.gif',
              style: 'border: #99BBE8 1px solid',
              width: 400
            }]
          }]
        }]
      }
    }, {
      name: 'Queries',
      action: 'Queries',
      icon: '/aig/img/launchpad/queries.png',
      tip: {
        tag: 'table',
        children: [{
          tag: 'tr',
          children: [{
            tag: 'td',
            html: '<B>My Queries</B>'
          }]
        }, {
          tag: 'tr',
          children: [{
            tag: 'td',
            html: 'Load saved queries within the Visual Query Tool for compounds, substances, assays, and people.'
          }]
        }, {
          tag: 'tr',
          children: [{
            tag: 'td',
            style: 'padding-top: 10px',
            children: [{
              tag: 'img',
              src: '/aig/img/launchpad_tips/saved_queries.gif',
              style: 'border: #99BBE8 1px solid',
              width: 400
            }]
          }]
        }]
      }
    }, {
      name: 'Documents',
      action: 'Documents',
      icon: '/aig/img/launchpad/documents.png',
      tip: {
        tag: 'table',
        children: [{
          tag: 'tr',
          children: [{
            tag: 'td',
            html: '<B>My Documents</B>'
          }]
        }, {
          tag: 'tr',
          children: [{
            tag: 'td',
            html: 'View, upload, edit, and share documents in Research Gateway (RG) with colleagues. Documents can be tagged with any RG object (e.g. compounds, assays, projects etc.) or free text. This allows Documents to be searched quickly and easily.'
          }]
        }, {
          tag: 'tr',
          children: [{
            tag: 'td',
            style: 'padding-top: 10px',
            children: [{
              tag: 'img',
              src: '/aig/img/launchpad_tips/documents.gif',
              style: 'border: #99BBE8 1px solid',
              width: 400
            }]
          }]
        }]
      }
    }, {
      name: 'Preferences',
      action: 'Preferences',
      icon: '/aig/img/launchpad/options.png',
      tip: {
        tag: 'table',
        children: [{
          tag: 'tr',
          children: [{
            tag: 'td',
            html: '<B>My Preferences</B>'
          }]
        }, {
          tag: 'tr',
          children: [{
            tag: 'td',
            html: 'Manage preferences which are used to customize the look and feel and behavior of Research Gateway.'
          }]
        }, {
          tag: 'tr',
          children: [{
            tag: 'td',
            style: 'padding-top: 10px',
            children: [{
              tag: 'img',
              src: '/aig/img/launchpad_tips/preferences.gif',
              style: 'border: #99BBE8 1px solid',
              width: 400
            }]
          }]
        }]
      }
    }        /*
         *
         * Commented out until implemented
         *
         * , {
         *   name: 'Subscriptions',
         *   action: 'TBD',
         *   icon: '/aig/img/launchpad/subscriptions.png'
         *} , {
         *    name: 'Options',
         *    action: 'TBD',
         *    icon: '/aig/img/launchpad/options.png'
         *   }, {
         *    name: 'People',
         *    action: 'TBD',
         *    icon: '/aig/img/launchpad/people.png'
         *   }
         */
    ]
  };
    
    
  var actionsStore = new Ext.data.JsonStore({
    data: actionsRecords,
    root: 'records',
    fields: ['name', 'action', 'icon', 'tip'],
    autoLoad: true
  });
    
  var thingsStore = new Ext.data.JsonStore({
    data: thingsRecords,
    root: 'records',
    fields: ['name', 'action', 'icon', 'tip'],
    autoLoad: true
  });
    
  //Default template for most browsers    
  var tpl = new Ext.XTemplate('<tpl for=".">', '<div class="thumb-wrap" id="{name}">', '<div class="thumb-bgImg" ><img src="{icon}"></div>', '<span>{name}</span></div>', '</tpl>');
    
  //Fixes the PNG transparency problem on IE6 by using an AlphaImageLoader filter
  if (Ext.isIE6) {
    tpl = new Ext.XTemplate('<tpl for=".">', '<div class="thumb-wrap" id="{name}">', '<div class="thumb-bgImg" >', '<span style="width:48px;height:48px;filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src=\'{icon}\', sizingMethod=\'scale\')">&nbsp;</span>', '</div>', '<div align="center">{name}</div>', '</div>', '</tpl>')
  }
  var tasksPanel = new Ext.Panel({
    title: 'Tasks',
    columnWidth: '.5',
    autoScroll: true,
    //border: false,
    height: 275,
    //frame: true,
    style: "margin-right:5px;",
    bodyStyle: "vertical-align: middle;padding:20px;background:url(/aig/img/launchpad/bg_gray.png) repeat",
    cls: 'launchpad-panel-header',
    items: [new Ext.DataView({
      title: 'Tasks',
      store: actionsStore,
      tpl: tpl,
      height: '100%',
      singleSelect: true,
      selectedClass: 'thumb-x-view-selected',
      overClass: 'thumb-x-view-over',
      itemSelector: 'div.thumb-wrap',
      listeners: {
        click: function(dataview, index, htmlElementNode, e){
          this.tip.hide()
          var nodeText = htmlElementNode.innerText || htmlElementNode.textContent
          var nodeName = nodeText.trim();
          var dataItems = dataview.store.data.items;
          for (i = 0; i < dataItems.length; i++) {
            var data = dataItems[i].data;
            if (data.name == nodeName) {
              var action = data.action;
              if (action == "TBD") {
                showInformationDialog("Not Yet Implemented")
              } else if (action == "View") {
                AIG.showViewLoader()
              } else if (action == "Import") {
                AIG.dataImport()
              } else {
                AIG.closeLaunchPad()
                Ext.getCmp("rg-main-container-panel").activateQueryWindowTab(action);
              }
            }
          }
        },
        render: function(dataview){
          this.tip = new Ext.rx.AnchorToolTip({
            target: dataview.getEl(),
            delegate: dataview.itemSelector,
            trackMouse: false,
            showDelay: 1000,
            quickShowInterval: 0,
            width: 415,
            renderTo: document.body,
            autoHide: true,
            closable: false,
            anchor: 'left',
            listeners: {
              beforeshow: function(){
                try {
                  var record = this.store.getAt(this.store.find('name', this.tip.triggerElement.id))
                  if (record && record.data.tip) {
                    Ext.DomHelper.overwrite(this.tip.body, record.data.tip)
                    return true
                  }
                } catch (e) {
                }
                return false
              },
              scope: this
            }
          })
        }
      }
    })]
  })
    
    
  var thingsPanel = new Ext.Panel({
    title: 'Things',
    columnWidth: '.5',
    height: 275,
    autoScroll: true,
    bodyStyle: "vertical-align: middle;padding:20px;background:url(/aig/img/launchpad/bg_gray.png) repeat",
    cls: 'launchpad-panel-header',
    items: [new Ext.DataView({
      title: 'Things',
      store: thingsStore,
      tpl: tpl,
      height: '100%',
      singleSelect: true,
      selectedClass: 'thumb-x-view-selected',
      overClass: 'thumb-x-view-over',
      itemSelector: 'div.thumb-wrap',
      listeners: {
        click: function(dataview, index, htmlElementNode, e){
          this.tip.hide()
          var nodeText = htmlElementNode.innerText || htmlElementNode.textContent
          var nodeName = nodeText.trim();
          var dataItems = dataview.store.data.items;
          for (i = 0; i < dataItems.length; i++) {
            var data = dataItems[i].data;
            if (data.name == nodeName) {
              var action = data.action;
              switch (action) {
                case "Queries":
                  AIG.closeLaunchPad()
                  Ext.getCmp("rg-main-container-panel").activateQueryWindowTab("Visual Query Tool", {
                    openFavorites: true
                  });
                  break;
                case "Preferences":
                  new AIG.UserPreferencesUi({
                    selectedGroup: 'Startup'
                  }).show()
                  break
                case "TBD":
                  showInformationDialog("Not Yet Implemented")
                  break;
                default:
                  AIG.closeLaunchPad()
                  Ext.getCmp("rg-main-container-panel").activateQueryWindowTab(action);
                  break
              }
            }
          }
        },
        render: function(dv){
          this.tip = new Ext.rx.AnchorToolTip({
            target: dv.getEl(),
            delegate: dv.itemSelector,
            trackMouse: false,
            showDelay: 1000,
            quickShowInterval: 0,
            width: 415,
            renderTo: document.body,
            autoHide: true,
            closable: false,
            anchor: 'left',
            listeners: {
              beforeshow: function(tip){
                try {
                  var record = this.store.getAt(this.store.find('name', this.tip.triggerElement.id))
                  if (record && record.data.tip) {
                    Ext.DomHelper.overwrite(this.tip.body, record.data.tip)
                    return true
                  }
                } catch (e) {
                }
                return false
              },
              scope: this
            }
          })
        }
      }
    })]
  })
    
  var contentPanel = new Ext.Panel({
    border: false,
    //height: '100%',
    split: true,
    //frame:true,
    autoScroll: true,
    bodyStyle: "vertical-align: middle;padding:20px;background:url(/aig/img/launchpad/bg_dark_gray.png) repeat",
    items: [{
      layout: 'column',
      border: false,
      //height:'100%',
      //frame:true,
      //baseCls: 'x-window',
      bodyStyle: "vertical-align: middle;background:url(/aig/img/launchpad/bg_dark_gray.png) repeat",
      items: [tasksPanel, thingsPanel]
        
    }]
  });
    
    
  config.items = [{
    collapsible: false,
    width: 400,
    split: true,
    border: false,
    //height: "50%",
    //height: '100%',
    region: 'center',
    margins: '5 0 0 0',
    bodyStyle: "vertical-align: middle;background:url(/aig/img/launchpad/bg_dark_gray.png) repeat",
    autoScroll: true,
    items: [contentPanel]
  }, {
    region: 'south',
    layout: 'fit',
    border: false,
    height: Math.max(100, Ext.getBody().getViewSize().height - 400),
    split: true,
    minSize: 25,
    maxSize: 650,
    cmargins: '5 0 0 0',
    //autoScroll: true,
    //items: bottomTabs        
    //items: new AIG.Favorites.FavoritePanel({
    //    region: 'center'
    //}),
    items: {
      xtype: 'tabpanel',
      border: false,
      split: true,
      region: 'center',
      activeItem: 0,
      items: [new AIG.Favorites.FavoriteFolderPanel({
        iconCls: 'favorites-tab'
      }), new AIG.FeedViewer({
        title: 'History',
        iconCls: 'history-tab',
        channel: 'history'
      }), new AIG.FeedViewer({
        title: 'Subscriptions',
        iconCls: 'subscriptions-tab',
        channel: 'subscriptions'
      })]
    }
  /*[new Ext.ux.ManagedIframePanel({
         region: 'center',
         id: 'FAVS_IFRAME',
         name: 'FAVS_IFRAME',
         defaultSrc: '/aig/favs/favs.jsp?cb=top.AIG.openFavorite'
         })]*/
  }]
    
  config.listeners = {
    render: function(panel){
    }
  }
    
  Ext.apply(this, config)
  LaunchPadPanel.superclass.constructor.call(this)
}

Ext.extend(LaunchPadPanel, Ext.Panel, {
  refreshChannels: function(channel){
    var bottomPanel = this.items.get(1).items.get(0)
    bottomPanel.refreshChannels(channel)
  }
})

AIG.showViewLoader = function(){
  var vl = Ext.getCmp('aig_viewloader')
  if (!vl) {
    vl = new Ext.Window({
      id: 'aig_viewloader',
      width: 620,
      height: 500,
      title: "View Loader",
      layout: 'fit',
      buttonAlign: 'center',
      resizable: false,
      constrain: true,
      initComponent: function(){
        this.items= createViewSelectionPanel(this)
        Ext.Window.prototype.initComponent.call(this);
      }            
    })
        
  }
  vl.show()
}


AIG.dataImport = function(){
  new AIG.ImportDataDialog({
    modal: true
  }).show()
    
}




