/*Ext.override(Ext.form.ComboBox, {
 setValue: function(v){
 if (this.mode == 'remote' && !Ext.isDefined(this.store.totalLength)) {
 this.store.on('load', this.setValue.createDelegate(this, arguments), null, {
 single: true
 });
 if (this.store.lastOptions === null) {
 this.store.load();
 }
 return;
 }
 var text = v;
 if (this.valueField) {
 var r = this.findRecord(this.valueField, v);
 if (r) {
 text = r.data[this.displayField];
 }
 else
 if (this.valueNotFoundText !== undefined) {
 text = this.valueNotFoundText;
 }
 }
 this.lastSelectionText = text;
 if (this.hiddenField) {
 this.hiddenField.value = v;
 }
 Ext.form.ComboBox.superclass.setValue.call(this, text);
 this.value = v;
 }
 });*/
function createWizard(viewsStore, view_ids_touse, view_ids_toedit){
  var categoryOutput = "";
  var compoundOutput = "";
  var viewOutput = "";
    
  var Tree = Ext.tree;
    
  var assaysForCompoundsSourceRoot = new Ext.tree.TreeNode({
    text: 'My Categories',
    expanded: true,
    iconCls: 'x-tree-node-expanded',
    draggable: false, // disable root node dragging,
    leaf: false,
    uiProvider: AIG.FolderTreeNodeUI
  });
    
  var currentCategoryRoot = new Ext.tree.AsyncTreeNode({
    text: 'My Categories',
    expanded: true,
    draggable: false, // disable root node dragging
    enableDrop: true,
    leaf: false,
    uiProvider: AIG.FolderTreeNodeUI
  });
    
  //var durl = 'http://ussf-dapp-dweb1.amgen.com:9090/DP_Implemented/ListManagementServlet' +
  //var durl = '/aig/xmldataproxy.go?src=' + escape(slink + 'ListManagementServlet') +
  //var durl = pre + escape(slink + 'ListManagementServlet') +
  var durl = createUrl(slink + 'ListManagementServlet') +
  '?session_user=' +
  session_user +
  '&available_type=Categories' +
  "&view_list_ids=" +
  view_ids_touse;
    
  var availableCategoryTree = new Tree.TreePanel({
    id: 'availableCategoryTree',
    //margins: '2 2 0 2',
    title: 'Available Categories',
    border: true,
    region: 'west',
    width: 323,
    autoScroll: true,
    expanded: true,
    ddScroll: true,
    root: new Tree.AsyncTreeNode({
      text: 'Available Categories',
      draggable: false, // disable root node dragging
      expanded: true,
      id: 'AvailableCategories'
    }),
    loader: new ListLoader({
      dataUrl: durl,
      listeners: {
        load: function(loader, node, resp){
		  debugger
        },
		loadexception: function(loader, node, resp){
		  //debugger
		}
      }
    }),
    //enableDD: true,
    enableDrag: true,
    dropConfig: {
      appendOnly: true
    }
  });
    
  var currentCategoryTree = new Tree.TreePanel({
    //id: 'tree1',
    //margins: '2 2 0 2',
    //columnWidth: '0.5',
    title: 'My Current Categories',
    name: 'My Current Categories',
    border: true,
    region: 'east',
    width: 323,
    autoScroll: true,
    expanded: true,
    root: currentCategoryRoot,
    loader: new ListLoader({
      //dataUrl: '/aig/xmldataproxy.go?src=' + escape(slink + 'ListManagementServlet') +
      //dataUrl: pre + escape(slink + 'ListManagementServlet') +
      dataUrl: createUrl(slink + 'ListManagementServlet') +
      //dataUrl: 'http://ussf-dapp-dweb1.amgen.com:9090/DP_Implemented/ListManagementServlet' +
      '?session_user=' +
      session_user +
      '&available_type=mycategories' +
      '&view_list_ids=' +
      view_ids_toedit
    }),
    enableDD: true,
    enableDrop: true,
    dropConfig: {
      appendOnly: true
    },
    contextMenu: function(node){
      if (node.isRoot) {
        var mainmenu = new Ext.menu.Menu();
        mainmenu.add(new Ext.menu.Item({
          text: 'Add Category',
          edit: true,
          scope: this,
          handler: function(){
            getNameForNode(node, "add", "", "");
          }
        }));
        return mainmenu;
                
      }
      else 
      if (!node.isRoot && !node.leaf) {
        var catmenu = new Ext.menu.Menu();
        var disableFlag = false;
        var local_id_flag = false;
        var link_disableFlag = false;
                    
        if (node.attributes.local_name && node.attributes.name) {
          if (node.attributes.local_name == node.attributes.name) {
            link_disableFlag = false;
          }
          else {
            link_disableFlag = true;
          }
        }
                    
        if (node.attributes.local_id != null &&
          node.attributes.local_id != "undefined" &&
          node.attributes.local_id.length > 0) {
          local_id_flag = true;
        }
        if (local_id_flag && node.attributes.usedBy) {
          disableFlag = true;
        }
                    
        catmenu.add(new Ext.menu.Item({
          text: 'Rename Category',
          edit: true,
          scope: this,
          handler: function(){
            getNameForNode(node, "rename", node.attributes.name, view_ids_toedit);
                            
          }
        }), new Ext.menu.Item({
          text: 'Delete Category',
          edit: true,
          disabled: disableFlag,
          scope: this,
          handler: function(){
            this.transferHandler('remove')
          }
                        
                        
        }), new Ext.menu.Item({
          text: 'Add Assays',
          edit: true,
          scope: this,
          handler: function(){
            getAssayNode(node, null);
          }
                        
        }));
        return catmenu;
                    
      }
      else 
      if (!node.isRoot && node.leaf) {
        //var amenu = new Ext.menu.Menu('amenu');
        var amenu = new Ext.menu.Menu();
        amenu.add(new Ext.menu.Item({
          text: 'Delete Assay',
          edit: true,
          scope: this,
          handler: function(){
            this.transferHandler('remove')
          }
        }));
        amenu.add(new Ext.menu.Item({
          text: 'Edit Assay',
          edit: true,
          scope: this,
          handler: function(){
            getAssayNode(node.parentNode, node);
                                
          }
        }));
        return amenu;
                        
      }
    },
    listeners: {
      'contextmenu': function(node, e){
        node.select();
        var c = node.getOwnerTree().contextMenu(node);
        c.contextNode = node;
        c.showAt(e.getXY());
                
      },
      'beforenodedrop': function(e){
            
        var n = e.dropNode;
        var copy = new Tree.TreeNode(Ext.apply({}, n.attributes));
        if (n.hasChildNodes()) {
          n.eachChild(function(child){
            var copyChild = new Tree.TreeNode(Ext.apply({}, child.attributes));
            copy.appendChild(copyChild);
          })
        }
        copy.attributes.copied = true;
        copy.attributes.name = copy.text;
        copy.attributes.text = copy.text;
        copy.attributes.text = copy.attributes.text + "->" + "LINK -> " + n.parentNode.attributes.text + ")";
        copy.text = copy.attributes.text;
        copy.attributes.name = copy.text;
        e.dropNode = copy;
        e.dropNode.attributes.copied = true;
                
        if (view_ids_toedit != null && view_ids_toedit.length > 0 && n.parentNode.attributes.id == view_ids_toedit) {
          Ext.MessageBox.show({
            title: 'Message',
            msg: 'You are editing view: ' + n.parentNode.attributes.name + ' - cannot link from the same view',
            buttons: Ext.MessageBox.OK,
            icon: Ext.MessageBox.ERROR
          })
          e.dropNode = null
        }
        e.tree.root.eachChild(function(node){
          if (node.attributes.id == n.attributes.id) {
            Ext.MessageBox.show({
              title: 'Message',
              msg: 'Category ' + n.attributes.name + ' already exists - cannot add the same category',
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
            e.dropNode = null;
            return
          }
        }, this)
                
      }
    },
    transferHandler: function(transfer){
      var availableNode = availableCategoryTree.getSelectionModel().getSelectedNode()
      var currentNode = currentCategoryTree.getSelectionModel().getSelectedNode()
      switch (transfer) {
        case 'add':
          if (availableNode && availableNode.attributes.category == 'ASSAYS') {
            if (availableNode.attributes.text.indexOf('->LINK') > 0) {
              Ext.MessageBox.show({
                title: 'Message',
                msg: 'Category is Linked. Please include from the original view',
                buttons: Ext.MessageBox.OK,
                icon: Ext.MessageBox.ERROR
              })
            }
            else 
            if (view_ids_toedit != null && view_ids_toedit.length > 0 && availableNode.parentNode.attributes.id == view_ids_toedit) {
              Ext.MessageBox.show({
                title: 'Message',
                msg: 'You are editing view: ' + availableNode.parentNode.attributes.name + ' - cannot link from the same view',
                buttons: Ext.MessageBox.OK,
                icon: Ext.MessageBox.ERROR
              })
            }
            else {
              var toAdd = true;
              currentCategoryTree.root.eachChild(function(node){
                if (node.attributes.id == availableNode.attributes.id) {
                  Ext.MessageBox.show({
                    title: 'Message',
                    msg: 'Category ' + availableNode.attributes.name + ' already exists - cannot add the same category',
                    buttons: Ext.MessageBox.OK,
                    icon: Ext.MessageBox.ERROR
                  })
                  toAdd = false;
                }
              }, this)
              if (toAdd) {
                var copy = new Tree.TreeNode(Ext.apply({}, availableNode.attributes));
                if (availableNode.hasChildNodes()) {
                  availableNode.eachChild(function(child){
                    var copyChild = new Tree.TreeNode(Ext.apply({}, child.attributes));
                    copy.appendChild(copyChild);
                  })
                }
                copy.attributes.copied = true;
                copy.attributes.name = copy.text;
                copy.attributes.text = copy.text;
                copy.attributes.text = copy.attributes.text + "->" + "LINK -> " + availableNode.parentNode.attributes.text + ")";
                copy.text = copy.attributes.text;
                copy.attributes.name = copy.text;
                currentCategoryTree.root.appendChild(copy)
                currentCategoryTree.root.expand()
              }
            }
          }
          break
        case 'remove':
          if (!currentNode) {
            return
          }
          //Check if the category is in use elsewhere. If so, bail					
          var local_id_flag = false;
                    
          //Delete Category                    
          if (currentNode.attributes.category == 'ASSAYS') {
            if (currentNode.attributes.local_id != null && currentNode.attributes.local_id != "undefined" &&
              currentNode.attributes.local_id.length > 0) {
              local_id_flag = true;
            }
            if (local_id_flag && currentNode.attributes.usedBy) {
              return
            }
            if (view_ids_toedit != null && view_ids_toedit.length > 0 &&
              currentNode.attributes.local_id.length > 0 &&
              currentNode.attributes.copied != true) {
              Ext.Ajax.request({
                url: createUrl(slink + 'ListManagementServlet'),
                success: function(response){
                  if (response.responseText.trim() == "Passed") {
                    currentNode.remove();
                  }
                  else {
                    Ext.MessageBox.show({
                      title: 'Deleted',
                      msg: response.responseText.trim(),
                      buttons: Ext.MessageBox.OK,
                      icon: Ext.MessageBox.ERROR
                    })
                  }
                },
                failure: function(response){
                  Ext.MessageBox.show({
                    title: 'Deleted',
                    msg: 'Delete Category Failure.',
                    buttons: Ext.MessageBox.OK,
                    icon: Ext.MessageBox.ERROR
                  })
                },
                scope: this,
                params: {
                  session_user: session_user,
                  available_type: 'deletecat',
                  local_id: currentNode.attributes.local_id,
                  usedBy: currentNode.attributes.usedBy,
                  usedFrom: currentNode.attributes.usedFrom,
                  'view_list_ids': view_ids_toedit
                }
              })
            }
            else {
              currentNode.remove();
            }
            return
          }
          //Delete Assay
          var parentCurrentNode = currentNode.parentNode
          if (!currentNode.isRoot && currentNode.leaf && parentCurrentNode) {
                    
            if (parentCurrentNode.attributes.copied != "undefined" &&
              parentCurrentNode.attributes.copied == true) {
              parentCurrentNode.attributes.copied = false;
              parentCurrentNode.attributes.list_id = "";
              parentCurrentNode.attributes.local_id = "";
            }
                        
            if (parentCurrentNode.attributes.name.indexOf('->LINK') > 0) {
              parentCurrentNode.attributes.name = parentCurrentNode.attributes.name.substring(0, parentCurrentNode.attributes.name.indexOf('->LINK'));
            }
            parentCurrentNode.attributes.edit = true;
            parentCurrentNode.attributes.text = parentCurrentNode.attributes.name;//changing node name from link to orig since there is some change					
            parentCurrentNode.setText(parentCurrentNode.attributes.name);
            currentNode.remove();
          }
          break
        case 'remove_all':
          while (currentCategoryTree.root.firstChild) {
            var c = currentCategoryTree.root.firstChild;
            currentCategoryTree.root.removeChild(c);
            c.destroy();
          }
          break
        case 'up':
          if (currentNode &&
            (!currentNode.attributes.category || currentNode.attributes.category == 'ASSAYS' || currentNode.attributes.category == 'ALIAS') &&
            currentNode.previousSibling) {
            currentNode.parentNode.insertBefore(currentNode, currentNode.previousSibling)
            currentNode.select()
            if (!currentNode.attributes.category || currentNode.attributes.category == 'ALIAS') {
              var parentCurrentNode = currentNode.parentNode
              if (parentCurrentNode.attributes.name.indexOf('->LINK') > 0) {
                parentCurrentNode.attributes.name = parentCurrentNode.attributes.name.substring(0, parentCurrentNode.attributes.name.indexOf('->LINK'));
              }
              parentCurrentNode.attributes.edit = true;
              parentCurrentNode.attributes.text = parentCurrentNode.attributes.name;//changing node name from link to orig since there is some change					
              parentCurrentNode.setText(parentCurrentNode.attributes.name);
              currentNode.attributes.edit = true;
            }
          }
          break
        case 'down':
          if (currentNode &&
            (!currentNode.attributes.category || currentNode.attributes.category == 'ASSAYS' || currentNode.attributes.category == 'ALIAS') &&
            currentNode.nextSibling) {
            currentNode.parentNode.insertBefore(currentNode.nextSibling, currentNode)
            currentNode.select()
            if (!currentNode.attributes.category || currentNode.attributes.category == 'ALIAS') {
              var parentCurrentNode = currentNode.parentNode
              if (parentCurrentNode.attributes.name.indexOf('->LINK') > 0) {
                parentCurrentNode.attributes.name = parentCurrentNode.attributes.name.substring(0, parentCurrentNode.attributes.name.indexOf('->LINK'));
              }
              parentCurrentNode.attributes.edit = true;
              parentCurrentNode.attributes.text = parentCurrentNode.attributes.name;//changing node name from link to orig since there is some change					
              parentCurrentNode.setText(parentCurrentNode.attributes.name);
              currentNode.attributes.edit = true;
            }
          }
          break
      }
    },
    updateOrderAttributes: function(){
      var counter = 1
      currentCategoryTree.root.eachChild(function(node){
        node.attributes.order = (counter++)
      }, this)
    }
  });
    
  /*
     var treeCat = new Tree.TreePanel({
     margins: '2 2 0 2',
     autoScroll: true,
     expanded: true,
     root: root,
     region: 'center',
     title: "Selected Assay Categories",
     selModel: new Ext.tree.MultiSelectionModel(),
     containerScroll: false
     
     });*/
  var cmpdsListreader = new Ext.data.XmlReader({
    record: 'elist'
  }, [{
    name: 'id',
    mapping: '@id'
  }, {
    name: 'name',
    mapping: '@name'
  }]);
    
  var compoundsStore1 = new Ext.data.Store({
    reader: cmpdsListreader,
    autoLoad: true,
    //url: 'http://ussf-dapp-dweb1.amgen.com:9090/DP_Implemented/ListManagementServlet?session_user=' + session_user + '&available_type=CompoundLists'
    //url: '/aig/xmldataproxy.go?src=' + escape(slink + 'ListManagementServlet'),
    //url: pre + escape(slink + 'ListManagementServlet'),
    url: createUrl(slink + 'ListManagementServlet'),
    baseParams: {
      session_user: session_user,
      available_type: 'CompoundLists'
    }
  });
    
    
  var categoryButtonPanel = new Ext.Panel({
    region: 'center',
    layout: 'border',
    border: false,
    items: [{
      xtype: 'buttongroup',
      region: 'center',
      style: 'margin-left:5px;margin-right:2px;',
      columns: 1, 
      border: false,
      frame: false,
      defaults: {
        style: 'margin-left:2px;margin-right:2px;margin-top:5px;margin-bottom:5px',
        cls: 'x-btn-icon',
        width: 60
      },      
      items: [new Ext.Button({
        icon: link + 'aig/img/add_button.gif',
        handler: function(){
          currentCategoryTree.transferHandler('add')
        }
      }), new Ext.Button({
        icon: link + 'aig/img/remove_button.gif',
        handler: function(){
          currentCategoryTree.transferHandler('remove')
        }
      }), new Ext.Button({
        icon: link + 'aig/img/remove_all_button.gif',
        handler: function(){
          currentCategoryTree.transferHandler('remove_all')
        }
      }), new Ext.Button({
        icon: link + 'aig/img/up_button.gif',
        handler: function(){
          currentCategoryTree.transferHandler('up')
        }
      }), new Ext.Button({
        icon: link + 'aig/img/down_button.gif',
        handler: function(){
          currentCategoryTree.transferHandler('down')
        }
      })]
    }]
  })
    
    
    
    
  var c3_project_store = new Ext.data.Store({
    reader: new Ext.data.ArrayReader({
      idIndex: 0 // id for each record will be the first element
    }, Ext.data.Record.create(['value', 'text']) // recordType
      )
  })
    
    
  var c2_project_store = new Ext.data.Store({
    reader: new Ext.data.XmlReader({
      record: 'Option'
    }, [{
      name: 'Label',
      mapping: 'Label'
    }, {
      name: 'Value',
      mapping: 'Value'
    }]),
    autoLoad: true,
    url: createUrl(slink + 'ProjectDataSourceServlet_RDH'),
    baseParams: {
      projectName: '',
      edit: false,
      exactMatch: 'false'
    },
    listeners: {
      load: function(store, records, option){
            
        if (store.baseParams.edit) {
          store.baseParams.edit = false;
          var ids = []
          for (var j = 0; j < store.data.length; j++) {
            ids.push(store.data.items[j].data.Value)
          }
          Ext.getCmp('id_pv_clist_c_reg').setValue(ids.length > 0 ? ids.join(';') : null)
        }
                
                
      }
    }
  })
    
  c2_project_store.on('beforeload', function(store){
    if (store.baseParams.edit == false && Ext.getCmp('id_pv_clist_c_reg').lastQuery && Ext.getCmp('id_pv_clist_c_reg').lastQuery.length > 0) {
      store.baseParams = {
        projectName: Ext.getCmp('id_pv_clist_c_reg').lastQuery,
        edit: false,
        exactMatch: 'false'
      };
    }
  //alert("last: " + Ext.getCmp('id_pv_clist_c_reg').lastQuery + " : " + Ext.getCmp('id_pv_clist_c_reg').getValue() + " : " + Ext.getCmp('id_pv_clist_c_reg').store.baseParams.projectName)
    
  });
    
  var selectedCmpdListsStore = new Ext.data.Store({
    reader: new Ext.data.ArrayReader({
      idIndex: 0 // id for each record will be the first element
    }, Ext.data.Record.create(['value', 'text']) // recordType
      )
  })
    
  var selectAssaysForCompoundsSourceTree = new Ext.tree.TreePanel({
    region: 'west',
    title: 'Assay to Select',
    name: 'selected_categories',
    expanded: true,
    frame: true,
    root: assaysForCompoundsSourceRoot,
    width: 285,
    enableDD: true,
    autoScroll: true,
    dropConfig: {
      appendOnly: true
    }
  })
    
  var selectAssaysForCompoundsTree = new Ext.tree.TreePanel({
    region: 'east',
    title: 'Assay Selected',
    name: 'assay_compound_categories',
    expanded: true,
    frame: true,
    root: new Tree.AsyncTreeNode({
      text: 'Selected Categories',
      expanded: true,
      leaf: false,
      draggable: false // disable root node dragging
    }),
    width: 285,
    enableDD: true,
    autoScroll: true,
    dropConfig: {
      appendOnly: true
    },
    loader: new ListLoader({
      //dataUrl: '/aig/xmldataproxy.go?src=' + escape(slink + 'ListManagementServlet') +            
      //dataUrl: pre + escape(slink + 'ListManagementServlet') +            
      dataUrl: createUrl(slink + 'ListManagementServlet') +
      //dataUrl: 'http://ussf-dapp-dweb1.amgen.com:9090/DP_Implemented/ListManagementServlet' +            
      '?session_user=' +
      session_user +
      '&available_type=AssayCompoundCategories' +
      '&view_list_ids=' +
      view_ids_toedit
    }),
        
    transferHandler: function(transfer){
      var availableNode = selectAssaysForCompoundsSourceTree.getSelectionModel().getSelectedNode()
      var currentNode = selectAssaysForCompoundsTree.getSelectionModel().getSelectedNode()
      switch (transfer) {
        case 'add':
          if (availableNode && availableNode.attributes.category == 'ASSAYS') {
                    
            if (availableNode.attributes.text.indexOf('->LINK') > 0) {
              Ext.MessageBox.show({
                title: 'Message',
                msg: 'Category is Linked. Please include categories from the current view',
                buttons: Ext.MessageBox.OK,
                icon: Ext.MessageBox.ERROR
              })
            }
            else {
              selectAssaysForCompoundsTree.root.appendChild(availableNode)
              selectAssaysForCompoundsTree.root.expand()
            }
          }
          break
        case 'remove':
          if (currentNode && currentNode.attributes.category == 'ASSAYS') {
            selectAssaysForCompoundsSourceTree.root.appendChild(currentNode)
            selectAssaysForCompoundsSourceTree.root.expand()
          }
          break
        case 'remove_all':
          while (selectAssaysForCompoundsTree.root.firstChild) {
            var c = selectAssaysForCompoundsTree.root.firstChild;
            selectAssaysForCompoundsSourceTree.root.appendChild(c)
          }
          selectAssaysForCompoundsSourceTree.root.expand()
          break
      }
    }
  })
    
    
    
    
  var wizard = new Ext.ux.Wiz({
    title: (view_ids_toedit ? 'Edit View' : 'Create View'),
    width: 735,
    height: 600,
    resizable: false,
    constrain: true,
    id: 'listwizard',
    headerConfig: {
      title: 'View Builder Wizard',
      height: 55
    },
    cardPanelConfig: {
      defaults: {
        //baseCls: 'x-small-editor',
        border: false
      }
    },
    onFinish: function(){
      /*
            if (this.fireEvent('finish', this, this.getWizardData()) !== false) {
                this.close();
            }*/
            
      var result = viewSave(this.cards[this.cardCount - 1]);           
           
            
      Ext.Ajax.request({
        //url: "http://ussf-dapp-dweb1.amgen.com:9090/DP_Implemented/ListManagementServlet",
        //url: '/aig/xmldataproxy.go?src=' + escape(slink + 'ListManagementServlet'),
        //url: pre + escape(slink + 'ListManagementServlet'),
        url: createUrl(slink + 'ListManagementServlet'),
        success: function(response){
          if (response.responseText.trim() == "Passed") {
            viewsStore.reload();
          }
          else {
            Ext.MessageBox.show({
              title: 'Save List',
              msg: response.responseText.trim(),
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
          }
        },
        failure: function(response){
          Ext.MessageBox.show({
            title: 'Save List',
            msg: 'Unable to save view.',
            buttons: Ext.MessageBox.OK,
            icon: Ext.MessageBox.ERROR
          })
        },
        scope: this,
        params: {
          session_user: session_user,
          available_type: 'addview',
          result: result,
          'view_list_ids': view_ids_toedit
        }
      })
            
      this.close();
            
    },
    cards: [new Ext.ux.Wiz.Card({
      width: 700,
      layout: 'border',
      title: 'Create Assay Categories',
      name: "create categories",
      border: false,
      items: [{
        border: false,
        region: 'center',
        layout: 'border',
        width: 700,
        items: [availableCategoryTree, categoryButtonPanel, currentCategoryTree]
      }],
      listeners: {
        'beforecardhide': function(){                
          currentCategoryTree.updateOrderAttributes()
          var flag = assaysSave(assaysForCompoundsSourceRoot, currentCategoryRoot);
          if (flag == false) {
            var pwiz = Ext.getCmp('listwizard');
            Ext.MessageBox.show({
              title: 'Create Assay Categories',
              msg: 'Please create an Assay Category',
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
          }
          return flag;
        }
      }       
    }), new Ext.ux.Wiz.Card({
      width: 800,
      autoScroll: true,
      monitorValid: true,
      fitToFrame: true,
      layout: 'border',
      title: 'Create Compound Lists',
      listeners: {
        'beforecardhide': function(){
          compoundsSave(this, assaysForCompoundsSourceRoot, selectedCmpdListsStore, c3_project_store);
        },
        'show': function(){
          if (view_ids_toedit != null && view_ids_toedit.length > 0) {
            this.getForm().load({
              waitTitle: 'Loading compound lists information',
              waitMsg: 'Waiting...',
              url: createUrl(slink + 'ListManagementServlet'),
              method: 'POST',
              params: {
                'available_type': 'CompoundListsJson',
                'session_user': session_user,
                'view_list_ids': view_ids_toedit
              },
              success: function(f, a){
                //Pasted Compounds
                if (a.result.data.hn_pv_clist_pasted && a.result.data.hn_pv_clist_pasted.length > 0) {
                  var pasted = f.items.items[3]
                  pasted.setValue(a.result.data.hn_pv_clist_pasted)
                }
                                
                //My list
                if (a.result.data.hn_pv_clist_mylist && a.result.data.hn_pv_clist_mylist.length > 0) {
                  var mylist_combo = f.items.items[2]
                  mylist_combo.setValue(a.result.data.hn_pv_clist_mylist)
                }
                                
                //VQT Queries
                if (a.result.data.hn_pv_clist_vqt && a.result.data.hn_pv_clist_vqt.length > 0) {
                  var vqt_combo = f.items.items[1]
                  var vqt_val = a.result.data.hn_pv_clist_vqt
                  var vqt_array = vqt_val.split(",");
                  for (var i = 0; i < vqt_array.length; i++) {
                    var value_text = vqt_array[i]
                    var array_value_text = value_text.split("___");
                    var queryname = array_value_text[0].substring(4)
                    var MyRecordType = Ext.data.Record.create(['value', 'text']);
                    myrec = new MyRecordType({
                      "value": array_value_text[1],
                      "text": queryname
                    });
                                        
                    vqt_combo.store.add(myrec)
                    vqt_combo.reset()
                    var ids = []
                    for (var j = 0; j < vqt_combo.store.data.length; j++) {
                      ids.push(vqt_combo.store.data.items[j].data.value)
                    }
                    vqt_combo.setValue(ids.length > 0 ? ids.join(';') : null)
                  }
                }
                                
                //Project Registered
                if (a.result.data.hn_pv_clist_c_reg && a.result.data.hn_pv_clist_c_reg.length > 0) {
                  var proj_combo = f.items.items[0]
                  var selected_project = a.result.data.hn_pv_clist_c_reg
                  proj_combo.store.baseParams = {
                    projectName: selected_project,
                    edit: true,
                    exactMatch:'true'
                  }
                  proj_combo.store.load()
                }
                                
                                
              },
              failure: function(f, a){
                Ext.MessageBox.show({
                  title: 'Failed for Editing',
                  msg: 'Failed to load compound lists for the view',
                  buttons: Ext.MessageBox.OK,
                  icon: Ext.MessageBox.ERROR
                })
              }
            })
          }
                    
          var selectAssaysForCompoundsChildNodes = selectAssaysForCompoundsTree.root.childNodes
          Ext.each(selectAssaysForCompoundsChildNodes, function(cn){
                    
            if (cn && cn.attributes && cn.attributes.list_id) {
              //Ext.log("selectAssaysForCompoundNode: " + cn.attributes.name + " : " + cn.attributes.list_id + " : " + cn.attributes.order);
              var sourceNode = selectAssaysForCompoundsSourceTree.root.findChild('list_id', cn.attributes.list_id)
              if (sourceNode) {
                var copy = new Tree.TreeNode(Ext.apply({}, sourceNode.attributes));
                if (sourceNode.hasChildNodes()) {
                  sourceNode.eachChild(function(child){
                    var copyChild = new Tree.TreeNode(Ext.apply({}, child.attributes));
                    copy.appendChild(copyChild);
                  })
                }
                selectAssaysForCompoundsTree.root.replaceChild(copy, cn)
                sourceNode.remove()
                                
              }
            }
          }, this)
                    
          var selectAssaysForCompoundsSourceTreeChildNodes = selectAssaysForCompoundsSourceTree.root.childNodes
          Ext.each(selectAssaysForCompoundsSourceTreeChildNodes, function(cn){
            if (cn && cn.attributes && cn.attributes.text.indexOf('->LINK') > 0) {
              cn.allowDrag = false;
              cn.draggable = false;
            }
                        
          })
          selectAssaysForCompoundsSourceTree.root.expand()
          selectAssaysForCompoundsTree.root.expand()
        }
      },
            
            
      /********Begin *****/
            
      items: [{
        region: 'center',
        layout: 'form',
        autoScroll: true,
        frame: true,
        width: 700,
        items: [{//start fieldset clist reg
          xtype: 'fieldset',
          title: 'Create a Compounds List From Compounds Registered To Projects',
          //region: 'north',
          //layout: 'border',
          height: 50,
          items: [new Ext.ux.form.SuperBoxSelect({
            region: 'center',
            autoLoad: true,
            listWidth: 450,
            //height: 50,
            width: 450,
            allowBlank: false,
            loadingText: 'Loading...',
            emptyText: 'Type in project name..(Min. 2 characters)',
            hideLabel: true,
            name: 'n_pv_clist_c_reg',
            hiddenName: 'hn_pv_clist_c_reg',
            displayField: 'Label',
            valueField: 'Value',
            editable: true,
            resizable: true,
            id: 'id_pv_clist_c_reg',
            store: c2_project_store,
            mode: 'remote',
            //mode: 'local',
            allowBlank: false,
            forceSelection: true,
            typeAhead: true,
            triggerAction: 'all',
            selectOnFocus: true,
            separator: ";",
            minChars: 2
                    
          })]
        },////end fieldset clist reg
        { // begin vqt fieldset
          xtype: 'fieldset',
          //region: 'center',
          title: 'Create Compound Lists From Saved VQT Queries',
          //layout: 'form',
          height: 50,
          items: new Ext.ux.form.SuperBoxSelect({
            height: 100,
            //region: 'center',
            autoLoad: true,
            //listWidth: 450,
            width: 450,
            //allowBlank: false,
            loadingText: 'Loading...',
            emptyText: 'Select a Saved VQT Query...',
            hideLabel: true,
            name: 'n_pv_clist_vqt',
            hiddenName: 'hn_pv_clist_vqt',
            displayField: 'text',
            valueField: 'value',
            editable: false,
            resizable: true,
            id: 'id_pv_clist_vqt',
            store: new Ext.data.Store({
              reader: new Ext.data.ArrayReader({
                idIndex: 0 // id for each record will be the first element
              }, Ext.data.Record.create(['value', 'text']) // recordType
                )
            }),
            mode: 'local',
            forceSelection: true,
            typeAhead: true,
            triggerAction: 'all',
            selectOnFocus: true,
            separator: ";",
            onTriggerClick: function(){
                        
              new AIG.VQTSavedQueryDialog({
                entityTypeCodeFilter: 'COMPOUND',
                title: 'Select a VQT Compound Query',
                handler: function(win, queryAttr){
                  //win.close()
                  //alert("In the handler")
                  if (queryAttr.query_id) {
                    var MyRecordType = Ext.data.Record.create(['value', 'text']);
                    myrec = new MyRecordType({
                      "value": queryAttr.query_id,
                      "text": queryAttr.text
                    });
                                        
                    this.store.add(myrec)
                    //alert(this.store.data.length + ":" + queryAttr.query_id + ":" + queryAttr.text)
                    //combo.setValue(queryAttr.query_id)
                    this.reset()
                    var ids = []
                    for (var i = 0; i < this.store.data.length; i++) {
                      ids.push(this.store.data.items[i].data.value)
                    }
                    this.setValue(ids.length > 0 ? ids.join(';') : null)
                  }
                },
                scope: this
              }).show()
            }
          })
        //end vqtfieldset items
        }//--- end vqt fieldset
        , {//start clist fielset
          xtype: 'fieldset',
          title: 'Create Compound Lists From Saved Lists In My Lists',
          height: 50,
          items: [new Ext.ux.form.SuperBoxSelect({
            autoLoad: true,
            listWidth: 450,
            //height: 60,
            width: 450,
            //allowBlank: false,
            loadingText: 'Loading...',
            fieldLabel: 'Pick a Compound List',
            emptyText: 'Pick a Compound List...',
            hideLabel: true,
            name: 'n_pv_clist_mylist',
            hiddenName: 'hn_pv_clist_mylist',
            displayField: 'name',
            editable: true,
            resizable: true,
            id: 'id_pv_clist_mylist',
            valueField: 'id',
            store: new Ext.data.Store({
              reader: cmpdsListreader,
              autoLoad: true,
              url: createUrl(slink + 'ListManagementServlet'),
              baseParams: {
                session_user: session_user,
                available_type: 'CompoundLists'
              }
            }),
            mode: 'local',
            forceSelection: true,
            typeAhead: true,
            triggerAction: 'all',
            selectOnFocus: true,
            separator: ";"
          })]
        }//end clist fielset
        , //end fieldset North -> creg, vqt, clist
        {
          xtype: 'fieldset',
          layout: 'border',
          title: 'Create a Compound List From Assay Categories',
          anchor: '100%',
          height: 125,
          items: {
            layout: 'border',
            region: 'center',
            items: [selectAssaysForCompoundsSourceTree, {
              region: 'center',
              layout: 'form',
              border: true,
              buttonAlign: 'center',
              defaults: {
                style: 'margin-left:12px;margin-right:12px;margin-top:5px;margin-bottom:5px',
                cls: 'x-btn-icon',
                minWidth: 60
              },
              items: [new Ext.Button({
                icon: link + 'aig/img/add_button.gif',
                handler: function(){
                  selectAssaysForCompoundsTree.transferHandler('add')
                }
              }), new Ext.Button({
                icon: link + 'aig/img/remove_button.gif',
                handler: function(){
                  selectAssaysForCompoundsTree.transferHandler('remove')
                }
              }), new Ext.Button({
                icon: link + 'aig/img/remove_all_button.gif',
                handler: function(){
                  selectAssaysForCompoundsTree.transferHandler('remove_all')
                }
              })]
                        
            }, selectAssaysForCompoundsTree]
          }
        }, {
          xtype: 'fieldset',
          title: 'Create a Compound List From Compound Root Numbers',
          height: 75,
          items: [{
            xtype: 'textarea',
            anchor: '100%',
            width: 650,
            height: 65,
            id: 'id_pv_clist_pasted',
            hideLabel: true,
            name: 'n_pv_clist_pasted',
            hiddenName: 'hn_pv_clist_pasted'
          }]
        }]//end items fieldset North -> creg, vqt, clist
      }]
        
        
    /*******End*******/
        
    }), new Ext.ux.Wiz.Card({
      width: 700,
      height: 600,
      monitorValid: true,
      title: 'Create View',
      labelWidth: 175,
      listeners: {
        'show': function(){
                
          if (view_ids_toedit != null && view_ids_toedit.length > 0) {
            this.getForm().load({
              waitTitle: 'Loading view information',
              waitMsg: 'Waiting...',
              url: createUrl(slink + 'ListManagementServlet'),
              method: 'POST',
              params: {
                'available_type': 'ViewsListsJson',
                'session_user': session_user,
                'view_list_ids': view_ids_toedit
              },
              success: function(f, a){
                var proj_combo = Ext.getCmp('view_load_def_proj');
                for (var j = 0; j < proj_combo.store.data.length; j++) {
                  if (proj_combo.store.data.items[j].data.text == a.result.data.view_project) {
                    proj_combo.setValue(proj_combo.store.data.items[j].data.value)
                    proj_combo.lastSelectionText = a.result.data.view_project
                    proj_combo.selectedIndex = j
                                        
                  }
                }
                                
                var ch = Ext.getCmp('view_load_def_proj_check');
                Ext.Ajax.request({
                  url: createUrl(slink + 'ListManagementServlet'),
                  success: function(response){
                    if (response.responseText.trim() == "Access") {
                      if (a.result.data.view_default) {
                        ch.setValue(true)
                      }
                      ch.setDisabled(false);
                    }
                    else {
                      ch.setDisabled(true);
                      ch.setValue(false);
                    }
                  },
                  failure: function(response){
                    Ext.MessageBox.show({
                      title: 'Find Access',
                      msg: 'Find Access failed',
                      buttons: Ext.MessageBox.OK,
                      icon: Ext.MessageBox.ERROR
                    })
                  },
                  scope: this,
                  params: {
                    available_type: 'findAccess',
                    session_user: session_user,
                    view_project: proj_combo.getValue()
                  }
                })
                                
                var cmpd_list_combo = Ext.getCmp('view_load_def_def_cmpd_list');
                for (var j = 0; j < cmpd_list_combo.store.data.length; j++) {
                  var xx = a.result.data.view_cmpd_default.substring(a.result.data.view_cmpd_default.indexOf("___") + 2)
                  //alert(a.result.data.view_cmpd_default + " : " + cmpd_list_combo.store.data.items[j].data.value + " : " + cmpd_list_combo.store.data.items[j].data.text)
                  if (cmpd_list_combo.store.data.items[j].data.value.indexOf(xx) >= 0) {
                    cmpd_list_combo.setValue(cmpd_list_combo.store.data.items[j].data.value)
                    cmpd_list_combo.selectedIndex = j
                  }
                  else 
                  if (a.result.data.view_cmpd_default.indexOf("Compounds driven by categories:") >= 0 &&
                    cmpd_list_combo.store.data.items[j].data.text == "Compounds driven by assays") {
                    cmpd_list_combo.setValue(cmpd_list_combo.store.data.items[j].data.value)
                    cmpd_list_combo.selectedIndex = j
                  }
                  else 
                  if (a.result.data.view_cmpd_default == cmpd_list_combo.store.data.items[j].data.text) {
                    cmpd_list_combo.setValue(cmpd_list_combo.store.data.items[j].data.value)
                    cmpd_list_combo.selectedIndex = j
                  }
                }
                                
                                
              /*
                                 var ch = Ext.getCmp('view_load_def_proj_check');
                                 if (ch.getValue()) {
                                 ch.setDisabled(false);
                                 }*/
              },
              failure: function(f, a){
                Ext.MessageBox.show({
                  title: 'Failed for Editing',
                  msg: 'Failed to load view information',
                  buttons: Ext.MessageBox.OK,
                  icon: Ext.MessageBox.ERROR
                })
                                
              }
            })
          }
          else {
            var proj_combo = Ext.getCmp('view_load_def_proj');
            var ss = proj_combo.getStore();
            if (ss.getCount() == 1) {
              proj_combo.setValue(ss.data.items[0].data.value);
              proj_combo.lastSelectionText = ss.data.items[0].data.text
              proj_combo.selectedIndex = 0;
            }
            var ch = Ext.getCmp('view_load_def_proj_check');
            Ext.Ajax.request({
              url: createUrl(slink + 'ListManagementServlet'),
              //waitMsg: 'Waiting...',
              success: function(response){
                //alert("Find Access for: " + proj_combo.getValue() + ":" + response.responseText.trim())
                if (response.responseText.trim() == "Access") {
                  ch.setDisabled(false);
                }
                else {
                  ch.setDisabled(true);
                  ch.setValue(false);
                }
              },
              failure: function(response){
                Ext.MessageBox.show({
                  title: 'Find Access',
                  msg: 'Find Access failed',
                  buttons: Ext.MessageBox.OK,
                  icon: Ext.MessageBox.ERROR
                })
              },
              scope: this,
              params: {
                available_type: 'findAccess',
                session_user: session_user,
                view_project: proj_combo.getValue()
              }
            })
                        
          }
                    
          var c = Ext.getCmp('view_load_def_def_cmpd_list');
          var s = c.getStore();
          if (s.getCount() == 1) {
            c.setValue(s.data.items[0].data.value);
            c.selectedIndex = 0;
          }
                    
                    
                    
        }
      },
      items: [{
        xtype: 'fieldset',
        layout: 'form',
        title: 'Create View',
        autoHeight: true,
        items: [{
          xtype: 'textfield',
          hiddenName: 'view_name',
          name: 'view_name',
          width: 175,
          allowBlank: false,
          fieldLabel: 'View Name (*)'
        }, {
          xtype: 'textarea',
          hiddenName: 'view_description',
          name: 'view_description',
          width: 175,
          fieldLabel: 'View Description',
          autoHeight: true,
          height: 300
        }, new Ext.form.ComboBox({
          autoHeight: true,
          autoLoad: true,
          listWidth: 210,
          width: 175,
          loadingText: 'Loading...',
          fieldLabel: 'Pick Default Compound List (*)',
          hiddenName: 'view_cmpd_default',
          displayField: 'text',
          allowBlank: false,
          valueField: 'value',
          editable: true,
          forceSelection: true,
          typeAhead: true,
          store: selectedCmpdListsStore,
          mode: 'local',
          triggerAction: 'all',
          emptyText: 'Pick Default Compound List...',
          selectOnFocus: true,
          id: 'view_load_def_def_cmpd_list'
                
        }), new Ext.form.ComboBox({
          autoHeight: true,
          autoLoad: true,
          listWidth: 210,
          width: 175,
          loadingText: 'Loading for ...',
          fieldLabel: 'Associate Project (*)',
          hiddenName: 'view_project',
          displayField: 'text',
          allowBlank: false,
          valueField: 'value',
          editable: true,
          forceSelection: true,
          typeAhead: true,
          store: c3_project_store,
          mode: 'local',
          triggerAction: 'all',
          emptyText: 'Select project...',
          selectOnFocus: true,
          id: 'view_load_def_proj',
          minChars: 1,
          listeners: {
            'select': function(c, record, index){
              var val = c.getValue();
              var ch = Ext.getCmp('view_load_def_proj_check');
              /* Check if user can make a view default */
              Ext.Ajax.request({
                            
                url: createUrl(slink + 'ListManagementServlet'),
                success: function(response){
                  if (response.responseText.trim() == "Access") {
                    ch.setDisabled(false);
                  }
                  else {
                    ch.setDisabled(true);
                    ch.setValue(false);
                  }
                },
                failure: function(response){
                  Ext.MessageBox.show({
                    title: 'Find Access',
                    msg: 'Find Access failed',
                    buttons: Ext.MessageBox.OK,
                    icon: Ext.MessageBox.ERROR
                  })
                },
                scope: this,
                params: {
                  available_type: 'findAccess',
                  session_user: session_user,
                  view_project: val
                }
              })
            }
          }
                
        }), {
          xtype: "checkbox",
          fieldLabel: 'Make the view default? ',
          hiddenName: 'view_default',
          name: 'view_default',
          id: 'view_load_def_proj_check',
          disabled: true
                
        }, new Ext.form.ComboBox({
          autoHeight: true,
          fieldLabel: 'Access',
          width: 175,
          listWidth: 210,
          hiddenName: 'view_visibility',
          displayField: 'visibility',
          editable: false,
          valueField: 'visibility',
          store: new Ext.data.SimpleStore({
            fields: ["visibility"],
            autoLoad: true,
            data: [['Public'], ['Private']]
          }),
          typeAhead: true,
          editable: true,
          forceSelection: true,
          allowBlank: false,
          mode: 'local',
          value: 'Private',
          triggerAction: 'all',
          emptyText: 'Select visibility level...',
          selectOnFocus: true,
          tpl: new Ext.XTemplate('<tpl for=".">', '<div class="x-combo-list-item">', '<img src="/aig/img/view_{visibility:lowercase}.gif" align="absmiddle" border=0 style="margin-right:3px">{visibility}</div>', '</tpl>')
        })]
      }]
    })]
  });
    
    
    
  return wizard;
}

function getAliasPanel(view_ids_toload, win){
  var aliasReader = new Ext.data.XmlReader({
    record: 'tr'
  }, [{
    name: 'AliasName',
    mapping: 'td[name="alias_name"] > result > @text_value'
  }, {
    name: 'AliasId',
    mapping: 'td[name="alias_id"] > result > @text_value'
  }, {
    name: 'AliasValue',
    mapping: 'td[name="alias_value"] > result > @text_value'
  }, {
    name: 'created',
    mapping: 'td[name="created"] > result > @text_value'
  }, {
    name: 'View',
    mapping: 'td[name="view_name"] > result > @text_value'
  }, {
    name: 'AssayCategory',
    mapping: 'td[name="category_name"] > result > @text_value'
  }, {
    name: 'ViewId',
    mapping: 'td[name="view_id"] > result > @text_value'
  }, {
    name: 'CategoryId',
    mapping: 'td[name="category_id"] > result > @text_value'
  }])
    
  var aliasStore = new Ext.data.Store({
    reader: aliasReader,
    autoLoad: true,
    //url: '/aig/xmldataproxy.go?src=' + escape(slink + 'AliasManagementServlet'),
    //url: pre + escape(slink + 'AliasManagementServlet'),
    url: createUrl(slink + 'AliasManagementServlet'),
    //url: 'http://ussf-dapp-dweb1.amgen.com:9090/DP_Implemented/AliasManagementServlet',
    baseParams: {
      session_user: session_user,
      available_type: 'get',
      view_list_ids: view_ids_toload
    }
  });
    
  var aliasFilters = new Ext.grid.GridFilters({
    filters: [{
      type: 'string',
      dataIndex: 'View'
    }, {
      type: 'string',
      dataIndex: 'created_by'
    }, {
      type: 'string',
      dataIndex: 'AssayCategory'
    }, {
      type: 'date',
      dataIndex: 'created'
    }],
    local: true,
    autoReload: true
  });
    
  var aliasButtons = [{
    text: 'Save',
    listeners: {
      'click': function(button, e){
        var records = aliasStore.getModifiedRecords();
        var changedValues = "";
        for (i = 0; i < records.length; i++) {
          var record = records[i];
          changedValues = changedValues + record.data.AliasId + "::" + record.data.AliasName + ",";
        }
        if (changedValues.length > 0) {
          changedValues = changedValues.substring(0, changedValues.length - 1);
        }
        //alert("Changed values: " + changedValues);
                
        Ext.Ajax.request({
          //url: "http://ussf-dapp-dweb1.amgen.com:9090/DP_Implemented/AliasManagementServlet",
          //url: '/aig/xmldataproxy.go?src=' + escape(slink + 'AliasManagementServlet'),
          //url: pre + escape(slink + 'AliasManagementServlet'),
          url: createUrl(slink + 'AliasManagementServlet'),
          success: function(response){
            if (response.responseText.trim() == "Passed") {
              //aliasStore.commitChanges();
              aliasStore.reload();
            }
            else {
              Ext.MessageBox.show({
                title: 'Save Alias',
                msg: 'Unable to save alias changes.',
                buttons: Ext.MessageBox.OK,
                icon: Ext.MessageBox.ERROR
              })
            }
          },
          failure: function(response){
            Ext.MessageBox.show({
              title: 'Save Alias',
              msg: 'Unable to save alias changes.',
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
          },
          scope: this,
          params: {
            available_type: 'edit',
            session_user: session_user,
            changedAliases: changedValues
          }
        })
                
                
                
      }
    }
  }, {
    text: 'Cancel',
    listeners: {
      'click': function(button, e){
        button.ownerCt.ownerCt.ownerCt.close();
      }
    }
  }];
    
  var aliasPanel = new Ext.grid.EditorGridPanel({
    store: aliasStore,
    loadMask: {
      msg: 'Loading Aliases'
    },
    columns: [{
      header: 'AliasName',
      width: 150,
      sortable: true,
      dataIndex: 'AliasName',
      editor: new Ext.form.TextField({
        allowBlank: false
      })
    }, {
      header: 'AliasId',
      width: 100,
      hidden: true,
      sortable: true,
      dataIndex: 'AliasId'
    }, {
      header: 'AliasValue',
      id: 'AliasValue',
      width: 150,
      sortable: true,
      dataIndex: 'AliasValue'
    }, {
      header: 'Date',
      width: 80,
      sortable: true,
      dataIndex: 'created'
    }, {
      header: 'View',
      width: 80,
      sortable: true,
      dataIndex: 'View'
    }, {
      header: 'AssayCategory',
      width: 100,
      sortable: true,
      dataIndex: 'AssayCategory'
    }],
    plugins: [aliasFilters],
    autoExpandColumn: 'AliasValue',
    border: true,
    height: 500,
    buttons: aliasButtons,
    buttonAlign: 'center'
  });
  return aliasPanel;
}



function createViewSelectionPanel(win){
  var viewsReader = new Ext.data.XmlReader({
    record: 'elist'
  }, [{
    name: 'name',
    mapping: '@name'
  }, {
    name: 'id',
    mapping: '@id'
  }, {
    name: 'created_by',
    mapping: '@created_by'
  }, {
    name: 'display_name',
    mapping: '@created_by'
  }, {
    name: 'created',
    mapping: '@created',
    type: 'date'
    
  }, {
    name: 'Project',
    mapping: 'tag[@alias_name="PROJECT"] > @project_id'
  }, {
    name: 'Project_id',
    mapping: 'tag[@alias_name="PROJECT"] > @alias_value'
  }, {
    name: 'visibility',
    mapping: '@visibility'
  }, {
    name: 'default',
    mapping: '@default'
  }, {
    name: 'selection',
    mapping: 'false'
  }])
    
  var viewsStore = new Ext.data.Store({
    reader: viewsReader,
    autoLoad: true,
    //url: '/aig/xmldataproxy.go?src=' + escape(slink + 'ListManagementServlet'),
    //url: pre + escape(slink + 'ListManagementServlet'),
    //url: pre + slink + 'ListManagementServlet',
    //url: 'http://ussf-dapp-dweb1.amgen.com:9090/DP_Implemented/ListManagementServlet',
    url: createUrl(slink + 'ListManagementServlet'),
    baseParams: {
      session_user: session_user,
      available_type: 'Views'
    },
    listeners: {
      load: {
        fn: function(store, records, options){
          for (i = 0; i < records.length; i++) {
            var record = records[i];
            record.data.display_name = record.data.created_by.substring(record.data.created_by.indexOf(';') + 1);
            record.data.created_by = record.data.created_by.substring(0, record.data.created_by.indexOf(';'));
          }
                    
        }
      }
    }
    
  });
    
  var viewFilters = new Ext.grid.GridFilters({
    filters: [{
      type: 'string',
      dataIndex: 'name'
    }, {
      type: 'string',
      dataIndex: 'Project'
    }, {
      type: 'string',
      dataIndex: 'created_by'
    }, {
      type: 'list',
      dataIndex: 'default',
      options: [{
        text: 'Default Views',
        id: 'true'
      }, {
        text: 'Other Views',
        id: 'false'
      }]
    }, {
      type: 'date',
      dataIndex: 'created'
    }],
    local: true,
    autoReload: true
  });
    
  var selectColumn = new Ext.grid.CheckboxSelectionModel();
    
  var viewPanel = new Ext.grid.GridPanel({
    region: 'center',
    loadMask: {
      msg: 'Loading Views'
    },
    store: viewsStore,
    border: false,
    columns: [selectColumn, {
      id: 'name',
      header: 'Name',
      width: 150,
      sortable: true,
      dataIndex: 'name'
    }, {
      header: 'Id',
      width: 100,
      hidden: true,
      sortable: true,
      dataIndex: 'id'
    }, {
      header: 'Owner',
      width: 90,
      sortable: true,
      dataIndex: 'display_name'
    }, {
      header: 'Date',
      width: 80,
      sortable: true,
      dataIndex: 'created',
      renderer: Ext.util.Format.dateRenderer('m/d/Y')
    }, {
      header: 'Project',
      width: 80,
      sortable: true,
      dataIndex: 'Project'
    }, {
      header: 'Access',
      width: 60,
      sortable: true,
      dataIndex: 'visibility',
      renderer: function(value, metadata){
        if (value == 'Public') {
          return "<div align='center'><img src='/aig/img/view_public.gif'/></div>"
        }
        else {
          return "<div align='center'><img src='/aig/img/view_private.gif'/></div>"
        }
      }
    }, {
      header: 'Default',
      width: 60,
      sortable: true,
      dataIndex: 'default',
      renderer: function(value, metadata){
        if (value == 'true') {
          return "<div align='center'><img src='/aig/img/small_red_check.gif'/></div>"
        }
      }
    }],
    sm: selectColumn,
    autoExpandColumn: 'name',
    plugins: [viewFilters],
    border: false,
    height: 500,
    title: 'Available Views',
    listeners: {
      rowdblclick: function(grid, row, evt){
        var record = grid.getStore().getAt(row)
        if (record && record.data.Project) {
          win.close.defer(500, win)
          RG.Load.loadEntityList({
            view_id: record.data.id,
            view_type: 'PROJECT_VIEW',
            project: record.data.Project,
            progress_title: 'Opening Project',
            progress_text: 'Opening Project'
          })
        }
      }
    }
  });
    
    
    
  var mainPanel = new Ext.FormPanel({
    width: 600,
    height: 500,
    border: true,
    frame: false,
    layout: 'border',
    //autoScroll: true,
    items: [viewPanel],
    buttons: [{
      text: 'New',
      listeners: {
        'click': function(button, e){
          var records = selectColumn.getSelections();
          if (records.length > 0) {
            var view_ids_touse = "";
            var view_names_touse = "";
            for (i = 0; i < records.length; i++) {
              var record = records[i];
              view_ids_touse = view_ids_touse + record.data.id + ",";
              view_names_touse = view_names_touse + record.data.name + ",";
            }
            if (view_ids_touse.length > 0) {
              view_ids_touse = view_ids_touse.substring(0, view_ids_touse.length - 1);
            }
          }
          else {
          //alert("You have not selected any views to create from or to use as reference");
          }
          var wiz = createWizard(viewsStore, view_ids_touse);
          wiz.show();
        }
      }
    }, {
      text: 'Edit',
      listeners: {
        'click': function(button, e){
          var records = selectColumn.getSelections();
          if (records.length == 1) {
            var record = records[0];
            var view_ids_toedit = record.data.id;
            var view_names_toedit = record.data.name;
            var view_created_by = record.data.created_by;
            if (view_created_by == session_user || session_user == 'jayanthi' || session_user == 'jemcdowe') {
              var wiz = createWizard(viewsStore, "", view_ids_toedit);
              wiz.show();
            } else {
              Ext.MessageBox.show({
                title: 'Edit View',
                msg: 'You are not the owner of the view',
                buttons: Ext.MessageBox.OK,
                icon: Ext.MessageBox.ERROR
              })
            }
          }
          else 
          if (records.length == 0) {
            Ext.MessageBox.show({
              title: 'Change a view',
              msg: 'Please select a view',
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
          }
          else {
            Ext.MessageBox.show({
              title: 'Change a view',
              msg: 'Please select a single view',
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
          }
                    
        }
      }
    }, {
      text: 'Delete',
      listeners: {
        'click': function(button, e){
          var records = selectColumn.getSelections();
          if (records.length > 0) {
            var view_ids_todelete = "";
            var view_names_todelete = "";
            var not_owner = "";
            for (i = 0; i < records.length; i++) {
              var record = records[i];
              if (record.data.created_by != session_user && session_user != 'jayanthi' && session_user != 'jemcdowe') {
                not_owner = not_owner + record.data.name + ",";
              }
              view_ids_todelete = view_ids_todelete + record.data.id + ",";
              view_names_todelete = view_names_todelete + record.data.name + ",";
            }
            if (view_ids_todelete.length > 0) {
              view_ids_todelete = view_ids_todelete.substring(0, view_ids_todelete.length - 1);
              view_names_todelete = view_names_todelete.substring(0, view_names_todelete.length - 1);
            }
                        
            if (not_owner.length > 0) {
              not_owner = not_owner.substring(0, not_owner.length - 1);
                            
              //alert("You have selected to delete the following views: " + view_names_todelete);
              //alert("You have selected to delete the following views: " + view_ids_todelete);
                            
              Ext.MessageBox.show({
                title: 'Edit View',
                msg: 'You are not the owner of the view: ' + not_owner,
                buttons: Ext.MessageBox.OK,
                icon: Ext.MessageBox.ERROR
              })
            }
            else {
                        
              Ext.MessageBox.show({
                title: 'Delete Views',
                msg: 'Do you want to delete the selected views: ' + view_names_todelete + '?',
                //msg: 'Do you want to delete the selected views: ' + view_ids_todelete + '?',
                buttons: Ext.MessageBox.YESNO,
                fn: function(buttonId){
                  if (buttonId != 'yes') {
                    return
                  }
                  Ext.Ajax.request({
                    //url: '/aig/xmldataproxy.go?src=' + escape(slink + 'ListManagementServlet'),
                    //url: pre + escape(slink + 'ListManagementServlet'),
                    url: createUrl(slink + 'ListManagementServlet'),
                    //url: "http://ussf-dapp-dweb1.amgen.com:9090/DP_Implemented/ListManagementServlet",
                    success: function(response){
                      if (response.responseText.trim() == "Passed") {
                        viewsStore.reload();
                      }
                      else {
                        var message = "Unable to delete view.";
                        if (response.responseText.trim().indexOf("View") >= 0) {
                          message = message + response.responseText.trim();
                        }
                        Ext.MessageBox.show({
                          title: 'Save List',
                          msg: message,
                          buttons: Ext.MessageBox.OK,
                          icon: Ext.MessageBox.ERROR
                        })
                      }
                    },
                    failure: function(response){
                      Ext.MessageBox.show({
                        title: 'Save List',
                        msg: 'Unable to save list2.',
                        buttons: Ext.MessageBox.OK,
                        icon: Ext.MessageBox.ERROR
                      })
                    },
                    scope: this,
                    params: {
                      available_type: 'deleteview',
                      session_user: session_user,
                      deleteAliasFlag: 'true',
                      view_ids_todelete: view_ids_todelete
                    }
                  })
                },
                icon: Ext.MessageBox.QUESTION
              })
            }
          }
          else {
            Ext.MessageBox.show({
              title: 'Select view to delete',
              msg: 'Please select a view',
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
          }
        }
      }
    }, {
      text: 'Load As...',
      listeners: {
        menushow: function(button, menu){
          var tableItem = menu.items.find(function(item){
            return (item.text == 'Table')
          }, this)
                    
          var pvItem = menu.items.find(function(item){
            return (item.text == 'Project View')
          }, this)
                    
          var records = selectColumn.getSelections();
          if (records.length == 0 || records.length > 1) {
            tableItem.setDisabled(true)
            //cinfoItem.setDisabled(true)
            pvItem.setDisabled(true)
          }
          else {
            //tableItem.setDisabled(true)
            tableItem.setDisabled((records[0].data.Project ? false : true))
            //cinfoItem.setDisabled(false)
            pvItem.setDisabled((records[0].data.Project ? false : true))
          }
                    
        }
      },
      // Menus can be built/referenced by using nested menu config objects
      menu: {
        items: [{
          text: 'Project View',
          iconCls: 'ix-v0-16-pie-chart_view',
          handler: function(){
            var records = selectColumn.getSelections();
            if (records && records.length == 1 && records[0].data.Project) {
              win.close.defer(500, win)              
              RG.Load.loadEntityList({
                view_id: records[0].data.id,
                view_type: 'PROJECT_VIEW',
                project: records[0].data.Project,
                progress_title: 'Opening Project',
                progress_text: 'Opening Project'
              })
            }
          }
        }, {
          text: 'Table',
          iconCls: 'ix-v0-16-table_sql',
          handler: function(){
            var records = selectColumn.getSelections();
            if (records && records.length == 1) {
              var view_id = records[0].data.id;
              var project = records[0].data.Project
                            
              var compoundListCombo = new Ext.form.ComboBox({
                store: new Ext.data.Store({
                  url: '/aig/entitylist.go',
                  autoLoad: true,
                  baseParams: {
                    op: 'all_compound_lists',
                    view_id: view_id
                  },
                  id: 'compound_list_id',
                  reader: new Ext.data.JsonReader({
                    root: 'CompoundLists'
                  }, Ext.data.Record.create([{
                    name: 'compoundListID',
                    mapping: 'compound_list_id'
                  }, {
                    name: 'compoundListName',
                    mapping: 'compound_list_name'
                  }, {
                    name: 'listType',
                    mapping: 'compound_list_type'
                  }, {
                    name: 'isCurrentList',
                    mapping: 'is_current_list',
                    type: 'boolean'
                  }]))
                }),
                pageData: this.pageData,
                fieldLabel: 'Compound Lists',
                displayField: 'compoundListName',
                valueField: 'compoundListID',
                typeAhead: false,
                editable: false,
                resizable: true,
                mode: 'remote',
                //mode: 'local',
                triggerAction: 'all',
                loadingText: 'Loading Compound Sources...',
                emptyText: 'Select compound list...',
                selectOnFocus: true,
                width: 135,
                listWidth: 500,
                itemSelector: "tr.pv-compoundlist-search-item",
                tpl: new Ext.XTemplate('<table cellspacing="0" class="border:1px solid #BBBBBB;border-collapse:collapse;width:100%">', '<tpl for=".">', 
                  '<tpl if="this.holdListType != values.listType">', 
                  '<tr class="pv-compoundlist-group-header">', 
                  '<tpl exec="this.holdListType = values.listType"></tpl>', 
                  '<tpl if="values.listType==\'VIEW_DATA_TEMPLATE\'">', 
                  '<td colspan="2">View Lists</td>', '</tpl>', 
                  '<tpl if="values.listType==\'SESSION\'">', '<td colspan="2">Temporary Lists</td>', 
                  '</tpl>', '<tpl if="values.listType==\'RESULTNODE\'">', 
                  '<td colspan="2">Data Items</td>', '</tpl>', 
                  '<tpl if="values.listType==\'PRIVATE\'">', '<td colspan="2">Private Lists</td>', 
                  '</tpl>', '<tpl if="values.listType==\'FILTER\'">', '<td colspan="2">Filtered Lists</td>', 
                  '</tpl>', '</tr>', '</tpl>', '<tr class="pv-compoundlist-search-item">', 
                  '<td style="border:1px solid #CCCCCC;border-collapse:collapse;padding:5px;font-family:helvetica,tahoma,verdana,sans-serif;font-size:13px;">', 
                  '<tpl if="values.listType==\'VIEW_DATA_TEMPLATE\'">', 
                  '<img src="/aig/img/launchpad/projectview-topic.gif" align="absmiddle" border=0 style="margin-right:3px">', '</tpl>', 
                  '<tpl if="values.listType==\'SESSION\'">', '<img src="/aig/img/treenodeicons/compounds.gif" align="absmiddle" border=0 style="margin-right:3px">', '</tpl>', 
                  '<tpl if="values.listType==\'RESULTNODE\'">', '<img src="/aig/img/treenodeicons/compounds.gif" align="absmiddle" border=0 style="margin-right:3px">', '</tpl>', 
                  '<tpl if="values.listType==\'PRIVATE\'">', '<img src="/aig/img/compounds_entitylist_16.gif" align="absmiddle" border=0 style="margin-right:3px">', '</tpl>', 
                  '<tpl if="values.listType==\'FILTER\'">', '<img src="/aig/img/filter.gif" align="absmiddle" border=0 style="margin-right:3px">', '</tpl>', 
                  '</td>', '<td nowrap="T" style="border:1px solid #CCCCCC;border-collapse:collapse;padding:5px;font-family:helvetica,tahoma,verdana,sans-serif;font-size:13px;width:100%">', 
                  '<tpl if="values.listType==\'VIEW_DATA_TEMPLATE\'">', '<div ext:qtip="<b>{compoundListName}</b> (View Compound List)">{compoundListName}</div>', '</tpl>', 
                  '<tpl if="values.listType==\'SESSION\'">', '<div ext:qtip="<b>{compoundListName}</b> (Data Item List)">{compoundListName}</div>', '</tpl>', 
                  '<tpl if="values.listType==\'RESULTNODE\'">', '<div ext:qtip="<b>{compoundListName}</b> (Data Item List)">{compoundListName}</div>', '</tpl>', 
                  '<tpl if="values.listType==\'PRIVATE\'">', '<div ext:qtip="<b>{compoundListName}</b> (Private Compound List)">{compoundListName}</div>', '</tpl>', 
                  '<tpl if="values.listType==\'FILTER\'">', '<div ext:qtip="<b>{compoundListName}</b> (Filtered Compound List)">{compoundListName}</div>', '</tpl>', 
                  '</td>', '</tr>', '</tpl></table>'),
                                
                listeners: {
                  beforequery: function(qe){
                  //delete qe.combo.lastQuery;
                  }
                }
              })       
              new AIG.ProjectViewColumnSelectionDialog({
                view_id: view_id,
                parentWindow: win,
                sourceURL: slink + 'datasourceservlet',
                compoundSourceCB: compoundListCombo,
                callback: function(values){
                  RG.Load.loadEntityList({
                    view_id: view_id,
                    view_type: 'ENTITY_TABLE',
                    project: project,
                    progress_title: 'Opening Project',
                    progress_text: 'Opening Project',
                    params: values
                  })
                }
              }).show()
                            
            }
          }
        }]
      }
    }, {
      text: 'Add To Favorites',
      handler: function(){
        var records = selectColumn.getSelections();
        if (records.length != 1) {
          Ext.MessageBox.show({
            title: 'Add To Favorites',
            msg: 'Please select a view',
            buttons: Ext.MessageBox.OK,
            icon: Ext.MessageBox.ERROR
          })
          return
        }
        var favoriteKey = {
          viewID: records[0].data.id,
          project: records[0].data.Project
        }
        RG.Favorites.createFavorite({
          name: favoriteKey.project + ' Project View',
          description: favoriteKey.project + ' Project View',
          type: 'PROJECTVIEW',
          key: Ext.util.JSON.encode(favoriteKey)
        })
      },
      scope: this
    }, {
      text: 'My Aliases',
      listeners: {
        'click': function(button, e){
          var records = selectColumn.getSelections();
          var view_ids_toload = "";
          var view_names_toload = "";
          if (records.length > 0) {
            for (i = 0; i < records.length; i++) {
              var record = records[i];
              view_ids_toload = record.data.id;
              view_names_toload = record.data.name;
            }
          }
          var win = new Ext.Window({
            width: 600,
            height: 300,
            title: "My Aliases",
            layout: 'fit',
            resizable: false,
            constrain: true,
            buttonAlign: 'center',
            items: getAliasPanel(view_ids_toload, win)
          })
          win.show();
        }
      }
    }, {
      text: 'Cancel',
      listeners: {
        'click': function(button, e){
          win.close();
        }
      }
    }]
    
  });
  return mainPanel;
}


