/**
 * @author jemcdowe
 */
AIG.FeedViewer = function(config){
    Ext.apply(this, config);
    Ext.apply(this, {
        enableHdMenu: false,
        enableColumnHide: false,
        enableColumnMove: false
    })
    this.channel = config.channel
    
    this.store = new Ext.data.GroupingStore({
        autoLoad: true,
        groupField: 'channel',
        sortInfo: {
            field: "pubDate",
            direction: "DESC"
        },
        url: '/aig/channel.go',
        baseParams: {
            channel: config.channel
        },
        reader: new Ext.data.XmlReader({
            record: 'item'
        }, [{
            name: 'id',
            mapping: '@id'
        }, {
            name: 'channel',
            mapping: '@channel'
        }, {
            name: 'type',
            mapping: '@type',
            defaultValue: 'rss'
        }, {
            name: 'link',
            mapping: 'link'
        }, {
            name: 'title'
        }, {
            name: 'author'
        }, {
            name: 'sharedWith'
        }, {
            name: 'pubDate',
            type: 'date',
            convert: function(value){
                if (!value) {
                    return '';
                }
                //value = value.replace(/ [Etc\/]*GMT$/, '')
                var date = Date.parseDate(value, "D, j M Y H:i:s T");
                if (date === null || date === undefined) {
                    date = new Date(value)
                }
                return (date || value)
            }
        }, {
            name: 'description'
        }, {
            name: 'content'
        }])
    });
    this.store.setDefaultSort('pubDate', "DESC");
    
    this.columns = [{
        id: 'channel',
        header: 'Source',
        dataIndex: 'channel',
        hidden: true,
        sortable: true,
        width: 100
    }, {
        id: 'title',
        header: "Title",
        dataIndex: 'title',
        sortable: true,
        width: 420,
        renderer: function(value, p, record){
            var sharedLabel = (config.channel == 'favorites' && hasLength(record.data.sharedWith) ? " (Shared)" : "");
            if (record.data.type) {
                return String.format('<div class="' + record.data.type.toLowerCase() + '-topic"><b>{0}{2}</b><BR><span class="author">{1}</span></div>', value, record.data.author, sharedLabel, record.id, record.data.forumid);
            } else {
                return String.format('<div class="' + config.channel + '-topic"><b>{0}</b><BR>{2}<span class="author">{1}</span></div>', value, record.data.author, sharedLabel, record.id, record.data.forumid);
            }
        }
    }, {
        header: "Author",
        dataIndex: 'author',
        width: 100,
        hidden: true,
        sortable: true
    }, {
        id: 'last',
        header: "Date",
        dataIndex: 'pubDate',
        width: 150,
        renderer: function(date){
            if (!date) {
                return '';
            }
            var now = new Date();
            var d = now.clearTime(true);
            var notime = date.clearTime(true).getTime();
            if (notime == d.getTime()) {
                return 'Today ' + date.dateFormat('g:i A T');
            }
            return date.dateFormat('m/d/Y g:i A T');
        },
        sortable: true
    }];
    
    AIG.FeedViewer.superclass.constructor.call(this, {
        loadMask: {
            msg: 'Loading ' + config.title + '...'
        },
        sm: new Ext.grid.RowSelectionModel({
            singleSelect: true
        }),
        view: new Ext.grid.GroupingView({
            forceFit: true,
            groupOnSort: true,
            enableRowBody: true,
            showPreview: true,
            getRowClass: this.applyRowClass,
            enableGroupingMenu: false,
            groupTextTpl: '<span class="' + config.channel + '-section">{group} ({[values.rs.length]} {[values.rs.length > 1 ? "Items" : "Item"]})</span>'
        })
    })
    this.on('rowclick', this.onRowClick, this);
};
Ext.extend(AIG.FeedViewer, Ext.grid.GridPanel, {
    onRowClick: function(grid, index, e){
        this.ctxRow = this.view.getRow(index);
        this.ctxRecord = this.store.getAt(index);
        if (!this.ctxRecord.data.link || !this.ctxRecord.data.type) {
            return
        }
        this.openItem(this.ctxRecord)
    },
    openItem: function(ctxRecord){
        switch (ctxRecord.data.type.toUpperCase()) {
            case 'RSS':
                window.open(ctxRecord.data.link)
                break
        }
    },
    // within this function "this" is actually the GridView
    applyRowClass: function(record, rowIndex, p, ds){
        if (this.showPreview) {
            var xf = Ext.util.Format;
            p.body = '<p class="feed-grid-row-body">' + xf.ellipsis(xf.stripTags(record.data.description), 200) + '</p>';
            return 'x-grid3-row-expanded';
        }
        return 'x-grid3-row-collapsed';
    }
});
