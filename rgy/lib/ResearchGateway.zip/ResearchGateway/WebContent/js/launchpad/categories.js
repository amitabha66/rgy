var session_user = 'jayanthi';
var a_version = 'DEV';
var slink = '';
var link = '';
var pre = '';
var pos = '';
var local = true;

session_user = AIG.USER_SESSION_INFO.LOGIN;
a_version = AIG_VERSION;
pre = '/aig/xmldataproxy.go?src=';
local = false;

if (a_version == "DEV") {
	slink = 'http://uslv-dapp-rgb01.amgen.com:9090/DP_Implemented/';
	link = 'http://uslv-dapp-rgb01.amgen.com:9090/';	
}
else {
	if (a_version == "TEST") {
		slink = 'http://uslv-tapp-rgb01.amgen.com:9090/DP_Implemented/';
		link = '/';
	}
	else {
		slink = 'http://uslv-papp-rgb02.amgen.com:9090/DP_Implemented/';
		link = '/';
	}	
}

function createUrl(link){
    if (local) {
        return link;
    }
    else {
        return pre + escape(link);
    }
}

ListLoader = Ext.extend(Ext.ux.XmlTreeLoader, {
    processAttributes: function(attr){
    
        if (attr.category == "VIEWS") {
            attr.display_name = attr.created_by.substring(attr.created_by.indexOf(';') + 1);
            attr.created_by = attr.created_by.substring(0, attr.created_by.indexOf(';'));
            attr.text = attr.name + '(Project=' + attr.type + '; Owner=' + attr.created_by + ')';
            attr.leaf = false;
            attr.edit = false;
            attr.loaded = true;
            attr.expanded = false;
            attr.draggable = false;
            attr.allowDrop = false;
            
            
            if ((attr.type == 'PKDM' || attr.type == 'Research Gateway' || attr.type == 'RG') && attr["default"] == 'true') {
                attr.iconCls = 'vl-reference_view'
                attr.cls = "vl-reference_view-text"
            }
            else 
                if (attr["default"] == "true") {
                    attr.iconCls = 'vl-view'
                    attr.cls = "vl-default_view-text"
                }
                else {
                    attr.iconCls = 'vl-view'
                }
        }
        else 
            if (attr.category == "ASSAYS") {
                if (attr.local_name == attr.name) {
                    attr.text = attr.name;
                }
                else {
                    attr.text = attr.local_name;
                }
                attr.name = attr.name;
                attr.loaded = true;
                attr.expanded = false;
                attr.leaf = false;
                attr.value = attr.value;
                attr.list_id = attr.id;
                attr.local_id = attr.local_id;
                attr.local_name = attr.local_name;
                attr.display_name = attr.created_by.substring(attr.created_by.indexOf(';') + 1);
                attr.created_by = attr.created_by.substring(0, attr.created_by.indexOf(';'));
                
                attr.order = attr.display_order;
                
                if (attr.usedFrom == "true") {
                    attr.usedFrom = true;
                }
                else {
                    attr.usedFrom = false;
                }
                if (attr.usedBy == "true") {
                    attr.usedBy = true;
                }
                else {
                    attr.usedBy = false;
                }
                if (attr.text.indexOf('->LINK') > 0) {
                    attr.draggable = false;
                }
                
                attr.edit = false;
                attr.allowDrop = false;
                attr.iconCls = 'assaysNode'
            }
            else 
                if (attr.member_type == "ALIAS") {
                    if (attr.alias_name.match("AA\\d+")) {
                        attr.text = attr.alias_value;
                    }
                    else {
                        attr.text = attr.alias_name + " : " + attr.alias_value;
                    }
                    attr.alias_name = attr.alias_name;
                    attr.alias_value = attr.alias_value;
                    attr.aggregate = (attr.aggregate == '1');
                    attr.force_display = (attr.force_display == '1');
                    attr.alias_id = attr.alias_id;
                    attr.member_id = attr.member_id;
                    attr.iconCls = 'assayNode'
                    attr.leaf = true;
                    attr.edit = false;
                    attr.draggable = false;
                    attr.allowDrop = false;
                }
    }
});

function getAssayNode(node, curChildNode){
    var curr_alias_id = undefined
    var curr_assay_id = undefined
    var curr_alias = undefined
    var curr_aggregate = undefined
    var curr_force_display = undefined
    
    if (curChildNode && curChildNode.attributes.alias_id.length > 0) {
        curr_alias_id = curChildNode.attributes.alias_id;
        curr_alias = curChildNode.attributes.alias_name;
        curr_aggregate = curChildNode.attributes.aggregate;
        curr_force_display = curChildNode.attributes.force_display;
    }
    else 
        if (curChildNode && curChildNode.attributes.alias_value.length > 0) {
            //SEND <AssayID>:[<ResultType>,<ResultType>] FOR EDITING AN ASSAY w/o AN ALIAS
            curr_assay_id = curChildNode.attributes.alias_value;
            curr_alias = curChildNode.attributes.alias_name;
            curr_aggregate = curChildNode.attributes.aggregate;
            curr_force_display = curChildNode.attributes.force_display;
        }
    
    var edit = curr_alias_id || curr_assay_id
    
    var dialog = new Ext.Window({
        title: (curr_alias_id || curr_assay_id ? 'Edit Assay' : 'Add Assay(s)'),
        iconCls: 'add-column',
        layout: 'border',
        width: 725,
        height: 300,
        stateful: false,
        resizable: false,
        closeAction: 'hide',
        plain: true,
        items: [new AIG.AssaySelectorField({
            region: 'center',
            show_alias: true,
            editor: true,
            show_alias: true,
            aggregate: curr_aggregate,
            force_display: curr_force_display,
            alias: curr_alias,
            title: null,
            show_aggregate: true,
            show_force_display: true,
            
            show_only_assaycodes: false,
            alias_id: curr_alias_id,
            assay_id: curr_assay_id
           
            
        })],
        buttons: [{
            text: 'OK',
            handler: function(){
                var assaySelector = dialog.getComponent(0)
                var assaySelections = assaySelector.getAssays()
                if (assaySelections.length == 0) {
                    Ext.Msg.alert('Problem', 'Please select at least one assay')
                    return
                }
                dialog.hide();
                dialog = null
                Ext.each(assaySelections, function(assay){
                    //should read assay.modified for edit implementations
                    var alias_id = "";
                    var display_name = "";
                    if (assay.alias_id != null && assay.alias_id != "undefined" && assay.alias_id.length > 0) {
                        alias_id = assay.alias_id;
                    }
                    var alias_name = assay.assay_alias;
                    var alias_value = assay.assay_code + ":" + assay.result_types;
                    if (alias_name == null || alias_name == "undefined") {
                        alias_name = assay.assay_code;
                        display_name = assay.assay_code + ":" + assay.result_types;
                    }
                    else {
                        if (alias_name.match("^AA[0-9]+$")) {
                            display_name = alias_value;
                        }
                        else {
                            display_name = alias_name + " : " + alias_value;
                        }
                    }
                    
                    
                    var childNode = new Ext.tree.TreeNode({
                        text: display_name,
                        iconCls: 'assayNode',
                        leaf: true,
                        alias_name: alias_name,
                        alias_id: alias_id,
                        alias_value: alias_value,
                        aggregate: assay.aggregate,
                        force_display: assay.force_display,
                        edit: true
                    });
                    childNode.setText(display_name);
                    if (curChildNode) {
                        node.replaceChild(childNode, curChildNode)
                    }
                    else {
                        node.appendChild(childNode)
                    }
                    
                    //Ext.Msg.alert('Test', node.attributes.name + ";" + node.attributes.text + ";" + node.attributes.edit + ";" + node.attributes.copied);
                    if (node.attributes.name.indexOf('->LINK') > 0) {
                        node.attributes.name = node.attributes.name.substring(0, node.attributes.name.indexOf('->LINK'));
                    }
                    if (node.attributes.copied != "undefined" && node.attributes.copied == true) {
                        node.attributes.copied = false;
                        node.attributes.list_id = "";
                        node.attributes.local_id = "";
                    }
                    node.attributes.edit = true;
                    node.attributes.text = node.attributes.name;//changing node name from link to orig since there is some change					
                    node.setText(node.attributes.name);
                    node.expand(true)
                })
            },
            scope: this
        }, {
            text: 'Cancel',
            handler: function(){
                dialog.hide();
                dialog = null
            }
        }]
    });
    dialog.show();
}

/*
 function getViewType(record, win){
 var viewTypeStore;
 var project = record.data.Project;
 if (project != null && project != "undefined" && project.length > 0) {
 viewTypeStore = new Ext.data.SimpleStore({
 fields: ["value", "text"],
 data: [["ENTITY_TABLE", "SAR Table"], ["COMPOUND_INFO_VIEW", "Compound & Assay Information"], ["PROJECT_VIEW", "Project"]]
 });
 }
 else {
 viewTypeStore = new Ext.data.SimpleStore({
 fields: ["value", "text"],
 data: [["ENTITY_TABLE", "SAR Table"], ["COMPOUND_INFO_VIEW", "Compound & Assay Information"]]
 });
 }
 
 var views = new Ext.form.ComboBox({
 name: 'view_type',
 allowBlank: false,
 autoHeight: true,
 autoLoad: true,
 listWidth: 310,
 hideLabel: true,
 displayField: 'text',
 editable: false,
 valueField: 'value',
 store: viewTypeStore,
 typeAhead: true,
 mode: 'local',
 forceSelection: true,
 triggerAction: 'all',
 emptyText: 'Select a view type...',
 selectOnFocus: true
 
 });
 
 var dialog = new Ext.Window({
 title: 'Choose View',
 iconCls: 'add-column',
 layout: 'fit',
 width: 400,
 height: 200,
 stateful: false,
 resizable: false,
 closeAction: 'hide',
 plain: true,
 items: [views],
 buttons: [{
 text: 'OK',
 handler: function(){
 var combo = dialog.getComponent(0)
 var index = (combo.selectedIndex) * 1;
 if (index >= 0) {
 var view_type = combo.store.data.items[index].data.value;
 var view_display = combo.store.data.items[index].data.text;
 dialog.hide();
 dialog = null;
 win.close();
 AIG.loadEntityList({
 view_id: record.data.id,
 view_type: view_type,
 project: record.data.Project,
 progress_title: 'Opening ' + view_display,
 progress_text: 'Opening ' + view_display
 });
 }
 else {
 Ext.Msg.alert('Problem', 'Please select a view type')
 return
 }
 },
 scope: this
 }, {
 text: 'Cancel',
 handler: function(){
 dialog.hide();
 dialog = null
 }
 }]
 });
 dialog.show();
 
 }
 */
function getNameForNode(node, action, current_value, view_ids_toedit){
    if (current_value == null || current_value == "undefined") {
        current_value = "";
    }
    
    if (current_value.indexOf('->LINK') > 0) {
        current_value = current_value.substring(0, current_value.indexOf('->LINK'));
    }
    
    Ext.Msg.prompt('Enter a Name', 'Name:', function(btn, text){
        if (btn == 'ok' && text.length > 0) {
            //Ext.Msg.alert('Test', node.attributes.name + ";" + node.attributes.text + ";" + node.attributes.edit + ";" + node.attributes.copied);
            switch (action) {
                case "add":
                    var childNode = new Ext.tree.TreeNode({
                        text: text,
                        name: text,
                        iconCls: 'assaysNode',
                        leaf: false,
                        expandable: true,
                        allowDrop: false,
                        expanded: true,
                        edit: true
                    })
                    node.appendChild(childNode)
                    node.attributes.edit = true;
                    childNode.attributes.text = text;
                    childNode.attributes.edit = true;
                    childNode.attributes.name = text;
                    childNode.attributes.category = 'ASSAYS'
                    break
                case "rename":
                    if (node.attributes.copied != "undefined" && node.attributes.copied == true) {
                        node.attributes.copied = false;
                        node.attributes.list_id = "";
                        node.attributes.local_id = "";
                    }
                    
                    if (view_ids_toedit != null && view_ids_toedit != "undefined" && view_ids_toedit.length > 0 &&
                    node.attributes.local_id.length > 0) {
                        node.attributes.name = text;
                        node.attributes.edit = true;
                        node.attributes.text = node.attributes.name;//changing node name from link to orig since there is some change					
                        node.setText(node.attributes.name);
                    }
                    else {
                        node.attributes.name = text;
                        node.attributes.edit = true;
                        node.attributes.text = node.attributes.name;//changing node name from link to orig since there is some change					
                        node.setText(node.attributes.name);
                    }
                    break
            }
            //Ext.Msg.alert('Test', node.attributes.name + ";" + node.attributes.text + ";" + node.attributes.edit+ ";" + node.attributes.copied);
        }
    }, this, false, current_value)
}

function assaysSave(targetRoot, sourceRoot){
    while (targetRoot.lastChild != null) {
        targetRoot.lastChild.remove()
    }
    if (sourceRoot.hasChildNodes()) {
        sourceRoot.eachChild(function(categoryNode){
            var cat_copy = new Ext.tree.TreeNode(Ext.apply({}, categoryNode.attributes));
            //Ext.log("categoryNode: " + categoryNode.attributes.order + " : assaySource: " + cat_copy.attributes.order);
            targetRoot.appendChild(cat_copy);
            
            if (categoryNode.hasChildNodes()) {
                categoryNode.eachChild(function(assayNode){
                    var assay_copy = new Ext.tree.TreeNode(Ext.apply({}, assayNode.attributes));
                    assay_copy.draggable = false;
                    cat_copy.appendChild(assay_copy);
                });
            }
        });
    }
    if (targetRoot.childNodes.length == 0) {
        return false;
    }
    else {
        targetRoot.expand()
        return true;
    }
}



function compoundsSave(panel, root, selectedCmpdListsStore, c3_project_store){
    categoryOutput = "";
    categoryOutput = appendCategories(root);
    //Ext.log("categoryOutput: " + categoryOutput);
    compoundOutput = "";
    compoundOutput = appendCompounds(panel, selectedCmpdListsStore, c3_project_store);
    
    return categoryOutput;
}

function appendCategories(root){
    var output = "";
    if (root.hasChildNodes()) {
        root.eachChild(function(category){
            if (category.hasChildNodes()) {
                output = output +
                "category[attributes{" +
                "id:" +
                category.attributes.list_id +
                "," +
                "edit:" +
                category.attributes.edit +
                "," +
                "copied:" +
                category.attributes.copied +
                "," +
                "local_id:" +
                category.attributes.local_id +
                "," +
                "usedFrom:" +
                category.attributes.usedFrom +
                "," +
                "usedBy:" +
                category.attributes.usedBy +
                "," +
                "order:" +
                category.attributes.order +
                "," +
                "name:" +
                category.attributes.name +
                "}"
                category.eachChild(function(assay){
                    output = output +
                    "assays{" +
                    "alias_id:" +
                    assay.attributes.alias_id +
                    "," +
                    "member_id:" +
                    assay.attributes.member_id +
                    "," +
                    "alias_name:" +
                    assay.attributes.alias_name +
                    "," +
                    "alias_value:" +
                    assay.attributes.alias_value +
                    "," +
                    "aggregate:" +
                    assay.attributes.aggregate +
                    "," +
                    "force_display:" +
                    assay.attributes.force_display +
                    "," +
                    "edit:" +
                    assay.attributes.edit +
                    "}"
                });
                output = output + "],";
            }
            else {
            }
        });
    }
    else {
    }
    //Ext.log(output);
    return output;
}

function appendCompounds(panel, selectedCmpdListsStore, c3_project_store){
    var items = panel.items.items;
    var output = "";
    var selectedCmpdLists = "";
    var map = new Object();
    selectedCmpdListsStore.removeAll();
    
    var inputSources = [panel.find('name', 'n_pv_clist_c_reg')[0], panel.find('name', 'n_pv_clist_vqt')[0], panel.find('name', 'n_pv_clist_mylist')[0], panel.find('name', 'assay_compound_categories')[0], panel.find('name', 'n_pv_clist_pasted')[0]]
    
    output = output + "compounds[attributes{"
    var nrecord = Ext.data.Record.create({
        name: 'value'
    }, {
        name: 'text'
    });
    
    var v_p_s_r = Ext.data.Record.create({
        name: 'Label'
    }, {
        name: 'Value'
    });
    
    Ext.each(inputSources, function(inputSource){
    
        switch (inputSource.name) {
            case 'n_pv_clist_c_reg':
                if (inputSource.items && inputSource.items.length > 0) {
                    c3_project_store.removeAll()
                    var displayTextArr = [];
                    var valueTextArr = [];
					var value_displayArr=[];
                    inputSource.items.each(function(item){
                        displayTextArr.push(item.display);
                        valueTextArr.push(item.value);
						value_displayArr.push(item.value + "___" + item.display)
                        c3_project_store.add(new nrecord({
                            value: item.value,
                            text: item.display
                        }));
                        
                    });
                    var displayText = displayTextArr.join(inputSource.valueDelimiter);
                    var valueText = valueTextArr.join(inputSource.valueDelimiter);
					var valueDisplayText = value_displayArr.join(inputSource.valueDelimiter);
                    
                    
                    output = output + inputSource.hiddenName + ":" + valueDisplayText + ",";
                    selectedCmpdListsStore.add(new nrecord({
                        value: 'n_pv_clist_c_reg_' + valueText,
                        text: 'Compounds Registered:' + displayText
                    }));
                    
                    
                }
                else {
                    output = output + inputSource.hiddenName + ":" + ",";
                }
                
                break
            case 'n_pv_clist_vqt':
                if (inputSource.items && inputSource.items.length > 0) {
                    var displayTextArr = [];
                    var valueTextArr = [];
					var value_displayArr=[];
                    inputSource.items.each(function(item){
                        displayTextArr.push(item.display);
                        valueTextArr.push(item.value);
						value_displayArr.push(item.value + "___" + item.display)
                        selectedCmpdListsStore.add(new nrecord({
                            value: 'n_pv_clist_vqt_' + item.value,
                            text: 'VQT Queries: ' + item.display
                        }));
                    });
                    var displayText = displayTextArr.join(inputSource.valueDelimiter);
                    var valueText = valueTextArr.join(inputSource.valueDelimiter);
					var valueDisplayText = value_displayArr.join(inputSource.valueDelimiter);
                    output = output + inputSource.hiddenName + ":" + valueDisplayText + ",";
                    
                }
                else {
                    output = output + inputSource.hiddenName + ":" + ",";
                }
                break
                
            case 'n_pv_clist_mylist':
                
                if (inputSource.items && inputSource.items.length > 0) {
                    var displayTextArr = [];
                    var valueTextArr = [];
					var value_displayArr=[];
                    inputSource.items.each(function(item){
                        displayTextArr.push(item.display);
                        valueTextArr.push(item.value);
						value_displayArr.push(item.value + "___" + item.display)
                        selectedCmpdListsStore.add(new nrecord({
                            value: 'n_pv_clist_mylist_' + item.value,
                            text: 'My Lists: ' + item.display
                        }));
                    });
                    var displayText = displayTextArr.join(inputSource.valueDelimiter);
                    var valueText = valueTextArr.join(inputSource.valueDelimiter);
					var valueDisplayText = value_displayArr.join(inputSource.valueDelimiter);
                    output = output + inputSource.hiddenName + ":" + valueDisplayText + ",";
                    
                }
                else {
                    output = output + inputSource.hiddenName + ":" + ",";
                }
                break
                
            case 'assay_compound_categories':
                var actualItemRoot = inputSource.root;
                var res = appendCategories(actualItemRoot);
                //Ext.log("Assay Cat: " + res);
                output = output + inputSource.name + ":" + res + ",";
                if (res != "undefined" && res.length > 0) {
                    selectedCmpdListsStore.add(new nrecord({
                        value: 'assay_compound_categories',
                        text: 'Compounds driven by assays'
                    }));
                }
                break
            case 'n_pv_clist_pasted':
                output = output + inputSource.name + ":" + inputSource.getValue() + "";
                if (inputSource.getValue() != "undefined" && inputSource.getValue().length > 0) {
                    selectedCmpdListsStore.add(new nrecord({
                        value: 'pasted_compounds',
                        text: 'Compounds Pasted'
                    }));
                }
                break
        }
        
        
    }, this);
    
    
    
    
    output = output + "}]";
    return output;
}


function viewSave(panel){
    viewOutput = "";
    var items = panel.items.items;
    viewOutput = viewOutput + "view[attributes{";
    
    for (i = 0; i < items.length; i++) {
        var parentItem = items[i].items.items;
        for (j = 0; j < parentItem.length; j++) {
            var actualItem = parentItem[j];
            if (actualItem.id == "view_load_def_proj") {				
				viewOutput = viewOutput + actualItem.hiddenName + ":" + actualItem.value+ "___" + actualItem.lastSelectionText + ",";
            }
            else if (actualItem.name == "view_cmpd_default" || actualItem.name == "view_visibility") {
                viewOutput = viewOutput + actualItem.hiddenName + ":" + actualItem.getValue() + ",";
            }
            else {
                viewOutput = viewOutput + actualItem.hiddenName + ":" + actualItem.getValue() + ",";
            }
        }
    }
    viewOutput = viewOutput + "}]";
    return categoryOutput + compoundOutput + viewOutput;
}



