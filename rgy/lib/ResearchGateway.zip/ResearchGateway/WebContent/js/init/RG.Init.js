/**
 * @version $Id: RG.Init.js,v 1.16 2015/09/02 23:38:06 jemcdowe Exp $
 * 
 * RG.Init: Initializes the RG system primarily the required Ext namespaces
 */
document.domain = 'amgen.com'

Ext.BLANK_IMAGE_URL = 'http://rg-resources/img/s.gif';


Ext.ns("AIG", "AIG.query", "AIG.Security", "AIG.Favorites", "RG.Favorites", "AIG.DataItems", 'AIG.ProjView');

Ext.ns("RG", 'RG.Geometry', 'RG.Icon', 'RG.Dialog', 'RG.Record', 'RG.Loft', 'RG.Lists', 'RG.Form', 'RG.Service', 'RG.Widget', 'RG.Main', 'RG.rx', 'RG.Load', 'RG.Node', 'RG.EntityTable')

Ext.ns('Ext.rx', 'Ext.rx.form')

