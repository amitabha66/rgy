/**
 * Grid used to display entity properties
 *
 *
 * @author    J. McDowell
 * @date      23 March 2009
 * @version   $Id: EntityPropertyGrid.js,v 1.10 2013/10/18 21:45:48 jemcdowe Exp $
 *
 */
AIG.EntityPropertyGrid = Ext.extend(Ext.grid.GridPanel, {
  autoExpandColumn: 'Value',
  enableHdMenu: false,
  enableColumnMove: false,
  disableSelection: true,
  trackMouseOver: false,
  cls: 'wrapcell',
  disableExportMenu: true,
    
  initComponent: function(){
    var grid = this
        
    var gridConfig = {
      hideHeaders: this.hideHeaders || false
    }
    gridConfig.loadMask = (Ext.type(this.initialConfig.loadMask) == 'boolean' ? this.initialConfig.loadMask : true)
    gridConfig.view = new Ext.grid.GroupingView({
      forceFit: true,
      autoFit: true,
      groupTextTpl: '{group}'
    })
        
    var reader = (this.json ? new Ext.data.JsonReader({
      root: "Properties"
    }, [{
      name: 'Name',
      mapping: 'name',
      sortable: false,
      sortType: 'none'
    }, {
      name: 'Value',
      mapping: 'value',
      sortable: false
    }, {
      name: 'Format',
      mapping: 'format',
      sortable: false
    }, {
      name: 'Type',
      mapping: 'type',
      sortable: false
    }, {
      name: 'Color',
      mapping: 'color',
      sortable: false
    }, {
      name: 'ImageURL',
      mapping: 'imageURL',
      sortable: false
    }, {
      name: 'LinkURL',
      mapping: 'linkURL',
      sortable: false
    }, {
      name: 'QTipImageURL',
      mapping: 'qtipImageURL',
      sortable: false
    }, {
      name: 'Category',
      mapping: 'category',
      sortable: false,
      defaultValue: 'Properties'
    }, {
      name: 'Order',
      mapping: 'order',
      type: 'int',
      sortable: false
    }]) : new Ext.data.XmlReader({
      record: 'Property'
    }, [{
      name: 'Name',
      mapping: '@name',
      sortable: false,
      sortType: 'none'
    }, {
      name: 'Value',
      mapping: '@value',
      sortable: false
    }, {
      name: 'Type',
      mapping: '@type',
      sortable: false
    }, {
      name: 'Format',
      mapping: '@format',
      sortable: false
    }, {
      name: 'Color',
      mapping: '@color',
      sortable: false
    }, {
      name: 'ImageURL',
      mapping: '@imageURL',
      sortable: false
    }, {
      name: 'LinkURL',
      mapping: '@linkURL',
      sortable: false
    }, {
      name: 'QTipImageURL',
      mapping: '@qtipImageURL',
      sortable: false
    }, {
      name: 'Category',
      mapping: '@category',
      sortable: false,
      defaultValue: 'Properties'
    }, {
      name: 'Order',
      mapping: '@order',
      type: 'int',
      sortable: false
    }]))
        
    gridConfig.store = new Ext.data.GroupingStore({
      // load using HTTP
      url: this.url || '/aig/entitydetailshandler.go',
      autoLoad: this.autoLoadStore || false,
      baseParams: this.params,
      groupField: 'Category',
      sortInfo: {
        field: 'Category'
      },
      remoteGroup: false,
      remoteSort: true,
      // the return will be XML, so lets set up a reader
      reader: reader,
      listeners: {
        load: function(a, b, c) {
          //dedee
        }
      }
    })
            
    
    gridConfig.columns = [{
      id: "Name",
      header: "Name",
      dataIndex: 'Name',
      sortable: false,
      renderer: function(value, metadata, record, rowIndw, colIndex, store){
        return AIG.propertyGridRender(value, null, null, metadata, record, rowIndw, colIndex, store, null, null, true)
      }
    }, {
      id: "Value",
      header: "Value",
      dataIndex: 'Value',
      sortable: false,
      renderer: function(value, metadata, record, rowIndw, colIndex, store){
        return AIG.propertyGridRender(value, null, null, metadata, record, rowIndw, colIndex, store)
      }
    }, {
      id: "Category",
      header: "Category",
      dataIndex: 'Category',
      sortable: false,
      hidden: true
        
    }, {
      id: "Order",
      header: "Order",
      dataIndex: 'Order',
      sortable: false,
      hidden: true
    }]
    this.on('cellcontextmenu', function(grid, rowIndex, cellIndex, evt){
      if (evt.hasModifier()) {
        return
      }
      evt.preventDefault()
      evt.stopPropagation()
      var store = grid.getStore()
      var cm = grid.getColumnModel()
      var record = store.getAt(rowIndex)
      if (record.data.Type && record.data.Type == 'structure') {
        grid.menudata = {
          rowIndex: rowIndex
        }
        if (!grid.structuremenu) {
          grid.structuremenu = top.AIG.StructureMenu.addStructureSubmenu(new Ext.menu.Menu({
            items: [{
              text: 'Export To Excel',
              icon: '/aig/img/document_icons/excel.gif',
              handler: function(){
                AIG.excelExporter(grid, false)
              }
            }]
          }), function(){
            var store = grid.getStore()
            var cm = grid.getColumnModel()
            var record = store.getAt(grid.menudata.rowIndex)
            var title = null
            var db = null
            if (record.data.Category == 'Compound' || record.data.Category == 'ACRF Compound') {
              db = 'acrf'
              title = 'Compound ' + record.data.Value
            } else if (record.data.Category.indexOf('Component') > 0) {
              db = 'acrfcomponent'
              title = 'Structure Details for ' + record.data.Category
            } else {
              return null
            }
            return {
              db: db,
              id: record.data.Value,
              title: title
            }
          }, grid)
        }
        grid.structuremenu.showAt(evt.getXY())
      } else if (Ext.type(grid.contextMenuHandler) == 'function') {
        grid.contextMenuHandler.call(grid.contextMenuScope, grid, record, rowIndex, cellIndex, evt)
      } else {
        grid.showGridValueMenu(grid, rowIndex, cellIndex, evt)
      }
    })

    this.on('cellclick', function(grid, rowIndex, cellIndex, evt){
      var store = grid.getStore()
      var record = store.getAt(rowIndex)
      if (!record.data.Type || record.data.Type!= 'structure') {
        return
      }
      if (evt.hasModifier()) {
        return
      }
      evt.preventDefault()
      evt.stopPropagation()
      var db = null
      var title = null
      if (record.data.Category == 'Compound' || record.data.Category == 'ACRF Compound') {
        db = 'acrf'
        title = 'Compound ' + record.data.Value
      } else if (record.data.Category.indexOf('Component') > 0) {
        db = 'acrfcomponent'
        title = 'Structure Details for ' + record.data.Value
      } else {
        return 
      }
      
      AIG.StructureMenu.showEntityDetails({
        db: db,
        id: record.data.Value,
        title: title
      })
    })        
        
    Ext.apply(this, gridConfig)
    AIG.EntityPropertyGrid.superclass.initComponent.call(this);
  },
  showGridValueMenu: function(grid, rowIndex, cellIndex, evt){
    grid.menudata = {
      rowIndex: rowIndex
    }
    if (!grid.valuemenu) {
      grid.valuemenu = new Ext.menu.Menu({
        items: [{
          text: 'Copy',
          icon: '/aig/img/copy.gif',
          scope: grid,
          disabled: !top.AIG.ClipboardCtrl.hasClipboardAccess(),
          handler: function(){
            AIG.copyCell(grid, grid.menudata.rowIndex, 1)
          },
          tooltip: {
            html: "Copy the value"
          }
        }]
      })
    }
    grid.valuemenu.showAt(evt.getXY())
  }
})

AIG.propertyGridRender = function(value, numFormat, digits, metadata, record, rowIndex, colIndex, store, qtip, cursor, isLabel){
  var dataType = record.data.Type || 'auto'
  numFormat = numFormat || "fixed"
  digits = (Ext.type(digits) == 'number' && digits >= 0 ? digits : 2)
  isLabel = isLabel || false
    
  var imageURL = record.data['ImageURL']
  var imageALT = record.data['ImageALT']
  var linkURL = record.data.LinkURL
  var qtipImageURL = record.data['QTipImageURL']
    
  var dataTag = null
    
  if (imageURL && !isLabel) {
    dataTag = {
      tag: 'img',
      width: 150,
      src: imageURL
    }
    if (imageALT) {
      imgTag.alt = imageALT
    }
    if (record.data.Type && record.data.Type == 'structure') {
      dataTag.style= 'cursor:pointer'
    }
  } else {
    if (typeof value == "string" && value.length < 1) {
      return "&#160;"
    }
    var color = record.data.Color || 'transparent'
    cursor = cursor || 'auto'
    
    if (cursor== 'auto' && hasLength(linkURL) && !isLabel) {
      cursor = 'pointer'
    }
        
    metadata.attr = "style= 'background-color:" + color + "'";
        
    if (dataType == 'date' && !isLabel) {
      var date = (record.data.Format ? Date.parseDate(value, record.data.Format) : new Date(value))
      dataTag = {
        tag: 'div',
        style: "white-space:normal;cursor:" + cursor,
        html: Ext.util.Format.date(date, "m/d/Y")
      }
    }
        
    if (isLabel || isNaN(value) || dataType == 'string') {
      dataTag = {
        tag: 'div',
        style: "white-space:normal;cursor:" + cursor,
        html: Ext.util.Format.nl2br(Ext.util.Format.htmlEncode(value.replace(/<BR\/>/gi, '\n')))
      }
    } else {
      var num = new Number(value)
      var numFixed
      if (dataType == 'integer') {
        numFixed = num.toFixed(0)
      } else if (numFormat == 'fixed') {
        numFixed = num.toFixed(digits)
      } else {
        numFixed = num.toExponential(digits)
      }
            
      dataTag = {
        tag: 'div',
        style: "white-space:normal;color:" + (num < 0 ? "red" : "green") + ";cursor:" + cursor,
        html: numFixed
      }
    }
  }
  if (dataTag != null) {
    if (qtip) {
      dataTag['ext:qtip'] = Ext.util.Format.htmlEncode(qtip)
    } else if (qtipImageURL) {
      dataTag['ext:qtip'] = Ext.util.Format.htmlEncode("<img src='" + qtipImageURL + "' />")
    }
    if (hasLength(linkURL) && !isLabel) {
      var aTag = {
        tag: 'a',
        href: linkURL,
        target: '_blank',
        style: "text-decoration:underline",
        children: dataTag
      }
      return Ext.DomHelper.markup(aTag)
    }
    return Ext.DomHelper.markup(dataTag)
  }
  return Ext.util.Format.nl2br(Ext.util.Format.htmlEncode(value.replace(/<BR\/>/gi, '\n')))
}
