/**
 * Window which displays an entity property Grid
 *
 *
 * @author    J. McDowell
 * @date      23 March 2009
 * @version   $Id: AIG.StructurePropertyDialog.js,v 1.4 2015/03/05 22:26:06 jemcdowe Exp $
 *
 */
AIG.StructurePropertyDialog= Ext.extend(Ext.Window, {
  layout: 'border',
  stateful: false,
  resizable: true,
  closeAction: 'hide',
  plain: true,
  maximizable: true, 
  
  initComponent: function(){
    var dialog= this
    
    var panels= []
    if (Ext.type(this.structures)!= 'object') {
      return  
    }
    var title= 'Structure'
    try {
      switch(this.structures.db.toLowerCase()) {
        case 'acrf':
          title= 'Compound ' + this.structures.id
          break;
        case 'acrfcomponent':
          title= 'Component ' + this.structures.id
          break;
      }
    } catch(e) {}
    Ext.applyIf(this, {
      title: title,
      width: 500,
      height: 550
    })


    if (Ext.type(this.structures.components)== 'array') {
      for(var i=0; i< this.structures.components.length; i++) {
        var title= "Component "+(i+1)
        panels.push(this.createStructurePanel(this.structures.components[i], title))
      }
    } else { 
      panels.push(this.createStructurePanel(this.structures))
    }
    if (panels.length== 1) {
      this.items= panels[0]
    } else {
      this.items= (this.tabPanel= new Ext.TabPanel({
        region: 'center',
        activeTab: 0,
        items: panels
      }))
    }
    
 
    this.tools= [{
      id: 'plus',
      handler: function() {
        var adjPanel
        if (panels.length== 1) {
          adjPanel= panels[0]
        } else {
          adjPanel= dialog.tabPanel.getActiveTab() 
        }
        AIG.adjustStructureScale(adjPanel.id+'_struct_applet', 'up')
      }
    }, {
      id: 'minus',
      handler: function() {
        var adjPanel
        if (panels.length== 1) {
          adjPanel= panels[0]
        } else {
          adjPanel= dialog.tabPanel.getActiveTab() 
        }
        AIG.adjustStructureScale(adjPanel.id+'_struct_applet', 'down')
      }
    }]
    for(var i=0; i< panels.length; i++) {
      panels[i].on('render', function(panel) { 
        var id= panel.id+'_struct_applet'
        var options= dialog.structures.preferences              
        var call = function(){
          try {
            AIG.setStructureOptions(id, options)
          } catch(e) {
          }                    
        };              
        window.setTimeout(call, 250);
      }
      )
    }
        
    this.buttons = [{
      text: 'Close',
      handler: function(){
        dialog.close()
      }
    }]
    AIG.StructurePropertyDialog.superclass.initComponent.call(this)
  },
  // private
  initEvents : function(){
    AIG.StructurePropertyDialog.superclass.initEvents.call(this);
    this.header.un('dblclick', this.toggleMaximize, this)
  },
  createStructurePanel: function(structure, title) {
    var panelID= Ext.id()
    var contents= structure.contents
        
    var children= [{
      tag: 'tr',
      children: [{
        tag: 'td',
        width: '100%',
        style: 
        'border-bottom: solid 1px #DFE8F6;font-size:8pt;font-weight:bold;-moz-user-select: none;-khtml-user-select: none;user-select: none;cursor:pointer;background: transparent url(http://uslv-papp-rgb02.amgen.com:9090/extjs/ext3/resources/images/default/grid/group-expand-sprite.gif) no-repeat 3px -47px;    padding: 4px 4px 4px 17px;',
        id: panelID+'_struct',
        html: 'Structure [Right-click on structure to copy]',
        onclick: 'AIG.toggleValueVisibility(this)'            
      }]
    }, {
      tag: 'tr', 
      id: panelID+'_struct_value',
      //style: 'display:none',
      children: [
      {
        tag: 'td',            
        children: [{
          tag: 'applet',
          id: panelID+'_struct_applet',
          name: panelID+'_struct_applet_name',
          code: 'com.symyx.draw.JDrawRenderer',
          width: '250',
          height: '250',
          mayscript: 'true',
          archive: '/aig/jdraw/jdrawapplet.jar,/aig/jdraw/jdrawcore.jar,/aig/jdraw/CsInline.jar',
          children: [{
            tag: 'param',
            name: 'java_arguments',
            value: '-Xmx256m -Dsun.java2d.noddraw=true'
          },{
            tag: 'param',
            name: 'chimeString',
            value: structure.chime_string
          },{
            tag: 'param',
            name: 'defaultBondLength',
            value: '50'
          }
          ]
        }]
      }]
    }
    ]
    for(var i=0; i< contents.length; i++) {
      var content= contents[i]
      children.push({
        tag: 'tr',
        children: [{
          tag: 'td',
          style: 
          'border-bottom: solid 1px #DFE8F6;font-size:8pt;font-weight:bold;-moz-user-select: none;-khtml-user-select: none;user-select: none;cursor:pointer;background: transparent url(http://uslv-papp-rgb02.amgen.com:9090/extjs/ext3/resources/images/default/grid/group-expand-sprite.gif) no-repeat 3px -47px;    padding: 4px 4px 4px 17px;',
          id: panelID+'_c'+i,
          html: content.name +" [Select text and right-click to copy]",
          onclick: 'AIG.toggleValueVisibility(this)'
        }]
      })
      children.push({
        tag: 'tr',
        id: panelID+'_c'+i+"_value",
        children: [{
          tag: 'td',
          children: [{
            tag: 'pre',
            html: content.value
          }]
        }]
      })       
    }      
        
    return new Ext.Panel({
      id: panelID,
      region: 'center',
      border: true,
      bodyStyle: 'padding: 3px',
      title: title,
      html: {
        tag: 'table',
        cellpadding: '5',
        cellspacing: '5',
        width: '100%',
        children: children
      },
      autoScroll: true
    })
        
  }
})
  
  

