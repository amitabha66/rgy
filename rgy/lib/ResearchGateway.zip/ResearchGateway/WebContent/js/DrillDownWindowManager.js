/*
 ********************************************************
 * Defines Windows for displaying drill down services
 ********************************************************
 */
/**
 * Provides a registry for drill down windows. 
 * @param {Object} config
 */
AIG.DrillDownWindowManager = function(config){
    config = config ||
    {}
    this.parentContainer = config.parentContainer    
    this.drillDownWindows = new Ext.util.MixedCollection()    
}
AIG.DrillDownWindowManager.prototype = {
    createDrillDownServiceView: function(config){
        if (!this.drillDownWindows.containsKey(config.windowID)) {
            this.drillDownWindows.add(config.windowID, new AIG.DrillDownWindow({
                title: config.windowTitle,
                renderTo: this.parentContainer.getId(),
                windowID: config.windowID,
                drillDownWindowManager: this,
                parentContainer: this.parentContainer,
                iconCls: 'details'
            }))
            this.drillDownWindows.get(config.windowID).show()
            this.drillDownWindows.get(config.windowID).minimized = false
        }
        var newTab = this.drillDownWindows.get(config.windowID).getTabPanel().createServiceView({
            serviceURL: config.serviceURL,
            serviceTitle: config.serviceTitle
        })
        this.drillDownWindows.get(config.windowID).show()
        if (this.drillDownWindows.get(config.windowID).getTabPanel().items.getCount() == 1) {
            this.drillDownWindows.get(config.windowID).getTabPanel().activate(newTab)
        }
    },
    closeDrillDownWindow: function(drillDownWindow){
		this.drillDownWindows.removeKey(drillDownWindow.windowID)
    }	
}

/**
 * DrillDownWindow Object
 * @param {Object} config
 */
AIG.DrillDownWindow = function(config){
    config = config ||
    {}
    this.tabPanel = new RG.Main.ResourceTabsPanel({
        windowID: config.windowID
    })
    var windowSize = Math.min(config.parentContainer.getSize().width, config.parentContainer.getSize().height)
    
    this.windowID = config.windowID
    this.drillDownWindowManager = config.drillDownWindowManager
    config.closable = true
    config.plain = true
    config.layout = 'fit'
    config.maximizable = true
    config.minimizable = false
    config.minHeight = 200
    config.minWidth = 200
    config.constrain = true   
    
    config.width = 0.85 * config.parentContainer.getSize().width
    config.height = 0.85 * config.parentContainer.getSize().height
    
    config.listeners = {
        close: function(win){
            win.drillDownWindowManager.closeDrillDownWindow(win)
        },
        show: function(win){
            if (Ext.type(config.callback) == 'function') {
                config.callback.call(config.callback, win)
                if (!config.callbackeveryshow) {
                    config.callback = Ext.emptyFn
                }
            }
        }
    }
    config.initComponent = function(){
        Ext.apply(this, {
            plugins: [new Ext.ux.IconMenu()]
        });
        // call parent
        AIG.DrillDownWindow.superclass.initComponent.apply(this, arguments);
    }
    config.items = [this.tabPanel]
    
    Ext.apply(this, config)
    AIG.DrillDownWindow.superclass.constructor.call(this)
}

Ext.extend(AIG.DrillDownWindow, Ext.Window, {
    getTabPanel: function(){
        return this.tabPanel
    },
    activateTabByTitle: function(title){
        var panel = this.getTabPanel().find('title', title)
        if (panel && panel.length > 0) {
            this.getTabPanel().activate(panel[0])
        }
    },
    /**
     * Override the Window method to properly accommodate the header/footer toolbars
     */
    fitContainer: function(){
        AIG.DrillDownWindow.superclass.fitContainer.call(this)
    }
})

