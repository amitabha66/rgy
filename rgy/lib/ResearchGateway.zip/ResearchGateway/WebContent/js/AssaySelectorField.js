/**
 * Provides a panel for searching and selecting assays, selecting result types, and updating alias result types
 * @param {Object} config
 * Config Options:
 * show_only_assaycodes: {Boolean} Initial value of the Only Assay Codes switch. Default: false
 * editor: {Boolean} Whether to allow editing of the alias name. Default: false
 * show_alias: {Boolean} Whether to show the alias column. Default: true
 * alias_id: {Array or Integer} Lookup alias id. Used for editing result types of a specific alias. In this state, other
 * fields are affected: Search fields are disabled. editor is set to false. show_alias is set to true
 *
 */
AIG.AssaySelectorField = function(config) {
  config = config ||
          {}
  config.url = '/aig/dhassayquery.go'
  config.title = (config.title === undefined ? null : config.title)
  config.autoScroll = true
  config.frame = false
  config.editor = config.editor || false
  config.show_alias = (config.show_alias == null ? true : config.show_alias)
  config.autoScroll = true
  config.height = 200
  config.width = 600
  config.autoExpandColumn = 'result_types'
  config.enableColumnMove = true
  config.bodyStyle = 'border:solid 1px #99BBE8;background-color:white'
  config.clicksToEdit = 1

  this.SEARCH_OPTIONS = [{
      label: 'Assays/RACs',
      id: 'RACS'
    }, {
      label: 'Parent Assays',
      id: 'PARENTS'
    }, {
      label: 'Alias ID',
      id: 'ALIAS_ID',
      visible: false
    }, {
      label: 'Assay ID',
      id: 'ASSAY_ID',
      visible: false
    }]

  this.init_alias_id = config.alias_id
  this.init_assay_id = config.assay_id
  this.init_alias = config.alias
  this.init_result_types = config.result_types

  this.aggregate = config.aggregate
  this.force_display = config.force_display

  this.assay_edit_mode = false
  this.editor = config.editor

  this.show_aggregate = config.show_aggregate
  this.show_force_display = config.show_force_display

  if (this.init_alias_id) {
    config.show_alias = true
  }
  var lc = new Ext.ux.form.LovCombo({
    width: 300,
    hideOnSelect: false,
    maxHeight: 200,
    resizable: true,
    listWidth: 230,
    name: 'stuff',
    store: new Ext.data.Store({
      autoLoad: false,
      reader: new Ext.data.JsonReader({
        root: "result_types"
      }, [{
          name: 'result_type'
        }, {
          name: 'result_id'
        }])
    }),
    triggerAction: 'all',
    valueField: 'result_type',
    displayField: 'result_type',
    checkField: 'result_type_checked',
    mode: 'local',
    forceSelection: false
  })

  var assaySelectModel = new Ext.grid.CheckboxSelectionModel({
    singleSelect: false
  })
  assaySelectModel.selectRow = function(index, keepExisting, preventViewNotify) {
    Ext.grid.CheckboxSelectionModel.superclass.selectRow.call(this, index, true, preventViewNotify)
  }
  this.AssayRecord = Ext.data.Record.create([{
      name: 'assay_code'
    }, {
      name: 'assay_class'
    }, {
      name: 'alias_id',
      type: 'int'
    }, {
      name: 'assay_name'
    }, {
      name: 'assay_alias'
    }, {
      name: 'assay_desc'
    }, {
      name: 'assay_species'
    }, {
      name: 'result_types'
    }, {
      name: 'aggregate',
      type: 'boolean',
      defaultValue: false
    }, {
      name: 'force_display',
      type: 'boolean',
      defaultValue: false
    }])

  var assayStore = new Ext.data.Store({
    reader: new Ext.data.ArrayReader({}, this.AssayRecord)
  });
  var initData = []
  var gridPlugins = []
  assayStore.loadData(initData)
  var columnConfigs = [assaySelectModel, {
      id: 'assay_class',
      header: "",
      width: 25,
      sortable: true,
      renderer: function(value, metadata, record, rowIndw, colIndex, store) {
        if (value && value == 'RAC') {
          return "<IMG ext:qtip='RAC' SRC='/aig/img/treenodeicons/assay.gif'" + " />"
        } else {
          return "<IMG ext:qtip='Parent Assay Code' SRC='/aig/img/treenodeicons/assays.gif'" + " />"
        }
      },
      dataIndex: 'assay_class'
    }]
  if (config.show_alias) {
    columnConfigs.push({
      id: 'assay_alias',
      header: "Alias",
      width: 75,
      sortable: true,
      editor: (config.editor ? new Ext.form.TextField({
        allowBlank: true
      }) : null),
      dataIndex: 'assay_alias'
    })
  }
  columnConfigs.push({
    id: 'assay_code',
    header: "Assay Code",
    width: 75,
    sortable: true,
    dataIndex: 'assay_code'
  })
  columnConfigs.push({
    id: 'assay_name',
    header: "Name",
    width: 75,
    sortable: true,
    dataIndex: 'assay_name',
    renderer: function(value, metadata, record, rowIndw, colIndex, store) {
      var cell = Ext.util.Format.ellipsis((value ? value : ""), 50)
      var qtipEl = null
      if (value && value.length > 50) {
        qtipEl = 'ext:qtip="' + Ext.util.Format.htmlEncode(value) + '"'
      }
      return "<div >" + cell + "</div>"
    }
  })
  columnConfigs.push({
    id: 'assay_desc',
    header: "Description",
    width: 150,
    sortable: true,
    dataIndex: 'assay_desc',
    renderer: function(value, metadata, record, rowIndw, colIndex, store) {
      var cell = Ext.util.Format.ellipsis((value ? value : ""), 50)
      var qtipEl = null
      var resultCount = 0
      var tip = "<table class='x-assay-desc-tip'>"
      if (value && value.length > 50) {
        if (Ext.type(record.result_types) == 'array') {
          for (var i = 0; i < record.result_types.length; i++) {
            tip += "<tr><td>" + record.result_types[i].result_type_display + "</td><td>" + record.result_types[i].result_count + " Results</td></tr>"
          }
        }
        tip += "</table>"
        tip = value + tip
        qtipEl = 'ext:qtip="' + Ext.util.Format.htmlEncode(tip) + '"'
      }
      return "<div>" + cell + "</div>"
    }
  })
  columnConfigs.push({
    id: 'assay_species',
    header: "Species",
    width: 75,
    sortable: true,
    hidden: true,
    dataIndex: 'assay_species'
  })
  columnConfigs.push({
    id: 'result_types',
    header: "Results",
    width: 300,
    sortable: true,
    editor: lc,
    dataIndex: 'result_types',
    renderer: function(value, metadata, record, rowIndex, colIndex, store) {
      if (value == 'Click To Select Result(s)') {
        return '<I><B>' + value + '</B></I>'
      } else {
        return value
      }
    }
  })

  if (this.show_aggregate) {
    var aggregateResults = new Ext.grid.CheckColumn({
      id: 'show_aggregate',
      dataIndex: 'aggregate',
      header: "Aggregate Results",
      width: 75
    })
    columnConfigs.push(aggregateResults)
    gridPlugins.push(aggregateResults)
  }
  if (this.show_force_display) {
    var displayEmpty = new Ext.grid.CheckColumn({
      id: 'show_force_display',
      dataIndex: 'force_display',
      header: "Display Empty",
      width: 75
    })
    columnConfigs.push(displayEmpty)
    gridPlugins.push(displayEmpty)
  }

  var colModel = new Ext.grid.ColumnModel({
    columns: columnConfigs
  })

  var searchTypeField = new Ext.Toolbar.SplitButton({
    text: this.search_type,
    disabled: this.assay_edit_mode,
    assaySelector: this,
    initComponent: function() {
      var field = this
      var menuItems = []
      for (var i = 0; i < this.assaySelector.SEARCH_OPTIONS.length; i++) {
        if (this.assaySelector.SEARCH_OPTIONS[i].visible !== false) {
          menuItems.push({
            text: this.assaySelector.SEARCH_OPTIONS[i].label,
            checked: (i == 0),
            group: 'search_type',
            searchOption: this.assaySelector.SEARCH_OPTIONS[i],
            checkHandler: function(item, checked) {
              if (checked) {
                searchTypeField.setText(item.searchOption.label)
                field.searchType = item.searchOption
              }
            }
          })
        }
      }
      this.menu = new Ext.menu.Menu({
        items: menuItems
      })
      this.searchType = this.assaySelector.SEARCH_OPTIONS[0]
      if (this.searchType.visible === false) {
        this.disabled = true
      } else {
        this.text = this.searchType.label
      }
      Ext.Toolbar.SplitButton.prototype.initComponent.call(this)
    }
  })

  AIG.AssaySelectorSearchField = Ext.extend(Ext.form.TwinTriggerField, {
    initTrigger: function() {
      AIG.AssaySelectorSearchField.superclass.initTrigger.call(this);
      this.wrap.setStyle('overflow', 'visible');
    },
    validationEvent: false,
    validateOnBlur: false,
    trigger2Class: 'x-form-clear-trigger',
    trigger1Class: 'x-form-search-trigger',
    width: 200,
    hasSearch: false,
    paramName: 'query',
    assayGrid: this,
    disabled: this.assay_edit_mode,
    listeners: {
      specialkey: function(f, e) {
        e.stopPropagation()
        if (e.getKey() == e.ENTER) {
          this.onTrigger1Click()
        }
      }
    },
    onTrigger2Click: function() {
      this.assayGrid.clear(true)
    },
    onTrigger1Click: function() {
      var assayQuery = this.getRawValue();
      if (assayQuery.length < 1) {
        return;
      }
      this.assayGrid.searchAssays(this.assayGrid, assayQuery, searchTypeField.searchType)
    }
  })

  if (!this.assay_edit_mode) {
    config.tbar = new Ext.Toolbar({
      items: ['Search For', '[', searchTypeField, ']:', new AIG.AssaySelectorSearchField()],
      // private
      listeners: {
        render: function(tb) {
          tb.displayEl = Ext.fly(tb.el.dom).createChild({
            cls: 'x-paging-info'
          })
        }
      }
    })
  }
  config.ds = assayStore
  config.cm = colModel
  config.sm = assaySelectModel
  config.plugins = gridPlugins

  config.listeners = {
    afteredit: function(e) {
      var grid = e.grid
      var record = e.record
      var field = e.field
      var value = e.value
      var originalValue = e.originalValue
      var row = e.row
      var column = e.column
      var fieldName = grid.getColumnModel().getDataIndex(column)

      if (fieldName == 'result_types' && (!record.data.result_types || record.data.result_types.length == 0)) {
        record.set("result_types", "Click To Select Result(s)")
      }
      grid.validate()
    },
    beforeedit: function(e) {
      var grid = e.grid
      var record = e.record
      var field = e.field
      var value = e.value
      var originalValue = e.originalValue
      var row = e.row
      var column = e.column
      var fieldName = grid.getColumnModel().getDataIndex(column)
      e.cancel = true

      if (fieldName == 'result_types') {
        if (record.result_types) {
          lc.store.loadData({
            result_types: record.result_types
          })
          e.cancel = false
        }
      } else if (fieldName == 'assay_alias') {
        e.cancel = false
      }
      return !e.cancel

    },
    render: function(grid) {/*
     grid.tooltip = new Ext.ToolTip({
     view: grid.getView(),
     target: grid.getView().mainBody,
     delegate: '.x-grid3-row',
     trackMouse: true,
     renderTo: document.body,
     rowIndex: -1,
     onTargetOver: function(e){
     if (this.disabled || e.within(this.target.dom, true)) {
     return;
     }
     var t = e.getTarget(this.delegate);
     if (t) {
     this.triggerElement = t;
     this.clearTimer('hide');
     this.targetXY = e.getXY();
     this.delayShow();
     }
     },
     onMouseMove: function(e){
     var t = e.getTarget(this.delegate);
     if (t) {
     this.targetXY = e.getXY();
     if (t === this.triggerElement) {
     if (!this.hidden && this.trackMouse) {
     this.setPagePosition(this.getTargetXY());
     }
     } else {
     this.hide();
     this.lastActive = new Date(0);
     this.onTargetOver(e);
     }
     } else if (!this.closable && this.isVisible()) {
     this.hide();
     }
     },
     hide: function(){
     this.clearTimer('dismiss');
     this.lastActive = new Date();
     delete this.triggerElement;
     Ext.ToolTip.superclass.hide.call(this);
     },
     listeners: {
     beforeshow: function(tip){
     var rowIndex = grid.getView().findRowIndex(tip.triggerElement)
     if (rowIndex === false) {
     return
     }
     tip.rowIndex = rowIndex
     var record = grid.getStore().getAt(rowIndex)
     var tipText = "<DIV class='x-assay-desc-tip'><B><U>" + record.data.assay_code + " " + record.data.assay_name + "</U></B>"
     tipText += "<table class='x-assay-desc-tip'>"
     tipText += "<tr><td colspan='2' class='x-assay-desc-tip'>" + record.data.assay_desc + "</td></tr>"
     if (Ext.type(record.result_types) == 'array') {
     tipText += "<table class='x-assay-desc-tip'>"
     for (var i = 0; i < record.result_types.length; i++) {
     tipText += "<tr><td class='x-assay-desc-tip'>" + record.result_types[i].result_type_display + "</td><td>" + record.result_types[i].result_count + " Results</td></tr>"
     }
     }
     tipText += "</table></DIV>"
     tip.body.dom.innerHTML = tipText
     }
     }
     })*/

      if (grid.init_alias_id) {
        new Ext.util.DelayedTask().delay(20, function() {
          grid.searchAssays(grid, grid.init_alias_id, 'ALIAS_ID', grid.init_result_types, grid.select_result_types)
        })
      } else if (grid.init_assay_id) {
        new Ext.util.DelayedTask().delay(20, function() {
          grid.searchAssays(grid, grid.init_assay_id, 'ASSAY_ID', grid.init_result_types, grid.select_result_types)
        })
      }
    },
    rowclick: function(grid) {
      grid.updateMessage()
      if (!grid.editing) {
        grid.validate()
      }
    }
  }

  Ext.apply(this, config)
  AIG.AssaySelectorField.superclass.constructor.call(this)
}

Ext.extend(AIG.AssaySelectorField, Ext.grid.EditorGridPanel, {
  onRender: function(ct, position) {
    AIG.AssaySelectorField.superclass.onRender.call(this, ct, position);	
    this.hiddenField = this.el.insertSibling({
      tag: 'input',
      type: 'hidden',
      name: this.name,
      id: this.name
    }, 'before', true);
  },
  validate: function() {
    this.setHiddenField()
    if (this.allowBlank !== undefined) {
      if (this.allowBlank) {
        return true
      }
    }
    return (this.getSelections() > 0)
  },
  setHiddenField: function() {
    this.hiddenField.value = this.getSelections(true)
  },
  cancelEditing: function() {
    //this.stopEditing(false)
  },
  updateMessage: function() {
    if (this.getTopToolbar().displayEl) {
      var format = "{0} Assays(s), {1} Selected"
      var count = this.store.getCount();
      this.getTopToolbar().displayEl.update(String.format(format, count, this.getSelectionModel().getCount()));
    }
  },
  clear: function(keepSelected) {
    var store = this.store
    var selections = this.getSelectionModel().getSelections()
    store.removeAll()
    if (keepSelected) {
      store.add(selections)
      this.getSelectionModel().selectRecords(selections)
    }
    this.updateMessage()
  },
  searchAssays: function(grid, query, searchType, limitResultTypes, selectResultTypes) {
    var me= this
    if (!grid.searchMask) {
      grid.searchMask = new Ext.LoadMask(grid.getEl(), {
        msg: 'Searching Assays'
      })
    }
    grid.searchMask.show()
    Ext.Ajax.request({
      url: grid.url,
      params: {
        type: 'ASSAY_IDENTIFIER',
        format: 'json',
        query: query,
        search_type: (Ext.type(searchType) == 'string' ? searchType : searchType.id),
        limit_result_types: limitResultTypes,
        select_result_types: selectResultTypes
      },
      success: function(response, options) {
        grid.searchMask.hide()
        var data = null
        try {
          data = Ext.util.JSON.decode(response.responseText)
        } catch (e) {
        }
        if (data != null && data.results) {
          var newRecords = []
          Ext.each(data.results, function(arrayDetails) {
            var assayRecord = new this.AssayRecord({
              assay_code: arrayDetails.assay_code,
              assay_name: arrayDetails.assay_name,
              alias_id: arrayDetails.alias_id,
              assay_alias: grid.init_alias || arrayDetails.assay_alias,
              assay_class: arrayDetails.assay_class,
              assay_desc: arrayDetails.assay_desc,
              assay_species: arrayDetails.assay_species,
              aggregate: grid.aggregate || false,
              force_display: grid.force_display || false,
              result_types: arrayDetails.selected_result_types || 'Click To Select Result(s)'
            })
            assayRecord.result_types = arrayDetails.assay_result_types
            newRecords.push(assayRecord)
          }, this)
          grid.getStore().add(newRecords)
          if (data.msg) {
            Ext.MessageBox.show({
              title: 'Message',
              msg: data.msg,
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.INFO
            })
          }
          if (grid.getStore().getCount() == 1) {
            grid.getSelectionModel().selectFirstRow()
            me.validate()
          }
          grid.ownerCt.init_alias = null
          grid.updateMessage()
        } else {
          showMessageDialog('No assays returned.')
        }
      },
      failure: function(response) {
        grid.searchMask.hide()
        showErrorDialog("Research Gateway Error", response.responseText)
      },
      scope: this
    })
  },
  /**
   * Returns selection in the assay code format:
   * <Assay Code>:<Result Type 1>,<Result Type 2>,...
   */
  getSelections: function(asString, delimiter) {
    var assaySelections = []
    var assaySelector = this
    this.stopEditing(false)
    var records = this.getSelectionModel().getSelections()
    if (records.length == 0 && this.store.getCount() == 1) {
      records.push(this.store.getAt(0))
    }
    var aliasChanged = false
    Ext.each(records, function(record) {
      if (record.data.assay_code && record.data.result_types) {
        assaySelections.push(record.data.assay_code + ":" + record.data.result_types)
      }
    })
    if (asString) {
      return assaySelections.join((delimiter || "\t"))
    } else {
      return assaySelections
    }
  },
  /**
   * Returns assays as an object in the format
   * assay_code: (String) assay code
   * result_types: (String) comma-delimited list of selected result type names
   * assay_alias: (String) alias, if exists
   * alias_id: (Number) alias id, if exists
   * modified: (Boolean) whether the result types or alias name has been modified
   *
   */
  getAssays: function() {
    var assays = []
    this.stopEditing(false)
    var records = this.getSelectionModel().getSelections()
    if (records.length == 0 && this.store.getCount() == 1) {
      records.push(this.store.getAt(0))
    }
    Ext.each(records, function(record) {
      if (record.data.assay_code && record.data.result_types) {
        assays.push({
          assay_code: record.data.assay_code,
          result_types: record.data.result_types,
          assay_alias: record.data.assay_alias,
          alias_id: record.data.alias_id,
          force_display: record.data.force_display || false,
          aggregate: record.data.aggregate || false,
          modified: (record.dirty)
        })
      }
    })
    return assays
  }

})

Ext.reg('rg-assay', AIG.AssaySelectorField)