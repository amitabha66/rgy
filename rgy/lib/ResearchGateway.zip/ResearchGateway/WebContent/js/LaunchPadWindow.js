/**
 * @author jemcdowe
 */
/**
 * @author jemcdowe
 */
AIG.LaunchPadWindow = Ext.extend(Ext.Window, {
    id: 'aig_launchpad',
    layout: 'border',
    shadow: false,
    border: false,
    draggable: true,
    resizable: true,
    closable: true,
    constrain: true,
    closeAction: 'close',
    title: 'Research Gateway Launch Pad',
    initComponent: function(){
        this.items = new LaunchPadPanel(), AIG.LaunchPadWindow.superclass.initComponent.call(this)
    },
    resizeToViewport: function(){
        var size = Ext.getBody().getViewSize();
        var top = 24
        size.height -= top
        this.setPagePosition(0, top)
        this.setSize(size)
        var southPanel = this.items.get(0).items.get(1)
        southPanel.setHeight(Math.max(100, Ext.getBody().getViewSize().height - 400))
    }
    
})

