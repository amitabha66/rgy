/**
 * Dialog which displays a name/description form
 *
 *
 * @author    J. McDowell
 * @date      23 March 2009
 * @version   $Id: NameDescriptionDialog.js,v 1.2 2013/03/06 23:42:48 jemcdowe Exp $
 *
 */
AIG.NameDescriptionDialog = function(config){
  var nameDescFormPanel = new Ext.FormPanel({
    items: [{
      xtype: 'textfield',
      name: 'name',
      fieldLabel: 'Name',
      width: 230,
      value: config.nameValue
    }, {
      xtype: 'textarea',
      name: 'description',
      fieldLabel: 'Description',
      width: 230,
      height: 75,
      value: config.descriptionValue
    }],
    frame: false,
    border: false,
    bodyStyle: 'background-color:transparent'
  })
  var dlg = new Ext.Window({
    items: [nameDescFormPanel],
    buttons: [{
      text: config.ok_text || 'Save',
      handler: function(){
        var values = nameDescFormPanel.getForm().getValues(false)
        dlg.close()
                
        if (Ext.type(config.handler) == 'function') {
          config.handler.call(config.scope, values)
        }
      }
    }, {
      text: 'Cancel',
      handler: function(){
        dlg.close()
      }
    }],
    autoCreate: true,
    title: config.title || 'Create New Item',
    resizable: false,
    constrain: true,
    constrainHeader: true,
    minimizable: false,
    maximizable: false,
    stateful: false,
    modal: true,
    shim: true,
    buttonAlign: "center",
    width: 400,
    height: 200,
    minHeight: 80,
    plain: true,
    footer: true,
    closable: true,
    close: function(){
      dlg.hide()
    },
    listeners: {
      show: function(window){
        nameDescFormPanel.items.get(0).focus(true, 500)
      }
    }
  })
  dlg.show()
  dlg.getEl().addClass('x-panel');
}
