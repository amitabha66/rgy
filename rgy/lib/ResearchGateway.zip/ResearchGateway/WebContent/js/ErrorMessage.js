/**
 * @author jemcdowe
 */
/**
 * Shows an error message dialgo if an error appears in the response.
 * Returns true if there is an error message and the dialog has been show,
 * false otherwise
 * @param {Object} response
 */
AIG.showErrorMessage = function(response, title){
  var msg
  if (Ext.type(response) == 'string') {
    msg = response
  } else if (isXMLResponse(response)) {
    msg = selectSingleNodeValue(response.responseXML, "/AIGError/ErrorText")
    title = selectSingleNodeValue(response.responseXML, "/AIGError/Title")
    if (!msg) {
      return false
    }
  } else {
    return false
  }
  Ext.Msg.show({
    title: title || 'Request Error',
    msg: msg || "Unknown error",
    width: 300,
    modal: true,
    buttons: Ext.MessageBox.OK,
    icon: Ext.MessageBox.ERROR
  })
  return true
}
