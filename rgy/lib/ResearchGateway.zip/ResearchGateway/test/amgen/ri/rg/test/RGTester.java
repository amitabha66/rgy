/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rg.test;

import amgen.ri.aig.AIGException;
import amgen.ri.aig.cache.item.GlobalCacheItem;
import amgen.ri.aig.cache.CacheType;
import amgen.ri.aig.cache.offline.CacheBuilder;
import amgen.ri.aig.cache.offline.CacheBuilderExe;
import amgen.ri.aig.cache.ora.CacheItemDAO;
import amgen.ri.aig.cache.ora.CacheMapper;
import amgen.ri.aig.constants.ServiceNamingContext;
import amgen.ri.asf.sa.uddi.ClassificationSchemeQuery;
import amgen.ri.asf.sa.uddi.ServiceDetails;
import amgen.ri.asf.sa.uddi.UDDIDetails;
import amgen.ri.xml.ExtXMLElement;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author jemcdowe
 */
public class RGTester {

  public RGTester() {
  }

  public SqlSessionFactory getSqlSessionFactory(String factoryID) {
    SqlSessionFactory sqlSessionFactory = null;
    try {
      String resource = "rg.mybatis.config.xml";
      Reader reader = Resources.getResourceAsReader(resource);
      sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader, factoryID);
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
    return sqlSessionFactory;
  }

  public GlobalCacheItem get(CacheType cacheType, String key) {
    SqlSession sqlSession = null;
    try {
      sqlSession = getSqlSessionFactory("rg").openSession();
      CacheMapper mapper = sqlSession.getMapper(CacheMapper.class);

      CacheItemDAO item = new CacheItemDAO(cacheType, "GLOBAL", key);
      mapper.getCacheItem(item);
      return (GlobalCacheItem) item.getCacheObj();
    } catch (Throwable t) {
      t.printStackTrace();
    } finally {
      sqlSession.close();
    }
    return null;
  }

  public Object put(CacheType cacheType, String key, GlobalCacheItem obj) throws AIGException {
    SqlSession sqlSession = null;
    try {
      sqlSession = getSqlSessionFactory("rg").openSession();
      CacheMapper mapper = sqlSession.getMapper(CacheMapper.class);
      CacheItemDAO item = new CacheItemDAO(cacheType, "GLOBAL", key, obj);
      mapper.putCacheItem(item);
      sqlSession.commit();
      return obj;
    } catch (Throwable t) {
      t.printStackTrace();
    } finally {
      sqlSession.close();
    }
    return null;
  }

  public List<ServiceDetails> getAllSortedServices(Collection<String> keys, ServiceNamingContext nameContext) {
    List<ServiceDetails> serviceDetails = new ArrayList<ServiceDetails>();
    SqlSession sqlSession = null;
    try {
      sqlSession = getSqlSessionFactory("rg").openSession();
      CacheMapper mapper = sqlSession.getMapper(CacheMapper.class);
      CacheItemDAO item = new CacheItemDAO(CacheType.SERVICE, "GLOBAL");
      item.setKeys(keys);
      item.setRequestUser("me");
      item.setNameContext(nameContext);
      mapper.getSortedServiceCacheItems(item);

      for (GlobalCacheItem globalCacheItem : item.getCacheItems()) {
        if (globalCacheItem.getCacheObject() instanceof ServiceDetails) {
          serviceDetails.add((ServiceDetails) globalCacheItem.getCacheObject());
        }
      }
    } catch (Throwable t) {
      t.printStackTrace();
    } finally {
      sqlSession.close();
    }
    return serviceDetails;
  }

  /**
   * Returns a List of offline service keys
   */
  public List<String> getOfflineServiceKeys() {
    SqlSession sqlSession = null;
    try {
      sqlSession = getSqlSessionFactory("rg").openSession();
      CacheMapper mapper = sqlSession.getMapper(CacheMapper.class);
      CacheItemDAO item = new CacheItemDAO("GLOBAL");
      mapper.getOfflineServiceKeys(item);
      return item.getKeys();
    } catch (Throwable t) {
      t.printStackTrace();
    } finally {
      sqlSession.close();
    }
    return new ArrayList<String>();
  }

  @BeforeClass
  public static void setUpClass() {
  }

  @AfterClass
  public static void tearDownClass() {
  }

  @Before
  public void setUp() {
  }

  @After
  public void tearDown() {
  }

  // TODO add test methods here.
  // The methods must be annotated with annotation @Test. For example:
  //
  @Test
  public void test() throws Exception {
    //String queryKey = "1KQ:(orAllKeys)CQ:(Research Gateway Entity Type Categorization Scheme=Ames Mutagenic Results|Amgen Drug Targets|Amgen Genes|Array Server Projects|Assay Types|Assays|Biological Structures|CAST Experiments|Cell Culture Runs|Compounds|Construct Lots|Construct Studies|Constructs|Data Analyses|Dates|Documents|Experiments|Folders|Galileo Studies|Genes|Genomic Profiling Datasets|LM Compounds|LM Substances|LMR Constructs|LMR Expression Systems|LMR Harvests|LMR Protein Lots|LMR Recombinant Sequences|LMR Requests|LMR Sequence Sets|Logical Assay Types|Logical Assays|Modified Large Molecules|Mosaic Plates|Notebooks|Nucleotide Accession Numbers|Omics Datasets|Omics Projects|Omics Samples|Omics Samplesets|Pathways|People|Plates|Projects|Protein Accession Numbers|Protein Sequences|RNAi Experiments|RNAi Molecules|Results|SMR Components|SMR Molecules|SMR Structures|Secreted Proteins|Squid Nucleotide Sequences|Squid Protein Sequences|Studies|Substances|Watson PD Studies|Watson PK Studies|Watson Studies|Watson TK Studies)RT:(Query RG Raw Entity Table Definition|QueryTreeNodes Definition)ARR:()";
    //GlobalCacheItem globalCacheItem = (GlobalCacheItem) get(CacheType.SERVICEQUERY, queryKey);
    
   // Collection<String> serviceKeys = (List<String>) globalCacheItem.getCacheObject();
    
    //System.out.println(serviceKeys);
    
    amgen.ri.aig.security.RGAccessController a;
   // RGAccessController c;
  }

  //@Test
  public void test1() throws Exception {
    new CacheBuilder().test();
  }

  protected Collection<ClassificationSchemeQuery> buildQueryFromKey(String queryKey) {
    Pattern keyPattern = Pattern.compile("KQ:\\((.*?)\\)CQ:\\((.*?)\\)RT:\\((.*?)\\)ARR:\\((.*)\\)");
    Matcher keyMatcher = keyPattern.matcher(queryKey);

    if (!keyMatcher.matches()) {
      return null;
    }
    String kq = keyMatcher.group(1);
    String cq = keyMatcher.group(2);
    String rt = keyMatcher.group(3);
    String arrGroups = keyMatcher.group(4);

    List<ClassificationSchemeQuery> queries = new ArrayList<ClassificationSchemeQuery>();

    if (StringUtils.isNotEmpty(rt)) {
      String[] rts = rt.split("\\|");
      for (String rt1 : rts) {
        ClassificationSchemeQuery classificationSchemeQuery = new ClassificationSchemeQuery();
        classificationSchemeQuery.setResultType(rt1);
        queries.add(classificationSchemeQuery);
      }
    }
    if (queries.isEmpty()) {
      queries.add(new ClassificationSchemeQuery());
    }
    if (StringUtils.isNotEmpty(kq)) {
      String[] kqs = kq.split("\\|");
      for (String kq1 : kqs) {
        for (ClassificationSchemeQuery query : queries) {
          query.addFindQualifier(kq1);
        }
      }
    }
    if (StringUtils.isNotEmpty(cq)) {
      String[] cqs = cq.split("\\|");
      for (String cq1 : cqs) {
        String[] c = cq1.split("=", 2);
        if (c.length == 2) {
          for (ClassificationSchemeQuery query : queries) {
            query.addKeyValue(c[0], c[1]);
          }
        }
      }
    }
    if (StringUtils.isNotEmpty(arrGroups)) {
      String[] arrs = arrGroups.split("\\|");
      for (String arr1 : arrs) {
        for (ClassificationSchemeQuery query : queries) {
          query.addInputTypeAcceptsArray(arr1);
        }
      }
    }
    return queries;
  }

  //@Test
  public void test2() throws Exception {
    get(CacheType.SERVICE, "0a0fb9c0-3c44-4346-8d64-dbcaeb346a73");
    get(CacheType.SERVICE, "1b2a6ef4-4ac0-427b-b315-ad946cdd0a31");
    get(CacheType.SERVICE, "dbdee889-1401-4ed2-89d7-09a2ebd741fa");
    get(CacheType.SERVICE, "a12052ab-f017-41a7-bff9-8624a342aaa1");
    get(CacheType.SERVICE, "f9713ef2-8fd8-4ebb-8c2a-81cd17193a51");
    get(CacheType.SERVICE, "afacff67-2498-4ef1-a6c9-f1883db96b22");
    get(CacheType.SERVICE, "8c8ad2ba-79d4-4b1c-86f9-154356b40f68");
    get(CacheType.SERVICE, "7bf10ac4-29d2-4ef9-b237-0cdb953a39e4");
    get(CacheType.SERVICE, "49dbbbe8-caf7-42a6-911c-b4b807e1de6a");
    get(CacheType.SERVICE, "dbdee889-1401-4ed2-89d7-09a2ebd741fa");
    get(CacheType.SERVICE, "edd044b2-cf30-4d90-888a-8d05d26898cd");
    get(CacheType.SERVICE, "af830c56-47c8-4d80-a9c6-1bf0a055aa0b");
    get(CacheType.SERVICE, "17b5d3b7-5caf-4bb7-bf24-bd7b5ab6f031");
    get(CacheType.SERVICE, "b73b3c23-2e9b-4412-9767-dcc6badeff4d");
    get(CacheType.SERVICE, "7b23da78-01ae-47b9-8c27-8e505381e499");
    get(CacheType.SERVICE, "2f6a10a4-812d-4749-969b-ac5e5f302909");
    get(CacheType.SERVICE, "7194c2fc-bae2-438e-bb0f-656c08233f55");
  }

  //@Test
  public void test3() throws Exception {
    ServiceDetails serviceDetails = new ServiceDetails(UDDIDetails.DEV_UDDIDETAILS, "0a0fb9c0-3c44-4346-8d64-dbcaeb346a73", false, false);

    put(CacheType.SERVICE, serviceDetails.getKey(), new GlobalCacheItem(serviceDetails));

    //serviceDetails = (ServiceDetails) get(CacheType.SERVICE, "0a0fb9c0-3c44-4346-8d64-dbcaeb346a73").getCacheObject();
    ExtXMLElement.printPrettyString(serviceDetails.getAsElement(true, false));

  }

  //@Test
  public void test4() throws AIGException {
    SqlSession sqlSession = null;
    try {
      sqlSession = getSqlSessionFactory("rg").openSession();
      CacheMapper mapper = sqlSession.getMapper(CacheMapper.class);
      CacheItemDAO item = new CacheItemDAO(CacheType.SERVICE, "GLOBAL");
      item.setKeys(Arrays.asList("0a0fb9c0-3c44-4346-8d64-dbcaeb346a73",
              "dbdee889-1401-4ed2-89d7-09a2ebd741fa",
              "1b2a6ef4-4ac0-427b-b315-ad946cdd0a31",
              "edd044b2-cf30-4d90-888a-8d05d26898cd",
              "2f6a10a4-812d-4749-969b-ac5e5f302909",
              "7b23da78-01ae-47b9-8c27-8e505381e499"));
      item.setRequestUser("jemcdowe");
      item.setNameContext(ServiceNamingContext.RG_QUERY);
      mapper.getSortedServiceCacheItems(item);
      sqlSession.commit();

      for (GlobalCacheItem g : item.getCacheItems()) {
        System.out.println(g.getCacheObject());
      }
    } catch (Throwable t) {
      t.printStackTrace();
    } finally {
      sqlSession.close();
    }
  }

  //@Test
  public void test5() throws AIGException {
    System.out.println(getOfflineServiceKeys());
  }
}
